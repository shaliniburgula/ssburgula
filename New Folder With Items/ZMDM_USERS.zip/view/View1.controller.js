jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("ZMDM_Users.util.formatter");

var userName = "";

var userId = "";

var indexArray = [];

var updated = false;

sap.ui.controller("ZMDM_Users.controller.View1", {

	onInit: function() {

		/*var oUser = sap.ui2.shell.getUser();

		oUser.load({}, function() {

			userName = oUser.getFullName();

			userId = oUser.getId();

			// var welcomeMessage = oUser.getWelcomeMessage();

			//debugger;

			console.log('you are loggin in with ' + userName + ', your user id is ' + userId);

		}, function(sError) {

			// alert ('user fetching failed ' + sError );

		});*/

		var odropDownJsonModel = new sap.ui.model.json.JSONModel();

		var dropdownModel = {

			results: [{

					"statusCode": "0",

					//	"enabled":false,

					"statusText": "New"

				}



				, {

					"statusCode": "1",

					//	"enabled":true,

					"statusText": "Need Clarification"

				}, {

					"statusCode": "2",

					//	"enabled":true,

					"statusText": "On Hold"

				},



				{

					"statusCode": "3",

					//	"enabled":true,

					"statusText": "InProgress"

				},



				{

					"statusCode": "4",

					//	"enabled":true,

					"statusText": "Completed"

				}



          ]

		};

		odropDownJsonModel.setData(dropdownModel);

		sap.ui.getCore().setModel(odropDownJsonModel, "dropdownModel");

		//	console.log(sap.ui.getCore().getModel("dropdownModel").getData());

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true, "", "");

		// var oJsonPlant = new sap.ui.model.json.JSONModel();

		// var tempArray ={"results" : []};

		var oJson = new sap.ui.model.json.JSONModel();

		var pathSet = "MDMDetailsSet?$filter=StatusCode ne '4'";

		oDataModel.read(pathSet, null, null, false, function(r) {
			oJson.setData(r);
			oJson.setSizeLimit(r.results.length);

		});

		//	console.log(oJson);

		sap.ui.getCore().setModel(oJson, "MDMDetailsModel");

		//sap.ui.getCore().setModel(oJsonPlant , "MDMDetailsPlantModel");

		//	this.getView().byId("idTableRequests").getItems[0].getAggregation("cells")[8].

	},

	Export: function() {

		var data = sap.ui.getCore().getModel("MDMDetailsModel").getData();
		this.JsonToCsvConverter(data, "Report", true);

	},

	JsonToCsvConverter: function(JSONData, ReportTitle, ShowLabel) {

		// If JSONData is not an object then JSON.parse will parse the JSON

		// string in an Object

		var arrData = this.byId("idTableRequests").getItems();

		//	var arrData = typeof JSONData.results != 'object' ? JSON.parse(JSONData.results) : JSONData.results;

		//console.log(arrData);

		var CSV = "";

		// Set Report title in first row or line

		CSV = ReportTitle + "\r\n\n";

		if (ShowLabel) {

			var row = "";

			row = row.slice(0, -1);

			CSV += row + "\r\n";

		}

		//loop is to extract each row

		var columnRow =
			'Material Code,HSN Master, New HSN,HSN from Matl.Master,% of Tax,Vendor ID,Processed By,Action Taken,Remarks,Status,Assigned On,Assigned Time,Created By,Material Description,';

		columnRow = columnRow.slice(0, -1);

		CSV += columnRow + "\r\n";

		for (var i = 0; i < arrData.length; i++) {

			var row = "";

			var bSelected = arrData[i].getAggregation("cells")[2].getSelected();

			var isSelected = "Not Available";

			if (bSelected) {

				isSelected = "Available";

			}

			//arrData[i].getAggregation("cells")[9].getSelectedItem().getText()

			row += '"' + arrData[i].getAggregation("cells")[0].getText()

			+ '","' + isSelected

			+ '","' + arrData[i].getAggregation("cells")[3].getText()

			+ '","' + arrData[i].getAggregation("cells")[4].getText()

			+ '","' + arrData[i].getAggregation("cells")[5].getText()

			+ '","' + arrData[i].getAggregation("cells")[6].getText() //vendor ID 

			+ '","' + arrData[i].getAggregation("cells")[7].getText()

			+ '","' + arrData[i].getAggregation("cells")[8].getValue()

			+ '","' + arrData[i].getAggregation("cells")[9].getValue()

			+ '","' + arrData[i].getAggregation("cells")[10].getButtons()[arrData[i].getAggregation("cells")[10].getSelectedIndex()].getText()

			+ '","' + arrData[i].getAggregation("cells")[11].getText()

			+ '","' + arrData[i].getAggregation("cells")[12].getText()

			+ '","' + arrData[i].getAggregation("cells")[13].getText()

			+ '","' + arrData[i].getAggregation("cells")[1].getText()

			+ '",';

			row.slice(0, row.length - 1);

			CSV += row + '\r\n';

		}

		if (CSV == "") {

			alert("Invalid Data");

			return;

		}

		// Generate a file name

		var fileName = "MyReport_";

		fileName += ReportTitle.replace(/ /g, "_");

		// Initialize file format you want csv or xls

		var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);

		// Now the little tricky part.

		// you can use either>> window.open(uri);

		// but this will not work in some browsers

		// or you will not get the correct file extension

		// this trick will generate a temp <a /> tag

		var link = document.createElement("a");

		link.href = uri;

		// set the visibility hidden so it will not effect on your web layout

		link.style = "visibility:hidden";

		link.download = fileName + ".csv";

		// this part will append the anchor tag and remove it after automatic

		// click

		document.body.appendChild(link);

		link.click();

		document.body.removeChild(link);

	},

	/**



	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered



	 * (NOT before the first rendering! onInit() is used for that one!).



	 * @memberOf view.View1



	 */

	//	onBeforeRendering: function() {

	//

	//	},

	/**



	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.



	 * This hook is the same one that SAPUI5 controls get after being rendered.



	 * @memberOf view.View1



	 */

	onAfterRendering: function() {

		//if (this.getView().byId("MatVenID").getVisible()) {

		var goodsModelItems = this.byId("idTableRequests").getModel("MDMDetailsModel");

		var items = this.byId("idTableRequests").getItems();

		if (goodsModelItems.oData.results && goodsModelItems.oData.results.length) {

			for (var k = 0; k < goodsModelItems.oData.results.length; k++) {

				var key = goodsModelItems.oData.results[k].StatusCode;

				items[k].getAggregation("cells")[10].setSelectedIndex(parseInt(key));

			}

		}

	},

	onChangeOfUserInput: function(oEvent) {

		//console.log(oEvent.getSource().getId());

		updated = true;

		var id = oEvent.getSource().getId();

		var flag = true;

		var arrId = id.split("-");

		var index = arrId[4];

		// console.log("index : " + index);

		if (indexArray.length !== undefined) {

			for (var i = 0; i < indexArray.length; i++) {

				if (indexArray[i] === index) {

					flag = false;

					break;

				}

			}

		}

		if (flag) {

			indexArray.push(index);

		}

		console.log(indexArray);

	},

	onRadioButtonChange: function(oEvent) {

		updated = true;

		var id = oEvent.getSource().getId();

		var flag = true;

		var arrId = id.split("-");

		var index = arrId[4];

		//console.log("index : " + index);

		if (indexArray.length !== undefined) {

			for (var i = 0; i < indexArray.length; i++) {

				if (indexArray[i] === index) {

					flag = false;

					break;

				}

			}

		}

		if (flag) {

			indexArray.push(index);

		}

		// console.log(indexArray); 

		var sId = oEvent.getSource().getId();

		//	var sSelectedKey = sap.ui.getCore().byId(sId).getSelectedKey();

		var sSelectedKey = sap.ui.getCore().byId(sId).getSelectedIndex();

		var parentId = oEvent.getSource().getParent().getId();

		var items = this.getView().byId("idTableRequests").getItems();

		//console.log("sSelectedKey : " + sSelectedKey);

		//	console.log("Parent id : " + parentId);

		var splittedString = parentId.split("-");

		//	console.log(splittedString);

		var index = splittedString[4];

		//	console.log("index : " + index);

		if (sSelectedKey === 0) {

			items[index].getAggregation("cells")[7].setText("");

			items[index].getAggregation("cells")[8].setValue("");

		} else if (sSelectedKey === 1) {

			items[index].getAggregation("cells")[7].setText(userName);

			items[index].getAggregation("cells")[8].setValue("Need Clarification");

		} else if (sSelectedKey === 2) {

			items[index].getAggregation("cells")[7].setText(userName);

			items[index].getAggregation("cells")[8].setValue("On Hold");

		} else if (sSelectedKey === 3) {

			items[index].getAggregation("cells")[7].setText(userName);

			items[index].getAggregation("cells")[8].setValue("In Progress");

		} else {

			items[index].getAggregation("cells")[7].setText(userName);

			items[index].getAggregation("cells")[8].setValue("Completed");

		}

	},

	/**



	 * Called on click of submit button for saving the entries of the table.



	 



	 */

	onSubmit: function() {

		var items = this.byId("idTableRequests").getItems();

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true);

		var B = new Array();

		for (var i = 0; i < indexArray.length; i++)

		{

			var materialObj = {};

			var bSelected = items[parseInt(indexArray[i])].getAggregation("cells")[2].getSelected();

			var isSelected = "";

			if (bSelected) {

				isSelected = "X";

			}

			materialObj.MaterialCode = items[parseInt(indexArray[i])].getAggregation("cells")[0].getText();

			materialObj.MaterialDescription = items[parseInt(indexArray[i])].getAggregation("cells")[1].getText();

			//materialObj.HSNCheck = items[parseInt(indexArray[i])].getAggregation("cells")[2].getText();

			materialObj.HSNCheck = isSelected;

			materialObj.HSNNumber = items[parseInt(indexArray[i])].getAggregation("cells")[3].getText();

			materialObj.HSNMaster = items[parseInt(indexArray[i])].getAggregation("cells")[4].getText();

			materialObj.TaxPercent = items[parseInt(indexArray[i])].getAggregation("cells")[5].getText();

			materialObj.ProcessedBy = /*"developer01";*/ items[parseInt(indexArray[i])].getAggregation("cells")[7].getText();

			materialObj.ActionTaken = items[parseInt(indexArray[i])].getAggregation("cells")[8].getValue();

			materialObj.Remarks = items[parseInt(indexArray[i])].getAggregation("cells")[9].getValue();

			materialObj.StatusCode = items[parseInt(indexArray[i])].getAggregation("cells")[10].getSelectedIndex().toString();

			materialObj.VendorID = items[parseInt(indexArray[i])].getAggregation("cells")[6].getText();

			//console.log("submitting : " + i +"st entry");

			//console.log(materialObj);

			//materialObj.CreatedBy = "developer01";

			B.push(dModel.createBatchOperation("MDMDetailsSet", "POST", materialObj));

		}

		this.getView().setBusy(true);

		jQuery.sap.delayedCall(4000, this, function() {

			dModel.addBatchChangeOperations(B);

			dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this));

			this.getView().setBusy(false);

		});

	},

	onRequestSuccess: function(e) {

		var that = this;

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				sap.m.MessageBox.alert(this.result.error);

			} else {

				sap.m.MessageBox.show("Details saved Successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction == "OK") {

							location.reload(true);

						}

					}.bind(that)

				});

			}

		}

	},

	onUpdateFinished: function() {

		// console.log("update finished called");

		if (updated) {

			console.log("gets inside update");

			var goodsModelItems = this.byId("idTableRequests").getModel("MDMDetailsModel");

			var items = this.byId("idTableRequests").getItems();

			//var items = this.byId("idTableRequests").getItems();

			//	console.log("items");

			//	console.log(items);

			for (var i = 0; i < items.length; i++) {

				var currentMaterial = items[i].getAggregation("cells")[0].getText();

				var currentHSN = items[i].getAggregation("cells")[3].getText();

				var currentTax = items[i].getAggregation("cells")[5].getText();

				// console.log("current material : " + currentMaterial);

				//  console.log("current HSN : " + currentHSN);

				//  console.log("current Tax : " + currentTax);

				for (var k = 0; k < goodsModelItems.oData.results.length; k++) {

					var materialcode = goodsModelItems.oData.results[k].MaterialCode;

					var HSN = goodsModelItems.oData.results[k].HSNNumber;

					var tax = goodsModelItems.oData.results[k].TaxPercent;

					// console.log(" material code : " + materialcode);

					// console.log(" HSN  : " + HSN);

					//  console.log(" Tax  : " + tax);

					var key = goodsModelItems.oData.results[k].StatusCode;

					console.log(" key : " + key);

					if (currentMaterial === materialcode && currentHSN === HSN && currentTax === tax) {

						items[i].getAggregation("cells")[10].setSelectedIndex(parseInt(key));

					}

				}

			}

		}

	},

	onFilter: function() {

		updated = true;

		var dialog = sap.ui.getCore().byId("FilterDialog");

		if (dialog === undefined)

		{

			dialog = sap.ui.xmlfragment("ZMDM_Users.fragments.ViewSettingsFilterDialog", this.getView().getController());

		}

		dialog.open();

	},

	onConfirmFilterDialog: function(e) {

		var p = e.getParameters();

		this.aTableFilters = [];

		$.each(p.filterItems, $.proxy(function(i, f) {

			if (f.sId === "StatusNew" || f.sId === "StatusNeedClar" || f.sId === "StatusOnhold" || f.sId === "StatusInprogress" ||

				f.sId === "StatusCompleted") {

				this.aTableFilters.push(f.getCustomData()[0].getValue().filters);

			}

		}, this));

		if (sap.ui.getCore().byId("idProBy").getValue() != "")

		{

			this.aTableFilters.push(new sap.ui.model.Filter("ProcessedBy", sap.ui.model.FilterOperator.EQ, sap.ui.getCore().byId("idProBy").getValue()));

		}

		if (sap.ui.getCore().byId("idMaterialCode").getValue() != "")

		{

			this.aTableFilters.push(new sap.ui.model.Filter("MaterialCode", sap.ui.model.FilterOperator.Contains, sap.ui.getCore().byId(
				"idMaterialCode").getValue()));

		}

		var startDate = sap.ui.getCore().byId("DateFromPicker").getDateValue();

		var formattedSD = new Date(ZMDM_Users.util.formatter.formattingDatesForFiltering(startDate));

		// console.log(formattedSD);

		var endDate = sap.ui.getCore().byId("DateToPicker").getDateValue();

		var formattedED = new Date(ZMDM_Users.util.formatter.formattingDatesForFiltering(endDate));

		if (startDate !== null && endDate !== null) {

			this.aTableFilters.push(new sap.ui.model.Filter("ProcessedDate", sap.ui.model.FilterOperator.BT, formattedSD, formattedED));

			this.getView().byId("idTableRequests").getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);

		}

		//if(){}

		this.getView().byId("idTableRequests").getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);

		// this.onAfterRendering();

	},
	onCompleted : function(){
	    
	}

	/**



	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.



	 * @memberOf view.View1



	 */

	//	onExit: function() {

	//

	//	}

});