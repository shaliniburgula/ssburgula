jQuery.sap.declare("MDM.utils.Formatter");

jQuery.sap.require("sap.ui.core.Element");

MDM.utils.Formatter = {

	leadingZeros: function(value)

	{

		var formattedVal = parseInt(value);

		return formattedVal;

	},

	HSNCheckHandling: function(fValue) {

		if (fValue === "X" || fValue === "x") {

			return "Available";

		} else {

			return "Not Available";

		}

	},

	ui5ToOdatadataForLocalFiltering: function(data, type) {

		var iDatadt = data;

		var month = (iDatadt.getMonth() + 1);

		var day = iDatadt.getDate()

		if ((iDatadt.getMonth() + 1).toString().length < 2) {

			month = '0' + (iDatadt.getMonth() + 1);

		}

		if ((iDatadt.getDate()).toString().length < 2) {

			day = '0' + iDatadt.getDate();

		}

		iDatadt = day + '-' + month + '-' + iDatadt.getFullYear();

		return iDatadt;

	},

	formattingDatesForFiltering: function(data, type) {

		var iDatadt = data;

		if (data !== null) {

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()

			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}

			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}

			iDatadt = iDatadt.getFullYear() + '-' + month + '-' + day + "T00:00:00";

			return iDatadt;

		}

	},

	formattingENDDatesForFiltering: function(data, type) {

		var iDatadt = data;

		if (data !== null) {

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate() + 1;

			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}

			if ((iDatadt.getDate()).toString().length < 2) {

				var t = iDatadt.getDate();

				day = '0' + day;

			}

			iDatadt = iDatadt.getFullYear() + '-' + month + '-' + day + "T00:00:00";

			return iDatadt;

		}

	},

	formatTime: function(val) {

		var d = new Date(val.ms);

		var s = d.getUTCSeconds();

		var h = d.getUTCHours();

		var m = d.getUTCMinutes();

		var value = h + ":" + m + ":" + s;

		return value;

	},

	statusText: function(value) {

		var statusText;

		if (value === "0")

		{

			statusText = "New";

		} else if (value === "1")

		{

			statusText = "Need Clarification";

		} else if (value === "2")

		{

			statusText = "On Hold";

		} else if (value === "3")

		{

			statusText = "Inprogress";

		} else if (value === "4")

		{

			statusText = "Completed";

		}
         else if (value === "5")

		{

			statusText = "Rejected";

		}
		return statusText;

	},
	leadingZeros : function(value)
	{
	    var formattedVal = parseInt(value);
	    return formattedVal;
	}
};