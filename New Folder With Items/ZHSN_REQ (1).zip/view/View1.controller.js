var user;
var fullName;
var userId;
var booleanMDM,booleanError= true;
jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("MDM.utils.Formatter");

sap.ui.controller("MDM.view.View1", {
	onInit: function() {

    /*var oUser = sap.ui2.shell.getUser();

		oUser.load({}, function() {

			var fullName = oUser.getFullName();

			var userId = oUser.getId();

			var welcomeMessage = oUser.getWelcomeMessage();

			console.log('you are loggin in with ' + fullName + ', your user id is ' + userId);

		}, function(sError) {

			alert('user fetching failed ' + sError);

		});*/

		// end of creating a user profile object

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true, "", "");

		var taskList = {};

		var taskObj = [];

		taskList["myTasks"] = taskObj;

		var myTasksModel = new sap.ui.model.json.JSONModel();

		myTasksModel.setData(taskList);

		var tsModelData = myTasksModel.oData.myTasks;

		var taskData = {};

		taskData.Updkz = "I";

		tsModelData.push(taskData);

		sap.ui.getCore().setModel(myTasksModel, "myTasksModel");

		//		this.byId("idMaterialsTable").setModel(myTasksModel, "myTasksModel");

		var oJson = new sap.ui.model.json.JSONModel();

		var pathSet = "MaterialDetailsSet";

		oDataModel.read(pathSet, null, null, false, function(r) {

			oJson.setData(r);

		});

		sap.ui.getCore().setModel(oJson, "materialModel");

		var oJson2 = new sap.ui.model.json.JSONModel();

		var pathSet2 = "ErrorRecordSet";

		oDataModel.read(pathSet2, null, null, false, function(r) {

			oJson2.setData(r);

			//console.log(oJson2.getData());

		});

		sap.ui.getCore().setModel(oJson2, "errorModel");

	},

	onAdd: function() {

		this.getView().byId("idMaterialsTable").removeSelections();

		var myTasksModel = this.getView().byId("idMaterialsTable").getModel("myTasksModel");

		var items = this.getView().byId("idMaterialsTable").getItems();

		var codeArrValue = [];

		var hsnArrValue = [];

		var taxArrValue = [];

		var desc = [];

		// var hsnMaster = [];

		for (var n = 0; n < items.length; n++) {

			codeArrValue[n] = items[n].getAggregation("cells")[0].getValue();

			hsnArrValue[n] = items[n].getAggregation("cells")[1].getValue();

			taxArrValue[n] = items[n].getAggregation("cells")[2].getValue();

			desc[n] = items[n].getAggregation("cells")[5].getText();

			//hsnMaster[n] = items[n].getAggregation("cells")[4].getText();

		}

		var tsModelData = myTasksModel.oData.myTasks;

		var taskData = {};

		taskData.MaterialCode = "";

		taskData.HSNNumber = "";

		taskData.TaxPercent = "";

		taskData.MaterialDescription = "";

		taskData.Updkz = "I";

		tsModelData.push(taskData);

		this.getView().byId("idMaterialsTable").setModel(myTasksModel);

		this.getView().byId("idMaterialsTable").getModel().refresh(true);

		items = this.getView().byId("idMaterialsTable").getItems();

		for (var n = 0; n < codeArrValue.length; n++) {

			items[n].getAggregation("cells")[0].setValue(codeArrValue[n]);

			items[n].getAggregation("cells")[1].setValue(hsnArrValue[n]);

			items[n].getAggregation("cells")[2].setValue(taxArrValue[n]);

			items[n].getAggregation("cells")[5].setText(desc[n]);

			//            items[n].getAggregation("cells")[4].setText(hsnMaster[n]);

		}

		this.getView().byId("idMaterialsTable").setSelectedItem("");

	},

	onSubmit: function() {

		var items = this.byId("idMaterialsTable").getItems();

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true);
		var B = new Array();
		var flag = true;
		var regExp = /^[0-9]+$/;
		for (var i = 0; i < items.length; i++) {
			if (items[i].getAggregation("cells")[0].getValue() === "") {
				items[i].getAggregation("cells")[0].setValueState(sap.ui.core.ValueState.Error);
				items[i].getAggregation("cells")[0].setValueStateText("Please enter");
				flag = false;
			}  else {

				if (!items[i].getAggregation("cells")[0].getValue().match(regExp)) {

					items[i].getAggregation("cells")[0].setValueState(sap.ui.core.ValueState.Error);

					items[i].getAggregation("cells")[0].setValueStateText("Please provide valid numeric Material Code only");

					flag = false;

				} else {

					items[i].getAggregation("cells")[0].setValueState(sap.ui.core.ValueState.None);

				}

			}

			if (items[i].getAggregation("cells")[1].getValue() === "") {

				items[i].getAggregation("cells")[1].setValueState(sap.ui.core.ValueState.Error);

				items[i].getAggregation("cells")[1].setValueStateText("Please enter");

				flag = false;

				//this.byId("idReq").setVisible(true);

			} else {

				if (!items[i].getAggregation("cells")[1].getValue().match(regExp) ||items[i].getAggregation("cells")[1].getValue().length>8 ) { 

					items[i].getAggregation("cells")[1].setValueState(sap.ui.core.ValueState.Error);

					items[i].getAggregation("cells")[1].setValueStateText("Please give valid HSN - Numeric and max. 8 digits");

					flag = false;

				} else {

					items[i].getAggregation("cells")[1].setValueState(sap.ui.core.ValueState.None);

				}

			}

			if (items[i].getAggregation("cells")[2].getValue() === "") {

				items[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

				items[i].getAggregation("cells")[2].setValueStateText("Please provide valid percentage");

				flag = false;

				//this.byId("idReq").setVisible(true);

			} else {

				if (!items[i].getAggregation("cells")[2].getValue().match(regExp)) {

					items[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

					items[i].getAggregation("cells")[2].setValueStateText("Please provide valid percentage");

					flag = false;

				} else {

					items[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.None);

				}

			}

			// mandatory check for vendor id if HSN and HSN from material master are different

			if (items[i].getAggregation("cells")[1].getValue().trim() !== items[i].getAggregation("cells")[6].getText().trim()) {

				if (items[i].getAggregation("cells")[3].getEditable()) {
					if (items[i].getAggregation("cells")[3].getValue() === "") {

						items[i].getAggregation("cells")[3].setValueState(sap.ui.core.ValueState.Error);

						items[i].getAggregation("cells")[3].setValueStateText("Please enter Vendor Id");

						flag = false;

					} else {

						items[i].getAggregation("cells")[3].setValueState(sap.ui.core.ValueState.None);

					}
				} else {
					items[i].getAggregation("cells")[3].setValue("");
				}

			} else {

				items[i].getAggregation("cells")[3].setValue("");

			}

		}

		if (flag) {

			for (var i = 0; i < items.length; i++)

			{

				var materialObj = {};

				materialObj.MaterialCode = items[i].getAggregation("cells")[0].getValue();

				materialObj.HSNNumber = items[i].getAggregation("cells")[1].getValue();

				materialObj.TaxPercent = items[i].getAggregation("cells")[2].getValue();

				materialObj.VendorID = items[i].getAggregation("cells")[3].getValue();

				materialObj.MaterialDescription = items[i].getAggregation("cells")[5].getText();

				materialObj.CreatedBy = fullName;

				B.push(dModel.createBatchOperation("MaterialDetailsSet", "POST", materialObj));

			}

			this.getView().setBusy(true);

			jQuery.sap.delayedCall(4000, this, function() {

				dModel.addBatchChangeOperations(B);

				dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this));

				this.getView().setBusy(false);

			});

		}

	},

	onRequestSuccess: function(e) {

		var that = this;

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				//sap.m.MessageBox.alert(this.result.error);

				//	console.log("getting in the right block");

				sap.m.MessageBox.show(this.result.error, {

					icon: sap.m.MessageBox.Icon.ERROR,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction == "OK") {

							location.reload(true);

						}

					}.bind(that)

				});

			} else {

				sap.m.MessageBox.show("Details saved Successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction == "OK") {

							location.reload(true);

						}

					}.bind(that)

				});

			}

		}

	},

	onRequestFailed: function(e) {

		if (e.response) {

			//if (Object.keys(e.response[0]).indexOf("response") === 1) {

			var j = e.response.body;

			var n = $.parseJSON(j);

			this.result = {};

			this.result.error = n.error.message.value;

			sap.m.MessageBox.alert(this.result.error);

			//}

		}

	},

	onClickDeleteRecord: function(e) {

		var selectedList = this.getView().byId("idMaterialsTable").getSelectedItems();

		for (var i = 0; i < selectedList.length; i++) {

			if (selectedList[i].getAggregation("cells")[6].getText() !== "")

				selectedList[i].getAggregation("cells")[6].setText("D");

		}

		if (selectedList.length > 0) {

			var items = this.getView().byId("idMaterialsTable").getItems();

			var taskList = {};

			var taskObj = [];

			taskList["myTasks"] = taskObj;

			var myTasksModelNew = new sap.ui.model.json.JSONModel();

			myTasksModelNew.setData(taskList);

			var tsModelDataNew = myTasksModelNew.oData.myTasks;

			var count = 0;

			var codeArrValue = [];

			var hsnArrValue = [];

			var taxArrValue = [];

			var desc = [];

			//var hsnMaster = [];

			for (var k = 0; k < items.length; k++) {

				if (items[k].getAggregation("cells")[6].getText() === "" || items[k].getAggregation("cells")[6].getText() === "I") {

					var taskData = {};

					codeArrValue[count] = items[k].getAggregation("cells")[0].getValue();

					hsnArrValue[count] = items[k].getAggregation("cells")[1].getValue();

					taxArrValue[count] = items[k].getAggregation("cells")[2].getValue();

					desc[count] = items[k].getAggregation("cells")[5].getText();

					//		hsnMaster[count] = items[k].getAggregation("cells")[4].getText();

					taskData.Updkz = items[k].getAggregation("cells")[6].getText();

					tsModelDataNew.push(taskData);

					count++;

				}

			}

			this.getView().byId("idMaterialsTable").setModel(myTasksModelNew);

			this.getView().byId("idMaterialsTable").getModel().refresh(true);

			sap.ui.getCore().getModel("myTasksModel").setData(this.getView().byId("idMaterialsTable").getModel().getData());

			items = this.getView().byId("idMaterialsTable").getItems();

			for (var n = 0; n < taxArrValue.length; n++) {

				items[n].getAggregation("cells")[0].setValue(codeArrValue[n]);

				items[n].getAggregation("cells")[1].setValue(hsnArrValue[n]);

				items[n].getAggregation("cells")[2].setValue(taxArrValue[n]);

				items[n].getAggregation("cells")[5].setText(desc[n]);

				//	items[n].getAggregation("cells")[4].setValue(hsnMaster[n]);

			}

			this.getView().byId("idMaterialsTable").removeSelections();

		}

	},

	onUpload: function(e) {

		var fU = this.getView().byId("idfileUploader");

		var domRef = fU.getFocusDomRef();

		var file = domRef.files[0];

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true);
		var dModelErrors = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true);

		var B = new Array();
		var errorArray = new Array();
		// Create a File Reader object

		var reader = new FileReader();

		var t = this;

		if (!this.msieversion()) {

			reader.onload = function(e) {

				var strCSV = e.target.result;

				var arrCSV = strCSV.match(/[\w .]+(?=,?)/g);

				var noOfCols = 3;

				// To ignore the first row which is header

				var hdrRow = arrCSV.splice(0, noOfCols);

				var data = [];

				while (arrCSV.length > 0) {

					var obj = {};

					// extract remaining rows one by one

					var row = arrCSV.splice(0, noOfCols)

					for (var i = 0; i < row.length; i++) {

						obj[hdrRow[i]] = row[i].trim()

					}

					// push row to an array

					data.push(obj)

				}

				// Bind the data to the Table

				var myBulkModel = new sap.ui.model.json.JSONModel();

				myBulkModel.setData(data);

				var oTable = t.byId("idBulkTable");

				oTable.setModel(myBulkModel, "myBulkModel");
                	var regExp = /^[0-9]+$/;
                	var materialObj = {}; 
					var errorObj ={};

				var itemsBulk = t.byId("idBulkTable").getModel("myBulkModel").getData();
				for (var i = 0; i < itemsBulk.length; i++) {
                    var materialCode = itemsBulk[i].MaterialCode;
                    var taxPercent = itemsBulk[i].PercentofTax;
                    var hsnNumber = itemsBulk[i].HSNNumber;
                    
                    
                    if(!materialCode.match(regExp))
					{
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "MaterialCode should be Numeric only"

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}
					else if(!hsnNumber.match(regExp)){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "HSNNumber should be Numeric only"

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}else if(hsnNumber.length>8){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "Maximum of 8 digits are allowed for HSNNumber  "

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}else if( !taxPercent.match(regExp)){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "Tax percent should be Numeric only"

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}else if(taxPercent.length>2){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "Maximum of 2 digits are allowed for Tax percent "

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}
					else{
					materialObj.MaterialCode = itemsBulk[i].MaterialCode;

					materialObj.HSNNumber = itemsBulk[i].HSNNumber;

					materialObj.TaxPercent = itemsBulk[i].PercentofTax;

					materialObj.CreatedBy = fullName;

					B.push(dModel.createBatchOperation("MaterialDetailsSet", "POST", materialObj));
					}
				}

				sap.ui.getCore().byId("idView1").setBusy(true);
				jQuery.sap.delayedCall(4000, this, function() {

					dModel.addBatchChangeOperations(B);
					dModelErrors.addBatchChangeOperations(errorArray);
                    
					//dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this.onRequestFailed));
                    
                    if(errorArray.length>0){
					dModelErrors.submitBatch(dModel, function(responseBody, sucRes) {

						var that = this;

						if (sucRes.data.__batchResponses && sucRes.data.__batchResponses.length > 0) {

							if (Object.keys(sucRes.data.__batchResponses[0]).indexOf("response") === 1) {

								var j = sucRes.data.__batchResponses[0].response.body;

								var n = $.parseJSON(j);

								this.result = {};

								this.result.error = n.error.message.value;

								sap.m.MessageBox.show(this.result.error, {

									icon: sap.m.MessageBox.Icon.ERROR,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

									//		location.reload(true);

										}

									}.bind(that)

								});
                                booleanError = true;
							} else {
                                 booleanError = true;
								sap.m.MessageBox.show(errorArray.length +"records got failed. Please check in Errors tab" , {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

								//			location.reload(true);

										}

									}.bind(that)

								});

							}

						}
					}, function(failRes) {

						var errorBody = JSON.parse(failRes.response.body);

						console.log("fail");

						sap.m.MessageBox.alert(errorBody.error.message.value);

					});
                    }if(B.length>0){
					dModel.submitBatch(dModel, function(responseBody, sucRes) {

						var that = this;

						if (sucRes.data.__batchResponses && sucRes.data.__batchResponses.length > 0) {

							if (Object.keys(sucRes.data.__batchResponses[0]).indexOf("response") === 1) {

								var j = sucRes.data.__batchResponses[0].response.body;

								var n = $.parseJSON(j);

								this.result = {};

								this.result.error = n.error.message.value;
                                booleanError = true;
								sap.m.MessageBox.show(this.result.error, {

									icon: sap.m.MessageBox.Icon.ERROR,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

										location.reload(true);

										}

									}.bind(that)

								});

							} else {
                                booleanError = true;
								sap.m.MessageBox.show("Details saved Successfully", {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});

							}

						}
					}, function(failRes) {

						var errorBody = JSON.parse(failRes.response.body);

						console.log("fail");

						sap.m.MessageBox.alert(errorBody.error.message.value);

					});
                    }
                    var that = this;
                    /*if( booleanError === false && booleanMDM ===false ){
                        var errorMDM = this.result.error; 
                        var errorValue = errorMDM.split(" ");
                        var totalRecords = parseInt(errorValue[0])+ errorArray.length;
                        sap.m.MessageBox.show(totalRecords +"records got failed. Please check in Errors tab" , {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});
                    }else if( booleanError === true && booleanMDM ===false)
                    {
                        
                        sap.m.MessageBox.show(this.result.error  , {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								}); 	
                    }else if( booleanError === false && booleanMDM ===true)
                    {
                        sap.m.MessageBox.show(errorArray.length +"records got failed. Please check in Errors tab" , {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});
                    }else if( booleanError === false && booleanMDM ===true)
                    {
                        sap.m.MessageBox.show("Details saved successfully" , {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});
                    }*/
                    
					sap.ui.getCore().byId("idView1").setBusy(false);

				});
				
				

			};

			reader.readAsBinaryString(file);

		} else {

			reader.onload = function(e) {

				var strCSV = e.target.result;

				var arrCSV = strCSV.match(/[\w .]+(?=,?)/g);

				var noOfCols = 3;

				// To ignore the first row which is header

				var hdrRow = arrCSV.splice(0, noOfCols);

				var data = [];

				while (arrCSV.length > 0) {

					var obj = {};

					// extract remaining rows one by one

					var row = arrCSV.splice(0, noOfCols)

					for (var i = 0; i < row.length; i++) {

						obj[hdrRow[i]] = row[i].trim()

					}

					// push row to an array

					data.push(obj)

				}

				// Bind the data to the Table

				var myBulkModel = new sap.ui.model.json.JSONModel();

				myBulkModel.setData(data);

				var oTable = t.byId("idBulkTable");

				oTable.setModel(myBulkModel, "myBulkModel");
                
                	var regExp = /^[0-9]+$/;
                	var materialObj = {}; 
					var errorObj ={};

				var itemsBulk = t.byId("idBulkTable").getModel("myBulkModel").getData();
				for (var i = 0; i < itemsBulk.length; i++) {
                    var materialCode = itemsBulk[i].MaterialCode;
                    var taxPercent = itemsBulk[i].PercentofTax;
                    var hsnNumber = itemsBulk[i].HSNNumber;
                    
                    if(!materialCode.match(regExp))
					{
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "MaterialCode should be Numeric only"

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}
					else if(!hsnNumber.match(regExp)){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "HSNNumber should be Numeric only"

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}else if(hsnNumber.length>8){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "Maximum of 8 digits are allowed for HSNNumber  "

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}else if( !taxPercent.match(regExp)){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "Tax percent should be Numeric only"

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}else if(taxPercent.length>2){
					    errorObj.MaterialCode = itemsBulk[i].MaterialCode;

					    errorObj.HSNNumber = itemsBulk[i].HSNNumber;

					    errorObj.TaxPercent = itemsBulk[i].PercentofTax;

					    errorObj.CreatedBy = fullName;
					    errorObj.ErrorText = "Maximum of 2 digits are allowed for Tax percent "

					    errorArray.push(dModel.createBatchOperation("ErrorRecordSet", "POST", errorObj));
					    
					}
					else{
					materialObj.MaterialCode = itemsBulk[i].MaterialCode;

					materialObj.HSNNumber = itemsBulk[i].HSNNumber;

					materialObj.TaxPercent = itemsBulk[i].PercentofTax;

					materialObj.CreatedBy = fullName;

					B.push(dModel.createBatchOperation("MaterialDetailsSet", "POST", materialObj));
					}
				}
				sap.ui.getCore().byId("idView1").setBusy(true);

				jQuery.sap.delayedCall(4000, this, function() {

					dModel.addBatchChangeOperations(B);
                    dModel.addBatchChangeOperations(errorArray);
					//dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this.onRequestFailed));

					
                    if(B.length>0){
					dModel.submitBatch(dModel, function(responseBody, sucRes) {

						var that = this;

						if (sucRes.data.__batchResponses && sucRes.data.__batchResponses.length > 0) {

							if (Object.keys(sucRes.data.__batchResponses[0]).indexOf("response") === 1) {

								var j = sucRes.data.__batchResponses[0].response.body;

								var n = $.parseJSON(j);

								this.result = {};

								this.result.error = n.error.message.value;

								sap.m.MessageBox.show(this.result.error, {

									icon: sap.m.MessageBox.Icon.ERROR,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});

							} else {

								sap.m.MessageBox.show("Details saved Successfully", {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});

							}

						}
					}, function(failRes) {

						var errorBody = JSON.parse(failRes.response.body);

						console.log("fail");

						sap.m.MessageBox.alert(errorBody.error.message.value);

					});
                    }
                    if(errorArray.length>0){
					dModelErrors.submitBatch(dModel, function(responseBody, sucRes) {

						var that = this;

						if (sucRes.data.__batchResponses && sucRes.data.__batchResponses.length > 0) {

							if (Object.keys(sucRes.data.__batchResponses[0]).indexOf("response") === 1) {

								var j = sucRes.data.__batchResponses[0].response.body;

								var n = $.parseJSON(j);

								this.result = {};

								this.result.error = n.error.message.value;

								sap.m.MessageBox.show(this.result.error, {

									icon: sap.m.MessageBox.Icon.ERROR,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});

							} else {

								sap.m.MessageBox.show(errorArray.length +"records got failed. Please check in Errors tab" , {

									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],

									onClose: function(oAction) {

										if (oAction == "OK") {

											location.reload(true);

										}

									}.bind(that)

								});

							}

						}
					}, function(failRes) {

						var errorBody = JSON.parse(failRes.response.body);

						console.log("fail");

						sap.m.MessageBox.alert(errorBody.error.message.value);

					});
                    }

					sap.ui.getCore().byId("idView1").setBusy(false);

				});

			};

			reader.readAsText(file);

		}

	},

	toFetchVendorDesc: function(oEvent) {

		var value = oEvent.getSource().sId.split("--idMaterialsTable-");

		console.log(value[1]);

		var items = this.getView().byId("idMaterialsTable").getItems();

		var vendorId = items[value[1]].getAggregation("cells")[3].getValue();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true, "", "");

		var oJson = new sap.ui.model.json.JSONModel();

		var pathSet = "VendorDescSet(VendorID='" + vendorId + "')";

		oDataModel.read(pathSet, null, null, false, function(r) {

			oJson.setData(r);

		});

		var VendorDesc = oJson.getData().VendorDescription;

		var VendorID = oJson.getData().VendorID;

		if (!VendorID) {

			items[value[1]].getAggregation("cells")[3].setValue("");

			items[value[1]].getAggregation("cells")[4].setText("");

		} else {

			items[value[1]].getAggregation("cells")[3].setValue(VendorID);

			items[value[1]].getAggregation("cells")[4].setText(VendorDesc);

		}

	},

	forVenderCheck: function(oEvent) {
		var value = oEvent.getSource().sId.split("--idMaterialsTable-");

		//	console.log(value[1]);

		var items = this.getView().byId("idMaterialsTable").getItems();

		var newHSN = items[value[1]].getAggregation("cells")[1].getValue();
		var hsnFromMatlMaster = items[value[1]].getAggregation("cells")[6].getText();
		if (hsnFromMatlMaster !== "") {
			if (newHSN.trim() === hsnFromMatlMaster.trim()) {

				items[value[1]].getAggregation("cells")[3].setEditable(false);
			} else {
				items[value[1]].getAggregation("cells")[3].setEditable(true);
			}
		} else {
			items[value[1]].getAggregation("cells")[3].setEditable(false);
		}

	},

	toFetchDesc: function(oEvent) {

		var value = oEvent.getSource().sId.split("--idMaterialsTable-");

		console.log(value[1]);

		var items = this.getView().byId("idMaterialsTable").getItems();

		var materialCode = items[value[1]].getAggregation("cells")[0].getValue();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_MDM_SRV/", true, "", "");

		var oJson = new sap.ui.model.json.JSONModel();

		var pathSet = "MaterialTextSet?$filter=Material eq'" + materialCode + "'";

		oDataModel.read(pathSet, null, null, false, function(r) {

			oJson.setData(r);

		});

		if (oJson.getData().results.length > 0) {

			var materialDesc = oJson.getData().results[0].MaterialDescription;

			var HSNMaster = oJson.getData().results[0].HSNMaster;

			items[value[1]].getAggregation("cells")[5].setText(materialDesc);

			items[value[1]].getAggregation("cells")[6].setText(HSNMaster);
			items[value[1]].getAggregation("cells")[3].setEditable(false);

		} else {

			items[value[1]].getAggregation("cells")[5].setText("");

			items[value[1]].getAggregation("cells")[6].setText("");
			items[value[1]].getAggregation("cells")[3].setEditable(false);

		}

		/*	var hsnMaster = oHSNJson.getData().HSNMaster;







			items[value[1]].getAggregation("cells")[4].setText(hsnMaster);







		*/

	},

	onUserManual: function() {

		var i = "/sap/opu/odata/sap/ZGST_MDM_SRV/UserManualSet(FileName='')/$value";

		window.open(i, "_blank");

	},

	onBulkRequest: function() {

		var JSONData = new sap.ui.model.json.JSONModel();

		var classifmodel = {

			results: [







				{

					"Desc": "MaterialCode",

					"HSN": "HSNNumber",

					"Tax": "PercentofTax"

          }]

		};

		JSONData.setData(classifmodel);

		this.JsonToCsvConverter(classifmodel, "Template", true);

	},

	JsonToCsvConverter: function(JSONData, ReportTitle, ShowLabel) {

		var arrData = typeof JSONData.results != 'object' ? JSON.parse(JSONData.results) : JSONData.results;

		console.log(arrData);

		var CSV = "";

		for (var i = 0; i < arrData.length; i++) {

			var row = "";

			row += '"' + arrData[i].Desc +

			'","' + arrData[i].HSN +

			'","' + arrData[i].Tax +

			'",';

			row.slice(0, row.length - 1);

			CSV += row + '\r\n';

		}

		if (CSV == "") {

			alert("Invalid Data");

			return;

		}

		var fileName = "BulkRequest_";

		var blob = new Blob([CSV], {

			type: "text/csv;charset=utf-8;"

		});

		if (navigator.msSaveBlob) { // IE 10+

			navigator.msSaveBlob(blob, "BulkRequest_Template.csv")

		} else {

			fileName += ReportTitle.replace(/ /g, "_");

			var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);

			var link = document.createElement("a");

			link.href = uri;

			link.style = "visibility:hidden";

			link.download = fileName + ".csv";

			document.body.appendChild(link);

			link.click();

			document.body.removeChild(link);

		}

	},

	msieversion: function() {

		var ua = window.navigator.userAgent;

		var msie = ua.indexOf("MSIE ");

		if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return true

		{

			return true;

		} else { // If another browser,

			return false;

		}

		return false;

	},

	onFilter: function() {

		var dialog = sap.ui.getCore().byId("FilterDialog");

		if (dialog === undefined)

		{

			dialog = sap.ui.xmlfragment("MDM.fragments.ViewSettingsFilterDialog", this.getView().getController());

		}

		dialog.open();

	},
	onErrorsFilter: function() {

		var dialog = sap.ui.getCore().byId("ErrorsFilterDialog");

		if (dialog === undefined)

		{

			dialog = sap.ui.xmlfragment("MDM.fragments.ErrorsViewSettingsFilterDialog", this.getView().getController());

		}

		dialog.open();

	},

	onConfirmFilterDialog: function(e) {

		var p = e.getParameters();

		this.aTableFilters = [];

		$.each(p.filterItems, $.proxy(function(i, f) {

			if (f.sId === "StatusNew" || f.sId === "StatusNeedClar" || f.sId === "StatusOnhold" || f.sId === "StatusInprogress" ||

				f.sId === "StatusCompleted" || f.sId === "StatusRejected") {

				this.aTableFilters.push(f.getCustomData()[0].getValue().filters);

			}

		}, this));

		var startDate = sap.ui.getCore().byId("DateFromPicker").getDateValue();

		var formattedSD = new Date(MDM.utils.Formatter.formattingDatesForFiltering(startDate));

		console.log(formattedSD);

		var endDate = sap.ui.getCore().byId("DateToPicker").getDateValue();

		var formattedED = new Date(MDM.utils.Formatter.formattingENDDatesForFiltering(endDate));

		if (startDate !== null && endDate !== null) {

			this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, formattedSD, formattedED));

		}
		
		if (sap.ui.getCore().byId("idMaterialCode").getValue() != "")

		{

			this.aTableFilters.push(new sap.ui.model.Filter("MaterialCode", sap.ui.model.FilterOperator.Contains, sap.ui.getCore().byId(
				"idMaterialCode").getValue()));

		}

		//if(){}

		this.getView().byId("idTableRequests").getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);

	},
	
	onConfirmErrorFilterDialog: function(e) {

		var p = e.getParameters();

		this.aTableFilters = [];

		var startDate = sap.ui.getCore().byId("DateFromPickerE").getDateValue();

		var formattedSD = new Date(MDM.utils.Formatter.formattingDatesForFiltering(startDate));

		console.log(formattedSD);

		var endDate = sap.ui.getCore().byId("DateToPickerE").getDateValue();

		var formattedED = new Date(MDM.utils.Formatter.formattingENDDatesForFiltering(endDate));

		if (startDate !== null && endDate !== null) {

			this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, formattedSD, formattedED));

		}
		
		if (sap.ui.getCore().byId("idMaterialCodeE").getValue() != "")

		{

			this.aTableFilters.push(new sap.ui.model.Filter("MaterialCode", sap.ui.model.FilterOperator.Contains, sap.ui.getCore().byId(
				"idMaterialCodeE").getValue()));

		}

		//if(){}

		this.getView().byId("idTableErrors").getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);

	}


	

});