/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"te3/tes1/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});