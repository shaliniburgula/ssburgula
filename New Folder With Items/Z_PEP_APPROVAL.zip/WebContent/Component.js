sap.ui.define([
  'sap/ui/core/UIComponent',
  'sap/m/routing/Router',
  'sap/ui/model/resource/ResourceModel',
  'sap/ui/model/odata/ODataModel',
  'sap/ui/model/json/JSONModel'
], function(UIComponent,
	Router,
	ResourceModel,
	ODataModel,
	JSONModel) {

	return UIComponent.extend("hcm.people.profile.Z_PEP_APPROVAL.Component", {

		metadata: {
			includes: ["css/style.css"],
			routing: {
				config: {
					routerClass: Router,
					viewType: "XML",
					viewPath: "hcm.people.profile.Z_PEP_APPROVAL.view",
					controlId: "splitApp",
					transition: "slide",

					bypassed: {

					}
				},
				routes: [
					{
						pattern: "",
						name: "home",
						target: ["home", "welcome"]
          },
					{
						pattern: "Address",
						name: "Address",
						target: "Address",
						viewId:"Address"
          },
					{
						pattern: "AddressDetails/{contextPath}",
						name: "AddressDetails",
						target: "AddressDetails"
          },
					{
						pattern: "Educational",
						name: "Educational",
						target: "Educational"
          },
					{
						pattern: "EducationalDetails/{contextPath}",
						name: "EducationalDetails",
						target: "EducationalDetails"
          },
					{
						pattern: "Experience",
						name: "Experience",
						target: "Experience"
          },
					{
						pattern: "ExperienceDetails/{contextPath}",
						name: "ExperienceDetails",
						target: "ExperienceDetails"
          },
          {
						pattern: "PersonalData",
						name: "PersonalData",
						target: "PersonalData"
          },
					{
						pattern: "PersDataDetails/{contextPath}",
						name: "PersDataDetails",
						target: "PersDataDetails"
          },
          {
						pattern: "IdentificationData",
						name: "IdentificationData",
						target: "IdentificationData"
          },
					{
						pattern: "IdentDataDetails/{contextPath}",
						name: "IdentDataDetails",
						target: "IdentDataDetails"
          },
          {
						pattern: "FamilyData",
						name: "FamilyData",
						target: "FamilyData"
          },
					{
						pattern: "FamDataDetails/{contextPath}",
						name: "FamDataDetails",
						target: "FamDataDetails"
          },

					{
						pattern: "notFound",
						name: "notFound",
						target: "notFound"
          }
        ],
				targets: {

					welcome: {
						viewName: "Welcome",
						viewId: "Welcome",
						controlAggregation: "detailPages"
					},
					home: {
						viewName: "Home",
						viewId: "Home",
						controlAggregation: "masterPages"
					},
					Address: {
						viewName: "Address",
						viewId: "Address",
						controlAggregation: "masterPages"
					},
					AddressDetails: {
						viewName: "AddressDetails",
						viewId: "AddressDetails",
						controlAggregation: "detailPages"
					},
					Educational: {
						viewName: "Educational",
						viewId: "Educational",
						controlAggregation: "masterPages"
					},
					EducationalDetails: {
						viewName: "EducationalDetails",
						viewId: "EducationalDetails",
						controlAggregation: "detailPages"
					},
					Experience: {
						viewName: "Experience",
						viewId: "Experience",
						controlAggregation: "masterPages"
					},
					ExperienceDetails: {
						viewName: "ExperienceDetails",
						viewId:"ExperienceDetails",
						controlAggregation: "detailPages"
					},
					PersonalData: {
						viewName: "PersonalData",
						viewId: "PersonalData",
						controlAggregation: "masterPages"
					},
					PersDataDetails: {
						viewName: "PersDataDetails",
						viewId:"PersDataDetails",
						controlAggregation: "detailPages"
					},
					IdentificationData: {
						viewName: "IdentificationData",
						viewId: "IdentificationData",
						controlAggregation: "masterPages"
					},
					IdentDataDetails: {
						viewName: "IdentDataDetails",
						viewId:"IdentDataDetails",
						controlAggregation: "detailPages"
					},
						FamilyData: {
						viewName: "FamilyData",
						viewId: "FamilyData",
						controlAggregation: "masterPages"
					},
					FamDataDetails: {
						viewName: "FamDataDetails",
						viewId:"FamDataDetails",
						controlAggregation: "detailPages"
					},
					notFound: {
						viewName: "NotFound",
						viewId: "notFound",
						controlAggregation: "detailPages"
					}
				}
			}
		},

		init: function() {
			// call overwritten init (calls createContent)
			UIComponent.prototype.init.apply(this, arguments);

			// set i18n model
			var oI18nModel = new ResourceModel({
				bundleName: "hcm.people.profile.Z_PEP_APPROVAL.i18n.appTexts"
			});
			this.setModel(oI18nModel, "i18n");

			var modelJson = new sap.ui.model.json.JSONModel();
			var addressJson = new sap.ui.model.json.JSONModel();
			var addressSet = "AddressesSet";
			var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

			var model = {
				results: [
					{
						"Name": "Address",
						"Key":"Address",
						"count": ""
					},
					{
						"Name": "Education",
						"Key": "Educational",
						"count": ""
					},
					/*{
						"Name": "Experience",
							"Key": "Experience",
						"count": ""
					},*/
					{
						"Name": "Personal Data",
							"Key": "PersonalData",
						"count": ""
					},
					{
					    "Name": "Personal IDs",
					    "Key": "IdentificationData",
					    "count":""
					},
					{
					    "Name":"Family Details",
					    "Key":"FamilyData",
					    "Count":""
					}
                        ]
			};
			modelJson.setData(model);
			this.setModel(modelJson, "appModel");

			oDataModel.read(addressSet, null, null, false, function(r) {

				addressJson.setData(r);
			});
			this.setModel(addressJson, "addressModel");
         
			modelJson.oData.results[0].count = addressJson.oData.results.length;

			var eduJson = new sap.ui.model.json.JSONModel();
			var eduSet = "EducationSet";

			oDataModel.read(eduSet, null, null, false, function(r) {

				eduJson.setData(r);
			});
			this.setModel(eduJson, "eduModel");
            
			modelJson.oData.results[1].count = eduJson.oData.results.length;

		/*	var empJson = new sap.ui.model.json.JSONModel();
			var empSet = "OtherEmployersSet";

			oDataModel.read(empSet, null, null, false, function(r) {

				empJson.setData(r);
			});
			this.setModel(empJson, "empModel");

			modelJson.oData.results[2].count = empJson.oData.results.length;*/

			var persDataJson = new sap.ui.model.json.JSONModel();
			var persDataSet = "PersDataSet";

			oDataModel.read(persDataSet, null, null, false, function(r) {

				persDataJson.setData(r);
			});
			this.setModel(persDataJson, "persDataModel");
            console.log(persDataJson)
			modelJson.oData.results[2].count = persDataJson.oData.results.length;
			
			var idenfDataJson = new sap.ui.model.json.JSONModel();
			var idenfDataSet = "IdentificationSet";

			oDataModel.read(idenfDataSet, null, null, false, function(r) {

				idenfDataJson.setData(r);
			});
			this.setModel(idenfDataJson, "identifDataModel");
            console.log(idenfDataJson)
			modelJson.oData.results[3].count = idenfDataJson.oData.results.length;


			var famDataJson = new sap.ui.model.json.JSONModel();
			var famDataSet = "FamilySet";

			oDataModel.read(famDataSet, null, null, false, function(r) {

				famDataJson.setData(r);
			});
			this.setModel(famDataJson, "famDataModel");
            console.log(famDataJson)
			modelJson.oData.results[4].count = famDataJson.oData.results.length;

			// set device model
			var oDeviceModel = new JSONModel({
				isTouch: sap.ui.Device.support.touch,
				isNoTouch: !sap.ui.Device.support.touch,
				isPhone: sap.ui.Device.system.phone,
				isNoPhone: !sap.ui.Device.system.phone,
				listMode: (sap.ui.Device.system.phone) ? "None" : "SingleSelectMaster",
				listItemType: (sap.ui.Device.system.phone) ? "Active" : "Inactive"
			});
			oDeviceModel.setDefaultBindingMode("OneWay");
			this.setModel(oDeviceModel, "device");

			this._router = this.getRouter();

			//navigate to initial page for !phone
			if (!sap.ui.Device.system.phone) {
				this._router.getTargets().display("welcome");
			}

			// initialize the router
			this._router.initialize();

		},

		myNavBack: function() {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				this._router.navTo("home", {}, true);
			}
		},

		createContent: function() {
			// create root view
			return sap.ui.view({
				viewName: "hcm.people.profile.Z_PEP_APPROVAL.view.App",
				type: "XML"
			});
		}
	});

});