jQuery.sap.require("sap.ca.ui.dialog.factory");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper");

var employeeNum,Infotype,Subtype,ObjectID,FirstName,LastName,CreationTime,CreationDate,ApproverName,Dateofbirth;
   var length ;
    var groupName ;
sap.ui.controller("hcm.people.profile.Z_PEP_APPROVAL.controller.FamDataDetails", {



/**

* Called when a controller is instantiated and its View controls (if available) are already created.

* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

* @memberOf z_pep_approval.Address

*/

  onInit: function() {

    this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

    this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 

  },





  _handleRouteMatched: function(oEvent)

  {

    var oParamaeters = oEvent.getParameter("name");

    if(oParamaeters!== "FamDataDetails")

    {

    return;

    }
   var path =  oEvent.getParameter("arguments").contextPath;
    this.getView().bindElement("famDataModel>/results/"+path);
    
    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", false, "", "");
    var servicepath = this.getView().getElementBinding('famDataModel').sPath;
    employeeNum = this.getView().getModel("famDataModel").getProperty(servicepath).Employeenumber;
    SubType = this.getView().getModel("famDataModel").getProperty(servicepath).Subtype;
    CreationDate = this.getView().getModel("famDataModel").getProperty(servicepath).CreationDate;
    Dateofbirth = this.getView().getModel("famDataModel").getProperty(servicepath).Dateofbirth;
   
    if(SubType === "11")
    {
        groupName = "Father";
    }
    else if(SubType === "12"){
        groupName ="Mother";
    }
    else if(SubType === "1"){
        groupName = "Spouse";
    }
    else {
        groupName ="Child";
    }
    
     var formattedStartDate = new Date(Dateofbirth);

	formattedStartDate = this.ui5ToOdatadataForLocalFiltering(Dateofbirth, 'date');
	
	this.getView().byId("FD_DOB_DESCR").setText(formattedStartDate);
   
    this.getView().byId("idTxtRel").setText(groupName);
    var personalJson = new sap.ui.model.json.JSONModel();
    var persSet = "EmployeeDataSet('"+employeeNum+"')";///$value

    oDataModel.read(persSet, null, null, true, function(r) {



      personalJson.setData(r);

    });

    this.getView().setModel(personalJson,"persModel");
  
  
    var persOldJson = new sap.ui.model.json.JSONModel();
    var persOldSet = "EmployeeDataSet('"+employeeNum+"')/PersonalInfoSet";
     oDataModel.read(persOldSet, null, null, false, function(r) {
      persOldJson.setData(r);
    });

    this.getView().setModel(persOldJson,"persDataOldModel");
    
    var persOldModel = this.getView().getModel("persDataOldModel").getData().results;
 
						var jsonObjTemp = {};
						jsonObjTemp.item = new Array();
    for(var i=0; i< persOldModel.length ; i++){
        if(persOldModel[i].SubGroupname === groupName){
            			jsonObjTemp.item.push({
								"title": persOldModel[i].Fieldlabel,
								"value": persOldModel[i].Fieldvalue

								});

        }
    }
    sap.ui.getCore().setModel(jsonObjTemp, "persDataOldModel");
    console.log(jsonObjTemp);
    var model = sap.ui.getCore().getModel("persDataOldModel");
 
    if(groupName === "Child")
    {
        length = model.item.length/3;
        
    }
    else
  {
      length ="";
  }
      //setting image 
    var iconUrl = oDataModel.sServiceUrl+ "/EmployeeDataSet('" + employeeNum+ "')/$value";
    
    this.byId("objHeader").setIcon(iconUrl);
         /*   if(model.item.length>1){
			for (var i = 0; i < model.item.length; i++) {
				if (model.item[i].title === "First name") {
					 this.getView().byId("FD_FN_DESCR1").setText(model.item[i].value);
				}else 
				if (model.item[i].title === "Last name") {
					 this.getView().byId("FD_LN_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "Date of Birth") {
				 this.getView().byId("FD_DOB_DESCR1").setText(model.item[i].value);
				} 
			}
            }
            else
            {
               			 this.getView().byId("FD_FN_DESCR1").setText("No Data");
					 this.getView().byId("FD_LN_DESCR1").setText("No Data");
				 this.getView().byId("FD_DOB_DESCR1").setText("No Data");
				
				 
            }

*/
  },

  submitData :function(){

     

  },

  onApprove : function()

  {
    var servicepath = this.getView().getElementBinding('famDataModel').sPath;
    employeeNum = this.getView().getModel("famDataModel").getProperty(servicepath).Employeenumber;

      Subtype = this.getView().getModel("famDataModel").getProperty(servicepath).Subtype;
         if(groupName=== "Child") {
             ObjectID = ""+length;        
         }
     else
     {
         ObjectID = this.getView().getModel("famDataModel").getProperty(servicepath).ObjectID;
     }

      LastName = this.getView().getModel("famDataModel").getProperty(servicepath).LastName;

      FirstName = this.getView().getModel("famDataModel").getProperty(servicepath).FirstName;
    
       
        Dateofbirth = this.getView().getModel("famDataModel").getProperty(servicepath).Dateofbirth;
        
      CreationTime = this.getView().getModel("famDataModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("famDataModel").getProperty(servicepath).CreationDate;

     ApproverName = this.getView().getModel("famDataModel").getProperty(servicepath).ApproverName;

      

    this.validationMessage = "sucess";

    

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

        

           var workflowStatus ="A";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var persObj = {

              Employeenumber :employeeNum,
              Subtype: Subtype,

              ObjectID: ObjectID,

                FirstName :FirstName,

                LastName:LastName,
              
                Dateofbirth:Dateofbirth,

              CreationTime:CreationTime,

              CreationDate:CreationDate,

               WorkflowStatus: workflowStatus,

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

           var createPath ="FamilySet";

          oDataModel.create(createPath,persObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Approved Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var persDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "FamilySet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				persDataJson.setData(r);

			});

			this.getOwnerComponent().setModel(persDataJson,"famDataModel");

			var resultsLength = this.getView().getModel("famDataModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("FamDataDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---FamilyData--famMasterPage").setTitle("Family Details Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---FamilyData--idList").getItems();

               sap.ui.getCore().byId("__component0---FamilyData--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "famDataModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("famDataModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Confirm to Approve",

      showNote: false,

      title: "Confirm",

      confirmButtonLabel: "Confirm"

    }, C)



  },

  onReject : function(){



    var servicepath = this.getView().getElementBinding('famDataModel').sPath;

    

    employeeNum = this.getView().getModel("famDataModel").getProperty(servicepath).Employeenumber;

      Subtype = this.getView().getModel("famDataModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("famDataModel").getProperty(servicepath).ObjectID;

      LastName = this.getView().getModel("famDataModel").getProperty(servicepath).LastName;

      FirstName = this.getView().getModel("famDataModel").getProperty(servicepath).FirstName;
        Dateofbirth = this.getView().getModel("famDataModel").getProperty(servicepath).Dateofbirth;

      CreationTime = this.getView().getModel("famDataModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("famDataModel").getProperty(servicepath).CreationDate;

     ApproverName = this.getView().getModel("famDataModel").getProperty(servicepath).ApproverName;

      

    this.validationMessage = "Rejected";

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

                   var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

          

           var workflowStatus ="R";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var persObj = {

              Employeenumber :employeeNum,
              Subtype: Subtype,

              ObjectID: ObjectID,

                FirstName :FirstName,

                LastName:LastName,
                Dateofbirth:Dateofbirth,

              CreationTime:CreationTime,

              CreationDate:CreationDate,

               WorkflowStatus: 'R',

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

           var createPath ="FamilySet";

          oDataModel.create(createPath,persObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Rejected Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var persDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "FamilySet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				persDataJson.setData(r);

			});

			this.getOwnerComponent().setModel(persDataJson,"famDataModel");

				var resultsLength = this.getView().getModel("famDataModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("FamDataDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---FamilyData--famMasterPage").setTitle("Family Details Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---FamilyData--idList").getItems();

               sap.ui.getCore().byId("__component0---FamilyData--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "famDataModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("famDataModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    

    sap.ca.ui.dialog.confirmation.open({

      question: "Please provide comments for rejection",

      showNote: true,
      noteMandatory :true,

      title: "Rejected",

      confirmButtonLabel: "Reject"

    }, C)

},

dateFormatter: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = day+ '.'+month+ '.' +iDatadt.getFullYear();



			return iDatadt;



		}



	},

  	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = day+"."+month+"."+iDatadt.getFullYear();


			return iDatadt;



		}



	}



/**

* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

* (NOT before the first rendering! onInit() is used for that one!).

* @memberOf z_pep_approval.Address

*/

//  onBeforeRendering: function() {

//

//  },



/**

* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

* This hook is the same one that SAPUI5 controls get after being rendered.

* @memberOf z_pep_approval.Address

*/

//  onAfterRendering: function() {

//

//  },



/**

* Called when the Controller is destroyed. Use this one to free resources and finalize activities.

* @memberOf z_pep_approval.Address

*/

//  onExit: function() {

//

//  }



});