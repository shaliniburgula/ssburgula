jQuery.sap.require("sap.ca.ui.dialog.factory");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper");

var employeeNum,Infotype,Subtype,ObjectID,StreetHouseNo,StateTxt,City,ApproverName,District,PostalCode,Country,AddressSecondLine,CreationTime,CreationDate;

var base64,fileContentType,fileLength,fileName ,stringUpload,   evFlag ,CreationTimeA,CreationDateA;

var SubtypeTitle ;

sap.ui.controller("hcm.people.profile.Z_PEP_APPROVAL.controller.AddressDetails", {



/**

* Called when a controller is instantiated and its View controls (if available) are already created.

* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

* @memberOf z_pep_approval.Address

*/

  onInit: function() {

    this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

    this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 

 

  },

    handleUpdateFinished: function(c) {

		if (!jQuery.device.is.phone && (c.getParameters().reason === "Filter" || c.getParameters().reason === "Change" || c.getParameters().reason ===

			"Refresh" || c.getParameters().reason === "Binding")) {

			if (this.oRouter._oRouter._prevMatchedRequest === "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {

				this.oList.removeSelections()

			} else if (this.oList.getSelectedItem()) {

				var b = this.oList.getSelectedItem().getBindingContext();

				this.handleSelectionChange(c, b)

			}

			if (this.getList().getItems().length == "0") {

				this._showLoadingText(false)

			} else {

				this._showLoadingText(true)

			}

		}

	},

    handleSelectionChange: function(c, b) {

		if (!jQuery.device.is.phone) {

			if (!b) {

				b = c.getParameter("listItem").getBindingContext()

			}

			

			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();

			sap.ui.getCore().getEventBus().publish(a, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, {

				context: b

			})

		}

	},

  _handleRouteMatched: function(oEvent)

  {

    var oParamaeters = oEvent.getParameter("name");

    if(oParamaeters!="AddressDetails")

    {

    return;

    }



   var path =  oEvent.getParameter("arguments").contextPath;



    //console.log(path);

    this.getView().bindElement("addressModel>/results/"+path);

   

    var attchJson = new sap.ui.model.json.JSONModel();

    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");



    var servicepath = this.getView().getElementBinding('addressModel').sPath;



    employeeNum = this.getView().getModel("addressModel").getProperty(servicepath).Employeenumber;

    CreationDate = this.getView().getModel("addressModel").getProperty(servicepath).CreationDate;

   SubtypeTitle = this.getView().getModel("addressModel").getProperty(servicepath).Subtype;
   var addName ;
    if (SubtypeTitle === "1")
     {
         addName = "Permanent Address";
         this.getView().byId("form1").setTitle("Permanent Address");
     }
     else
     {
         addName = "Local/Temporary Address";
         this.getView().byId("form1").setTitle("Local/Temporary Residence");
     }

     var formattedStartDate = new Date(CreationDate);

	formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');

    

    var attchSet = "AttachmentCreateSet?$filter=Employeenumber eq '"+employeeNum+"' and Infotype eq '0006' and CreationDate eq datetime'"+formattedStartDate+"'";///$value

    oDataModel.read(attchSet, null, null, false, function(r) {



      attchJson.setData(r);

    });

    this.getView().setModel(attchJson,"attchModel");

    console.log(attchJson);
    
    var size = this.getView().getModel("attchModel").getData().results.length;
    if(size ===0){
        this.getView().byId("application-ZPEPPROFAPPR-approve-component---AddressDetails--ATT_ICON_TAB").setVisible(false);
        
    }
    else
    {
        this.getView().byId("application-ZPEPPROFAPPR-approve-component---AddressDetails--ATT_ICON_TAB").setVisible(true);
    }
    

    var personalJson = new sap.ui.model.json.JSONModel();
    var persSet = "EmployeeDataSet('"+employeeNum+"')";///$value

    oDataModel.read(persSet, null, null, false, function(r) {
      personalJson.setData(r);
    });

    this.getView().setModel(personalJson,"persModel");
    console.log(personalJson)
    
    //setting image 
    var iconUrl = oDataModel.sServiceUrl+ "/EmployeeDataSet('" + employeeNum+ "')/$value";
    
    this.byId("objHeader").setIcon(iconUrl);
    var addJson = new sap.ui.model.json.JSONModel();
    var addSet = "EmployeeDataSet('"+employeeNum+"')/PersonalInfoSet";
     oDataModel.read(addSet, null, null, false, function(r) {
      addJson.setData(r);
    });

    this.getView().setModel(addJson,"addModel");
    
    var addressModel = this.getView().getModel("addModel").getData().results;
    
    console.log(addressModel);
    
						var jsonObjTemp = {};
						jsonObjTemp.item = new Array();
    for(var i=0; i< addressModel.length ; i++){
        if(addressModel[i].SubGroupname === addName){
            			jsonObjTemp.item.push({
								"title": addressModel[i].Fieldlabel,
								"value": addressModel[i].Fieldvalue

								});

        }
    }
    sap.ui.getCore().setModel(jsonObjTemp, "oldAddModel");
    
    console.log(jsonObjTemp);
    
    var model = sap.ui.getCore().getModel("oldAddModel");
            if(model.item.length>1){
			for (var i = 0; i < model.item.length; i++) {
				if (model.item[i].title === "Contact Name") {
					 this.getView().byId("PP_CN_DESCR1").setText(model.item[i].value);
				}else 
				if (model.item[i].title === "House No/Street") {
					 this.getView().byId("PP_HNo_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "2nd Address Line") {
				 this.getView().byId("PP_2nd_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "City") {
					 this.getView().byId("PP_City1").setText(model.item[i].value);
				} else if (model.item[i].title === "District") {
				 this.getView().byId("PP_Dis1").setText(model.item[i].value);
				} else if (model.item[i].title === "Region") {
				 this.getView().byId("PP_State1").setText(model.item[i].value);
				} else if (model.item[i].title === "Postal Code") {
				 this.getView().byId("PP_PinCode1").setText(model.item[i].value);
				} else if (model.item[i].title === "Country Name") {
				 this.getView().byId("PP_Country1").setText(model.item[i].value);
				} else if (model.item[i].title === "Telephone Number") {
				 this.getView().byId("PP_TEL_DESCR1").setText(model.item[i].value);
				}

			}
            }
            else
            {
               			 this.getView().byId("PP_CN_DESCR1").setText("No Data");
					 this.getView().byId("PP_HNo_DESCR1").setText("No Data");
				 this.getView().byId("PP_2nd_DESCR1").setText("No Data");
					 this.getView().byId("PP_City1").setText("No Data");
				 this.getView().byId("PP_Dis1").setText("No Data");
				 this.getView().byId("PP_State1").setText("No Data");
				 this.getView().byId("PP_PinCode1").setText("No Data");
				 this.getView().byId("PP_Country1").setText("No Data");
				 this.getView().byId("PP_TEL_DESCR1").setText("No Data");
            }

  },

  submitData :function(){

     

  },

  onApprove : function()

  {



    var servicepath = this.getView().getElementBinding('addressModel').sPath;



    employeeNum = this.getView().getModel("addressModel").getProperty(servicepath).Employeenumber;

     Infotype = this.getView().getModel("addressModel").getProperty(servicepath).Infotype;

      Subtype = this.getView().getModel("addressModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("addressModel").getProperty(servicepath).ObjectID;

      StreetHouseNo = this.getView().getModel("addressModel").getProperty(servicepath).StreetHouseNo;

      City = this.getView().getModel("addressModel").getProperty(servicepath).City;

      District = this.getView().getModel("addressModel").getProperty(servicepath).District;

      PostalCode = this.getView().getModel("addressModel").getProperty(servicepath).PostalCode;

      Country = this.getView().getModel("addressModel").getProperty(servicepath).Country;

      AddressSecondLine = this.getView().getModel("addressModel").getProperty(servicepath).AddressSecondLine;

      StateTxt = this.getView().getModel("addressModel").getProperty(servicepath).StateTxt;

      CreationTime = this.getView().getModel("addressModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("addressModel").getProperty(servicepath).CreationDate;

      ApproverName = this.getView().getModel("addressModel").getProperty(servicepath).ApproverName;

      //ApproverComments = this.getView().getModel("addressModel").getProperty(servicepath).ApproverComment

        var attchPath = "/results/0"
    if(this.getView().getModel("attchModel").getData().length>0){
       base64 = this.getView().getModel("attchModel").getProperty(attchPath).FileContent;

        fileContentType = this.getView().getModel("attchModel").getProperty(attchPath).FileContentType; 

        fileLength = this.getView().getModel("attchModel").getProperty(attchPath).FileLength;

        fileName =  this.getView().getModel("attchModel").getProperty(attchPath).FileName;

        stringUpload = this.getView().getModel("attchModel").getProperty(attchPath).StringUpload;

        evFlag = this.getView().getModel("attchModel").getProperty(attchPath).EvFlag;

        CreationTimeA = this.getView().getModel("attchModel").getProperty(attchPath).CreationTime;

      CreationDateA = this.getView().getModel("attchModel").getProperty(attchPath).CreationDate;
}
        

    this.validationMessage = "sucess";

    

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

          var  createPath = "AddressesSet";

           var workflowStatus ="A";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var addressObj = {

              Employeenumber :employeeNum,

              Infotype: Infotype,

              Subtype: Subtype,

              ObjectID: ObjectID,

              StreetHouseNo:StreetHouseNo,

              City:City,

              District:District,

              PostalCode:PostalCode,

              Country:Country,

              AddressSecondLine:AddressSecondLine,

               StateTxt:StateTxt,

              CreationTime:CreationTime,

              CreationDate:CreationDate,

               WorkflowStatus: workflowStatus,

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

          oDataModel.create(createPath,addressObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });
if(that.getView().getModel("attchModel").getData().length>0){
    var attchUpdateSet = "AttachmentCreateSet";///$value

    	var fileDataObj = {

								

								Employeenumber : employeeNum,

								Infotype : "0006",

								Subtype: "2",

								FileContent:base64,

								FileContentType:fileContentType,

								FileLength:fileLength,

								FileName:fileName,

								StringUpload:stringUpload,

								EvFlag:evFlag,

								WorkflowStatus : 'A',

								 CreationTime:CreationTimeA,

                                CreationDate:CreationDateA

						};

	oDataModel.create(attchUpdateSet,fileDataObj, null, function(responseBody, sucRes) {

		result = true;

	}, function(failRes) {

		result = false;

		errorBody = JSON.parse(failRes.response.body);

			

	});

}

	if(result=== true){

	     sap.m.MessageBox.show("Data Approved Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var addressJson = new sap.ui.model.json.JSONModel();

			var addressSet = "AddressesSet";

	         oDataModel.read(addressSet, null, null, false, function(r) {



				addressJson.setData(r);

			});

			this.getOwnerComponent().setModel(addressJson,"addressModel")

			

			  var resultsLength = this.getView().getModel("addressModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("AddressDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

              

                

             sap.ui.getCore().byId("__component0---Address--addMasterPage").setTitle("Address Data("+resultsLength +")");

            var items = sap.ui.getCore().byId("__component0---Address--idList").getItems();

               sap.ui.getCore().byId("__component0---Address--idList").setSelectedItem(items[0]);



          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Confirm to Approve",

      showNote: false,

      title: "Confirm",

      confirmButtonLabel: "Confirm"

    }, C)



  },

  onReject : function(){



    var servicepath = this.getView().getElementBinding('addressModel').sPath;

    employeeNum = this.getView().getModel("addressModel").getProperty(servicepath).Employeenumber;

     Infotype = this.getView().getModel("addressModel").getProperty(servicepath).Infotype;

      Subtype = this.getView().getModel("addressModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("addressModel").getProperty(servicepath).ObjectID;

      StreetHouseNo = this.getView().getModel("addressModel").getProperty(servicepath).StreetHouseNo;

      City = this.getView().getModel("addressModel").getProperty(servicepath).City;

      District = this.getView().getModel("addressModel").getProperty(servicepath).District;

      PostalCode = this.getView().getModel("addressModel").getProperty(servicepath).PostalCode;

      Country = this.getView().getModel("addressModel").getProperty(servicepath).Country;

      AddressSecondLine = this.getView().getModel("addressModel").getProperty(servicepath).AddressSecondLine;

      StateTxt = this.getView().getModel("addressModel").getProperty(servicepath).StateTxt;

      CreationTime = this.getView().getModel("addressModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("addressModel").getProperty(servicepath).CreationDate;

      ApproverName = this.getView().getModel("addressModel").getProperty(servicepath).ApproverName;

    //  ApproverComments = this.getView().getModel("addressModel").getProperty(servicepath).ApproverComments;

    

       var attchPath = "/results/0"
      if(this.getView().getModel("attchModel").getData().length>0){
       base64 = this.getView().getModel("attchModel").getProperty(attchPath).FileContent;

        fileContentType = this.getView().getModel("attchModel").getProperty(attchPath).FileContentType; 

        fileLength = this.getView().getModel("attchModel").getProperty(attchPath).FileLength;

        fileName =  this.getView().getModel("attchModel").getProperty(attchPath).FileName;

        stringUpload = this.getView().getModel("attchModel").getProperty(attchPath).StringUpload;

        evFlag = this.getView().getModel("attchModel").getProperty(attchPath).EvFlag;

              CreationTimeA = this.getView().getModel("attchModel").getProperty(attchPath).CreationTime;

      CreationDateA = this.getView().getModel("attchModel").getProperty(attchPath).CreationDate;

        
}
    this.validationMessage = "Rejected";

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

         var  createPath = "AddressesSet";

           var workflowStatus ="R";

          	var result = false;

	        var errorBody;

    

          var addressObj = {

              Employeenumber :employeeNum,

              Infotype: Infotype,

              Subtype: Subtype,

              ObjectID: ObjectID,

              StreetHouseNo:StreetHouseNo,

              City:City,

              District:District,

              PostalCode:PostalCode,

              Country:Country,

              AddressSecondLine:AddressSecondLine,

               StateTxt:StateTxt,

              CreationTime:CreationTime,

              CreationDate:CreationDate,

               WorkflowStatus: workflowStatus,

               ApproverName :ApproverName,

               ApproverComments:r.sNote

               

           };

          

           var that = this;

          oDataModel.create(createPath,addressObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

     
  if(this.getView().getModel("attchModel").getData().length>0){
    var attchUpdateSet = "AttachmentCreateSet";///$value

    	var fileDataObj = {

								

								Employeenumber : employeeNum,

								Infotype : "0006",

								Subtype: "2",

								FileContent:base64,

								FileContentType:fileContentType,

								FileLength:fileLength,

								FileName:fileName,

								StringUpload:stringUpload,

								EvFlag:evFlag,

								WorkflowStatus : 'R',

								 CreationTime:CreationTimeA,

                                CreationDate:CreationDateA

						};

	oDataModel.create(attchUpdateSet,fileDataObj, null, function(responseBody, sucRes) {

		result = true;

	}, function(failRes) {

		result = false;

		errorBody = JSON.parse(failRes.response.body);

			

	});

  }

	if(result=== true){

	     sap.m.MessageBox.show("Data Rejected Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var addressJson = new sap.ui.model.json.JSONModel();

			var addressSet = "AddressesSet";

	         oDataModel.read(addressSet, null, null, false, function(r) {



				addressJson.setData(r);

			});

			this.getOwnerComponent().setModel(addressJson,"addressModel");

			  var resultsLength = this.getView().getModel("addressModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("AddressDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

              

                

                 sap.ui.getCore().byId("__component0---Address--addMasterPage").setTitle("Address Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---Address--idList").getItems();

               sap.ui.getCore().byId("__component0---Address--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "addressModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("addressModel");
            
			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Please provide comments for rejection",

      showNote: true,
      noteMandatory :true,

      title: "Rejected",

      confirmButtonLabel: "Reject"

    }, C)

},



  onAttachListItemSelect : function(e){

    var s = e.getSource();

    var servicepath = this.getView().getElementBinding('addressModel').sPath;

    var employeeNum = this.getView().getModel("addressModel").getProperty(servicepath).Employeenumber;

      var CreationDate = this.getView().getModel("addressModel").getProperty(servicepath).CreationDate;

    

     var formattedStartDate = new Date(CreationDate);

		formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');

//and CreationDate eq datetime'"+formattedStartDate+"'";

    var infoType = "0006";

    if (employeeNum && infoType) {

      var display = "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/AttachmentDisplaySet(Employeenumber='"+employeeNum+"',Infotype='"+infoType+"',CreationDate=datetime'"+formattedStartDate+"')/$value";

      //location.href = display;

      window.open(display,"_blank");

    }

  },

  	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = iDatadt.getFullYear() +

				'-' + month +

				'-' + day +

				'T' + "00" +

				':' + "00" +

				':' + "00";



			return iDatadt;



		}



	},



/**

* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

* (NOT before the first rendering! onInit() is used for that one!).

* @memberOf z_pep_approval.Address

*/

//  onBeforeRendering: function() {

//

//  },



/**

* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

* This hook is the same one that SAPUI5 controls get after being rendered.

* @memberOf z_pep_approval.Address

*/

 onAfterRendering: function() {

    


  },



/**

* Called when the Controller is destroyed. Use this one to free resources and finalize activities.

* @memberOf z_pep_approval.Address

*/

//  onExit: function() {

//

//  }



});