sap.ui.define([

  "sap/ui/core/mvc/Controller",

  "sap/ui/core/routing/History",

  "sap/ui/Device",

], function(Controller, History,Device) {

  "use strict";



  return Controller.extend("hcm.people.profile.Z_PEP_APPROVAL.controller.NotFound", {





      onNavBack: function() {

      var oHistory = History.getInstance();

      var sPreviousHash = oHistory.getPreviousHash();



      if (sPreviousHash !== undefined) {

        window.history.go(-1);

      } else {

        this.getOwnerComponent().getRouter().navTo("Address", {}, true);

      }

    }



  });



});