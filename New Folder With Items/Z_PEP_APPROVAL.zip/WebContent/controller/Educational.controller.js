sap.ui.controller("hcm.people.profile.Z_PEP_APPROVAL.controller.Educational", {



/**

* Called when a controller is instantiated and its View controls (if available) are already created.

* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

* @memberOf z_pep_approval.Address

*/

  onInit: function() {

     this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

     this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 

  },

 onBeforeRendering: function() {



    var numItems = this.getView().byId("idList").getBinding("items").getLength();

     this.getView().byId("idEduMaster").setTitle("Educational Data("+numItems +")");

     var items = this.getView().byId("idList").getItems();

     this.getView().byId("idList").setSelectedItem(items[0]);

     

     this.getView().byId("idList").fireSelect({"listItem": items[0]});

     //this._oRouter.navTo("Address");

     

  },

    onSearch : function(oEvent){

         var filters = [];

                var searchString = oEvent.getParameter("query");

                if(!searchString) {

                	searchString = oEvent.getParameter("newValue");

                }

                if (searchString && searchString.length > 0) {

                    filters = [new sap.ui.model.Filter("Employeenumber", 	sap.ui.model.FilterOperator.Contains,

                        searchString)];

                }

                // Update list binding

                this.byId("idList").getBinding("items").filter(filters);

    },

  _handleRouteMatched: function(oEvent)

  {

    var oParamaeters = oEvent.getParameter("name");

    if(oParamaeters !== "Educational")

    {

    return;

    }



    var resultsLength = this.getView().getModel("eduModel").getData().results.length;

  if(resultsLength >0){

     this._oRouter.navTo("EducationalDetails",{contextPath:0});   

  }

  else

  {

       this._oRouter.navTo("notFound");

  }



  },



  handleListItem : function(){

    var spath = this.getView().byId("idList").getSelectedItem().oBindingContexts.eduModel.sPath;

    var path = spath.split("/");

    var sId = path[2];

    this._oRouter.navTo("EducationalDetails",{contextPath:sId});



    //sap.ui.getCore().byId("idDetailView1--detailHeader").bindProperty("title",bindexpheader);

    //sap.ui.getCore().byId("idDetailView1--idobjattr").bindProperty("text",bindexpattr);

  },

  handleNavButtonPress: function () {

    //this.getOwnerComponent().myNavBack();

        	var modelJson = new sap.ui.model.json.JSONModel();

			var addressJson = new sap.ui.model.json.JSONModel();

			var addressSet = "AddressesSet";

			var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");



			var model = {
				results: [
					{
						"Name": "Address",
						"Key":"Address",
						"count": ""
					},
					{
						"Name": "Education",
						"Key": "Educational",
						"count": ""
					},
					/*{
						"Name": "Experience",
							"Key": "Experience",
						"count": ""
					},*/
					{
						"Name": "Personal Data",
							"Key": "PersonalData",
						"count": ""
					},
					{
					    "Name": "Personal IDs",
					    "Key": "IdentificationData",
					    "count":""
					},
					{
					    "Name":"Family Details",
					    "Key":"FamilyData",
					    "Count":""
					}
                        ]
			};

			modelJson.setData(model);



			oDataModel.read(addressSet, null, null, false, function(r) {



				addressJson.setData(r);

			});

			 this.getOwnerComponent().setModel(addressJson, "addressModel");

         

			modelJson.oData.results[0].count = addressJson.oData.results.length;



			var eduJson = new sap.ui.model.json.JSONModel();

			var eduSet = "EducationSet";



			oDataModel.read(eduSet, null, null, false, function(r) {



				eduJson.setData(r);

			});

			 this.getOwnerComponent().setModel(eduJson, "eduModel");

            

			modelJson.oData.results[1].count = eduJson.oData.results.length;


/*
			var empJson = new sap.ui.model.json.JSONModel();

			var empSet = "OtherEmployersSet";



			oDataModel.read(empSet, null, null, false, function(r) {



				empJson.setData(r);

			});

			 this.getOwnerComponent().setModel(empJson, "empModel");



			modelJson.oData.results[2].count = empJson.oData.results.length;

*/

			var persDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "PersDataSet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				persDataJson.setData(r);

			});

			 this.getOwnerComponent().setModel(persDataJson, "persDataModel");

     

			modelJson.oData.results[2].count = persDataJson.oData.results.length;

            
            	var idenfDataJson = new sap.ui.model.json.JSONModel();
			var idenfDataSet = "IdentificationSet";

			oDataModel.read(idenfDataSet, null, null, false, function(r) {

				idenfDataJson.setData(r);
			});
			 this.getOwnerComponent().setModel(idenfDataJson, "identifDataModel");
            console.log(idenfDataJson)
			modelJson.oData.results[3].count = idenfDataJson.oData.results.length;

            
            	var famDataJson = new sap.ui.model.json.JSONModel();
			var famDataSet = "FamilySet";

			oDataModel.read(famDataSet, null, null, false, function(r) {

				famDataJson.setData(r);
			});
			 this.getOwnerComponent().setModel(famDataJson, "famDataModel");
  
			modelJson.oData.results[4].count = famDataJson.oData.results.length;

		    this.getOwnerComponent().setModel(modelJson,"appModel");

    this._oRouter.navTo("home");

  },





/**

* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

* (NOT before the first rendering! onInit() is used for that one!).

* @memberOf z_pep_approval.Address

*/

//  onBeforeRendering: function() {

//

//  },



/**

* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

* This hook is the same one that SAPUI5 controls get after being rendered.

* @memberOf z_pep_approval.Address

*/

//  onAfterRendering: function() {

//

//  },



/**

* Called when the Controller is destroyed. Use this one to free resources and finalize activities.

* @memberOf z_pep_approval.Address

*/

//  onExit: function() {

//

//  }



});