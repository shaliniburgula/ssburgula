jQuery.sap.require("sap.ca.ui.dialog.factory");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper");

var employeeNum,Infotype,Subtype,ObjectID,FirstName,LastName,CreationTime,CreationDate,ApproverName,MaritalStatusKey,DateofMarriage;
var BirthPlace ,Country ,StateTxt ;
sap.ui.controller("hcm.people.profile.Z_PEP_APPROVAL.controller.PersDataDetails", {



/**

* Called when a controller is instantiated and its View controls (if available) are already created.

* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

* @memberOf z_pep_approval.Address

*/

  onInit: function() {

    this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

    this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 

  },





  _handleRouteMatched: function(oEvent)

  {

    var oParamaeters = oEvent.getParameter("name");

    if(oParamaeters!="PersDataDetails")

    {

    return;

    }
   var path =  oEvent.getParameter("arguments").contextPath;
    this.getView().bindElement("persDataModel>/results/"+path);
    var attchJson = new sap.ui.model.json.JSONModel();

    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", false, "", "");



    var servicepath = this.getView().getElementBinding('persDataModel').sPath;



    employeeNum = this.getView().getModel("persDataModel").getProperty(servicepath).Employeenumber;

    CreationDate = this.getView().getModel("persDataModel").getProperty(servicepath).CreationDate;

    var maritalStatusKey = this.getView().getModel("persDataModel").getProperty(servicepath).MaritalStatusKey;
    var maritalStatus;
    if(maritalStatusKey === "1"){
        maritalStatus = "Married";
    }
    else
    {
        maritalStatus ="Single";
    }
    
    this.getView().byId("PP_Marr_DESCR").setText(maritalStatus);
    
    var dateofMarriage = this.getView().getModel("persDataModel").getProperty(servicepath).DateofMarriage;
    
     
   var formattedDOM = this.dateFormatter(dateofMarriage, 'date');
   
    this.getView().byId("PP_DOM_DESCR").setText(formattedDOM);
    
    var firstName = this.getView().getModel("persDataModel").getProperty(servicepath).FirstName;
    
     this.getView().byId("PP_FN_DESCR").setText(firstName);
    
    var secondName = this.getView().getModel("persDataModel").getProperty(servicepath).LastName;
    this.getView().byId("PP_LN_DESCR").setText(secondName);
    
    
   
     var formattedStartDate = new Date(CreationDate);

	formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');

    

    var attchSet = "AttachmentCreateSet?$filter=Employeenumber eq '"+employeeNum+"' and Infotype eq '0002' and CreationDate eq datetime'"+formattedStartDate+"'";///$value

    oDataModel.read(attchSet, null, null, false, function(r) {



      attchJson.setData(r);

    });

    this.getView().setModel(attchJson,"attchPersModel");

    console.log(attchJson);
    
    

    var personalJson = new sap.ui.model.json.JSONModel();

    

    var persSet = "EmployeeDataSet('"+employeeNum+"')";///$value

    oDataModel.read(persSet, null, null, true, function(r) {



      personalJson.setData(r);

    });

    this.getView().setModel(personalJson,"persModel");
  
  
    var persOldJson = new sap.ui.model.json.JSONModel();
    var persOldSet = "EmployeeDataSet('"+employeeNum+"')/PersonalInfoSet";
     oDataModel.read(persOldSet, null, null, false, function(r) {
      persOldJson.setData(r);
    });

    this.getView().setModel(persOldJson,"persDataOldModel");
    
    var persOldModel = this.getView().getModel("persDataOldModel").getData().results;
 
						var jsonObjTemp = {};
						jsonObjTemp.item = new Array();
    for(var i=0; i< persOldModel.length ; i++){
        if(persOldModel[i].Groupname === "Personal Data" || persOldModel[i].Groupname === "Personal data" ){
            			jsonObjTemp.item.push({
								"title": persOldModel[i].Fieldlabel,
								"value": persOldModel[i].Fieldvalue

								});

        }
    }
    sap.ui.getCore().setModel(jsonObjTemp, "persDataOldModel");
    var model = sap.ui.getCore().getModel("persDataOldModel");
            if(model.item.length>1){
			for (var i = 0; i < model.item.length; i++) {
				if (model.item[i].title === "First name") {
					 this.getView().byId("PP_FN_DESCR1").setText(model.item[i].value);
				}else 
				if (model.item[i].title === "Last name") {
					 this.getView().byId("PP_LN_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "Marital Status") {
				 this.getView().byId("PP_Marr_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "Date of Marriage") {
					 this.getView().byId("PP_DOM_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "Country of Birth") {
					 this.getView().byId("PP_DP_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "State") {
					 this.getView().byId("PP_St_DESCR1").setText(model.item[i].value);
				} else if (model.item[i].title === "Birthplace") {
					 this.getView().byId("PP_DP_DESCR1").setText(model.item[i].value);
				} 
			}
            }
            else
            {
               			 this.getView().byId("PP_FN_DESCR1").setText("No Data");
					 this.getView().byId("PP_LN_DESCR1").setText("No Data");
				 this.getView().byId("PP_Marr_DESCR1").setText("No Data");
					 this.getView().byId("PP_DOM_DESCR1").setText("No Data");
				 
            }

        //setting image 
    var iconUrl = oDataModel.sServiceUrl+ "/EmployeeDataSet('" + employeeNum+ "')/$value";
    
    this.byId("objHeader").setIcon(iconUrl);
  },

  submitData :function(){

     

  },

  onApprove : function()

  {



    var servicepath = this.getView().getElementBinding('persDataModel').sPath;



    employeeNum = this.getView().getModel("persDataModel").getProperty(servicepath).Employeenumber;

     Infotype = this.getView().getModel("persDataModel").getProperty(servicepath).Infotype;

      Subtype = this.getView().getModel("persDataModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("persDataModel").getProperty(servicepath).ObjectID;

      LastName = this.getView().getModel("persDataModel").getProperty(servicepath).LastName;

      FirstName = this.getView().getModel("persDataModel").getProperty(servicepath).FirstName;
    
        MaritalStatusKey = this.getView().getModel("persDataModel").getProperty(servicepath).MaritalStatusKey;
        
        DateofMarriage = this.getView().getModel("persDataModel").getProperty(servicepath).DateofMarriage;
        
        BirthPlace = this.getView().getModel("persDataModel").getProperty(servicepath).BirthPlace;
         Country = this.getView().getModel("persDataModel").getProperty(servicepath).Country;
          StateTxt = this.getView().getModel("persDataModel").getProperty(servicepath).StateTxt;
        
      CreationTime = this.getView().getModel("persDataModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("persDataModel").getProperty(servicepath).CreationDate;

     ApproverName = this.getView().getModel("persDataModel").getProperty(servicepath).ApproverName;

      

    this.validationMessage = "sucess";

    

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

        

           var workflowStatus ="A";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var persObj = {

              Employeenumber :employeeNum,

              Infotype: Infotype,

              Subtype: Subtype,

              ObjectID: ObjectID,

                FirstName :FirstName,

                LastName:LastName,
                MaritalStatusKey:MaritalStatusKey,
                DateofMarriage:DateofMarriage,
                
                BirthPlace :BirthPlace ,
                Country :Country ,
                StateTxt :StateTxt ,

              CreationTime:CreationTime,

              CreationDate:CreationDate,

               WorkflowStatus: workflowStatus,

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

           var createPath ="PersDataSet('" + employeeNum + "')";

          oDataModel.update(createPath,persObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Approved Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var persDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "PersDataSet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				persDataJson.setData(r);

			});

			this.getOwnerComponent().setModel(persDataJson,"persDataModel");

			var resultsLength = this.getView().getModel("persDataModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("PersDataDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---PersonalData--persMasterPage").setTitle("Personal Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---PersonalData--idList").getItems();

               sap.ui.getCore().byId("__component0---PersonalData--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "persDataModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("persDataModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Confirm to Approve",

      showNote: false,

      title: "Confirm",

      confirmButtonLabel: "Confirm"

    }, C)



  },

  onReject : function(){



    var servicepath = this.getView().getElementBinding('persDataModel').sPath;

    

    employeeNum = this.getView().getModel("persDataModel").getProperty(servicepath).Employeenumber;

     Infotype = this.getView().getModel("persDataModel").getProperty(servicepath).Infotype;

      Subtype = this.getView().getModel("persDataModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("persDataModel").getProperty(servicepath).ObjectID;

      LastName = this.getView().getModel("persDataModel").getProperty(servicepath).LastName;

      FirstName = this.getView().getModel("persDataModel").getProperty(servicepath).FirstName;
        MaritalStatusKey = this.getView().getModel("persDataModel").getProperty(servicepath).MaritalStatusKey;
        
        DateofMarriage = this.getView().getModel("persDataModel").getProperty(servicepath).DateofMarriage;
         BirthPlace = this.getView().getModel("persDataModel").getProperty(servicepath).BirthPlace;
         Country = this.getView().getModel("persDataModel").getProperty(servicepath).Country;
          StateTxt = this.getView().getModel("persDataModel").getProperty(servicepath).StateTxt;
      CreationTime = this.getView().getModel("persDataModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("persDataModel").getProperty(servicepath).CreationDate;

     ApproverName = this.getView().getModel("persDataModel").getProperty(servicepath).ApproverName;

      

    this.validationMessage = "Rejected";

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

                   var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

          

           var workflowStatus ="R";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var persObj = {

              Employeenumber :employeeNum,

              Infotype: Infotype,

              Subtype: Subtype,

              ObjectID: ObjectID,

                FirstName :FirstName,

                LastName:LastName,
                
                MaritalStatusKey:MaritalStatusKey,
                DateofMarriage:DateofMarriage,
                  BirthPlace :BirthPlace ,
                Country :Country ,
                StateTxt :StateTxt ,
              CreationTime:CreationTime,

              CreationDate:CreationDate,

               WorkflowStatus: 'R',

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

           var createPath ="PersDataSet('" + employeeNum + "')";

          oDataModel.update(createPath,persObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Rejected Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var persDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "PersDataSet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				persDataJson.setData(r);

			});

			this.getOwnerComponent().setModel(persDataJson,"persDataModel");

				var resultsLength = this.getView().getModel("persDataModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("PersDataDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---PersonalData--persMasterPage").setTitle("Personal Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---PersonalData--idList").getItems();

               sap.ui.getCore().byId("__component0---PersonalData--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "persDataModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("persDataModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    

    sap.ca.ui.dialog.confirmation.open({

      question: "Please provide comments for rejection",

      showNote: true,
      
      noteMandatory :true,

      title: "Rejected",

      confirmButtonLabel: "Reject"

    }, C)

},

dateFormatter: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = day+ '.'+month+ '.' +iDatadt.getFullYear();



			return iDatadt;



		}



	},

  	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = iDatadt.getFullYear() +

				'-' + month +

				'-' + day +

				'T' + "00" +

				':' + "00" +

				':' + "00";



			return iDatadt;



		}



	}



/**

* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

* (NOT before the first rendering! onInit() is used for that one!).

* @memberOf z_pep_approval.Address

*/

//  onBeforeRendering: function() {

//

//  },



/**

* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

* This hook is the same one that SAPUI5 controls get after being rendered.

* @memberOf z_pep_approval.Address

*/

//  onAfterRendering: function() {

//

//  },



/**

* Called when the Controller is destroyed. Use this one to free resources and finalize activities.

* @memberOf z_pep_approval.Address

*/

//  onExit: function() {

//

//  }



});