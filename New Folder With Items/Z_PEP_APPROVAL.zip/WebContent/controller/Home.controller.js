sap.ui.define([

  'sap/ui/core/mvc/Controller',

  'hcm/people/profile/Z_PEP_APPROVAL/model/formatter',

  'sap/ui/model/Filter',

  'sap/ui/model/FilterOperator'

], function (Controller,

       formatter,

       Filter,

       FilterOperator) {

  "use strict";



  return Controller.extend("hcm.people.profile.Z_PEP_APPROVAL.controller.Home", {

    formatter : formatter,



    onInit: function () {

      var oComponent = this.getOwnerComponent();

      this._router = oComponent.getRouter();

      // trigger first search to set visibilities right

      //this._search();



    },



    handleSearch: function (oEvent) {

         var filters = [];

                var searchString = oEvent.getParameter("query");

                if(!searchString) {

                	searchString = oEvent.getParameter("newValue");

                }

                if (searchString && searchString.length > 0) {

                    filters = [new sap.ui.model.Filter("Name", 	sap.ui.model.FilterOperator.Contains,

                        searchString)];

                }

                // Update list binding

                this.byId("idList").getBinding("items").filter(filters);

    },



    handleRefresh: function () {

      var that = this;



      // trigger search again and hide pullToRefresh when data ready

      var oProductList = this.getView().byId("productList");

      var oBinding = oProductList.getBinding("items");

      var fnHandler = function () {

        that.getView().byId("pullToRefresh").hide();

        oBinding.detachDataReceived(fnHandler);

      };

      oBinding.attachDataReceived(fnHandler);

    //  that._search();

    },



    handleListItemPress: function (oEvent) {

      var oItem = oEvent.getSource();

      var spath = this.getView().byId("idList").getSelectedItem().oBindingContexts.appModel.sPath;

      console.log(spath);

      var sId = this.getView().byId("idList").getModel("appModel").getProperty(spath).Key;

      this._router.navTo(sId);

    }

  });

});