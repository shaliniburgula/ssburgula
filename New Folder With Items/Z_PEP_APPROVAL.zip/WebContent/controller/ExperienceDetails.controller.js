jQuery.sap.require("sap.ca.ui.dialog.factory");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper");

var employeeNum,Infotype,Subtype,ObjectID, EmployerName ,Country ,City ,IndustrykeyTxt ,FormerJobTxt ,EndDate ,StartDate;

var CreationTime ,CreationDate ,empModel;

var base64,fileContentType,fileLength,fileName ,stringUpload,   evFlag,eduEstVal,CreationTimeA ,CreationDateA ;

sap.ui.controller("hcm.people.profile.Z_PEP_APPROVAL.controller.ExperienceDetails", {



/**

* Called when a controller is instantiated and its View controls (if available) are already created.

* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

* @memberOf z_pep_approval.Address

*/

  onInit: function() {

     this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

     this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 

  },





  _handleRouteMatched: function(oEvent)

  {

    var oParamaeters = oEvent.getParameter("name");

    if(oParamaeters!="ExperienceDetails")

    {

    return;

    }



   var path =  oEvent.getParameter("arguments").contextPath;



    //console.log(path);

    this.getView().bindElement("empModel>/results/"+path);

   

    var attchJson = new sap.ui.model.json.JSONModel();

    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");



    var servicepath = this.getView().getElementBinding('empModel').sPath;



    employeeNum = this.getView().getModel("empModel").getProperty(servicepath).Employeenumber;

    

    CreationDate = this.getView().getModel("empModel").getProperty(servicepath).CreationDate;

    

     var formattedStartDate = new Date(CreationDate);

		formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');

		

    

    var attchSet = "AttachmentCreateSet?$filter=Employeenumber eq '"+employeeNum+"' and Infotype eq '0023' and CreationDate eq datetime'"+formattedStartDate+"'";///$value

   

    

   // var attchSet = "AttachmentCreateSet?$filter=Employeenumber eq '"+employeeNum+"' and Infotype eq '0023'";///$value

    oDataModel.read(attchSet, null, null, false, function(r) {



      attchJson.setData(r);

    });

    this.getView().setModel(attchJson,"attchEmpModel");

    

    var personalJson = new sap.ui.model.json.JSONModel();

    

    var persSet = "EmployeeDataSet('"+employeeNum+"')";///$value

    oDataModel.read(persSet, null, null, true, function(r) {



      personalJson.setData(r);

    });

    this.getView().setModel(personalJson,"persExpModel");
        //setting image 
    var iconUrl = oDataModel.sServiceUrl+ "/EmployeeDataSet('" + employeeNum+ "')/$value";
    
    this.byId("objHeader").setIcon(iconUrl);
   

    

  },

  submitData :function(){

     

  },

  onApprove : function()

  {



    var servicepath = this.getView().getElementBinding('empModel').sPath;



    employeeNum = this.getView().getModel("empModel").getProperty(servicepath).Employeenumber;

     Infotype = this.getView().getModel("empModel").getProperty(servicepath).Infotype;

      Subtype = this.getView().getModel("empModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("empModel").getProperty(servicepath).ObjectID;

      EmployerName = this.getView().getModel("empModel").getProperty(servicepath).EmployerName;

      City = this.getView().getModel("empModel").getProperty(servicepath).City;

      Country = this.getView().getModel("empModel").getProperty(servicepath).Country;

      IndustrykeyTxt = this.getView().getModel("empModel").getProperty(servicepath).IndustrykeyTxt;

      FormerJobTxt = this.getView().getModel("empModel").getProperty(servicepath).FormerJobTxt;

      EndDate = this.getView().getModel("empModel").getProperty(servicepath).EndDate;

      StartDate = this.getView().getModel("empModel").getProperty(servicepath).StartDate;

      CreationTime = this.getView().getModel("empModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("empModel").getProperty(servicepath).CreationDate;

     

         var attchPath = "/results/0"

      

        base64 = this.getView().getModel("attchEmpModel").getProperty(attchPath).FileContent;

        fileContentType = this.getView().getModel("attchEmpModel").getProperty(attchPath).FileContentType; 

        fileLength = this.getView().getModel("attchEmpModel").getProperty(attchPath).FileLength;

        fileName =  this.getView().getModel("attchEmpModel").getProperty(attchPath).FileName;

        stringUpload = this.getView().getModel("attchEmpModel").getProperty(attchPath).StringUpload;

        evFlag = this.getView().getModel("attchEmpModel").getProperty(attchPath).EvFlag;

        CreationTimeA = this.getView().getModel("attchEmpModel").getProperty(attchPath).CreationTime;

      CreationDateA = this.getView().getModel("attchEmpModel").getProperty(attchPath).CreationDate;

     

      

      

    this.validationMessage = "success";

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

          var  createPath = "OtherEmployersSet";

           var workflowStatus ="A";

            	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var empObj = {

              Employeenumber :employeeNum,

              Infotype: Infotype,

              Subtype: Subtype,

              ObjectID: ObjectID,

              IndustrykeyTxt: IndustrykeyTxt,

              Country : Country,

              FormerJobTxt:FormerJobTxt ,

              EmployerName:EmployerName ,

              EndDate:EndDate ,

              StartDate :StartDate,

              CreationTime:CreationTime ,

              CreationDate:CreationDate ,

              WorkflowStatus :workflowStatus ,

              ApproverComments :r.sNote

           };

           

           var that = this;

          oDataModel.create(createPath,empObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

    var attchUpdateSet = "AttachmentCreateSet";///$value

    	var fileDataObj = {

								

								Employeenumber : employeeNum,

									Infotype : "0023",

								Subtype: "",

								FileContent:base64,

								FileContentType:fileContentType,

								FileLength:fileLength,

								FileName:fileName,

								StringUpload:stringUpload,

								EvFlag:evFlag,

								WorkflowStatus : 'A',

								EduEstablishTxt : eduEstVal,

								 CreationTime:CreationTimeA,

                                CreationDate:CreationDateA

						};

	oDataModel.create(attchUpdateSet,fileDataObj, null, function(responseBody, sucRes) {

		result = true;

	}, function(failRes) {

		result = false;

		errorBody = JSON.parse(failRes.response.body);

			

	});

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Approved Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			

			var empJson = new sap.ui.model.json.JSONModel();

			var empSet = "OtherEmployersSet";



			oDataModel.read(empSet, null, null, false, function(r) {



				empJson.setData(r);

			});

			this.getOwnerComponent().setModel(empJson,"empModel")

				 var resultsLength = this.getView().getModel("empModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("ExperienceDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---Experience--idExpPage").setTitle("Experience Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---Experience--idList").getItems();

               sap.ui.getCore().byId("__component0---Experience--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "addressModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("addressModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Do you want to Approve?",

      showNote: true,

      title: "Confirm",

      confirmButtonLabel: "Confirm"

    }, C)



  },

  onReject : function(){

    var servicepath = this.getView().getElementBinding('empModel').sPath;



    employeeNum = this.getView().getModel("empModel").getProperty(servicepath).Employeenumber;

     Infotype = this.getView().getModel("empModel").getProperty(servicepath).Infotype;

      Subtype = this.getView().getModel("empModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("empModel").getProperty(servicepath).ObjectID;

      EmployerName = this.getView().getModel("empModel").getProperty(servicepath).EmployerName;

      City = this.getView().getModel("empModel").getProperty(servicepath).City;

      Country = this.getView().getModel("empModel").getProperty(servicepath).Country;

      IndustrykeyTxt = this.getView().getModel("empModel").getProperty(servicepath).IndustrykeyTxt;

      FormerJobTxt = this.getView().getModel("empModel").getProperty(servicepath).FormerJobTxt;

      EndDate = this.getView().getModel("empModel").getProperty(servicepath).EndDate;

      StartDate = this.getView().getModel("empModel").getProperty(servicepath).StartDate;

      CreationTime = this.getView().getModel("empModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("empModel").getProperty(servicepath).CreationDate;

      empModel = this.getView().getModel("empModel").getProperty(servicepath).empModel;

      

   var attchPath = "/results/0"

      

        base64 = this.getView().getModel("attchEmpModel").getProperty(attchPath).FileContent;

        fileContentType = this.getView().getModel("attchEmpModel").getProperty(attchPath).FileContentType; 

        fileLength = this.getView().getModel("attchEmpModel").getProperty(attchPath).FileLength;

        fileName =  this.getView().getModel("attchEmpModel").getProperty(attchPath).FileName;

        stringUpload = this.getView().getModel("attchEmpModel").getProperty(attchPath).StringUpload;

        evFlag = this.getView().getModel("attchEmpModel").getProperty(attchPath).EvFlag;

         CreationTimeA = this.getView().getModel("attchEmpModel").getProperty(attchPath).CreationTime;

      CreationDateA = this.getView().getModel("attchEmpModel").getProperty(attchPath).CreationDate;

      

    this.validationMessage = "Rejected";

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

          var  createPath = "OtherEmployersSet";

           var workflowStatus ="R";

         	var result = false;

	        var errorBody;

      

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

         var empObj = {

              Employeenumber :employeeNum,

              Infotype: Infotype,

              Subtype: Subtype,

              ObjectID: ObjectID,

              IndustrykeyTxt: IndustrykeyTxt,

              Country : Country,

              FormerJobTxt:FormerJobTxt ,

              EmployerName:EmployerName ,

              EndDate:EndDate ,

              StartDate :StartDate,

              CreationTime:CreationTime ,

              CreationDate:CreationDate ,

              WorkflowStatus :workflowStatus ,

              empModel :empModel, 

              ApproverComments :r.sNote

           };

               var that = this;

          oDataModel.create(createPath,empObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

    var attchUpdateSet = "AttachmentCreateSet";///$value

    	var fileDataObj = {

								

								Employeenumber : employeeNum,

									Infotype : "0023",

								Subtype: "",

								FileContent:base64,

								FileContentType:fileContentType,

								FileLength:fileLength,

								FileName:fileName,

								StringUpload:stringUpload,

								EvFlag:evFlag,

								WorkflowStatus : 'R',

								 CreationTime:CreationTimeA,

                                CreationDate:CreationDateA

						};

	oDataModel.create(attchUpdateSet,fileDataObj, null, function(responseBody, sucRes) {

		result = true;

	}, function(failRes) {

		result = false;

		errorBody = JSON.parse(failRes.response.body);

			

	});

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Rejected Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			

			var empJson = new sap.ui.model.json.JSONModel();

			var empSet = "OtherEmployersSet";



			oDataModel.read(empSet, null, null, false, function(r) {



				empJson.setData(r);

			});

			this.getOwnerComponent().setModel(empJson,"empModel")

				 var resultsLength = this.getView().getModel("empModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("ExperienceDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---Experience--idExpPage").setTitle("Experience Data("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---Experience--idList").getItems();

               sap.ui.getCore().byId("__component0---Experience--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "addressModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("addressModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Do you want to Reject. Please provide comments",

      showNote: true,

      title: "Rejected",

      confirmButtonLabel: "Reject"

    }, C)

},



  onAttachListItemSelect : function(e){

    var servicepath = this.getView().getElementBinding('empModel').sPath;

    var employeeNum = this.getView().getModel("empModel").getProperty(servicepath).Employeenumber;

     var CreationDate = this.getView().getModel("empModel").getProperty(servicepath).CreationDate;

    

     var formattedStartDate = new Date(CreationDate);

		formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');

    

    var infoType = "0023";

    if (employeeNum && infoType) {

      var display = "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/AttachmentDisplaySet(Employeenumber='"+employeeNum+"',Infotype='"+infoType+"',CreationDate=datetime'"+formattedStartDate+"')/$value";

      //location.href = display;

      window.open(display,"_blank");

    }

  },

  	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = iDatadt.getFullYear() +

				'-' + month +

				'-' + day +

				'T' + "00" +

				':' + "00" +

				':' + "00";



			return iDatadt;



		}



	}







/**

* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

* (NOT before the first rendering! onInit() is used for that one!).

* @memberOf z_pep_approval.Address

*/

//  onBeforeRendering: function() {

//

//  },



/**

* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

* This hook is the same one that SAPUI5 controls get after being rendered.

* @memberOf z_pep_approval.Address

*/

//  onAfterRendering: function() {

//

//  },



/**

* Called when the Controller is destroyed. Use this one to free resources and finalize activities.

* @memberOf z_pep_approval.Address

*/

//  onExit: function() {

//

//  }



});