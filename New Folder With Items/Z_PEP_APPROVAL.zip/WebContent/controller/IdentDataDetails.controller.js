jQuery.sap.require("sap.ca.ui.dialog.factory");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper");

var employeeNum,Infotype,Subtype,ObjectID,FirstName,LastName,CreationTime,CreationDate,ApproverName,IDNumber;

sap.ui.controller("hcm.people.profile.Z_PEP_APPROVAL.controller.IdentDataDetails", {



/**

* Called when a controller is instantiated and its View controls (if available) are already created.

* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

* @memberOf z_pep_approval.Address

*/

  onInit: function() {

    this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

    this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 

  },





  _handleRouteMatched: function(oEvent)

  {

    var oParamaeters = oEvent.getParameter("name");

    if(oParamaeters!="IdentDataDetails")

    {

    return;

    }
   var path =  oEvent.getParameter("arguments").contextPath;
    this.getView().bindElement("identifDataModel>/results/"+path);

    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", false, "", "");



    var servicepath = this.getView().getElementBinding('identifDataModel').sPath;

     CreationDate = this.getView().getModel("identifDataModel").getProperty(servicepath).CreationDate;

    employeeNum = this.getView().getModel("identifDataModel").getProperty(servicepath).Employeenumber;
        IDNumber = this.getView().getModel("identifDataModel").getProperty(servicepath).IDNumber;
        var subtype;
        if(IDNumber.length === 8)
        {
            this.getView().byId("idPers").setText("Passport No");
            this.getView().byId("idPersOld").setText("Passport No");
            subtype = "04";
        }
        else
        {
            this.getView().byId("idPers").setText("Aadhar ID");
            this.getView().byId("idPersOld").setText("Aadhar ID");
            subtype="06";
        }

     var formattedStartDate = new Date(CreationDate);

	formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');
      var attchJson = new sap.ui.model.json.JSONModel();
    var attchSet = "AttachmentCreateSet?$filter=Employeenumber eq '"+employeeNum+"' and Infotype eq '0185' and CreationDate eq datetime'"+formattedStartDate+"'";///$value

    oDataModel.read(attchSet, null, null, false, function(r) {

      attchJson.setData(r);

    });

    this.getView().setModel(attchJson,"attchModel");

    console.log(attchJson);
        
    var size = this.getView().getModel("attchModel").getData().results.length;
    if(size ===0){
        this.getView().byId("application-ZPEPPROFAPPR-approve-component---IdentDataDetails--ATTID_ICON_TAB").setVisible(false);
        
    }
    else
    {
        this.getView().byId("application-ZPEPPROFAPPR-approve-component---IdentDataDetails--ATTID_ICON_TAB").setVisible(true);
    }
    
    var personalJson = new sap.ui.model.json.JSONModel();

    

    var persSet = "EmployeeDataSet('"+employeeNum+"')";///$value

    oDataModel.read(persSet, null, null, true, function(r) {



      personalJson.setData(r);

    });

    this.getView().setModel(personalJson,"persIdentModel");
    var persID;
     if(IDNumber.length === 8)
        {
            persID = this.getView().getModel("persIdentModel").getData().PassportID;
            if(persID !== "" && persID !== undefined){
                this.getView().byId("AA_IDOld").setText(persID);
            }
            else
            {
                this.getView().byId("AA_IDOld").setText("No Data");
            }
        }
        else
        {
             persID = this.getView().getModel("persIdentModel").getData().AadharID;
             
            if(persID !== "" && persID !== undefined){
                this.getView().byId("AA_IDOld").setText(persID);
            }
            else
            {
                this.getView().byId("AA_IDOld").setText("No Data");
            }
        }
        //setting image 
    var iconUrl = oDataModel.sServiceUrl+ "/EmployeeDataSet('" + employeeNum+ "')/$value";
    
    this.byId("objHeader").setIcon(iconUrl);
  },

  submitData :function(){

     

  },

  onApprove : function()

  {



    var servicepath = this.getView().getElementBinding('identifDataModel').sPath;



    employeeNum = this.getView().getModel("identifDataModel").getProperty(servicepath).Employeenumber;

      Subtype = this.getView().getModel("identifDataModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("identifDataModel").getProperty(servicepath).ObjectID;

      IDNumber = this.getView().getModel("identifDataModel").getProperty(servicepath).IDNumber;
      CreationTime = this.getView().getModel("identifDataModel").getProperty(servicepath).CreationTime;
      
      
     var formattedStartDate = new Date(CreationDate);

	formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');

      CreationDate = this.getView().getModel("identifDataModel").getProperty(servicepath).CreationDate;

     ApproverName = this.getView().getModel("identifDataModel").getProperty(servicepath).ApproverName;

      

    this.validationMessage = "sucess";

    

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

           var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

        

           var workflowStatus ="A";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var persObj = {

              Employeenumber :employeeNum,

              Subtype: Subtype,

              ObjectID: ObjectID,

                IDNumber :IDNumber,

              CreationTime:CreationTime,

              CreationDate:formattedStartDate,

               WorkflowStatus: workflowStatus,

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

           var createPath ="IdentificationSet";

          oDataModel.create(createPath,persObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Approved Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var identDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "IdentificationSet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				identDataJson.setData(r);

			});

			this.getOwnerComponent().setModel(identDataJson,"identifDataModel");

			var resultsLength = this.getView().getModel("identifDataModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("IdentDataDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---IdentificationData--identMasterPage").setTitle("Personal IDs("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---IdentificationData--idList").getItems();

               sap.ui.getCore().byId("__component0---IdentificationData--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "persDataModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("persDataModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    sap.ca.ui.dialog.confirmation.open({

      question: "Confirm to Approve",

      showNote: false,

      title: "Confirm",

      confirmButtonLabel: "Confirm"

    }, C)



  },

  onReject : function(){



    var servicepath = this.getView().getElementBinding('identifDataModel').sPath;

    

    employeeNum = this.getView().getModel("identifDataModel").getProperty(servicepath).Employeenumber;

      Subtype = this.getView().getModel("identifDataModel").getProperty(servicepath).Subtype;

      ObjectID = this.getView().getModel("identifDataModel").getProperty(servicepath).ObjectID;

      IDNumber = this.getView().getModel("identifDataModel").getProperty(servicepath).IDNumber;

      CreationTime = this.getView().getModel("identifDataModel").getProperty(servicepath).CreationTime;

      CreationDate = this.getView().getModel("identifDataModel").getProperty(servicepath).CreationDate;
      
      
     var formattedStartDate = new Date(CreationDate);

	formattedStartDate = this.ui5ToOdatadataForLocalFiltering(CreationDate, 'date');


     ApproverName = this.getView().getModel("identifDataModel").getProperty(servicepath).ApproverName;

      

    this.validationMessage = "Rejected";

    var C = jQuery.proxy(function(r) {

      if (r) {

        jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);

        if (r.sNote) {

          jQuery.sap.log.debug(r.sNote)

        }

        if (r.isConfirmed) {

                   var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

          

           var workflowStatus ="R";

           	var result = false;

	        var errorBody;

          // var employeeNum = this.getView().getModel("appModel").getProperty(servicepath).Employeenumber;

          var persObj = {

              Employeenumber :employeeNum,

              Subtype: Subtype,

              ObjectID: ObjectID,

                IDNumber :IDNumber,

              CreationTime:CreationTime,

              CreationDate:formattedStartDate,

               WorkflowStatus: 'R',

              ApproverName : ApproverName,

              ApproverComments :r.sNote

           };

           var that = this;

           var createPath ="IdentificationSet";

          oDataModel.create(createPath,persObj, null, function(responseBody, sucRes) {

            result = true;

          }, function(failRes) {

            result = false;

            	errorBody= JSON.parse(failRes.response.body);

          });

	

	if(result=== true){

	     sap.m.MessageBox.show("Data Rejected Successfully", {

      icon: sap.m.MessageBox.Icon.SUCCESS,

      actions: [sap.m.MessageBox.Action.OK],

      onClose: function(oAction) {

          if (oAction === "OK") {

              	

			var identDataJson = new sap.ui.model.json.JSONModel();

			var persDataSet = "IdentificationSet";



			oDataModel.read(persDataSet, null, null, false, function(r) {



				identDataJson.setData(r);

			});

			this.getOwnerComponent().setModel(identDataJson,"identifDataModel");

				var resultsLength = this.getView().getModel("identifDataModel").getData().results.length;

              if(resultsLength >0){

                 this._oRouter.navTo("IdentDataDetails",{contextPath:0});   

              }

              else

              {

                   this._oRouter.navTo("notFound");

              }

                

                 sap.ui.getCore().byId("__component0---IdentificationData--identMasterPage").setTitle("Personal IDs("+resultsLength +")");

                var items = sap.ui.getCore().byId("__component0---IdentificationData--idList").getItems();

               sap.ui.getCore().byId("__component0---IdentificationData--idList").setSelectedItem(items[0]);

		//	sap.ui.getCore().setModel(addressJson, "persDataModel");

		//	sap.ui.getCore().byId("Address--idList").setModel("persDataModel");

			

          }

      }.bind(that)

    });

	}

	else {

	    	sap.m.MessageBox.error("Message: " + errorBody.error.message.value);

	}

            

        }

      }

    }, this);

    

    sap.ca.ui.dialog.confirmation.open({

      question: "Please provide comments for rejection",

      showNote: true,

      title: "Rejected",
      noteMandatory :true,

      confirmButtonLabel: "Reject"

    }, C)

},

dateFormatter: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = day+ '/'+month+ '/' +iDatadt.getFullYear();



			return iDatadt;



		}



	},

  	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = iDatadt.getFullYear() +

				'-' + month +

				'-' + day +

				'T' + "00" +

				':' + "00" +

				':' + "00";



			return iDatadt;



		}



	}



/**

* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

* (NOT before the first rendering! onInit() is used for that one!).

* @memberOf z_pep_approval.Address

*/

//  onBeforeRendering: function() {

//

//  },



/**

* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

* This hook is the same one that SAPUI5 controls get after being rendered.

* @memberOf z_pep_approval.Address

*/

//  onAfterRendering: function() {

//

//  },



/**

* Called when the Controller is destroyed. Use this one to free resources and finalize activities.

* @memberOf z_pep_approval.Address

*/

//  onExit: function() {

//

//  }



});