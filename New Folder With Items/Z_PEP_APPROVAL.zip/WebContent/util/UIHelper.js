/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
hcm.people.profile.Z_PEP_APPROVAL.util.UIHelper = (function() {
	return {
		formatDateold: function(D, a) {
			var b = sap.ca.ui.model.format.DateFormat.getDateInstance({
				style: "medium"
			});
			if (D !== null && D !== undefined) {
				if (a !== undefined) {
					return b.format(D, a);
				} else {
					return b.format(D, true);
				}
			}
		},
		formatDate : function (value) {
    if (value) {
      var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd-MM-yyyy"});
       var value = oDateFormat.format(new Date(value));

      if(value =='31-12-9999'){
        value="Not Applicable";
      }
      return value;
    } else {
      return value;
    }
  },
		formatTime: function(D, a) {
			var b = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				style: "medium"
			});
			if (D !== null && D !== undefined) {
				if (a !== undefined) {
					return b.format(D, a);
				} else {
					return b.format(D, true);
				}
			}
		},
		formatNumber: function(v) {
			var a = sap.ca.ui.model.format.NumberFormat.getInstance();
			return a.format(v);
		},
		sortArrayByProperty: function(v, w) {
			function x(y) {
				var z = 1;
				if (y[0] === "-") {
					z = -1;
					y = y.substr(1);
				}
				return function(a, b) {
					var A = (a[y] < b[y]) ? -1 : (a[y] > b[y]) ? 1 : 0;
					return A * z;
				};
			}
			return v.sort(x(w));
		},
		formatHigherEdu : function(value){
		    if(value ===""){
		        return "No";
		    }
		    else
		    {
		        return "Yes";
		    }
		}
	};
}());