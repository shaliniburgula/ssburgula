jQuery.sap.declare("ui.s2p.srm.sc.create.ZSRM_SC_CRE.util.Formatter");

jQuery.sap.require("sap.ui.core.Element");

jQuery.sap.require("sap.ui.core.ValueState");

jQuery.sap.require("sap.ui.core.format.NumberFormat");

ui.s2p.srm.sc.create.ZSRM_SC_CRE.util.Formatter = {

	doctorNameFormat: function(a, splKey, unnatiID) {
        if(a!== "" || a !== undefined){
		var docList = a.split(",");

		var splKeyList = splKey.split(",");

		var unnatiIDList = unnatiID.split(",");

		var docNames = "";

		for (var i = 0; i < docList.length; i++) {

			docNames += docList[i] + "-" + splKeyList[i] + "-" + unnatiIDList[i] + "\n";

		}

		return docNames;
        }
	},

	formatPreferredItem: function(a) {

		if (a == "01") {

			var A = sap.ca.scfld.md.app.Application.getImpl();

			var b = A.getResourceBundle();

			return b.getText("PREFERRED_ITEM")

		} else {

			return ""

		}

	},

	formatQuantity: function(v, u) {

		return sap.ca.ui.model.format.QuantityFormat.FormatQuantityStandard(v, u, 0)

	},

	formatItemCount: function(i) {

		var a = sap.ca.scfld.md.app.Application.getImpl();

		var b = a.getResourceBundle();

		return b.getText("ITEMS_QTY_EX", [i])

	},

	formatPrice: function(v) {

		var n = v;

		var i, j;

		var decPlaces = "2";

		var decSeparator = ".";

		var thouSeparator = ",";

		decPlaces = isNaN(decPlaces = Math.abs(decPlaces)) ? 2 : decPlaces;

		decSeparator = decSeparator === undefined ? "." : decSeparator;

		thouSeparator = thouSeparator === undefined ? "," : thouSeparator;

		i = parseInt(n = Math.abs(+n || 0).toFixed(decPlaces)) + "";

		j = (j = i.length) > 3 ? j % 3 : 0;

		return (j ? i.substr(0, j) + thouSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thouSeparator) + (decPlaces ?
			decSeparator + Math.abs(n - i).toFixed(decPlaces).slice(2) : "");

	},

	formatCreatedOn: function(c) {

		return this.oBundle.ResourceBundle.getText("CREATED_EX", [c])

	},

	leadingZerosCode: function(docCode, splKey, unnatiCode) {

		var UTCode = "";

		if (unnatiCode !== "") {

			UTCode = parseInt(unnatiCode);

		}

		var result = docCode + ":" + splKey + ":" + UTCode;

		return result;

	}

};