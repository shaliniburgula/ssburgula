jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");

jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

jQuery.sap.require("ui.s2p.srm.sc.create.ZSRM_SC_CRE.util.Formatter");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("sap.ca.ui.model.type.Number");

jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.ZSRM_SC_CRE.view.ShoppingCartCheckoutCustom", {

	onInit: function() {

		this.oBundle = this.oApplicationFacade.getResourceBundle();

		this.busyDialog = new sap.m.BusyDialog({

			customIcon: sap.ca.ui.images.images.Flower

		});

		this.oRouter.attachRouteMatched(function(e) {

			if (e.getParameter("name") === "shoppingCartCheckout") {

				this.tempCartId = e.getParameter("arguments").tempCartId;

				this.busyDialog.open();

				this.getUserPersonalizationsettings();

				this.getTempCartItems();

				//	this.getView().byId("dateplusseven").setValue("");

				//this.getView().byId("state").setValue("");

			}

		}, this);

		var c = sap.ui.core.Component.getOwnerIdFor(this.getView());

		var C = sap.ui.component(c);

		C.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", jQuery.proxy(this.getData, this), this);

		//	this.getView().byId("dateplusseven").setValue("");

		this.getView().byId("state").setValue("");

		this.co_area = "";

		this.country_key = "";

		this.oCountryModel = this.createModel('Country', 'CountryCollection', null, "COUNTRY_SH_SERVICE");

		this.jsonModel = new sap.ui.model.json.JSONModel({

			results: [{

					accAssg: this.oBundle.getText("COST_CENTER")

			}







				/*, {







				accAssg: this.oBundle.getText("INTERNAL_ORDER")







			}*/







				]

		});

		this.getView().setModel(this.jsonModel, "AccountAssignment");

		var stateList = function(D, r) {

			var m = new sap.ui.model.json.JSONModel(D);

			this.getView().setModel(m, "stateList");

			console.log(m);

		};

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		var path = "SHStateSet?$filter=Country eq 'India'";

		dModel.read(path, null, null, false, jQuery.proxy(stateList, this), jQuery.proxy(this.onRequestFailed, this))

		//Costcenter

		this.getUserPersonalizationsettings();

		var CCList = function(D, r) {

			var m = new sap.ui.model.json.JSONModel(D);

			this.getView().setModel(m, "CCList");

			console.log(m.oData.results[0].CC_DESCRIPTION);

		};

		var ccModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/srmnxp/ACC_ASS_SEARCH_HELP/", true);

		var ccPath = "CostCenterTabCollection?$filter=COST_CTR eq '" + this.costCenter + "'";

		ccModel.read(ccPath, null, null, false, jQuery.proxy(CCList, this), jQuery.proxy(this.onRequestFailed, this))

		//brand value

		var brandList = function(D, r) {

			var brandModel = new sap.ui.model.json.JSONModel(D);

			this.getView().setModel(brandModel, "brandModel");

			console.log(brandModel);

		};

		var brandPath = "SHBrandSet"

		dModel.read(brandPath, null, null, false, jQuery.proxy(brandList, this), jQuery.proxy(this.onRequestFailed, this));

		this.setHeaderFooterOptions(this.createHeaderFooterOptions());

		//	this.getView().byId("dateplusseven").setDisplayFormat(sap.m.getLocaleData().getDatePattern("medium"))

	},

	getData: function(c, e, v) {

		var t = v;

		this.getView().byId("totalValue").setValue(t.totalValue)

	},

	createModel: function(m, p, f, M) {

		var o;

		var a = function(D, r) {

			o = new sap.ui.model.json.JSONModel(D);

			o.setSizeLimit(500);

			this.getView().setModel(o, m)

		};

		var d = this.oApplicationFacade.getODataModel(M);

		d.read(p, null, f, false, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));

		if (m === "Country") return o;

		else return m

	},

	getUserPersonalizationsettings: function() {

		var o = function(D, r) {

			this.oUserDefaults = new sap.ui.model.json.JSONModel(D.results[0]);

			this.costCenter = this.oUserDefaults.oData.COST_CTR;

			this.getView().setModel(this.oUserDefaults, "personalCollection");

			//this.getView().byId("dateplusseven").setValue(this.sevenDaysFromNowDateAsString())

		};

		var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");

		d.read("User_PersonalizationCollection?ts=" + Date.now(), null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,

			this))

	},

	sevenDaysFromNowDateAsString: function() {

		var d = new Date();

		d.setDate(d.getDate() + 15);

		/*	var v = this.getView().byId('dateplusseven').getValueFormat();







		return sap.ca.ui.model.format.DateFormat.getDateInstance({







			pattern: v







		}).format(d)*/

		return d;

	},

	getTempCartItems: function() {

		var o = function(D, r) {

			var T = new sap.ui.model.json.JSONModel(D);

			for (var i = 0; i < T.oData.results.length; i++) {

				T.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(T.oData.results[i].QUANTITY) * parseFloat(T.oData.results[i].PRICE))

			}

			this.getView().byId("MaterialList").setModel(T, "ShoppingCartItems");

			var a = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(T.oData.results.length);

			this.getView().byId("MaterialList").setHeaderText(a);

			this.busyDialog.close()

		};

		//var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		this.getDefaultUserSettings();

		var t = this.getTempCartId();

		d.read("ShoppingcartCollection(TEMP_CART_ID='" + t + "')/ShoppingCartItemNavigation?ts=" + Date.now(), null, null, true, jQuery.proxy(o,

			this), jQuery.proxy(this.onRequestFailed, this))

	},

	discardTempCart: function(t, o) {

		this.busyDialog.open();

		this.OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		this.OShoppingCartDataModel.update("HOLD_DOCUMENT?TEMP_CART_ID='" + t + "'&OBJECT_ID='" + o + "'", null, {

			oContext: null,

			fnSuccess: jQuery.proxy(function() {

				this.busyDialog.close()

			}, this),

			fnError: jQuery.proxy(this.onRequestFailed, this)

		})

		this.OShoppingNewModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		this.OShoppingNewModel.update("HOLD_DOCUMENT?TEMP_CART_ID='" + t + "'&OBJECT_ID='" + o + "'", null, {

			oContext: null,

			fnSuccess: jQuery.proxy(function() {

				this.busyDialog.close()

			}, this),

			fnError: jQuery.proxy(this.onRequestFailed, this)

		})

	},

	getItemId: function() {

		return this.oDefaultSettings.oData.results[0].ITEM_NO;

	},

	getTempCartId: function() {

		return this.oDefaultSettings.oData.results[0].TEMP_CART_ID;

	},

	getDefaultUserSettings: function() {

		var o = function(D, r) {

			this.oDefaultSettings = new sap.ui.model.json.JSONModel(D)

		};

		var d = this.oApplicationFacade.getODataModel("getdefusrset");

		d.read("DefaultUserSettings?ts=" + Date.now(), null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))

	},

	getCartObjectId: function() {

		return this.oDefaultSettings.oData.results[0].OBJECT_ID

	},

	getRequestorId: function() {

		return this.oDefaultSettings.oData.results[0].USERID;

	},

	onCancel: function() {

		var t = this;

		var c = new sap.m.Text({

			text: t.oBundle.getText("CANCEL_MESSAGE")

		});

		var a = null;

		a = new sap.m.Dialog({

			content: [c],

			title: t.oBundle.getText("CANCEL_TITLE"),

			leftButton: new sap.m.Button({

				text: this.oBundle.getText("YES"),

				press: function() {

					t.discardTempCart(t.getTempCartId(), t.getCartObjectId());

					a.close();

					t.oRouter.navTo("master", null, true);

					t.getView().byId("noteToApprover").setValue("")

				}

			}),

			rightButton: new sap.m.Button({

				text: this.oBundle.getText("NO"),

				press: function() {

					a.close()

				}

			})

		}).addStyleClass("sapUiPopupWithPadding");

		a.open()

	},

	getSRMCartItems: function(s, c, b) {

		if (typeof(b) === undefined) {

			b = true

		}

		var o = jQuery.proxy(function(d, r) {

			if (s) {

				s.call(d, r)

			}

		}, this);

		var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");

		var p = "SRMShoppingCartCollection(OBJECT_ID='" + c + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartItemNavigation?ts=" + Date.now();

		O.read(p, null, null, b, o, jQuery.proxy(this.onRequestFailed, this))

	},

	saveSRMShoppingCart: function(s, o, d, a) {

		var I;

		var t = this;

		var b = jQuery.proxy(function(D, r) {

			I = D;

			I.CURRENCY = d.oData.results[0].CURRENCY;

			I.CITY = this.getView().byId("city").getValue();

			I.COUNTRY = t.country_key;

			I.STREET = this.getView().byId("street").getValue();

			I.APRV_NOTE = a

		}, this);

		var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");

		var p = "SRMShoppingCartCollection(OBJECT_ID='" + o + "',DOC_MODE='DISPLAY',WIID='000000000000')?ts=" + Date.now();

		O.read(p, null, null, false, b, jQuery.proxy(this.onRequestFailed, this));

		for (var i = 0; i < t.oCountryModel.oData.results.length; i++) {

			if (this.getView().byId("input_assisted1").getValue() === t.oCountryModel.oData.results[i].CountryName) {

				I.COUNTRY = t.oCountryModel.oData.results[i].CountryKey;

				t.country_key = t.oCountryModel.oData.results[i].CountryKey

			}

		}

		if (this.extHook1) {

			this.extHook1()

		};

		if (this.extHook2) {

			this.extHook2()

		};

		var c = {};

		c.ACC_NO = '0001';

		c.WIID = '000000000000';

		c.DISTR_PERC = '100.0';

		c.G_L_ACCT = this.oUserDefaults.oData.G_L_ACCT;

		if (this.co_area === "") {

			this.co_area = this.oUserDefaults.oData.CO_AREA

		}

		var e = "Cost Center";

		var f = this.oBundle.getText("COST_CENTER").trim();

		var g = this.oBundle.getText("INTERNAL_ORDER").trim();

		if (e === f) {

			var CC = this.getView().byId("input_assisted2").getValue();

			CC = CC.split("-");

			c.COST_CTR = CC[0];

			c.ACC_CAT = 'CC';

			c.CO_AREA = t.co_area

		} else if (e === g) {

			c.ORDER_NO = this.getView().byId("input_assisted2").getValue();

			c.ACC_CAT = 'OR';

			c.CO_AREA = t.co_area

		} else if (e === "") {

			c.CO_AREA = this.oUserDefaults.oData.CO_AREA

		}

		var h = {};

		h.ShoppingCartID = o;

		h.WIID = '000000000000';

		h.City = this.getView().byId("city").getValue();

		h.Name = this.oUserDefaults.oData.REQUESTOR_DESC;

		h.CountryName = this.getView().byId("input_assisted1").getValue();

		h.Country = t.country_key;

		h.Street = this.getView().byId("street").getValue();

		h.PostalCode1 = this.getView().byId("zip").getValue();

		h.PhoneNumber = this.getView().byId("mobile").getValue();

		var S = function() {

			s.call()

		};

		this.getSRMCartItems(jQuery.proxy(function(D, r) {

			var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");

			var B = new Array();

			for (var i = 0; i < D.data.results.length; i++) {

				var deliveryDate = this.sevenDaysFromNowDateAsString();

				D.data.results[i].DELIV_DATE = deliveryDate;

				var j = new Date();

				j.setUTCMonth(D.data.results[i].DELIV_DATE.getMonth());

				j.setUTCDate(D.data.results[i].DELIV_DATE.getDate());

				j.setUTCFullYear(D.data.results[i].DELIV_DATE.getFullYear());

				j.setUTCHours(00);

				j.setUTCMinutes(00);

				j.setUTCSeconds(00);

				D.data.results[i].DELIV_DATE = j;

				delete D.data.results[i].__metadata;

				delete D.data.results[i].SourceofSupplyNavigation;

				delete D.data.results[i].ItemAccountAssignmentNavigation;

				delete D.data.results[i].ItemApproverNavigation;

				delete D.data.results[i].ItemAttachmentNavigation;

				delete D.data.results[i].ItemShippingAddressNavigation;
        /*start To send data to custom fields SRMSHOPPING_CART */				
			var docCodeArray, docNamesArray, unnatiArray, splKeyArray, prod_id, bookDes;
	
		var tempcartId = this.getTempCartId();

		var oCustomData = function(CustomD, r) {

			var T = new sap.ui.model.json.JSONModel(CustomD);

			docCodeArray = T.oData.results[i].Doccode;

			//	docCodeArray = docCodeArray.split(",");

				docNamesArray = T.oData.results[i].Docname;

			//	docNamesArray = docNamesArray.split(",");

				unnatiArray = T.oData.results[i].UnnatiID;

			//	unnatiArray = unnatiArray.split(",");

				splKeyArray = T.oData.results[i].SpecialityKey;

			//	splKeyArray = splKeyArray.split(",");

				prod_id = T.oData.results[i].PRODUCTKEY;

				bookDes = T.oData.results[i].DESCRIPTION;

				var k = i + 1;

				var ItemNumber;

				if (i >= 10) {

					ItemNumber = "00000000" + k;

				} else if (i >= 100) {

					ItemNumber = "0000000" + k;

				} else {

					ItemNumber = "000000000" + k;

				}
					D.data.results[i].ZZREGION_TEXT = this.getView().byId("state").getValue(); //ZZREGION_TEXT

					D.data.results[i].ZZDOCCODE = docCodeArray; //ZZDOCCODE

					D.data.results[i].ZZDOCNAME = docNamesArray; //ZZDOCNAME

					D.data.results[i].ZZUNNATIID = unnatiArray; //ZZUNNATIID

					D.data.results[i].ZZSPECIALITYKEY = splKeyArray; //ZZSPECIALITYKEY

					D.data.results[i].ZZKOSTL = this.costCenter;  //ZZKOSTL
					
					D.data.results[i].ZZDOCCITY = "";
					D.data.results[i].ZZBRAND = this.getView().byId("idBrandSelect").getSelectedItem().getText();

		};
            	var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);
		    dModel.read("ShoppingcartCollection(TEMP_CART_ID='" + tempcartId + "')/ShoppingCartItemNavigation?ts=" + Date.now(), null, null, false, jQuery.proxy(oCustomData,

			this), jQuery.proxy(this.onRequestFailed, this));

/*end To send data to custom fields SRMSHOPPING_CART */
				B.push(O.createBatchOperation("SRMShoppingCartItemCollection(NUMBER_INT='" + D.data.results[i].NUMBER_INT + "',OBJECT_ID='" + o +

					"',DOC_MODE='',WIID='000000000000')", "PUT", D.data.results[i]));

				c.NUMBER_INT = D.data.results[i].NUMBER_INT;

				B.push(O.createBatchOperation("AccountAssignmentCollection(NUMBER_INT='" + c.NUMBER_INT + "',OBJECT_ID='" + o +

					"',ACC_NO='0001',DOC_MODE='',WIID='000000000000')", "PUT", c));

				h.ItemNumber = D.data.results[i].NUMBER_INT;

				B.push(O.createBatchOperation("ShippingAddressCollection(ItemNumber='" + c.NUMBER_INT + "',ShoppingCartID='" + o +

					"',DOC_MODE='',WIID='000000000000')", "PUT", h))

			}

			O.addBatchChangeOperations(B);

			O.submitBatch(S, jQuery.proxy(this.onRequestFailed, this))

		}, this), o)

	},

	saveTempCart: function(s, t, o) {

		var i = {

			TEMP_CART_ID: this.getTempCartId(),

			CHECKOUT: "X",

			WAERS: this.oDefaultSettings.oData.results[0].CURRENCY,
			
			Brand : this.getView().byId("idBrandSelect").getSelectedItem().getText()

		};

		if (o !== null) {

			i.OBJECT_ID = o

		};

		var e = function(E) {

			this.busyDialog.close();

			jQuery.sap.require("sap.ca.ui.message.message");

			sap.ca.ui.message.showMessageBox({

				type: sap.ca.ui.message.Type.ERROR,

				message: E.message,

				details: jQuery.parseJSON(E.response.body).error.message.value

			})

		};

		var S = jQuery.proxy(function(D, r) {

			if (s) {

				s.call(D, r)

			}

		}, this);

		var a = this.getView().byId("noteToApprover").getValue();

		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		d.create("ShoppingcartCollection", i, null, jQuery.proxy(function(D, r) {

			this.saveSRMShoppingCart(S, D.OBJECT_ID, this.oDefaultSettings, a)
            this.saveShoppingCart(S, D.OBJECT_ID);
			//this.saveBookDetails(S, D.OBJECT_ID);

		

		}, this), jQuery.proxy(e, this))

	},

	saveShoppingCart: function(s, objectId) {

		var B = new Array();

		var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		var t = this.getTempCartId();

		var o = function(D, r) {

			var T = new sap.ui.model.json.JSONModel(D);

			for (var j = 0; j < T.oData.results.length; j++) {

				var h = {};

				h.OBJECT_ID = objectId;

				h.ITEM_NO = T.oData.results[j].ITEM_NO;

				h.TEMP_CART_ID = t;

				B.push(d.createBatchOperation("ShoppingcartItemCollection(ITEM_NO='" + T.oData.results[j].ITEM_NO + "',TEMP_CART_ID='" + t + "')",
					"PUT", h))

			}

			d.addBatchChangeOperations(B);

			d.submitBatch(d, jQuery.proxy(this.onRequestFailed, this))

			this.busyDialog.close()

		};

		d.read("ShoppingcartCollection(TEMP_CART_ID='" + t + "')/ShoppingCartItemNavigation?ts=" + Date.now(), null, null, false, jQuery.proxy(o,

			this), jQuery.proxy(this.onRequestFailed, this));

		var S = function() {

			s.call()

		};

	},

	saveBookDetails: function(s, objectId) {

		var B = new Array();

		var docCodeArray, docNamesArray, unnatiArray, splKeyArray, prod_id, bookDes;

		var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		var userId = this.getRequestorId();

		//	var userIdSplit = requestor.split("P");

		//	var userId = userIdSplit[1];

		var t = this.getTempCartId();

		var o = function(D, r) {

			var T = new sap.ui.model.json.JSONModel(D);

			for (var j = 0; j < T.oData.results.length; j++) {

				docCodeArray = T.oData.results[j].Doccode;

				docCodeArray = docCodeArray.split(",");

				docNamesArray = T.oData.results[j].Docname;

				docNamesArray = docNamesArray.split(",");

				unnatiArray = T.oData.results[j].UnnatiID;

				unnatiArray = unnatiArray.split(",");

				splKeyArray = T.oData.results[j].SpecialityKey;

				splKeyArray = splKeyArray.split(",");

				prod_id = T.oData.results[j].PRODUCTKEY;

				bookDes = T.oData.results[j].DESCRIPTION;

				var k = j + 1;

				var ItemNumber;

				if (j >= 10) {

					ItemNumber = "00000000" + k;

				} else if (j >= 100) {

					ItemNumber = "0000000" + k;

				} else {

					ItemNumber = "000000000" + k;

				}

				for (var i = 0; i < docCodeArray.length; i++) {

					var h = {};

					//	h.OrderedProd = itemModel.oData.matnr;

					h.Street = this.getView().byId("street").getValue();

					h.City = this.getView().byId("city").getValue() + ". +91" + this.getView().byId("mobile").getValue();

					h.RegionName = this.getView().byId("state").getValue();

					h.CountryName = this.getView().byId("input_assisted1").getValue();

					h.PostalCode1 = this.getView().byId("zip").getValue();

					h.PhoneNumber = this.getView().byId("mobile").getValue();

					h.BookDescription = bookDes;

					h.Mrpostn = "";

					h.Doccode = docCodeArray[i];

					h.Docname = docNamesArray[i];

					h.UnnatiID = unnatiArray[i];

					h.SpecialityKey = splKeyArray[i];

					h.CartNo = objectId;

					h.ItemNumber = ItemNumber;

					h.CreatedBy = userId;

					h.CostCenter = this.costCenter;

					h.Brand = this.getView().byId("idBrandSelect").getSelectedItem().getText();

					B.push(d.createBatchOperation("BookDetailsSet", "POST", h))

				}

			}

			d.addBatchChangeOperations(B);

			d.submitBatch(d, jQuery.proxy(this.onRequestFailed, this))

			this.busyDialog.close()

		};

		d.read("ShoppingcartCollection(TEMP_CART_ID='" + t + "')/ShoppingCartItemNavigation?ts=" + Date.now(), null, null, false, jQuery.proxy(o,

			this), jQuery.proxy(this.onRequestFailed, this));

		var S = function() {

			s.call()

		};

	},

	submitTempCart: function(s, t, o) {

		var i = {

			TEMP_CART_ID: t,

			ORDER: "X"

		};

		var e = function(E) {

			this.busyDialog.close();

			var c = function() {

				if (sap.ui.getCore().byId("SCNumber")) {

					sap.ui.getCore().byId("SCNumber").destroy()

				}

			};

			jQuery.sap.require("sap.ca.ui.message.message");

			sap.ca.ui.message.showMessageBox({

				type: sap.ca.ui.message.Type.ERROR,

				message: E.message,

				details: jQuery.parseJSON(E.response.body).error.message.value

			}, c)

		};

		var S = jQuery.proxy(function(d, r) {

			var O = this.oApplicationFacade.getODataModel("SHOPPING_CART");

			O.create("ShoppingcartCollection", i, null, jQuery.proxy(function(d, r) {

				if (s) {

					s.call(d, r)

				}

			}, this), jQuery.proxy(e, this))

		}, this);

		this.saveTempCart(S, t, o)

	},

	onSubmit: function() {

		this.busyDialog.open();

		var t = this;

		var a = this.getView().byId("input_assisted2").getValue().trim();

		if (a === "") {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_ON_SUBMIT"));

			return

		}

		/*	var delivery_date = this.getDeliveryDate();
		if(delivery_date !== true){
		    this.busyDialog.close();
			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_DELIVERYDATE_ON_SUBMIT"));
			return
		}
		var deliveryValid = this.checkDeliveryDate();
		if(deliveryValid !== true){
		    this.busyDialog.close();
			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_VALIDDATE_ON_SUBMIT"));
			return
		}*/
		var brand = this.getBrandValue();

		if (brand !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_BRAND_ON_SUBMIT"));

			return

		}

		var street = this.getStreetStatus();

		if (street !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_STREET_ON_SUBMIT"));

			return

		}

		var city = this.getCityStatus();

		if (city !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_CITY_ON_SUBMIT"));

			return

		}

		var state = this.getStateStatus();

		if (state !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_STATE_ON_SUBMIT"));

			return

		}

		var pincode = this.getPinStatus();

		if (pincode !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_PIN_ON_SUBMIT"));

			return

		}

		var pinValidation = this.getPinValid();

		if (pinValidation !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_PINCODE_ON_SUBMIT"));

			return

		}

		var pinLength = this.getpinCodeLength();

		if (pinLength !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_PINLEN_ON_SUBMIT"));

			return

		}

		var c = this.getCountryStatus();

		if (c !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_COUNTRY_ON_SUBMIT"));

			return

		}

		var mobile = this.getMobileStatus();

		if (mobile !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_MOBILE_ON_SUBMIT"));

			return

		}

		var mobValidation = this.getMobValid();

		if (mobValidation !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_MOBNO_ON_SUBMIT"));

			return

		}

		var mobLength = this.getMobLength();

		if (mobLength !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_MOBLEN_ON_SUBMIT"));

			return

		}

		var note = this.getApproverNoteStatus();

		if (note !== true) {

			this.busyDialog.close();

			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_NOTEAPP_ON_SUBMIT"));

			return

		}

		var b = null;

		b = new sap.m.Dialog({

			title: this.oBundle.getText("CONFIRMATION"),

			rightButton: new sap.m.Button({

				text: this.oBundle.getText("DONE"),

				press: function() {

					b.close();

					b.destroyContent();

					t.oRouter.navTo("master", null, true);

					t.getView().byId("noteToApprover").setValue("")

				}

			})

		}).addStyleClass("sapUiPopupWithPadding");

		//on submit functionality 
		var itemsModel = this.getView().byId("MaterialList").getModel("ShoppingCartItems");
	var length = itemsModel.getData().results.length;

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);
        this.cartCheckResult= true;
        var count=0;
        
		for (var i = 0; i < itemsModel.getData().results.length; i++) {
		    if(this.cartCheckResult){
			var productKey = itemsModel.oData.results[i].PRODUCTKEY;
			productKey= jQuery.sap.encodeURL(productKey.substring(0,productKey.length-1));
			var description = jQuery.sap.encodeURL(itemsModel.oData.results[i].DESCRIPTION);
			var costcenter = this.costCenter;

			var path = "CartCheckSet(productkey='" + productKey + "',DESCRIPTION='" + description + "',CostCenter='" + costcenter + "')";
			var CartCheck = function(D, r) {
				
				var oJSONModel = new sap.ui.model.json.JSONModel(D);
			    count++;
			};
			dModel.read(path, null, null, false, jQuery.proxy(CartCheck, this), jQuery.proxy(this.onRequestCartCheckFailed, this))
		
		    }
		   }
		   if(count === length){
	    
			this.submitTempCart(jQuery.proxy(function(d, r) {

			this.busyDialog.close();

			var e = new sap.m.Text("SCNumber");

			b.addContent(e);

			e.setText(t.oBundle.getText("SUCCESSFUL").replace("{0}", d.data.OBJECT_ID));

			b.open();

		}, this), this.getTempCartId(), this.getCartObjectId());
		
		   }
	},
	onRequestCartCheckFailed : function(e){
			this.cartCheckResult = false;
				var j = e.response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				this.busyDialog.close();

				sap.m.MessageBox.alert(this.result.error);
            return;
			
	},

	onCountryValueHelpRequest: function(e) {

		var t = this;

		var a = this.oBundle.getText("SELECT_COUNTRY");

		var p = "/results";

		var b = "{CountryName}";

		var d = "{CountryKey}";

		var f = "CountryName";

		var m = "Country";

		var c = this.getView().byId("input_assisted1");

		var h = function(e) {

			var s = e.getParameter("selectedItem");

			if (s) {

				c.setValue(s.getTitle());

				t.country_key = s.getDescription()

			}

			e.getSource().getBinding("items").filter([])

		};

		this._valueHelpSelectDialog = new sap.m.SelectDialog({

			title: a,

			items: {

				path: p,

				template: new sap.m.StandardListItem({

					title: b,

					description: d,

					active: true

				})

			},

			search: function(e) {

				var v = e.getParameter("value");

				var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);

				e.getSource().getBinding("items").filter([F])

			},

			confirm: h,

			cancel: h

		});

		this._valueHelpSelectDialog.setModel(this.getView().getModel(m));

		this._valueHelpSelectDialog.open()

	},

	onAssignmentTypeValueHelpRequest: function(e) {

		var t = this;

		var a = this.getView().byId("input_assisted3").getValue();

		var b = this.getView().byId("input_assisted2");

		var c = "";

		var d = "";

		var p = "";

		var f = "";

		var g = "";

		var m = "";

		var i = "";

		switch (a) {

			case this.oBundle.getText("COST_CENTER"):

				m = this.createModel('CostCenter', 'CostCenterTabCollection', null, "ACC_ASS_SEARCH_HELP");

				c = this.oBundle.getText("COST_ASSIGNMENT");

				p = "/results";

				d = "{COST_CTR}";

				f = "{CC_DESCRIPTION}";

				g = "COST_CTR";

				i = "{CO_AREA}";

				break;

			case this.oBundle.getText("INTERNAL_ORDER"):

				m = this.createModel('InternalOrder', 'OrderNoTabCollection', null, "ACC_ASS_SEARCH_HELP");

				c = this.oBundle.getText("COST_ASSIGNMENT");

				p = "/results";

				d = "{ORDER_NO}";

				f = "{OR_DESCRIPTION}";

				g = "ORDER_NO";

				i = "{CO_AREA}";

				break;

			case "":

				this.busyDialog.close();

				sap.m.MessageBox.alert(this.oBundle.getText("SELECT_ACCOUNT_ASSIGNMENT_ALERT"));

				return;

			default:

				this.busyDialog.close();

				sap.m.MessageBox.alert(this.oBundle.getText("SELECT_VALID_ACCOUNT_ASSIGNMENT"));

				return

		}

		var h = function(e) {

			var s = e.getParameter("selectedItem");

			if (s) {

				b.setValue(s.getTitle());

				t.co_area = s.getInfo()

			}

			e.getSource().getBinding("items").filter([])

		};

		this._valueHelpSelectDialog = new sap.m.SelectDialog({

			title: c,

			items: {

				path: p,

				template: new sap.m.StandardListItem({

					title: d,

					description: f,

					info: i,

					active: true

				})

			},

			search: function(e) {

				var v = e.getParameter("value");

				var F = new sap.ui.model.Filter(g, sap.ui.model.FilterOperator.Contains, v);

				e.getSource().getBinding("items").filter([F])

			},

			confirm: h,

			cancel: h

		});

		this._valueHelpSelectDialog.setModel(this.getView().getModel(m));

		this._valueHelpSelectDialog.open()

	},

	onAccountAssignmentValueHelpRequest: function(e) {

		var t = this.oBundle.getText("COST_TYPE");

		var p = "/results";

		var a = "{accAssg}";

		var f = "accAssg";

		var b = this.getView().byId("input_assisted3");

		var c = this.getView().byId("input_assisted2");

		var h = function(e) {

			var s = e.getParameter("selectedItem");

			if (s) {

				b.setValue(s.getTitle());

				c.setValue("")

			}

			e.getSource().getBinding("items").filter([])

		};

		this._valueHelpSelectDialog = new sap.m.SelectDialog({

			title: t,

			items: {

				path: p,

				template: new sap.m.StandardListItem({

					title: a,

					active: true

				})

			},

			search: function(e) {

				var v = e.getParameter("value");

				var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);

				e.getSource().getBinding("items").filter([F])

			},

			confirm: h,

			cancel: h

		});

		this._valueHelpSelectDialog.setModel(this.getView().getModel("AccountAssignment"));

		this._valueHelpSelectDialog.open()

	},

	onNavigateBack: function() {

		window.history.back()

	},

	createHeaderFooterOptions: function() {

		var t = this;

		return {

			sFullscreenTitle: t.oBundle.getText("ORDER_TITLE"),

			onBack: jQuery.proxy(function(e) {

				t.oRouter.navTo("shoppingCartItems", {

					tempCartId: t.tempCartId

				}, true);

				t.getView().byId("noteToApprover").setValue("")

			}),

			oEditBtn: {

				sI18nBtnTxt: "SUBMIT_CART",

				onBtnPressed: jQuery.proxy(t.onSubmit, t)

			},

			buttonList: [{

				sI18nBtnTxt: "CANCEL",

				onBtnPressed: jQuery.proxy(t.onCancel, t)

			}],

			oAddBookmarkSettings: {

				title: t.oBundle.getText("ORDER_TITLE"),

				icon: "sap-icon://cart"

			}

		}

	},

	onRequestFailed: function(e) {

		this.busyDialog.close();

		jQuery.sap.require("sap.ca.ui.message.message");

		sap.ca.ui.message.showMessageBox({

			type: sap.ca.ui.message.Type.ERROR,

			message: e.message,

			details: e.response.body

		})

	},

	getCountryStatus: function() {

		for (var i = 0; i < this.oCountryModel.oData.results.length; i++) {

			if (this.getView().byId("input_assisted1").getValue() === this.oCountryModel.oData.results[i].CountryName) {

				return true

			}

		}

		return false

	},

	/*	getDeliveryDate: function() {







		







			if (this.getView().byId("dateplusseven").getValue() !== "") {







				return true







			}







		







		return false







	},*/

	getBrandValue: function() {

		if (this.getView().byId("idBrandSelect").getSelectedItem().getText() !== "") {

			return true

		}

		return false

	},

	getStreetStatus: function() {

		if (this.getView().byId("street").getValue() !== "") {

			return true

		}

		return false

	},

	getCityStatus: function() {

		if (this.getView().byId("city").getValue() !== "") {

			return true

		}

		return false

	},

	getStateStatus: function() {

		if (this.getView().byId("state").getValue() !== "") {

			return true

		}

		return false

	},

	getPinStatus: function() {

		if (this.getView().byId("zip").getValue() !== "") {

			return true

		}

		return false

	},

	getMobileStatus: function() {

		if (this.getView().byId("mobile").getValue() !== "") {

			return true

		}

		return false

	},

	getApproverNoteStatus: function() {

		if (this.getView().byId("noteToApprover").getValue() !== "") {

			return true

		}

		return false

	},

	getMobLength: function() {

		var mobVal = this.getView().byId("mobile").getValue();

		if (mobVal.length !== 10) {

			return false;

		}

		return true;

	},

	getMobValid: function() {

		var phone_regExp = /^[0-9]+$/;

		if (!this.getView().byId("mobile").getValue().match(phone_regExp)) {

			return false;

		}

		return true;

	},

	getPinValid: function() {

		var zip_regExp = /^[0-9]+$/;

		if (!this.getView().byId("zip").getValue().match(zip_regExp)) {

			return false;

		}

		return true;

	},

	getpinCodeLength: function() {

		var zip = this.getView().byId("zip").getValue();

		if (zip.length !== 6) {

			return false;

		}

		return true;

	},

	/*checkDeliveryDate : function(){







	    var devDate = this.getView().byId("dateplusseven").getDateValue();







	    console.log(devDate);















	  var currDate = new Date();







	  console.log(currDate);







      var eDate = new Date(devDate);







      if (eDate.getTime() <= currDate.getTime()){







        return false;







      }







	    return true;







	},*/

	onStateValueHelpRequest: function(e) {

		var t = this;

		var a = this.oBundle.getText("SELECT_STATE");

		var p = "/results";

		var b = "{StateTxt}";

		var d = "{State}";

		var f = "StateTxt";

		var m = "stateList";

		var c = this.getView().byId("state");

		var h = function(e) {

			var s = e.getParameter("selectedItem");

			if (s) {

				c.setValue(s.getTitle());

				t.State = s.getDescription()

			}

			e.getSource().getBinding("items").filter([])

		};

		this._valueHelpSelectDialog = new sap.m.SelectDialog({

			title: a,

			items: {

				path: p,

				template: new sap.m.StandardListItem({

					title: b,

					active: true

				})

			},

			search: function(e) {

				var v = e.getParameter("value");

				var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);

				e.getSource().getBinding("items").filter([F])

			},

			confirm: h,

			cancel: h

		});

		this._valueHelpSelectDialog.setModel(this.getView().getModel(m));

		this._valueHelpSelectDialog.open()

	},

	onAfterRendering: function() {},

	onExit: function() {},

	onBeforeRendering: function() {}

});