jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");



jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");



jQuery.sap.require("sap.m.MessageBox");



sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.ZSRM_SC_CRE.view.ShoppingCartItemsCustom", {



	onInit: function() {



		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);



		this.oBundle = this.oApplicationFacade.getResourceBundle();



		this.busyDialog = new sap.m.BusyDialog({



			customIcon: sap.ca.ui.images.images.Flower



		});



		this.oRouter.attachRouteMatched(function(e) {



			if (e.getParameter("name") === "shoppingCartItems") {



				var t = this;



				this.Temp_Cart_Id = e.getParameter("arguments").tempCartId;



				this.busyDialog.open();



				jQuery.proxy(this.getShoppingCartItemDetails(), t)



			}



		}, this);



		this.setHeaderFooterOptions(this.createHeaderFooterOptions())



	},



	getShoppingCartItemDetails: function() {



		var o = function(D, r) {



			var m = new sap.ui.model.json.JSONModel(D);



			this.getView().setModel(m, "ShoppingCartHeader");



			var i = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(m.oData.ITM_COUNT);



			this.getView().byId("MaterialList").setHeaderText(i)



		};



		var a = function(D, r) {



			var m = new sap.ui.model.json.JSONModel(D);



			this.originalModel = m.oData.results;



			if (m.oData.results.length > 0) {



				this.setBtnEnabled("checkoutBtn", true);



				//	this.setBtnEnabled("updateBtn", true)



			} else {



				this.setBtnEnabled("checkoutBtn", false);



				//this.setBtnEnabled("updateBtn", false)



			}



			for (var i = 0; i < m.oData.results.length; i++) {



				m.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(m.oData.results[i].QUANTITY) * parseFloat(m.oData.results[i].PRICE).toString()).toFixed(



					2)



			}



			this.getView().setModel(m, "ShoppingCartItems");



			this.busyDialog.close()



		};



		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);



		var path = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')?ts=" + Date.now();



		dModel.read(path, null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this));



		var Path = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();



		dModel.read(Path, null, null, false, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this))



		var oldItems = function(D, r) {



			var m = new sap.ui.model.json.JSONModel(D);



			this.originalOldModel = m.oData.results;



			this.getView().setModel(m, "ShoppingCartItemsOld");



			this.busyDialog.close()



		};



		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");



		d.setHeaders({



			"Cache-Control": "no-cache, no-store, must-revalidate",



			"Pragma": "no-cache",



			"Expires": "-1"



		});



		var P = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();



		d.read(P, null, null, false, jQuery.proxy(oldItems, this), jQuery.proxy(this.onRequestFailed, this))



	},



	onQuantityChanged: function(e) {



		var v = e.getParameters().newValue;



		var c = Math.floor(v);



		if (c < 1) {



			c = 1



		}



		if (c != v) {



			e.getSource().setValue(c)



		}



		var i = e.getParameter("id");



		var a = parseInt(i.substring(i.lastIndexOf("-") + 1), 10);



		if (!this.quantities) {



			this.quantities = []



		}



		this.quantities[a] = c;



		if (this.quantities) {



			this.setBtnEnabled("checkoutBtn", false)



		}



	},



	removeItem: function(e) {



		var l = e.getSource();



		var b = l.getBindingContext("ShoppingCartItems");



		var m = b.getModel();



		var p = b.getPath();



		var i = m.getProperty(p);



		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");



		d.remove("ShoppingcartItemCollection(ITEM_NO='" + i.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", null, jQuery.proxy(this.getShoppingCartItemDetails,



			this), jQuery.proxy(this.onRequestFailed, this));



	var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);



		dModel.remove("ShoppingcartItemCollection(ITEM_NO='" + i.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", null, jQuery.proxy(

			this.getShoppingCartItemDetails,



			this), jQuery.proxy(this.onRequestFailed, this));



	/*	var price = i.PRICE;



		var docCode = i.Doccode;



		var docCodes = docCode.split(',');



		var availableLimit;



		var availablelimits = [];



		var updateLimit = function(D, r) {



			var a = new sap.ui.model.json.JSONModel(D);



			availableLimit = a.oData.AvailableLimit;



			var creditedAmt = parseFloat(availableLimit) + parseFloat(price);



			if (creditedAmt > 15000) {



				creditedAmt = 15000;



			}



			creditedAmt = parseFloat(creditedAmt).toString();



			if (creditedAmt.indexOf(".") === -1) {



				creditedAmt = creditedAmt + ".00";



			}



			availablelimits.push(creditedAmt);



		};



		for (var k = 0; k < docCodes.length; k++) {



			var path = "DocAvailLimitSet(Doccode='" + docCodes[k] + "')";



			dModel.read(path, null, null, false, jQuery.proxy(updateLimit, this), jQuery.proxy(this.onRequestFailed, this))



		}



		var B = new Array();



		for (var j = 0; j < docCodes.length; j++) {



			var h = {};



			h.Doccode = docCodes[j];



			h.AvailableLimit = "" + availablelimits[j];



			B.push(dModel.createBatchOperation("DocAvailLimitSet", "POST", h))



		}



		dModel.addBatchChangeOperations(B);



		dModel.submitBatch(dModel, jQuery.proxy(this.onRequestFailed, this))



		this.busyDialog.close()

*/

	},



	_cloneItemData: function(s) {



		return {



			'ITEM_NO': s.ITEM_NO,



			'TEMP_CART_ID': s.TEMP_CART_ID,



			'DESCRIPTION': s.DESCRIPTION,



			'QUANTITY': s.QUANTITY,



			'UNIT': s.UNIT,



			'PRICE': s.PRICE.toString(),



			'CURRENCY': s.CURRENCY,



			'PRODUCTKEY': s.PRODUCTKEY,



		}



	},



	onUpdateCart: function(e) {



		var m = this.originalModel;



		if (this.quantities) {



			this.busyDialog.open();



			var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");



			var b = new Array();



			for (var i = 0; i < this.quantities.length; i++) {



				if (this.quantities[i] && parseInt(m[i].QUANTITY, 10) != this.quantities[i]) {



					var a = this._cloneItemData(m[i]);



					a.QUANTITY = this.quantities[i].toString();



					var p = "ShoppingcartItemCollection(ITEM_NO=\'" + a.ITEM_NO + "\',TEMP_CART_ID=\'" + this.Temp_Cart_Id + "\')?ts=" + Date.now();



					b.push(d.createBatchOperation(p, "PUT", a))



				}



			}



			if (b.length === 0) {



				this.quantity = null;



				this.busyDialog.close();



				this.setBtnEnabled("checkoutBtn", this.getView().getModel("ShoppingCartItems").getData().results.length > 0);



				return



			}



			d.addBatchChangeOperations(b);



			var o = function(r) {



				this.quantities = null;



				this.getShoppingCartItemDetails();



				this.setBtnEnabled("checkoutBtn", true);



				var c = r && r.__batchResponses ? r.__batchResponses : [];



				for (var i = 0; i < c.length; i++) {



					if (c[0] && c[0].response && c[0].response.statusCode == "400") {



						this.onRequestFailed(c[0]);



						return



					}



				}



				jQuery.sap.require("sap.m.MessageToast");



				sap.m.MessageToast.show("Updated Successfully");



				this.busyDialog.close()



			};



			d.submitBatch(jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))



		} else {



			this.busyDialog.close();



			this.setBtnEnabled("checkoutBtn", this.getView().getModel("ShoppingCartItems").getData().results.length > 0)



		}



	},



	onCheckoutCart: function() {



		this.oRouter.navTo("shoppingCartCheckout", {



			tempCartId: this.Temp_Cart_Id,



		}, true);



		var t = this.getView().getModel("ShoppingCartHeader").oData.TOTAL_VALUE + " " + this.getView().getModel("ShoppingCartHeader").oData.WAERS;



		var c = sap.ui.core.Component.getOwnerIdFor(this.oView);



		var C = sap.ui.component(c);



		C.oEventBus.publish("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", {



			totalValue: t



		})



	},



	createHeaderFooterOptions: function() {



		var t = this;



		return {



			sFullscreenTitle: t.oBundle.getText("CART_TITLE"),



			onBack: jQuery.proxy(function(e) {



				t.oRouter.navTo("noData", {



					viewTitle: "DETAIL_TITLE",



					languageKey: "NO_ITEMS_AVAILABLE"



				}, true)



			}),



			/*	buttonList: [{















				sId: "updateBtn",















				sI18nBtnTxt: "UPDATE_BUTTON",















				onBtnPressed: jQuery.proxy(t.onUpdateCart, t)















			}],*/



			oEditBtn: {



				sId: "checkoutBtn",



				sI18nBtnTxt: "CHECKOUT_BUTTON",



				onBtnPressed: jQuery.proxy(t.onCheckoutCart, t)



			},



			oAddBookmarkSettings: {



				title: t.oBundle.getText("CART_TITLE"),



				icon: "sap-icon://cart"



			}



		}



	},



	onRequestFailed: function(e) {



		this.busyDialog.close();



		jQuery.sap.require("sap.ca.ui.message.message");



		sap.ca.ui.message.showMessageBox({



			type: sap.ca.ui.message.Type.ERROR,



			message: e.message,



			details: e.response.body



		})



	},



	onAfterRendering: function() {},



	onExit: function() {},



	onBeforeRendering: function() {}



});