jQuery.sap.declare("ui.s2p.srm.sc.create.ZSRM_SC_CRE.Configuration");

jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");

jQuery.sap.require("sap.m.MessageToast");

jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

jQuery.sap.require("ui.s2p.srm.sc.create.ZSRM_SC_CRE.util.Formatter");

sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.create.ZSRM_SC_CRE.view.S3Custom", {

	onInit: function() {

		var oUser = sap.ushell.Container.getUser();

		this.user = oUser.getId();

		this.userId = this.user.split('P');

		//this.userId = "00001172";

		var dModel = new sap.ui.model.json.JSONModel();

		var oContext = this.getView().getBindingContext();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZBOOKUSER_SRV/", true, "", "");

	    var path = "GetReporteesSet?$filter=UserName eq '" + this.user + "'";

		   //var path = "GetReporteesSet?$filter=UserName eq 'P00012185'";

		//var path = "DocDetailsSet?$filter=PSRID eq '00001172'";P00012185

		oDataModel.read(path, oContext, [], false, function(data) {

			dModel.setData(data);

			dModel.setSizeLimit(data.results.length);

		}, function(err) {

			console.log("inside failure");

		});

		this.getView().setModel(dModel, "PSRModel");

		console.log(dModel);

		var that = this;

		this.doctorVal = [];

		this.doctorCodes = [];

		this.unnatiIds = [];

		this._docKeys = "";

		this._docNames = "";

		this._unnatiCodes = "";

		this.splKeys = [];

		this._splKCodes = "";

		that._ITEM_NO = "";

		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);

		this.oBundle = this.oApplicationFacade.getResourceBundle();

		this.busyDialog = new sap.m.BusyDialog({

			customIcon: sap.ca.ui.images.images.Flower

		});

		this.oRouter.attachRouteMatched(function(e) {

			if (e.getParameter("name") === "detail") {

				this.Temp_Cart_Id = e.getParameter("arguments").tempCartId;

				this.busyDialog.open();

				this.getTempCartQuantity()

			}

		}, this);

		var c = sap.ui.core.Component.getOwnerIdFor(this.getView());

		var C = sap.ui.component(c);

		C.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshDetail", this.getData, this)

	},

	getData: function(c, e, d) {

		this.productKey = d.data.productkey;

		this.description = d.data.description;

		d.data.cartValue = 1;

		this.selectedItemModel = new sap.ui.model.json.JSONModel(d.data);

		this.getView().setModel(this.selectedItemModel, "itemDetail");

		sap.ui.getCore().setModel(this.selectedItemModel, "itemDetail");

		this.getView().byId("idComboBox").setSelectedItems([]);

		this.getView().byId("idPSR").setValue("");

		var h = this.getHeaderFooterOptions();

		this.setHeaderFooterOptions(h);

		if (sap.ui.getCore().byId("cartValue")) sap.ui.getCore().byId("cartValue").setText(this.cartValue)

	},

	getTempCartQuantity: function() {

		var o = function(D, r) {

			this.cartValue = 0;

			var t = this.Temp_Cart_Id.trim();

			for (var i = 0; i < D.results.length; i++) {

				var e = D.results[i].TEMP_CART_ID.trim();

				if (t === e) {

					this.cartValue = parseInt(this.cartValue, 10) + 1

				}

			}

			if (sap.ui.getCore().byId("cartValue")) sap.ui.getCore().byId("cartValue").setText(this.cartValue);

			this.busyDialog.close()

		};

		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		d.setHeaders({

			"Cache-Control": "no-cache, no-store, must-revalidate",

			"Pragma": "no-cache",

			"Expires": "-1"

		});

		var p = "ShoppingcartItemCollection?ts=" + Date.now();

		d.read(p, null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))

	},

	gotoCartItem: function() {

		this.oRouter.navTo("shoppingCartItems", {

			tempCartId: this.Temp_Cart_Id

		}, true)

	},

	getHeaderFooterOptions: function() {

		var t = this;

		return {

			oHeaderBtnSettings: {

				sId: "cartValue",

				sIcon: 'sap-icon://cart-full',

				onBtnPressed: function() {

					t.gotoCartItem()

				}

			},

			oEditBtn: {

				sId: "addToCartBtn",

				sI18nBtnTxt: "ADD_TO_CART_DETAIL",

				type: "Accept",

				onBtnPressed: function() {

					t.onAddToCart()

				}

			},

			oJamOptions: {

				oDiscussSettings: {

					object: {

						id: this.oApplicationFacade.getODataModel().sServiceUrl + "CATALOG_ITEM('" + this.productKey + "')",

						type: this.oApplicationFacade.getODataModel().sServiceUrl + "$metadata#CATALOG_ITEM",

						name: this.description

					}

				}

			},

			bSuppressBookmarkButton: true

		}

	},

	onAddToCart: function() {

		this.busyDialog.open();

		this.doctorVal = [];

		this.doctorCodes = [];

		this._docKeys = "";

		this._docNames = "";

		this.unnatiIds = [];

		this._unnatiCodes = "";

		this.splKeys = [];

		this._splKCodes = "";

		this.busyDialog.open();

		var selectedItems = this.getView().byId("idComboBox").getSelectedItems();

		for (var i = 0; i < selectedItems.length; i++) {

			this._docKeys += selectedItems[i].getKey();

			var docValues = selectedItems[i].getText();

			docValues = docValues.split(":");

			this._docNames += docValues[0];

			this._unnatiCodes += docValues[2];

			this._splKCodes += docValues[1];

			this.doctorVal.push(this._docNames);

			this.unnatiIds.push(this._unnatiCodes);

			this.splKeys.push(this._splKCodes);

			this.doctorCodes.push(this._docKeys);

			if (i !== selectedItems.length - 1) {

				this._docKeys += ",";

				this._docNames += ",";

				this._unnatiCodes += ",";

				this._splKCodes += ",";

			}

		}

		if (this.doctorVal.length > 0) {

			var resultDocCheck, valid, ackResult;

			var cart = new sap.ui.model.json.JSONModel();

			var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

			var path = "BookDetailsSet/$count?$filter=CreatedBy eq '" + this.userId + "'";

			//var path = "BookDetailsSet/$count?$filter=CreatedBy eq 'p00001172'";

			dModel.read(path, null, null, false, function(responseBody, sucRes) {

				var successResObj = JSON.parse(sucRes.body);

				cart = successResObj;

			});

			ackResult = this.checkAcknowlegedCart(cart);

			if (ackResult) {

				var docList = function(D, r) {

					var a = new sap.ui.model.json.JSONModel(D);

					//valid = this.budgetValidation(a);

					resultDocCheck = this.checkDuplicateDoctors(a);

				};

				var dModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

				var path1 = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();

				dModel1.read(path1, null, null, false, jQuery.proxy(docList, this), jQuery.proxy(this.onRequestFailed, this))

				//if (valid.length === 0) {

				if (!resultDocCheck) {

					var o = function(D, r) {

						var a = new sap.ui.model.json.JSONModel(D);

						jQuery.proxy(this.addToCartItemDetails(a), this);

						this.getTempCartQuantity();

					};

					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");

					var p = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();

					d.read(p, null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))

					var oExt = function(D, r) {

						var a = new sap.ui.model.json.JSONModel(D);

						jQuery.proxy(this.addToCartItemExtDetails(a), this);

						this.getTempCartQuantity();

					};

					var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

					var path = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();

					dModel.read(path, null, null, false, jQuery.proxy(oExt, this), jQuery.proxy(this.onRequestFailed, this))

				} else {

					sap.m.MessageBox.alert("Book is already added to the Doctor");

					//To Clear Dropdown list of doctors

					this.getView().byId("idComboBox").setSelectedItems([]);

					this.getView().byId("idPSR").setValue("");

					this.busyDialog.close();

				}

				/*} else {



					sap.m.MessageBox.alert(valid);



					this.busyDialog.close();



				}*/

			} else {

				sap.m.MessageBox.alert("Cannot Create Book Cart...Please Acknowledge the Carts which are Pending...")

				this.busyDialog.close();

			}

		} else {

			sap.m.MessageBox.alert("Please select Doctor");

			this.busyDialog.close();

		}

	},

	budgetValidation: function(t) {

		var docCode = this._docKeys.split(",");

		var docNames = this._docNames.split(",");

		var docName;

		var result = "";

		var availableLimit;

		var availablelimits = [];

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		var budgetCheck = function(D, r) {

			result = "";

			var a = new sap.ui.model.json.JSONModel(D);

			availableLimit = a.oData.AvailableLimit;

			var item_price = this.selectedItemModel.oData.itm_price;

			/*if (parseFloat(availableLimit) < parseFloat(item_price)) {















				result = "";//result += "For Doctor " + docName + " Available Limit is " + availableLimit + "\n";















			} else {*/

			var deductedAmt = parseFloat(availableLimit) - parseFloat(item_price);

			deductedAmt = parseFloat(deductedAmt).toString();

			if (deductedAmt.indexOf(".") === -1) {

				deductedAmt = deductedAmt + ".00";

			}

			availablelimits.push(parseFloat(deductedAmt));

			//}

		};

		for (var d = 0; d < docCode.length; d++) {

			var path = "DocAvailLimitSet(Doccode='" + docCode[d] + "')";

			docName = docNames[d];

			dModel.read(path, null, null, false, jQuery.proxy(budgetCheck, this), jQuery.proxy(this.onRequestFailed, this))

		}

		if (result.length === 0) {

			var B = new Array();

			for (var i = 0; i < docCode.length; i++) {

				var h = {};

				h.Doccode = docCode[i];

				h.AvailableLimit = "" + availablelimits[i];

				B.push(dModel.createBatchOperation("DocAvailLimitSet", "POST", h))

			}

			dModel.addBatchChangeOperations(B);

			dModel.submitBatch(dModel, jQuery.proxy(this.onRequestFailed, this))

			this.busyDialog.close();

		}

		return result;

	},

	checkAcknowlegedCart: function(cartOrdered) {

		var result = true;

		var acknowledged = "";

		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		var path = "BookDetailsSet/$count?$filter=AcknowledgeFlag eq 'X' and CreatedBy eq '" + this.user + "'";

		//var path = "BookDetailsSet/$count?$filter=AcknowledgeFlag eq 'X' and CreatedBy eq 'p00001172'";

		dModel.read(path, null, null, false, function(responseBody, sucRes) {

			var successResObj = JSON.parse(sucRes.body);

			acknowledged = successResObj;

		});

		var checkCount = parseInt(cartOrdered) - parseInt(acknowledged);

		if (checkCount >= 5) {

			return false;

		}

		return result;

	},

	_cloneItemData: function(s) {

		return {

			'ITEM_NO': s.ITEM_NO,

			'TEMP_CART_ID': s.TEMP_CART_ID,

			'DESCRIPTION': s.DESCRIPTION,

			'QUANTITY': s.QUANTITY,

			'UNIT': s.UNIT,

			'PRICE': s.PRICE,

			'CURRENCY': s.CURRENCY,

			'PRODUCTKEY': s.PRODUCTKEY,

		}

	},

	_cloneItemExtData: function(s) {

		return {

			'ITEM_NO': s.ITEM_NO,

			'TEMP_CART_ID': s.TEMP_CART_ID,

			'DESCRIPTION': s.DESCRIPTION,

			'QUANTITY': s.QUANTITY,

			'UNIT': s.UNIT,

			'PRICE': s.PRICE,

			'CURRENCY': s.CURRENCY,

			'PRODUCTKEY': s.PRODUCTKEY,

			'Doccode': s.Doccode,

			'Docname': s.Docname,

			'UnnatiID': s.UnnatiID,

			'SpecialityKey': s.SpecialityKey

		}

	},

	_createItemData: function(t, s) {

		var i = {

			'ITEM_NO': '',

			'TEMP_CART_ID': '',

			'DESCRIPTION': '',

			'QUANTITY': '',

			'UNIT': 'EA',

			'PRICE': '',

			'CURRENCY': '',

			'PRODUCTKEY': '',

		};

		i.TEMP_CART_ID = t;

		i.DESCRIPTION = s.description;

		i.CURRENCY = s.itm_currency;

		i.UNIT = s.unit;

		i.PRICE = s.itm_price;

		return i

	},

	_createItemExtData: function(t, s) {

		var i = {

			'ITEM_NO': '',

			'TEMP_CART_ID': '',

			'DESCRIPTION': '',

			'QUANTITY': '',

			'UNIT': 'EA',

			'PRICE': '',

			'CURRENCY': '',

			'PRODUCTKEY': '',

			'Doccode': '',

			'Docname': '',

			'UnnatiID': '',

			'SpecialityKey': ''

		};

		i.ITEM_NO = this._ITEM_NO;

		i.TEMP_CART_ID = t;

		i.DESCRIPTION = s.description;

		i.CURRENCY = s.itm_currency;

		i.UNIT = s.unit;

		i.PRICE = s.itm_price;

		i.Doccode = this._docKeys;

		i.Docname = this._docNames;

		i.UnnatiID = this._unnatiCodes;

		i.SpecialityKey = this._splKCodes;

		return i

	},

	checkDuplicateDoctors: function(t) {

		var s = new sap.ui.model.json.JSONModel();

		s = null;

		var result;

		if (this.selectedItemModel != null) {

			var a = this.selectedItemModel.oData.productkey.trim();

			for (var i = 0; i < t.oData.results.length; i++) {

				var e = t.oData.results[i].PRODUCTKEY.trim();

				if (e === a | e === jQuery.sap.encodeURL(a)) {

					s = t.oData.results[i];

					break

				}

			}

			if (s != null) {

				var docList = s.Doccode;

				var listNames = docList.split(",");

				for (var j = 0; j < listNames.length; j++) {

					result = this.doctorCodes.indexOf(listNames[j]);

					if (result !== -1)

					{

						result = true;

					} else

					{

						result = false;

					}

					if (result) {

						break;

					}

				}

			}

		}

		return result;

	},

	addToCartItemDetails: function(t) {

		var s = new sap.ui.model.json.JSONModel();

		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		s = null;

		if (this.selectedItemModel != null) {

			var a = this.selectedItemModel.oData.productkey.trim();

			for (var i = 0; i < t.oData.results.length; i++) {

				var e = t.oData.results[i].PRODUCTKEY.trim();

				if (e === a | e === jQuery.sap.encodeURL(a)) {

					s = t.oData.results[i];

					break

				}

			}

			var b = this._createItemData(this.Temp_Cart_Id, this.selectedItemModel.oData);

			if (s != null) {

				b = this._cloneItemData(s);

				b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);

				b.UNIT = this.selectedItemModel.oData.unit_cu;

				b.QUANTITY = (parseInt(b.QUANTITY, 10) + this.doctorVal.length).toString();

				a = b.PRICE;

				b.PRICE = a.split(".")[0] + "." + a.split(".")[1].slice(0, 2);

				this.updateTriggered = true;

				d.update("ShoppingcartItemCollection(ITEM_NO='" + b.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", b, null,

					null, jQuery.proxy(this.onRequestFailed, this))

			} else {

				b.UNIT = this.selectedItemModel.oData.unit_cu;

				b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);

				b.PRODUCTKEY = jQuery.sap.encodeURL(this.selectedItemModel.oData.productkey);

				b.QUANTITY = (this.selectedItemModel.oData.minorderqty ? this.selectedItemModel.oData.minorderqty : 1) + "";

				b.QUANTITY = b.QUANTITY * this.doctorVal.length + "";

				a = b.PRICE;

				b.PRICE = a.split(".")[0] + "." + a.split(".")[1].slice(0, 2);

				this.updateTriggered = false;

				var that = this;

				d.create("ShoppingcartItemCollection", b, null, function(responseBody, sucRes) {

					var successResObj = JSON.parse(sucRes.body);

					that._ITEM_NO = successResObj.d.ITEM_NO;

				}, jQuery.proxy(this.onRequestFailed, this))

			}

		}

	},

	addToCartItemExtDetails: function(t) {

		var s = new sap.ui.model.json.JSONModel();

		var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		s = null;

		if (this.selectedItemModel != null) {

			var a = this.selectedItemModel.oData.productkey.trim();

			for (var i = 0; i < t.oData.results.length; i++) {

				var e = t.oData.results[i].PRODUCTKEY.trim();

				if (e === a | e === jQuery.sap.encodeURL(a)) {

					s = t.oData.results[i];

					break

				}

			}

			var b = this._createItemExtData(this.Temp_Cart_Id, this.selectedItemModel.oData);

			if (s != null) {

				b = this._cloneItemExtData(s, this._messageText);

				b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);

				b.UNIT = this.selectedItemModel.oData.unit_cu;

				b.QUANTITY = (parseInt(b.QUANTITY, 10) + this.doctorVal.length).toString();

				a = b.PRICE;

				b.PRICE = a.split(".")[0] + "." + a.split(".")[1].slice(0, 2);

				b.Doccode = b.Doccode + "," + this._docKeys;

				b.Docname = b.Docname + "," + this._docNames;

				b.UnnatiID = b.UnnatiID + "," + this._unnatiCodes;

				b.SpecialityKey = b.SpecialityKey + "," + this._splKCodes;

				this.updateTriggered = true;

				d.update("ShoppingcartItemCollection(ITEM_NO='" + b.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", b, null,

					jQuery.proxy(this.onItemAdded, this), jQuery.proxy(this.onRequestFailed, this))

			} else {

				var that = this;

				b.ITEM_NO = that._ITEM_NO;

				b.UNIT = this.selectedItemModel.oData.unit_cu;

				b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);

				b.PRODUCTKEY = this.selectedItemModel.oData.productkey;

				b.QUANTITY = (this.selectedItemModel.oData.minorderqty ? this.selectedItemModel.oData.minorderqty : 1) + "";

				b.QUANTITY = b.QUANTITY * this.doctorVal.length + "";

				a = b.PRICE;

				b.PRICE = a.split(".")[0] + "." + a.split(".")[1].slice(0, 2);

				b.Doccode = b.Doccode;

				b.Docname = b.Docname;

				b.UnnatiID = b.UnnatiID;

				b.SpecialityKey = b.SpecialityKey;

				this.updateTriggered = false;

				d.create("ShoppingcartItemCollection", b, null, jQuery.proxy(this.onItemAdded, this), jQuery.proxy(this.onRequestFailed, this))

			}

		}

	},

	onRequestFailed: function(e) {

		this.busyDialog.close();

		jQuery.sap.require("sap.ca.ui.message.message");

		sap.ca.ui.message.showMessageBox({

			type: sap.ca.ui.message.Type.ERROR,

			message: e.message,

			details: e.response.body

		})

	},

	onItemAdded: function(e) {

		var c = sap.ui.getCore().byId("cartValue").getText();

		if (!this.updateTriggered) {

			c = parseInt(c, 10) + 1;

			sap.ui.getCore().byId("cartValue").setText(c)

		}

		//To Clear Dropdown list of doctors

		this.getView().byId("idComboBox").setSelectedItems([]);

		this.getView().byId("idPSR").setValue("");

		sap.m.MessageToast.show(this.oBundle.getText("ADD_CART_SUCCESS"));

		this.busyDialog.close()

	},

	navToEmptyView: function() {

		this.oRouter.navTo("noData", null, true)

	},

	onAfterRendering: function() {},

	onExit: function() {},

	onBeforeRendering: function() {},

	handleSelectionChange: function(oEvent) {

		var changedItem = oEvent.getParameter("changedItem");

		var isSelected = oEvent.getParameter("selected");

		var state = "Selected";

		if (!isSelected) {

			state = "Deselected"

		}

	},

	selectPSR: function(oEvent) {

		var selectedId = this.getView().byId("idPSR").getSelectedKey();

		var dModel = new sap.ui.model.json.JSONModel();

		var oContext = this.getView().getBindingContext();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_DOC_SRV/", true, "", "");

		var path = "DocDetailsSet?$filter=PSRID eq '" + selectedId + "'";

		//var path = "DocDetailsSet?$filter=PSRID eq '00001172'";

		oDataModel.read(path, oContext, [], false, function(data) {

			dModel.setData(data);

			dModel.setSizeLimit(data.results.length);

		}, function(err) {

			console.log("inside failure");

		});

		this.getView().setModel(dModel, "doctorsModel");

	},

	handleImagePress: function(evt) {

		var url = evt.oSource.mProperties.src;

		window.open(url, "_blank");

	}

});