sap.ui.define([
		'jquery.sap.global',
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"map/zgeolocation/model/models"
], function (jQuery,UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("map.zgeolocation.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		
		 jQuery.sap.includeScript({
             // url: "https://maps.googleapis.com/maps/api/js?key=AIzaSyDhAilRWEiDKUwxjBwCos2ob5DV3BNr3XQ&libraries=places&region=In",
           url: "https://maps.googleapis.com/maps/api/js?key=AIzaSyDhAilRWEiDKUwxjBwCos2ob5DV3BNr3XQ&libraries=places",
                promisify: true
            });
		
         /*		jQuery.sap.includeScript({
                          url: "https://maps.googleapis.com/maps/api/js?key=AIzaSyDhAilRWEiDKUwxjBwCos2ob5DV3BNr3XQ&callback=initMap",
                promisify: true
            });*/
           
		}
	});
});