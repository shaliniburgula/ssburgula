 sap.ui.define([
	'jquery.sap.global',
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",

	"sap/m/MessageBox"
], function (jQuery, Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("map.zgeolocation.controller.View1", {
	
		 onInit : function () {
	sap.ui.getCore().getEventBus().subscribe("myNamespace", "myFunctionName", this.myFunction, this);
	
		 },
		 myFunctionName:function () {
		  var a =  this.getView().byId("map");
		   	 var id = a.sId;
		 var bh =  	id + '-inner';
		 	   
		 	   
var map, infoWindow;
  

	//map = new google.maps.Map(this.getView().byId('map'), {
	map = new google.maps.Map(document.getElementById(id),{
          center: {lat: 17.425169399999998, lng: 78.39840079999999},
          zoom: 6
        });
       // infoWindow = new google.maps.InfoWindow;
        var infoWindow = new google.maps.InfoWindow({map: map});

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };

            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found.');
            infoWindow.open(map);
            map.setCenter(pos);
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
      

      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
      }
	
       

		 	   

	
		 },
		 
		 
		 
		 
		 onAddressTyped3:function (oEvent) {
		 			var placeSearch, autocomplete;

			var componentForm = {
				street_number: 'short_name',
				route: 'long_name',
				locality: 'long_name',
				administrative_area_level_1: 'short_name',
				country: 'long_name',
				postal_code: 'short_name'
			};

			var sdf = this.getView().byId("pac-input-1");
			var gh = sdf.sId;
			var bh = gh + '-inner';
			
			autocomplete = new google.maps.places.Autocomplete(
				/** @type {!HTMLInputElement} */
				(document.getElementById(bh)), {
					types: ['geocode']
				});

			// When the user selects an address from the dropdown, populate the address
			// fields in the form.
			autocomplete.addListener('place_changed', fillInAddress);

			function fillInAddress() {
				// Get the place details from the autocomplete object.
				var places = autocomplete.getPlace();
			
					for (var component in componentForm) {
					//  document.getElementById(component).value = '';
					//document.getElementById(component).disabled = false;
				}

				// Get each component of the address from the place details
				// and fill the corresponding field on the form.
				for (var i = 0; i < place.address_components.length; i++) {
					var addressType = place.address_components[i].types[0];
					if (componentForm[addressType]) {
						var val = place.address_components[i][componentForm[addressType]];
						// document.getElementById(addressType).value = val;
					}
				}
			}

			function geolocate() {
				if (navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(function (position) {
						var geolocation = {
							lat: position.coords.latitude,
							lng: position.coords.longitude
						};
						var circle = new google.maps.Circle({
							center: geolocation,
							radius: position.coords.accuracy
						});
						autocomplete.setBounds(circle.getBounds());
					});
				}
			}
		 	
		 	
		 },
		 
		 		onAddressTyped2: function (oEvent) {

			var placeSearch, autocomplete;

			var componentForm = {
				street_number: 'short_name',
				route: 'long_name',
				locality: 'long_name',
				administrative_area_level_1: 'short_name',
				country: 'long_name',
				postal_code: 'short_name'
			};

			var sdf = this.getView().byId("pac-input");
			var gh = sdf.sId;
			var bh = gh + '-inner';
				var a =  this.getView().byId("map");
		   	 var id = a.sId;

			// Create the autocomplete object, restricting the search to geographical
			// location types.
			autocomplete = new google.maps.places.Autocomplete(
				/** @type {!HTMLInputElement} */
				(document.getElementById(bh)), {
					types: ['geocode']
				});

			// When the user selects an address from the dropdown, populate the address
			// fields in the form.
			autocomplete.addListener('place_changed', fillInAddress);

			function fillInAddress() {
				// Get the place details from the autocomplete object.
				var places = autocomplete.getPlace();
				if(places!== "") {


				

		var latlng = new google.maps.LatLng(21.7679, 78.8718);
map = new google.maps.Map(document.getElementById(id), {
  center: latlng,
  zoom: 13,
  mapTypeId: 'roadmap'
});
			 var markers = [];
          // Clear out the old markers.
          markers.forEach(function(marker) {
            marker.setMap(null);
          });
          markers = [];
var place = {};
			
          // For each place, get the icon, name and location.
          var bounds = new google.maps.LatLngBounds();
         
            var icon = {
              url: places.icon,
              size: new google.maps.Size(71, 71),
              origin: new google.maps.Point(0, 0),
              anchor: new google.maps.Point(17, 34),
              scaledSize: new google.maps.Size(25, 25)
            };

            // Create a marker for each place.
            markers.push(new google.maps.Marker({
              map: map,
              icon: icon,
              title: places.name,
              position: places.geometry.location
            }));
             if (places.geometry.viewport) {
              // Only geocodes have viewport.
              bounds.union(places.geometry.viewport);
            } else {
              bounds.extend(places.geometry.location);
            }
				
          map.fitBounds(bounds);
			
        


	}			for (var component in componentForm) {
					//  document.getElementById(component).value = '';
					//document.getElementById(component).disabled = false;
				}

				// Get each component of the address from the place details
				// and fill the corresponding field on the form.
				for (var i = 0; i < place.address_components.length; i++) {
					var addressType = place.address_components[i].types[0];
					if (componentForm[addressType]) {
						var val = place.address_components[i][componentForm[addressType]];
						// document.getElementById(addressType).value = val;
					}
				}
			}

			function geolocate() {
				if (navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(function (position) {
						var geolocation = {
							lat: position.coords.latitude,
							lng: position.coords.longitude
						};
						var circle = new google.maps.Circle({
							center: geolocation,
							radius: position.coords.accuracy
						});
						autocomplete.setBounds(circle.getBounds());
					});
				}
			}

		},
			
			
	liveChangeTo: function (evnt) {
		//var  origin = this.getView().byId("pac-input").getValue();
		
		var a = evnt.getSource().sId;
			var inp = a.replace("_xmlview0--","");
			
			if(inp == "_pac-input"){
			var origin = this.getView().byId("pac-input").getValue();
			}else if(inp == "_pac-input-1"){
			var origin = this.getView().byId("pac-input-1").getValue();	
			}

			var request = {
				origin: origin,
				
				travelMode: google.maps.TravelMode.DRIVING

			};
				var service = new google.maps.DistanceMatrixService();
			service.getDistanceMatrix({
				origins: [origin],
			
				travelMode: google.maps.TravelMode.DRIVING,
				unitSystem: google.maps.UnitSystem.METRIC,
				avoidHighways: false,
				avoidTolls: false
			}, function callback(response, status) {
				if (status != google.maps.DistanceMatrixStatus.OK) {
					alert('Error was: ' + status);
				} else {
					var origins = response.originAddresses;
				//	var destinations = response.destinationAddresses;
				}
				var directionsService = new google.maps.DirectionsService;
				var directionsDisplay = new google.maps.DirectionsRenderer();
				var latlng = new google.maps.LatLng(17.3660, 78.4760);
				var myOptions = {
					zoom: 7,
					center: latlng,
					mapTypeId: google.maps.MapTypeId.DRIVING,
					mapTypeControlOptions: {
						style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
						position: google.maps.ControlPosition.TOP_RIGHT
					},
				};
				var map = new google.maps.Map($('#map_canvas').get(0), myOptions);
				map.setTilt(90);
				directionsDisplay.setMap(map);
				var marker = new google.maps.Marker({
					position: Center,
					animation: google.maps.Animation.BOUNCE,
				});
				marker.setMap(map);
				directionsService.route(request, function (response, status) {
					if (status == google.maps.DirectionsStatus.OK) {
						directionsDisplay.setDirections(response);
					}
				});
			});

	},		
			


		onpress: function (oEven) {
		var sdf = this.getView().byId("pac-input");
			var gh = sdf.sId;
			var bh = gh + '-inner';
				var sdf1 = this.getView().byId("pac-input-1");
			var gh1 = sdf1.sId;
			var bh1 = gh1 + '-inner';
	   var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        	var a =  this.getView().byId("map");
		   	 var id = a.sId;
		   	 	var latlng = new google.maps.LatLng(21.7679, 78.8718);
map = new google.maps.Map(document.getElementById(id), {
  center: latlng,
  zoom: 15
  
 
});
 directionsDisplay.setMap(map);


          calculateAndDisplayRoute(directionsService, directionsDisplay);
  
        // document.getElementById('bh').addEventListener('change', onChangeHandler);
      //  document.getElementById('bh1').addEventListener('change', onChangeHandler);
      

	  function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        directionsService.route({
          origin: document.getElementById(bh).value,
          destination: document.getElementById(bh1).value,
          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
            directionsDisplay.setDirections(response);
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
		}
	
	
		},
	
   
    
    
	});
});