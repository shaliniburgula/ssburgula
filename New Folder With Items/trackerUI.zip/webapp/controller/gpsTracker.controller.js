var geocoder = new google.maps.Geocoder();
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("caltex.com.au.trackerUI.controller.gpsTracker", {
		onInit: function () {},
		getPosition: function () {
			var options = {
				enableHighAccuracy: true,
				maximumAge: 3600000
			};
			var watchID = navigator.geolocation.getCurrentPosition(onSuccess, onError, options);

			function onSuccess(position) {
				/*MessageBox.alert('Latitude: ' + position.coords.latitude + '\n' +
					'Longitude: ' + position.coords.longitude + '\n' +
					'Altitude: ' + position.coords.altitude + '\n' +
					'Accuracy: ' + position.coords.accuracy + '\n' +
					'Altitude Accuracy: ' + position.coords.altitudeAccuracy + '\n' +
					'Heading: ' + position.coords.heading + '\n' +
					'Speed: ' + position.coords.speed + '\n' +
					'Timestamp: ' + position.timestamp + '\n');*/
				var Latitude = position.coords.latitude;
				var Longitude = position.coords.longitude;

				// this.getMap(Latitude, Longitude);
				var mapOptions = {
					center: new google.maps.LatLng(Latitude, Longitude),
					zoom: 1,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};

				var map = new google.maps.Map(document.getElementById("container-trackerUI---gpsTracker--map_canvas"), mapOptions);

				var latLong = new google.maps.LatLng(Latitude, Longitude);

				var marker = new google.maps.Marker({
					position: latLong
				});
				var that = this;
				marker.setMap(map);
				map.setZoom(15);
				map.setCenter(marker.getPosition());
				geocoder.geocode({
						latLng: latLong
					},
					function (responses) {
						if (responses && responses.length > 0) {
							var formatedAddress = responses[0].formatted_address;
							//console.log(document.getElementById("__xmlview0--idAddress"));
							sap.m.MessageToast.show("You are at : " + formatedAddress);
						} else {
							sap.m.MessageToast.show('Not getting Any address for given latitude and longitude.');
						}
					});
			}

			function onError(error) {
				MessageBox.alert('code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
			}
		},

		watchPosition: function () {
			var options = {
				maximumAge: 3600000,
				timeout: 3000,
				enableHighAccuracy: true,
			}
			var watchID = navigator.geolocation.watchPosition(onSuccess, onError, options);

			function onSuccess(position) {
			
				/*		var payload = {
				  "stimestamp": "",
				  "sdate":"",
				  "lat":"",
				  "lon":""
			};
			if (this._oViewModel.getProperty("/mode") === "edit") {
				var jurl = "/sales_dest/xsjs/allocationDeepSales.xsjs?cmd=updateAlloc";
			} else {
				var jurl = "/sales_dest/xsjs/allocationDeepSales.xsjs?cmd=createAlloc";
			}

			jQuery.ajax({
				url: jurl,
				async: false,
				data: {
					dataobject: JSON.stringify(payload)
				},
				method: 'POST',
				dataType: 'text',
				success: function (data) {
					this.getView().getModel().refresh(true);
					//MessageBox.show(data, MessageBox.Icon.SUCCESS, "Created....");
					if (this._oViewModel.getProperty("/mode") === "edit") {
						this.getModel("appView").setProperty("/busy", false);
						this.getView().unbindObject();
						MessageBox.show(
							"Sales request  has successfully updated", {
								icon: MessageBox.Icon.SUCCESS,
								title: "updated...!",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === "OK") {
										this.getRouter().getTargets().display("object");
									}
								}.bind(this)
							}
						);

					} else {
						var sObjectPath = this.getModel().createKey("Zc_allocsales", {
							assigmentno: this.getView().byId("f1").getValue()
						});
						this.getModel("appView").setProperty("/itemToSelect", "/" + sObjectPath); //save last created
						this.getModel("appView").setProperty("/busy", false);
						MessageBox.show(
							"New Sales request has successfully created", {
								icon: MessageBox.Icon.SUCCESS,
								title: "Created...!",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === "OK") {
										this.getRouter().getTargets().display("object");
									}
								}.bind(this)
							}
						);

					}
				}.bind(this),
				error: function () {
					MessageBox.show("Some error occured , please check the data or Internet connectivity", MessageBox.Icon.ERROR,
						"oops error ccured.!");
				}
			});*/
				var Latitude = position.coords.latitude;
				var Longitude = position.coords.longitude;

				// this.getMap(Latitude, Longitude);
				var mapOptions = {
					center: new google.maps.LatLng(Latitude, Longitude),
					zoom: 1,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};

				var map = new google.maps.Map(document.getElementById("container-trackerUI---gpsTracker--map_canvas"), mapOptions);

				var latLong = new google.maps.LatLng(Latitude, Longitude);

				var marker = new google.maps.Marker({
					position: latLong
				});
				var that = this;
				marker.setMap(map);
				map.setZoom(15);
				map.setCenter(marker.getPosition());
				geocoder.geocode({
						latLng: latLong
					},
					function (responses) {
						if (responses && responses.length > 0) {
							var formatedAddress = responses[0].formatted_address;
							//console.log(document.getElementById("__xmlview0--idAddress"));
							sap.m.MessageToast.show("You are at : " + formatedAddress);
						} else {
							sap.m.MessageToast.show('Not getting Any address for given latitude and longitude.');
						}
					});
			
					
			}

			function onError(error) {
				MessageBox.alert('code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
			}
		}
	});
});