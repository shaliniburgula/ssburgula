sap.ui.define([
	"caltex/com/au/trackerUI/test/unit/controller/gpsTracker.controller"
], function () {
	"use strict";
});