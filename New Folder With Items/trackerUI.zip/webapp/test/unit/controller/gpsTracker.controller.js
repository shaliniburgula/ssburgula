/*global QUnit*/

sap.ui.define([
	"caltex/com/au/trackerUI/controller/gpsTracker.controller"
], function (Controller) {
	"use strict";

	QUnit.module("gpsTracker Controller");

	QUnit.test("I should test the gpsTracker controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});