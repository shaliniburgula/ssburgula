sap.ui.define(['sap/uxap/BlockBase'],
	function(BlockBase) {
	"use strict";

	var BlockAdresses = BlockBase.extend("sap.uxap.sample.ObjectPageOnJSON.block.personal.BlockAdresses", {
	    metadata: {
	    }
	});


	return BlockAdresses;

});
