sap.ui.define(['sap/uxap/BlockBase'],
	function(BlockBase) {
	"use strict";

	var BlockMailing = BlockBase.extend("sap.uxap.sample.ObjectPageOnJSON.block.personal.BlockMailing", {
	    metadata: {
	    }
	});


	return BlockMailing;

});
