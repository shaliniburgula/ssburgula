sap.ui.define(['sap/uxap/BlockBase'],
	function(BlockBase) {
	"use strict";

	var BlockSocial = BlockBase.extend("sap.uxap.sample.ObjectPageOnJSON.block.personal.BlockSocial", {
	    metadata: {
	    }
	});


	return BlockSocial;

});
