sap.ui.define(function() {
	"use strict";

	var Component = sap.ui.core.UIComponent.extend("sap.uxap.sample.ObjectPageOnJSON.Component", {

	    metadata : {
	        rootView : "sap.uxap.sample.ObjectPageOnJSON.ObjectPageOnJSON",
	        dependencies : {
	            libs : [
	                "sap.m"
	            ]
	        },
	        config : {
	            sample : {
	                stretch : true,
	                files : [
	                    "ObjectPageOnJSON.view.xml",
	                    "ObjectPageOnJSON.controller.js",
	                    "block/employment/BlockEmpDetailPart1.js",
	                    "block/employment/BlockEmpDetailPart1.view.xml",
	                    "block/employment/BlockEmpDetailPart2.js",
	                    "block/employment/BlockEmpDetailPart2.view.xml",
	                    "block/employment/BlockEmpDetailPart3.js",
	                    "block/employment/BlockEmpDetailPart3.view.xml",
	                    "block/employment/BlockJobInfoPart1.js",
	                    "block/employment/BlockJobInfoPart1.view.xml",
	                    "block/employment/BlockJobInfoPart2.js",
	                    "block/employment/BlockJobInfoPart2.view.xml",
	                    "block/employment/BlockJobInfoPart3.js",
	                    "block/employment/BlockJobInfoPart3.view.xml",
	                    "block/employment/EmploymentBlockJob.js",
	                    "block/employment/EmploymentBlockJobCollapsed.view.xml",
	                    "block/employment/EmploymentBlockJobExpanded.view.xml",
	                    "block/goals/GoalsBlock.js",
	                    "block/goals/GoalsBlock.view.xml",
	                    "block/personal/BlockAdresses.js",
	                    "block/personal/BlockAdresses.view.xml",
	                    "block/personal/BlockMailing.js",
	                    "block/personal/BlockMailing.view.xml",
	                    "block/personal/BlockPhoneNumber.js",
	                    "block/personal/BlockPhoneNumber.view.xml",
	                    "block/personal/BlockSocial.js",
	                    "block/personal/BlockSocial.view.xml",
	                    "block/personal/PersonalBlockPart1.js",
	                    "block/personal/PersonalBlockPart1.view.xml",
	                    "block/personal/PersonalBlockPart2.js",
	                    "block/personal/PersonalBlockPart2.view.xml"
	                ]
	            }
	        }
	    }
	});

	return Component;

});