sap.ui.define(['sap/m/SplitContainer'],
	function(SplitContainer) {
	"use strict";

	sap.ui.controller("sap.uxap.sample.ObjectPageOnJSON.ObjectPageOnJSON", {

	    onInit: function () {

	     /*   //by default we always show the master
	        if (sap.ui.Device.system.desktop) {
	            this._oSplitContainer = sap.ui.getCore().byId("splitApp");
	            if (this._oSplitContainer) {
	                this._oSplitContainer.backToPage = jQuery.proxy(function () {

	                    this.setMode("ShowHideMode");
	                    this.showMaster();

	                    SplitContainer.prototype.backToPage.apply(this, arguments);

	                }, this._oSplitContainer);
	            }

	        }


	        var oJsonModel = new sap.ui.model.json.JSONModel("./test-resources/sap/uxap/demokit/sample/ObjectPageOnJSONWithLazyLoading/HRData.json");

	        this.getView().setModel(oJsonModel, "ObjectPageModel");
*/
	    },

	    onBeforeRendering: function () {

	       /* if (sap.ui.Device.system.desktop && this._oSplitContainer) {
	            this._oSplitContainer.setMode("HideMode");
	            this._oSplitContainer.hideMaster();
	        }*/
	    },
	    handleLink1Press: function (oEvent) {
			var msg = 'Page 1 a very long link clicked',
				msgToast = sap.m.MessageToast; 
			msgToast.show(msg);
		},
		handleLink2Press: function (oEvent) {
			var msg = 'Page 2 long link clicked',
				msgToast = sap.m.MessageToast; 
			msgToast.show(msg);
		}
	});


}, /* bExport= */ true);