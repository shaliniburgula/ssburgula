sap.ui.controller("SimpleUI.ext.controller.ListReportExt", {

	//Creation 
	onClickActionZc_allocsales1: function (oEvent) {

		this._oCreateAllocDialog = sap.ui.xmlfragment("SimpleUI.ext.fragments.createAllocation", this);

		this.getView().addDependent(this._oCreateAllocDialog);

		var oModel = new sap.ui.model.json.JSONModel({

			assigmentno: "",
			assgNoPlaceholder: "Enter the Allocation ID",

			rdes: "",
			regionPlaceholder: "Enter the region name",

			fromdate: "",
			fromDatePlaceholder: "Enter the from date",

			todate: "",
			toDatePlaceholder: "Enter the to date",

			slstrgt: "",
			slstrgtPlaceholder: "Enter the Sales target",

			cstmrtrgt: "",
			cstmrtrgtPlaceholder: "Enter the Estimated target",

			statusText: "",
			stText: "Enter the Status Text",

			allctdexpns: "",
			allctedPlaceholder: " Enter the allocted Expenses",

			userid: "",
			userIdPlaceholder: " Enter the user ID",

			assignedby: "",
			assignedPlaceholder: "Enter the assigned by",

			SalesTargetAch: "",
			SalesTargetAchPlaceholder: "Enter the Sales Target Achieved",
			doneButtonActive: true

		});

		this._oCreateAllocDialog.setModel(oModel);
		console.log(oModel);
		this._oCreateAllocDialog.open();

	},
	onCreateAllocation: function (oEvent) {
		var oModel = oEvent.getSource().getModel();
		var assgStatus = "";
		if (oModel.oData.statusText === "Assigned") {
			assgStatus = "01";
		} else if (oModel.oData.statusText === "Assigned") {
			assgStatus = "02";
		} else {
			assgStatus = "03";
		}

		var fromDate = new Date(oModel.oData.fromdate);
		var fromDateMS = "" + "/Date(" + fromDate.getTime() + ")/";
		var toDate = new Date(oModel.oData.todate);
		var toDateMS = "" + "/Date(" + toDate.getTime() + ")/";
		var payload = {

			"Accept_ac": "",
			"Reject_ac": "",
			"assigmentno": oModel.oData.assigmentno,
			"slstrgt": oModel.oData.slstrgt,
			"curr": "INR",
			"Assgstatus": assgStatus,
			"statusText": oModel.oData.statusText,
			"SalesTargetAch": oModel.oData.SalesTargetAch,
			"allctdexpns": oModel.oData.allctdexpns,
			"remarks": "",
			"actiontime": oModel.oData.fromdate,
			"userid": oModel.oData.userid,
			"eassgn_timestamp": oModel.oData.fromdate,
			"fromdate": oModel.oData.fromdate,
			"assignedby": oModel.oData.assignedby,
			"regkey": "",
			"rdes": oModel.oData.rdes,
			"todate": oModel.oData.todate,
			"cstmrtrgt": oModel.oData.cstmrtrgt

		};
		var datavalue = JSON.stringify(payload);
		console.log(fromDateMS);
		//alert(datavalue);

		var jurl = "/xsjs/allocationSales.xsjs?cmd=createAlloc";
		var that = this;
		jQuery.ajax({

			url: jurl,
			async: false,
			data: {
				dataobject: datavalue
			},
			method: 'POST',
			dataType: 'text',
			success: function (data) {
				that._oCreateAllocDialog.close();
				new sap.m.MessageBox.confirm(data);
			}
		});

		this.getView().getModel().refresh();
	},
	onCancelCreation: function () {
		this._oCreateAllocDialog.close();
	},
	//Update
	onClickActionZc_allocsales2: function (oEvent) {

		var assignmentNo = oEvent.getSource().getParent().getParent().getTable().getSelectedItem().getBindingContext().getProperty(
			"assigmentno");
		var oModel = oEvent.getSource().getModel();
		var payload = {
			"assigmentno": assignmentNo
		};
		var datavalue = JSON.stringify(payload);

		var jurl = "/xsjs/allocationSales.xsjs?cmd=readAlloc";
		var that = this;
		jQuery.ajax({

			url: jurl,
			async: false,
			data: {
				dataobject: datavalue
			},
			method: 'GET',
			dataType: 'text',
			success: function (data) {

				var modelData = JSON.parse(data);
				that.onUpdateOpenAllocation(modelData);
			}
		});
	},

	onUpdateOpenAllocation: function (data) {

		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData(data);

		this.getView().setModel(oModel, "updateModel");
		sap.ui.getCore().setModel(oModel, "updateModel");
		if (!this._oUpdateAllocDialog) {
			this._oUpdateAllocDialog = sap.ui.xmlfragment("SimpleUI.ext.fragments.updateAllocation", this);
			this.getView().addDependent(this._oUpdateAllocDialog);
		}

		this._oUpdateAllocDialog.open();
	},

	onCancelUpdation: function () {
		this._oUpdateAllocDialog.close();
	},
	
	onUpdateAllocation: function(oEvent){
		var oModel = oEvent.getSource().getModel("updateModel");
		var assgStatus = "";
		if (oModel.oData.statusText === "Assigned") {
			assgStatus = "01";
		} else if (oModel.oData.statusText === "Assigned") {
			assgStatus = "02";
		} else {
			assgStatus = "03";
		}
		var payload = {

			"Accept_ac": "",
			"Reject_ac": "",
			"assigmentno": oModel.oData.assigmentno,
			"slstrgt": oModel.oData.slstrgt,
			"curr": "INR",
			"Assgstatus": assgStatus,
			"statusText": oModel.oData.StatusText,
			"SalesTargetAch": oModel.oData.SalesTargetAch,
			"allctdexpns": oModel.oData.allctdexpns,
			"remarks": "",
			"actiontime": oModel.oData.fromdate,
			"userid": oModel.oData.userid,
			"eassgn_timestamp": oModel.oData.fromdate,
			"fromdate": oModel.oData.fromdate,
			"assignedby": oModel.oData.assignedby,
			"regkey": "",
			"rdes": oModel.oData.rdes,
			"todate": oModel.oData.todate,
			"cstmrtrgt": oModel.oData.cstmrtrgt

		};
		var datavalue = JSON.stringify(payload);
             var jurl="/xsjs/allocationSales.xsjs?cmd=updateAlloc";
      var that = this;
           jQuery.ajax({
      
      url: jurl,
              async :false,
              TYPE: 'POST' ,
              data:{dataobject:datavalue},
              method: 'GET',
              dataType: 'text',
              success: function(data) {
              	that._oUpdateAllocDialog.close();
				new sap.m.MessageBox.confirm(data);
              }
            });
          this.getView().getModel().refresh();
	},
	//deletion
	onClickActionZc_allocsales3: function (oEvent) {
		
			var assignmentNo = oEvent.getSource().getParent().getParent().getTable().getSelectedItem().getBindingContext().getProperty(
			"assigmentno");
		var oModel = oEvent.getSource().getModel();
		var payload = {
			"assigmentno": assignmentNo
		};
		var datavalue = JSON.stringify(payload);

		var jurl = "/xsjs/allocationSales.xsjs?cmd=deleteAlloc";
		var that = this;
	var that = this;
           jQuery.ajax({
      
      url: jurl,
              async :false,
              TYPE: 'POST' ,
              data:{dataobject:datavalue},
              method: 'GET',
              dataType: 'text',
              success: function(data) {
				new sap.m.MessageBox.confirm(data);
              }
            });
          this.getView().getModel().refresh();
	}
});