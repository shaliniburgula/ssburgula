jQuery.sap.declare("ZEMPLOYEE_WORK_ALLOC.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("ZEMPLOYEE_WORK_ALLOC.Component", {
	metadata: {
		"manifest": "json"
	}
});