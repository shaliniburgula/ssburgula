sap.ui.controller("ZEMPLOYEE_WORK_ALLOC.ext.controller.ListReportExt", {
	onAfterRendering: function(){
	sap.ui.getCore().byId("ZEMPLOYEE_WORK_ALLOC::sap.suite.ui.generic.template.ListReport.view.ListReport::Zc_allocsales--listReport").setUseExportToExcel(true);
	
	}

});