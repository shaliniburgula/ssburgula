/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.Component");
jQuery.sap.require("ui.s2p.srm.sc.create.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
sap.ca.scfld.md.ComponentBase.extend("ui.s2p.srm.sc.create.Component", {
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name": "Master Detail Sample",
		"version": "1.0.0",
		"library": "ui.s2p.srm.sc.create",
		"includes": ["css/shoppingcart.css"],
		"dependencies": {
			"libs": ["sap.m", "sap.me"],
			"components": []
		},
		"config": {
			"titleResource": "DISPLAY_NAME_CREATE",
			"resourceBundle": "i18n/i18n.properties",
			"icon": "sap-icon://Fiori2/F0407",
			"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/My_Shopping_Cart.ico",
			"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/57_iPhone_Desktop_Launch.png",
			"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/114_iPhone-Retina_Web_Clip.png",
			"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/72_iPad_Desktop_Launch.png",
			"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/144_iPad_Retina_Web_Clip.png"
		},
		"masterPageRoutes": {
			"master": {
				"pattern": "",
				"view": "ui.s2p.srm.sc.create.view.S2"
			}
		},
		"detailPageRoutes": {
			"detail": {
				"pattern": "detail/{tempCartId}/{contextPath}",
				"view": "ui.s2p.srm.sc.create.view.S3"
			},
			"noData": {
				"pattern": "noData/{viewTitle}/{languageKey}",
				"view": "empty"
			}
		},
		"fullScreenPageRoutes": {
			"shoppingCartItems": {
				"pattern": "shoppingCartItems/{tempCartId}",
				"view": "ui.s2p.srm.sc.create.view.ShoppingCartItems"
			},
			"shoppingCartCheckout": {
				"pattern": "shoppingCartCheckout/{tempCartId}",
				"view": "ui.s2p.srm.sc.create.view.ShoppingCartCheckout"
			}
		}
	}),
	createContent: function() {
		var v = {
				component: this
			},
			V = sap.ui.view({
				viewName: "ui.s2p.srm.sc.create.Main",
				type: sap.ui.core.mvc.ViewType.XML,
				viewData: v
			}),
			p = V.getId() + "--",
			e = sap.ui.getCore().getEventBus();
		this.oEventBus = {
			publish: function(c, a, d) {
				c = p + c;
				e.publish(c, a, d)
			},
			subscribe: function(c, a, d, l) {
				c = p + c;
				e.subscribe(c, a, d, l)
			},
			unsubscribe: function(c, a, d, l) {
				c = p + c;
				e.unsubscribe(c, a, d, l)
			}
		};
		return V
	}
});