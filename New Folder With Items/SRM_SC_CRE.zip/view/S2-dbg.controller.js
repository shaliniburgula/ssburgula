/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.create.view.S2", {

	onInit : function() {
		// execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		
		//get resource bundle
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		
		this.isRoot=true;
		
		this.oRouter.attachRouteMatched(function(oEvent) { 
			
			if( oEvent.getParameter("name") === "master" && !this.isRoot && 
				Object.keys(oEvent.getParameter("arguments")).length === 0){
				
				var sDir = sap.ui.core.routing.History.getInstance().getDirection("shoppingCartCheckout/"+this.tempCartId);				
				if(sDir === "Unknown"){
					//we are navigating from the checkout page to the master page. 
					//in this case, we want to restore the initial state of the application
					this.isRoot = true;
					
					//FIXME: workaround to clear the search field
					this._oControlStore.oMasterSearchField.clear();
				}
				else{
					//If from any other page, set the master and detail page accordingly
					if(this.getList() !== null){
						var oItem = this.getList().getSelectedItem();
						if(oItem !== null){
							this.setListItem(oItem);
						}
					}
				}				
			}
			this.isRoot = (this.isRoot) ? false : this.isRoot;			
		}, this);
		
		this.setEmptyCart(true);
	},

	/**
	 * @private [Gets the default settings of the user]
	 */
	getDefaultUserSettings : function(bRoute){
		var onRequestSuccess = function(oData, oResponse) {
			this.tempCartId = oData.results[0].TEMP_CART_ID;
			if(!jQuery.device.is.phone){
				//FIXME: When the screen is first loaded, the method navToEmptyView 
				//does not get the title correctly. For solving this issue, we added
				//an explicit route to noData. In all other cases, the normal
				//navToEmptyView returns correct results.
				if(bRoute){
					this.oRouter.navTo("noData",{
						viewTitle: "DETAIL_TITLE",
						languageKey: "NO_ITEMS_AVAILABLE"
					},true);
				}
				else{
					this.navToEmptyView();
				}
			}
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("getdefusrset");
		oDataModel.read("DefaultUserSettings?ts="+ Date.now(), null,null, true,
				jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},

	/**
	 * @override
	 *
	 * @param oItem
	 * @param sFilterPattern
	 * @returns {*}
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {

		if (sFilterPattern.substring(0, 1) === "#") {
			var sTail = sFilterPattern.substr(1);
			var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
			return sDescr.indexOf(sTail) === 0;
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem,sFilterPattern);
		}

	},

	/**
	 * @public [getHeaderFooterOptions Define header & footer options]
	 */
	getHeaderFooterOptions : function() {
		var oOptions = {
			sI18NMasterTitle : "MASTER_TITLE",
			buttonList: []	
		};
		return oOptions;
	},

	isBackendSearch: function(){
		return true;
	},
	
	/**
	 * @public [Back-end search - filter the results based on user input]
	 * @param  {[type]} sFilterPattern - search pattern entered in the search field
	 * @param  {[type]} oBinding
	 */
	applyBackendSearchPattern: function(sFilterPattern, oBinding){
		if(sFilterPattern != "" && sFilterPattern != null){
			this.startReadListData(sFilterPattern);
		}else{
			this.setEmptyCart(false);
		}
	},

	/**
	 * @private [Populate the master list depending upon the filter parameter passed]
	 * @param {[type]} filterItem - search pattern entered in the search field
	 */
	startReadListData: function(filterItem) {

		var onRequestSuccess = function(oData, oResponse) {
			var oModel2 = new sap.ui.model.json.JSONModel(oData.results);
			this.getView().setModel(oModel2);
			this.getList().destroyItems();
			this.getList().bindAggregation("items", {
				path : "/",
				template : this.oTemplate.clone(),
				filter : [],
				sorter : null,
			});
			this.registerMasterListBind(this.getList());
		};
		//Encoding the filter item for special characters
		var encodedfilterItem= encodeURIComponent(filterItem);

		var oDataModel = this.oApplicationFacade.getODataModel();
		oDataModel.read("CATALOG_ITEM?$filter=startswith(description,'"+encodedfilterItem+"')&$top=20", null , null, true,
				jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		
		
	},  

	/**
	 * @private [On selection of an item in the master list, sets the detail page accordingly]
	 * @param oItem - item selected in the master list
	 */
	//On selection of an item in the master list
	setListItem: function(oItem) {
		var bindingContext = oItem.getBindingContext();
		var modelData = bindingContext.oModel.oData[parseInt(bindingContext.sPath.split('/')[1])] ;
		
		this.oRouter.navTo("detail", {
			tempCartId : this.tempCartId,
			contextPath: bindingContext.getPath().substr(1)
		},true);
		
		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView);
        var oComponent   = sap.ui.component(sComponentId);	

        oComponent.oEventBus.publish("ui.s2p.srm.sc.create", "refreshDetail",{
			data:modelData
		});
	},

	/*
	 * In the initial screen, the list should be empty, hence we explicitly create
	 * an empty model here and bind it to the list. When a search is triggered via
	 * the search bar, the list is populated then from the search results. ]
	 */
	setEmptyCart: function(bRoute){
		//empty JSON model
		var oEmptyModel = new sap.ui.model.json.JSONModel({
			results: []
		});
		
		this.oRouter.navTo("noData",{
            viewTitle: "DETAIL_TITLE",
            languageKey: "NO_ITEMS_AVAILABLE"
          },true);


		this.getView().setModel(oEmptyModel);

		this.oTemplate = new sap.m.ObjectListItem({
			type : "{device>/listItemType}",
			title : "{description}",
			press : jQuery.proxy(this._handleItemPress,this),
			number : "{parts:[{path:'itm_price'},{path:'itm_currency'}],formatter:'ui.s2p.srm.sc.create.util.Formatter.formatPrice'}",
			numberUnit : "{itm_currency}",
			attributes : [ new sap.m.ObjectAttribute({
				text : "{vendormat}"
			}) ],
		});

		this.getList().bindAggregation("items", {
			path : "/results",
			template : this.oTemplate,
			filter : [],
			sorter : null,
		});
		this.registerMasterListBind(this.getList());
		
		//get default settings for the user
		this.getDefaultUserSettings(bRoute);		 		
	},
	
	onRequestFailed : function(oError) {
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: oError.message,
			details: oError.response.body
		});
	},
	
	
	onAfterRendering : function(){},
	onExit: function(){},
	onBeforeRendering : function(){}
	
	
});