/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.model.type.Number");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartCheckout",{

       onInit : function() {
              this.oBundle = this.oApplicationFacade.getResourceBundle();
              
              // Get instance of the busy dialog
      		  this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});
      		  
              this.oRouter.attachRouteMatched(function(oEvent) {
            	  if (oEvent.getParameter("name") === "shoppingCartCheckout") {
            		  this.tempCartId = oEvent.getParameter("arguments").tempCartId;
            		  
                  //start the busy dialog now
       			  this.busyDialog.open();
                  this.getUserPersonalizationsettings();
                  this.getTempCartItems();
            	  }
              }, this);              
              
              //Using the component ID we subscribe a call back for refreshing the data
              var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
              var oComponent   = sap.ui.component(sComponentId);
              
              oComponent.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", jQuery.proxy(this.getData,this),this);
              
              this.co_area = "";
              this.country_key = "";
              
              //To populate the country help dialog box + To give suggestion items for the input field for Country
              this.oCountryModel = this.createModel('Country', 'CountryCollection', null, "COUNTRY_SH_SERVICE");
              
              //To populate the account assignment help dialog box + To give suggestion items for the input field for Account Assignment
              //Hard coding used
              this.jsonModel = new sap.ui.model.json.JSONModel({
                                    results : [{accAssg : this.oBundle.getText("COST_CENTER")},
                                               {accAssg : this.oBundle.getText("INTERNAL_ORDER")} 
                                    		  ]});
              this.getView().setModel(this.jsonModel,"AccountAssignment");

              this.setHeaderFooterOptions(this.createHeaderFooterOptions());
              this.getView().byId("dateplusseven").setDisplayFormat(sap.m.getLocaleData().getDatePattern("medium"));
       },
       
       getData : function(sChannelId, sEventId, value) {
          var totalValue = value;
          this.getView().byId("totalValue").setValue(totalValue.totalValue);             
       },

       /**
        * @private [generic function for creating a model after oData read]
        * @param modelName - name to be assigned to the model created
        * @param sParam - service collection name
        * @param sFilter - filter parameter if any
        * @param sModel - corresponding to the service meta data mentioned in Configuration.js
        * @returns oModel if modelName of the model being created is 'Country'
        * @returns oModelName in all other cases
        */
       createModel : function(modelName, sParam, sFilter, sModel) {
    	   	
    	   	  var oModel;
              var onRequestSuccess = function(oData, oResponse) {
                     oModel = new sap.ui.model.json.JSONModel(oData);
                     oModel.setSizeLimit(500);
                     this.getView().setModel(oModel, modelName);
              };
              
              var oDataModel = this.oApplicationFacade.getODataModel(sModel);
              oDataModel.read(sParam, null, sFilter, false,jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
              if(modelName === "Country")
            	  return oModel;
              else
            	  return modelName;
       },

       /**
        * @private [Gets the personalization settings of the user]
        */
       getUserPersonalizationsettings : function() {
              var onRequestSuccess = function(oData, oResponse) {
                     this.oUserDefaults = new sap.ui.model.json.JSONModel(oData.results[0]);
                     this.getView().setModel(this.oUserDefaults,"personalCollection");
                     this.getView().byId("dateplusseven").setValue(this.sevenDaysFromNowDateAsString());
              };

              var oDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
              oDataModel.read("User_PersonalizationCollection?ts="+Date.now(),null, null, false, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Adds 7 days to the current date, for calculating the default delivery date]
        */
       sevenDaysFromNowDateAsString : function() {
              var date = new Date();
              date.setDate(date.getDate() + 7);
              var valueFormat = this.getView().byId('dateplusseven').getValueFormat();
              return sap.ca.ui.model.format.DateFormat.getDateInstance({
                     pattern : valueFormat
              }).format(date);
       },

       /**
        * @private [Gets the temporary cart details and binds it to the table displaying the items in the cart (Order Summary)]
        */
       getTempCartItems : function() {
              var onRequestSuccess = function(oData, oResponse) {
                     var TempCartModel = new sap.ui.model.json.JSONModel(oData);
                     for ( var i = 0; i < TempCartModel.oData.results.length; i++) {
                           TempCartModel.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(TempCartModel.oData.results[i].QUANTITY) * parseFloat(TempCartModel.oData.results[i].PRICE));
                     }

                     this.getView().byId("MaterialList").setModel(TempCartModel, "ShoppingCartItems");
                     var itemCount = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(TempCartModel.oData.results.length);
                     this.getView().byId("MaterialList").setHeaderText(itemCount);
                     //last place for all data to be fetched, stop the busy dialog now
         			 this.busyDialog.close();
              };

              var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
              this.getDefaultUserSettings();
              var tempcartId = this.getTempCartId();
              oDataModel.read("ShoppingcartCollection(TEMP_CART_ID='"+ tempcartId + "')/ShoppingCartItemNavigation?ts="+Date.now(),null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Discards the temporary cart on event of Cancel]
        */
       discardTempCart : function(tempCartId, objectId) {
    	   	  //start the busy dialog now
			  this.busyDialog.open();
              this.OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
              this.OShoppingCartDataModel.update(
                           "HOLD_DOCUMENT?TEMP_CART_ID='" + tempCartId
                           + "'&OBJECT_ID='" + objectId
                           + "'", null, {
                                  oContext : null,
                                  fnSuccess : jQuery.proxy(function(){this.busyDialog.close();},this),
                                  fnError : jQuery.proxy(this.onRequestFailed, this)
                           });
       },

       /**
        * @private [Gets the temporary cart id]
        */
       getTempCartId : function() {
              return this.oDefaultSettings.oData.results[0].TEMP_CART_ID;
       },

       /**
        * @private [Gets the default user settings] 
        */
       getDefaultUserSettings : function() {
              var onRequestSuccess = function(oData, oResponse) {
                     this.oDefaultSettings = new sap.ui.model.json.JSONModel(oData);
              };

              var oDataModel = this.oApplicationFacade.getODataModel("getdefusrset");
              oDataModel.read("DefaultUserSettings?ts="+Date.now(), null, null,
                           false, jQuery.proxy(onRequestSuccess, this),
                           jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Gets the object id of the cart]
        * @returns objectid
        */
       getCartObjectId : function() {
              return this.oDefaultSettings.oData.results[0].OBJECT_ID;
       },

       /**
        * @private [Cancel dialog box displayed.
        * On confirmation, discards the temporary cart otherwise remains in the checkout screen] 
        */
       onCancel : function() {
              var that = this;
              var cancelText = new sap.m.Text({
                     text : that.oBundle.getText("CANCEL_MESSAGE")
              });
              var cancelDialog = null;
              cancelDialog = new sap.m.Dialog({
                     content : [ cancelText ],
                     title : that.oBundle.getText("CANCEL_TITLE"),
                     leftButton : new sap.m.Button({
                           text : this.oBundle.getText("YES"),
                           press : function() {
                                  that.discardTempCart(that.getTempCartId(),that.getCartObjectId());
                                  cancelDialog.close();
                                  that.oRouter.navTo("master",null,true);
                                  that.getView().byId("noteToApprover").setValue("");
                           }
                     }),
                     rightButton : new sap.m.Button({
                           text : this.oBundle.getText("NO"),
                           press : function() {
                                  cancelDialog.close();
                           }
                     })
              }).addStyleClass("sapUiPopupWithPadding");

              cancelDialog.open();
       },

       /**
        * @private [Gets the items in the SRM Cart]
        * @param successCallback
        * @param cartObjectId
        * @param basync
        */
       getSRMCartItems : function(successCallback, cartObjectId,basync) {

              if (typeof (basync) === undefined) {
                     basync = true;
              }
              var onRequestSuccess = jQuery.proxy(function(oData,oResponse) {
                     if (successCallback) {
                           successCallback.call(oData, oResponse);
                     }
              }, this);

              var OSRMShoppingCartDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
              var sPath = "SRMShoppingCartCollection(OBJECT_ID='"+ cartObjectId+ "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartItemNavigation?ts="+Date.now();
              OSRMShoppingCartDataModel.read(sPath, null, null,basync, onRequestSuccess, jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Actual SRM Shopping Cart is saved with all the details]
        * @param successCallback
        * @param objectID
        * @param oDefaultSettings
        * @param approveNotes
        */
       saveSRMShoppingCart : function(successCallback, objectID,oDefaultSettings, approveNotes) {
              
    	     var oItem;
             var that=this;
             
             //Fetching the values required for oItem, which will later be send as payload for POST call to SRMShoppingCartCollection
             //and updating the values of those fields edited by the user 
             var onRequestSuccess1 = jQuery.proxy(function(oData,oResponse) {
                  oItem = oData;
                  oItem.CURRENCY = oDefaultSettings.oData.results[0].CURRENCY;
                  oItem.CITY = this.getView().byId("city").getValue();
                  oItem.COUNTRY = that.country_key;
                  oItem.STREET = this.getView().byId("street").getValue();
                  oItem.APRV_NOTE = approveNotes;

              }, this);
              var OSRMShoppingCartDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
              var sPath = "SRMShoppingCartCollection(OBJECT_ID='"+ objectID+ "',DOC_MODE='DISPLAY',WIID='000000000000')?ts="+Date.now();
              OSRMShoppingCartDataModel.read(sPath, null, null,false, onRequestSuccess1, jQuery.proxy(this.onRequestFailed, this));
            
              //In case the user has not used valueHelpRequest for Country, that.country_key would remain empty.
              //So comparing the value entered in the Country input field to that in the oCountryModel to get the corresponding country key
              for(var i=0;i<that.oCountryModel.oData.results.length;i++){
            	  if(this.getView().byId("input_assisted1").getValue() === that.oCountryModel.oData.results[i].CountryName){
            		  oItem.COUNTRY = that.oCountryModel.oData.results[i].CountryKey;
            		  that.country_key = that.oCountryModel.oData.results[i].CountryKey;
            	  }
              }
              
              //Extension hook for saving extMoreInfo2
              /**
               * @ControllerHook Extension hook for saving  
               * This hook can be used to save the fields through extensibility
               * @callback sap.ca.scfld.md.controller.BaseFullscreenController~extHook1
               * @return {void}  ...
              */
             // var extensionHook1 = this.onDataRecieved1;
              if(this.extHook1){
        			this.extHook1();
              };
              //Extension hook for saving extMoreInfo3
              /**
               * @ControllerHook Extension hook for saving  
               * This hook can be used to save the fields through extensibility
               * @callback sap.ca.scfld.md.controller.BaseFullscreenController~extHook2
               * @return {void}  ...
              */
        	  //var extensionHook2 = this.onDataRecieved2;
        	  if(this.extHook2){
        			this.extHook2();
        	  };
              
              //costAssignment is made fit to the format of the required pay load
              var costAssignment = {};
              costAssignment.ACC_NO = '0001';
              costAssignment.WIID = '000000000000';
              costAssignment.DISTR_PERC = '100.0';
              costAssignment.G_L_ACCT = this.oUserDefaults.oData.G_L_ACCT;
              
              if (this.co_area === "") {
                     this.co_area = this.oUserDefaults.oData.CO_AREA;
              }
              
              //If accountAssignment selected is CostCenter
              var costAssignmentField = this.getView().byId("input_assisted3").getValue().trim();
              var costCenter = this.oBundle.getText("COST_CENTER").trim();
              var internalOrder = this.oBundle.getText("INTERNAL_ORDER").trim();
              if (costAssignmentField === costCenter) {
                     costAssignment.COST_CTR = this.getView().byId("input_assisted2").getValue();
                     costAssignment.ACC_CAT = 'CC';
                     costAssignment.CO_AREA = that.co_area;
              }
              //If accountAssignment selected is InternalOrder
              else if (costAssignmentField === internalOrder) {
                     costAssignment.ORDER_NO = this.getView().byId("input_assisted2").getValue();
                     costAssignment.ACC_CAT = 'OR';
                     costAssignment.CO_AREA = that.co_area;
              } else if (costAssignmentField === "") {
                     costAssignment.CO_AREA = this.oUserDefaults.oData.CO_AREA;
              }

              //addressAssignment is made fit to the format of the required pay load
              var addressAssignment = {};
              addressAssignment.ShoppingCartID = objectID;
              addressAssignment.WIID = '000000000000';
              addressAssignment.City = this.getView().byId("city").getValue();
              addressAssignment.Name = this.oUserDefaults.oData.REQUESTOR_DESC;
              addressAssignment.CountryName = this.getView().byId("input_assisted1").getValue();
              addressAssignment.Country = that.country_key;
              addressAssignment.Street = this.getView().byId("street").getValue();
              addressAssignment.PostalCode1 = this.getView().byId("zip").getValue();
              
              var fnSuccessCallback = function() {
                     successCallback.call();
              };
              
              this.getSRMCartItems(jQuery.proxy(function(oData,oResponse) {
                  var OSRMShoppingCartDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
                  var aBatchArray = new Array();
                  for ( var i = 0; i < oData.data.results.length; i++) {
                	  oData.data.results[i].DELIV_DATE = this.getView().byId("dateplusseven").getDateValue() === null ? "": this.getView().byId("dateplusseven").getDateValue();
                      var dateUI = new Date();   
                      dateUI.setUTCMonth(oData.data.results[i].DELIV_DATE.getMonth());
                      dateUI.setUTCDate(oData.data.results[i].DELIV_DATE.getDate());
                      dateUI.setUTCFullYear(oData.data.results[i].DELIV_DATE.getFullYear());
                      dateUI.setUTCHours(00);
                      dateUI.setUTCMinutes(00);
                      dateUI.setUTCSeconds(00);
                      oData.data.results[i].DELIV_DATE = dateUI;
                      delete oData.data.results[i].__metadata;
                      delete oData.data.results[i].SourceofSupplyNavigation;
                      delete oData.data.results[i].ItemAccountAssignmentNavigation;
                      delete oData.data.results[i].ItemApproverNavigation;
                      delete oData.data.results[i].ItemAttachmentNavigation;
                      delete oData.data.results[i].ItemShippingAddressNavigation;
                      aBatchArray.push( OSRMShoppingCartDataModel.createBatchOperation(
                                                       "SRMShoppingCartItemCollection(NUMBER_INT='"
                                                       + oData.data.results[i].NUMBER_INT
                                                       + "',OBJECT_ID='"
                                                       + objectID
                                                       + "',DOC_MODE='',WIID='000000000000')",
                                                       "PUT",
                                                        oData.data.results[i]));
                      
                	  costAssignment.NUMBER_INT = oData.data.results[i].NUMBER_INT;
                              aBatchArray.push( OSRMShoppingCartDataModel.createBatchOperation(
                                                                "AccountAssignmentCollection(NUMBER_INT='"
                                                                + costAssignment.NUMBER_INT
                                                                + "',OBJECT_ID='"
                                                                + objectID
                                                                + "',ACC_NO='0001',DOC_MODE='',WIID='000000000000')",
                                                                "PUT",
                                                                costAssignment)
                                                                );
                        addressAssignment.ItemNumber = oData.data.results[i].NUMBER_INT;
                        aBatchArray.push( OSRMShoppingCartDataModel.createBatchOperation(
                                                                "ShippingAddressCollection(ItemNumber='"
                                                                + costAssignment.NUMBER_INT
                                                                + "',ShoppingCartID='"
                                                                + objectID
                                                                + "',DOC_MODE='',WIID='000000000000')",
                                                                "PUT",
                                                                addressAssignment) );
                        
                       }
                  // Header update of shopping cart is obselete because of which removing the header update
                  //Deleting extra meta data from oItem before sending it as payload
//                  delete oItem.__metadata;
//                  delete oItem.HeaderMessageNavigation;
//                  delete oItem.HeaderPersonalisedDataNavigation;
//                  delete oItem.ShoppingCartAddressnavigation;
//                  delete oItem.ShoppingCartApprovalNavigation;
//                  delete oItem.ShoppingCartItemBasicDataNavigation;
//                  delete oItem.ShoppingCartItemNavigation;
//                  delete oItem.ShoppingCartNotesNavigation;
//                  delete oItem.ShoppingCartReviewerNavigation;
//
//                  aBatchArray.push(OSRMShoppingCartDataModel.createBatchOperation(
//                                                     "SRMShoppingCartCollection",
//                                                     "POST",
//                                                     oItem) );
                OSRMShoppingCartDataModel.addBatchChangeOperations(aBatchArray);
                OSRMShoppingCartDataModel.submitBatch(fnSuccessCallback,jQuery.proxy(this.onRequestFailed,this));
                                    
                }, this), objectID);

       },

       /**
        * @private [Actual SRM Shopping Cart is created]
        * @param successCallback
        * @param tempCartId
        * @param objectID
        */
       saveTempCart : function(successCallback, tempCartId, objectID) {
              var itemData = {TEMP_CART_ID : this.getTempCartId(),
                              CHECKOUT : "X",
                              WAERS : this.oDefaultSettings.oData.results[0].CURRENCY};
              if (objectID !== null) {
                     itemData.OBJECT_ID = objectID;
              };

              var fnErrorCallback = function(oError) {
            	     //close the busy dialog first
       			     this.busyDialog.close();
                     jQuery.sap.require("sap.ca.ui.message.message");
                     sap.ca.ui.message.showMessageBox({
                           type : sap.ca.ui.message.Type.ERROR,
                           message : oError.message,
                           details : jQuery.parseJSON(oError.response.body).error.message.value
                     });
              };
              var fnSuccessCallback = jQuery.proxy(function(oData,oResponse) {
                     if (successCallback) {
                           successCallback.call(oData, oResponse);
                     }
              }, this);

              var approveNotes = this.getView().byId("noteToApprover").getValue();

              var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
              oDataModel.create(
                           "ShoppingcartCollection",itemData, null, jQuery.proxy(function(oData,oResponse) {
                                  this.saveSRMShoppingCart(fnSuccessCallback,oData.OBJECT_ID,this.oDefaultSettings,approveNotes);
                           }, this), jQuery.proxy(fnErrorCallback, this));

       },

       /**
        * @private [Submits the temporary cart]
        * @param successCallback
        * @param tempCartId
        * @param objectID
        */
       submitTempCart : function(successCallback, tempCartId,objectID) {
              var itemData = {
                           TEMP_CART_ID : tempCartId,
                           ORDER : "X"
              };

              var fnErrorCallback = function(oError) {
            	     //close the busy dialog first
       			     this.busyDialog.close();
	       			  var fnClose = function(){
	                      if(sap.ui.getCore().byId("SCNumber")){
	                      sap.ui.getCore().byId("SCNumber").destroy();
	                      }
	                   };
                     jQuery.sap.require("sap.ca.ui.message.message");
                     sap.ca.ui.message.showMessageBox({
                           type : sap.ca.ui.message.Type.ERROR,
                           message : oError.message,
                           details : jQuery.parseJSON(oError.response.body).error.message.value
                     }, fnClose);
              };
              var fnSuccessCallback = jQuery.proxy(function(oData, oResponse) {
            	  var OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
                  OShoppingCartDataModel.create("ShoppingcartCollection",itemData,null,
                		  		jQuery.proxy(function(oData,oResponse) {if (successCallback) {successCallback.call(oData,oResponse);}},this),
                		  		jQuery.proxy(fnErrorCallback,this));
                  }, this);

              this.saveTempCart(fnSuccessCallback, tempCartId,objectID);
       },

       /**
        * @private [Submits the temporary cart - calls submitTempCart function and displays confirmation dialog on success]
        */
       onSubmit : function() {
    	      //start the busy dialog now
   			  this.busyDialog.open();
              var that = this;
             
              
              var accountAssignmentField = this.getView().byId("input_assisted2").getValue().trim();
              //If AccountAssignmentType field is left empty
              if (accountAssignmentField === "") {
            	  	 //close the busy dialog first
       			  	 this.busyDialog.close();
                     sap.m.MessageBox.alert(this.oBundle.getText("WARNING_ON_SUBMIT"));
                     return;
              }
              var countryStatus = this.getCountryStatus();
              if (countryStatus != true) {
         	  	 //close the busy dialog first
    			  	 this.busyDialog.close();
                  sap.m.MessageBox.alert(this.oBundle.getText("WARNING_COUNTRY_ON_SUBMIT"));
                  return;
           }
              var confirmationDone = null;
              confirmationDone = new sap.m.Dialog({
                     title : this.oBundle.getText("CONFIRMATION"),
                     rightButton : new sap.m.Button({
                           text : this.oBundle.getText("DONE"),
                           press : function() {
                                  confirmationDone.close();
                                  confirmationDone.destroyContent();
                                  that.oRouter.navTo("master",null,true);
                                  that.getView().byId("noteToApprover").setValue("");
                           }
                     })
              }).addStyleClass("sapUiPopupWithPadding");

              //Calls submitTempCart function, which in turn displays success dialog on success call back
              this.submitTempCart(jQuery.proxy(function(oData,
                           oResponse) {
            	  	 //close the busy dialog first
          			 this.busyDialog.close();
          			 var confirmSuccess = new sap.m.Text("SCNumber");
         			 confirmationDone.addContent(confirmSuccess);
                     confirmSuccess.setText(that.oBundle.getText("SUCCESSFUL").replace("{0}",oData.data.OBJECT_ID));
                     confirmationDone.open();
              }, this), this.getTempCartId(), this.getCartObjectId());

       },

       /**
        * @private [Input assistance for country selection]
        * @param oEvent
        */
       onCountryValueHelpRequest : function(oEvent) {
    	   	  var that = this;
              var title1            = this.oBundle.getText("SELECT_COUNTRY");
              var path              = "/results";
              var title2            = "{CountryName}";
              var description  = "{CountryKey}";
              var filter            = "CountryName";
              var modelName         = "Country";        
              var countryField = this.getView().byId("input_assisted1");
              
              // Handling of both confirm and cancel; clear the filter
              var handleClose = function(oEvent) {
                     var oSelectedItem = oEvent
                     .getParameter("selectedItem");
                     if (oSelectedItem) {
                           countryField.setValue(oSelectedItem.getTitle());
                           that.country_key = oSelectedItem.getDescription();
                     }
                     oEvent.getSource().getBinding("items").filter([]);
              };

              this._valueHelpSelectDialog = new sap.m.SelectDialog(
              {
                     title : title1,
                     items : {
                           path : path,
                           template : new sap.m.StandardListItem(
                                         {
                                                title : title2,
                                                description : description,
                                                active : true
                                         })
                     },
                     search : function(oEvent) {
                           var sValue = oEvent.getParameter("value");
                           var oFilter = new sap.ui.model.Filter(filter,sap.ui.model.FilterOperator.Contains,sValue);
                           oEvent.getSource().getBinding("items").filter([ oFilter ]);
                     },
                     confirm : handleClose,
                     cancel : handleClose
              });
              this._valueHelpSelectDialog.setModel(this.getView().getModel(modelName));
              this._valueHelpSelectDialog.open();
       },

       /**
        * @private [Input assistance for account assignment selection]
        * @param oEvent
        */
       onAssignmentTypeValueHelpRequest : function(oEvent) {

              var that=this;

              var accountType = this.getView().byId("input_assisted3").getValue();
              var assignmentField = this.getView().byId("input_assisted2");
              
              var title1 = "";
              var title2 = "";
              var path   = "";           
              var description = "";
              var filter      = "";
              var modelName   = "";
              var info        = "";
              
              switch(accountType){
                     case this.oBundle.getText("COST_CENTER"):
                           modelName = this.createModel('CostCenter','CostCenterTabCollection', null,"ACC_ASS_SEARCH_HELP");
                           title1 = this.oBundle.getText("COST_ASSIGNMENT");
                           path = "/results";
                           title2 = "{COST_CTR}";
                           description = "{CC_DESCRIPTION}";
                           filter = "COST_CTR";
                           info = "{CO_AREA}";
                           break;
                     case this.oBundle.getText("INTERNAL_ORDER"):
                           modelName = this.createModel('InternalOrder','OrderNoTabCollection', null,"ACC_ASS_SEARCH_HELP");
                           title1          = this.oBundle.getText("COST_ASSIGNMENT");
                           path = "/results";
                           title2 = "{ORDER_NO}";
                           description = "{OR_DESCRIPTION}";
                           filter = "ORDER_NO";
                           info = "{CO_AREA}";
                           break;
                     case "":
                    	   //close the busy dialog first
              			   this.busyDialog.close();
                           sap.m.MessageBox.alert(this.oBundle.getText("SELECT_ACCOUNT_ASSIGNMENT_ALERT"));
                           return;                           
                     default:
                    	   //close the busy dialog first
              			   this.busyDialog.close();
                           sap.m.MessageBox.alert(this.oBundle.getText("SELECT_VALID_ACCOUNT_ASSIGNMENT"));
                           return;                           
              }
              
              // Handling of both confirm and cancel; clear the filter
              var handleClose = function(oEvent) {
                     var oSelectedItem = oEvent.getParameter("selectedItem");
                     if (oSelectedItem) {
                           assignmentField.setValue(oSelectedItem.getTitle());
                           that.co_area = oSelectedItem.getInfo();
                     }
                     oEvent.getSource().getBinding("items").filter([]);
              };

              // Create a SelectDialog and display it; bind to the same model as for the suggested items
              this._valueHelpSelectDialog = new sap.m.SelectDialog(
              {
                     title : title1,
                     items : {
                           path : path,
                           template : new sap.m.StandardListItem(
                                         {
                                                title : title2,
                                                description : description,
                                                info: info,
                                                active : true
                                         })
                     },
                     search : function(oEvent) {
                           var sValue = oEvent.getParameter("value");
                           var oFilter = new sap.ui.model.Filter(filter,sap.ui.model.FilterOperator.Contains,sValue);
                           oEvent.getSource().getBinding("items").filter([ oFilter ]);
                     },
                     confirm : handleClose,
                     cancel : handleClose
              });
              this._valueHelpSelectDialog.setModel(this.getView().getModel(modelName));
              this._valueHelpSelectDialog.open();
       },

       /**
        * @private [Input assistance for assignment type selection]
        * @param oEvent
        */
       onAccountAssignmentValueHelpRequest : function(oEvent) {

              var title1 = this.oBundle.getText("COST_TYPE");
              var path = "/results";
              var title2 = "{accAssg}";
              var filter = "accAssg";

              var accountField = this.getView().byId("input_assisted3");
              var assignmentTypeField = this.getView().byId("input_assisted2");

              // Handling of both confirm and cancel; clear the filter
              var handleClose = function(oEvent) {

                     var oSelectedItem = oEvent
                     .getParameter("selectedItem");
                     if (oSelectedItem) {
                           accountField.setValue(oSelectedItem.getTitle());
                           assignmentTypeField.setValue("");
                     }
                     oEvent.getSource().getBinding("items").filter([]);
              };

              // Create a SelectDialog and display it; bind to the same model as for the suggested items
              this._valueHelpSelectDialog = new sap.m.SelectDialog(
              {
                     title : title1,
                     items : {
                           path : path,
                           template : new sap.m.StandardListItem(
                                         {
                                                title : title2,
                                                active : true
                                         })
                     },
                     search : function(oEvent) {
                           var sValue = oEvent.getParameter("value");
                           var oFilter = new sap.ui.model.Filter(filter,sap.ui.model.FilterOperator.Contains,sValue);
                           oEvent.getSource().getBinding("items").filter([ oFilter ]);
                     },
                     confirm : handleClose,
                     cancel : handleClose
              });
              this._valueHelpSelectDialog.setModel(this.getView().getModel("AccountAssignment"));
              this._valueHelpSelectDialog.open();
       },

       onNavigateBack : function() {
              window.history.back();
       },

       /**
        * @private creates header and footer options which are to be set
        * @returns {_}
        */
       createHeaderFooterOptions: function(){
           var that = this;
           return {
                  sFullscreenTitle: that.oBundle.getText("ORDER_TITLE"),
                  onBack : jQuery.proxy(function(oEvent){
                	  that.oRouter.navTo("shoppingCartItems", {

                          tempCartId : that.tempCartId

                   },true);
                 that.getView().byId("noteToApprover").setValue("");
                  }),
                oEditBtn:  {
                        sI18nBtnTxt: "SUBMIT_CART",
                        onBtnPressed: jQuery.proxy(that.onSubmit, that)
                  },
                  
                   buttonList: [{    sI18nBtnTxt: "CANCEL",
                        onBtnPressed: jQuery.proxy(that.onCancel, that)  
                  }],

                  oAddBookmarkSettings: {
                        title: that.oBundle.getText("ORDER_TITLE"),
                        icon: "sap-icon://cart"
                  }
           };
    },

       
       onRequestFailed : function(oError) {
    	   	  //close the busy dialog first
   			  this.busyDialog.close();
              jQuery.sap.require("sap.ca.ui.message.message");
              sap.ca.ui.message.showMessageBox({
                     type : sap.ca.ui.message.Type.ERROR,
                     message : oError.message,
                     details : oError.response.body
              });
       },
       
       /**
        * @private Checks the country selected by user with the oData model of Country
        * @returns boolean value
        */
       getCountryStatus: function(){

    	   for(var i=0;i<this.oCountryModel.oData.results.length;i++){
    	                if(this.getView().byId("input_assisted1").getValue() === this.oCountryModel.oData.results[i].CountryName){
    	                	return true;
    	                	} 
    	   }
    	  return false;
       },
       
       onAfterRendering : function(){},
   	   onExit: function(){},
   	   onBeforeRendering : function(){}
});

