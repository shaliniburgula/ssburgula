/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartItems", {

	onInit: function() {
		//execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();

		// Get instance of the busy dialog
		this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});

		this.oRouter.attachRouteMatched(function(oEvent) { 
			if (oEvent.getParameter("name") === "shoppingCartItems") {
				var that = this;
				this.Temp_Cart_Id = oEvent.getParameter("arguments").tempCartId;
				//start the busy dialog now
				this.busyDialog.open();
				jQuery.proxy(this.getShoppingCartItemDetails(),that);
			}
		}, this);

		this.setHeaderFooterOptions(this.createHeaderFooterOptions());
	},

	/**
	 * private [Gets details of the temporary cart and binds it to the table displaying the item list and details]
	 */
	getShoppingCartItemDetails : function(){

		var onRequestSuccess1 = function(oData, oResponse) {
			var model1 = new sap.ui.model.json.JSONModel(oData);
			this.getView().setModel(model1, "ShoppingCartHeader");

			var itemCount = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(model1.oData.ITM_COUNT);
			this.getView().byId("MaterialList").setHeaderText(itemCount);                 
		};

		var onRequestSuccess2 = function(oData, oResponse) {
			var model2 = new sap.ui.model.json.JSONModel(oData);
			this.originalModel = model2.oData.results;
			if(model2.oData.results.length > 0){
				this.setBtnEnabled("checkoutBtn",true);
				this.setBtnEnabled("updateBtn",true);

			}else{
				this.setBtnEnabled("checkoutBtn",false);
				this.setBtnEnabled("updateBtn",false);
			}
			for(var i = 0 ; i < model2.oData.results.length; i++){
				model2.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(model2.oData.results[i].QUANTITY) * parseFloat(model2.oData.results[i].PRICE).toString()).toFixed(2);
			}
			this.getView().setModel(model2, "ShoppingCartItems");
			//last place for all data to be fetched, stop the busy dialog now
			this.busyDialog.close();
		};		

		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		//explicitly setting some headers for retrieving the updating information from the server
		//this setting is particularly significant for internet explorer since the page does not 
		//update upon addition of items of the cart
		oDataModel.setHeaders({"Cache-Control":"no-cache, no-store, must-revalidate","Pragma":"no-cache","Expires":"-1"});
		
		var sPath1 = "ShoppingcartCollection(TEMP_CART_ID='"+ this.Temp_Cart_Id +"')?ts="+Date.now();
		oDataModel.read(sPath1, null,null, true,jQuery.proxy(onRequestSuccess1, this), jQuery.proxy(this.onRequestFailed, this));
		
		var sPath2 = "ShoppingcartCollection(TEMP_CART_ID='"+ this.Temp_Cart_Id +"')/ShoppingCartItemNavigation?ts="+Date.now();
		oDataModel.read(sPath2, null,null, true,jQuery.proxy(onRequestSuccess2, this), jQuery.proxy(this.onRequestFailed, this));
	},


	/**
	 * @private [On changing the quantity, disables checkout button]
	 * @param oEvent
	 */
	onQuantityChanged : function(oEvent) {
		var value = oEvent.getParameters().newValue;
		//Floors the quantity value
		var cleanValue = Math.floor(value);

		//If quantity is less than 1, changes it to 1 (Minimum value for quantity)
		if(cleanValue<1) {
			cleanValue = 1;
		}
		if(cleanValue!=value) {
			oEvent.getSource().setValue(cleanValue);
		}
		var sId = oEvent.getParameter("id");
		var index = parseInt(sId.substring(sId.lastIndexOf("-")+1), 10);

		if(!this.quantities) {
			this.quantities = [];
		     }
		
		this.quantities[index] = cleanValue;
		//Disabling Checkout button
		if(this.quantities)
		{
		this.setBtnEnabled("checkoutBtn",false);
		}
	},

	/**
	 * @private [On deleting an item from the item list, removes it from the temporary cart]
	 * @param oEvent
	 */
	removeItem : function(oEvent) {
		var listItem = oEvent.getSource();
		var bindingContext = listItem.getBindingContext("ShoppingCartItems");
		var oModel = bindingContext.getModel();
		var path = bindingContext.getPath();
		var itemData = oModel.getProperty(path);

		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		oDataModel.remove("ShoppingcartItemCollection(ITEM_NO='"
				+ itemData.ITEM_NO
				+"',TEMP_CART_ID='" + this.Temp_Cart_Id
				+ "')"
				, null,jQuery.proxy(this.getShoppingCartItemDetails,this),
				jQuery.proxy(this.onRequestFailed,this));
	},

	/**
	 * @private [Itemdata is made to the format required for pay load ]
	 * @param selectedObject
	 * @returns {___anonymous4601_4955}
	 */
	_cloneItemData : function(selectedObject) {
		return {
			'ITEM_NO' : selectedObject.ITEM_NO,
			'TEMP_CART_ID' : selectedObject.TEMP_CART_ID,
			'DESCRIPTION' : selectedObject.DESCRIPTION,
			'QUANTITY' : selectedObject.QUANTITY,
			'UNIT' : selectedObject.UNIT,
			'PRICE' : selectedObject.PRICE.toString(),
			'CURRENCY' : selectedObject.CURRENCY,
			'PRODUCTKEY' : selectedObject.PRODUCTKEY,
		};
	},

	/**
	 * @private [Updates the temporary cart]
	 * @param oEvent
	 */
	onUpdateCart : function(oEvent) {
		var oModel = this.originalModel;
		if(this.quantities) {
			//start the busy dialog when the quantity is changed
			this.busyDialog.open();
			var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
			var aBatchArray = new Array();
			for (var i = 0; i < this.quantities.length; i++) {
				if(this.quantities[i] && parseInt(oModel[i].QUANTITY, 10)!=this.quantities[i]) {
					var itemdet = this._cloneItemData(oModel[i]);
					itemdet.QUANTITY = this.quantities[i].toString();
					//	itemdet.PRODUCTKEY = jQuery.sap.encodeURL(itemdet.PRODUCTKEY);
					//Creating a batch request
					var sPath = "ShoppingcartItemCollection(ITEM_NO=\'" + itemdet.ITEM_NO + "\',TEMP_CART_ID=\'" + this.Temp_Cart_Id + "\')?ts=" + Date.now();
					aBatchArray.push(oDataModel.createBatchOperation(sPath, "PUT", itemdet));
					
				}
			}
			
			
			if(aBatchArray.length === 0)
			{
			this.quantity = null;
			//Close the busy dialog now
			this.busyDialog.close();
			this.setBtnEnabled("checkoutBtn",this.getView().getModel("ShoppingCartItems").getData().results.length > 0);
			return;
			}
			oDataModel.addBatchChangeOperations(aBatchArray);
			var onRequestSuccess = function(oResponse) {
				this.quantities = null;
				this.getShoppingCartItemDetails();
				this.setBtnEnabled("checkoutBtn",true);
				var batchResponses = oResponse && oResponse.__batchResponses ? oResponse.__batchResponses : []; 
				for ( var i = 0; i < batchResponses.length; i++) {
					if(batchResponses[0] && batchResponses[0].response && batchResponses[0].response.statusCode == "400"){
						this.onRequestFailed(batchResponses[0]);
						return;
					}
				}
				jQuery.sap.require("sap.m.MessageToast");
				sap.m.MessageToast.show("Updated Successfully");
				this.busyDialog.close();
			};
			oDataModel.submitBatch(jQuery.proxy(onRequestSuccess,this),jQuery.proxy(this.onRequestFailed,this));
		}
		else
		{	
			//Close the busy dialog now
			this.busyDialog.close();
			this.setBtnEnabled("checkoutBtn",this.getView().getModel("ShoppingCartItems").getData().results.length > 0);
		}

	},

	/**
	 * @private [Navigates to checkout page]
	 */
	onCheckoutCart: function(){  
		this.oRouter.navTo("shoppingCartCheckout", {  
			tempCartId : this.Temp_Cart_Id,
		}, true);

		var totalValue = this.getView().getModel("ShoppingCartHeader").oData.TOTAL_VALUE +" "+ this.getView().getModel("ShoppingCartHeader").oData.WAERS;

		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView);
		var oComponent   = sap.ui.component(sComponentId);	

		oComponent.oEventBus.publish("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout",{
			totalValue: totalValue
		});
	},

	/**
	 * @private [creates header and footer options which are to be set]
	 * @returns {___anonymous6785_7210}
	 */
    createHeaderFooterOptions: function(){
        var that=this;
        return {
               sFullscreenTitle: that.oBundle.getText("CART_TITLE"),

               onBack: jQuery.proxy(function(oEvent){
            	   that.oRouter.navTo("noData",{

                       viewTitle: "DETAIL_TITLE",

                       languageKey: "NO_ITEMS_AVAILABLE"

                },true);

               }),

               buttonList: [{
                     sId: "updateBtn",
                     sI18nBtnTxt: "UPDATE_BUTTON",
                     onBtnPressed: jQuery.proxy(that.onUpdateCart, that)
               }],
               oEditBtn:{    
                     sId: "checkoutBtn",        
                     sI18nBtnTxt: "CHECKOUT_BUTTON",
                     onBtnPressed: jQuery.proxy(that.onCheckoutCart, that)  
               },
               
                 oAddBookmarkSettings: {
            title: that.oBundle.getText("CART_TITLE"),
            icon: "sap-icon://cart"
      }

        };
 },


	onRequestFailed: function(oError){
		//close the busy dialog first
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: oError.message,
			details: oError.response.body
		});
	},
	
	onAfterRendering : function(){},
	onExit: function(){},
	onBeforeRendering : function(){}
});
