/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.create.view.S3", {

	onInit : function() {
		// execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		
		// Get instance of the busy dialog
		this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});
	
		this.oRouter.attachRouteMatched(
			function(oEvent) {
				if (oEvent.getParameter("name") === "detail") 
					{
					this.Temp_Cart_Id = oEvent.getParameter("arguments").tempCartId;
					//start the busy dialog now
					this.busyDialog.open();
					this.getTempCartQuantity();
					}
		}, this);
		
        //Using the component ID we subscribe a call back for refreshing the data
        var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
        var oComponent = sap.ui.component(sComponentId);
        
        oComponent.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshDetail", this.getData, this);
	},

	
	getData : function(sChannelId, sEventId, oData) {		
		this.productKey = oData.data.productkey;
		this.description = oData.data.description;
		oData.data.cartValue = 1;
		this.selectedItemModel = new sap.ui.model.json.JSONModel(oData.data);
		this.getView().setModel(this.selectedItemModel, "itemDetail");
		var oHFOptions = this.getHeaderFooterOptions();
	    this.setHeaderFooterOptions(oHFOptions);
	    if(sap.ui.getCore().byId("cartValue"))
	    	sap.ui.getCore().byId("cartValue").setText(this.cartValue);
	},

	
	/**
	 * @private [Gets the quantity of items in temporary cart, and sets it to the shopping cart icon displayed in the header]
	 */
	getTempCartQuantity : function() {
		var onRequestSuccess = function(oData, oResponse) {
			this.cartValue = 0;
			var tempCartId = this.Temp_Cart_Id.trim();
			for ( var i = 0; i < oData.results.length; i++) {
				var existingTempCartId = oData.results[i].TEMP_CART_ID.trim();
				if (tempCartId === existingTempCartId) {
					this.cartValue = parseInt(this.cartValue,10) + 1;
				}
			}
			if(sap.ui.getCore().byId("cartValue"))
		    	sap.ui.getCore().byId("cartValue").setText(this.cartValue);
			
			this.busyDialog.close();
		};

		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		
		//explicitly setting some headers for retrieving the updating information from the server
		//this setting is particularly significant for internet explorer since the page does not 
		//update upon addition of items of the cart
		oDataModel.setHeaders({"Cache-Control":"no-cache, no-store, must-revalidate","Pragma":"no-cache","Expires":"-1"});
		var sPath = "ShoppingcartItemCollection?ts="+ Date.now();
		oDataModel.read(sPath,null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},

	
	/**
	 * @private [For navigation to the ShoppingCartItems page]
	 */
	gotoCartItem : function() {
		this.oRouter.navTo("shoppingCartItems", {
			tempCartId : this.Temp_Cart_Id
		},true);
	},
	/**
	 * @public [ getHeaderFooterOptions Define Header and Footer for the Detail
	 *         Screen ]
	 */
	getHeaderFooterOptions: function(){		
		
		        var that = this;
				return {
					oHeaderBtnSettings:{
						sId : "cartValue",
//						text : this.cartValue,
						sIcon:'sap-icon://cart-full',
						onBtnPressed : function(){
							that.gotoCartItem();} 	},
					oEditBtn:{
						sId : "addToCartBtn",
						sI18nBtnTxt : "ADD_TO_CART_DETAIL",
						type : "Accept",
						onBtnPressed : function(){that.onAddToCart();}}, 	
					oJamOptions : {
						oDiscussSettings : {
							object: {
								//as CROSS_CATALOG_SEARCH is maintained as default in configuration.js. No need to pass any parameter in getODataModel 
								id: this.oApplicationFacade.getODataModel().sServiceUrl+"CATALOG_ITEM('"+this.productKey+"')",
             					type: this.oApplicationFacade.getODataModel().sServiceUrl+"$metadata#CATALOG_ITEM",
            					name: this.description
          			                }
											}
           
									},
									bSuppressBookmarkButton : true
						};
	},

	/**
	 * @private [Gets the current temp cart details
	 * and on success callback updates the temp cart details in accordance with the currently added item]
	 */
	onAddToCart : function() {
		
		//start the busy dialog now
		this.busyDialog.open();
		   
		var onRequestSuccess = function(oData, oResponse) {
			var otempCartModel = new sap.ui.model.json.JSONModel(oData);
			jQuery.proxy(this.addToCartItemDetails(otempCartModel),this);
			this.getTempCartQuantity();
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		var sPath = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts="+ Date.now();
		oDataModel.read(sPath,
				null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},

	/**
	 * @private [In case the item added is already in the cart, makes a clone of the itemData in the format of the required pay load]
	 * @param selectedObject 
	 * @returns {___anonymous3662_4005}
	 */
	_cloneItemData : function(selectedObject) {
		return {
			'ITEM_NO' : selectedObject.ITEM_NO,
			'TEMP_CART_ID' : selectedObject.TEMP_CART_ID,
			'DESCRIPTION' : selectedObject.DESCRIPTION,
			'QUANTITY' : selectedObject.QUANTITY,
			'UNIT' : selectedObject.UNIT,
			'PRICE' : selectedObject.PRICE,
			'CURRENCY' : selectedObject.CURRENCY,
			'PRODUCTKEY' : selectedObject.PRODUCTKEY,
		};
	},

	/**
	 * @private [If the item added was not already in the cart, creates a new itemData in the format of the required pay load]
	 * @param tempCartId
	 * @param selectedObject
	 * @returns {___anonymous4352_4528}
	 */
	_createItemData : function(tempCartId, selectedObject) {
		var itemData = {
			'ITEM_NO' : '',
			'TEMP_CART_ID' : '',
			'DESCRIPTION' : '',
			'QUANTITY' : '',
			'UNIT' : 'EA',
			'PRICE' : '',
			'CURRENCY' : '',
			'PRODUCTKEY' : '',
		};

		itemData.TEMP_CART_ID = tempCartId;
		itemData.DESCRIPTION  = selectedObject.description;    
		itemData.CURRENCY 	  = selectedObject.itm_currency;
		itemData.UNIT 		  = selectedObject.unit;
		itemData.PRICE 		  = selectedObject.itm_price;
		return itemData;
	},

	
	/**
	 * @private [If the item to be added is already in the cart, updates the existing item details in the temporary cart
	 * else if the item is added for the first time, then creates the item in the temporary cart] 
	 * @param tempCartModel - model corresponding to the current temporary cart 
	 */
	addToCartItemDetails : function(tempCartModel) {
		
		var selectedModel = new sap.ui.model.json.JSONModel();
		var oDataModel    = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		selectedModel = null;
		
		//this.selectedItemModel - Item selected from master list
		if (this.selectedItemModel != null) {
			var selectedItemProductKey = this.selectedItemModel.oData.productkey.trim();
			//Checks whether the item with this product key already exists in the temp cart
			for ( var i = 0; i < tempCartModel.oData.results.length; i++) {
				var existingProductKey = tempCartModel.oData.results[i].PRODUCTKEY.trim();
				if (existingProductKey === selectedItemProductKey|existingProductKey === jQuery.sap.encodeURL(selectedItemProductKey)) {
					selectedModel = tempCartModel.oData.results[i];
					break;
				}
			}
			
			var itemData = this._createItemData(this.Temp_Cart_Id,this.selectedItemModel.oData);
			
			if (selectedModel != null) {
				//If the item to be added is already in the cart, update the corresponding item details in the temp cart
				itemData = this._cloneItemData(selectedModel);
				//Truncating description to 40 characters
				itemData.DESCRIPTION = this.selectedItemModel.oData.description.substring(0,39);
				itemData.UNIT = this.selectedItemModel.oData.unit_cu;
				itemData.QUANTITY   = (parseInt(itemData.QUANTITY, 10) + 1).toString();
				itemData.PRICE = itemData.PRICE.split(".")[0]+"."+itemData.PRICE.split(".")[1].slice(0,2);
				this.updateTriggered = true;
				oDataModel.update("ShoppingcartItemCollection(ITEM_NO='"+ itemData.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')",
						itemData,null,jQuery.proxy(this.onItemAdded,this),jQuery.proxy(this.onRequestFailed, this));
			} 
			else {
				//If the item to be added is not already in the cart, create the item in the temp cart
				itemData.UNIT = this.selectedItemModel.oData.unit_cu;
				//Truncating description to 40 characters
				itemData.DESCRIPTION = this.selectedItemModel.oData.description.substring(0,39);
				itemData.PRODUCTKEY = jQuery.sap.encodeURL(this.selectedItemModel.oData.productkey);
				itemData.QUANTITY   = ( this.selectedItemModel.oData.minorderqty ? this.selectedItemModel.oData.minorderqty : 1 ) + "";
				itemData.PRICE = itemData.PRICE.split(".")[0]+"."+itemData.PRICE.split(".")[1].slice(0,2);
				this.updateTriggered = false;
				oDataModel.create("ShoppingcartItemCollection",itemData,null,
						jQuery.proxy(this.onItemAdded,this),jQuery.proxy(this.onRequestFailed,this));
			}
		}
	},
			
	onRequestFailed: function(oError){
		//close the busy dialog first
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type : sap.ca.ui.message.Type.ERROR,
			message : oError.message,
			details : oError.response.body
		});
	},
	
	onItemAdded: function(){
		var cartValue = sap.ui.getCore().byId("cartValue").getText();
		if(!this.updateTriggered){
			cartValue = parseInt(cartValue,10) + 1;
			sap.ui.getCore().byId("cartValue").setText(cartValue);
		}
		sap.m.MessageToast.show(this.oBundle.getText("ADD_CART_SUCCESS"));
		this.busyDialog.close();
	},
	
	navToEmptyView: function(){
		this.oRouter.navTo("noData",null,true);
	},
	
	onAfterRendering : function(){},
	onExit: function(){},
	onBeforeRendering : function(){}
});
//sap.ushell.ui.footerbar.JamDiscussButton.prototype.setEnabled = function (bEnabled) {
//
//	sap.m.Button.prototype.setEnabled.call(this, bEnabled);
//
//	};