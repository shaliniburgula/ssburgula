/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.model.type.Number");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartCheckout", {
	onInit: function() {
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		this.busyDialog = new sap.m.BusyDialog({
			customIcon: sap.ca.ui.images.images.Flower
		});
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "shoppingCartCheckout") {
				this.tempCartId = e.getParameter("arguments").tempCartId;
				this.busyDialog.open();
				this.getUserPersonalizationsettings();
				this.getTempCartItems()
			}
		}, this);
		var c = sap.ui.core.Component.getOwnerIdFor(this.getView());
		var C = sap.ui.component(c);
		C.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", jQuery.proxy(this.getData, this), this);
		this.co_area = "";
		this.country_key = "";
		this.oCountryModel = this.createModel('Country', 'CountryCollection', null, "COUNTRY_SH_SERVICE");
		this.jsonModel = new sap.ui.model.json.JSONModel({
			results: [{
				accAssg: this.oBundle.getText("COST_CENTER")
			}, {
				accAssg: this.oBundle.getText("INTERNAL_ORDER")
			}]
		});
		this.getView().setModel(this.jsonModel, "AccountAssignment");
		this.setHeaderFooterOptions(this.createHeaderFooterOptions());
		this.getView().byId("dateplusseven").setDisplayFormat(sap.m.getLocaleData().getDatePattern("medium"))
	},
	getData: function(c, e, v) {
		var t = v;
		this.getView().byId("totalValue").setValue(t.totalValue)
	},
	createModel: function(m, p, f, M) {
		var o;
		var a = function(D, r) {
			o = new sap.ui.model.json.JSONModel(D);
			o.setSizeLimit(500);
			this.getView().setModel(o, m)
		};
		var d = this.oApplicationFacade.getODataModel(M);
		d.read(p, null, f, false, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));
		if (m === "Country") return o;
		else return m
	},
	getUserPersonalizationsettings: function() {
		var o = function(D, r) {
			this.oUserDefaults = new sap.ui.model.json.JSONModel(D.results[0]);
			this.getView().setModel(this.oUserDefaults, "personalCollection");
			this.getView().byId("dateplusseven").setValue(this.sevenDaysFromNowDateAsString())
		};
		var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		d.read("User_PersonalizationCollection?ts=" + Date.now(), null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,
			this))
	},
	sevenDaysFromNowDateAsString: function() {
		var d = new Date();
		d.setDate(d.getDate() + 7);
		var v = this.getView().byId('dateplusseven').getValueFormat();
		return sap.ca.ui.model.format.DateFormat.getDateInstance({
			pattern: v
		}).format(d)
	},
	getTempCartItems: function() {
		var o = function(D, r) {
			var T = new sap.ui.model.json.JSONModel(D);
			for (var i = 0; i < T.oData.results.length; i++) {
				T.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(T.oData.results[i].QUANTITY) * parseFloat(T.oData.results[i].PRICE))
			}
			this.getView().byId("MaterialList").setModel(T, "ShoppingCartItems");
			var a = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(T.oData.results.length);
			this.getView().byId("MaterialList").setHeaderText(a);
			this.busyDialog.close()
		};
		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		this.getDefaultUserSettings();
		var t = this.getTempCartId();
		d.read("ShoppingcartCollection(TEMP_CART_ID='" + t + "')/ShoppingCartItemNavigation?ts=" + Date.now(), null, null, true, jQuery.proxy(o,
			this), jQuery.proxy(this.onRequestFailed, this))
	},
	discardTempCart: function(t, o) {
		this.busyDialog.open();
		this.OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		this.OShoppingCartDataModel.update("HOLD_DOCUMENT?TEMP_CART_ID='" + t + "'&OBJECT_ID='" + o + "'", null, {
			oContext: null,
			fnSuccess: jQuery.proxy(function() {
				this.busyDialog.close()
			}, this),
			fnError: jQuery.proxy(this.onRequestFailed, this)
		})
	},
	getTempCartId: function() {
		return this.oDefaultSettings.oData.results[0].TEMP_CART_ID
	},
	getDefaultUserSettings: function() {
		var o = function(D, r) {
			this.oDefaultSettings = new sap.ui.model.json.JSONModel(D)
		};
		var d = this.oApplicationFacade.getODataModel("getdefusrset");
		d.read("DefaultUserSettings?ts=" + Date.now(), null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
	},
	getCartObjectId: function() {
		return this.oDefaultSettings.oData.results[0].OBJECT_ID
	},
	onCancel: function() {
		var t = this;
		var c = new sap.m.Text({
			text: t.oBundle.getText("CANCEL_MESSAGE")
		});
		var a = null;
		a = new sap.m.Dialog({
			content: [c],
			title: t.oBundle.getText("CANCEL_TITLE"),
			leftButton: new sap.m.Button({
				text: this.oBundle.getText("YES"),
				press: function() {
					t.discardTempCart(t.getTempCartId(), t.getCartObjectId());
					a.close();
					t.oRouter.navTo("master", null, true);
					t.getView().byId("noteToApprover").setValue("")
				}
			}),
			rightButton: new sap.m.Button({
				text: this.oBundle.getText("NO"),
				press: function() {
					a.close()
				}
			})
		}).addStyleClass("sapUiPopupWithPadding");
		a.open()
	},
	getSRMCartItems: function(s, c, b) {
		if (typeof(b) === undefined) {
			b = true
		}
		var o = jQuery.proxy(function(d, r) {
			if (s) {
				s.call(d, r)
			}
		}, this);
		var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		var p = "SRMShoppingCartCollection(OBJECT_ID='" + c + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartItemNavigation?ts=" + Date.now();
		O.read(p, null, null, b, o, jQuery.proxy(this.onRequestFailed, this))
	},
	saveSRMShoppingCart: function(s, o, d, a) {
		var I;
		var t = this;
		var b = jQuery.proxy(function(D, r) {
			I = D;
			I.CURRENCY = d.oData.results[0].CURRENCY;
			I.CITY = this.getView().byId("city").getValue();
			I.COUNTRY = t.country_key;
			I.STREET = this.getView().byId("street").getValue();
			I.APRV_NOTE = a
		}, this);
		var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		var p = "SRMShoppingCartCollection(OBJECT_ID='" + o + "',DOC_MODE='DISPLAY',WIID='000000000000')?ts=" + Date.now();
		O.read(p, null, null, false, b, jQuery.proxy(this.onRequestFailed, this));
		for (var i = 0; i < t.oCountryModel.oData.results.length; i++) {
			if (this.getView().byId("input_assisted1").getValue() === t.oCountryModel.oData.results[i].CountryName) {
				I.COUNTRY = t.oCountryModel.oData.results[i].CountryKey;
				t.country_key = t.oCountryModel.oData.results[i].CountryKey
			}
		}
		if (this.extHook1) {
			this.extHook1()
		};
		if (this.extHook2) {
			this.extHook2()
		};
		var c = {};
		c.ACC_NO = '0001';
		c.WIID = '000000000000';
		c.DISTR_PERC = '100.0';
		c.G_L_ACCT = this.oUserDefaults.oData.G_L_ACCT;
		if (this.co_area === "") {
			this.co_area = this.oUserDefaults.oData.CO_AREA
		}
		var e = this.getView().byId("input_assisted3").getValue().trim();
		var f = this.oBundle.getText("COST_CENTER").trim();
		var g = this.oBundle.getText("INTERNAL_ORDER").trim();
		if (e === f) {
			c.COST_CTR = this.getView().byId("input_assisted2").getValue();
			c.ACC_CAT = 'CC';
			c.CO_AREA = t.co_area
		} else if (e === g) {
			c.ORDER_NO = this.getView().byId("input_assisted2").getValue();
			c.ACC_CAT = 'OR';
			c.CO_AREA = t.co_area
		} else if (e === "") {
			c.CO_AREA = this.oUserDefaults.oData.CO_AREA
		}
		var h = {};
		h.ShoppingCartID = o;
		h.WIID = '000000000000';
		h.City = this.getView().byId("city").getValue();
		h.Name = this.oUserDefaults.oData.REQUESTOR_DESC;
		h.CountryName = this.getView().byId("input_assisted1").getValue();
		h.Country = t.country_key;
		h.Street = this.getView().byId("street").getValue();
		h.PostalCode1 = this.getView().byId("zip").getValue();
		var S = function() {
			s.call()
		};
		this.getSRMCartItems(jQuery.proxy(function(D, r) {
			var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
			var B = new Array();
			for (var i = 0; i < D.data.results.length; i++) {
				D.data.results[i].DELIV_DATE = this.getView().byId("dateplusseven").getDateValue() === null ? "" : this.getView().byId(
					"dateplusseven").getDateValue();
				var j = new Date();
				j.setUTCMonth(D.data.results[i].DELIV_DATE.getMonth());
				j.setUTCDate(D.data.results[i].DELIV_DATE.getDate());
				j.setUTCFullYear(D.data.results[i].DELIV_DATE.getFullYear());
				j.setUTCHours(00);
				j.setUTCMinutes(00);
				j.setUTCSeconds(00);
				D.data.results[i].DELIV_DATE = j;
				delete D.data.results[i].__metadata;
				delete D.data.results[i].SourceofSupplyNavigation;
				delete D.data.results[i].ItemAccountAssignmentNavigation;
				delete D.data.results[i].ItemApproverNavigation;
				delete D.data.results[i].ItemAttachmentNavigation;
				delete D.data.results[i].ItemShippingAddressNavigation;
				B.push(O.createBatchOperation("SRMShoppingCartItemCollection(NUMBER_INT='" + D.data.results[i].NUMBER_INT + "',OBJECT_ID='" + o +
					"',DOC_MODE='',WIID='000000000000')", "PUT", D.data.results[i]));
				c.NUMBER_INT = D.data.results[i].NUMBER_INT;
				B.push(O.createBatchOperation("AccountAssignmentCollection(NUMBER_INT='" + c.NUMBER_INT + "',OBJECT_ID='" + o +
					"',ACC_NO='0001',DOC_MODE='',WIID='000000000000')", "PUT", c));
				h.ItemNumber = D.data.results[i].NUMBER_INT;
				B.push(O.createBatchOperation("ShippingAddressCollection(ItemNumber='" + c.NUMBER_INT + "',ShoppingCartID='" + o +
					"',DOC_MODE='',WIID='000000000000')", "PUT", h))
			}
			O.addBatchChangeOperations(B);
			O.submitBatch(S, jQuery.proxy(this.onRequestFailed, this))
		}, this), o)
	},
	saveTempCart: function(s, t, o) {
		var i = {
			TEMP_CART_ID: this.getTempCartId(),
			CHECKOUT: "X",
			WAERS: this.oDefaultSettings.oData.results[0].CURRENCY
		};
		if (o !== null) {
			i.OBJECT_ID = o
		};
		var e = function(E) {
			this.busyDialog.close();
			jQuery.sap.require("sap.ca.ui.message.message");
			sap.ca.ui.message.showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: E.message,
				details: jQuery.parseJSON(E.response.body).error.message.value
			})
		};
		var S = jQuery.proxy(function(D, r) {
			if (s) {
				s.call(D, r)
			}
		}, this);
		var a = this.getView().byId("noteToApprover").getValue();
		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		d.create("ShoppingcartCollection", i, null, jQuery.proxy(function(D, r) {
			this.saveSRMShoppingCart(S, D.OBJECT_ID, this.oDefaultSettings, a)
		}, this), jQuery.proxy(e, this))
	},
	submitTempCart: function(s, t, o) {
		var i = {
			TEMP_CART_ID: t,
			ORDER: "X"
		};
		var e = function(E) {
			this.busyDialog.close();
			var c = function() {
				if (sap.ui.getCore().byId("SCNumber")) {
					sap.ui.getCore().byId("SCNumber").destroy()
				}
			};
			jQuery.sap.require("sap.ca.ui.message.message");
			sap.ca.ui.message.showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: E.message,
				details: jQuery.parseJSON(E.response.body).error.message.value
			}, c)
		};
		var S = jQuery.proxy(function(d, r) {
			var O = this.oApplicationFacade.getODataModel("SHOPPING_CART");
			O.create("ShoppingcartCollection", i, null, jQuery.proxy(function(d, r) {
				if (s) {
					s.call(d, r)
				}
			}, this), jQuery.proxy(e, this))
		}, this);
		this.saveTempCart(S, t, o)
	},
	onSubmit: function() {
		this.busyDialog.open();
		var t = this;
		var a = this.getView().byId("input_assisted2").getValue().trim();
		if (a === "") {
			this.busyDialog.close();
			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_ON_SUBMIT"));
			return
		}
		var c = this.getCountryStatus();
		if (c != true) {
			this.busyDialog.close();
			sap.m.MessageBox.alert(this.oBundle.getText("WARNING_COUNTRY_ON_SUBMIT"));
			return
		}
		var b = null;
		b = new sap.m.Dialog({
			title: this.oBundle.getText("CONFIRMATION"),
			rightButton: new sap.m.Button({
				text: this.oBundle.getText("DONE"),
				press: function() {
					b.close();
					b.destroyContent();
					t.oRouter.navTo("master", null, true);
					t.getView().byId("noteToApprover").setValue("")
				}
			})
		}).addStyleClass("sapUiPopupWithPadding");
		this.submitTempCart(jQuery.proxy(function(d, r) {
			this.busyDialog.close();
			var e = new sap.m.Text("SCNumber");
			b.addContent(e);
			e.setText(t.oBundle.getText("SUCCESSFUL").replace("{0}", d.data.OBJECT_ID));
			b.open()
		}, this), this.getTempCartId(), this.getCartObjectId())
	},
	onCountryValueHelpRequest: function(e) {
		var t = this;
		var a = this.oBundle.getText("SELECT_COUNTRY");
		var p = "/results";
		var b = "{CountryName}";
		var d = "{CountryKey}";
		var f = "CountryName";
		var m = "Country";
		var c = this.getView().byId("input_assisted1");
		var h = function(e) {
			var s = e.getParameter("selectedItem");
			if (s) {
				c.setValue(s.getTitle());
				t.country_key = s.getDescription()
			}
			e.getSource().getBinding("items").filter([])
		};
		this._valueHelpSelectDialog = new sap.m.SelectDialog({
			title: a,
			items: {
				path: p,
				template: new sap.m.StandardListItem({
					title: b,
					description: d,
					active: true
				})
			},
			search: function(e) {
				var v = e.getParameter("value");
				var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);
				e.getSource().getBinding("items").filter([F])
			},
			confirm: h,
			cancel: h
		});
		this._valueHelpSelectDialog.setModel(this.getView().getModel(m));
		this._valueHelpSelectDialog.open()
	},
	onAssignmentTypeValueHelpRequest: function(e) {
		var t = this;
		var a = this.getView().byId("input_assisted3").getValue();
		var b = this.getView().byId("input_assisted2");
		var c = "";
		var d = "";
		var p = "";
		var f = "";
		var g = "";
		var m = "";
		var i = "";
		switch (a) {
			case this.oBundle.getText("COST_CENTER"):
				m = this.createModel('CostCenter', 'CostCenterTabCollection', null, "ACC_ASS_SEARCH_HELP");
				c = this.oBundle.getText("COST_ASSIGNMENT");
				p = "/results";
				d = "{COST_CTR}";
				f = "{CC_DESCRIPTION}";
				g = "COST_CTR";
				i = "{CO_AREA}";
				break;
			case this.oBundle.getText("INTERNAL_ORDER"):
				m = this.createModel('InternalOrder', 'OrderNoTabCollection', null, "ACC_ASS_SEARCH_HELP");
				c = this.oBundle.getText("COST_ASSIGNMENT");
				p = "/results";
				d = "{ORDER_NO}";
				f = "{OR_DESCRIPTION}";
				g = "ORDER_NO";
				i = "{CO_AREA}";
				break;
			case "":
				this.busyDialog.close();
				sap.m.MessageBox.alert(this.oBundle.getText("SELECT_ACCOUNT_ASSIGNMENT_ALERT"));
				return;
			default:
				this.busyDialog.close();
				sap.m.MessageBox.alert(this.oBundle.getText("SELECT_VALID_ACCOUNT_ASSIGNMENT"));
				return
		}
		var h = function(e) {
			var s = e.getParameter("selectedItem");
			if (s) {
				b.setValue(s.getTitle());
				t.co_area = s.getInfo()
			}
			e.getSource().getBinding("items").filter([])
		};
		this._valueHelpSelectDialog = new sap.m.SelectDialog({
			title: c,
			items: {
				path: p,
				template: new sap.m.StandardListItem({
					title: d,
					description: f,
					info: i,
					active: true
				})
			},
			search: function(e) {
				var v = e.getParameter("value");
				var F = new sap.ui.model.Filter(g, sap.ui.model.FilterOperator.Contains, v);
				e.getSource().getBinding("items").filter([F])
			},
			confirm: h,
			cancel: h
		});
		this._valueHelpSelectDialog.setModel(this.getView().getModel(m));
		this._valueHelpSelectDialog.open()
	},
	onAccountAssignmentValueHelpRequest: function(e) {
		var t = this.oBundle.getText("COST_TYPE");
		var p = "/results";
		var a = "{accAssg}";
		var f = "accAssg";
		var b = this.getView().byId("input_assisted3");
		var c = this.getView().byId("input_assisted2");
		var h = function(e) {
			var s = e.getParameter("selectedItem");
			if (s) {
				b.setValue(s.getTitle());
				c.setValue("")
			}
			e.getSource().getBinding("items").filter([])
		};
		this._valueHelpSelectDialog = new sap.m.SelectDialog({
			title: t,
			items: {
				path: p,
				template: new sap.m.StandardListItem({
					title: a,
					active: true
				})
			},
			search: function(e) {
				var v = e.getParameter("value");
				var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);
				e.getSource().getBinding("items").filter([F])
			},
			confirm: h,
			cancel: h
		});
		this._valueHelpSelectDialog.setModel(this.getView().getModel("AccountAssignment"));
		this._valueHelpSelectDialog.open()
	},
	onNavigateBack: function() {
		window.history.back()
	},
	createHeaderFooterOptions: function() {
		var t = this;
		return {
			sFullscreenTitle: t.oBundle.getText("ORDER_TITLE"),
			onBack: jQuery.proxy(function(e) {
				t.oRouter.navTo("shoppingCartItems", {
					tempCartId: t.tempCartId
				}, true);
				t.getView().byId("noteToApprover").setValue("")
			}),
			oEditBtn: {
				sI18nBtnTxt: "SUBMIT_CART",
				onBtnPressed: jQuery.proxy(t.onSubmit, t)
			},
			buttonList: [{
				sI18nBtnTxt: "CANCEL",
				onBtnPressed: jQuery.proxy(t.onCancel, t)
			}],
			oAddBookmarkSettings: {
				title: t.oBundle.getText("ORDER_TITLE"),
				icon: "sap-icon://cart"
			}
		}
	},
	onRequestFailed: function(e) {
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: e.message,
			details: e.response.body
		})
	},
	getCountryStatus: function() {
		for (var i = 0; i < this.oCountryModel.oData.results.length; i++) {
			if (this.getView().byId("input_assisted1").getValue() === this.oCountryModel.oData.results[i].CountryName) {
				return true
			}
		}
		return false
	},
	onAfterRendering: function() {},
	onExit: function() {},
	onBeforeRendering: function() {}
});