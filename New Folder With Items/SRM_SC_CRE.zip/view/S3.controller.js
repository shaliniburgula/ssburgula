/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.create.view.S3", {
	onInit: function() {
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		this.busyDialog = new sap.m.BusyDialog({
			customIcon: sap.ca.ui.images.images.Flower
		});
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "detail") {
				this.Temp_Cart_Id = e.getParameter("arguments").tempCartId;
				this.busyDialog.open();
				this.getTempCartQuantity()
			}
		}, this);
		var c = sap.ui.core.Component.getOwnerIdFor(this.getView());
		var C = sap.ui.component(c);
		C.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshDetail", this.getData, this)
	},
	getData: function(c, e, d) {
		this.productKey = d.data.productkey;
		this.description = d.data.description;
		d.data.cartValue = 1;
		this.selectedItemModel = new sap.ui.model.json.JSONModel(d.data);
		this.getView().setModel(this.selectedItemModel, "itemDetail");
		var h = this.getHeaderFooterOptions();
		this.setHeaderFooterOptions(h);
		if (sap.ui.getCore().byId("cartValue")) sap.ui.getCore().byId("cartValue").setText(this.cartValue)
	},
	getTempCartQuantity: function() {
		var o = function(D, r) {
			this.cartValue = 0;
			var t = this.Temp_Cart_Id.trim();
			for (var i = 0; i < D.results.length; i++) {
				var e = D.results[i].TEMP_CART_ID.trim();
				if (t === e) {
					this.cartValue = parseInt(this.cartValue, 10) + 1
				}
			}
			if (sap.ui.getCore().byId("cartValue")) sap.ui.getCore().byId("cartValue").setText(this.cartValue);
			this.busyDialog.close()
		};
		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		d.setHeaders({
			"Cache-Control": "no-cache, no-store, must-revalidate",
			"Pragma": "no-cache",
			"Expires": "-1"
		});
		var p = "ShoppingcartItemCollection?ts=" + Date.now();
		d.read(p, null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
	},
	gotoCartItem: function() {
		this.oRouter.navTo("shoppingCartItems", {
			tempCartId: this.Temp_Cart_Id
		}, true)
	},
	getHeaderFooterOptions: function() {
		var t = this;
		return {
			oHeaderBtnSettings: {
				sId: "cartValue",
				sIcon: 'sap-icon://cart-full',
				onBtnPressed: function() {
					t.gotoCartItem()
				}
			},
			oEditBtn: {
				sId: "addToCartBtn",
				sI18nBtnTxt: "ADD_TO_CART_DETAIL",
				type: "Accept",
				onBtnPressed: function() {
					t.onAddToCart()
				}
			},
			oJamOptions: {
				oDiscussSettings: {
					object: {
						id: this.oApplicationFacade.getODataModel().sServiceUrl + "CATALOG_ITEM('" + this.productKey + "')",
						type: this.oApplicationFacade.getODataModel().sServiceUrl + "$metadata#CATALOG_ITEM",
						name: this.description
					}
				}
			},
			bSuppressBookmarkButton: true
		}
	},
	onAddToCart: function() {
		this.busyDialog.open();
		var o = function(D, r) {
			var a = new sap.ui.model.json.JSONModel(D);
			jQuery.proxy(this.addToCartItemDetails(a), this);
			this.getTempCartQuantity()
		};
		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		var p = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();
		d.read(p, null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
	},
	_cloneItemData: function(s) {
		return {
			'ITEM_NO': s.ITEM_NO,
			'TEMP_CART_ID': s.TEMP_CART_ID,
			'DESCRIPTION': s.DESCRIPTION,
			'QUANTITY': s.QUANTITY,
			'UNIT': s.UNIT,
			'PRICE': s.PRICE,
			'CURRENCY': s.CURRENCY,
			'PRODUCTKEY': s.PRODUCTKEY,
		}
	},
	_createItemData: function(t, s) {
		var i = {
			'ITEM_NO': '',
			'TEMP_CART_ID': '',
			'DESCRIPTION': '',
			'QUANTITY': '',
			'UNIT': 'EA',
			'PRICE': '',
			'CURRENCY': '',
			'PRODUCTKEY': '',
		};
		i.TEMP_CART_ID = t;
		i.DESCRIPTION = s.description;
		i.CURRENCY = s.itm_currency;
		i.UNIT = s.unit;
		i.PRICE = s.itm_price;
		return i
	},
	addToCartItemDetails: function(t) {
		var s = new sap.ui.model.json.JSONModel();
		var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		s = null;
		if (this.selectedItemModel != null) {
			var a = this.selectedItemModel.oData.productkey.trim();
			for (var i = 0; i < t.oData.results.length; i++) {
				var e = t.oData.results[i].PRODUCTKEY.trim();
				if (e === a | e === jQuery.sap.encodeURL(a)) {
					s = t.oData.results[i];
					break
				}
			}
			var b = this._createItemData(this.Temp_Cart_Id, this.selectedItemModel.oData);
			if (s != null) {
				b = this._cloneItemData(s);
				b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);
				b.UNIT = this.selectedItemModel.oData.unit_cu;
				b.QUANTITY = (parseInt(b.QUANTITY, 10) + 1).toString();
				b.PRICE = b.PRICE.split(".")[0] + "." + b.PRICE.split(".")[1].slice(0, 2);
				this.updateTriggered = true;
				d.update("ShoppingcartItemCollection(ITEM_NO='" + b.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", b, null, jQuery.proxy(
					this.onItemAdded, this), jQuery.proxy(this.onRequestFailed, this))
			} else {
				b.UNIT = this.selectedItemModel.oData.unit_cu;
				b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);
				b.PRODUCTKEY = jQuery.sap.encodeURL(this.selectedItemModel.oData.productkey);
				b.QUANTITY = (this.selectedItemModel.oData.minorderqty ? this.selectedItemModel.oData.minorderqty : 1) + "";
				b.PRICE = b.PRICE.split(".")[0] + "." + b.PRICE.split(".")[1].slice(0, 2);
				this.updateTriggered = false;
				d.create("ShoppingcartItemCollection", b, null, jQuery.proxy(this.onItemAdded, this), jQuery.proxy(this.onRequestFailed, this))
			}
		}
	},
	onRequestFailed: function(e) {
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: e.message,
			details: e.response.body
		})
	},
	onItemAdded: function() {
		var c = sap.ui.getCore().byId("cartValue").getText();
		if (!this.updateTriggered) {
			c = parseInt(c, 10) + 1;
			sap.ui.getCore().byId("cartValue").setText(c)
		}
		sap.m.MessageToast.show(this.oBundle.getText("ADD_CART_SUCCESS"));
		this.busyDialog.close()
	},
	navToEmptyView: function() {
		this.oRouter.navTo("noData", null, true)
	},
	onAfterRendering: function() {},
	onExit: function() {},
	onBeforeRendering: function() {}
});