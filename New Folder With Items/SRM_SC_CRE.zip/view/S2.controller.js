/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.create.view.S2", {
	onInit: function() {
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		this.isRoot = true;
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "master" && !this.isRoot && Object.keys(e.getParameter("arguments")).length === 0) {
				var d = sap.ui.core.routing.History.getInstance().getDirection("shoppingCartCheckout/" + this.tempCartId);
				if (d === "Unknown") {
					this.isRoot = true;
					this._oControlStore.oMasterSearchField.clear()
				} else {
					if (this.getList() !== null) {
						var i = this.getList().getSelectedItem();
						if (i !== null) {
							this.setListItem(i)
						}
					}
				}
			}
			this.isRoot = (this.isRoot) ? false : this.isRoot
		}, this);
		this.setEmptyCart(true)
	},
	getDefaultUserSettings: function(r) {
		var o = function(D, R) {
			this.tempCartId = D.results[0].TEMP_CART_ID;
			if (!jQuery.device.is.phone) {
				if (r) {
					this.oRouter.navTo("noData", {
						viewTitle: "DETAIL_TITLE",
						languageKey: "NO_ITEMS_AVAILABLE"
					}, true)
				} else {
					this.navToEmptyView()
				}
			}
		};
		var d = this.oApplicationFacade.getODataModel("getdefusrset");
		d.read("DefaultUserSettings?ts=" + Date.now(), null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
	},
	applySearchPatternToListItem: function(i, f) {
		if (f.substring(0, 1) === "#") {
			var t = f.substr(1);
			var d = i.getBindingContext().getProperty("Name").toLowerCase();
			return d.indexOf(t) === 0
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
		}
	},
	getHeaderFooterOptions: function() {
		var o = {
			sI18NMasterTitle: "MASTER_TITLE",
			buttonList: []
		};
		return o
	},
	isBackendSearch: function() {
		return true
	},
	applyBackendSearchPattern: function(f, b) {
		if (f != "" && f != null) {
			this.startReadListData(f)
		} else {
			this.setEmptyCart(false)
		}
	},
	startReadListData: function(f) {
		var o = function(D, r) {
			var m = new sap.ui.model.json.JSONModel(D.results);
			this.getView().setModel(m);
			this.getList().destroyItems();
			this.getList().bindAggregation("items", {
				path: "/",
				template: this.oTemplate.clone(),
				filter: [],
				sorter: null,
			});
			this.registerMasterListBind(this.getList())
		};
		var e = encodeURIComponent(f);
		var d = this.oApplicationFacade.getODataModel();
		d.read("CATALOG_ITEM?$filter=startswith(description,'" + e + "')&$top=20", null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,
			this))
	},
	setListItem: function(i) {
		var b = i.getBindingContext();
		var m = b.oModel.oData[parseInt(b.sPath.split('/')[1])];
		this.oRouter.navTo("detail", {
			tempCartId: this.tempCartId,
			contextPath: b.getPath().substr(1)
		}, true);
		var c = sap.ui.core.Component.getOwnerIdFor(this.oView);
		var C = sap.ui.component(c);
		C.oEventBus.publish("ui.s2p.srm.sc.create", "refreshDetail", {
			data: m
		})
	},
	setEmptyCart: function(r) {
		var e = new sap.ui.model.json.JSONModel({
			results: []
		});
		this.oRouter.navTo("noData", {
			viewTitle: "DETAIL_TITLE",
			languageKey: "NO_ITEMS_AVAILABLE"
		}, true);
		this.getView().setModel(e);
		this.oTemplate = new sap.m.ObjectListItem({
			type: "{device>/listItemType}",
			title: "{description}",
			press: jQuery.proxy(this._handleItemPress, this),
			number: "{parts:[{path:'itm_price'},{path:'itm_currency'}],formatter:'ui.s2p.srm.sc.create.util.Formatter.formatPrice'}",
			numberUnit: "{itm_currency}",
			attributes: [new sap.m.ObjectAttribute({
				text: "{vendormat}"
			})],
		});
		this.getList().bindAggregation("items", {
			path: "/results",
			template: this.oTemplate,
			filter: [],
			sorter: null,
		});
		this.registerMasterListBind(this.getList());
		this.getDefaultUserSettings(r)
	},
	onRequestFailed: function(e) {
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: e.message,
			details: e.response.body
		})
	},
	onAfterRendering: function() {},
	onExit: function() {},
	onBeforeRendering: function() {}
});