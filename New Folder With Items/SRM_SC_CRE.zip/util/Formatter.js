/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.util.Formatter");
jQuery.sap.require("sap.ui.core.Element");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
ui.s2p.srm.sc.create.util.Formatter = {
	formatPreferredItem: function(a) {
		if (a == "01") {
			var A = sap.ca.scfld.md.app.Application.getImpl();
			var b = A.getResourceBundle();
			return b.getText("PREFERRED_ITEM")
		} else {
			return ""
		}
	},
	formatQuantity: function(v, u) {
		return sap.ca.ui.model.format.QuantityFormat.FormatQuantityStandard(v, u, 0)
	},
	formatItemCount: function(i) {
		var a = sap.ca.scfld.md.app.Application.getImpl();
		var b = a.getResourceBundle();
		return b.getText("ITEMS_QTY_EX", [i])
	},
	formatPrice: function(v, c) {
		var f = sap.ca.ui.model.format.AmountFormat.getInstance(c, {
			style: "standard"
		});
		return f.format(v)
	},
	formatCreatedOn: function(c) {
		return this.oBundle.ResourceBundle.getText("CREATED_EX", [c])
	}
};