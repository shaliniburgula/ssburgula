/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.util.TrackCaller");
ui.s2p.srm.sc.create.util.TrackCaller = {};
ui.s2p.srm.sc.create.util.TrackCaller.stack = (function() {
	var i = [];
	return {
		add: function(c) {
			i.push({
				item: c
			})
		},
		clear: function() {
			i = []
		},
		getLastCaller: function() {
			if (i.length === 0) {
				return ""
			} else {
				return i[i.length - 1].item
			}
		}
	}
})();