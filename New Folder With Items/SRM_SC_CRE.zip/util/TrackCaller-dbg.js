/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.util.TrackCaller");

ui.s2p.srm.sc.create.util.TrackCaller = {};

ui.s2p.srm.sc.create.util.TrackCaller.stack = (function() {
	var info = [];
	return {
		add : function(callerInfo) {
			info.push({
				item : callerInfo
			});
		},

		clear: function(){
			info = [];
		},
		
		getLastCaller: function(){
			if(info.length === 0){
				return "";
			}
			else{
				return info[info.length-1].item;
			}
		}
				
	};
})();
