/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.util.Formatter");
jQuery.sap.require("sap.ui.core.Element");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

ui.s2p.srm.sc.create.util.Formatter = {

		formatPreferredItem : function(assortmentInd) {
			if (assortmentInd == "01") {
				var oApplication = sap.ca.scfld.md.app.Application.getImpl();
				var oBundle = oApplication.getResourceBundle();
				return oBundle.getText("PREFERRED_ITEM");
			} else {
				return "";
			}
		},
		
		formatQuantity : function(oValue,unitCode){
			return sap.ca.ui.model.format.QuantityFormat.FormatQuantityStandard(oValue,unitCode,0);
		},

		formatItemCount : function(itemCount) {
			var oApplication = sap.ca.scfld.md.app.Application.getImpl();
			var oBundle = oApplication.getResourceBundle();
			return oBundle.getText("ITEMS_QTY_EX", [ itemCount ]);
		},

		formatPrice : function(oValue, sCurrency) {
			var formatter = sap.ca.ui.model.format.AmountFormat.getInstance(sCurrency, {
								style: "standard"
							});
				return formatter.format(oValue);

		},

		formatCreatedOn : function(createdOnText) {
			return this.oBundle.ResourceBundle.getText("CREATED_EX",[ createdOnText ]);
		}

};
