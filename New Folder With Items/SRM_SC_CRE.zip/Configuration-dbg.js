/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("ui.s2p.srm.sc.create.Configuration", {

	oServiceParams: {
        serviceList: [
            {
            	name: "CROSS_CATALOG_SEARCH",
                masterCollection: "CATALOG_ITEM",
                serviceUrl: URI("/sap/opu/odata/srmnxp/CROSS_CATALOG_SEARCH/").directory(),
                isDefault: true,
                mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },
            {
	            name: "SHOPPING_CART",
	            masterCollection: "ShoppingCart",
	            serviceUrl: URI("/sap/opu/odata/srmnxp/SHOPPING_CART/").directory(),
	            isDefault: false,
	            mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },
            /*{
                name: "UTIL",
                masterCollection: "TEXTCollection",
                serviceUrl: URI("/sap/opu/odata/srmnxp/UTIL/").directory(),
                isDefault: false,
                mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },*/
            {
	            name: "getdefusrset",
	            masterCollection: "DefaultUser",
	            serviceUrl: URI("/sap/opu/odata/srmnxp/getdefusrset/").directory(),
	            isDefault: false,
	            mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },
            {
                name: "ACC_ASS_SEARCH_HELP",
                  masterCollection: "CostCenterTabCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/ACC_ASS_SEARCH_HELP/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              },
              {
                name: "COUNTRY_SH_SERVICE",
                  masterCollection: "CountryCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/COUNTRY_SH_SERVICE/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              },
              {
                name: "SRMSHOPPING_CART",
                  masterCollection: "User_PersonalizationCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/SRMSHOPPING_CART/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              },
              
              {
                  name: "ACC_ASSIGN_CATEGORY",
                  masterCollection: "AccountAssignmentCategoryCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/ACC_ASSIGN_CATEGORY/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              }
        ]
    },
    
    /**
     * @inherit
     */
    getServiceList: function () {
        return this.oServiceParams.serviceList;
    }
   
});
