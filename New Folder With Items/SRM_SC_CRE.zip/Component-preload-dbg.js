jQuery.sap.registerPreloadedModules({
"name":"ui/s2p/srm/sc/create/Component-preload",
"version":"2.0",
"modules":{
	"ui/s2p/srm/sc/create/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
//define a root UIComponent which exposes the main view
jQuery.sap.declare("ui.s2p.srm.sc.create.Component");
jQuery.sap.require("ui.s2p.srm.sc.create.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

//new Component
sap.ca.scfld.md.ComponentBase.extend("ui.s2p.srm.sc.create.Component",{
	
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name" : "Master Detail Sample",
		"version" : "1.0.0",
		"library" : "ui.s2p.srm.sc.create",
		"includes" : ["css/shoppingcart.css"],
		"dependencies" : {
			"libs" : [ "sap.m", "sap.me" ],
			"components" : []
		},
		"config": {
			"titleResource": "DISPLAY_NAME_CREATE",
			"resourceBundle": "i18n/i18n.properties",
			"icon": "sap-icon://Fiori2/F0407",
			"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/My_Shopping_Cart.ico",
			"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/57_iPhone_Desktop_Launch.png",
			"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/114_iPhone-Retina_Web_Clip.png",
			"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/72_iPad_Desktop_Launch.png",
			"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/144_iPad_Retina_Web_Clip.png"			
		},
			// Navigation related properties
		"masterPageRoutes": {
			"master": {
				"pattern": "",
				"view": "ui.s2p.srm.sc.create.view.S2"
			}
		},
		
		"detailPageRoutes": {
			"detail": {
				"pattern": "detail/{tempCartId}/{contextPath}",
				"view": "ui.s2p.srm.sc.create.view.S3"
			},
			"noData":{
				"pattern" : "noData/{viewTitle}/{languageKey}",
				"view" : "empty"
			}
		},
	
		"fullScreenPageRoutes" : {
		// fill the routes to your full screen pages in here.
			
			"shoppingCartItems" :{
				"pattern" : "shoppingCartItems/{tempCartId}",
				"view" : "ui.s2p.srm.sc.create.view.ShoppingCartItems"
			},		
			"shoppingCartCheckout" :{
				"pattern" : "shoppingCartCheckout/{tempCartId}",
				"view" : "ui.s2p.srm.sc.create.view.ShoppingCartCheckout"
			}
	
		}
		
	}),

	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
		var oViewData = {
			component: this
	    },
		oView     = sap.ui.view({
						viewName : "ui.s2p.srm.sc.create.Main",
						type : sap.ui.core.mvc.ViewType.XML,
						viewData : oViewData
					}),
		sPrefix   = oView.getId() + "--",
		oEventBus = sap.ui.getCore().getEventBus();
		
		this.oEventBus = {	
			publish: function(channelId, eventId, data) {	
				channelId = sPrefix + channelId;	
				oEventBus.publish(channelId, eventId, data);
			},
			
			subscribe: function(channelId, eventId, data, oListener) {	
				channelId = sPrefix + channelId;
				oEventBus.subscribe(channelId, eventId, data, oListener);
			},
			
			unsubscribe: function(channelId, eventId, data, oListener) {
				channelId = sPrefix + channelId;
				oEventBus.unsubscribe(channelId, eventId, data, oListener);
			}	
		};	
		return oView;
	
	}
});

},
	"ui/s2p/srm/sc/create/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("ui.s2p.srm.sc.create.Configuration", {

	oServiceParams: {
        serviceList: [
            {
            	name: "CROSS_CATALOG_SEARCH",
                masterCollection: "CATALOG_ITEM",
                serviceUrl: URI("/sap/opu/odata/srmnxp/CROSS_CATALOG_SEARCH/").directory(),
                isDefault: true,
                mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },
            {
	            name: "SHOPPING_CART",
	            masterCollection: "ShoppingCart",
	            serviceUrl: URI("/sap/opu/odata/srmnxp/SHOPPING_CART/").directory(),
	            isDefault: false,
	            mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },
            /*{
                name: "UTIL",
                masterCollection: "TEXTCollection",
                serviceUrl: URI("/sap/opu/odata/srmnxp/UTIL/").directory(),
                isDefault: false,
                mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },*/
            {
	            name: "getdefusrset",
	            masterCollection: "DefaultUser",
	            serviceUrl: URI("/sap/opu/odata/srmnxp/getdefusrset/").directory(),
	            isDefault: false,
	            mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
            },
            {
                name: "ACC_ASS_SEARCH_HELP",
                  masterCollection: "CostCenterTabCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/ACC_ASS_SEARCH_HELP/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              },
              {
                name: "COUNTRY_SH_SERVICE",
                  masterCollection: "CountryCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/COUNTRY_SH_SERVICE/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              },
              {
                name: "SRMSHOPPING_CART",
                  masterCollection: "User_PersonalizationCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/SRMSHOPPING_CART/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              },
              
              {
                  name: "ACC_ASSIGN_CATEGORY",
                  masterCollection: "AccountAssignmentCategoryCollection",
                  serviceUrl: URI("/sap/opu/odata/srmnxp/ACC_ASSIGN_CATEGORY/").directory(),
                  isDefault: false,
                  mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
              }
        ]
    },
    
    /**
     * @inherit
     */
    getServiceList: function () {
        return this.oServiceParams.serviceList;
    }
   
});

},
	"ui/s2p/srm/sc/create/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("ui.s2p.srm.sc.create.Main", {

	onInit : function() {
        jQuery.sap.require("sap.ca.scfld.md.Startup");				
		sap.ca.scfld.md.Startup.init('ui.s2p.srm.sc.create', this);
	},
	
	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * 
	 * @memberOf MainXML
	 */
	onExit : function() {
		//exit cleanup code here
	}	
	
});
},
	"ui/s2p/srm/sc/create/Main.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n\txmlns:core="sap.ui.core"\n\txmlns="sap.m"\n\tcontrollerName="ui.s2p.srm.sc.create.Main"\n\tdisplayBlock="true"\n\theight="100%">\n\t<NavContainer\n\t\tid="fioriContent"\n\t\tshowHeader="false">\n\t</NavContainer>\n</core:View>',
	"ui/s2p/srm/sc/create/util/Formatter.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.util.Formatter");
jQuery.sap.require("sap.ui.core.Element");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

ui.s2p.srm.sc.create.util.Formatter = {

		formatPreferredItem : function(assortmentInd) {
			if (assortmentInd == "01") {
				var oApplication = sap.ca.scfld.md.app.Application.getImpl();
				var oBundle = oApplication.getResourceBundle();
				return oBundle.getText("PREFERRED_ITEM");
			} else {
				return "";
			}
		},
		
		formatQuantity : function(oValue,unitCode){
			return sap.ca.ui.model.format.QuantityFormat.FormatQuantityStandard(oValue,unitCode,0);
		},

		formatItemCount : function(itemCount) {
			var oApplication = sap.ca.scfld.md.app.Application.getImpl();
			var oBundle = oApplication.getResourceBundle();
			return oBundle.getText("ITEMS_QTY_EX", [ itemCount ]);
		},

		formatPrice : function(oValue, sCurrency) {
			var formatter = sap.ca.ui.model.format.AmountFormat.getInstance(sCurrency, {
								style: "standard"
							});
				return formatter.format(oValue);

		},

		formatCreatedOn : function(createdOnText) {
			return this.oBundle.ResourceBundle.getText("CREATED_EX",[ createdOnText ]);
		}

};

},
	"ui/s2p/srm/sc/create/util/TrackCaller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.create.util.TrackCaller");

ui.s2p.srm.sc.create.util.TrackCaller = {};

ui.s2p.srm.sc.create.util.TrackCaller.stack = (function() {
	var info = [];
	return {
		add : function(callerInfo) {
			info.push({
				item : callerInfo
			});
		},

		clear: function(){
			info = [];
		},
		
		getLastCaller: function(){
			if(info.length === 0){
				return "";
			}
			else{
				return info[info.length-1].item;
			}
		}
				
	};
})();

},
	"ui/s2p/srm/sc/create/view/S2.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.create.view.S2", {

	onInit : function() {
		// execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		
		//get resource bundle
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		
		this.isRoot=true;
		
		this.oRouter.attachRouteMatched(function(oEvent) { 
			
			if( oEvent.getParameter("name") === "master" && !this.isRoot && 
				Object.keys(oEvent.getParameter("arguments")).length === 0){
				
				var sDir = sap.ui.core.routing.History.getInstance().getDirection("shoppingCartCheckout/"+this.tempCartId);				
				if(sDir === "Unknown"){
					//we are navigating from the checkout page to the master page. 
					//in this case, we want to restore the initial state of the application
					this.isRoot = true;
					
					//FIXME: workaround to clear the search field
					this._oControlStore.oMasterSearchField.clear();
				}
				else{
					//If from any other page, set the master and detail page accordingly
					if(this.getList() !== null){
						var oItem = this.getList().getSelectedItem();
						if(oItem !== null){
							this.setListItem(oItem);
						}
					}
				}				
			}
			this.isRoot = (this.isRoot) ? false : this.isRoot;			
		}, this);
		
		this.setEmptyCart(true);
	},

	/**
	 * @private [Gets the default settings of the user]
	 */
	getDefaultUserSettings : function(bRoute){
		var onRequestSuccess = function(oData, oResponse) {
			this.tempCartId = oData.results[0].TEMP_CART_ID;
			if(!jQuery.device.is.phone){
				//FIXME: When the screen is first loaded, the method navToEmptyView 
				//does not get the title correctly. For solving this issue, we added
				//an explicit route to noData. In all other cases, the normal
				//navToEmptyView returns correct results.
				if(bRoute){
					this.oRouter.navTo("noData",{
						viewTitle: "DETAIL_TITLE",
						languageKey: "NO_ITEMS_AVAILABLE"
					},true);
				}
				else{
					this.navToEmptyView();
				}
			}
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("getdefusrset");
		oDataModel.read("DefaultUserSettings?ts="+ Date.now(), null,null, true,
				jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},

	/**
	 * @override
	 *
	 * @param oItem
	 * @param sFilterPattern
	 * @returns {*}
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {

		if (sFilterPattern.substring(0, 1) === "#") {
			var sTail = sFilterPattern.substr(1);
			var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
			return sDescr.indexOf(sTail) === 0;
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem,sFilterPattern);
		}

	},

	/**
	 * @public [getHeaderFooterOptions Define header & footer options]
	 */
	getHeaderFooterOptions : function() {
		var oOptions = {
			sI18NMasterTitle : "MASTER_TITLE",
			buttonList: []	
		};
		return oOptions;
	},

	isBackendSearch: function(){
		return true;
	},
	
	/**
	 * @public [Back-end search - filter the results based on user input]
	 * @param  {[type]} sFilterPattern - search pattern entered in the search field
	 * @param  {[type]} oBinding
	 */
	applyBackendSearchPattern: function(sFilterPattern, oBinding){
		if(sFilterPattern != "" && sFilterPattern != null){
			this.startReadListData(sFilterPattern);
		}else{
			this.setEmptyCart(false);
		}
	},

	/**
	 * @private [Populate the master list depending upon the filter parameter passed]
	 * @param {[type]} filterItem - search pattern entered in the search field
	 */
	startReadListData: function(filterItem) {

		var onRequestSuccess = function(oData, oResponse) {
			var oModel2 = new sap.ui.model.json.JSONModel(oData.results);
			this.getView().setModel(oModel2);
			this.getList().destroyItems();
			this.getList().bindAggregation("items", {
				path : "/",
				template : this.oTemplate.clone(),
				filter : [],
				sorter : null,
			});
			this.registerMasterListBind(this.getList());
		};
		//Encoding the filter item for special characters
		var encodedfilterItem= encodeURIComponent(filterItem);

		var oDataModel = this.oApplicationFacade.getODataModel();
		oDataModel.read("CATALOG_ITEM?$filter=startswith(description,'"+encodedfilterItem+"')&$top=20", null , null, true,
				jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		
		
	},  

	/**
	 * @private [On selection of an item in the master list, sets the detail page accordingly]
	 * @param oItem - item selected in the master list
	 */
	//On selection of an item in the master list
	setListItem: function(oItem) {
		var bindingContext = oItem.getBindingContext();
		var modelData = bindingContext.oModel.oData[parseInt(bindingContext.sPath.split('/')[1])] ;
		
		this.oRouter.navTo("detail", {
			tempCartId : this.tempCartId,
			contextPath: bindingContext.getPath().substr(1)
		},true);
		
		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView);
        var oComponent   = sap.ui.component(sComponentId);	

        oComponent.oEventBus.publish("ui.s2p.srm.sc.create", "refreshDetail",{
			data:modelData
		});
	},

	/*
	 * In the initial screen, the list should be empty, hence we explicitly create
	 * an empty model here and bind it to the list. When a search is triggered via
	 * the search bar, the list is populated then from the search results. ]
	 */
	setEmptyCart: function(bRoute){
		//empty JSON model
		var oEmptyModel = new sap.ui.model.json.JSONModel({
			results: []
		});
		
		this.oRouter.navTo("noData",{
            viewTitle: "DETAIL_TITLE",
            languageKey: "NO_ITEMS_AVAILABLE"
          },true);


		this.getView().setModel(oEmptyModel);

		this.oTemplate = new sap.m.ObjectListItem({
			type : "{device>/listItemType}",
			title : "{description}",
			press : jQuery.proxy(this._handleItemPress,this),
			number : "{parts:[{path:'itm_price'},{path:'itm_currency'}],formatter:'ui.s2p.srm.sc.create.util.Formatter.formatPrice'}",
			numberUnit : "{itm_currency}",
			attributes : [ new sap.m.ObjectAttribute({
				text : "{vendormat}"
			}) ],
		});

		this.getList().bindAggregation("items", {
			path : "/results",
			template : this.oTemplate,
			filter : [],
			sorter : null,
		});
		this.registerMasterListBind(this.getList());
		
		//get default settings for the user
		this.getDefaultUserSettings(bRoute);		 		
	},
	
	onRequestFailed : function(oError) {
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: oError.message,
			details: oError.response.body
		});
	},
	
	
	onAfterRendering : function(){},
	onExit: function(){},
	onBeforeRendering : function(){}
	
	
});
},
	"ui/s2p/srm/sc/create/view/S2.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n\txmlns="sap.m" controllerName="ui.s2p.srm.sc.create.view.S2">\n\t<Page id="page" title="{i18n>MASTER_TITLE}">\n\t\t<content>\n\t\t\t<List id="list" mode="{device>/listMode}" select="_handleSelect" noDataText="{i18n>SEARCH}" showNoData="false">\n\t\t\t\t\n\t\t\t</List>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footer"></Bar>\n\t\t</footer>\n\t</Page>\n</core:View>',
	"ui/s2p/srm/sc/create/view/S3.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.create.view.S3", {

	onInit : function() {
		// execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		
		// Get instance of the busy dialog
		this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});
	
		this.oRouter.attachRouteMatched(
			function(oEvent) {
				if (oEvent.getParameter("name") === "detail") 
					{
					this.Temp_Cart_Id = oEvent.getParameter("arguments").tempCartId;
					//start the busy dialog now
					this.busyDialog.open();
					this.getTempCartQuantity();
					}
		}, this);
		
        //Using the component ID we subscribe a call back for refreshing the data
        var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
        var oComponent = sap.ui.component(sComponentId);
        
        oComponent.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshDetail", this.getData, this);
	},

	
	getData : function(sChannelId, sEventId, oData) {		
		this.productKey = oData.data.productkey;
		this.description = oData.data.description;
		oData.data.cartValue = 1;
		this.selectedItemModel = new sap.ui.model.json.JSONModel(oData.data);
		this.getView().setModel(this.selectedItemModel, "itemDetail");
		var oHFOptions = this.getHeaderFooterOptions();
	    this.setHeaderFooterOptions(oHFOptions);
	    if(sap.ui.getCore().byId("cartValue"))
	    	sap.ui.getCore().byId("cartValue").setText(this.cartValue);
	},

	
	/**
	 * @private [Gets the quantity of items in temporary cart, and sets it to the shopping cart icon displayed in the header]
	 */
	getTempCartQuantity : function() {
		var onRequestSuccess = function(oData, oResponse) {
			this.cartValue = 0;
			var tempCartId = this.Temp_Cart_Id.trim();
			for ( var i = 0; i < oData.results.length; i++) {
				var existingTempCartId = oData.results[i].TEMP_CART_ID.trim();
				if (tempCartId === existingTempCartId) {
					this.cartValue = parseInt(this.cartValue,10) + 1;
				}
			}
			if(sap.ui.getCore().byId("cartValue"))
		    	sap.ui.getCore().byId("cartValue").setText(this.cartValue);
			
			this.busyDialog.close();
		};

		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		
		//explicitly setting some headers for retrieving the updating information from the server
		//this setting is particularly significant for internet explorer since the page does not 
		//update upon addition of items of the cart
		oDataModel.setHeaders({"Cache-Control":"no-cache, no-store, must-revalidate","Pragma":"no-cache","Expires":"-1"});
		var sPath = "ShoppingcartItemCollection?ts="+ Date.now();
		oDataModel.read(sPath,null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},

	
	/**
	 * @private [For navigation to the ShoppingCartItems page]
	 */
	gotoCartItem : function() {
		this.oRouter.navTo("shoppingCartItems", {
			tempCartId : this.Temp_Cart_Id
		},true);
	},
	/**
	 * @public [ getHeaderFooterOptions Define Header and Footer for the Detail
	 *         Screen ]
	 */
	getHeaderFooterOptions: function(){		
		
		        var that = this;
				return {
					oHeaderBtnSettings:{
						sId : "cartValue",
//						text : this.cartValue,
						sIcon:'sap-icon://cart-full',
						onBtnPressed : function(){
							that.gotoCartItem();} 	},
					oEditBtn:{
						sId : "addToCartBtn",
						sI18nBtnTxt : "ADD_TO_CART_DETAIL",
						type : "Accept",
						onBtnPressed : function(){that.onAddToCart();}}, 	
					oJamOptions : {
						oDiscussSettings : {
							object: {
								//as CROSS_CATALOG_SEARCH is maintained as default in configuration.js. No need to pass any parameter in getODataModel 
								id: this.oApplicationFacade.getODataModel().sServiceUrl+"CATALOG_ITEM('"+this.productKey+"')",
             					type: this.oApplicationFacade.getODataModel().sServiceUrl+"$metadata#CATALOG_ITEM",
            					name: this.description
          			                }
											}
           
									},
									bSuppressBookmarkButton : true
						};
	},

	/**
	 * @private [Gets the current temp cart details
	 * and on success callback updates the temp cart details in accordance with the currently added item]
	 */
	onAddToCart : function() {
		
		//start the busy dialog now
		this.busyDialog.open();
		   
		var onRequestSuccess = function(oData, oResponse) {
			var otempCartModel = new sap.ui.model.json.JSONModel(oData);
			jQuery.proxy(this.addToCartItemDetails(otempCartModel),this);
			this.getTempCartQuantity();
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		var sPath = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts="+ Date.now();
		oDataModel.read(sPath,
				null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},

	/**
	 * @private [In case the item added is already in the cart, makes a clone of the itemData in the format of the required pay load]
	 * @param selectedObject 
	 * @returns {___anonymous3662_4005}
	 */
	_cloneItemData : function(selectedObject) {
		return {
			'ITEM_NO' : selectedObject.ITEM_NO,
			'TEMP_CART_ID' : selectedObject.TEMP_CART_ID,
			'DESCRIPTION' : selectedObject.DESCRIPTION,
			'QUANTITY' : selectedObject.QUANTITY,
			'UNIT' : selectedObject.UNIT,
			'PRICE' : selectedObject.PRICE,
			'CURRENCY' : selectedObject.CURRENCY,
			'PRODUCTKEY' : selectedObject.PRODUCTKEY,
		};
	},

	/**
	 * @private [If the item added was not already in the cart, creates a new itemData in the format of the required pay load]
	 * @param tempCartId
	 * @param selectedObject
	 * @returns {___anonymous4352_4528}
	 */
	_createItemData : function(tempCartId, selectedObject) {
		var itemData = {
			'ITEM_NO' : '',
			'TEMP_CART_ID' : '',
			'DESCRIPTION' : '',
			'QUANTITY' : '',
			'UNIT' : 'EA',
			'PRICE' : '',
			'CURRENCY' : '',
			'PRODUCTKEY' : '',
		};

		itemData.TEMP_CART_ID = tempCartId;
		itemData.DESCRIPTION  = selectedObject.description;    
		itemData.CURRENCY 	  = selectedObject.itm_currency;
		itemData.UNIT 		  = selectedObject.unit;
		itemData.PRICE 		  = selectedObject.itm_price;
		return itemData;
	},

	
	/**
	 * @private [If the item to be added is already in the cart, updates the existing item details in the temporary cart
	 * else if the item is added for the first time, then creates the item in the temporary cart] 
	 * @param tempCartModel - model corresponding to the current temporary cart 
	 */
	addToCartItemDetails : function(tempCartModel) {
		
		var selectedModel = new sap.ui.model.json.JSONModel();
		var oDataModel    = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		selectedModel = null;
		
		//this.selectedItemModel - Item selected from master list
		if (this.selectedItemModel != null) {
			var selectedItemProductKey = this.selectedItemModel.oData.productkey.trim();
			//Checks whether the item with this product key already exists in the temp cart
			for ( var i = 0; i < tempCartModel.oData.results.length; i++) {
				var existingProductKey = tempCartModel.oData.results[i].PRODUCTKEY.trim();
				if (existingProductKey === selectedItemProductKey|existingProductKey === jQuery.sap.encodeURL(selectedItemProductKey)) {
					selectedModel = tempCartModel.oData.results[i];
					break;
				}
			}
			
			var itemData = this._createItemData(this.Temp_Cart_Id,this.selectedItemModel.oData);
			
			if (selectedModel != null) {
				//If the item to be added is already in the cart, update the corresponding item details in the temp cart
				itemData = this._cloneItemData(selectedModel);
				//Truncating description to 40 characters
				itemData.DESCRIPTION = this.selectedItemModel.oData.description.substring(0,39);
				itemData.UNIT = this.selectedItemModel.oData.unit_cu;
				itemData.QUANTITY   = (parseInt(itemData.QUANTITY, 10) + 1).toString();
				itemData.PRICE = itemData.PRICE.split(".")[0]+"."+itemData.PRICE.split(".")[1].slice(0,2);
				this.updateTriggered = true;
				oDataModel.update("ShoppingcartItemCollection(ITEM_NO='"+ itemData.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')",
						itemData,null,jQuery.proxy(this.onItemAdded,this),jQuery.proxy(this.onRequestFailed, this));
			} 
			else {
				//If the item to be added is not already in the cart, create the item in the temp cart
				itemData.UNIT = this.selectedItemModel.oData.unit_cu;
				//Truncating description to 40 characters
				itemData.DESCRIPTION = this.selectedItemModel.oData.description.substring(0,39);
				itemData.PRODUCTKEY = jQuery.sap.encodeURL(this.selectedItemModel.oData.productkey);
				itemData.QUANTITY   = ( this.selectedItemModel.oData.minorderqty ? this.selectedItemModel.oData.minorderqty : 1 ) + "";
				itemData.PRICE = itemData.PRICE.split(".")[0]+"."+itemData.PRICE.split(".")[1].slice(0,2);
				this.updateTriggered = false;
				oDataModel.create("ShoppingcartItemCollection",itemData,null,
						jQuery.proxy(this.onItemAdded,this),jQuery.proxy(this.onRequestFailed,this));
			}
		}
	},
			
	onRequestFailed: function(oError){
		//close the busy dialog first
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type : sap.ca.ui.message.Type.ERROR,
			message : oError.message,
			details : oError.response.body
		});
	},
	
	onItemAdded: function(){
		var cartValue = sap.ui.getCore().byId("cartValue").getText();
		if(!this.updateTriggered){
			cartValue = parseInt(cartValue,10) + 1;
			sap.ui.getCore().byId("cartValue").setText(cartValue);
		}
		sap.m.MessageToast.show(this.oBundle.getText("ADD_CART_SUCCESS"));
		this.busyDialog.close();
	},
	
	navToEmptyView: function(){
		this.oRouter.navTo("noData",null,true);
	},
	
	onAfterRendering : function(){},
	onExit: function(){},
	onBeforeRendering : function(){}
});
//sap.ushell.ui.footerbar.JamDiscussButton.prototype.setEnabled = function (bEnabled) {
//
//	sap.m.Button.prototype.setEnabled.call(this, bEnabled);
//
//	};
},
	"ui/s2p/srm/sc/create/view/S3.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View controllerName="ui.s2p.srm.sc.create.view.S3"\n\txmlns="sap.m" xmlns:form="sap.ui.layout.form" xmlns:sap.ui.layout="sap.ui.layout"\n\txmlns:sap.ui.core="sap.ui.core">\n\t<Page id="SHOPPING_CART_ITEMS_PAGE" navButtonTap="_navBack"\n\t\ttitle="{i18n>DETAIL_TITLE}" class="sapUiFioriObjectPage">\n\t\t<content>\n\t\t\t<ObjectHeader id="ITEM_DETAIL_OBJECT_HEADER" title="{itemDetail>/description}"\n\t\t\t\tnumber="{parts:[{path:\'itemDetail>/itm_price\'},{path:\'itemDetail>/itm_currency\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPrice\'}"\n\t\t\t\tnumberUnit="{itemDetail>/itm_currency}" introActive="false"\n\t\t\t\ttitleActive="false" iconActive="false">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{itemDetail>/vendormat}"\n\t\t\t\t\t\tactive="false"></ObjectAttribute>\n\t\t\t\t\t<ObjectAttribute text="{itemDetail>/longtext}"\n\t\t\t\t\t\tactive="false"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t\t<firstStatus>\n\t\t\t\t\t<ObjectStatus\n\t\t\t\t\t\ttext="{path:\'itemDetail>/assortmentind\',formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPreferredItem\'}"></ObjectStatus>\n\t\t\t\t</firstStatus>\n\t\t\t</ObjectHeader>\n\t\t\t<form:SimpleForm id="myForm1" class="detailForm"\n\t\t\t\tminWidth="1024" editable="false">\n\t\t\t\t<form:content>\n\t\t\t\t\t<sap.ui.core:Title text="{i18n>INFORMATION}" id="info"></sap.ui.core:Title>\n\t\t\t\t\t<Label text="{i18n>CATEGORY}" id="catagory">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/matgrouptext}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t<Label text="{i18n>MANUFACTURER}" id="manufacturer">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData \n\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/manufactname}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t<Label text="{i18n>MANUFACTURER_PART_NUMBER}" id="part_Number">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/manufactcode}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t<Label text="{i18n>SUPPLIER}" id="supplier">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/vendor_name}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Extension point added for more information  -->\n\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extMoreInfo1"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\t\n\t\t\t\t</form:content>\n\t\t\t</form:SimpleForm>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footerBar" translucent="true">\n\t\t\t\t\n\t\t\t</Bar>\n\t\t</footer>\n\n\t</Page>\n</sap.ui.core:View>',
	"ui/s2p/srm/sc/create/view/ShoppingCartCheckout.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.model.type.Number");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartCheckout",{

       onInit : function() {
              this.oBundle = this.oApplicationFacade.getResourceBundle();
              
              // Get instance of the busy dialog
      		  this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});
      		  
              this.oRouter.attachRouteMatched(function(oEvent) {
            	  if (oEvent.getParameter("name") === "shoppingCartCheckout") {
            		  this.tempCartId = oEvent.getParameter("arguments").tempCartId;
            		  
                  //start the busy dialog now
       			  this.busyDialog.open();
                  this.getUserPersonalizationsettings();
                  this.getTempCartItems();
            	  }
              }, this);              
              
              //Using the component ID we subscribe a call back for refreshing the data
              var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
              var oComponent   = sap.ui.component(sComponentId);
              
              oComponent.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", jQuery.proxy(this.getData,this),this);
              
              this.co_area = "";
              this.country_key = "";
              
              //To populate the country help dialog box + To give suggestion items for the input field for Country
              this.oCountryModel = this.createModel('Country', 'CountryCollection', null, "COUNTRY_SH_SERVICE");
              
              //To populate the account assignment help dialog box + To give suggestion items for the input field for Account Assignment
              //Hard coding used
              this.jsonModel = new sap.ui.model.json.JSONModel({
                                    results : [{accAssg : this.oBundle.getText("COST_CENTER")},
                                               {accAssg : this.oBundle.getText("INTERNAL_ORDER")} 
                                    		  ]});
              this.getView().setModel(this.jsonModel,"AccountAssignment");

              this.setHeaderFooterOptions(this.createHeaderFooterOptions());
              this.getView().byId("dateplusseven").setDisplayFormat(sap.m.getLocaleData().getDatePattern("medium"));
       },
       
       getData : function(sChannelId, sEventId, value) {
          var totalValue = value;
          this.getView().byId("totalValue").setValue(totalValue.totalValue);             
       },

       /**
        * @private [generic function for creating a model after oData read]
        * @param modelName - name to be assigned to the model created
        * @param sParam - service collection name
        * @param sFilter - filter parameter if any
        * @param sModel - corresponding to the service meta data mentioned in Configuration.js
        * @returns oModel if modelName of the model being created is 'Country'
        * @returns oModelName in all other cases
        */
       createModel : function(modelName, sParam, sFilter, sModel) {
    	   	
    	   	  var oModel;
              var onRequestSuccess = function(oData, oResponse) {
                     oModel = new sap.ui.model.json.JSONModel(oData);
                     oModel.setSizeLimit(500);
                     this.getView().setModel(oModel, modelName);
              };
              
              var oDataModel = this.oApplicationFacade.getODataModel(sModel);
              oDataModel.read(sParam, null, sFilter, false,jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
              if(modelName === "Country")
            	  return oModel;
              else
            	  return modelName;
       },

       /**
        * @private [Gets the personalization settings of the user]
        */
       getUserPersonalizationsettings : function() {
              var onRequestSuccess = function(oData, oResponse) {
                     this.oUserDefaults = new sap.ui.model.json.JSONModel(oData.results[0]);
                     this.getView().setModel(this.oUserDefaults,"personalCollection");
                     this.getView().byId("dateplusseven").setValue(this.sevenDaysFromNowDateAsString());
              };

              var oDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
              oDataModel.read("User_PersonalizationCollection?ts="+Date.now(),null, null, false, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Adds 7 days to the current date, for calculating the default delivery date]
        */
       sevenDaysFromNowDateAsString : function() {
              var date = new Date();
              date.setDate(date.getDate() + 7);
              var valueFormat = this.getView().byId('dateplusseven').getValueFormat();
              return sap.ca.ui.model.format.DateFormat.getDateInstance({
                     pattern : valueFormat
              }).format(date);
       },

       /**
        * @private [Gets the temporary cart details and binds it to the table displaying the items in the cart (Order Summary)]
        */
       getTempCartItems : function() {
              var onRequestSuccess = function(oData, oResponse) {
                     var TempCartModel = new sap.ui.model.json.JSONModel(oData);
                     for ( var i = 0; i < TempCartModel.oData.results.length; i++) {
                           TempCartModel.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(TempCartModel.oData.results[i].QUANTITY) * parseFloat(TempCartModel.oData.results[i].PRICE));
                     }

                     this.getView().byId("MaterialList").setModel(TempCartModel, "ShoppingCartItems");
                     var itemCount = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(TempCartModel.oData.results.length);
                     this.getView().byId("MaterialList").setHeaderText(itemCount);
                     //last place for all data to be fetched, stop the busy dialog now
         			 this.busyDialog.close();
              };

              var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
              this.getDefaultUserSettings();
              var tempcartId = this.getTempCartId();
              oDataModel.read("ShoppingcartCollection(TEMP_CART_ID='"+ tempcartId + "')/ShoppingCartItemNavigation?ts="+Date.now(),null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Discards the temporary cart on event of Cancel]
        */
       discardTempCart : function(tempCartId, objectId) {
    	   	  //start the busy dialog now
			  this.busyDialog.open();
              this.OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
              this.OShoppingCartDataModel.update(
                           "HOLD_DOCUMENT?TEMP_CART_ID='" + tempCartId
                           + "'&OBJECT_ID='" + objectId
                           + "'", null, {
                                  oContext : null,
                                  fnSuccess : jQuery.proxy(function(){this.busyDialog.close();},this),
                                  fnError : jQuery.proxy(this.onRequestFailed, this)
                           });
       },

       /**
        * @private [Gets the temporary cart id]
        */
       getTempCartId : function() {
              return this.oDefaultSettings.oData.results[0].TEMP_CART_ID;
       },

       /**
        * @private [Gets the default user settings] 
        */
       getDefaultUserSettings : function() {
              var onRequestSuccess = function(oData, oResponse) {
                     this.oDefaultSettings = new sap.ui.model.json.JSONModel(oData);
              };

              var oDataModel = this.oApplicationFacade.getODataModel("getdefusrset");
              oDataModel.read("DefaultUserSettings?ts="+Date.now(), null, null,
                           false, jQuery.proxy(onRequestSuccess, this),
                           jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Gets the object id of the cart]
        * @returns objectid
        */
       getCartObjectId : function() {
              return this.oDefaultSettings.oData.results[0].OBJECT_ID;
       },

       /**
        * @private [Cancel dialog box displayed.
        * On confirmation, discards the temporary cart otherwise remains in the checkout screen] 
        */
       onCancel : function() {
              var that = this;
              var cancelText = new sap.m.Text({
                     text : that.oBundle.getText("CANCEL_MESSAGE")
              });
              var cancelDialog = null;
              cancelDialog = new sap.m.Dialog({
                     content : [ cancelText ],
                     title : that.oBundle.getText("CANCEL_TITLE"),
                     leftButton : new sap.m.Button({
                           text : this.oBundle.getText("YES"),
                           press : function() {
                                  that.discardTempCart(that.getTempCartId(),that.getCartObjectId());
                                  cancelDialog.close();
                                  that.oRouter.navTo("master",null,true);
                                  that.getView().byId("noteToApprover").setValue("");
                           }
                     }),
                     rightButton : new sap.m.Button({
                           text : this.oBundle.getText("NO"),
                           press : function() {
                                  cancelDialog.close();
                           }
                     })
              }).addStyleClass("sapUiPopupWithPadding");

              cancelDialog.open();
       },

       /**
        * @private [Gets the items in the SRM Cart]
        * @param successCallback
        * @param cartObjectId
        * @param basync
        */
       getSRMCartItems : function(successCallback, cartObjectId,basync) {

              if (typeof (basync) === undefined) {
                     basync = true;
              }
              var onRequestSuccess = jQuery.proxy(function(oData,oResponse) {
                     if (successCallback) {
                           successCallback.call(oData, oResponse);
                     }
              }, this);

              var OSRMShoppingCartDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
              var sPath = "SRMShoppingCartCollection(OBJECT_ID='"+ cartObjectId+ "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartItemNavigation?ts="+Date.now();
              OSRMShoppingCartDataModel.read(sPath, null, null,basync, onRequestSuccess, jQuery.proxy(this.onRequestFailed, this));
       },

       /**
        * @private [Actual SRM Shopping Cart is saved with all the details]
        * @param successCallback
        * @param objectID
        * @param oDefaultSettings
        * @param approveNotes
        */
       saveSRMShoppingCart : function(successCallback, objectID,oDefaultSettings, approveNotes) {
              
    	     var oItem;
             var that=this;
             
             //Fetching the values required for oItem, which will later be send as payload for POST call to SRMShoppingCartCollection
             //and updating the values of those fields edited by the user 
             var onRequestSuccess1 = jQuery.proxy(function(oData,oResponse) {
                  oItem = oData;
                  oItem.CURRENCY = oDefaultSettings.oData.results[0].CURRENCY;
                  oItem.CITY = this.getView().byId("city").getValue();
                  oItem.COUNTRY = that.country_key;
                  oItem.STREET = this.getView().byId("street").getValue();
                  oItem.APRV_NOTE = approveNotes;

              }, this);
              var OSRMShoppingCartDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
              var sPath = "SRMShoppingCartCollection(OBJECT_ID='"+ objectID+ "',DOC_MODE='DISPLAY',WIID='000000000000')?ts="+Date.now();
              OSRMShoppingCartDataModel.read(sPath, null, null,false, onRequestSuccess1, jQuery.proxy(this.onRequestFailed, this));
            
              //In case the user has not used valueHelpRequest for Country, that.country_key would remain empty.
              //So comparing the value entered in the Country input field to that in the oCountryModel to get the corresponding country key
              for(var i=0;i<that.oCountryModel.oData.results.length;i++){
            	  if(this.getView().byId("input_assisted1").getValue() === that.oCountryModel.oData.results[i].CountryName){
            		  oItem.COUNTRY = that.oCountryModel.oData.results[i].CountryKey;
            		  that.country_key = that.oCountryModel.oData.results[i].CountryKey;
            	  }
              }
              
              //Extension hook for saving extMoreInfo2
              /**
               * @ControllerHook Extension hook for saving  
               * This hook can be used to save the fields through extensibility
               * @callback sap.ca.scfld.md.controller.BaseFullscreenController~extHook1
               * @return {void}  ...
              */
             // var extensionHook1 = this.onDataRecieved1;
              if(this.extHook1){
        			this.extHook1();
              };
              //Extension hook for saving extMoreInfo3
              /**
               * @ControllerHook Extension hook for saving  
               * This hook can be used to save the fields through extensibility
               * @callback sap.ca.scfld.md.controller.BaseFullscreenController~extHook2
               * @return {void}  ...
              */
        	  //var extensionHook2 = this.onDataRecieved2;
        	  if(this.extHook2){
        			this.extHook2();
        	  };
              
              //costAssignment is made fit to the format of the required pay load
              var costAssignment = {};
              costAssignment.ACC_NO = '0001';
              costAssignment.WIID = '000000000000';
              costAssignment.DISTR_PERC = '100.0';
              costAssignment.G_L_ACCT = this.oUserDefaults.oData.G_L_ACCT;
              
              if (this.co_area === "") {
                     this.co_area = this.oUserDefaults.oData.CO_AREA;
              }
              
              //If accountAssignment selected is CostCenter
              var costAssignmentField = this.getView().byId("input_assisted3").getValue().trim();
              var costCenter = this.oBundle.getText("COST_CENTER").trim();
              var internalOrder = this.oBundle.getText("INTERNAL_ORDER").trim();
              if (costAssignmentField === costCenter) {
                     costAssignment.COST_CTR = this.getView().byId("input_assisted2").getValue();
                     costAssignment.ACC_CAT = 'CC';
                     costAssignment.CO_AREA = that.co_area;
              }
              //If accountAssignment selected is InternalOrder
              else if (costAssignmentField === internalOrder) {
                     costAssignment.ORDER_NO = this.getView().byId("input_assisted2").getValue();
                     costAssignment.ACC_CAT = 'OR';
                     costAssignment.CO_AREA = that.co_area;
              } else if (costAssignmentField === "") {
                     costAssignment.CO_AREA = this.oUserDefaults.oData.CO_AREA;
              }

              //addressAssignment is made fit to the format of the required pay load
              var addressAssignment = {};
              addressAssignment.ShoppingCartID = objectID;
              addressAssignment.WIID = '000000000000';
              addressAssignment.City = this.getView().byId("city").getValue();
              addressAssignment.Name = this.oUserDefaults.oData.REQUESTOR_DESC;
              addressAssignment.CountryName = this.getView().byId("input_assisted1").getValue();
              addressAssignment.Country = that.country_key;
              addressAssignment.Street = this.getView().byId("street").getValue();
              addressAssignment.PostalCode1 = this.getView().byId("zip").getValue();
              
              var fnSuccessCallback = function() {
                     successCallback.call();
              };
              
              this.getSRMCartItems(jQuery.proxy(function(oData,oResponse) {
                  var OSRMShoppingCartDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
                  var aBatchArray = new Array();
                  for ( var i = 0; i < oData.data.results.length; i++) {
                	  oData.data.results[i].DELIV_DATE = this.getView().byId("dateplusseven").getDateValue() === null ? "": this.getView().byId("dateplusseven").getDateValue();
                      var dateUI = new Date();   
                      dateUI.setUTCMonth(oData.data.results[i].DELIV_DATE.getMonth());
                      dateUI.setUTCDate(oData.data.results[i].DELIV_DATE.getDate());
                      dateUI.setUTCFullYear(oData.data.results[i].DELIV_DATE.getFullYear());
                      dateUI.setUTCHours(00);
                      dateUI.setUTCMinutes(00);
                      dateUI.setUTCSeconds(00);
                      oData.data.results[i].DELIV_DATE = dateUI;
                      delete oData.data.results[i].__metadata;
                      delete oData.data.results[i].SourceofSupplyNavigation;
                      delete oData.data.results[i].ItemAccountAssignmentNavigation;
                      delete oData.data.results[i].ItemApproverNavigation;
                      delete oData.data.results[i].ItemAttachmentNavigation;
                      delete oData.data.results[i].ItemShippingAddressNavigation;
                      aBatchArray.push( OSRMShoppingCartDataModel.createBatchOperation(
                                                       "SRMShoppingCartItemCollection(NUMBER_INT='"
                                                       + oData.data.results[i].NUMBER_INT
                                                       + "',OBJECT_ID='"
                                                       + objectID
                                                       + "',DOC_MODE='',WIID='000000000000')",
                                                       "PUT",
                                                        oData.data.results[i]));
                      
                	  costAssignment.NUMBER_INT = oData.data.results[i].NUMBER_INT;
                              aBatchArray.push( OSRMShoppingCartDataModel.createBatchOperation(
                                                                "AccountAssignmentCollection(NUMBER_INT='"
                                                                + costAssignment.NUMBER_INT
                                                                + "',OBJECT_ID='"
                                                                + objectID
                                                                + "',ACC_NO='0001',DOC_MODE='',WIID='000000000000')",
                                                                "PUT",
                                                                costAssignment)
                                                                );
                        addressAssignment.ItemNumber = oData.data.results[i].NUMBER_INT;
                        aBatchArray.push( OSRMShoppingCartDataModel.createBatchOperation(
                                                                "ShippingAddressCollection(ItemNumber='"
                                                                + costAssignment.NUMBER_INT
                                                                + "',ShoppingCartID='"
                                                                + objectID
                                                                + "',DOC_MODE='',WIID='000000000000')",
                                                                "PUT",
                                                                addressAssignment) );
                        
                       }
                  // Header update of shopping cart is obselete because of which removing the header update
                  //Deleting extra meta data from oItem before sending it as payload
//                  delete oItem.__metadata;
//                  delete oItem.HeaderMessageNavigation;
//                  delete oItem.HeaderPersonalisedDataNavigation;
//                  delete oItem.ShoppingCartAddressnavigation;
//                  delete oItem.ShoppingCartApprovalNavigation;
//                  delete oItem.ShoppingCartItemBasicDataNavigation;
//                  delete oItem.ShoppingCartItemNavigation;
//                  delete oItem.ShoppingCartNotesNavigation;
//                  delete oItem.ShoppingCartReviewerNavigation;
//
//                  aBatchArray.push(OSRMShoppingCartDataModel.createBatchOperation(
//                                                     "SRMShoppingCartCollection",
//                                                     "POST",
//                                                     oItem) );
                OSRMShoppingCartDataModel.addBatchChangeOperations(aBatchArray);
                OSRMShoppingCartDataModel.submitBatch(fnSuccessCallback,jQuery.proxy(this.onRequestFailed,this));
                                    
                }, this), objectID);

       },

       /**
        * @private [Actual SRM Shopping Cart is created]
        * @param successCallback
        * @param tempCartId
        * @param objectID
        */
       saveTempCart : function(successCallback, tempCartId, objectID) {
              var itemData = {TEMP_CART_ID : this.getTempCartId(),
                              CHECKOUT : "X",
                              WAERS : this.oDefaultSettings.oData.results[0].CURRENCY};
              if (objectID !== null) {
                     itemData.OBJECT_ID = objectID;
              };

              var fnErrorCallback = function(oError) {
            	     //close the busy dialog first
       			     this.busyDialog.close();
                     jQuery.sap.require("sap.ca.ui.message.message");
                     sap.ca.ui.message.showMessageBox({
                           type : sap.ca.ui.message.Type.ERROR,
                           message : oError.message,
                           details : jQuery.parseJSON(oError.response.body).error.message.value
                     });
              };
              var fnSuccessCallback = jQuery.proxy(function(oData,oResponse) {
                     if (successCallback) {
                           successCallback.call(oData, oResponse);
                     }
              }, this);

              var approveNotes = this.getView().byId("noteToApprover").getValue();

              var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
              oDataModel.create(
                           "ShoppingcartCollection",itemData, null, jQuery.proxy(function(oData,oResponse) {
                                  this.saveSRMShoppingCart(fnSuccessCallback,oData.OBJECT_ID,this.oDefaultSettings,approveNotes);
                           }, this), jQuery.proxy(fnErrorCallback, this));

       },

       /**
        * @private [Submits the temporary cart]
        * @param successCallback
        * @param tempCartId
        * @param objectID
        */
       submitTempCart : function(successCallback, tempCartId,objectID) {
              var itemData = {
                           TEMP_CART_ID : tempCartId,
                           ORDER : "X"
              };

              var fnErrorCallback = function(oError) {
            	     //close the busy dialog first
       			     this.busyDialog.close();
	       			  var fnClose = function(){
	                      if(sap.ui.getCore().byId("SCNumber")){
	                      sap.ui.getCore().byId("SCNumber").destroy();
	                      }
	                   };
                     jQuery.sap.require("sap.ca.ui.message.message");
                     sap.ca.ui.message.showMessageBox({
                           type : sap.ca.ui.message.Type.ERROR,
                           message : oError.message,
                           details : jQuery.parseJSON(oError.response.body).error.message.value
                     }, fnClose);
              };
              var fnSuccessCallback = jQuery.proxy(function(oData, oResponse) {
            	  var OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
                  OShoppingCartDataModel.create("ShoppingcartCollection",itemData,null,
                		  		jQuery.proxy(function(oData,oResponse) {if (successCallback) {successCallback.call(oData,oResponse);}},this),
                		  		jQuery.proxy(fnErrorCallback,this));
                  }, this);

              this.saveTempCart(fnSuccessCallback, tempCartId,objectID);
       },

       /**
        * @private [Submits the temporary cart - calls submitTempCart function and displays confirmation dialog on success]
        */
       onSubmit : function() {
    	      //start the busy dialog now
   			  this.busyDialog.open();
              var that = this;
             
              
              var accountAssignmentField = this.getView().byId("input_assisted2").getValue().trim();
              //If AccountAssignmentType field is left empty
              if (accountAssignmentField === "") {
            	  	 //close the busy dialog first
       			  	 this.busyDialog.close();
                     sap.m.MessageBox.alert(this.oBundle.getText("WARNING_ON_SUBMIT"));
                     return;
              }
              var countryStatus = this.getCountryStatus();
              if (countryStatus != true) {
         	  	 //close the busy dialog first
    			  	 this.busyDialog.close();
                  sap.m.MessageBox.alert(this.oBundle.getText("WARNING_COUNTRY_ON_SUBMIT"));
                  return;
           }
              var confirmationDone = null;
              confirmationDone = new sap.m.Dialog({
                     title : this.oBundle.getText("CONFIRMATION"),
                     rightButton : new sap.m.Button({
                           text : this.oBundle.getText("DONE"),
                           press : function() {
                                  confirmationDone.close();
                                  confirmationDone.destroyContent();
                                  that.oRouter.navTo("master",null,true);
                                  that.getView().byId("noteToApprover").setValue("");
                           }
                     })
              }).addStyleClass("sapUiPopupWithPadding");

              //Calls submitTempCart function, which in turn displays success dialog on success call back
              this.submitTempCart(jQuery.proxy(function(oData,
                           oResponse) {
            	  	 //close the busy dialog first
          			 this.busyDialog.close();
          			 var confirmSuccess = new sap.m.Text("SCNumber");
         			 confirmationDone.addContent(confirmSuccess);
                     confirmSuccess.setText(that.oBundle.getText("SUCCESSFUL").replace("{0}",oData.data.OBJECT_ID));
                     confirmationDone.open();
              }, this), this.getTempCartId(), this.getCartObjectId());

       },

       /**
        * @private [Input assistance for country selection]
        * @param oEvent
        */
       onCountryValueHelpRequest : function(oEvent) {
    	   	  var that = this;
              var title1            = this.oBundle.getText("SELECT_COUNTRY");
              var path              = "/results";
              var title2            = "{CountryName}";
              var description  = "{CountryKey}";
              var filter            = "CountryName";
              var modelName         = "Country";        
              var countryField = this.getView().byId("input_assisted1");
              
              // Handling of both confirm and cancel; clear the filter
              var handleClose = function(oEvent) {
                     var oSelectedItem = oEvent
                     .getParameter("selectedItem");
                     if (oSelectedItem) {
                           countryField.setValue(oSelectedItem.getTitle());
                           that.country_key = oSelectedItem.getDescription();
                     }
                     oEvent.getSource().getBinding("items").filter([]);
              };

              this._valueHelpSelectDialog = new sap.m.SelectDialog(
              {
                     title : title1,
                     items : {
                           path : path,
                           template : new sap.m.StandardListItem(
                                         {
                                                title : title2,
                                                description : description,
                                                active : true
                                         })
                     },
                     search : function(oEvent) {
                           var sValue = oEvent.getParameter("value");
                           var oFilter = new sap.ui.model.Filter(filter,sap.ui.model.FilterOperator.Contains,sValue);
                           oEvent.getSource().getBinding("items").filter([ oFilter ]);
                     },
                     confirm : handleClose,
                     cancel : handleClose
              });
              this._valueHelpSelectDialog.setModel(this.getView().getModel(modelName));
              this._valueHelpSelectDialog.open();
       },

       /**
        * @private [Input assistance for account assignment selection]
        * @param oEvent
        */
       onAssignmentTypeValueHelpRequest : function(oEvent) {

              var that=this;

              var accountType = this.getView().byId("input_assisted3").getValue();
              var assignmentField = this.getView().byId("input_assisted2");
              
              var title1 = "";
              var title2 = "";
              var path   = "";           
              var description = "";
              var filter      = "";
              var modelName   = "";
              var info        = "";
              
              switch(accountType){
                     case this.oBundle.getText("COST_CENTER"):
                           modelName = this.createModel('CostCenter','CostCenterTabCollection', null,"ACC_ASS_SEARCH_HELP");
                           title1 = this.oBundle.getText("COST_ASSIGNMENT");
                           path = "/results";
                           title2 = "{COST_CTR}";
                           description = "{CC_DESCRIPTION}";
                           filter = "COST_CTR";
                           info = "{CO_AREA}";
                           break;
                     case this.oBundle.getText("INTERNAL_ORDER"):
                           modelName = this.createModel('InternalOrder','OrderNoTabCollection', null,"ACC_ASS_SEARCH_HELP");
                           title1          = this.oBundle.getText("COST_ASSIGNMENT");
                           path = "/results";
                           title2 = "{ORDER_NO}";
                           description = "{OR_DESCRIPTION}";
                           filter = "ORDER_NO";
                           info = "{CO_AREA}";
                           break;
                     case "":
                    	   //close the busy dialog first
              			   this.busyDialog.close();
                           sap.m.MessageBox.alert(this.oBundle.getText("SELECT_ACCOUNT_ASSIGNMENT_ALERT"));
                           return;                           
                     default:
                    	   //close the busy dialog first
              			   this.busyDialog.close();
                           sap.m.MessageBox.alert(this.oBundle.getText("SELECT_VALID_ACCOUNT_ASSIGNMENT"));
                           return;                           
              }
              
              // Handling of both confirm and cancel; clear the filter
              var handleClose = function(oEvent) {
                     var oSelectedItem = oEvent.getParameter("selectedItem");
                     if (oSelectedItem) {
                           assignmentField.setValue(oSelectedItem.getTitle());
                           that.co_area = oSelectedItem.getInfo();
                     }
                     oEvent.getSource().getBinding("items").filter([]);
              };

              // Create a SelectDialog and display it; bind to the same model as for the suggested items
              this._valueHelpSelectDialog = new sap.m.SelectDialog(
              {
                     title : title1,
                     items : {
                           path : path,
                           template : new sap.m.StandardListItem(
                                         {
                                                title : title2,
                                                description : description,
                                                info: info,
                                                active : true
                                         })
                     },
                     search : function(oEvent) {
                           var sValue = oEvent.getParameter("value");
                           var oFilter = new sap.ui.model.Filter(filter,sap.ui.model.FilterOperator.Contains,sValue);
                           oEvent.getSource().getBinding("items").filter([ oFilter ]);
                     },
                     confirm : handleClose,
                     cancel : handleClose
              });
              this._valueHelpSelectDialog.setModel(this.getView().getModel(modelName));
              this._valueHelpSelectDialog.open();
       },

       /**
        * @private [Input assistance for assignment type selection]
        * @param oEvent
        */
       onAccountAssignmentValueHelpRequest : function(oEvent) {

              var title1 = this.oBundle.getText("COST_TYPE");
              var path = "/results";
              var title2 = "{accAssg}";
              var filter = "accAssg";

              var accountField = this.getView().byId("input_assisted3");
              var assignmentTypeField = this.getView().byId("input_assisted2");

              // Handling of both confirm and cancel; clear the filter
              var handleClose = function(oEvent) {

                     var oSelectedItem = oEvent
                     .getParameter("selectedItem");
                     if (oSelectedItem) {
                           accountField.setValue(oSelectedItem.getTitle());
                           assignmentTypeField.setValue("");
                     }
                     oEvent.getSource().getBinding("items").filter([]);
              };

              // Create a SelectDialog and display it; bind to the same model as for the suggested items
              this._valueHelpSelectDialog = new sap.m.SelectDialog(
              {
                     title : title1,
                     items : {
                           path : path,
                           template : new sap.m.StandardListItem(
                                         {
                                                title : title2,
                                                active : true
                                         })
                     },
                     search : function(oEvent) {
                           var sValue = oEvent.getParameter("value");
                           var oFilter = new sap.ui.model.Filter(filter,sap.ui.model.FilterOperator.Contains,sValue);
                           oEvent.getSource().getBinding("items").filter([ oFilter ]);
                     },
                     confirm : handleClose,
                     cancel : handleClose
              });
              this._valueHelpSelectDialog.setModel(this.getView().getModel("AccountAssignment"));
              this._valueHelpSelectDialog.open();
       },

       onNavigateBack : function() {
              window.history.back();
       },

       /**
        * @private creates header and footer options which are to be set
        * @returns {_}
        */
       createHeaderFooterOptions: function(){
           var that = this;
           return {
                  sFullscreenTitle: that.oBundle.getText("ORDER_TITLE"),
                  onBack : jQuery.proxy(function(oEvent){
                	  that.oRouter.navTo("shoppingCartItems", {

                          tempCartId : that.tempCartId

                   },true);
                 that.getView().byId("noteToApprover").setValue("");
                  }),
                oEditBtn:  {
                        sI18nBtnTxt: "SUBMIT_CART",
                        onBtnPressed: jQuery.proxy(that.onSubmit, that)
                  },
                  
                   buttonList: [{    sI18nBtnTxt: "CANCEL",
                        onBtnPressed: jQuery.proxy(that.onCancel, that)  
                  }],

                  oAddBookmarkSettings: {
                        title: that.oBundle.getText("ORDER_TITLE"),
                        icon: "sap-icon://cart"
                  }
           };
    },

       
       onRequestFailed : function(oError) {
    	   	  //close the busy dialog first
   			  this.busyDialog.close();
              jQuery.sap.require("sap.ca.ui.message.message");
              sap.ca.ui.message.showMessageBox({
                     type : sap.ca.ui.message.Type.ERROR,
                     message : oError.message,
                     details : oError.response.body
              });
       },
       
       /**
        * @private Checks the country selected by user with the oData model of Country
        * @returns boolean value
        */
       getCountryStatus: function(){

    	   for(var i=0;i<this.oCountryModel.oData.results.length;i++){
    	                if(this.getView().byId("input_assisted1").getValue() === this.oCountryModel.oData.results[i].CountryName){
    	                	return true;
    	                	} 
    	   }
    	  return false;
       },
       
       onAfterRendering : function(){},
   	   onExit: function(){},
   	   onBeforeRendering : function(){}
});


},
	"ui/s2p/srm/sc/create/view/ShoppingCartCheckout.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View controllerName="ui.s2p.srm.sc.create.view.ShoppingCartCheckout"\n\txmlns="sap.m" xmlns:form="sap.ui.layout.form" xmlns:sap.ui.layout="sap.ui.layout"\n\txmlns:sap.ui.core="sap.ui.core">\n\t<Page class="sapUiFioriObjectPage"\n\t\tnavButtonTap="_navBack" \n\t\tshowNavButton="true">\n\t\t<content>\n\t\t\t<form:SimpleForm editable="true">\n\t\t\t\t<form:content>\n\t\t\t\t\t<sap.ui.core:Title text="{i18n>INFORMATION}"></sap.ui.core:Title>\n\t\t\t\t\t<Label text="{i18n>TOTAL_VALUE}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="totalValue" editable="false">\n \t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData> \n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>COST_ASSIGNMENT}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="input_assisted3" value="{i18n>COST_CENTER}"\n\t\t\t\t\t\tplaceholder="{i18n>SELECT_ACCOUNT_ASSIGNMENT}" showValueHelp="true"\n\t\t\t\t\t\tshowSuggestion="true" suggestionItems="{AccountAssignment>/results}"\n\t\t\t\t\t\twidth="50%" valueHelpRequest="onAccountAssignmentValueHelpRequest">\n\t\t\t\t\t\t<suggestionItems>\n\t\t\t\t\t\t\t<sap.ui.core:Item text="{AccountAssignment>accAssg}"></sap.ui.core:Item>\n\t\t\t\t\t\t</suggestionItems>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>ASSIGNMENT_TYPE}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="input_assisted2" value="{personalCollection>/COST_CTR}"\n\t\t\t\t\t\tplaceholder="{i18n>SELECT_ASSIGNMENT_TYPE}" showValueHelp="true"\n\t\t\t\t\t\tshowSuggestion="true" width="50%" valueHelpRequest="onAssignmentTypeValueHelpRequest">\n\n\t\t\t\t\t</Input>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Extension point added for more information  -->\n\t\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extMoreInfo2"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\t\n\t\t\t\t\t<Label text="{i18n>REQUESTED_DELIVERY}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<DateTimeInput id="dateplusseven" width="50%"\n                         valueFormat="dd-MM, yyyy">\n                        <layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</DateTimeInput>\n\t\t\t\t\t<Label text="{i18n>DELIVERY_ADDRESS}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="street" value="{personalCollection>/STREET}"\n\t\t\t\t\t\twidth="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>CITY}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="city" value="{personalCollection>/CITY}" width="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>STATE}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="state" value="{personalCollection>/REGION}" width="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>ZIP}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="zip" value="{personalCollection>/POSTL_COD1}"\n\t\t\t\t\t\twidth="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>COUNTRY}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\n\t\t\t\t\t<Input id="input_assisted1" value="{personalCollection>/COUNTRY_DESC}"\n\t\t\t\t\t\tplaceholder="{i18n>SELECT_COUNTRY}" showValueHelp="true"\n\t\t\t\t\t\tshowSuggestion="true" suggestionItems="{Country>/results}" width="50%"\n\t\t\t\t\t\tvalueHelpRequest="onCountryValueHelpRequest">\n\t\t\t\t\t\t<suggestionItems>\n\t\t\t\t\t\t\t<sap.ui.core:Item text="{Country>CountryName}"></sap.ui.core:Item>\n\t\t\t\t\t\t</suggestionItems>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>NOTE_TO_APPROVER}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<TextArea id="noteToApprover" width="50%" wrapping="None">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</TextArea>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Extension point added for more information  -->\n\t\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extMoreInfo3"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\n\t\t\t\t</form:content>\n\t\t\t</form:SimpleForm>\n\t\t\t<Table id="MaterialList" class="sapSccList" inset="true"\n\t\t\t\titems="{ShoppingCartItems>/results}">\n\t\t\t\t<items>\n\t\t\t\t\t<ColumnListItem unread="true" counter="0">\n\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t<ObjectIdentifier title="{ShoppingCartItems>DESCRIPTION}"\n\t\t\t\t\t\t\t\tbadgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n\t\t\t\t\t\t\t<ObjectNumber\n\t\t\t\t\t\t\t\tnumber="{path:\'ShoppingCartItems>QUANTITY\', type:\'sap.ca.ui.model.type.Number\', formatOptions:{decimals:0}}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>UNIT}"></ObjectNumber>\n\t\t\t\t\t\t\t<ObjectNumber number="{parts:[{path:\'ShoppingCartItems>ITM_TOTAL_PRICE\'},{path:\'ShoppingCartItems>CURRENCY\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPrice\'}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>CURRENCY}"></ObjectNumber>\n\t\t\t\t\t\t</cells>\n\t\t\t\t\t</ColumnListItem>\n\t\t\t\t</items>\n\t\t\t\t<columns>\n\t\t\t\t\t<Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>DESCRIPTION}" textAlign="Left" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column width="20%" hAlign="Right" minScreenWidth="tablet"\n\t\t\t\t\t\tdemandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>QUANTITY_LBL}" textAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column hAlign="Right" minScreenWidth="tablet" demandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>SUB_TOTAL}" textAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t</columns>\n\t\t\t</Table>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footerBar" translucent="true">\n\t\t\t</Bar>\n\t\t</footer>\n\t</Page>\n\n</sap.ui.core:View>\n',
	"ui/s2p/srm/sc/create/view/ShoppingCartItems.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartItems", {

	onInit: function() {
		//execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();

		// Get instance of the busy dialog
		this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});

		this.oRouter.attachRouteMatched(function(oEvent) { 
			if (oEvent.getParameter("name") === "shoppingCartItems") {
				var that = this;
				this.Temp_Cart_Id = oEvent.getParameter("arguments").tempCartId;
				//start the busy dialog now
				this.busyDialog.open();
				jQuery.proxy(this.getShoppingCartItemDetails(),that);
			}
		}, this);

		this.setHeaderFooterOptions(this.createHeaderFooterOptions());
	},

	/**
	 * private [Gets details of the temporary cart and binds it to the table displaying the item list and details]
	 */
	getShoppingCartItemDetails : function(){

		var onRequestSuccess1 = function(oData, oResponse) {
			var model1 = new sap.ui.model.json.JSONModel(oData);
			this.getView().setModel(model1, "ShoppingCartHeader");

			var itemCount = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(model1.oData.ITM_COUNT);
			this.getView().byId("MaterialList").setHeaderText(itemCount);                 
		};

		var onRequestSuccess2 = function(oData, oResponse) {
			var model2 = new sap.ui.model.json.JSONModel(oData);
			this.originalModel = model2.oData.results;
			if(model2.oData.results.length > 0){
				this.setBtnEnabled("checkoutBtn",true);
				this.setBtnEnabled("updateBtn",true);

			}else{
				this.setBtnEnabled("checkoutBtn",false);
				this.setBtnEnabled("updateBtn",false);
			}
			for(var i = 0 ; i < model2.oData.results.length; i++){
				model2.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(model2.oData.results[i].QUANTITY) * parseFloat(model2.oData.results[i].PRICE).toString()).toFixed(2);
			}
			this.getView().setModel(model2, "ShoppingCartItems");
			//last place for all data to be fetched, stop the busy dialog now
			this.busyDialog.close();
		};		

		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");

		//explicitly setting some headers for retrieving the updating information from the server
		//this setting is particularly significant for internet explorer since the page does not 
		//update upon addition of items of the cart
		oDataModel.setHeaders({"Cache-Control":"no-cache, no-store, must-revalidate","Pragma":"no-cache","Expires":"-1"});
		
		var sPath1 = "ShoppingcartCollection(TEMP_CART_ID='"+ this.Temp_Cart_Id +"')?ts="+Date.now();
		oDataModel.read(sPath1, null,null, true,jQuery.proxy(onRequestSuccess1, this), jQuery.proxy(this.onRequestFailed, this));
		
		var sPath2 = "ShoppingcartCollection(TEMP_CART_ID='"+ this.Temp_Cart_Id +"')/ShoppingCartItemNavigation?ts="+Date.now();
		oDataModel.read(sPath2, null,null, true,jQuery.proxy(onRequestSuccess2, this), jQuery.proxy(this.onRequestFailed, this));
	},


	/**
	 * @private [On changing the quantity, disables checkout button]
	 * @param oEvent
	 */
	onQuantityChanged : function(oEvent) {
		var value = oEvent.getParameters().newValue;
		//Floors the quantity value
		var cleanValue = Math.floor(value);

		//If quantity is less than 1, changes it to 1 (Minimum value for quantity)
		if(cleanValue<1) {
			cleanValue = 1;
		}
		if(cleanValue!=value) {
			oEvent.getSource().setValue(cleanValue);
		}
		var sId = oEvent.getParameter("id");
		var index = parseInt(sId.substring(sId.lastIndexOf("-")+1), 10);

		if(!this.quantities) {
			this.quantities = [];
		     }
		
		this.quantities[index] = cleanValue;
		//Disabling Checkout button
		if(this.quantities)
		{
		this.setBtnEnabled("checkoutBtn",false);
		}
	},

	/**
	 * @private [On deleting an item from the item list, removes it from the temporary cart]
	 * @param oEvent
	 */
	removeItem : function(oEvent) {
		var listItem = oEvent.getSource();
		var bindingContext = listItem.getBindingContext("ShoppingCartItems");
		var oModel = bindingContext.getModel();
		var path = bindingContext.getPath();
		var itemData = oModel.getProperty(path);

		var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
		oDataModel.remove("ShoppingcartItemCollection(ITEM_NO='"
				+ itemData.ITEM_NO
				+"',TEMP_CART_ID='" + this.Temp_Cart_Id
				+ "')"
				, null,jQuery.proxy(this.getShoppingCartItemDetails,this),
				jQuery.proxy(this.onRequestFailed,this));
	},

	/**
	 * @private [Itemdata is made to the format required for pay load ]
	 * @param selectedObject
	 * @returns {___anonymous4601_4955}
	 */
	_cloneItemData : function(selectedObject) {
		return {
			'ITEM_NO' : selectedObject.ITEM_NO,
			'TEMP_CART_ID' : selectedObject.TEMP_CART_ID,
			'DESCRIPTION' : selectedObject.DESCRIPTION,
			'QUANTITY' : selectedObject.QUANTITY,
			'UNIT' : selectedObject.UNIT,
			'PRICE' : selectedObject.PRICE.toString(),
			'CURRENCY' : selectedObject.CURRENCY,
			'PRODUCTKEY' : selectedObject.PRODUCTKEY,
		};
	},

	/**
	 * @private [Updates the temporary cart]
	 * @param oEvent
	 */
	onUpdateCart : function(oEvent) {
		var oModel = this.originalModel;
		if(this.quantities) {
			//start the busy dialog when the quantity is changed
			this.busyDialog.open();
			var oDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
			var aBatchArray = new Array();
			for (var i = 0; i < this.quantities.length; i++) {
				if(this.quantities[i] && parseInt(oModel[i].QUANTITY, 10)!=this.quantities[i]) {
					var itemdet = this._cloneItemData(oModel[i]);
					itemdet.QUANTITY = this.quantities[i].toString();
					//	itemdet.PRODUCTKEY = jQuery.sap.encodeURL(itemdet.PRODUCTKEY);
					//Creating a batch request
					var sPath = "ShoppingcartItemCollection(ITEM_NO=\'" + itemdet.ITEM_NO + "\',TEMP_CART_ID=\'" + this.Temp_Cart_Id + "\')?ts=" + Date.now();
					aBatchArray.push(oDataModel.createBatchOperation(sPath, "PUT", itemdet));
					
				}
			}
			
			
			if(aBatchArray.length === 0)
			{
			this.quantity = null;
			//Close the busy dialog now
			this.busyDialog.close();
			this.setBtnEnabled("checkoutBtn",this.getView().getModel("ShoppingCartItems").getData().results.length > 0);
			return;
			}
			oDataModel.addBatchChangeOperations(aBatchArray);
			var onRequestSuccess = function(oResponse) {
				this.quantities = null;
				this.getShoppingCartItemDetails();
				this.setBtnEnabled("checkoutBtn",true);
				var batchResponses = oResponse && oResponse.__batchResponses ? oResponse.__batchResponses : []; 
				for ( var i = 0; i < batchResponses.length; i++) {
					if(batchResponses[0] && batchResponses[0].response && batchResponses[0].response.statusCode == "400"){
						this.onRequestFailed(batchResponses[0]);
						return;
					}
				}
				jQuery.sap.require("sap.m.MessageToast");
				sap.m.MessageToast.show("Updated Successfully");
				this.busyDialog.close();
			};
			oDataModel.submitBatch(jQuery.proxy(onRequestSuccess,this),jQuery.proxy(this.onRequestFailed,this));
		}
		else
		{	
			//Close the busy dialog now
			this.busyDialog.close();
			this.setBtnEnabled("checkoutBtn",this.getView().getModel("ShoppingCartItems").getData().results.length > 0);
		}

	},

	/**
	 * @private [Navigates to checkout page]
	 */
	onCheckoutCart: function(){  
		this.oRouter.navTo("shoppingCartCheckout", {  
			tempCartId : this.Temp_Cart_Id,
		}, true);

		var totalValue = this.getView().getModel("ShoppingCartHeader").oData.TOTAL_VALUE +" "+ this.getView().getModel("ShoppingCartHeader").oData.WAERS;

		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.oView);
		var oComponent   = sap.ui.component(sComponentId);	

		oComponent.oEventBus.publish("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout",{
			totalValue: totalValue
		});
	},

	/**
	 * @private [creates header and footer options which are to be set]
	 * @returns {___anonymous6785_7210}
	 */
    createHeaderFooterOptions: function(){
        var that=this;
        return {
               sFullscreenTitle: that.oBundle.getText("CART_TITLE"),

               onBack: jQuery.proxy(function(oEvent){
            	   that.oRouter.navTo("noData",{

                       viewTitle: "DETAIL_TITLE",

                       languageKey: "NO_ITEMS_AVAILABLE"

                },true);

               }),

               buttonList: [{
                     sId: "updateBtn",
                     sI18nBtnTxt: "UPDATE_BUTTON",
                     onBtnPressed: jQuery.proxy(that.onUpdateCart, that)
               }],
               oEditBtn:{    
                     sId: "checkoutBtn",        
                     sI18nBtnTxt: "CHECKOUT_BUTTON",
                     onBtnPressed: jQuery.proxy(that.onCheckoutCart, that)  
               },
               
                 oAddBookmarkSettings: {
            title: that.oBundle.getText("CART_TITLE"),
            icon: "sap-icon://cart"
      }

        };
 },


	onRequestFailed: function(oError){
		//close the busy dialog first
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: oError.message,
			details: oError.response.body
		});
	},
	
	onAfterRendering : function(){},
	onExit: function(){},
	onBeforeRendering : function(){}
});

},
	"ui/s2p/srm/sc/create/view/ShoppingCartItems.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View controllerName="ui.s2p.srm.sc.create.view.ShoppingCartItems"\n    xmlns="sap.m"\n    xmlns:sap.ui.core="sap.ui.core" >\n    <Page class="sapUiFioriObjectPage" navButtonTap="_navBack" showNavButton="true" id="page">\n        <content>\n            <Table id="MaterialList" inset="true" footerText="{parts:[{path:\'i18n>TOTAL\'},{path:\'ShoppingCartHeader>/TOTAL_VALUE\'},{path:\'ShoppingCartHeader>/WAERS\'}]}" items="{ShoppingCartItems>/results}">\n                <items>\n                    <ColumnListItem unread="true" counter="0">\n                        <cells>\n                            <ObjectIdentifier title="{ShoppingCartItems>DESCRIPTION}" class="soc-table-label-elem-align" badgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n                            <Input liveChange="onQuantityChanged" value="{parts:[{path:\'ShoppingCartItems>QUANTITY\'},{path:\'ShoppingCartItems>UNIT\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatQuantity\'}" width="6em" type="Number"></Input>\n                            <Label text="{ShoppingCartItems>UNIT}" class="soc-table-label-elem-align"></Label>\n                            <ObjectNumber number="{parts:[{path:\'ShoppingCartItems>ITM_TOTAL_PRICE\'},{path:\'ShoppingCartItems>CURRENCY\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPrice\'}"\n                                          id="totalPrice" numberUnit="{ShoppingCartItems>CURRENCY}" class="soc-table-label-elem-align"></ObjectNumber>\n                            <Button tap="removeItem" type="Transparent" icon="sap-icon://decline"></Button>\n                        </cells>\n                    </ColumnListItem>\n                </items>\n                <columns>\n                    <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>DESCRIPTION}" textAlign="Left" width="100%"></Label>\n                        </header>\n                    </Column>\n                    <Column width="6em" hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>QUANTITY_LBL}" textAlign="Left" width="100%"></Label>\n                        </header>\n                    </Column>\n                    <Column width="6em" hAlign="Left" minScreenWidth="tablet" demandPopin="true"></Column>\n                    <Column width="8em" hAlign="Right" minScreenWidth="tablet" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>Subtotal}" textAlign="Right" width="100%"></Label>\n                        </header>\n                    </Column>\n                    <Column width="4em" hAlign="Right" minScreenWidth="phone"></Column>\n                </columns>\n            </Table>\n        </content>\n        <footer>\n            <Bar id="footerBar" translucent="true">\n            </Bar>\n        </footer>\n    </Page>\n</sap.ui.core:View>'
}});
