jQuery.sap.registerPreloadedModules({
	"name": "ui/s2p/srm/sc/create/Component-preload",
	"version": "2.0",
	"modules": {
		"ui/s2p/srm/sc/create/Component.js": function() {
			/*
			 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
			 */
			jQuery.sap.declare("ui.s2p.srm.sc.create.Component");
			jQuery.sap.require("ui.s2p.srm.sc.create.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
			sap.ca.scfld.md.ComponentBase.extend("ui.s2p.srm.sc.create.Component", {
				metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
					"name": "Master Detail Sample",
					"version": "1.0.0",
					"library": "ui.s2p.srm.sc.create",
					"includes": ["css/shoppingcart.css"],
					"dependencies": {
						"libs": ["sap.m", "sap.me"],
						"components": []
					},
					"config": {
						"titleResource": "DISPLAY_NAME_CREATE",
						"resourceBundle": "i18n/i18n.properties",
						"icon": "sap-icon://Fiori2/F0407",
						"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/My_Shopping_Cart.ico",
						"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/57_iPhone_Desktop_Launch.png",
						"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/114_iPhone-Retina_Web_Clip.png",
						"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/72_iPad_Desktop_Launch.png",
						"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/My_Shopping_Cart/144_iPad_Retina_Web_Clip.png"
					},
					"masterPageRoutes": {
						"master": {
							"pattern": "",
							"view": "ui.s2p.srm.sc.create.view.S2"
						}
					},
					"detailPageRoutes": {
						"detail": {
							"pattern": "detail/{tempCartId}/{contextPath}",
							"view": "ui.s2p.srm.sc.create.view.S3"
						},
						"noData": {
							"pattern": "noData/{viewTitle}/{languageKey}",
							"view": "empty"
						}
					},
					"fullScreenPageRoutes": {
						"shoppingCartItems": {
							"pattern": "shoppingCartItems/{tempCartId}",
							"view": "ui.s2p.srm.sc.create.view.ShoppingCartItems"
						},
						"shoppingCartCheckout": {
							"pattern": "shoppingCartCheckout/{tempCartId}",
							"view": "ui.s2p.srm.sc.create.view.ShoppingCartCheckout"
						}
					}
				}),
				createContent: function() {
					var v = {
							component: this
						},
						V = sap.ui.view({
							viewName: "ui.s2p.srm.sc.create.Main",
							type: sap.ui.core.mvc.ViewType.XML,
							viewData: v
						}),
						p = V.getId() + "--",
						e = sap.ui.getCore().getEventBus();
					this.oEventBus = {
						publish: function(c, a, d) {
							c = p + c;
							e.publish(c, a, d)
						},
						subscribe: function(c, a, d, l) {
							c = p + c;
							e.subscribe(c, a, d, l)
						},
						unsubscribe: function(c, a, d, l) {
							c = p + c;
							e.unsubscribe(c, a, d, l)
						}
					};
					return V
				}
			})
		},
		"ui/s2p/srm/sc/create/Configuration.js": function() {
			jQuery.sap.declare("ui.s2p.srm.sc.create.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
			jQuery.sap.require("sap.ca.scfld.md.app.Application");
			sap.ca.scfld.md.ConfigurationBase.extend("ui.s2p.srm.sc.create.Configuration", {
				oServiceParams: {
					serviceList: [{
						name: "CROSS_CATALOG_SEARCH",
						masterCollection: "CATALOG_ITEM",
						serviceUrl: URI("/sap/opu/odata/srmnxp/CROSS_CATALOG_SEARCH/").directory(),
						isDefault: true,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}, {
						name: "SHOPPING_CART",
						masterCollection: "ShoppingCart",
						serviceUrl: URI("/sap/opu/odata/srmnxp/SHOPPING_CART/").directory(),
						isDefault: false,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}, {
						name: "getdefusrset",
						masterCollection: "DefaultUser",
						serviceUrl: URI("/sap/opu/odata/srmnxp/getdefusrset/").directory(),
						isDefault: false,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}, {
						name: "ACC_ASS_SEARCH_HELP",
						masterCollection: "CostCenterTabCollection",
						serviceUrl: URI("/sap/opu/odata/srmnxp/ACC_ASS_SEARCH_HELP/").directory(),
						isDefault: false,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}, {
						name: "COUNTRY_SH_SERVICE",
						masterCollection: "CountryCollection",
						serviceUrl: URI("/sap/opu/odata/srmnxp/COUNTRY_SH_SERVICE/").directory(),
						isDefault: false,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}, {
						name: "SRMSHOPPING_CART",
						masterCollection: "User_PersonalizationCollection",
						serviceUrl: URI("/sap/opu/odata/srmnxp/SRMSHOPPING_CART/").directory(),
						isDefault: false,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}, {
						name: "ACC_ASSIGN_CATEGORY",
						masterCollection: "AccountAssignmentCategoryCollection",
						serviceUrl: URI("/sap/opu/odata/srmnxp/ACC_ASSIGN_CATEGORY/").directory(),
						isDefault: false,
						mockedDataSource: "/srm.shoppingcart.create/model/metadata.xml"
					}]
				},
				getServiceList: function() {
					return this.oServiceParams.serviceList
				}
			})
		},
		"ui/s2p/srm/sc/create/Main.controller.js": function() {
			sap.ui.controller("ui.s2p.srm.sc.create.Main", {
				onInit: function() {
					jQuery.sap.require("sap.ca.scfld.md.Startup");
					sap.ca.scfld.md.Startup.init('ui.s2p.srm.sc.create', this)
				},
				onExit: function() {}
			})
		},
		"ui/s2p/srm/sc/create/Main.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n\txmlns:core="sap.ui.core"\n\txmlns="sap.m"\n\tcontrollerName="ui.s2p.srm.sc.create.Main"\n\tdisplayBlock="true"\n\theight="100%">\n\t<NavContainer\n\t\tid="fioriContent"\n\t\tshowHeader="false">\n\t</NavContainer>\n</core:View>',
		"ui/s2p/srm/sc/create/util/Formatter.js": function() {
			jQuery.sap.declare("ui.s2p.srm.sc.create.util.Formatter");
			jQuery.sap.require("sap.ui.core.Element");
			jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
			jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
			ui.s2p.srm.sc.create.util.Formatter = {
				formatPreferredItem: function(a) {
					if (a == "01") {
						var A = sap.ca.scfld.md.app.Application.getImpl();
						var b = A.getResourceBundle();
						return b.getText("PREFERRED_ITEM")
					} else {
						return ""
					}
				},
				formatQuantity: function(v, u) {
					return sap.ca.ui.model.format.QuantityFormat.FormatQuantityStandard(v, u, 0)
				},
				formatItemCount: function(i) {
					var a = sap.ca.scfld.md.app.Application.getImpl();
					var b = a.getResourceBundle();
					return b.getText("ITEMS_QTY_EX", [i])
				},
				formatPrice: function(v, c) {
					var f = sap.ca.ui.model.format.AmountFormat.getInstance(c, {
						style: "standard"
					});
					return f.format(v)
				},
				formatCreatedOn: function(c) {
					return this.oBundle.ResourceBundle.getText("CREATED_EX", [c])
				}
			}
		},
		"ui/s2p/srm/sc/create/util/TrackCaller.js": function() {
			jQuery.sap.declare("ui.s2p.srm.sc.create.util.TrackCaller");
			ui.s2p.srm.sc.create.util.TrackCaller = {};
			ui.s2p.srm.sc.create.util.TrackCaller.stack = (function() {
				var i = [];
				return {
					add: function(c) {
						i.push({
							item: c
						})
					},
					clear: function() {
						i = []
					},
					getLastCaller: function() {
						if (i.length === 0) {
							return ""
						} else {
							return i[i.length - 1].item
						}
					}
				}
			})()
		},
		"ui/s2p/srm/sc/create/view/S2.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
			jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
			sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.create.view.S2", {
				onInit: function() {
					sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
					this.oBundle = this.oApplicationFacade.getResourceBundle();
					this.isRoot = true;
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "master" && !this.isRoot && Object.keys(e.getParameter("arguments")).length === 0) {
							var d = sap.ui.core.routing.History.getInstance().getDirection("shoppingCartCheckout/" + this.tempCartId);
							if (d === "Unknown") {
								this.isRoot = true;
								this._oControlStore.oMasterSearchField.clear()
							} else {
								if (this.getList() !== null) {
									var i = this.getList().getSelectedItem();
									if (i !== null) {
										this.setListItem(i)
									}
								}
							}
						}
						this.isRoot = (this.isRoot) ? false : this.isRoot
					}, this);
					this.setEmptyCart(true)
				},
				getDefaultUserSettings: function(r) {
					var o = function(D, R) {
						this.tempCartId = D.results[0].TEMP_CART_ID;
						if (!jQuery.device.is.phone) {
							if (r) {
								this.oRouter.navTo("noData", {
									viewTitle: "DETAIL_TITLE",
									languageKey: "NO_ITEMS_AVAILABLE"
								}, true)
							} else {
								this.navToEmptyView()
							}
						}
					};
					var d = this.oApplicationFacade.getODataModel("getdefusrset");
					d.read("DefaultUserSettings?ts=" + Date.now(), null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				applySearchPatternToListItem: function(i, f) {
					if (f.substring(0, 1) === "#") {
						var t = f.substr(1);
						var d = i.getBindingContext().getProperty("Name").toLowerCase();
						return d.indexOf(t) === 0
					} else {
						return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
					}
				},
				getHeaderFooterOptions: function() {
					var o = {
						sI18NMasterTitle: "MASTER_TITLE",
						buttonList: []
					};
					return o
				},
				isBackendSearch: function() {
					return true
				},
				applyBackendSearchPattern: function(f, b) {
					if (f != "" && f != null) {
						this.startReadListData(f)
					} else {
						this.setEmptyCart(false)
					}
				},
				startReadListData: function(f) {
					var o = function(D, r) {
						var m = new sap.ui.model.json.JSONModel(D.results);
						this.getView().setModel(m);
						this.getList().destroyItems();
						this.getList().bindAggregation("items", {
							path: "/",
							template: this.oTemplate.clone(),
							filter: [],
							sorter: null,
						});
						this.registerMasterListBind(this.getList())
					};
					var e = encodeURIComponent(f);
					var d = this.oApplicationFacade.getODataModel();
					d.read("CATALOG_ITEM?$filter=startswith(description,'" + e + "')&$top=20", null, null, true, jQuery.proxy(o, this), jQuery.proxy(
						this.onRequestFailed, this))
				},
				setListItem: function(i) {
					var b = i.getBindingContext();
					var m = b.oModel.oData[parseInt(b.sPath.split('/')[1])];
					this.oRouter.navTo("detail", {
						tempCartId: this.tempCartId,
						contextPath: b.getPath().substr(1)
					}, true);
					var c = sap.ui.core.Component.getOwnerIdFor(this.oView);
					var C = sap.ui.component(c);
					C.oEventBus.publish("ui.s2p.srm.sc.create", "refreshDetail", {
						data: m
					})
				},
				setEmptyCart: function(r) {
					var e = new sap.ui.model.json.JSONModel({
						results: []
					});
					this.oRouter.navTo("noData", {
						viewTitle: "DETAIL_TITLE",
						languageKey: "NO_ITEMS_AVAILABLE"
					}, true);
					this.getView().setModel(e);
					this.oTemplate = new sap.m.ObjectListItem({
						type: "{device>/listItemType}",
						title: "{description}",
						press: jQuery.proxy(this._handleItemPress, this),
						number: "{parts:[{path:'itm_price'},{path:'itm_currency'}],formatter:'ui.s2p.srm.sc.create.util.Formatter.formatPrice'}",
						numberUnit: "{itm_currency}",
						attributes: [new sap.m.ObjectAttribute({
							text: "{vendormat}"
						})],
					});
					this.getList().bindAggregation("items", {
						path: "/results",
						template: this.oTemplate,
						filter: [],
						sorter: null,
					});
					this.registerMasterListBind(this.getList());
					this.getDefaultUserSettings(r)
				},
				onRequestFailed: function(e) {
					jQuery.sap.require("sap.ca.ui.message.message");
					sap.ca.ui.message.showMessageBox({
						type: sap.ca.ui.message.Type.ERROR,
						message: e.message,
						details: e.response.body
					})
				},
				onAfterRendering: function() {},
				onExit: function() {},
				onBeforeRendering: function() {}
			})
		},
		"ui/s2p/srm/sc/create/view/S2.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n\txmlns="sap.m" controllerName="ui.s2p.srm.sc.create.view.S2">\n\t<Page id="page" title="{i18n>MASTER_TITLE}">\n\t\t<content>\n\t\t\t<List id="list" mode="{device>/listMode}" select="_handleSelect" noDataText="{i18n>SEARCH}" showNoData="false">\n\t\t\t\t\n\t\t\t</List>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footer"></Bar>\n\t\t</footer>\n\t</Page>\n</core:View>',
		"ui/s2p/srm/sc/create/view/S3.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
			jQuery.sap.require("sap.m.MessageToast");
			jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
			sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.create.view.S3", {
				onInit: function() {
					sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
					this.oBundle = this.oApplicationFacade.getResourceBundle();
					this.busyDialog = new sap.m.BusyDialog({
						customIcon: sap.ca.ui.images.images.Flower
					});
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "detail") {
							this.Temp_Cart_Id = e.getParameter("arguments").tempCartId;
							this.busyDialog.open();
							this.getTempCartQuantity()
						}
					}, this);
					var c = sap.ui.core.Component.getOwnerIdFor(this.getView());
					var C = sap.ui.component(c);
					C.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshDetail", this.getData, this)
				},
				getData: function(c, e, d) {
					this.productKey = d.data.productkey;
					this.description = d.data.description;
					d.data.cartValue = 1;
					this.selectedItemModel = new sap.ui.model.json.JSONModel(d.data);
					this.getView().setModel(this.selectedItemModel, "itemDetail");
					var h = this.getHeaderFooterOptions();
					this.setHeaderFooterOptions(h);
					if (sap.ui.getCore().byId("cartValue")) sap.ui.getCore().byId("cartValue").setText(this.cartValue)
				},
				getTempCartQuantity: function() {
					var o = function(D, r) {
						this.cartValue = 0;
						var t = this.Temp_Cart_Id.trim();
						for (var i = 0; i < D.results.length; i++) {
							var e = D.results[i].TEMP_CART_ID.trim();
							if (t === e) {
								this.cartValue = parseInt(this.cartValue, 10) + 1
							}
						}
						if (sap.ui.getCore().byId("cartValue")) sap.ui.getCore().byId("cartValue").setText(this.cartValue);
						this.busyDialog.close()
					};
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					d.setHeaders({
						"Cache-Control": "no-cache, no-store, must-revalidate",
						"Pragma": "no-cache",
						"Expires": "-1"
					});
					var p = "ShoppingcartItemCollection?ts=" + Date.now();
					d.read(p, null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				gotoCartItem: function() {
					this.oRouter.navTo("shoppingCartItems", {
						tempCartId: this.Temp_Cart_Id
					}, true)
				},
				getHeaderFooterOptions: function() {
					var t = this;
					return {
						oHeaderBtnSettings: {
							sId: "cartValue",
							sIcon: 'sap-icon://cart-full',
							onBtnPressed: function() {
								t.gotoCartItem()
							}
						},
						oEditBtn: {
							sId: "addToCartBtn",
							sI18nBtnTxt: "ADD_TO_CART_DETAIL",
							type: "Accept",
							onBtnPressed: function() {
								t.onAddToCart()
							}
						},
						oJamOptions: {
							oDiscussSettings: {
								object: {
									id: this.oApplicationFacade.getODataModel().sServiceUrl + "CATALOG_ITEM('" + this.productKey + "')",
									type: this.oApplicationFacade.getODataModel().sServiceUrl + "$metadata#CATALOG_ITEM",
									name: this.description
								}
							}
						},
						bSuppressBookmarkButton: true
					}
				},
				onAddToCart: function() {
					this.busyDialog.open();
					var o = function(D, r) {
						var a = new sap.ui.model.json.JSONModel(D);
						jQuery.proxy(this.addToCartItemDetails(a), this);
						this.getTempCartQuantity()
					};
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					var p = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();
					d.read(p, null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				_cloneItemData: function(s) {
					return {
						'ITEM_NO': s.ITEM_NO,
						'TEMP_CART_ID': s.TEMP_CART_ID,
						'DESCRIPTION': s.DESCRIPTION,
						'QUANTITY': s.QUANTITY,
						'UNIT': s.UNIT,
						'PRICE': s.PRICE,
						'CURRENCY': s.CURRENCY,
						'PRODUCTKEY': s.PRODUCTKEY,
					}
				},
				_createItemData: function(t, s) {
					var i = {
						'ITEM_NO': '',
						'TEMP_CART_ID': '',
						'DESCRIPTION': '',
						'QUANTITY': '',
						'UNIT': 'EA',
						'PRICE': '',
						'CURRENCY': '',
						'PRODUCTKEY': '',
					};
					i.TEMP_CART_ID = t;
					i.DESCRIPTION = s.description;
					i.CURRENCY = s.itm_currency;
					i.UNIT = s.unit;
					i.PRICE = s.itm_price;
					return i
				},
				addToCartItemDetails: function(t) {
					var s = new sap.ui.model.json.JSONModel();
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					s = null;
					if (this.selectedItemModel != null) {
						var a = this.selectedItemModel.oData.productkey.trim();
						for (var i = 0; i < t.oData.results.length; i++) {
							var e = t.oData.results[i].PRODUCTKEY.trim();
							if (e === a | e === jQuery.sap.encodeURL(a)) {
								s = t.oData.results[i];
								break
							}
						}
						var b = this._createItemData(this.Temp_Cart_Id, this.selectedItemModel.oData);
						if (s != null) {
							b = this._cloneItemData(s);
							b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);
							b.UNIT = this.selectedItemModel.oData.unit_cu;
							b.QUANTITY = (parseInt(b.QUANTITY, 10) + 1).toString();
							b.PRICE = b.PRICE.split(".")[0] + "." + b.PRICE.split(".")[1].slice(0, 2);
							this.updateTriggered = true;
							d.update("ShoppingcartItemCollection(ITEM_NO='" + b.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", b, null, jQuery.proxy(
								this.onItemAdded, this), jQuery.proxy(this.onRequestFailed, this))
						} else {
							b.UNIT = this.selectedItemModel.oData.unit_cu;
							b.DESCRIPTION = this.selectedItemModel.oData.description.substring(0, 39);
							b.PRODUCTKEY = jQuery.sap.encodeURL(this.selectedItemModel.oData.productkey);
							b.QUANTITY = (this.selectedItemModel.oData.minorderqty ? this.selectedItemModel.oData.minorderqty : 1) + "";
							b.PRICE = b.PRICE.split(".")[0] + "." + b.PRICE.split(".")[1].slice(0, 2);
							this.updateTriggered = false;
							d.create("ShoppingcartItemCollection", b, null, jQuery.proxy(this.onItemAdded, this), jQuery.proxy(this.onRequestFailed, this))
						}
					}
				},
				onRequestFailed: function(e) {
					this.busyDialog.close();
					jQuery.sap.require("sap.ca.ui.message.message");
					sap.ca.ui.message.showMessageBox({
						type: sap.ca.ui.message.Type.ERROR,
						message: e.message,
						details: e.response.body
					})
				},
				onItemAdded: function() {
					var c = sap.ui.getCore().byId("cartValue").getText();
					if (!this.updateTriggered) {
						c = parseInt(c, 10) + 1;
						sap.ui.getCore().byId("cartValue").setText(c)
					}
					sap.m.MessageToast.show(this.oBundle.getText("ADD_CART_SUCCESS"));
					this.busyDialog.close()
				},
				navToEmptyView: function() {
					this.oRouter.navTo("noData", null, true)
				},
				onAfterRendering: function() {},
				onExit: function() {},
				onBeforeRendering: function() {}
			})
		},
		"ui/s2p/srm/sc/create/view/S3.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View controllerName="ui.s2p.srm.sc.create.view.S3"\n\txmlns="sap.m" xmlns:form="sap.ui.layout.form" xmlns:sap.ui.layout="sap.ui.layout"\n\txmlns:sap.ui.core="sap.ui.core">\n\t<Page id="SHOPPING_CART_ITEMS_PAGE" navButtonTap="_navBack"\n\t\ttitle="{i18n>DETAIL_TITLE}" class="sapUiFioriObjectPage">\n\t\t<content>\n\t\t\t<ObjectHeader id="ITEM_DETAIL_OBJECT_HEADER" title="{itemDetail>/description}"\n\t\t\t\tnumber="{parts:[{path:\'itemDetail>/itm_price\'},{path:\'itemDetail>/itm_currency\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPrice\'}"\n\t\t\t\tnumberUnit="{itemDetail>/itm_currency}" introActive="false"\n\t\t\t\ttitleActive="false" iconActive="false">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{itemDetail>/vendormat}"\n\t\t\t\t\t\tactive="false"></ObjectAttribute>\n\t\t\t\t\t<ObjectAttribute text="{itemDetail>/longtext}"\n\t\t\t\t\t\tactive="false"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t\t<firstStatus>\n\t\t\t\t\t<ObjectStatus\n\t\t\t\t\t\ttext="{path:\'itemDetail>/assortmentind\',formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPreferredItem\'}"></ObjectStatus>\n\t\t\t\t</firstStatus>\n\t\t\t</ObjectHeader>\n\t\t\t<form:SimpleForm id="myForm1" class="detailForm"\n\t\t\t\tminWidth="1024" editable="false">\n\t\t\t\t<form:content>\n\t\t\t\t\t<sap.ui.core:Title text="{i18n>INFORMATION}" id="info"></sap.ui.core:Title>\n\t\t\t\t\t<Label text="{i18n>CATEGORY}" id="catagory">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/matgrouptext}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t<Label text="{i18n>MANUFACTURER}" id="manufacturer">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData \n\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/manufactname}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t<Label text="{i18n>MANUFACTURER_PART_NUMBER}" id="part_Number">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/manufactcode}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t<Label text="{i18n>SUPPLIER}" id="supplier">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Text text="{itemDetail>/vendor_name}" maxLines="0">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Text>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Extension point added for more information  -->\n\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extMoreInfo1"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\t\n\t\t\t\t</form:content>\n\t\t\t</form:SimpleForm>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footerBar" translucent="true">\n\t\t\t\t\n\t\t\t</Bar>\n\t\t</footer>\n\n\t</Page>\n</sap.ui.core:View>',
		"ui/s2p/srm/sc/create/view/ShoppingCartCheckout.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
			jQuery.sap.require("sap.m.MessageBox");
			jQuery.sap.require("sap.ca.ui.model.type.Number");
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartCheckout", {
				onInit: function() {
					this.oBundle = this.oApplicationFacade.getResourceBundle();
					this.busyDialog = new sap.m.BusyDialog({
						customIcon: sap.ca.ui.images.images.Flower
					});
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "shoppingCartCheckout") {
							this.tempCartId = e.getParameter("arguments").tempCartId;
							this.busyDialog.open();
							this.getUserPersonalizationsettings();
							this.getTempCartItems()
						}
					}, this);
					var c = sap.ui.core.Component.getOwnerIdFor(this.getView());
					var C = sap.ui.component(c);
					C.oEventBus.subscribe("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", jQuery.proxy(this.getData, this), this);
					this.co_area = "";
					this.country_key = "";
					this.oCountryModel = this.createModel('Country', 'CountryCollection', null, "COUNTRY_SH_SERVICE");
					this.jsonModel = new sap.ui.model.json.JSONModel({
						results: [{
							accAssg: this.oBundle.getText("COST_CENTER")
						}, {
							accAssg: this.oBundle.getText("INTERNAL_ORDER")
						}]
					});
					this.getView().setModel(this.jsonModel, "AccountAssignment");
					this.setHeaderFooterOptions(this.createHeaderFooterOptions());
					this.getView().byId("dateplusseven").setDisplayFormat(sap.m.getLocaleData().getDatePattern("medium"))
				},
				getData: function(c, e, v) {
					var t = v;
					this.getView().byId("totalValue").setValue(t.totalValue)
				},
				createModel: function(m, p, f, M) {
					var o;
					var a = function(D, r) {
						o = new sap.ui.model.json.JSONModel(D);
						o.setSizeLimit(500);
						this.getView().setModel(o, m)
					};
					var d = this.oApplicationFacade.getODataModel(M);
					d.read(p, null, f, false, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));
					if (m === "Country") return o;
					else return m
				},
				getUserPersonalizationsettings: function() {
					var o = function(D, r) {
						this.oUserDefaults = new sap.ui.model.json.JSONModel(D.results[0]);
						this.getView().setModel(this.oUserDefaults, "personalCollection");
						this.getView().byId("dateplusseven").setValue(this.sevenDaysFromNowDateAsString())
					};
					var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					d.read("User_PersonalizationCollection?ts=" + Date.now(), null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,
						this))
				},
				sevenDaysFromNowDateAsString: function() {
					var d = new Date();
					d.setDate(d.getDate() + 7);
					var v = this.getView().byId('dateplusseven').getValueFormat();
					return sap.ca.ui.model.format.DateFormat.getDateInstance({
						pattern: v
					}).format(d)
				},
				getTempCartItems: function() {
					var o = function(D, r) {
						var T = new sap.ui.model.json.JSONModel(D);
						for (var i = 0; i < T.oData.results.length; i++) {
							T.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(T.oData.results[i].QUANTITY) * parseFloat(T.oData.results[i].PRICE))
						}
						this.getView().byId("MaterialList").setModel(T, "ShoppingCartItems");
						var a = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(T.oData.results.length);
						this.getView().byId("MaterialList").setHeaderText(a);
						this.busyDialog.close()
					};
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					this.getDefaultUserSettings();
					var t = this.getTempCartId();
					d.read("ShoppingcartCollection(TEMP_CART_ID='" + t + "')/ShoppingCartItemNavigation?ts=" + Date.now(), null, null, true, jQuery.proxy(
						o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				discardTempCart: function(t, o) {
					this.busyDialog.open();
					this.OShoppingCartDataModel = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					this.OShoppingCartDataModel.update("HOLD_DOCUMENT?TEMP_CART_ID='" + t + "'&OBJECT_ID='" + o + "'", null, {
						oContext: null,
						fnSuccess: jQuery.proxy(function() {
							this.busyDialog.close()
						}, this),
						fnError: jQuery.proxy(this.onRequestFailed, this)
					})
				},
				getTempCartId: function() {
					return this.oDefaultSettings.oData.results[0].TEMP_CART_ID
				},
				getDefaultUserSettings: function() {
					var o = function(D, r) {
						this.oDefaultSettings = new sap.ui.model.json.JSONModel(D)
					};
					var d = this.oApplicationFacade.getODataModel("getdefusrset");
					d.read("DefaultUserSettings?ts=" + Date.now(), null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				getCartObjectId: function() {
					return this.oDefaultSettings.oData.results[0].OBJECT_ID
				},
				onCancel: function() {
					var t = this;
					var c = new sap.m.Text({
						text: t.oBundle.getText("CANCEL_MESSAGE")
					});
					var a = null;
					a = new sap.m.Dialog({
						content: [c],
						title: t.oBundle.getText("CANCEL_TITLE"),
						leftButton: new sap.m.Button({
							text: this.oBundle.getText("YES"),
							press: function() {
								t.discardTempCart(t.getTempCartId(), t.getCartObjectId());
								a.close();
								t.oRouter.navTo("master", null, true);
								t.getView().byId("noteToApprover").setValue("")
							}
						}),
						rightButton: new sap.m.Button({
							text: this.oBundle.getText("NO"),
							press: function() {
								a.close()
							}
						})
					}).addStyleClass("sapUiPopupWithPadding");
					a.open()
				},
				getSRMCartItems: function(s, c, b) {
					if (typeof(b) === undefined) {
						b = true
					}
					var o = jQuery.proxy(function(d, r) {
						if (s) {
							s.call(d, r)
						}
					}, this);
					var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					var p = "SRMShoppingCartCollection(OBJECT_ID='" + c + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartItemNavigation?ts=" +
						Date.now();
					O.read(p, null, null, b, o, jQuery.proxy(this.onRequestFailed, this))
				},
				saveSRMShoppingCart: function(s, o, d, a) {
					var I;
					var t = this;
					var b = jQuery.proxy(function(D, r) {
						I = D;
						I.CURRENCY = d.oData.results[0].CURRENCY;
						I.CITY = this.getView().byId("city").getValue();
						I.COUNTRY = t.country_key;
						I.STREET = this.getView().byId("street").getValue();
						I.APRV_NOTE = a
					}, this);
					var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					var p = "SRMShoppingCartCollection(OBJECT_ID='" + o + "',DOC_MODE='DISPLAY',WIID='000000000000')?ts=" + Date.now();
					O.read(p, null, null, false, b, jQuery.proxy(this.onRequestFailed, this));
					for (var i = 0; i < t.oCountryModel.oData.results.length; i++) {
						if (this.getView().byId("input_assisted1").getValue() === t.oCountryModel.oData.results[i].CountryName) {
							I.COUNTRY = t.oCountryModel.oData.results[i].CountryKey;
							t.country_key = t.oCountryModel.oData.results[i].CountryKey
						}
					}
					if (this.extHook1) {
						this.extHook1()
					};
					if (this.extHook2) {
						this.extHook2()
					};
					var c = {};
					c.ACC_NO = '0001';
					c.WIID = '000000000000';
					c.DISTR_PERC = '100.0';
					c.G_L_ACCT = this.oUserDefaults.oData.G_L_ACCT;
					if (this.co_area === "") {
						this.co_area = this.oUserDefaults.oData.CO_AREA
					}
					var e = this.getView().byId("input_assisted3").getValue().trim();
					var f = this.oBundle.getText("COST_CENTER").trim();
					var g = this.oBundle.getText("INTERNAL_ORDER").trim();
					if (e === f) {
						c.COST_CTR = this.getView().byId("input_assisted2").getValue();
						c.ACC_CAT = 'CC';
						c.CO_AREA = t.co_area
					} else if (e === g) {
						c.ORDER_NO = this.getView().byId("input_assisted2").getValue();
						c.ACC_CAT = 'OR';
						c.CO_AREA = t.co_area
					} else if (e === "") {
						c.CO_AREA = this.oUserDefaults.oData.CO_AREA
					}
					var h = {};
					h.ShoppingCartID = o;
					h.WIID = '000000000000';
					h.City = this.getView().byId("city").getValue();
					h.Name = this.oUserDefaults.oData.REQUESTOR_DESC;
					h.CountryName = this.getView().byId("input_assisted1").getValue();
					h.Country = t.country_key;
					h.Street = this.getView().byId("street").getValue();
					h.PostalCode1 = this.getView().byId("zip").getValue();
					var S = function() {
						s.call()
					};
					this.getSRMCartItems(jQuery.proxy(function(D, r) {
						var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
						var B = new Array();
						for (var i = 0; i < D.data.results.length; i++) {
							D.data.results[i].DELIV_DATE = this.getView().byId("dateplusseven").getDateValue() === null ? "" : this.getView().byId(
								"dateplusseven").getDateValue();
							var j = new Date();
							j.setUTCMonth(D.data.results[i].DELIV_DATE.getMonth());
							j.setUTCDate(D.data.results[i].DELIV_DATE.getDate());
							j.setUTCFullYear(D.data.results[i].DELIV_DATE.getFullYear());
							j.setUTCHours(00);
							j.setUTCMinutes(00);
							j.setUTCSeconds(00);
							D.data.results[i].DELIV_DATE = j;
							delete D.data.results[i].__metadata;
							delete D.data.results[i].SourceofSupplyNavigation;
							delete D.data.results[i].ItemAccountAssignmentNavigation;
							delete D.data.results[i].ItemApproverNavigation;
							delete D.data.results[i].ItemAttachmentNavigation;
							delete D.data.results[i].ItemShippingAddressNavigation;
							B.push(O.createBatchOperation("SRMShoppingCartItemCollection(NUMBER_INT='" + D.data.results[i].NUMBER_INT + "',OBJECT_ID='" + o +
								"',DOC_MODE='',WIID='000000000000')", "PUT", D.data.results[i]));
							c.NUMBER_INT = D.data.results[i].NUMBER_INT;
							B.push(O.createBatchOperation("AccountAssignmentCollection(NUMBER_INT='" + c.NUMBER_INT + "',OBJECT_ID='" + o +
								"',ACC_NO='0001',DOC_MODE='',WIID='000000000000')", "PUT", c));
							h.ItemNumber = D.data.results[i].NUMBER_INT;
							B.push(O.createBatchOperation("ShippingAddressCollection(ItemNumber='" + c.NUMBER_INT + "',ShoppingCartID='" + o +
								"',DOC_MODE='',WIID='000000000000')", "PUT", h))
						}
						O.addBatchChangeOperations(B);
						O.submitBatch(S, jQuery.proxy(this.onRequestFailed, this))
					}, this), o)
				},
				saveTempCart: function(s, t, o) {
					var i = {
						TEMP_CART_ID: this.getTempCartId(),
						CHECKOUT: "X",
						WAERS: this.oDefaultSettings.oData.results[0].CURRENCY
					};
					if (o !== null) {
						i.OBJECT_ID = o
					};
					var e = function(E) {
						this.busyDialog.close();
						jQuery.sap.require("sap.ca.ui.message.message");
						sap.ca.ui.message.showMessageBox({
							type: sap.ca.ui.message.Type.ERROR,
							message: E.message,
							details: jQuery.parseJSON(E.response.body).error.message.value
						})
					};
					var S = jQuery.proxy(function(D, r) {
						if (s) {
							s.call(D, r)
						}
					}, this);
					var a = this.getView().byId("noteToApprover").getValue();
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					d.create("ShoppingcartCollection", i, null, jQuery.proxy(function(D, r) {
						this.saveSRMShoppingCart(S, D.OBJECT_ID, this.oDefaultSettings, a)
					}, this), jQuery.proxy(e, this))
				},
				submitTempCart: function(s, t, o) {
					var i = {
						TEMP_CART_ID: t,
						ORDER: "X"
					};
					var e = function(E) {
						this.busyDialog.close();
						var c = function() {
							if (sap.ui.getCore().byId("SCNumber")) {
								sap.ui.getCore().byId("SCNumber").destroy()
							}
						};
						jQuery.sap.require("sap.ca.ui.message.message");
						sap.ca.ui.message.showMessageBox({
							type: sap.ca.ui.message.Type.ERROR,
							message: E.message,
							details: jQuery.parseJSON(E.response.body).error.message.value
						}, c)
					};
					var S = jQuery.proxy(function(d, r) {
						var O = this.oApplicationFacade.getODataModel("SHOPPING_CART");
						O.create("ShoppingcartCollection", i, null, jQuery.proxy(function(d, r) {
							if (s) {
								s.call(d, r)
							}
						}, this), jQuery.proxy(e, this))
					}, this);
					this.saveTempCart(S, t, o)
				},
				onSubmit: function() {
					this.busyDialog.open();
					var t = this;
					var a = this.getView().byId("input_assisted2").getValue().trim();
					if (a === "") {
						this.busyDialog.close();
						sap.m.MessageBox.alert(this.oBundle.getText("WARNING_ON_SUBMIT"));
						return
					}
					var c = this.getCountryStatus();
					if (c != true) {
						this.busyDialog.close();
						sap.m.MessageBox.alert(this.oBundle.getText("WARNING_COUNTRY_ON_SUBMIT"));
						return
					}
					var b = null;
					b = new sap.m.Dialog({
						title: this.oBundle.getText("CONFIRMATION"),
						rightButton: new sap.m.Button({
							text: this.oBundle.getText("DONE"),
							press: function() {
								b.close();
								b.destroyContent();
								t.oRouter.navTo("master", null, true);
								t.getView().byId("noteToApprover").setValue("")
							}
						})
					}).addStyleClass("sapUiPopupWithPadding");
					this.submitTempCart(jQuery.proxy(function(d, r) {
						this.busyDialog.close();
						var e = new sap.m.Text("SCNumber");
						b.addContent(e);
						e.setText(t.oBundle.getText("SUCCESSFUL").replace("{0}", d.data.OBJECT_ID));
						b.open()
					}, this), this.getTempCartId(), this.getCartObjectId())
				},
				onCountryValueHelpRequest: function(e) {
					var t = this;
					var a = this.oBundle.getText("SELECT_COUNTRY");
					var p = "/results";
					var b = "{CountryName}";
					var d = "{CountryKey}";
					var f = "CountryName";
					var m = "Country";
					var c = this.getView().byId("input_assisted1");
					var h = function(e) {
						var s = e.getParameter("selectedItem");
						if (s) {
							c.setValue(s.getTitle());
							t.country_key = s.getDescription()
						}
						e.getSource().getBinding("items").filter([])
					};
					this._valueHelpSelectDialog = new sap.m.SelectDialog({
						title: a,
						items: {
							path: p,
							template: new sap.m.StandardListItem({
								title: b,
								description: d,
								active: true
							})
						},
						search: function(e) {
							var v = e.getParameter("value");
							var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);
							e.getSource().getBinding("items").filter([F])
						},
						confirm: h,
						cancel: h
					});
					this._valueHelpSelectDialog.setModel(this.getView().getModel(m));
					this._valueHelpSelectDialog.open()
				},
				onAssignmentTypeValueHelpRequest: function(e) {
					var t = this;
					var a = this.getView().byId("input_assisted3").getValue();
					var b = this.getView().byId("input_assisted2");
					var c = "";
					var d = "";
					var p = "";
					var f = "";
					var g = "";
					var m = "";
					var i = "";
					switch (a) {
						case this.oBundle.getText("COST_CENTER"):
							m = this.createModel('CostCenter', 'CostCenterTabCollection', null, "ACC_ASS_SEARCH_HELP");
							c = this.oBundle.getText("COST_ASSIGNMENT");
							p = "/results";
							d = "{COST_CTR}";
							f = "{CC_DESCRIPTION}";
							g = "COST_CTR";
							i = "{CO_AREA}";
							break;
						case this.oBundle.getText("INTERNAL_ORDER"):
							m = this.createModel('InternalOrder', 'OrderNoTabCollection', null, "ACC_ASS_SEARCH_HELP");
							c = this.oBundle.getText("COST_ASSIGNMENT");
							p = "/results";
							d = "{ORDER_NO}";
							f = "{OR_DESCRIPTION}";
							g = "ORDER_NO";
							i = "{CO_AREA}";
							break;
						case "":
							this.busyDialog.close();
							sap.m.MessageBox.alert(this.oBundle.getText("SELECT_ACCOUNT_ASSIGNMENT_ALERT"));
							return;
						default:
							this.busyDialog.close();
							sap.m.MessageBox.alert(this.oBundle.getText("SELECT_VALID_ACCOUNT_ASSIGNMENT"));
							return
					}
					var h = function(e) {
						var s = e.getParameter("selectedItem");
						if (s) {
							b.setValue(s.getTitle());
							t.co_area = s.getInfo()
						}
						e.getSource().getBinding("items").filter([])
					};
					this._valueHelpSelectDialog = new sap.m.SelectDialog({
						title: c,
						items: {
							path: p,
							template: new sap.m.StandardListItem({
								title: d,
								description: f,
								info: i,
								active: true
							})
						},
						search: function(e) {
							var v = e.getParameter("value");
							var F = new sap.ui.model.Filter(g, sap.ui.model.FilterOperator.Contains, v);
							e.getSource().getBinding("items").filter([F])
						},
						confirm: h,
						cancel: h
					});
					this._valueHelpSelectDialog.setModel(this.getView().getModel(m));
					this._valueHelpSelectDialog.open()
				},
				onAccountAssignmentValueHelpRequest: function(e) {
					var t = this.oBundle.getText("COST_TYPE");
					var p = "/results";
					var a = "{accAssg}";
					var f = "accAssg";
					var b = this.getView().byId("input_assisted3");
					var c = this.getView().byId("input_assisted2");
					var h = function(e) {
						var s = e.getParameter("selectedItem");
						if (s) {
							b.setValue(s.getTitle());
							c.setValue("")
						}
						e.getSource().getBinding("items").filter([])
					};
					this._valueHelpSelectDialog = new sap.m.SelectDialog({
						title: t,
						items: {
							path: p,
							template: new sap.m.StandardListItem({
								title: a,
								active: true
							})
						},
						search: function(e) {
							var v = e.getParameter("value");
							var F = new sap.ui.model.Filter(f, sap.ui.model.FilterOperator.Contains, v);
							e.getSource().getBinding("items").filter([F])
						},
						confirm: h,
						cancel: h
					});
					this._valueHelpSelectDialog.setModel(this.getView().getModel("AccountAssignment"));
					this._valueHelpSelectDialog.open()
				},
				onNavigateBack: function() {
					window.history.back()
				},
				createHeaderFooterOptions: function() {
					var t = this;
					return {
						sFullscreenTitle: t.oBundle.getText("ORDER_TITLE"),
						onBack: jQuery.proxy(function(e) {
							t.oRouter.navTo("shoppingCartItems", {
								tempCartId: t.tempCartId
							}, true);
							t.getView().byId("noteToApprover").setValue("")
						}),
						oEditBtn: {
							sI18nBtnTxt: "SUBMIT_CART",
							onBtnPressed: jQuery.proxy(t.onSubmit, t)
						},
						buttonList: [{
							sI18nBtnTxt: "CANCEL",
							onBtnPressed: jQuery.proxy(t.onCancel, t)
						}],
						oAddBookmarkSettings: {
							title: t.oBundle.getText("ORDER_TITLE"),
							icon: "sap-icon://cart"
						}
					}
				},
				onRequestFailed: function(e) {
					this.busyDialog.close();
					jQuery.sap.require("sap.ca.ui.message.message");
					sap.ca.ui.message.showMessageBox({
						type: sap.ca.ui.message.Type.ERROR,
						message: e.message,
						details: e.response.body
					})
				},
				getCountryStatus: function() {
					for (var i = 0; i < this.oCountryModel.oData.results.length; i++) {
						if (this.getView().byId("input_assisted1").getValue() === this.oCountryModel.oData.results[i].CountryName) {
							return true
						}
					}
					return false
				},
				onAfterRendering: function() {},
				onExit: function() {},
				onBeforeRendering: function() {}
			})
		},
		"ui/s2p/srm/sc/create/view/ShoppingCartCheckout.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View controllerName="ui.s2p.srm.sc.create.view.ShoppingCartCheckout"\n\txmlns="sap.m" xmlns:form="sap.ui.layout.form" xmlns:sap.ui.layout="sap.ui.layout"\n\txmlns:sap.ui.core="sap.ui.core">\n\t<Page class="sapUiFioriObjectPage"\n\t\tnavButtonTap="_navBack" \n\t\tshowNavButton="true">\n\t\t<content>\n\t\t\t<form:SimpleForm editable="true">\n\t\t\t\t<form:content>\n\t\t\t\t\t<sap.ui.core:Title text="{i18n>INFORMATION}"></sap.ui.core:Title>\n\t\t\t\t\t<Label text="{i18n>TOTAL_VALUE}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="totalValue" editable="false">\n \t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData> \n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>COST_ASSIGNMENT}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="input_assisted3" value="{i18n>COST_CENTER}"\n\t\t\t\t\t\tplaceholder="{i18n>SELECT_ACCOUNT_ASSIGNMENT}" showValueHelp="true"\n\t\t\t\t\t\tshowSuggestion="true" suggestionItems="{AccountAssignment>/results}"\n\t\t\t\t\t\twidth="50%" valueHelpRequest="onAccountAssignmentValueHelpRequest">\n\t\t\t\t\t\t<suggestionItems>\n\t\t\t\t\t\t\t<sap.ui.core:Item text="{AccountAssignment>accAssg}"></sap.ui.core:Item>\n\t\t\t\t\t\t</suggestionItems>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>ASSIGNMENT_TYPE}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="input_assisted2" value="{personalCollection>/COST_CTR}"\n\t\t\t\t\t\tplaceholder="{i18n>SELECT_ASSIGNMENT_TYPE}" showValueHelp="true"\n\t\t\t\t\t\tshowSuggestion="true" width="50%" valueHelpRequest="onAssignmentTypeValueHelpRequest">\n\n\t\t\t\t\t</Input>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Extension point added for more information  -->\n\t\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extMoreInfo2"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\t\n\t\t\t\t\t<Label text="{i18n>REQUESTED_DELIVERY}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<DateTimeInput id="dateplusseven" width="50%"\n                         valueFormat="dd-MM, yyyy">\n                        <layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</DateTimeInput>\n\t\t\t\t\t<Label text="{i18n>DELIVERY_ADDRESS}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="street" value="{personalCollection>/STREET}"\n\t\t\t\t\t\twidth="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>CITY}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="city" value="{personalCollection>/CITY}" width="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>STATE}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="state" value="{personalCollection>/REGION}" width="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>ZIP}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<Input id="zip" value="{personalCollection>/POSTL_COD1}"\n\t\t\t\t\t\twidth="50%">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>COUNTRY}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\n\t\t\t\t\t<Input id="input_assisted1" value="{personalCollection>/COUNTRY_DESC}"\n\t\t\t\t\t\tplaceholder="{i18n>SELECT_COUNTRY}" showValueHelp="true"\n\t\t\t\t\t\tshowSuggestion="true" suggestionItems="{Country>/results}" width="50%"\n\t\t\t\t\t\tvalueHelpRequest="onCountryValueHelpRequest">\n\t\t\t\t\t\t<suggestionItems>\n\t\t\t\t\t\t\t<sap.ui.core:Item text="{Country>CountryName}"></sap.ui.core:Item>\n\t\t\t\t\t\t</suggestionItems>\n\t\t\t\t\t</Input>\n\t\t\t\t\t<Label text="{i18n>NOTE_TO_APPROVER}">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</Label>\n\t\t\t\t\t<TextArea id="noteToApprover" width="50%" wrapping="None">\n\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t</TextArea>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Extension point added for more information  -->\n\t\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extMoreInfo3"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\n\t\t\t\t</form:content>\n\t\t\t</form:SimpleForm>\n\t\t\t<Table id="MaterialList" class="sapSccList" inset="true"\n\t\t\t\titems="{ShoppingCartItems>/results}">\n\t\t\t\t<items>\n\t\t\t\t\t<ColumnListItem unread="true" counter="0">\n\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t<ObjectIdentifier title="{ShoppingCartItems>DESCRIPTION}"\n\t\t\t\t\t\t\t\tbadgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n\t\t\t\t\t\t\t<ObjectNumber\n\t\t\t\t\t\t\t\tnumber="{path:\'ShoppingCartItems>QUANTITY\', type:\'sap.ca.ui.model.type.Number\', formatOptions:{decimals:0}}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>UNIT}"></ObjectNumber>\n\t\t\t\t\t\t\t<ObjectNumber number="{parts:[{path:\'ShoppingCartItems>ITM_TOTAL_PRICE\'},{path:\'ShoppingCartItems>CURRENCY\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPrice\'}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>CURRENCY}"></ObjectNumber>\n\t\t\t\t\t\t</cells>\n\t\t\t\t\t</ColumnListItem>\n\t\t\t\t</items>\n\t\t\t\t<columns>\n\t\t\t\t\t<Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>DESCRIPTION}" textAlign="Left" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column width="20%" hAlign="Right" minScreenWidth="tablet"\n\t\t\t\t\t\tdemandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>QUANTITY_LBL}" textAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column hAlign="Right" minScreenWidth="tablet" demandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>SUB_TOTAL}" textAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t</columns>\n\t\t\t</Table>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footerBar" translucent="true">\n\t\t\t</Bar>\n\t\t</footer>\n\t</Page>\n\n</sap.ui.core:View>\n',
		"ui/s2p/srm/sc/create/view/ShoppingCartItems.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("ui.s2p.srm.sc.create.util.Formatter");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("ui.s2p.srm.sc.create.view.ShoppingCartItems", {
				onInit: function() {
					sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
					this.oBundle = this.oApplicationFacade.getResourceBundle();
					this.busyDialog = new sap.m.BusyDialog({
						customIcon: sap.ca.ui.images.images.Flower
					});
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "shoppingCartItems") {
							var t = this;
							this.Temp_Cart_Id = e.getParameter("arguments").tempCartId;
							this.busyDialog.open();
							jQuery.proxy(this.getShoppingCartItemDetails(), t)
						}
					}, this);
					this.setHeaderFooterOptions(this.createHeaderFooterOptions())
				},
				getShoppingCartItemDetails: function() {
					var o = function(D, r) {
						var m = new sap.ui.model.json.JSONModel(D);
						this.getView().setModel(m, "ShoppingCartHeader");
						var i = ui.s2p.srm.sc.create.util.Formatter.formatItemCount(m.oData.ITM_COUNT);
						this.getView().byId("MaterialList").setHeaderText(i)
					};
					var a = function(D, r) {
						var m = new sap.ui.model.json.JSONModel(D);
						this.originalModel = m.oData.results;
						if (m.oData.results.length > 0) {
							this.setBtnEnabled("checkoutBtn", true);
							this.setBtnEnabled("updateBtn", true)
						} else {
							this.setBtnEnabled("checkoutBtn", false);
							this.setBtnEnabled("updateBtn", false)
						}
						for (var i = 0; i < m.oData.results.length; i++) {
							m.oData.results[i].ITM_TOTAL_PRICE = (parseFloat(m.oData.results[i].QUANTITY) * parseFloat(m.oData.results[i].PRICE).toString()).toFixed(
								2)
						}
						this.getView().setModel(m, "ShoppingCartItems");
						this.busyDialog.close()
					};
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					d.setHeaders({
						"Cache-Control": "no-cache, no-store, must-revalidate",
						"Pragma": "no-cache",
						"Expires": "-1"
					});
					var p = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')?ts=" + Date.now();
					d.read(p, null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this));
					var P = "ShoppingcartCollection(TEMP_CART_ID='" + this.Temp_Cart_Id + "')/ShoppingCartItemNavigation?ts=" + Date.now();
					d.read(P, null, null, true, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this))
				},
				onQuantityChanged: function(e) {
					var v = e.getParameters().newValue;
					var c = Math.floor(v);
					if (c < 1) {
						c = 1
					}
					if (c != v) {
						e.getSource().setValue(c)
					}
					var i = e.getParameter("id");
					var a = parseInt(i.substring(i.lastIndexOf("-") + 1), 10);
					if (!this.quantities) {
						this.quantities = []
					}
					this.quantities[a] = c;
					if (this.quantities) {
						this.setBtnEnabled("checkoutBtn", false)
					}
				},
				removeItem: function(e) {
					var l = e.getSource();
					var b = l.getBindingContext("ShoppingCartItems");
					var m = b.getModel();
					var p = b.getPath();
					var i = m.getProperty(p);
					var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
					d.remove("ShoppingcartItemCollection(ITEM_NO='" + i.ITEM_NO + "',TEMP_CART_ID='" + this.Temp_Cart_Id + "')", null, jQuery.proxy(this
						.getShoppingCartItemDetails, this), jQuery.proxy(this.onRequestFailed, this))
				},
				_cloneItemData: function(s) {
					return {
						'ITEM_NO': s.ITEM_NO,
						'TEMP_CART_ID': s.TEMP_CART_ID,
						'DESCRIPTION': s.DESCRIPTION,
						'QUANTITY': s.QUANTITY,
						'UNIT': s.UNIT,
						'PRICE': s.PRICE.toString(),
						'CURRENCY': s.CURRENCY,
						'PRODUCTKEY': s.PRODUCTKEY,
					}
				},
				onUpdateCart: function(e) {
					var m = this.originalModel;
					if (this.quantities) {
						this.busyDialog.open();
						var d = this.oApplicationFacade.getODataModel("SHOPPING_CART");
						var b = new Array();
						for (var i = 0; i < this.quantities.length; i++) {
							if (this.quantities[i] && parseInt(m[i].QUANTITY, 10) != this.quantities[i]) {
								var a = this._cloneItemData(m[i]);
								a.QUANTITY = this.quantities[i].toString();
								var p = "ShoppingcartItemCollection(ITEM_NO=\'" + a.ITEM_NO + "\',TEMP_CART_ID=\'" + this.Temp_Cart_Id + "\')?ts=" + Date.now();
								b.push(d.createBatchOperation(p, "PUT", a))
							}
						}
						if (b.length === 0) {
							this.quantity = null;
							this.busyDialog.close();
							this.setBtnEnabled("checkoutBtn", this.getView().getModel("ShoppingCartItems").getData().results.length > 0);
							return
						}
						d.addBatchChangeOperations(b);
						var o = function(r) {
							this.quantities = null;
							this.getShoppingCartItemDetails();
							this.setBtnEnabled("checkoutBtn", true);
							var c = r && r.__batchResponses ? r.__batchResponses : [];
							for (var i = 0; i < c.length; i++) {
								if (c[0] && c[0].response && c[0].response.statusCode == "400") {
									this.onRequestFailed(c[0]);
									return
								}
							}
							jQuery.sap.require("sap.m.MessageToast");
							sap.m.MessageToast.show("Updated Successfully");
							this.busyDialog.close()
						};
						d.submitBatch(jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this))
					} else {
						this.busyDialog.close();
						this.setBtnEnabled("checkoutBtn", this.getView().getModel("ShoppingCartItems").getData().results.length > 0)
					}
				},
				onCheckoutCart: function() {
					this.oRouter.navTo("shoppingCartCheckout", {
						tempCartId: this.Temp_Cart_Id,
					}, true);
					var t = this.getView().getModel("ShoppingCartHeader").oData.TOTAL_VALUE + " " + this.getView().getModel("ShoppingCartHeader").oData.WAERS;
					var c = sap.ui.core.Component.getOwnerIdFor(this.oView);
					var C = sap.ui.component(c);
					C.oEventBus.publish("ui.s2p.srm.sc.create", "refreshShoppingCartCheckout", {
						totalValue: t
					})
				},
				createHeaderFooterOptions: function() {
					var t = this;
					return {
						sFullscreenTitle: t.oBundle.getText("CART_TITLE"),
						onBack: jQuery.proxy(function(e) {
							t.oRouter.navTo("noData", {
								viewTitle: "DETAIL_TITLE",
								languageKey: "NO_ITEMS_AVAILABLE"
							}, true)
						}),
						buttonList: [{
							sId: "updateBtn",
							sI18nBtnTxt: "UPDATE_BUTTON",
							onBtnPressed: jQuery.proxy(t.onUpdateCart, t)
						}],
						oEditBtn: {
							sId: "checkoutBtn",
							sI18nBtnTxt: "CHECKOUT_BUTTON",
							onBtnPressed: jQuery.proxy(t.onCheckoutCart, t)
						},
						oAddBookmarkSettings: {
							title: t.oBundle.getText("CART_TITLE"),
							icon: "sap-icon://cart"
						}
					}
				},
				onRequestFailed: function(e) {
					this.busyDialog.close();
					jQuery.sap.require("sap.ca.ui.message.message");
					sap.ca.ui.message.showMessageBox({
						type: sap.ca.ui.message.Type.ERROR,
						message: e.message,
						details: e.response.body
					})
				},
				onAfterRendering: function() {},
				onExit: function() {},
				onBeforeRendering: function() {}
			})
		},
		"ui/s2p/srm/sc/create/view/ShoppingCartItems.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View controllerName="ui.s2p.srm.sc.create.view.ShoppingCartItems"\n    xmlns="sap.m"\n    xmlns:sap.ui.core="sap.ui.core" >\n    <Page class="sapUiFioriObjectPage" navButtonTap="_navBack" showNavButton="true" id="page">\n        <content>\n            <Table id="MaterialList" inset="true" footerText="{parts:[{path:\'i18n>TOTAL\'},{path:\'ShoppingCartHeader>/TOTAL_VALUE\'},{path:\'ShoppingCartHeader>/WAERS\'}]}" items="{ShoppingCartItems>/results}">\n                <items>\n                    <ColumnListItem unread="true" counter="0">\n                        <cells>\n                            <ObjectIdentifier title="{ShoppingCartItems>DESCRIPTION}" class="soc-table-label-elem-align" badgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n                            <Input liveChange="onQuantityChanged" value="{parts:[{path:\'ShoppingCartItems>QUANTITY\'},{path:\'ShoppingCartItems>UNIT\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatQuantity\'}" width="6em" type="Number"></Input>\n                            <Label text="{ShoppingCartItems>UNIT}" class="soc-table-label-elem-align"></Label>\n                            <ObjectNumber number="{parts:[{path:\'ShoppingCartItems>ITM_TOTAL_PRICE\'},{path:\'ShoppingCartItems>CURRENCY\'}],formatter:\'ui.s2p.srm.sc.create.util.Formatter.formatPrice\'}"\n                                          id="totalPrice" numberUnit="{ShoppingCartItems>CURRENCY}" class="soc-table-label-elem-align"></ObjectNumber>\n                            <Button tap="removeItem" type="Transparent" icon="sap-icon://decline"></Button>\n                        </cells>\n                    </ColumnListItem>\n                </items>\n                <columns>\n                    <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>DESCRIPTION}" textAlign="Left" width="100%"></Label>\n                        </header>\n                    </Column>\n                    <Column width="6em" hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>QUANTITY_LBL}" textAlign="Left" width="100%"></Label>\n                        </header>\n                    </Column>\n                    <Column width="6em" hAlign="Left" minScreenWidth="tablet" demandPopin="true"></Column>\n                    <Column width="8em" hAlign="Right" minScreenWidth="tablet" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>Subtotal}" textAlign="Right" width="100%"></Label>\n                        </header>\n                    </Column>\n                    <Column width="4em" hAlign="Right" minScreenWidth="phone"></Column>\n                </columns>\n            </Table>\n        </content>\n        <footer>\n            <Bar id="footerBar" translucent="true">\n            </Bar>\n        </footer>\n    </Page>\n</sap.ui.core:View>'
	}
});