sap.ui.jsview("drlhub.view.Hub", {
    /** Specifies the Controller belonging to this View. 
     * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
     * @memberOf view.Overview
     */
    getControllerName: function() {
        return "drlhub.view.Hub";
    },
    /**
     * Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
     * Since the Controller is given to this method, its event handlers can be attached right away. 
     * @memberOf view.Overview
     * @param {type} oController
     * @returns {unresolved}
     */
    createContent: function(oController) {
        var row = sap.ui.commons.layout.MatrixLayoutRow;
        var cell = sap.ui.commons.layout.MatrixLayoutCell;
        var bg = sap.ui.commons.layout.BackgroundDesign.Plain;
        var sep = sap.ui.commons.layout.Separation.Small;
        return new sap.ui.commons.layout.MatrixLayout({
            layoutFixed: true,
            columns: 4,
            width: '85%',
            widths: ['49%', '2%', '22%', '27%'],
            rows: [
                new row({
                    height: '40px',
                    cells: [
                        new cell({
                            colSpan: 3,
                            content: [
                                new sap.ui.commons.Label({
                                    text: 'This Financial Year,'
                                })
                            ]
                        }).addStyleClass('top-image'),
                        new cell({
                            colSpan: 1,
                            rowSpan: 2,
                            content: new sap.m.CustomTile({
                                content: new sap.ui.layout.VerticalLayout({
                                    width: '100%',
                                    height: '100%',
                                    content: [
                                        new sap.ui.commons.TextView({
                                            text: 'More Insights @'
                                        }),
                                        new sap.ui.commons.TextView({
                                            width: '100%',
                                            height: '100px',
                                            text: 'END 2 END Visibility Report'
                                        })]
                                }),
                                press: function() {
                                    console.log('pressed');
                                }
                            }).addStyleClass('top-right-button-cont')
                        }).addStyleClass('top-right-cell')
                    ]
                }),
                new row({
                    height: '100px',
                    cells: [
                        new cell({
                            colSpan: 3,
                            content: createTopBarLeftSide()
                        }).addStyleClass('bottom-tabs')
                    ]
                }),
                new row(this.createId('firstSep'), {
                    height: '30px',
                    cells: [
                        new cell({
                            colSpan: 4
                        })
                    ]
                }),
                new row(this.createId('firstRow'), {
                    height: '100px',
                    cells: [
                        new cell({
                            colSpan: 1,
                            rowSpan: 3,
                            separation: sep,
                            backgroundDesign: bg,
                            content: createRfx(oController)
                        }),
                        getBlankCell(1),
                        new cell({
                            colSpan: 2,
                            backgroundDesign: bg,
                            separation: sep,
                            content: createAlerts()
                        })
                    ]
                }),
                getSeparator(this, 'second', 0),
                new row(this.createId('secondRow'), {
                    height: '200px',
                    cells: [
                        getBlankCell(1),
                        new cell({
                            colSpan: 2,
                            rowSpan: 5,
                            backgroundDesign: bg,
                            separation: sep,
                            content: createInvoice(oController)
                        })
                    ]
                }),
                getSeparator(this, 'third', 2),
                new row(this.createId('thirdRow'), {
                    height: '180px',
                    cells: [
                        new cell({
                            colSpan: 1,
                            rowSpan: 1,
                            backgroundDesign: bg,
                            separation: sep,
                            content: createPO(oController)
                        }),
                        getBlankCell(1)
                    ]
                }),
                getSeparator(this, 'fourth', 2),
                new row(this.createId('fourthRow'), {
                    height: '126px',
                    cells: [
                        new cell({
                            colSpan: 1,
                            rowSpan: 3,
                            backgroundDesign: bg,
                            separation: sep,
                            content: createASN(oController)
                        }),
                        getBlankCell(1)
                    ]
                }),
                getSeparator(this, 'fifth', 3),
                new row(this.createId('fifthRow'), {
                    height: '120px',
                    cells: [
                        getBlankCell(1),
                        new cell({
                            colSpan: 2,
                            rowSpan: 3,
                            separation: sep,
                            backgroundDesign: bg,
                            content: createPayment(oController)
                        })
                    ]
                }),
                getSeparator(this, 'sixth', 2),
                new row(this.createId('sixthRow'), {
                    height: '200px',
                    cells: [
                        new cell({
                            colSpan: 1,
                            rowSpan: 3,
                            backgroundDesign: bg,
                            separation: sep,
                            content: createGRN(oController)
                        }),
                        getBlankCell(1)
                    ]
                }),
                getSeparator(this, 'seventh', 3),
//                new row(this.createId('seventhRow'), {
//                    height: '90px',
//                    cells: [
//                        getBlankCell(1),
//                        new cell({
//                            colSpan: 2,
//                            rowSpan: 4,
//                            backgroundDesign: bg,
//                            separation: sep,
//                            content: createFlaggedItems()
//                        })
//                    ]
//                }),
//                getSeparator(this, 'eight', 2),
//                new row(this.createId('eighthRow'), {
//                    height: '210px',
//                    cells: [
//                        new cell({
//                            colSpan: 1,
//                            backgroundDesign: bg,
//                            separation: sep,
//                            content: createWhatsNew()
//                        }),
//                        getBlankCell(1)
//                    ]
//                }),
                new row(this.createId('ninethRow'), {
                    height: '160px',
                    cells: [
                        getBlankCell(2)
                    ]
                })
            ]
        }).addStyleClass('main-layout');
    }
});

/**
 * Blank cells
 * @param {type} span
 * @returns {sap.ui.commons.layout.MatrixLayoutCell}
 */
function getBlankCell(span) {
    return new sap.ui.commons.layout.MatrixLayoutCell({
        colSpan: span
    });
}

/**
 * 
 * @param {type} _this
 * @param {type} id
 * @param {type} span
 * @returns {sap.ui.commons.layout.MatrixLayoutRow}
 */
function getSeparator(_this, id, span) {
    return new sap.ui.commons.layout.MatrixLayoutRow(_this.createId(id + 'Sep'), {
        height: '20px',
        cells: getBlankCell(span)
    });
}

/**
 * Create header of each panel
 * @param {type} text
 * @param {type} id
 * @returns {Array|createHeader.header}
 */
function createHeader(text, id, oController) {
    var header = [];
    if (text !== null) {
        header.push(new sap.ui.commons.TextView({
            text: text
        }).addStyleClass('rfx-header-text'));
    }

    if (id !== null) {
        header.push(new sap.ui.commons.DropdownBox({
            width: '130px',
            items: [
                {
//                    key: '1',
                	key: 'M03',
                    text: 'Last 3 months'
                },
                {
//                    key: '2',
                	key: 'M06',
                    text: 'Last 6 months'
                },
                {
//                    key: '3',
                	key: 'M12',
                    text: 'Past 1 Year'
                }
            ],
            change:function(oEvent)
            {
//                console.log('############ text:  ' + text + '      id:  ' + id + '  selected itemid:  ' + oEvent.oSource.getSelectedItemId() + '   selected key:  ' + oEvent.oSource.getSelectedKey());
//            	alert('Selected Value:   ' + oEvent.oSource.getSelectedItemId() + '    ' + oEvent.oSource.getSelectedKey());
            	oController.drlHubDropDownBox(text, id, oEvent.oSource.getSelectedKey());
            },
            customData: [{
                    type: sap.ui.core.CustomData,
                    key: "panel",
                    value: id
                }]
//        }));
        }).addStyleClass('hub-dropdown'));
    }
    return header;
}

/**
 * Create the left side Business result portion of top panel
 * @returns {sap.suite.ui.commons.HeaderContainer}
 */
function createTopBarLeftSide() {
    return new sap.suite.ui.commons.HeaderContainer({
        scrollStep: 400,
        scrollTime: 500,
        items: [
            new sap.suite.ui.commons.HeaderCell({
                north: new sap.suite.ui.commons.HeaderCellItem({
                	
//					content : new sap.suite.ui.commons.NumericContent(Widgets.header.businessConducted.id, {
                	content : new sap.ui.commons.Label(Widgets.header.businessConducted.id, {
//						value: {
//									formatter: function(value) 
//									{
//										console.log('Business Conducted:  Value: ****&&&%%%%  ' + value);
//										if (value > 1000000) 
//										{
//											return 'Rs. ' + value / 1000000 + 'M';
//										} else 
//										{
//											return 'Rs. ' + value;
//										}
//									}
//						},
//                      size: sap.suite.ui.commons.InfoTileSize.S,
//                      truncateValueTo: 15,
                      icon: 'images/PO-icon.png'	//'images/business-icon.png'
				}).addStyleClass('sts-figure'),

                	
//                    content: new sap.suite.ui.commons.NumericContent({
//                        value: {
////                            path: 'HubModel>/OverviewData/results/TopPanelData/results/BusinessConducted',
//                        	path: "HubHeaderModel>/results/",
//                            formatter: function(value) {
//                                if (value > 1000000) {
//                                    return 'Rs. ' + value / 1000000 + 'M';
//                                } else {
//                                    return 'Rs. ' + value;
//                                }
//                            }
//                        },
//                        size: sap.suite.ui.commons.InfoTileSize.S,
//                        truncateValueTo: 15,
//                        icon: 'images/business-icon.png'
//                    })
                }),
                south: new sap.suite.ui.commons.HeaderCellItem({
                    content: new sap.ui.commons.TextView(Widgets.header.businessConducted.nameID, {
//                        text: 'Business Conducted'
                    })
                })
            }),
            new sap.suite.ui.commons.HeaderCell({
                north: new sap.suite.ui.commons.HeaderCellItem({
//                    content: new sap.suite.ui.commons.NumericContent({
//                        value: '{HubModel>/OverviewData/results/TopPanelData/results/PoConducted}',
//                        size: sap.suite.ui.commons.InfoTileSize.S,
//                        truncateValueTo: 15,
//                        icon: 'images/PO-icon.png'
//                    })
                	content : new sap.ui.commons.Label(Widgets.header.poConfirmed.id, {
                		icon: 'images/business-icon.png'	//'images/PO-icon.png'
                	}).addStyleClass('sts-figure')
                }),
                south: new sap.suite.ui.commons.HeaderCellItem({
                    content: new sap.ui.commons.TextView(Widgets.header.poConfirmed.nameID, {
//                        text: 'POs Confirmed'
                    })
                })
            }),
            new sap.suite.ui.commons.HeaderCell({
                north: new sap.suite.ui.commons.HeaderCellItem({
//                    content: new sap.suite.ui.commons.NumericContent({
//                        value: '{HubModel>/OverviewData/results/TopPanelData/results/Invoices}',
//                        size: sap.suite.ui.commons.InfoTileSize.S,
//                        truncateValueTo: 15,
//                        icon: 'images/invoice-icon.png'
//                    })
                	content : new sap.ui.commons.Label(Widgets.header.invoiceRaised.id, {
                		icon: 'images/invoice-icon.png'
                	}).addStyleClass('sts-figure')
                }),
                south: new sap.suite.ui.commons.HeaderCellItem({
                    content: new sap.ui.commons.TextView(Widgets.header.invoiceRaised.nameID, {
//                        text: 'Invoices Raised'
                    })
                })
            })
        ]
    });
}

/**
 * 
 * @param {type} _this
 * @returns {Array|createRfx.rfx}
 */
function createRfx(_this) {
    var chart = new sap.viz.ui5.Donut({
        id: "mychart",
        width: "100%",
        height: "180px",
        plotArea: {
            'colorPalette': d3.scale.category20().range()
        },
        legend: {
            content: []
        },
        dataset: new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [
                {
                    axis: 1,
                    value: '{HubModel>StatusText}'
//                    value: {
//                        path: 'HubModel>StatusText',
//                        formatter: function(value) {
//                        	console.log('********************************** value:  ' +  value);
//                            if (value == 'YETTORESPOND') {
//                                return 'Yet to respond';
//                            } else if (value == 'SUBMITTED') {
//                                return 'Submitted';
//                            }
//                        }
//                    }
                }
            ],
            measures: [{
                		value: '{HubModel>Count}'
                }],
            data: {
            	path: "HubModel>/results/"
            }
        })
    });
    var footer = new sap.ui.layout.HorizontalLayout({
        content: [
            
//                  	new sap.ui.commons.TextView(
//                  	{
//                  			text: 'Total Received'
//                  	}),
                  	new sap.ui.commons.TextView(Widgets.overview.totalReceived.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.overview.totalReceived.id).addStyleClass('rfx-value'),

                  	new sap.ui.commons.TextView(Widgets.overview.yetToRespond.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.overview.yetToRespond.id).addStyleClass('rfx-value'),

                  	new sap.ui.commons.TextView(Widgets.overview.submitted.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.overview.submitted.id).addStyleClass('rfx-value')

                  	
//            new sap.ui.commons.TextView({
//                text: '{LocalHubModel>/rfx/total}'
//            })
        ]
    });
    var rfx = [].concat(createHeader('RFx', 'rfx', _this));
    rfx.push(chart);
    rfx.push(footer);
    return rfx;
}

/**
 * 
 * @returns {Array}
 */
function createInvoice( _this) {
    var chart = new sap.viz.ui5.StackedColumn({
        width: "100%",
        height: "500px",
        plotArea: {
//        	colorPalette :['#ffdcdd','#ffb6b8', '#ff7679', '#e1262a', '#b61014', '#790306', '#434343']
            colorPalette: d3.scale.category20().range()
        },
        yAxis: {
            isIndependentMode: false,
            gridline: {
                visible: false,
                showFirstLine: false,
                showLastLine: false,
//                type: sap.viz.ui5.types.Axis_gridline_type.incised,//sap.viz.ui5.types.Axis_gridline_type.dotted
            },
            scale: {
                fixedRange: false,
//                minValue: 2,
//                maxValue: 60
            }
        },
        dataset: new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [
                {
                    axis: 1,
//                    name: 'Yet To Upload',
//                	value: '{HubInvoiceModel>yetToUpload}'
                }
            ],
            measures: [
                {
                    name: 'Yet To Upload',
                	value: '{HubInvoiceModel>yetToUpload}'
                },
                
                {
                    name: 'Pending for Hard Copy',
                    value: '{HubInvoiceModel>pendingForHardCopy}'
                },
                {
                    name: 'In-Process',
                    value: '{HubInvoiceModel>inProcess}'
                },
                {
                    name: 'Under Deviation',
                    value: '{HubInvoiceModel>underDeviation}'
                },
                {
                    name: 'Hold for Payment',
                    value: '{HubInvoiceModel>holdForPayment}'
                },
                {
                    name: 'Clear for payment',
                    value: '{HubInvoiceModel>clearForPayment}'
                },
                {
                    name: 'Payment Credited',
                    value: '{HubInvoiceModel>paymentCredited}'
                },
                {
                    name: 'Rejected',
                    value: '{HubInvoiceModel>rejected}'
                }
            ],
            data: {
            	path: "HubInvoiceModel>/invoiceResults/"
            }
        })
    });
    var content = [].concat(createHeader('Invoice', 'invoice',  _this));
    content.push(chart);
    return content;
}


/**
 * 
 * @returns {createPO.content|Array}
 */
function createPO(_this) {
    var container = new sap.ui.layout.HorizontalLayout({
    	content: [
              new sap.m.CustomTile({
                content: new sap.ui.layout.VerticalLayout({
                    content: [
							new sap.ui.commons.TextView(Widgets.overview.acknowledgedPO.id, {
							}),

							new sap.ui.commons.TextView(Widgets.overview.acknowledgedPO.nameID, {
							})
                    ]
                }),
                press: function() {
                    console.log('PO Tile pressed');
                }
            }),
            new sap.m.CustomTile({
                content: new sap.ui.layout.VerticalLayout({
                    content: [
                              new sap.ui.commons.TextView(Widgets.overview.newPO.id, {
                              }),
                              
                              new sap.ui.commons.TextView(Widgets.overview.newPO.nameID, {
                              })
                    ]
                }),
                press: function() {
                    console.log('PO Tile pressed');
                }
            })
        ]
    }).addStyleClass('po-layout');
    var content = [].concat(createHeader('PO', 'po', _this));
    content.push(container);

    return content;
}

/**
 * 
 * @returns {undefined}
 */
function createGRN(_this) {
    var chart = new sap.viz.ui5.StackedColumn({
//    var chart = new sap.viz.ui5.Bar({
        width: "100%",
//        width: "320px",
        height: "200px",
        plotArea: {
            colorPalette: d3.scale.category20().range()
//            colorPalette :['#339966','#66CC99']
        },
        title: {
            // visible : true,
            // text : 'Profit and Revenue By Country'
        },
        xAxis: {
            visible: false
        },
        yAxis: {
            visible: false
        },
        dataset: new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [
                {
                    axis: 1,
                    value: '{HubGRNModel>StatusText}'
                },
                {
                    axis: 2,
                    value: '{HubGRNModel>StatusText}'
                }
            ],
            measures: [
                {name: '{HubGRNModel>StatusText}', value: '{HubGRNModel>Count}'}
            ],
            data: {
            	path: "HubGRNModel>/results/"
            }
        }),
        beforeCreateViz: function(e) {
            var usrOptions = e.getParameter("usrOptions");
            console.log(usrOptions);
            // make the vertical stacked bar a horizontal stacked bar
            usrOptions.type = "viz/stacked_bar";
            // add a feeding definition to show MND
            usrOptions.feeding = [
                {
                    "feedId": "axisLabels",
                    "binding": [
                        {
                            "type": "measureNamesDimension"
                        },
                        {
                            "type": "analysisAxis",
                            "index": 1
                        }
                    ]
                },
                {
                    "feedId": "regionColor",
                    "binding": [
                        {
                            "type": "analysisAxis",
                            "index": 1,
                            "values": ['#000', '#66CC99']
                        }
                    ]
                },
                {
                    "feedId": "primaryValues",
                    "binding": [
                        {
                            "type": "measureValuesGroup",
                            "index": 1
                        }
                    ]
                }
            ];
        }
    });

    var footer = new sap.ui.layout.HorizontalLayout({
        content: [
                  	new sap.ui.commons.TextView(Widgets.overview.qcPending.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.overview.qcPending.id).addStyleClass('rfx-value'),
        ]
    });

    var footer1 = new sap.ui.layout.HorizontalLayout({
        content: [
                	new sap.ui.commons.TextView(Widgets.overview.approved.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.overview.approved.id).addStyleClass('rfx-value'),
        ]
    });

    var footer2 = new sap.ui.layout.HorizontalLayout({
        content: [
                	new sap.ui.commons.TextView(Widgets.overview.rejectedGrn.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.overview.rejectedGrn.id).addStyleClass('rfx-value'),
        ]
    });

    var footer3 = new sap.ui.layout.HorizontalLayout({
        content: [
                	new sap.ui.commons.TextView(Widgets.overview.returned.nameID).addStyleClass('rfx-total'),
                	new sap.ui.commons.TextView(Widgets.overview.returned.id).addStyleClass('rfx-value'),
        ]
    });
    
    var content = [].concat(createHeader('GRN', 'grn', _this));
    content.push(chart);
    content.push(footer);
    content.push(footer1);
    content.push(footer2);
    content.push(footer3);
    return content;
}

/**
 * 
 * @returns {undefined}
 */
function createASN(_this) {
    var container = new sap.ui.layout.HorizontalLayout({
        content: [
            new sap.m.CustomTile({
                content: new sap.ui.layout.VerticalLayout({
                    content: [
						new sap.ui.commons.TextView(Widgets.overview.pendingShipment.id, {
						}),

						new sap.ui.commons.TextView(Widgets.overview.pendingShipment.nameID, {
						})

                    ]
                }),
                press: function() {
                    console.log('ASN Tile pressed');
                }
            }),
            
            new sap.m.CustomTile({
                content: new sap.ui.layout.VerticalLayout({
                    content: [
						new sap.ui.commons.TextView(Widgets.overview.inTransit.id, {
						}),

						new sap.ui.commons.TextView(Widgets.overview.inTransit.nameID, {
						})

                    ]
                }),
                press: function() {
                    console.log('ASN Tile pressed');
                }
            }).addStyleClass('hub-tile'),

            new sap.m.CustomTile({
                content: new sap.ui.layout.VerticalLayout({
                    content: [
						new sap.ui.commons.TextView(Widgets.overview.gateEntryDone.id, {
						}),

						new sap.ui.commons.TextView(Widgets.overview.gateEntryDone.nameID, {
						})
                    ]
                }),
                press: function() {
                    console.log('ASN Tile pressed');
                }
            }).addStyleClass('hub-tile'),
        ]
    }).addStyleClass('asn-layout');
    
    var container1 = new sap.ui.layout.HorizontalLayout({
        content: [
                  
                  new sap.m.CustomTile({
                      content: new sap.ui.layout.VerticalLayout({
                          content: [
      						new sap.ui.commons.TextView(Widgets.overview.pedningForGRN.id, {
      						}),

      						new sap.ui.commons.TextView(Widgets.overview.pedningForGRN.nameID, {
      						})
                          ]
                      }),
                      press: function() {
                          console.log('ASN Tile pressed');
                      }
                  }).addStyleClass('hub-tile')

                  ]
    });
    
    var content = [].concat(createHeader('ASN', 'asn', _this));
    content.push(container);
    content.push(container1);
    return content;
}

/**
 * 
 * @returns {createWhatsNew.content|Array}
 */
function createWhatsNew() {
    var text = new sap.ui.commons.TextView({
        text: 'Dr.Reddy’s Won the Best Suply Chain Management Award and got nominated for Innovation in medicines',
        width: '97%'
    }).addStyleClass('top-text');
    var container = new sap.ui.layout.HorizontalLayout({
        content: [
            new sap.m.Button({
                text: 'RSS',
                height: '80px',
                width: '120px',
                type: sap.m.ButtonType.Unstyled
            }),
            new sap.m.Button({
                text: 'DRL Stocks',
                height: '80px',
                width: '120px',
                type: sap.m.ButtonType.Unstyled
            }),
            new sap.m.Button({
                text: '20 Posts',
                height: '80px',
                width: '120px',
                type: sap.m.ButtonType.Unstyled
            }),
            new sap.m.Button({
                text: '20 Posts',
                height: '80px',
                width: '120px',
                type: sap.m.ButtonType.Unstyled
            })
        ]
    }).addStyleClass('whats-new-layout');
    var content = [].concat(createHeader("What's New", null));
    content.push(text);
    content.push(container);

    return content;
}

/**
 * 
 * @returns {undefined}
 */
function createAlerts() {
    var text = new sap.ui.layout.HorizontalLayout({
        content: [
            new sap.ui.commons.TextView({
                text: 'You have 0 new alerts.',
                width: '97%'
            }),
            new sap.ui.commons.Link({
                text: 'Click here to view them.'
            })
        ]
    }).addStyleClass('alert-layout');
    var content = [].concat(createHeader("Alerts", null));
    content.push(text);

    return content;
}

/**
 * 
 * @returns {undefined}
 */
function createPayment(_this) {
    var chart = new sap.viz.ui5.Donut({
        id: "pchart",
//        width: "395px",
        width: "100%",
        height: "200px",
        plotArea: {
            // 'colorPalette' : d3.scale.category20().range()
            colorPalette: ['#99E6E6', '#0099CC', '#00FFCC']
        },
        dataset: new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [
                {
                    axis: 1,
                    name: '',
                    value: "{HubPaymentsModel>statusText}"
                }
            ],
            measures: [
                {
                    name: '',
                    value: '{HubPaymentsModel>valueText}'
                }
            ],
            data: {
                path: 'HubPaymentsModel>/paymentsResults/'		//HubHeaderModel
            }
        })
    });

    var footer = new sap.ui.layout.HorizontalLayout({
        content: [
                  	new sap.ui.commons.TextView(Widgets.header.paymentDetails.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.header.paymentDetails.id).addStyleClass('rfx-value'),

                  	new sap.ui.commons.TextView(Widgets.header.paymentDetails1.nameID).addStyleClass('rfx-total'),
                  	new sap.ui.commons.TextView(Widgets.header.paymentDetails1.id).addStyleClass('rfx-value'),
        ]
    });

    
    var content = [].concat(createHeader('Receivables', 'payment', _this));
    content.push(chart);
    content.push(footer);
    return content;
}

/**
 * 
 * @returns {createFlaggedItems.content|Array}
 */
function createFlaggedItems() {
    var oSimpleForm = new sap.m.VBox({
        maxContainerCols: 2,
        editable: false,
        items: {
            path: 'HubModel>/OverviewData/results/FlaggedItemData/results/',
            template: new sap.ui.layout.VerticalLayout({
                content: [
                    new sap.ui.commons.Label({
                        text: "{HubModel>Title}",
                        design: sap.ui.commons.LabelDesign.Bold
                    }).addStyleClass('item-title'),
                    new sap.ui.layout.HorizontalLayout({
                        content: [
                            new sap.ui.commons.Label({
                                text: "Status"
                            }).addStyleClass('item-label'),
                            new sap.ui.commons.Label({
                                text: ':'
                            }),
                            new sap.ui.commons.TextView({
                                text: "{HubModel>Status}"
                            })
                        ]
                    }),
                    new sap.ui.layout.HorizontalLayout({
                        content: [
                            new sap.ui.commons.Label({
                                text: "Last Updated"
                            }),
                            new sap.ui.commons.Label({
                                text: ':'
                            }),
                            new sap.ui.commons.TextView({
                                text: "{HubModel>Date}"
                            })
                        ]
                    })
                ]
            })
        }
    }).addStyleClass('flagged-item-layout');

    var link = new sap.ui.commons.Link({
        text: 'Show All'
    }).addStyleClass('bottom-link');

    var content = [].concat(createHeader('Flagged Items', null));
    content.push(oSimpleForm);
    content.push(link);

    return content;
}