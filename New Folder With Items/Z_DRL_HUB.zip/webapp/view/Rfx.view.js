sap.ui.jsview("drlhub.view.Rfx", {

	/** Specifies the Controller belonging to this View.
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf drlhub.rfx
	*/
	getControllerName : function() {
		return "drlhub.view.Rfx";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed.
	* Since the Controller is given to this method, its event handlers can be attached right away.
	* @memberOf drlhub.rfx
	*/
    createContent: function(oController)
    {
        var row = sap.ui.commons.layout.MatrixLayoutRow;
        var cell = sap.ui.commons.layout.MatrixLayoutCell;

        return new sap.ui.commons.layout.MatrixLayout({
        	rows : [
	                    new row(this.createId('firstRow'),
	                    {
	                        cells: [
	                                	new cell({
	                                			content: createDropDown(oController)
	                                	}).addStyleClass('sts-details'),
	                               ]
	                    }),
	                    getSeparator(this, 'first', 1),
	                    new row(this.createId('secondRow'), {
	                    	height: '100px',
	                        cells: [
	                            new cell({
	                                content: createButtons(oController)
	                            })
	                        ]
	                    }),
	                    getSeparator(this, 'second', 1),
	                    new row(this.createId('ThridRow'), {
	                        cells: [
	                            new cell({
	                                content: createDataTable()
	                            })
	                        ]
	                    }),
        	        ]
        });
    }

});
		
function getSeparator(_this, id, span)
{
    return new sap.ui.commons.layout.MatrixLayoutRow(_this.createId(id + 'Sep'),
    {
        height: '20px',
        cells: getBlankCell(span)
    });
}

function getBlankCell(span)
{
    return new sap.ui.commons.layout.MatrixLayoutCell(
    {
        colSpan: span
    });
}

function createDropDown (oController)
{
	var rfxDropDownBox = new sap.ui.commons.DropdownBox("rfxDropDownBox", {
		
		items: [
		        new sap.ui.core.ListItem("M01",{text: "Last 1 Month", key: "M01"}),
		        new sap.ui.core.ListItem("M03",{text: "Last 3 Month", key: "M03"}),
		        new sap.ui.core.ListItem("M06",{text: "Last 6 Month", key: "M06"}),
		        new sap.ui.core.ListItem("M12",{text: "Past 1 Year", key: "M12"})
		],
		
        change:function(oEvent)
        {
        	oController.drlRfxDropDownBox('RFX', oEvent.oSource.getSelectedKey());
        },

	}).addStyleClass('hub-dropdown');

	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	rfxDropDownBox
	               ]
	  }).addStyleClass('viewMainLayout');;
}

function createButtons(oController)
{
    var rcdBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('rcdbtn',{
            width: '95%',
            content: [
                new sap.ui.commons.TextView(Widgets.rfx.totalReceived.id,{
                }).addStyleClass('rrval'),

                new sap.ui.commons.TextView(Widgets.rfx.totalReceived.nameID, {
                }).addStyleClass('rrtxt')
 			]
        })
      /*  press: function() {
            console.log('pressed');
        }*/
    });

    var ntrcdBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('ryrbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.rfx.yetToRespond.id, {
                }).addStyleClass('ryval'),

                new sap.ui.commons.TextView(Widgets.rfx.yetToRespond.nameID, {
                }).addStyleClass('rytxt')
               ]
        })
    });

    var sbtBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('rsbt',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.rfx.submitted.id, {
                }).addStyleClass('rsval'),

                new sap.ui.commons.TextView(Widgets.rfx.submitted.nameID, {
                }).addStyleClass('rstxt')
                ]
        })
    });

    rcdBtn.attachPress(oController.recd);
    ntrcdBtn.attachPress(oController.ntrecd);
    sbtBtn.attachPress(oController.subm);

  return new sap.ui.layout.HorizontalLayout({
      content: [
                	rcdBtn,
                	ntrcdBtn,
                	sbtBtn
               ]
  }).addStyleClass('viewMainLayout');
}

function createDataTable ()
{
	var oRFXTable = new sap.m.Table("testTbl", {
	  growing: true,
	  growingThreshold: 10,
	});

	oRFXTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "RFx Number", design : sap.m.LabelDesign.Bold}),
		}
	));

	oRFXTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Contact Person", design : sap.m.LabelDesign.Bold}),
		}
	));

	oRFXTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Submission Date", design : sap.m.LabelDesign.Bold}),
		}
	));

	oRFXTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Event Status", design : sap.m.LabelDesign.Bold}),
		}
	));

	var oTemplate = new sap.m.ColumnListItem(
	{
			type: sap.m.ListType.Active,
			cells : [
			         	new sap.m.Label({
//			         		text : '{HubRFXTableModel>RfxObjectId}'
			         		text : '{HubTEMPRFXTableModel>rfxNumber}'
			         	}),
		
			         	new sap.m.Label({
//			         		text: '{HubRFXTableModel>BuyerName}'
			         		text: '{HubTEMPRFXTableModel>contactPerson}'
			         	}),
		
			         	new sap.m.Label({
//			         		text : '{HubRFXTableModel>QuotDead}'
			         		text : '{HubTEMPRFXTableModel>submissionDate}'
			         	}),
		
			         	new sap.m.Label({
//			         		text: '{HubRFXTableModel>RfxStatTxt}'
			         		text: '{HubTEMPRFXTableModel>eventStatus}'
			         	})
			]
	});

//	oRFXTable.setModel(sap.ui.getCore().getModel('HubRFXTableModel'));
//	oRFXTable.bindItems("HubRFXTableModel>/results",oTemplate);

	oRFXTable.setModel(sap.ui.getCore().getModel('HubTEMPRFXTableModel'));
	oRFXTable.bindItems("HubTEMPRFXTableModel>/rfxResults/", oTemplate);

	oRFXTable.setWidth('860px');
	
	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	oRFXTable
	               ]
	  }).addStyleClass('viewMainLayout');
}