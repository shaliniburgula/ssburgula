sap.ui.jsview("drlhub.view.asn", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf drlhub.asn
	*/ 
	getControllerName : function() {
		return "drlhub.view.asn";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf drlhub.asn
	*/ 

    createContent: function(oController) 
    {
        var row = sap.ui.commons.layout.MatrixLayoutRow;
        var cell = sap.ui.commons.layout.MatrixLayoutCell;
    
        return new sap.ui.commons.layout.MatrixLayout({
        	rows : [
	                    new row(this.createId('firstRow'), 
	                    {
	                        cells: [
	                                	new cell({
	                                			content: createDropDown(oController)
	                                	}).addStyleClass('sts-details'),
	                               ]
	                    }),
	                    getSeparator(this, 'first', 1),
	                    new row(this.createId('secondRow'), {
	                    	height: '100px',
	                        cells: [
	                            new cell({
	                                content: createButtons(oController)
	                            })
	                        ]
	                    }),
	                    getSeparator(this, 'second', 1),
	                    new row(this.createId('ThridRow'), {
	                        cells: [
	                            new cell({
	                                content: createDataTable()
	                            })
	                        ]
	                    }),
        	        ]
        });
    }
});

function getSeparator(_this, id, span) 
{
    return new sap.ui.commons.layout.MatrixLayoutRow(_this.createId(id + 'Sep'), 
    {
        height: '20px',
        cells: getBlankCell(span)
    });
}

function getBlankCell(span) 
{
    return new sap.ui.commons.layout.MatrixLayoutCell(
    {
        colSpan: span
    });
}

function createDropDown (oController)
{
	var asnDropDownBox = new sap.ui.commons.DropdownBox("asnDropDownBox", {
		
		items: [
		        new sap.ui.core.ListItem("M11",{text: "Last 1 Month", key: "M01"}),
		        new sap.ui.core.ListItem("M13",{text: "Last 3 Month", key: "M03"}),
		        new sap.ui.core.ListItem("M16",{text: "Last 6 Month", key: "M06"}),
		        new sap.ui.core.ListItem("M112",{text: "Past 1 Year", key: "M12"})
		],
		
        change:function(oEvent)
        {
        	oController.drlasnDropDownBox('ASN', oEvent.oSource.getSelectedKey());
        },

	}).addStyleClass('hub-dropdown');

	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	asnDropDownBox
	               ]
	  }).addStyleClass('viewMainLayout');
}

function createButtons(oController)
{
    var psBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('apsbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.asn.pendingShipment.id, {
                }).addStyleClass('apval'),

                new sap.ui.commons.TextView(Widgets.asn.pendingShipment.nameID, {
                }).addStyleClass('aptxt')
                ]
        })
      /*  press: function() {
            console.log('pressed');
        }*/
    });
    
    var itBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('ait',{
            width: '95%',
           // height:'100%',
            content: [
                new sap.ui.commons.TextView(Widgets.asn.intransit.id, {
                }).addStyleClass('aival'),

                new sap.ui.commons.TextView(Widgets.asn.intransit.nameID, {
                }).addStyleClass('aitxt')
                ]
        })
    });

    var geBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('aged',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.asn.gateEntryDone.id, {
                }).addStyleClass('agval'),
                
                new sap.ui.commons.TextView(Widgets.asn.gateEntryDone.nameID, {
                }).addStyleClass('agtxt')
                ]
        })
    });

    var prgBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('prgBtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.asn.pedningForGRN.id, {
                }).addStyleClass('prgval'),
                
                new sap.ui.commons.TextView(Widgets.asn.pedningForGRN.nameID, {
                }).addStyleClass('prgtxt')
                ]
        })
    });

    psBtn.attachPress(oController.psmnt);
    itBtn.attachPress(oController.itst);
    geBtn.attachPress(oController.agtent);
    prgBtn.attachPress(oController.pendingForGrn);
    
  return new sap.ui.layout.HorizontalLayout({
      content: [
                	psBtn,
                	itBtn,
                	geBtn,
                	prgBtn
               ]
  }).addStyleClass('viewMainLayout');
}

function createDataTable ()
{
	var oASNTable = new sap.m.Table("asnTbl", {
	  growing: true,
	  growingThreshold: 10,
	  visible : false
	});
  
	oASNTable.addColumn(new sap.m.Column(
		{  
			header: new sap.m.Label({text: "ASN Number", design : sap.m.LabelDesign.Bold}),     
		}
	));

	oASNTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "PO Number", design : sap.m.LabelDesign.Bold}),
		}
	));

	oASNTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Open Since", design : sap.m.LabelDesign.Bold}),
		}
	));

	oASNTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Status", design : sap.m.LabelDesign.Bold}),
		}
	));

	var oTemplate = new sap.m.ColumnListItem(
	{
			type: sap.m.ListType.Active,
			cells : [
			         	new sap.m.Label({
//			         		text : '{HubASNTableModel>AsnObjectId}'
			         		text : '{HubTEMPASNTableModel>AsnObjectId}'
			         	}),
		
			         	new sap.m.Label({
//			         		text: '{HubASNTableModel>PoObjectId}'
			         		text : '{HubTEMPASNTableModel>PoObjectId}'
			         	}),
		
			         	new sap.m.Label({
//			         		text : '{HubASNTableModel>AsnDate}'
			         		text : '{HubTEMPASNTableModel>AsnDate}'
			         	}),
		
			         	new sap.m.Label({
//			         		text: '{HubASNTableModel>AsnStatTxt}'
			         		text : '{HubTEMPASNTableModel>AsnStatTxt}'
			         	})
			]
	});

//	oASNTable.setModel(sap.ui.getCore().getModel('HubASNTableModel'));
//	oASNTable.bindItems("HubASNTableModel>/results",oTemplate);

	oASNTable.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
	oASNTable.bindItems("HubTEMPASNTableModel>/asnResults/",oTemplate);

	oASNTable.setWidth('860px');

	
	var oASNTable_1 = new sap.m.Table("asnTbl_1", {
		  growing: true,
		  growingThreshold: 10,
		  visible : true
		});
	  
		oASNTable_1.addColumn(new sap.m.Column(
			{
				header: new sap.m.Label({text: "PO Number", design : sap.m.LabelDesign.Bold}),
			}
		));

		oASNTable_1.addColumn(new sap.m.Column(
			{
				header: new sap.m.Label({text: "Open Since", design : sap.m.LabelDesign.Bold}),
			}
		));

		oASNTable_1.addColumn(new sap.m.Column(
			{
				header: new sap.m.Label({text: "Status", design : sap.m.LabelDesign.Bold}),
			}
		));

		var oTemplate_1 = new sap.m.ColumnListItem(
		{
				type: sap.m.ListType.Active,
				cells : [
				         	new sap.m.Label({
//				         		text: '{HubASNTableModel>PoObjectId}'
				         		text: '{HubTEMPASNTableModel>PoObjectId}'
				         	}),
			
				         	new sap.m.Label({
//				         		text : '{HubASNTableModel>AsnDate}'
				         		text : '{HubTEMPASNTableModel>AsnDate}'
				         	}),
			
				         	new sap.m.Label({
//				         		text: '{HubASNTableModel>AsnStatTxt}'
				         		text: '{HubTEMPASNTableModel>AsnStatTxt}'
				         	})
				]
		});

//		oASNTable_1.setModel(sap.ui.getCore().getModel('HubASNTableModel'));
//		oASNTable_1.bindItems("HubASNTableModel>/results",oTemplate);

		oASNTable_1.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
		oASNTable_1.bindItems("HubTEMPASNTableModel>/asnResults/",oTemplate_1);

		oASNTable_1.setWidth('860px');

	
	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	oASNTable,
	                	oASNTable_1
	               ]
	  }).addStyleClass('viewMainLayout');
}
