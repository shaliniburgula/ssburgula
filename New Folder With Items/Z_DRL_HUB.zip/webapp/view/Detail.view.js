sap.ui.jsview("drlhub.view.Detail", {
    getControllerName: function() {
        return "drlhub.view.Detail";
    },
    createContent: function(oController) {
        return new sap.m.Page(this.createId('workLocationPage'), {
            showHeader: false,
            content: [
                new sap.ui.ux3.NavigationBar(this.createId('topNavBar'), {
                    items: [
                        new sap.ui.ux3.NavigationItem({
                            key: "Hub",
                            text: "Overview"
                        }),
                        new sap.ui.ux3.NavigationItem({
                            key: "Rfx",
                            text: "RFx"
                        }),
                        new sap.ui.ux3.NavigationItem({
                            key: "PO",
                            text: "PO"
                        }),
                        new sap.ui.ux3.NavigationItem({
                            key: "asn",
                            text: "ASN"
                        }),
                        new sap.ui.ux3.NavigationItem({
                            key: "grn",
                            text: "GRN"
                        }),
                        new sap.ui.ux3.NavigationItem({
                            key: "invoice",
                            text: "Invoice"
                        }),
                        new sap.ui.ux3.NavigationItem({
                            key: "alerts",
                            text: "Alerts (0)"
                        })

//                        new sap.ui.ux3.NavigationItem({
//                            key: "alerts",
//                            text: {
//                                path: "HubModel>/OverviewData/results/Alerts",
//                                formatter: function(value) {
//                                    return "Alerts (" + value + ")";
//                                }
//                            }
//                        })
                    ],
                    select: [oController.onItemSelect, oController]
                }).addStyleClass('detail-header'),
                new sap.ui.layout.VerticalLayout(this.createId('mainContent'))
            ]
        }).addStyleClass('white-background');
    }
});