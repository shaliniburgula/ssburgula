sap.ui.jsview("drlhub.view.App", {
    getControllerName: function() {
        return "drlhub.view.App";
    },
    createContent: function(oController) {
        this.setDisplayBlock(true);

        this.app = new sap.m.SplitApp('theApp');
        this.app.addMasterPage(sap.ui.jsview("Master", "drlhub.view.Master"));
        this.app.addDetailPage(sap.ui.jsview("Detail", "drlhub.view.Detail"));

        this.app.setMode(sap.m.SplitAppMode.HideMode);

        return this.app;
    }
});