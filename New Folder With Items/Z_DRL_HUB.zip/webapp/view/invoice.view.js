sap.ui.jsview("drlhub.view.invoice", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf drlhub.invoice
	*/ 
	getControllerName : function() {
		return "drlhub.view.invoice";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf drlhub.invoice
	*/ 
	    createContent: function(oController) 
	    {
	        var row = sap.ui.commons.layout.MatrixLayoutRow;
	        var cell = sap.ui.commons.layout.MatrixLayoutCell;
	    
	        return new sap.ui.commons.layout.MatrixLayout({
	        	rows : [
		                    new row(this.createId('firstRow'), 
		                    {
		                        cells: [
		                                	new cell({
		                                			content: createDropDown(oController)
		                                	}).addStyleClass('sts-details'),
		                               ]
		                    }),
		                    getSeparator(this, 'second', 1),
		                    new row(this.createId('secondRow'), {
		                    	height: '100px',
		                        cells: [
		                            new cell({
		                                content: createButtons(oController)
		                            })
		                        ]
		                    }),
		                    getSeparator(this, 'thrid', 1),
		                    new row(this.createId('thridRow'), {
		                    	height: '100px',
		                        cells: [
		                            new cell({
		                                content: createButtons_1(oController)
		                            })
		                        ]
		                    }),
		                    getSeparator(this, 'fourth', 1),
		                    new row(this.createId('fourthRow'), {
		                        cells: [
		                            new cell({
		                                content: createDataTable()
		                            })
		                        ]
		                    }),
	        	        ]
	        });
	    }
		
		
});

function getSeparator(_this, id, span) 
{
    return new sap.ui.commons.layout.MatrixLayoutRow(_this.createId(id + 'Sep'), 
    {
        height: '20px',
        cells: getBlankCell(span)
    });
}

function getBlankCell(span) 
{
    return new sap.ui.commons.layout.MatrixLayoutCell(
    {
        colSpan: span
    });
}

function createDropDown (oController)
{
	var invoiceDropDownBox = new sap.ui.commons.DropdownBox("invoiceDropDownBox", {
		
		items: [
		        new sap.ui.core.ListItem("M111",{text: "Last 1 Month", key: "M01"}),
		        new sap.ui.core.ListItem("M211",{text: "Last 3 Month", key: "M03"}),
		        new sap.ui.core.ListItem("M311",{text: "Last 6 Month", key: "M06"}),
		        new sap.ui.core.ListItem("M411",{text: "Past 1 Year", key: "M12"})
		],
		
        change:function(oEvent)
        {
        	oController.drlInvoiceDropDownBox('INV', oEvent.oSource.getSelectedKey());
        },

	}).addStyleClass('hub-dropdown');

	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	invoiceDropDownBox
	               ]
	  }).addStyleClass('viewMainLayout');

}

function createButtons(oController)
{
    var iyBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('iybtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoiceYetToUpload.id, {
                }).addStyleClass('iyval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoiceYetToUpload.nameID, {
                }).addStyleClass('iytxt')
                ]
        }),
      press: [oController.yetup, oController]
    });
    
    var ipBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('ipbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoicePendingForHardCopy.id, {
                }).addStyleClass('ipval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoicePendingForHardCopy.nameID, {
                }).addStyleClass('iptxt')

                ]
        })
    });
    
    var iiBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('iibtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoiceInProcess.id, {
                }).addStyleClass('iival'),

                new sap.ui.commons.TextView(Widgets.invoice.invoiceInProcess.nameID, {
                }).addStyleClass('iitxt')

                ]
        })
    });
    var iubtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('iubtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoiceUnderDeviation.id, {
                }).addStyleClass('iuval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoiceUnderDeviation.nameID, {
                }).addStyleClass('iutxt')

                ]
        })
    });
    ipBtn.attachPress(oController.pend);
    iiBtn.attachPress(oController.inproc);
    iyBtn.attachPress(oController.yetup);
    iubtn.attachPress(oController.underd);
  
  return new sap.ui.layout.HorizontalLayout({
      content: [
                iyBtn,
                ipBtn,
                iiBtn,
                iubtn,
               ]
  }).addStyleClass('viewMainLayout');
}

function createButtons_1(oController)
{
    var ibBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('ibbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoiceHoldForPayment.id, {
                }).addStyleClass('ibval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoiceHoldForPayment.nameID, {
                }).addStyleClass('ibtxt')

                ]
        })
    });
    
    var icbtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('icbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoiceClearForPayment.id, {
                }).addStyleClass('icval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoiceClearForPayment.nameID, {
                }).addStyleClass('ictxt')
                ]
        })
    });
    var ipcbtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('ipcbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoicePaymentCredited.id, {
                }).addStyleClass('irval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoicePaymentCredited.nameID, {
                }).addStyleClass('irtxt')
                ]
        })
    });

    var irbtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('irbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.invoice.invoiceRejected.id, {
                }).addStyleClass('irval'),

                new sap.ui.commons.TextView(Widgets.invoice.invoiceRejected.nameID, {
                }).addStyleClass('irtxt')

                ]
        })
    });

    ibBtn.attachPress(oController.underb);
    icbtn.attachPress(oController.clerpay);
    ipcbtn.attachPress(oController.paymentCredited);
    irbtn.attachPress(oController.rejected);
  
  return new sap.ui.layout.HorizontalLayout({
      content: [
                ibBtn,
                icbtn,
                ipcbtn,
                irbtn
               ]
  }).addStyleClass('viewMainLayout');
}

function createDataTable ()
{
	var oInvoiceTable = new sap.m.Table("invoiceTable_yetToUpload", {
	  growing: true,
	  growingThreshold: 10,
	  visible : true
	});
  
	oInvoiceTable.addColumn(new sap.m.Column(
		{  
			header: new sap.m.Label({text: "PO Number", design : sap.m.LabelDesign.Bold}),     
		}
	));

	oInvoiceTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Open Since", design : sap.m.LabelDesign.Bold}),
		}
	));

	oInvoiceTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Buyer Name", design : sap.m.LabelDesign.Bold}),
		}
	));

	oInvoiceTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Action", design : sap.m.LabelDesign.Bold}),
		}
	));

	var oTemplate = new sap.m.ColumnListItem(
	{
			type: sap.m.ListType.Active,
			cells : [
			         	new sap.m.Label({
			         		text : '{HubTEMPASNTableModel>PoObjectId}'
			         	}),
		
			         	new sap.m.Label({
			         		text: '{HubTEMPASNTableModel>AsnDate}'
			         	}),
		
			         	new sap.m.Label({
			         		text : '' //'{HubInvoiceTableModel_1>PoObjectId}'
			         	}),
		
			         	new sap.m.Label({
			         		text: 'Upload Invoice' //'{HubInvoiceTableModel_1>PoObjectId}'
			         	})
			]
	});

//	oInvoiceTable.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel_1'));
//	oInvoiceTable.bindItems("HubInvoiceTableModel_1>/results",oTemplate);

	oInvoiceTable.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
	oInvoiceTable.bindItems("HubTEMPASNTableModel>/invoiceResults/",oTemplate);

	
	oInvoiceTable.setWidth('860px');

	var oInvoiceTable_1 = new sap.m.Table("invoiceTable_pendingForHardCopy", {
		  growing: true,
		  growingThreshold: 10,
		  visible : false
		});
	  
		oInvoiceTable_1.addColumn(new sap.m.Column(
			{  
				header: new sap.m.Label({text: "Invoice Number", design : sap.m.LabelDesign.Bold}),     
			}
		));

		oInvoiceTable_1.addColumn(new sap.m.Column(
			{
				header: new sap.m.Label({text: "Processing Started On", design : sap.m.LabelDesign.Bold}),
			}
		));

		oInvoiceTable_1.addColumn(new sap.m.Column(
			{
				header: new sap.m.Label({text: "Payment Due Date", design : sap.m.LabelDesign.Bold}),
			}
		));

		var oTemplate_1 = new sap.m.ColumnListItem(
		{
				type: sap.m.ListType.Active,
				cells : [
				         	new sap.m.Label({
				         		text : '{HubTEMPASNTableModel>InvNum}'
				         	}),
			
				         	new sap.m.Label({
				         		text: '{HubTEMPASNTableModel>StatusDate}'
				         	}),
			
				         	new sap.m.Label({
				         		text : '{HubTEMPASNTableModel>PayDueDate}'
				         	})
				]
		});

//		oInvoiceTable_1.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
//		oInvoiceTable_1.bindItems("HubInvoiceTableModel>/results",oTemplate_1);

		oInvoiceTable_1.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
		oInvoiceTable_1.bindItems("HubTEMPASNTableModel>/invoiceResults",oTemplate_1);

		
		oInvoiceTable_1.setWidth('860px');

		var oInvoiceTable_2 = new sap.m.Table("invoiceTable_inProcessTable", {
			  growing: true,
			  growingThreshold: 10,
			  visible : false
			});
		  
			oInvoiceTable_2.addColumn(new sap.m.Column(
				{  
					header: new sap.m.Label({text: "Invoice Number", design : sap.m.LabelDesign.Bold}),     
				}
			));

			oInvoiceTable_2.addColumn(new sap.m.Column(
				{
					header: new sap.m.Label({text: "Buyer Name", design : sap.m.LabelDesign.Bold}),
				}
			));

			oInvoiceTable_2.addColumn(new sap.m.Column(
				{
					header: new sap.m.Label({text: "Amount Raised (INR)", design : sap.m.LabelDesign.Bold}),
				}
			));

			oInvoiceTable_2.addColumn(new sap.m.Column(
				{
						header: new sap.m.Label({text: "Payment Date", design : sap.m.LabelDesign.Bold}),
				}
			));

			oInvoiceTable_2.addColumn(new sap.m.Column(
				{
						header: new sap.m.Label({text: "Sub State", design : sap.m.LabelDesign.Bold}),
				}
			));

			var oTemplate_2 = new sap.m.ColumnListItem(
			{
					type: sap.m.ListType.Active,
					cells : [
					         	new sap.m.Label({
					         		text : '{HubTEMPASNTableModel>InvNum}'
					         	}),
				
					         	new sap.m.Label({
					         		text: '{HubTEMPASNTableModel>PersonName}'
					         	}),
				
					         	new sap.m.Label({
					         		text : '{HubTEMPASNTableModel>InvAmt}'
					         	}),
					         	
					         	new sap.m.Label({
					         		text: '{HubTEMPASNTableModel>PayDueDate}'
					         	}),
				
					         	new sap.m.Label({
					         		text : '{HubTEMPASNTableModel>StatusDescription}'
					         	})

					]
			});

//			oInvoiceTable_2.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
//			oInvoiceTable_2.bindItems("HubInvoiceTableModel>/results",oTemplate_2);

			oInvoiceTable_2.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
			oInvoiceTable_2.bindItems("HubTEMPASNTableModel>/invoiceResults",oTemplate_2);

			oInvoiceTable_2.setWidth('860px');

			var oInvoiceTable_3 = new sap.m.Table("invoiceTable_underDeviationTable", {
				  growing: true,
				  growingThreshold: 10,
				  visible : false
				});
			  
				oInvoiceTable_3.addColumn(new sap.m.Column(
					{  
						header: new sap.m.Label({text: "Invoice Number", design : sap.m.LabelDesign.Bold}),     
					}
				));

				oInvoiceTable_3.addColumn(new sap.m.Column(
					{
						header: new sap.m.Label({text: "Deviation", design : sap.m.LabelDesign.Bold}),
					}
				));

				oInvoiceTable_3.addColumn(new sap.m.Column(
					{
						header: new sap.m.Label({text: "Payment Due Date", design : sap.m.LabelDesign.Bold}),
					}
				));

				var oTemplate_3 = new sap.m.ColumnListItem(
				{
						type: sap.m.ListType.Active,
						cells : [
						         	new sap.m.Label({
						         		text : '{HubTEMPASNTableModel>InvNum}'
						         	}),
					
						         	new sap.m.Label({
						         		text: '{HubTEMPASNTableModel>DeviationName}'
						         	}),
					
						         	new sap.m.Label({
						         		text : '{HubTEMPASNTableModel>PayDueDate}'
						         	})
						]
				});

//				oInvoiceTable_3.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
//				oInvoiceTable_3.bindItems("HubInvoiceTableModel>/results",oTemplate_3);

				oInvoiceTable_3.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
				oInvoiceTable_3.bindItems("HubTEMPASNTableModel>/invoiceResults",oTemplate_3);

				oInvoiceTable_3.setWidth('860px');

				var oInvoiceTable_4 = new sap.m.Table("invoiceTable_clearForPaymentTable", {
					  growing: true,
					  growingThreshold: 10,
					  visible : false
					});
				  
					oInvoiceTable_4.addColumn(new sap.m.Column(
						{  
							header: new sap.m.Label({text: "Invoice Number", design : sap.m.LabelDesign.Bold}),     
						}
					));

					oInvoiceTable_4.addColumn(new sap.m.Column(
						{
							header: new sap.m.Label({text: "Payment Due Date", design : sap.m.LabelDesign.Bold}),
						}
					));

					oInvoiceTable_4.addColumn(new sap.m.Column(
						{
							header: new sap.m.Label({text: "Amount Raised (INR)", design : sap.m.LabelDesign.Bold}),
						}
					));

					oInvoiceTable_4.addColumn(new sap.m.Column(
						{
							header: new sap.m.Label({text: "Amount Approved (INR)", design : sap.m.LabelDesign.Bold}),
						}
					));

					var oTemplate_4 = new sap.m.ColumnListItem(
					{
							type: sap.m.ListType.Active,
							cells : [
							         	new sap.m.Label({
							         		text : '{HubTEMPASNTableModel>InvNum}'
							         	}),
						
							         	new sap.m.Label({
							         		text: '{HubTEMPASNTableModel>PayDueDate}'
							         	}),
						
							         	new sap.m.Label({
							         		text : '{HubTEMPASNTableModel>InvAmt}'
							         	}),
										
										new sap.m.Label({
							         		text : '{HubTEMPASNTableModel>InvApprAmt}'
							         	})

							]
					});

//					oInvoiceTable_4.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
//					oInvoiceTable_4.bindItems("HubInvoiceTableModel>/results",oTemplate_4);

					oInvoiceTable_4.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
					oInvoiceTable_4.bindItems("HubTEMPASNTableModel>/invoiceResults",oTemplate_4);

					oInvoiceTable_4.setWidth('860px');
			
					var oInvoiceTable_5 = new sap.m.Table("invoiceTable_paymentCreditedTable", {
						  growing: true,
						  growingThreshold: 10,
						  visible : false
						});
					  
						oInvoiceTable_5.addColumn(new sap.m.Column(
							{  
								header: new sap.m.Label({text: "Invoice Number", design : sap.m.LabelDesign.Bold}),     
							}
						));

						oInvoiceTable_5.addColumn(new sap.m.Column(
							{
								header: new sap.m.Label({text: "Payment Credited Date", design : sap.m.LabelDesign.Bold}),
							}
						));

						oInvoiceTable_5.addColumn(new sap.m.Column(
							{
								header: new sap.m.Label({text: "Amount Credited (INR)", design : sap.m.LabelDesign.Bold}),
							}
						));

						oInvoiceTable_5.addColumn(new sap.m.Column(
							{
								header: new sap.m.Label({text: "Amount Approved (INR)", design : sap.m.LabelDesign.Bold}),
							}
						));

						var oTemplate_5 = new sap.m.ColumnListItem(
						{
								type: sap.m.ListType.Active,
								cells : [
								         	new sap.m.Label({
								         		text : '{HubTEMPASNTableModel>InvNum}'
								         	}),
							
								         	new sap.m.Label({
								         		text: '{HubTEMPASNTableModel>StatusDate}'
								         	}),
							
								         	new sap.m.Label({
								         		text : '{HubTEMPASNTableModel>InvApprAmt}'
								         	}),
											
											new sap.m.Label({
								         		text : '{HubTEMPASNTableModel>InvApprAmt}'
								         	})

								]
						});

//						oInvoiceTable_5.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
//						oInvoiceTable_5.bindItems("HubInvoiceTableModel>/results",oTemplate_5);

						oInvoiceTable_5.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
						oInvoiceTable_5.bindItems("HubInvoiceTableModel>/invoiceResults",oTemplate_5);

						oInvoiceTable_5.setWidth('860px');

						var oInvoiceTable_6 = new sap.m.Table("invoiceTable_rejectedTable", {
							  growing: true,
							  growingThreshold: 10,
							  visible : false
							});
						  
							oInvoiceTable_6.addColumn(new sap.m.Column(
								{  
									header: new sap.m.Label({text: "Invoice Number", design : sap.m.LabelDesign.Bold}),     
								}
							));

							oInvoiceTable_6.addColumn(new sap.m.Column(
								{
									header: new sap.m.Label({text: "Amount Raised (INR)", design : sap.m.LabelDesign.Bold}),
								}
							));

							oInvoiceTable_6.addColumn(new sap.m.Column(
								{
									header: new sap.m.Label({text: "Reason for Rejection", design : sap.m.LabelDesign.Bold}),
								}
							));

							var oTemplate_6 = new sap.m.ColumnListItem(
							{
									type: sap.m.ListType.Active,
									cells : [
									         	new sap.m.Label({
									         		text : '{HubTEMPASNTableModel>InvNum}'
									         	}),
								
									         	new sap.m.Label({
									         		text: 'HubTEMPASNTableModel>InvAmt'
									         	}),
								
									         	new sap.m.Label({
									         		text : '{HubTEMPASNTableModel>StatusDescription}'
									         	}),
								]
							});

//							oInvoiceTable_6.setModel(sap.ui.getCore().getModel('HubInvoiceTableModel'));
//							oInvoiceTable_6.bindItems("HubInvoiceTableModel>/results",oTemplate_6);

							oInvoiceTable_6.setModel(sap.ui.getCore().getModel('HubTEMPASNTableModel'));
							oInvoiceTable_6.bindItems("HubTEMPASNTableModel>/invoiceResults",oTemplate_6);

							oInvoiceTable_6.setWidth('860px');

						
	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	oInvoiceTable,
	                	oInvoiceTable_1,
	                	oInvoiceTable_2,
	                	oInvoiceTable_3,
	                	oInvoiceTable_4,
	                	oInvoiceTable_5,
	                	oInvoiceTable_6
	               ]
	  }).addStyleClass('viewMainLayout');
}
