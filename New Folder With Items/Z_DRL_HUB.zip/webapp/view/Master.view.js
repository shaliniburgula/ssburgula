sap.ui.jsview("Z_DRL_HUB.view.Master", {
    getControllerName: function() {
        return "Z_DRL_HUB.view.Master";
    },
    createContent: function(oController) {
        var oPage = new sap.m.Page(this.createId("mPage"), {
            content: new sap.m.List(this.createId("mList"), {
                growing: true,
                growingThreshold: 7,
                select: [oController.handleListSelect, oController],
                mode: sap.m.ListMode.SingleSelectMaster,
                items: {
                    path: "MasterModel>/LeftPanelData/results",
                    template: new sap.m.ObjectListItem(this.createId('list'), {
                        press: [oController.handleListItemPress, oController],
                        type: sap.m.ListType.Active,
                        firstStatus: new sap.m.ObjectStatus({
                            text: "{MasterModel>number}"
                        }),
                        attributes: new sap.m.ObjectAttribute({
                            text: "{MasterModel>text}"
                        })
                    }).addStyleClass("list-item")
                },
                headerToolbar: new sap.m.Toolbar()
            }).addStyleClass('cust-master-list')
        }).addStyleClass('master-left-link');

        return oPage;
    }
});