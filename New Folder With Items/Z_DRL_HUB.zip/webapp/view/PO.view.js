sap.ui.jsview("drlhub.view.PO", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf drlhub.po
	*/ 
	getControllerName : function() {
		return "drlhub.view.PO";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf drlhub.po
	*/ 
    createContent: function(oController) 
    {
        var row = sap.ui.commons.layout.MatrixLayoutRow;
        var cell = sap.ui.commons.layout.MatrixLayoutCell;
    
        return new sap.ui.commons.layout.MatrixLayout({
        	rows : [
	                    new row(this.createId('firstRow'), 
	                    {
	                        cells: [
	                                	new cell({
	                                			content: createDropDown(oController)
	                                	}).addStyleClass('sts-details'),
	                               ]
	                    }),
	                    getSeparator(this, 'first', 1),
	                    new row(this.createId('secondRow'), {
	                    	height: '100px',
	                        cells: [
	                            new cell({
	                                content: createButtons(oController)
	                            })
	                        ]
	                    }),
	                    getSeparator(this, 'second', 1),
	                    new row(this.createId('ThridRow'), {
	                        cells: [
	                            new cell({
	                                content: createDataTable()
	                            })
	                        ]
	                    }),
        	        ]
        });
    }
});

function getSeparator(_this, id, span) 
{
    return new sap.ui.commons.layout.MatrixLayoutRow(_this.createId(id + 'Sep'), 
    {
        height: '20px',
        cells: getBlankCell(span)
    });
}

function getBlankCell(span) 
{
    return new sap.ui.commons.layout.MatrixLayoutCell(
    {
        colSpan: span
    });
}

function createDropDown (oController)
{
	var poDropDownBox = new sap.ui.commons.DropdownBox("poDropDownBox", {
		
		items: [
		        new sap.ui.core.ListItem("M1",{text: "Last 1 Month", key: "M01"}),
		        new sap.ui.core.ListItem("M2",{text: "Last 3 Month", key: "M03"}),
		        new sap.ui.core.ListItem("M3",{text: "Last 6 Month", key: "M06"}),
		        new sap.ui.core.ListItem("M4",{text: "Past 1 Year", key: "M12"})
		],
		
        change:function(oEvent)
        {
        	oController.drlPODropDownBox('PO', oEvent.oSource.getSelectedKey());
        },

	}).addStyleClass('hub-dropdown');

	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	poDropDownBox
	               ]
	  }).addStyleClass('viewMainLayout');
}

function createButtons(oController)
{
    var rcdBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('pybtn',{
            content: [
                new sap.ui.commons.TextView(Widgets.po.newStatus.id, {
                }).addStyleClass('pyval'),
                
                new sap.ui.commons.TextView(Widgets.po.newStatus.nameID, {
                }).addStyleClass('pytxt')
            ]
        }),
        press: function() {
            console.log('pressed');
        }
    });
    
    var ntrcdBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('pabtn', {
            content: [
                new sap.ui.commons.TextView(Widgets.po.acknowledged.id, {
                }).addStyleClass('paval'),
                
                new sap.ui.commons.TextView(Widgets.po.acknowledged.nameID, {
                }).addStyleClass('patxt')
            ]
        })
    });

  rcdBtn.attachPress(oController.yta);
  ntrcdBtn.attachPress(oController.ack);
  
  return new sap.ui.layout.HorizontalLayout({
      content: [
                	rcdBtn,
                	ntrcdBtn
               ]
  }).addStyleClass('viewMainLayout');
}

function createDataTable ()
{
	var oPOTable = new sap.m.Table("ptestTbl", {
	  growing: true,
	  growingThreshold: 10,
	});

	oPOTable.addColumn(new sap.m.Column(
		{  
			header: new sap.m.Label({text: "PO Number", design : sap.m.LabelDesign.Bold}),     
		}
	));

	oPOTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "RFx Number", design : sap.m.LabelDesign.Bold}),
		}
	));

	oPOTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Value", design : sap.m.LabelDesign.Bold}),
		}
	));

	oPOTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "Status", design : sap.m.LabelDesign.Bold}),
		}
	));

	var oTemplate = new sap.m.ColumnListItem(
	{
			type: sap.m.ListType.Active,
			cells : [
			         	new sap.m.Label({
			         		text : '{HubPOTableModel>PoObjectId}'
			         	}),
		
			         	new sap.m.Label({
			         		text: '{HubPOTableModel>RfxObjectId}'
			         	}),
		
			         	new sap.m.Label({
			         		text : '{HubPOTableModel>PoAmount}'
			         	}),
		
			         	new sap.m.Label({
			         		text: '{HubPOTableModel>PoStatTxt}'
			         	})
			]
	});

	oPOTable.setModel(sap.ui.getCore().getModel('HubPOTableModel'));
	oPOTable.bindItems("HubPOTableModel>/results",oTemplate);
  
	oPOTable.setWidth('860px');
	
	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	oPOTable
	               ]
	  }).addStyleClass('viewMainLayout');
}