sap.ui.jsview("drlhub.view.grn", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf drlhub.grn
	*/ 
	getControllerName : function() {
		return "drlhub.view.grn";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf drlhub.grn
	*/ 
    createContent: function(oController) 
    {
        var row = sap.ui.commons.layout.MatrixLayoutRow;
        var cell = sap.ui.commons.layout.MatrixLayoutCell;
    
        return new sap.ui.commons.layout.MatrixLayout({
        	rows : [
	                    new row(this.createId('firstRow'), 
	                    {
	                        cells: [
	                                	new cell({
	                                			content: createDropDown(oController)
	                                	}).addStyleClass('sts-details'),
	                               ]
	                    }),
	                    getSeparator(this, 'first', 1),
	                    new row(this.createId('secondRow'), {
	                    	height: '100px',
	                        cells: [
	                            new cell({
	                                content: createButtons(oController)
	                            })
	                        ]
	                    }),
	                    getSeparator(this, 'second', 1),
	                    new row(this.createId('ThridRow'), {
	                        cells: [
	                            new cell({
	                                content: createDataTable()
	                            })
	                        ]
	                    }),
        	        ]
        });
    }

});

function getSeparator(_this, id, span) 
{
    return new sap.ui.commons.layout.MatrixLayoutRow(_this.createId(id + 'Sep'), 
    {
        height: '20px',
        cells: getBlankCell(span)
    });
}

function getBlankCell(span) 
{
    return new sap.ui.commons.layout.MatrixLayoutCell(
    {
        colSpan: span
    });
}

function createDropDown (oController)
{
	var grnDropDownBox = new sap.ui.commons.DropdownBox("grnDropDownBox", {
		
		items: [
		        new sap.ui.core.ListItem("M1111",{text: "Last 1 Month", key: "M01"}),
		        new sap.ui.core.ListItem("M2111",{text: "Last 3 Month", key: "M03"}),
		        new sap.ui.core.ListItem("M3111",{text: "Last 6 Month", key: "M06"}),
		        new sap.ui.core.ListItem("M4111",{text: "Past 1 Year", key: "M12"})
		],
		
        change:function(oEvent)
        {
        	oController.drlgrnDropDownBox('GRN', oEvent.oSource.getSelectedKey());
        },

	}).addStyleClass('hub-dropdown');

	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	grnDropDownBox
	               ]
	  }).addStyleClass('viewMainLayout');;
}

function createButtons(oController)
{
    var ipBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('gibtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.grn.qcPending.id, {
               }).addStyleClass('gival'),

                new sap.ui.commons.TextView(Widgets.grn.qcPending.nameID, {
                }).addStyleClass('gitxt')
                ]
        })
      /*  press: function() {
            console.log('pressed');
        }*/
    });
    
    var aBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('gabtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.grn.approved.id, {
                }).addStyleClass('gaval'),

                new sap.ui.commons.TextView(Widgets.grn.approved.nameID, {
                }).addStyleClass('gatxt')
                ]
        })
    });

    var rBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('grjbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.grn.rejectedGrn.id, {
                }).addStyleClass('grjval'),

                new sap.ui.commons.TextView(Widgets.grn.rejectedGrn.nameID, {
                }).addStyleClass('grjtxt')
                ]
        })
    });

    var retBtn = new sap.m.CustomTile({
        content: new sap.ui.layout.VerticalLayout('grtbtn',{
            width: '95%',
           // height: '100%',
            content: [
                new sap.ui.commons.TextView(Widgets.grn.returned.id, {
                }).addStyleClass('grval'),

                new sap.ui.commons.TextView(Widgets.grn.returned.nameID, {
                }).addStyleClass('grtxt')

                ]
        })
    });

    ipBtn.attachPress(oController.inprocess);
    aBtn.attachPress(oController.approved);
    rBtn.attachPress(oController.rejected);
    retBtn.attachPress(oController.returned);

  return new sap.ui.layout.HorizontalLayout({
      content: [
                	ipBtn,
                	aBtn, 
                	rBtn,
                	retBtn
               ]
  }).addStyleClass('viewMainLayout');
}

function createDataTable ()
{
	var oGRNTable = new sap.m.Table("gtestTbl", {
	  growing: true,
	  growingThreshold: 10,
	});
  
	oGRNTable.addColumn(new sap.m.Column(
		{  
			header: new sap.m.Label({text: "GRN Number", design : sap.m.LabelDesign.Bold}),     
		}
	));

	oGRNTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "ASN Number", design : sap.m.LabelDesign.Bold}),
		}
	));

	oGRNTable.addColumn(new sap.m.Column(
		{
			header: new sap.m.Label({text: "PO Number", design : sap.m.LabelDesign.Bold}),
		}
	));

//	oGRNTable.addColumn(new sap.m.Column(
//		{
//			header: new sap.m.Label({text: "Status", design : sap.m.LabelDesign.Bold}),
//		}
//	));

	var oTemplate = new sap.m.ColumnListItem(
	{
			type: sap.m.ListType.Active,
			cells : [
			         	new sap.m.Label({
			         		text : '{HubGRNTableModel>Mblnr}'
			         	}),
		
			         	new sap.m.Label({
			         		text: '{HubGRNTableModel>AsnNum}'
			         	}),
		
			         	new sap.m.Label({
			         		text : '{HubGRNTableModel>PoObjectId}'
			         	}),
		
//			         	new sap.m.Label({
//			         		text: '{HubGRNTableModel>Status}'
//			         	})
			]
	});

	oGRNTable.setModel(sap.ui.getCore().getModel('HubGRNTableModel'));
	oGRNTable.bindItems("HubGRNTableModel>/results",oTemplate);
  
	oGRNTable.setWidth('860px');
	
	  return new sap.ui.layout.HorizontalLayout({
	      content: [
	                	oGRNTable
	               ]
	  }).addStyleClass('viewMainLayout');
}
