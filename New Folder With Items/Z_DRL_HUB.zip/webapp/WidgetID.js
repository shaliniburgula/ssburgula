var Widgets = 
{
		applicationName : "HUB",
		applicationTitle : "DRL HUB",
		serviceName: "sap/opu/odata/sap",
		
		getControlById : function getControlById(controlId) 
		{
//			console.log ('WidgetID.js:   getControlById:   ' + sap.ui.getCore().byId(controlId));
			return sap.ui.getCore().byId(controlId);
		},

		header:
		{
			headerServiceName : "ZGW_HUB_HEADER_SRV",
			headerCountEntityName : "/HubHeaderSet",
			
			businessConducted :
			{
				id : "businessConductedID",
				nameID : "businessConductedName"
			},
			
			poConfirmed :
			{
				id : 'poConfirmedID',
				nameID : 'poconfirmedName'
			},
			
			invoiceRaised :
			{
				id : 'invoiceRaisedID',
				nameID : 'invoiceRaisedName'
			},
			
			paymentDetails :
			{
				id : 'amountPaidID',
				nameID : 'amountPaidName'
			},
			
			paymentDetails1 :
			{
				id : 'pendingPaymentID',
				nameID : 'pendingPaymentName'
			},
		},
		
		grn :
		{
			grnServiceName: "ZGW_PO_HUB_SRV",
			grnCountEntityName: "/GrnHubCountSet",
			grnTableEntityName: "/GrnHubSet",

			qcPending :
			{
				id : "grnQCPendingID",
				nameID : "grnQCPendingName"
			},
			
			approved : 
			{
				id : "grnApprovedID",
				nameID : "grnApprovedIDName"
			},
			
			rejectedGrn :
			{
				id : "grnRejectedID",
				nameID : "grnRejectedName"
			},
			
			returned :
			{
				id : "grnReturnedID",
				nameID : "grnReturnedName"
			}
		},
		
		invoice :
		{
			invoiceServiceName: "ZGW_PO_HUB_SRV",
			invoiceCountEntityName: "/InvHubCountSet",
			invoiceTableEntityName: "/InvcHubSet",
			invoiceTableEntityName1: "/InvcHub01Set",

			invoiceYetToUpload : 
			{
				id : "invoiceYetToUploadID",
				nameID : "invoiceYetToUploadName"
			},
			
			invoicePendingForHardCopy:
			{
				id : "invoicependingForHardCopyID",
				nameID : "invoicependingForHardCopyName"
			},
			
			invoiceInProcess: 
			{
				id : "invoiceinProcessID",
				nameID : "invoiceinProcessName"
			},
			
			invoiceUnderDeviation:
			{
				id : "invoiceunderDeviationID",
				nameID : "invoiceunderDeviationName"
			},
			
			invoiceHoldForPayment:
			{
				id : "invoiceholdForPaymentID",
				nameID : "invoiceholdForPaymentName"
			},

			invoiceClearForPayment:
			{
				id : "invoiceclearForPaymentID",
				nameID : "invoiceclearForPaymentName"
			},
			
			invoicePaymentCredited:
			{
				id : "invoicepaymentCreditedID",
				nameID : "invoicepaymentCreditedName"
			},
			
			invoiceRejected:
			{
				id : "invoicerejectedID",
				nameID : "invoicerejectedName"
			}
		},
		
		asn :
		{
			asnServiceName:"ZGW_PO_HUB_SRV",
			asnCountEntityName: "/AsnHubCountSet",
			asnTableEntityName: "/AsnHubSet",
			
			pendingShipment:
			{
				id : "psID",
				nameID: "psName"
			},
			
			intransit:
			{
				id: "intID",
				nameID: "intName"
			},
			
			gateEntryDone:
			{
				id: "gedID",
				nameID: "gedName"
			},
			
			pedningForGRN:
			{
				id: "pfgID",
				nameID: "pfgName"
			},
		},

		po :
		{
			poServiceName:"ZGW_PO_HUB_SRV",
			poCountEntityName: "/PoHubCountSet",
			poTableEntityName: "/PoHubSet",
			
			newStatus:
			{
				id : "newPOID",
				nameID: "newPOName"
			},
			
			acknowledged:
			{
				id: "acknowledgedID",
				nameID: "acknowledgedName"
			}
		},

		rfx :
		{
			rfxServiceName: "ZGW_RFX_HUB_SRV",
			rfxCountEntityName: "/RfxHubCountSet",
			rfxTableEntityName: "/RfxHubSet",
			
			totalReceived: 
			{
				id : "rfxTotalReceived",
				nameID : "rfxNameTotlaReceived"
			},
			
			yetToRespond:
			{
				id : "rfxYetToRespond",
				nameID : "rfxNameYetToRespond"
			},
			
			submitted:
			{
				id : "rfxSubmitted",
				nameID : "rfxNameSubmitted"
			}
		},
		
		overview : 
		{
			id : "overview",
			totalReceived : 
			{
				id : "rfxTotalReceivedID",
				nameID : "rfxTotalReceivedName"
			},
			
			yetToRespond : 
			{
				id : "rfxYetToRespondID",
				nameID : "rfxYetToRespondName"
			},
			
			submitted : 
			{
				id : "rfxSubmittedID",
				nameID : "rfxSubmittedName"
			},
			
			newPO :
			{
				id : "poNewStatusID",
				nameID : "poNewName"
			},
			
			acknowledgedPO : 
			{
				id : "acknowledgedPOID",
				nameID: "acknowledgedPOName"
			},
			
			pendingShipment : 
			{
				id : "pendingShipmentID",
				nameID: "pendingShipmentName"
			},
			
			inTransit : 
			{
				id : "intransitID",
				nameID : "intransitNameID"
			},
			
			gateEntryDone :
			{
				id : "gateEntryDoneID",
				nameID : "gateEntryNameID"
			},
			
			pedningForGRN :
			{
				id : "pendingForGRNID",
				nameID : "pendingForGRNNameID"
			},
			
			yetToUpload : 
			{
				id : "invoiceYetToUploadID",
				nameID : "invoiceYetToUploadName"
			},
			
			pendingForHardCopy:
			{
				id : "invoicependingForHardCopyID",
				nameID : "invoicependingForHardCopyName"
			},
			
			inProcess: 
			{
				id : "invoiceinProcessID",
				nameID : "invoiceinProcessName"
			},
			
			underDeviation:
			{
				id : "invoiceunderDeviationID",
				nameID : "invoiceunderDeviationName"
			},
			
			holdForPayment:
			{
				id : "invoiceholdForPaymentID",
				nameID : "invoiceholdForPaymentName"
			},

			clearForPayment:
			{
				id : "invoiceclearForPaymentID",
				nameID : "invoiceclearForPaymentName"
			},
			
			paymentCredited:
			{
				id : "invoicepaymentCreditedID",
				nameID : "invoicepaymentCreditedName"
			},
			
			rejected:
			{
				id : "invoicerejectedID",
				nameID : "invoicerejectedName"
			},
			
			qcPending :
			{
				id : "overviewGRNQCPendingID",
				nameID : "overviewGRNQCPendingName"
			},
			
			approved : 
			{
				id : "overviewGRNApprovedID",
				nameID : "overviewGRNApprovedIDName"
			},
			
			rejectedGrn :
			{
				id : "overviewGRNRejectedID",
				nameID : "overviewGRNRejectedName"
			},
			
			returned :
			{
				id : "overviewGRNReturnedID",
				nameID : "overviewGRNReturnedName"
			}
		},
};
