sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ca/ui/utils/busydialog"
], function(Controller,Busydialog) {
	"use strict";

	return Controller.extend("drlhub.view.App", {
		 _busyDialog: null,
    onInit: function() {
        
    },
    _setBusyOn: function() {
        if (!this.busyOn) {
            this.busyOn = true;
            Busydialog.requireBusyDialog();
        }
    },
    _setBusyOff: function() {
        if (this.busyOn) {
            this.busyOn = false;
            Busydialog.releaseBusyDialog();
        }
    }
	});

});

