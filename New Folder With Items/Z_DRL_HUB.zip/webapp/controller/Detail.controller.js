sap.ui.controller("drlhub.view.Detail", {
    onInit: function() {
        sap.ui.getCore().getEventBus().subscribe("app", "RefreshDetail", this._refresh, this);

        var self = this;
        this.getView().addEventDelegate({
            onBeforeShow: $.proxy(function(evt) {
                self.onBeforeShow();
            }, this)
        });
    },
    onBeforeShow: function() {
        var navBar = this.getView().byId('topNavBar');
        navBar.setSelectedItem(navBar.getItems()[0]);
    },
    onItemSelect: function(evt) {
        this._refresh(null, null, {
            id: evt.getParameter('item').getKey()
        });
    },
    _refresh: function(channelId, eventId, data) {
        var app = sap.ui.getCore().byId('theApp');
        
//        alert('View ID: Detail.controller.js:  ' + data.id);
        console.log('Detail.controller:  		View ID:     ' + data.id);

        if (data && data.id) {
            var view = sap.ui.getCore().byId(data.id);
            if (typeof view === 'undefined') {
                view = sap.ui.jsview(data.id, "drlhub.view." + data.id);
            }
           
            if (app.getPage(data.id) === null) {
                app.addPage(view);
            }
            this.getView().byId('mainContent').removeAllContent();
            this.getView().byId('mainContent').addContent(view);
//            console.log('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%: getView%%%%%%%%%%%%%%%%%%%%  ' + this.getView());
            
            //this.getView().setModel(sap.ui.getCore().getModel('DataModel'), 'HubModel');
        }
    }
});