sap.ui.controller("drlhub.view.Master", {
    onInit: function() {
        var bus = sap.ui.getCore().getEventBus();
        bus.subscribe("app", "SelectDetail", this._selectDetail, this);
//        bus.subscribe("nav", "to", this._navToHandler, this);

        var self = this;
        bus.subscribe("app", "dataLoaded", function() {
            self.getView().setModel(sap.ui.getCore().getModel('DataModel'), 'MasterModel');
            this._selectDetail();
        }, this);

        var self = this;
        this.getView().addEventDelegate({
            onBeforeShow: jQuery.proxy(function(evt) {
                self.onBeforeShow();
            }, this)
        });
    },
    onBeforeShow: function() {
        //.....
    },
    handleListSelect: function(evt) {
        this._showDetail(evt.getParameter("listItem"));
    },
    _selectDetail: function() {
        var list = this.getView().byId("mList");
        var items = list.getItems();
        if (items.length > 0 && !list.getSelectedItem()) {
            list.setSelectedItem(items[0]);
            this._showDetail(items[0]);
        }
    },
    _showDetail: function(item) {
//        sap.ui.getCore().getEventBus().publish("nav", "to", {
//            id: "Detail",
//            viewName: "drlhub.view.Detail",
//        });

        sap.ui.getCore().getEventBus().publish("app", "RefreshDetail", {
            id: item.getAttributes()[0].getText()
//            context: item.getBindingContext("mock")
        });
    }
});