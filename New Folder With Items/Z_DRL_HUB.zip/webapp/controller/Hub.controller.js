sap.ui.controller("drlhub.view.Hub", {

	rfxModel : null,
	rfxJSONModel : null,
	poModel : null,
	poJSONModel : null,
	asnModel : null,
	asnJSONModel : null,
	invoiceModel : null,
	invoiceJSONModel : null,
	grnModel : null,
	grnJSONModel : null,
	headerModel : null,
	headerJSONModel : null,
	paymentsJSONModel : null,

	yetToUploadCount : null,
	pendingForHardCopy : null,
	
	self: null,
	
	drlHubDropDownBox: function(text, id, selectedKey)
	{
		console.log('Hub.controller.js:   text:  ' + text + '   id:  ' + id + '    selectedKey:  ' + selectedKey);
		
		if (text == 'RFx')
			hubRFXData (text.toUpperCase(), selectedKey, self);
		else if (text == 'PO')
			hubPOData  ('PO', selectedKey, self);
		else if (text == 'ASN')
			hubASNOData ('ASN', selectedKey, self);
		else if (text == 'Invoice')
			hubInvoiceOData ('INV', selectedKey, self);
		else if (text == 'GRN')
			hubGRNOData ('GRN', selectedKey, self);

	},

//	onBeforeShow: function ()
//	{
//		
//	},
	
/*** Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.Overview
*/
	onInit: function() 
	{
			self = this;
			hubRFXData ('RFX', 'M03', self);
			hubPOData  ('PO', 'M03', self);
			hubASNOData ('ASN', 'M03', self);
			hubInvoiceOData ('INV', 'M03', self);
			hubGRNOData ('GRN', 'M03', self);
			hubHeaderOData (self);
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.Overview
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.Overview
*/
//     onAfterRendering: function() {
//
//     },

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.Overview
*/
//	onExit: function() {
//
//	}

});


function hubHeaderOData (self)
{
	headerModel = sap.ui.getCore().getModel('headerODataModel');
	headerJSONModel = new sap.ui.model.json.JSONModel();
	paymentsJSONModel = new sap.ui.model.json.JSONModel();
	
//	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];
	var param = "";
	
	headerModel.read(Widgets.header.headerCountEntityName, null, param, null, function(oData, oResponse)
	{
		headerJSONModel.setData(oData);

		var businessConducted;
		if (oData.results[0].Value > 1000000) 
			businessConducted = 'Rs. ' + (oData.results[0].Value) / 1000000 + 'M';
		else 
			businessConducted = 'Rs. ' + oData.results[0].Value;
		
		(Widgets.getControlById(Widgets.header.businessConducted.id)).setText(businessConducted);
		(Widgets.getControlById(Widgets.header.businessConducted.nameID)).setText(oData.results[0].HubComponent);

		(Widgets.getControlById(Widgets.header.poConfirmed.id)).setText(oData.results[1].Value);
		(Widgets.getControlById(Widgets.header.poConfirmed.nameID)).setText(oData.results[1].HubComponent);

		(Widgets.getControlById(Widgets.header.invoiceRaised.id)).setText(oData.results[2].Value);
		(Widgets.getControlById(Widgets.header.invoiceRaised.nameID)).setText(oData.results[2].HubComponent);

		self.getView().setModel(headerJSONModel, 'HubHeaderModel');
		paymentsJSONModel.setData({"paymentsResults" : 
			[{
					statusText			:   oData.results[3].HubComponent,
					valueText			: 	oData.results[3].Value
			},
			{
				statusText			:   oData.results[4].HubComponent,
				valueText			: 	oData.results[4].Value
			}]
		});
		
		(Widgets.getControlById(Widgets.header.paymentDetails.id)).setText(oData.results[3].Value);
		(Widgets.getControlById(Widgets.header.paymentDetails.nameID)).setText(oData.results[3].HubComponent);

		(Widgets.getControlById(Widgets.header.paymentDetails1.id)).setText(oData.results[4].Value);
		(Widgets.getControlById(Widgets.header.paymentDetails1.nameID)).setText(oData.results[4].HubComponent);

		self.getView().setModel(paymentsJSONModel, 'HubPaymentsModel');
	})
}


function hubRFXData(text, selectedKey, self)
{
	rfxModel = sap.ui.getCore().getModel('rfxODataModel');
	rfxJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	rfxModel.read(Widgets.rfx.rfxCountEntityName, null, param, null, function(oData, oResponse)
	{
		rfxJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.overview.totalReceived.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.overview.totalReceived.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.overview.yetToRespond.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.overview.yetToRespond.nameID)).setText(oData.results[1].StatusText);

		(Widgets.getControlById(Widgets.overview.submitted.id)).setText(oData.results[2].Count);
		(Widgets.getControlById(Widgets.overview.submitted.nameID)).setText(oData.results[2].StatusText);

		self.getView().setModel(rfxJSONModel, 'HubModel');
	})
}

function hubPOData(text, selectedKey, self)
{
	poModel = sap.ui.getCore().getModel('poODataModel');
	poJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	poModel.read(Widgets.po.poCountEntityName, null, param, null, function(oData, oResponse)
	{
		poJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.overview.acknowledgedPO.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.overview.acknowledgedPO.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.overview.newPO.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.overview.newPO.nameID)).setText(oData.results[1].StatusText);

		self.getView().setModel(poJSONModel, 'HubPOModel');
	})
}

function hubASNOData(text, selectedKey, self)
{
	asnModel = sap.ui.getCore().getModel('asnODataModel');
	asnJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	asnModel.read(Widgets.asn.asnCountEntityName, null, param, null, function(oData, oResponse)
	{
		asnJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.overview.pendingShipment.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.overview.pendingShipment.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.overview.inTransit.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.overview.inTransit.nameID)).setText(oData.results[1].StatusText);

		(Widgets.getControlById(Widgets.overview.gateEntryDone.id)).setText(oData.results[2].Count);
		(Widgets.getControlById(Widgets.overview.gateEntryDone.nameID)).setText(oData.results[2].StatusText);

		(Widgets.getControlById(Widgets.overview.pedningForGRN.id)).setText(oData.results[3].Count);
		(Widgets.getControlById(Widgets.overview.pedningForGRN.nameID)).setText(oData.results[3].StatusText);

		self.getView().setModel(asnJSONModel, 'HubASNModel');
	})
}


function hubInvoiceOData(text, selectedKey, self)
{
	invoiceModel = sap.ui.getCore().getModel('invoiceODataModel');
	invoiceJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	invoiceModel.read(Widgets.invoice.invoiceCountEntityName, null, param, null, function(oData, oResponse)
	{
//		invoiceJSONModel.setData(oData);
//		yetToUploadCount = oData.results[0].Count;
//		pendingForHardCopy = oData.results[1].Count;

//		console.log('yetToUploadCount:  ' + yetToUploadCount);
//		console.log('pendingForHardCopy:  ' + pendingForHardCopy);
		
//		(Widgets.getControlById(Widgets.overview.yetToUpload.id)).setText(oData.results[0].Count);
//		(Widgets.getControlById(Widgets.overview.yetToUpload.nameID)).setText(oData.results[0].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.pendingForHardCopy.id)).setText(oData.results[1].Count);
//		(Widgets.getControlById(Widgets.overview.pendingForHardCopy.nameID)).setText(oData.results[1].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.inProcess.id)).setText(oData.results[2].Count);
//		(Widgets.getControlById(Widgets.overview.inProcess.nameID)).setText(oData.results[2].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.underDeviation.id)).setText(oData.results[3].Count);
//		(Widgets.getControlById(Widgets.overview.underDeviation.nameID)).setText(oData.results[3].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.holdForPayment.id)).setText(oData.results[4].Count);
//		(Widgets.getControlById(Widgets.overview.holdForPayment.nameID)).setText(oData.results[4].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.clearForPayment.id)).setText(oData.results[5].Count);
//		(Widgets.getControlById(Widgets.overview.clearForPayment.nameID)).setText(oData.results[5].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.paymentCredited.id)).setText(oData.results[6].Count);
//		(Widgets.getControlById(Widgets.overview.paymentCredited.nameID)).setText(oData.results[6].StatusText);
//
//		(Widgets.getControlById(Widgets.overview.rejected.id)).setText(oData.results[7].Count);
//		(Widgets.getControlById(Widgets.overview.rejected.nameID)).setText(oData.results[7].StatusText);

//		self.getView().setModel(invoiceJSONModel, 'HubInvoiceModel');
		
		invoiceJSONModel.setData({"invoiceResults" : 
				[{
						yetToUpload 		: 	oData.results[0].Count,
						pendingForHardCopy 	: 	oData.results[1].Count,
						inProcess 			: 	oData.results[2].Count,
						underDeviation 		: 	oData.results[3].Count,
						holdForPayment 		: 	oData.results[4].Count,
						clearForPayment 	: 	oData.results[5].Count,
						paymentCredited 	: 	oData.results[6].Count,	
						rejected 			: 	oData.results[7].Count
				}]
		});
		
		self.getView().setModel(invoiceJSONModel, 'HubInvoiceModel');

	})
}

function hubGRNOData(text, selectedKey, self)
{
	grnModel = sap.ui.getCore().getModel('asnODataModel');
	grnJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	grnModel.read(Widgets.asn.asnCountEntityName, null, param, null, function(oData, oResponse)
	{
		grnJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.overview.qcPending.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.overview.qcPending.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.overview.approved.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.overview.approved.nameID)).setText(oData.results[1].StatusText);

		(Widgets.getControlById(Widgets.overview.rejectedGrn.id)).setText(oData.results[2].Count);
		(Widgets.getControlById(Widgets.overview.rejectedGrn.nameID)).setText(oData.results[2].StatusText);

		(Widgets.getControlById(Widgets.overview.returned.id)).setText(oData.results[3].Count);
		(Widgets.getControlById(Widgets.overview.returned.nameID)).setText(oData.results[3].StatusText);

		self.getView().setModel(grnJSONModel, 'HubGRNModel');
	})
}
