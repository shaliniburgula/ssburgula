sap.ui.controller("drlhub.view.invoice",
		{

			/**
			 * Called when a controller is instantiated and its View controls
			 * (if available) are already created. Can be used to modify the
			 * View before it is displayed, to bind event handlers and do other
			 * one-time initialization.
			 * 
			 * @memberOf drlhub.invoice
			 */
			invoiceModel : null,
			invoiceJSONModel : null,
			tempINVOICEJSONModel : null,
			self : null,
			selectedButton : null,
			selectedKeyValue : null,
			textValue : null,

			onInit : function() 
			{
				sap.ui.getCore().byId('iybtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');

				self = this;
				selectedButton = '01';
				textValue = 'INV';
				selectedKeyValue = 'M01';

				/*
				 * this.getView().addEventDelegate({ onBeforeShow:
				 * jQuery.proxy(function(evt) { self.onBeforeShow(); }, this)
				 * });
				 * 
				 */
				hubInvoiceOData(textValue, selectedKeyValue, self);
				hubInvoiceTableData_1(textValue, selectedKeyValue, selectedButton, self);
			},

			drlInvoiceDropDownBox: function(text, selectedKey)
			{
				selectedKeyValue = selectedKey;
				textValue = text.toUpperCase();

				console.log('invoice.controller.js:   textValue:  ' + textValue + '    selectedKeyValue:  ' + selectedKeyValue);
				hubInvoiceOData(textValue, selectedKeyValue, self);
				hubInvoiceTableData_1(textValue, selectedKeyValue, selectedButton, self);
			},

			
			onBeforeShow : function() 
			{
				console.log('onBeforeShow Method:   selectedButton:  ' + selectedButton);
			},

			onAfterRendering : function() 
			{
				// sap.ui.getCore().getElementById("itestTbl").setModel(oModelRfx);
				// $('#iphbtn').append("<br>Hard Copy");
			},

			/**
			 * Similar to onAfterRendering, but this hook is invoked before the
			 * controller's View is re-rendered (NOT before the first rendering!
			 * onInit() is used for that one!).
			 * 
			 * @memberOf drlhub.invoice
			 */
			onBeforeRendering : function() 
			{
				console.log('onBeforeRendering:    selectedButton:   ' + selectedButton);
			},

			/**
			 * Called when the View has been rendered (so its HTML is part of
			 * the document). Post-rendering manipulations of the HTML could be
			 * done here. This hook is the same one that SAPUI5 controls get
			 * after being rendered.
			 * 
			 * @memberOf drlhub.invoice
			 */
			onAfterRendering : function() 
			{
				console.log('onAfterRendering:    selectedButton:   ' + selectedButton);
			},

			/**
			 * Called when the Controller is destroyed. Use this one to free
			 * resources and finalize activities.
			 * 
			 * @memberOf drlhub.invoice
			 */
			// onExit: function() {
			//
			// }
			yetup : function() 
			{
				selectedButton = '01';
				hubInvoiceTableData_1(textValue, selectedKeyValue, selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(true);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(false);

				sap.ui.getCore().byId('iybtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');
			},

			pend : function() 
			{
				selectedButton = '02';
				hubInvoiceTableData(textValue, selectedKeyValue, selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(true);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(false);

				sap.ui.getCore().byId('ipbtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');
			},

			inproc : function() 
			{

				selectedButton = '03';
				hubInvoiceTableData(textValue, selectedKeyValue, selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(true);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(false);

				sap.ui.getCore().byId('iibtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');
			},

			underd : function() 
			{
				selectedButton = '04';
				hubInvoiceTableData(textValue, selectedKeyValue, selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(true);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(false);

				sap.ui.getCore().byId('iubtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');
			},

			underb : function() 
			{
				selectedButton = '05';
				hubInvoiceTableData(textValue, selectedKeyValue,selectedButton, self);

				sap.ui.getCore().byId('ibbtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');

			},

			clerpay : function() 
			{
				selectedButton = '06';
				hubInvoiceTableData(textValue, selectedKeyValue,selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(true);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(false);

				sap.ui.getCore().byId('icbtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');

			},

			paymentCredited : function() 
			{
				selectedButton = '07';
				hubInvoiceTableData(textValue, selectedKeyValue, selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(true);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(false);

				sap.ui.getCore().byId('ipcbtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('irbtn').removeStyleClass('iybtn1');
			},

			rejected : function() 
			{
				selectedButton = '08';
				hubInvoiceTableData(textValue, selectedKeyValue,selectedButton, self);

				sap.ui.getCore().byId("invoiceTable_yetToUpload").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_pendingForHardCopy").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_inProcessTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_underDeviationTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_clearForPaymentTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_paymentCreditedTable").setVisible(false);
				sap.ui.getCore().byId("invoiceTable_rejectedTable").setVisible(true);

				sap.ui.getCore().byId('irbtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('iybtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iibtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ibbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('iubtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('icbtn').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('ipcbtn').removeStyleClass('iybtn1');
			}

		});

function hubInvoiceOData(text, selectedKey, self) {
	invoiceModel = sap.ui.getCore().getModel('invoiceODataModel');
	invoiceJSONModel = new sap.ui.model.json.JSONModel();

	var param = [ "$filter=DataType eq '" + text + "' and DataRange eq '"
			+ selectedKey + "'" ];

	invoiceModel
			.read(
					Widgets.invoice.invoiceCountEntityName,
					null,
					param,
					null,
					function(oData, oResponse) {
						invoiceJSONModel.setData(oData);

						(Widgets
								.getControlById(Widgets.invoice.invoiceYetToUpload.id))
								.setText(oData.results[0].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoiceYetToUpload.nameID))
								.setText(oData.results[0].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoicePendingForHardCopy.id))
								.setText(oData.results[1].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoicePendingForHardCopy.nameID))
								.setText(oData.results[1].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoiceInProcess.id))
								.setText(oData.results[2].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoiceInProcess.nameID))
								.setText(oData.results[2].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoiceUnderDeviation.id))
								.setText(oData.results[3].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoiceUnderDeviation.nameID))
								.setText(oData.results[3].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoiceHoldForPayment.id))
								.setText(oData.results[4].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoiceHoldForPayment.nameID))
								.setText(oData.results[4].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoiceClearForPayment.id))
								.setText(oData.results[5].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoiceClearForPayment.nameID))
								.setText(oData.results[5].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoicePaymentCredited.id))
								.setText(oData.results[6].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoicePaymentCredited.nameID))
								.setText(oData.results[6].StatusText);

						(Widgets
								.getControlById(Widgets.invoice.invoiceRejected.id))
								.setText(oData.results[7].Count);
						(Widgets
								.getControlById(Widgets.invoice.invoiceRejected.nameID))
								.setText(oData.results[7].StatusText);

						self.getView().setModel(invoiceJSONModel,
								'HubInvoiceModel');
					})
}

function hubInvoiceTableData_1(text, selectedKey, selectedButton, self) {
	invoiceModel = sap.ui.getCore().getModel('invoiceODataModel');
	invoiceJSONModel = new sap.ui.model.json.JSONModel();
	tempINVOICEJSONModel = new sap.ui.model.json.JSONModel();
	
	var param = [ "$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "' and Status eq '" + selectedButton + "'" ];

	console.log('Invoice Param:   hubInvoiceTableData_1:  ' + param);

	invoiceModel.read(Widgets.invoice.invoiceTableEntityName1, null, param, null, function(oData, oResponse) 
			{
				invoiceJSONModel.setData(oData);
				
				if (oData.results.length > 0)
				{
					var tempOData = "{\"invoiceResults\":["; 
					for (var count = 0; count < oData.results.length; count++)
					{
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd/MM/yyyy"}); //Returns a DateFormat instance for date and time
						var tempDate = oData.results[count].AsnDate;
						console.log('tempDate: *********  ' + tempDate + '    length:   ' + tempDate.length);
					
//						if (tempDate.length != null || tempDate != "" || (!tempDate || /^\s*$/.test(tempDate)))
//						if (!tempDate.length === 0)
						tempDate = oDateFormat.format(oData.results[count].AsnDate)
//						else
//							tempDate = "";
					
						tempOData = tempOData + "{\"PoObjectId\":\"" + oData.results[count].PoObjectId + "\"," + 
									"\"AsnDate\":\"" + tempDate + "\"},";
					}
				
					tempOData = tempOData.substring(0, tempOData.length - 1);
					tempOData = tempOData + "]}";
					console.log('tempOData:   ' + tempOData);

					var tempArray;
					if (tempOData.length > 0)
						tempArray = jQuery.parseJSON(tempOData);
				
//					tempASNJSONModel.setData({modelData: tempOData});
					tempINVOICEJSONModel.setData(tempArray);
					self.getView().setModel(tempINVOICEJSONModel, 'HubTEMPASNTableModel');
				}else
				{
					self.getView().setModel(invoiceJSONModel, 'HubTEMPASNTableModel');
				}
			})
}

function hubInvoiceTableData(text, selectedKey, selectedButton, self) 
{
	invoiceModel = sap.ui.getCore().getModel('invoiceODataModel');
	invoiceJSONModel = new sap.ui.model.json.JSONModel();

	var param = [ "$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "' and Status1 eq '" + selectedButton + "'" ];

	console.log('Invoice Param:   hubInvoiceTableData:  ' + param);

	invoiceModel.read(Widgets.invoice.invoiceTableEntityName, null, param, null, function(oData, oResponse) 
			{
				invoiceJSONModel.setData(oData);
				
				if (oData.results.length > 0)
				{
					var tempOData = "{\"invoiceResults\":["; 
					for (var count = 0; count < oData.results.length; count++)
					{
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd/MM/yyyy"}); //Returns a DateFormat instance for date and time
						var tempDate = oData.results[count].PayDueDate;
						var tempDate1 = oData.results[count].StatusDate;
						
//						console.log('tempDate: *********  ' + tempDate + '    length:   ' + tempDate.length);
					
//						if (tempDate.length != null || tempDate != "" || (!tempDate || /^\s*$/.test(tempDate)))
//						if (!tempDate.length === 0)
						tempDate = oDateFormat.format(oData.results[count].PayDueDate);
						tempDate1 = oDateFormat.format(oData.results[count].StatusDate);
//						else
//							tempDate = "";
					
						tempOData = tempOData + "{\"DeviationName\":\"" + oData.results[count].DeviationName + "\"," + 
									"\"InvAmt\":\"" + oData.results[count].InvAmt + "\"," + 
									"\"InvApprAmt\":\"" + oData.results[count].InvApprAmt + "\"," + 
									"\"InvNum\":\"" + oData.results[count].InvNum + "\"," + 
									"\"PayDueDate\":\"" + tempDate + "\"," + 
									"\"PersonName\":\"" + oData.results[count].PersonName + "\"," + 
									"\"StatusDate\":\"" + tempDate1 + "\"," + 
									"\"StatusDescription\":\"" + oData.results[count].StatusDescription + "\"},";
					}
				
					tempOData = tempOData.substring(0, tempOData.length - 1);
					tempOData = tempOData + "]}";
					console.log('tempOData:   ' + tempOData);

					var tempArray;
					if (tempOData.length > 0)
						tempArray = jQuery.parseJSON(tempOData);
				
//					tempASNJSONModel.setData({modelData: tempOData});
					tempINVOICEJSONModel.setData(tempArray);
					self.getView().setModel(tempINVOICEJSONModel, 'HubTEMPASNTableModel');
				}else
				{
					self.getView().setModel(invoiceJSONModel, 'HubTEMPASNTableModel');
				}
			})
}
