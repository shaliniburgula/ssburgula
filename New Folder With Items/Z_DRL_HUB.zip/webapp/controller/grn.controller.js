sap.ui.controller("drlhub.view.grn", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf drlhub.grn
*/
	grnModel: null,
	grnJSONModel: null,
	self: null,
	selectedButton: null,
	selectedKeyValue: null,
	textValue: null,

	drlgrnDropDownBox: function(text, selectedKey)
	{
		selectedKeyValue = selectedKey;
		textValue = text.toUpperCase();

		hubGRNOData(textValue, selectedKeyValue, self);
		hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);
	},

	
	 onInit: function ()
	 {
			self = this;
			selectedButton = '01';
			textValue = 'GRN';
			selectedKeyValue = 'M01';

	        this.getView().addEventDelegate({
	            onBeforeShow: jQuery.proxy(function(evt) {
	                self.onBeforeShow();
	            }, this)
	        });
			
	        hubGRNOData (textValue, selectedKeyValue, self);
	        hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);
	 },
	
	 onBeforeShow: function() 
	 {
		 hubGRNOData (textValue, selectedKeyValue, self);
	     hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);
	},

	
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf drlhub.grn
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf drlhub.grn
*/
	onAfterRendering: function() {
			sap.ui.getCore().byId('gibtn').addStyleClass('iybtn1');
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf drlhub.grn
*/
//	onExit: function() {
//
//	}
	inprocess: function (){
		sap.ui.getCore().byId('gibtn').addStyleClass('iybtn1');
		sap.ui.getCore().byId('gabtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('grjbtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('grtbtn').removeStyleClass('iybtn1');

	 selectedButton = '01';
	 hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);
},

approved: function (){
	sap.ui.getCore().byId('gabtn').addStyleClass('iybtn1');
	sap.ui.getCore().byId('gibtn').removeStyleClass('iybtn1');
	sap.ui.getCore().byId('grjbtn').removeStyleClass('iybtn1');
	sap.ui.getCore().byId('grtbtn').removeStyleClass('iybtn1');

		 selectedButton = '02';
		 hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);

	},
	rejected: function (){
		sap.ui.getCore().byId('grjbtn').addStyleClass('iybtn1');
		sap.ui.getCore().byId('gabtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('gibtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('grtbtn').removeStyleClass('iybtn1');

	 selectedButton = '03';
	 hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);

},
   returned: function (){
		sap.ui.getCore().byId('grtbtn').addStyleClass('iybtn1');
		sap.ui.getCore().byId('grjbtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('gabtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('gibtn').removeStyleClass('iybtn1');

		 selectedButton = '04';
		 hubGRNTableData (textValue, selectedKeyValue, selectedButton, self);

	}

});

function hubGRNOData(text, selectedKey, self)
{
	grnModel = sap.ui.getCore().getModel('grnODataModel');
	grnJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	grnModel.read(Widgets.grn.grnCountEntityName, null, param, null, function(oData, oResponse)
	{
		grnJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.grn.qcPending.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.grn.qcPending.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.grn.approved.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.grn.approved.nameID)).setText(oData.results[1].StatusText);

		(Widgets.getControlById(Widgets.grn.rejectedGrn.id)).setText(oData.results[2].Count);
		(Widgets.getControlById(Widgets.grn.rejectedGrn.nameID)).setText(oData.results[2].StatusText);

		(Widgets.getControlById(Widgets.grn.returned.id)).setText(oData.results[3].Count);
		(Widgets.getControlById(Widgets.grn.returned.nameID)).setText(oData.results[3].StatusText);

		self.getView().setModel(grnJSONModel, 'HubGRNModel');
	})
}

function hubGRNTableData (text, selectedKey, selectedButton, self)
{
	grnModel = sap.ui.getCore().getModel('grnODataModel');
	grnJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "' and Status eq '" + selectedButton + "'"];

	console.log('grn.controller.js		Param:   ' + param);
	
	grnModel.read(Widgets.grn.grnTableEntityName, null, param, null, function(oData, oResponse)
	{
		grnJSONModel.setData(oData);
		self.getView().setModel(grnJSONModel, 'HubGRNTableModel');
	})
}
