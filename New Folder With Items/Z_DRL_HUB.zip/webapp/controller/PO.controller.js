sap.ui.controller("drlhub.view.PO", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf drlhub.po
*/
	poModel: null,
	poJSONModel: null,
	tempSelf: null,
	selectedButton: null,
	selectedKeyValue: null,
	textValue: null,

	 onInit: function ()
	 {
			var self = this;
			tempSelf = this;
			
			selectedButton = '01';
			textValue = 'PO';
			selectedKeyValue = 'M01';

	        this.getView().addEventDelegate({
	            onBeforeShow: function(evt) {
	                self.onBeforeShow();
	            }
	        });
			
	        hubPOData (textValue, selectedKeyValue, self);
			hubPOTableData (textValue, selectedKeyValue, selectedButton, self);

			sap.ui.getCore().byId('pybtn').addStyleClass('iybtn1');
	 },

//    onInit: function() {
//
//        self = this;
//        this.getView().addEventDelegate({
//            onBeforeShow: $.proxy(function(evt) {
//                self.onBeforeShow();
//            }, this)
//        });
//    },
    onBeforeShow: function() {
    	console.log('Method onBeforeShow PO.controller.js Method onBeforeShow PO.controller.js Method onBeforeShow PO.controller.js Method onBeforeShow PO.controller.js');
    },

	drlPODropDownBox: function(text, selectedKey)
	{
		selectedKeyValue = selectedKey;
		textValue = text.toUpperCase();

		console.log('PO.controller.js:   textValue:  ' + textValue + '    selectedKeyValue:  ' + selectedKeyValue);
		hubPOData (textValue, selectedKeyValue, tempSelf);
		hubPOTableData (textValue, selectedKeyValue, selectedButton, tempSelf);
	},

	
	onAfterRendering: function() 
	{
//		$("#pybtn").css({'background':'#ffb806',"color":"#fff"});
//		sap.ui.getCore().byId('pybtn').addStyleClass('iybtn1');
//		sap.ui.getCore().byId(Widgets.po.acknowledged.id).addStyleClass('iybtn2');
//		sap.ui.getCore().byId(Widgets.po.acknowledged.nameID).addStyleClass('iybtn2');
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf drlhub.po
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf drlhub.po
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf drlhub.po
*/
//	onExit: function() {
//
//	}

	yta : function()
	{
			sap.ui.getCore().byId('pybtn').addStyleClass('iybtn1');
			sap.ui.getCore().byId('pabtn').removeStyleClass('iybtn1');

			selectedButton = '01';

			hubPOTableData (textValue, selectedKeyValue, selectedButton, tempSelf);
	},
	
	ack : function()
	{
			sap.ui.getCore().byId('pybtn').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('pabtn').addStyleClass('iybtn1');

			selectedButton = '02';

			hubPOTableData (textValue, selectedKeyValue, selectedButton, tempSelf);
	}
});


function hubPOData(text, selectedKey, self)
{
	poModel = sap.ui.getCore().getModel('poODataModel');
	poJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	poModel.read(Widgets.po.poCountEntityName, null, param, null, function(oData, oResponse)
	{
		poJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.po.newStatus.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.po.newStatus.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.po.acknowledged.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.po.acknowledged.nameID)).setText(oData.results[1].StatusText);

		self.getView().setModel(poJSONModel, 'HubPOModel');
	})
}

function hubPOTableData (text, selectedKey, selectedButton, self)
{
	poModel = sap.ui.getCore().getModel('poODataModel');
	poJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "' and Status eq '" + selectedButton + "'"];

	console.log('PO Param:   ' + param);
	
	poModel.read(Widgets.po.poTableEntityName, null, param, null, function(oData, oResponse)
	{
		poJSONModel.setData(oData);
		self.getView().setModel(poJSONModel, 'HubPOTableModel');
	})
}
