sap.ui.controller("drlhub.view.Rfx", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf drlhub.rfx
*/
		rfxModel : null,
		rfxJSONModel : null,
		tempRFXJSONModel : null,
		self: null,
		selectedButton: null,
		selectedKeyValue: null,
		textValue: null,
		
		drlRfxDropDownBox: function(text, selectedKey)
		{
			selectedKeyValue = selectedKey;
			textValue = text.toUpperCase();

			hubRFXData (textValue, selectedKeyValue, self);
			hubRFXTableData (textValue, selectedKeyValue, selectedButton, self);
		},
	 onInit: function ()
	 {
			self = this;
			selectedButton = '01';

			textValue = 'RFX';
			selectedKeyValue = 'M01';
			
			hubRFXData (textValue, selectedKeyValue, self);
			hubRFXTableData (textValue, selectedKeyValue, selectedButton, self);
	 },

//		onBeforeShow: function() {
//			console.log('onBeforeShowasdfsadfasdfdsafsa');
//		},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf drlhub.rfx
*/
	onBeforeRendering: function() {
		
	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf drlhub.rfx
*/
	onAfterRendering: function()
	{
		sap.ui.getCore().byId('rcdbtn').addStyleClass('iybtn1');
	},
	
/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf drlhub.rfx
*/
//	onExit: function() {
//
//	}
	
	recd : function ()
	{
		sap.ui.getCore().byId('rcdbtn').addStyleClass('iybtn1');
		sap.ui.getCore().byId('ryrbtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('rsbt').removeStyleClass('iybtn1');
		
		selectedButton = '01';
		hubRFXTableData (textValue, selectedKeyValue, selectedButton, self);
	},
	
	ntrecd: function()
	{
		sap.ui.getCore().byId('ryrbtn').addStyleClass('iybtn1');
		sap.ui.getCore().byId('rcdbtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('rsbt').removeStyleClass('iybtn1');

		selectedButton = '02';
		hubRFXTableData (textValue, selectedKeyValue, selectedButton, self);
	},
	
	subm: function()
	{
		sap.ui.getCore().byId('rsbt').addStyleClass('iybtn1');
		sap.ui.getCore().byId('ryrbtn').removeStyleClass('iybtn1');
		sap.ui.getCore().byId('rcdbtn').removeStyleClass('iybtn1');

		selectedButton = '03';
		hubRFXTableData (textValue, selectedKeyValue, selectedButton, self);
	}
});


function hubRFXData(text, selectedKey, self)
{
	rfxModel = sap.ui.getCore().getModel('rfxODataModel');
	rfxJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	rfxModel.read(Widgets.rfx.rfxCountEntityName, null, param, null, function(oData, oResponse)
	{
		rfxJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.rfx.totalReceived.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.rfx.totalReceived.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.rfx.yetToRespond.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.rfx.yetToRespond.nameID)).setText(oData.results[1].StatusText);

		(Widgets.getControlById(Widgets.rfx.submitted.id)).setText(oData.results[2].Count);
		(Widgets.getControlById(Widgets.rfx.submitted.nameID)).setText(oData.results[2].StatusText);
		
		self.getView().setModel(rfxJSONModel, 'HubModel');
	})
}

function hubRFXTableData (text, selectedKey, selectedButton, self)
{
	rfxModel = sap.ui.getCore().getModel('rfxODataModel');
	rfxJSONModel = new sap.ui.model.json.JSONModel();
	
	tempRFXJSONModel = new sap.ui.model.json.JSONModel();
	
	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "' and Status eq '" + selectedButton + "'"];

	console.log('Param:   ' + param);
	
	rfxModel.read(Widgets.rfx.rfxTableEntityName, null, param, null, function(oData, oResponse)
	{
		rfxJSONModel.setData(oData);
		console.log ('#$@%$#@%$#@%$#@%#@$%$#@%#@$%#@%#@:    ' + oData.results.length);
		
		var tempOData = "{\"rfxResults\":["; 
		if (oData.results.length > 0)
		{
			for (var count = 0; count < oData.results.length; count++)
			{
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd/MM/yyyy"}); //Returns a DateFormat instance for date and time
				var tempDate = oData.results[count].QuotDead;
			
				console.log('tempDate:   ' + tempDate +'      ******   ' + tempDate.length);
				
//				if (tempDate.length != null || tempDate != "")
//				if (!tempDate.length === 0)
					tempDate = oDateFormat.format(oData.results[count].QuotDead);
//					else
//						tempDate = "";
			
				tempOData = tempOData + "{\"rfxNumber\":\"" + oData.results[count].RfxObjectId + "\"," + 
							"\"contactPerson\":\""  + oData.results[count].BuyerName + "\"," + 
							"\"submissionDate\":\"" + tempDate + "\"," + 
							"\"eventStatus\":\"" + oData.results[count].RfxStatTxt + "\"},";
			}
		
			tempOData = tempOData.substring(0, tempOData.length - 1);
			tempOData = tempOData + "]}";
			console.log('tempOData:   ' + tempOData);
		
			var tempArray = jQuery.parseJSON(tempOData);
		
//			tempRFXJSONModel.setData({modelData: tempOData});
			tempRFXJSONModel.setData(tempArray);
		
			self.getView().setModel(tempRFXJSONModel, 'HubTEMPRFXTableModel');
		}
		else
		{
//			self.getView().setModel(rfxJSONModel, 'HubRFXTableModel');
			self.getView().setModel(rfxJSONModel, 'HubTEMPRFXTableModel');
		}
	})
}

