sap.ui.controller("drlhub.view.asn", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf drlhub.asn
*/

	asnModel : null,
	asnJSONModel : null,
	tempASNJSONModel : null,
	self: null,
	selectedButton: null,
	selectedKeyValue: null,
	textValue: null,
	
	drlasnDropDownBox: function(text, selectedKey)
	{
		selectedKeyValue = selectedKey;
		textValue = text.toUpperCase();

		hubASNOData(textValue, selectedKeyValue, self);
		hubASNTableData (textValue, selectedKeyValue, selectedButton, self);
	},

 
 onInit: function ()
 {
		self = this;
		selectedButton = '01';

		textValue = 'ASN';
		selectedKeyValue = 'M01';
		
		hubASNOData(textValue, selectedKeyValue, self);
		hubASNTableData (textValue, selectedKeyValue, selectedButton, self);

		sap.ui.getCore().byId('apsbtn').addStyleClass('iybtn1');
 },

	
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf drlhub.asn
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf drlhub.asn
*/
		onAfterRendering: function() {
//			  sap.ui.getCore().getElementById("atestTbl").setModel(oModelRfx);
//			  $("#apsbtn").css({'background':'#ffb806',"color":"#fff"});
		},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf drlhub.asn
*/
//	onExit: function() {
//
//	}
		psmnt : function()
		{
			 selectedButton = '01';
			 hubASNTableData (textValue, selectedKeyValue, selectedButton, self);

				sap.ui.getCore().byId('apsbtn').addStyleClass('iybtn1');
				sap.ui.getCore().byId('ait').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('aged').removeStyleClass('iybtn1');
				sap.ui.getCore().byId('prgBtn').removeStyleClass('iybtn1');

				sap.ui.getCore().byId("asnTbl").setVisible(false);
				sap.ui.getCore().byId("asnTbl_1").setVisible(true);
		},

		itst: function()
		{

			 selectedButton = '02';
			 hubASNTableData (textValue, selectedKeyValue, selectedButton, self);

			sap.ui.getCore().byId('ait').addStyleClass('iybtn1');
			sap.ui.getCore().byId('apsbtn').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('aged').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('prgBtn').removeStyleClass('iybtn1');
			
				sap.ui.getCore().byId("asnTbl").setVisible(true);
				sap.ui.getCore().byId("asnTbl_1").setVisible(false);
		},
		
		agtent: function()
		{
			 selectedButton = '03';
			 hubASNTableData (textValue, selectedKeyValue, selectedButton, self);

			sap.ui.getCore().byId('aged').addStyleClass('iybtn1');
			sap.ui.getCore().byId('ait').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('apsbtn').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('prgBtn').removeStyleClass('iybtn1');
			
				sap.ui.getCore().byId("asnTbl").setVisible(true);
				sap.ui.getCore().byId("asnTbl_1").setVisible(false);
		},

		pendingForGrn: function()
		{
			 selectedButton = '04';
			 hubASNTableData (textValue, selectedKeyValue, selectedButton, self);

			 sap.ui.getCore().byId('prgBtn').addStyleClass('iybtn1');
			 sap.ui.getCore().byId('aged').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('ait').removeStyleClass('iybtn1');
			sap.ui.getCore().byId('apsbtn').removeStyleClass('iybtn1');

				sap.ui.getCore().byId("asnTbl").setVisible(true);
				sap.ui.getCore().byId("asnTbl_1").setVisible(false);
		}

});

function hubASNOData(text, selectedKey, self)
{
	asnModel = sap.ui.getCore().getModel('asnODataModel');
	asnJSONModel = new sap.ui.model.json.JSONModel();

	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "'"];

	asnModel.read(Widgets.asn.asnCountEntityName, null, param, null, function(oData, oResponse)
	{
		asnJSONModel.setData(oData);

		(Widgets.getControlById(Widgets.asn.pendingShipment.id)).setText(oData.results[0].Count);
		(Widgets.getControlById(Widgets.asn.pendingShipment.nameID)).setText(oData.results[0].StatusText);

		(Widgets.getControlById(Widgets.asn.intransit.id)).setText(oData.results[1].Count);
		(Widgets.getControlById(Widgets.asn.intransit.nameID)).setText(oData.results[1].StatusText);

		(Widgets.getControlById(Widgets.asn.gateEntryDone.id)).setText(oData.results[2].Count);
		(Widgets.getControlById(Widgets.asn.gateEntryDone.nameID)).setText(oData.results[2].StatusText);

		(Widgets.getControlById(Widgets.asn.pedningForGRN.id)).setText(oData.results[3].Count);
		(Widgets.getControlById(Widgets.asn.pedningForGRN.nameID)).setText(oData.results[3].StatusText);

		self.getView().setModel(asnJSONModel, 'HubASNModel');
	})
}

function hubASNTableData (text, selectedKey, selectedButton, self)
{
	asnModel = sap.ui.getCore().getModel('asnODataModel');
	asnJSONModel = new sap.ui.model.json.JSONModel();
	tempASNJSONModel = new sap.ui.model.json.JSONModel();
	
	var param = ["$filter=DataType eq '" + text + "' and DataRange eq '" + selectedKey + "' and Status eq '" + selectedButton + "'"];

	console.log('asn.controller.js		Param:   ' + param);
	
	asnModel.read(Widgets.asn.asnTableEntityName, null, param, null, function(oData, oResponse)
	{
		asnJSONModel.setData(oData);
		if (oData.results.length > 0)
		{
			var tempOData = "{\"asnResults\":["; 
			for (var count = 0; count < oData.results.length; count++)
			{
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd/MM/yyyy"}); //Returns a DateFormat instance for date and time
				var tempDate = oData.results[count].AsnDate;
				console.log('tempDate: *********  ' + tempDate + '    length:   ' + tempDate.length);
			
//				if (tempDate.length != null || tempDate != "" || (!tempDate || /^\s*$/.test(tempDate)))
//				if (!tempDate.length === 0)
				tempDate = oDateFormat.format(oData.results[count].AsnDate)
//				else
//					tempDate = "";
			
				tempOData = tempOData + "{\"AsnObjectId\":\"" + oData.results[count].AsnObjectId + "\"," + 
							"\"PoObjectId\":\""  + oData.results[count].PoObjectId + "\"," + 
							"\"AsnDate\":\"" + tempDate + "\"," + 
							"\"AsnStatTxt\":\"" + oData.results[count].AsnStatTxt + "\"},";
			}
		
			tempOData = tempOData.substring(0, tempOData.length - 1);
			tempOData = tempOData + "]}";
			console.log('tempOData:   ' + tempOData);

			var tempArray;
			if (tempOData.length > 0)
				tempArray = jQuery.parseJSON(tempOData);
		
//			tempASNJSONModel.setData({modelData: tempOData});
			tempASNJSONModel.setData(tempArray);
			self.getView().setModel(tempASNJSONModel, 'HubTEMPASNTableModel');
		}else
		{
			self.getView().setModel(asnJSONModel, 'HubTEMPASNTableModel');
		}
	})
}
