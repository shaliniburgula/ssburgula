var serviceAccess =
  {
    getProxyAddress   :   function_getProxyAddress(),

//    serviceName     :   "sap/opu/odata/sap/ZGW_RFX_HUB_SRV",
    getServiceName    :   function_getServiceName,
//    userName      :   "500056", //"Developer01",
//    password      :   "abcd1234", //"$3[Zyu9mg",

      userName : "512595",
      password : "welcome1",


    getBaseAddress    :   function_getBaseAddress,
    testAllServices   : function_testAllServices
  };

function function_getBaseAddress(serviceName, oDataFunctionName)
{
//  var baseAddress = window.location.protocol+"//" + function_getProxyAddress() + "/" + function_getServiceName() + "";
  var baseAddress = window.location.protocol+"//" + function_getProxyAddress() + "/" + function_getServiceName(serviceName, oDataFunctionName);
  return baseAddress;
}

function function_getProxyAddress()
{
//  return window.location.host;
//  var hostName = (window.location.host).trim();
  var hostName = (window.location.host);

  console.log('serviceAccess.js   hostName   ' + hostName + '    ' + hostName.charAt(0));

  if (hostName.charAt(0) == 'l')
    return "GRC10DCSWS.mydrreddys.com:8000";
  else
    return window.location.host;
}


function function_getServiceName(serviceName, oDataFunctionName)
{
//  var serviceName = Widgets.serviceName;    //"sap/opu/odata/sap";
//  var oDataFunctionName = Widgets.rfx.rfxServiceName; //"ZGW_RFX_HUB_SRV";
//  var oDataentityName = Widgets.rfx.rfxTableEntityName; //"RfxHubCountSet";

//  return serviceName + "/" + oDataFunctionName + "/" +  oDataentityName + "?$filter=DataType eq 'RFX' and DataRange eq 'M01'&$format=json";
  return serviceName + "/" + oDataFunctionName + "/";
}

function function_testAllServices()
{
//  console.log('Proxy Address:  ' + serviceAccess.getProxyAddress());
  console.log('Base Address:  ' + serviceAccess.getBaseAddress());

  return "done";
}
