sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Z_DRL_HUB/model/models",
	"Z_DRL_HUB/serviceAccess",
	"Z_DRL_HUB/WidgetID"
], function(UIComponent, Device, models,serviceAccess,Widgets) {
	"use strict";

	return UIComponent.extend("Z_DRL_HUB.Component", {

		metadata: {
		//	manifest: "json"
		//},
		
        version: "1.0",
        library: "drlhub",
        autoDestroy: false,
        initOnBeforeRender: true,
        includes: ["css/custom.css"],
        aggregations: {
            rootControl: {
                type: "sap.ui.core.Control",
                multiple: false,
                visibility: "hidden"
            }
        },
        config: {
//            resourceBundle: "i18n/i18n.properties"
        },
        viewPath: "Z_DRL_HUB.view"
    },
 //   eventbus: sap.ui.getCore().getEventBus(),

		    createContent: function() {
 
    	var m = new sap.ui.model.json.JSONModel("model/data.json");
        sap.ui.getCore().setModel(m, "DataModel");
        m.attachRequestCompleted(function() {
            sap.ui.getCore().getEventBus().publish("app", "dataLoaded");
        });
        
/* RFX OData Consumption Starts Here */    	
    	var rfxODataModel = new sap.ui.model.odata.ODataModel(serviceAccess.getBaseAddress(Widgets.serviceName, Widgets.rfx.rfxServiceName), true, serviceAccess.userName, serviceAccess.password);
    	sap.ui.getCore().setModel(rfxODataModel, "rfxODataModel");
/* RFX OData Consumption Starts Here */

/* PO OData Consumption Starts Here */
    	var poODataModel = new sap.ui.model.odata.ODataModel(serviceAccess.getBaseAddress(Widgets.serviceName, Widgets.po.poServiceName), true, serviceAccess.userName, serviceAccess.password);
    	sap.ui.getCore().setModel(poODataModel, "poODataModel");
/* PO OData Consumption Ends Here */    	
    	
/* ASN OData Consumption Starts Here */    	
    	var asnODataModel = new sap.ui.model.odata.ODataModel(serviceAccess.getBaseAddress(Widgets.serviceName, Widgets.asn.asnServiceName), true, serviceAccess.userName, serviceAccess.password);
    	sap.ui.getCore().setModel(asnODataModel, "asnODataModel");
/* ASN OData Consumption Ends Here */    	

/* Invoice OData Consumption Starts Here */
    	var invoiceODataModel = new sap.ui.model.odata.ODataModel(serviceAccess.getBaseAddress(Widgets.serviceName, Widgets.invoice.invoiceServiceName), true, serviceAccess.userName, serviceAccess.password);
    	sap.ui.getCore().setModel(invoiceODataModel, "invoiceODataModel");
/* Invoice OData Consumption Ends Here */    	

/* GRN OData Consumption Starts Here */
    	var grnODataModel = new sap.ui.model.odata.ODataModel(serviceAccess.getBaseAddress(Widgets.serviceName, Widgets.grn.grnServiceName), true, serviceAccess.userName, serviceAccess.password);
    	sap.ui.getCore().setModel(grnODataModel, "grnODataModel");
/* GRN OData Consumption Ends Here */    	

/* Header OData Consumption Starts Here */
    	var headerODataModel = new sap.ui.model.odata.ODataModel(serviceAccess.getBaseAddress(Widgets.serviceName, Widgets.header.headerServiceName), true, serviceAccess.userName, serviceAccess.password);
    	sap.ui.getCore().setModel(headerODataModel, "headerODataModel");
/* Header OData Consumption Ends Here */

    	return sap.ui.view({
            id: 'App',
            viewName: "Z_DRL_HUB.view.App",
            type: sap.ui.core.mvc.ViewType.JS,
            viewData: {
                component: this
            }
        });
    },
    createStartupParametersData: function(oComponentData) {
        var aParameters = [], sKey = null;
        if (oComponentData) {
            for (sKey in oComponentData) {
                aParameters[sKey] = oComponentData[sKey].toString();
            }
        }
        return aParameters;
    },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});

});