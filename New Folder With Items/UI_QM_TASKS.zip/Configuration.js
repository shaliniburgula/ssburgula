/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
sap.ca.scfld.md.ConfigurationBase.extend("i2d.qm.task.tracknconfirm.Configuration", {
	aServiceList: [{
		name: "QM_TASK_SRV",
		masterCollection: "QMTaskSet",
		taskActions: ["ConfirmTask", "ReassignTask"],
		SetCollection: ["QMUserSet", "QMSettingsSet", "QMTaskStatusSet"],
		QIAttachmentStream: "QMStreamSet",
		serviceUrl: "" + URI("/sap/opu/odata/sap/QM_TASK_SRV/"),
		isDefault: true,
		mockedDataSource: "model/metadata.xml"
	}],
	GlobalParams: {
		settingsName: "objSettings",
		eventListItemSelected: "ListItemSelected",
		HTTP_Method: {
			GET: "GET",
			POST: "POST",
			PUT: "PUT",
			DELETE: "DELETE",
			MERGE: "MERGE"
		},
		TaskModificationMode: {
			Reassign: 0,
			Complete: 1,
			AddNote: 2
		},
		ProcessingModeEnum: {
			Read: "Read",
			Batch: "ReadBatch",
			Change: "ChangeBatch"
		},
		InteropService: {
			name: "UI2/INTEROP",
			linkCheck: "ResolveLink?linkId='QualityNotification-displayFactSheet'",
			serviceUrl: URI("/sap/opu/odata/UI2/INTEROP/")
		},
		filterDialogDefaultFromDate: "1970-01-01T00:00:00.000Z",
		filterDialogDefaultToDate: "9999-12-31T00:00:00.000Z"
	},
	getServiceParams: function() {
		return this.oServiceParams
	},
	getServiceList: function() {
		return this.aServiceList
	},
	getMasterKeyAttributes: function() {
		return ["TaskNum", "NotificationID"]
	},
	getParams: function() {
		return this.GlobalParams
	},
	getAppIdentifier: function() {
		return "i2d.qm.task.tracknconfirm"
	},
});