/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function(){'use strict';jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.InteropServiceHelper");jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");i2d.qm.task.tracknconfirm.utils.InteropServiceHelper={isFactSheetExists:function(){if(location.hostname==="localhost"){return false}if(this._bLinkExists===undefined){var d=i2d.qm.task.tracknconfirm.utils.InteropServiceHelper.getServiceData();this._bLinkExists=(!$.isBlank(d))&&(d.length>0)}return this._bLinkExists},getServiceData:function(){var p=sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().InteropService.linkCheck;return i2d.qm.task.tracknconfirm.utils.Helper.getInteropServiceData(p)}}}());
