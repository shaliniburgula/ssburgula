/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.StatusHelper");
	jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
	i2d.qm.task.tracknconfirm.utils.StatusHelper = {
		constructor: function(v) {
			this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			this.STATUS_COLORS = "STATUS_COLORS";
			this.setArrayColors(this.getStatusSettings(v))
		},
		statusStateBool: function(v) {
			var e = true;
			if (v === "I0156") {
				e = false
			}
			return e
		},
		statusText: function(s) {
			var a = i2d.qm.task.tracknconfirm.utils.StatusHelper;
			a.constructor(this);
			if (a.getArrayColors()) {
				var r = $.grep(a.getArrayColors(), function(i) {
					return i.stateStatus === s
				});
				if (r.length > 0) {
					return r[0].stateText
				} else {
					switch (s) {
						case "I0154":
							return this.oBundle.getText("QT_STATUS_NEW");
						case "I0155":
							return this.oBundle.getText("QT_STATUS_IN_PROCESS");
						case "I0156":
							return this.oBundle.getText("QT_STATUS_COMPLETED");
						case "I0157":
							return this.oBundle.getText("QT_STATUS_SUCCESSFUL");
						default:
							return ""
					}
				}
			}
		},
		getStatusSettings: function(v) {
			var a = [{
				output: "stateText",
				source: "Text"
			}, {
				output: "stateColor",
				source: "Color"
			}, {
				output: "stateStatus",
				source: "Status"
			}];
			if (!this.getArrayColors()) {
				var b = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(2, a, v);
				var d = b.items && b.items.length > 0 && b.items;
				this.setArrayColors(d)
			}
			return this.getArrayColors()
		},
		getArrayColors: function() {
			return this.arStatusColors
		},
		setArrayColors: function(a) {
			this.arStatusColors = a
		},
	}
}());