/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

i2d.qm.task.tracknconfirm.utils.DateTimeConversions = {};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysAgo = function(sDate) {
	var formatterdaysAgo = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style : "daysAgo"
	}, null);
	if (sDate)
	{
		return formatterdaysAgo.format(sDate);
	}
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatMediumDate = function(sDate) {
	var formatterMedium = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style : "medium"
	}, null);
	if (sDate)
	{
		return formatterMedium.format(sDate);
	}
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatLongDate = function(sDate) {
	var formatterLong = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style : "long"
	}, null);
	if (sDate)
	{
		return formatterLong.format(sDate);
	}
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysNumber = function(sDate, sStatus) {
	if (sStatus === "I0156" || sStatus === "I0157")// completed or successful
	{
		return "";
	};

	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return "";
	}
	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = today.valueOf() - sDate.valueOf();
		daysDue = Math.floor(timePast / (24 * 60 * 60 * 1000));
	}
	var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
	
	if (daysDue === 0){
		return oBundle.getText("QT_TODAY");
	}else{
		return Math.abs(daysDue);		
	}

};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDue = function(sDate, sStatus) {

	if (sStatus === "I0156" || sStatus === "I0157")// completed or successful
	{
		return "";
	};

	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return "";
	}

	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = today.valueOf() - sDate.valueOf();
		daysDue = Math.floor(timePast / (24 * 60 * 60 * 1000));
	}

	var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

	switch (daysDue) {
	case 0:
		return "";//return oBundle.getText("QT_TODAY");
	case -1:
		return oBundle.getText("QT_DUE_IN_ONE");
	case 1:
		return oBundle.getText("QT_DAYS_OVERDUE_ONE");
	default:
		if (daysDue < 0) {
			return oBundle.getText("QT_DUE_IN");
		} else {
			return oBundle.getText("QT_DAYS_OVERDUE");
		}
	}

};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDueState = function(sDate) {
	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return sap.ui.core.ValueState.None;
	}

	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = today.valueOf() - sDate.valueOf();
		daysDue = Math.floor(timePast / (24 * 60 * 60 * 1000));
	}

	if (daysDue === 0) {
		return sap.ui.core.ValueState.Warning;

	} else if (daysDue < 0) {
		daysDue = Math.abs(daysDue);
		if (daysDue > 1)
		{
			return sap.ui.core.ValueState.Success;
		}
		else
		{
			return sap.ui.core.ValueState.Warning;
		}
	}

	return sap.ui.core.ValueState.Error;
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue = function(sDate) {

	var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return oBundle.getText("QT_GRP_WITHOUT");
	}

	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = sDate.valueOf() - today.valueOf();
		daysDue = Math.ceil(timePast / (24 * 60 * 60 * 1000));
	}

	if (daysDue < 0) {
		return oBundle.getText("QT_GRP_OVER_COM");
	} else if (daysDue >= 0 && daysDue <= 1) {
		return oBundle.getText("QT_GRP_APPROACH");
	} else if (daysDue >= 2) {
		return oBundle.getText("QT_GRP_FAR");
	}

};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentDate = function(sDate, sUser) {
	if (sDate) {
		// format is <d:CreatedAt>13092013154103</d:CreatedAt>
		var Day = sDate.substring(6, 8) * 1;
		var Month = sDate.substring(4, 6) * 1 - 1;// Month value 0-11
		var Year = sDate.substring(0, 4) * 1;
		var hh = sDate.substring(8, 10) * 1;
		var mm = sDate.substring(10, 12) * 1;
		var ss = sDate.substring(12, 14) * 1;

		var DateStr = new Date(Year, Month, Day, hh, mm, ss);

		DateStr = sap.ca.ui.model.format.DateFormat.getDateInstance({
			style : "medium"
		}, null).format(DateStr);
		var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

		return oBundle.getText("QT_ATT_DOC_DATE", [ DateStr, sUser ]);
	}
};


i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentName = function(sDocName) {
// in case the file is uploaded from the back end and has no name, then the other properties are also not displayed
// set text for missing name in order to solve the problem
	if(!sDocName){
		var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		sDocName = oBundle.getText("QT_ATT_DOC_NAME");
	}
	
	return sDocName;
};
