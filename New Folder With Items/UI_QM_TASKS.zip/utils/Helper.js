/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.Helper");
	i2d.qm.task.tracknconfirm.utils.Helper = {
		processChangeOperation: function(p, h, o, c) {
			this.result = {};
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			var m = c && c.getView().getModel();
			if (!m) {
				m = new sap.ui.model.odata.ODataModel("" + a.getServiceList()[0].serviceUrl)
			}
			var C = m.createBatchOperation(p, h, o);
			m.setUseBatch(true);
			this.ProcessingMode = a.getParams().ProcessingModeEnum.Change;
			this.arExpectedProperties = null;
			this.itemsPrefix = null;
			m.addBatchChangeOperations([C]);
			this.modelSubmitBatch(m);
			return this.result
		},
		getAttStream: function(n, d) {
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			var u = a.getServiceList()[0].serviceUrl + a.getServiceList()[0].QIAttachmentStream + "(Notification='" + n + "',DocumentNumber='" + d +
				"')/$value";
			location.href = u
		},
		convertCollection: function(a, b) {
			var c = [];
			$.each(a, function(d, e) {
				var o = {};
				if (b && $.isArray(b) && b.length > 0) {
					for (var i = 0; i < b.length; i++) {
						o[b[i].output] = e[b[i].source]
					}
				} else {
					o = e
				}
				c.push(o)
			});
			return c
		},
		getCollection: function(i, a, c, I, b) {
			if (!I) {
				I = false
			}
			if (b) {
				this.itemsPrefix = b
			} else {
				this.itemsPrefix = "items"
			}
			var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			this.result = [];
			var m = (c && c.getModel && c.getModel()) || c && c.getView().getModel();
			if (!m) {
				m = new sap.ui.model.odata.ODataModel("" + A.getServiceList()[0].serviceUrl)
			}
			this.arExpectedProperties = a;
			m.setUseBatch(false);
			this.ProcessingMode = A.getParams().ProcessingModeEnum.Read;
			this.modelReadOperation(m, A.getServiceList()[0].SetCollection[i]);
			if (I && this.result.items) {
				return this.result.items.length > 0 && this.result.items[0]
			} else {
				return this.result
			}
		},
		getInteropServiceData: function(p) {
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			this.result = [];
			var m = new sap.ui.model.odata.ODataModel("" + a.getParams().InteropService.serviceUrl, true);
			this.ProcessingMode = a.getParams().ProcessingModeEnum.Read;
			this.arExpectedProperties = null;
			this.itemsPrefix = null;
			m.setUseBatch(false);
			this.modelReadOperation(m, p);
			return this.result
		},
		resetFooterContentRightWidth: function(c) {
			var p = c.getView().getContent()[0];
			var r = jQuery.sap.byId(p.getFooter().getId() + "-BarRight");
			var R = r.outerWidth(true);
			if (R > 0) {
				c.iRBWidth = R
			}
			if (r.width() === 0 && c.iRBWidth) {
				jQuery.sap.log.info('Update footer contentRight Width=' + c.iRBWidth);
				r.width(c.iRBWidth)
			}
		},
		fConvert: function(d) {
			var D = d;
			if (typeof d === "string") {
				if (d.indexOf("Date") !== -1) {
					d = d.substring(d.indexOf("(") + 1, d.indexOf(")"));
					d = new Number(d)
				}
				D = new Date(d)
			} else if (typeof d !== "object" || d === null) {
				D = ""
			}
			return D
		},
		removeZeroLinkText: function(t) {
			if (!t || "" + t === "0") {
				return ""
			}
			return t
		},
		displaySuccessMessage: function(c, s) {
			sap.m.MessageToast.show(s);
			var b = c.getView().getBindingContext();
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
			sap.ui.getCore().getEventBus().publish(a, "RefreshDetail", {
				context: b
			})
		},
		convertToISODateTime: function(d) {
			if ($.isBlank(d)) {
				return
			}
			var a = new Date(d),
				t = a.getTimezoneOffset();
			a.setHours(a.getHours() - ~~(t / 60));
			a.setMinutes(a.getMinutes() - (t / 60 - ~~(t / 60)) * 60);
			return a.toISOString()
		},
		isValidDate: function(d) {
			if ($.isBlank(d) || isNaN(Date.parse(d))) {
				return false
			}
			return true
		},
		fnBatchSuccess: function(d, r, e) {
			var a, o;
			var P = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().ProcessingModeEnum;
			switch (this.ProcessingMode) {
				case P.Read:
					a = r.data.results;
					break;
				case P.Change:
					a = r.data.__batchResponses[0].__changeResponses && r.data.__batchResponses[0].__changeResponses.length > 0 && r.data.__batchResponses[
						0].__changeResponses[0].data;
					break
			}
			if (this.arExpectedProperties && a) {
				a = i2d.qm.task.tracknconfirm.utils.Helper.convertCollection(a, this.arExpectedProperties)
			}
			if (this.itemsPrefix) {
				o = {};
				o[this.itemsPrefix] = a;
				this.result = o
			} else {
				this.result = a
			}; if (e && e.length > 0) {
				var j = e[0].response.body;
				var n = $.parseJSON(j);
				this.result = {};
				this.result.error = n.error.message.value;
				jQuery.sap.log.error("Error occurs during batch processing: " + n.error.message.value);
				sap.ca.ui.message.showMessageBox({
					type: sap.ca.ui.message.Type.ERROR,
					message: n.error.message.value,
					details: n.error.message.value
				})
			}
		},
		fnBatchError: function(e) {
			this.result.error = e.message;
			jQuery.sap.log.error("Error occurs during batch processing: " + e.message);
			sap.ca.ui.message.showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: e.message,
				details: e.response.statusText
			})
		},
		modelSubmitBatch: function(m) {
			m.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false)
		},
		modelReadOperation: function(m, p) {
			m.read(p, null, null, false, $.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this))
		},
		setProcessingMode: function(v) {
			this.ProcessingMode = v
		},
		setBatchResult: function(v) {
			this.result = v
		},
		setConversionProperties: function(v) {
			this.arExpectedProperties = v
		},
		setResultPrefix: function(v) {
			this.itemsPrefix = v
		},
		getBatchResult: function() {
			return this.result
		},
		getProcessingMode: function() {
			return this.ProcessingMode
		},
	}
}());