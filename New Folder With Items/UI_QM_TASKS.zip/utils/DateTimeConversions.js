/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
i2d.qm.task.tracknconfirm.utils.DateTimeConversions = {};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysAgo = function(d) {
	var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style: "daysAgo"
	}, null);
	if (d) {
		return f.format(d)
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatMediumDate = function(d) {
	var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style: "medium"
	}, null);
	if (d) {
		return f.format(d)
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatLongDate = function(d) {
	var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style: "long"
	}, null);
	if (d) {
		return f.format(d)
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysNumber = function(d, s) {
	if (s === "I0156" || s === "I0157") {
		return ""
	};
	var a = 0,
		t, b = new Date();
	d = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(d);
	if (d === "") {
		return ""
	}
	if (d.getDate() !== b.getDate() || d.getMonth() !== b.getMonth() || d.getFullYear() !== b.getFullYear()) {
		t = b.valueOf() - d.valueOf();
		a = Math.floor(t / (24 * 60 * 60 * 1000))
	}
	var B = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
	if (a === 0) {
		return B.getText("QT_TODAY")
	} else {
		return Math.abs(a)
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDue = function(d, s) {
	if (s === "I0156" || s === "I0157") {
		return ""
	};
	var a = 0,
		t, b = new Date();
	d = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(d);
	if (d === "") {
		return ""
	}
	if (d.getDate() !== b.getDate() || d.getMonth() !== b.getMonth() || d.getFullYear() !== b.getFullYear()) {
		t = b.valueOf() - d.valueOf();
		a = Math.floor(t / (24 * 60 * 60 * 1000))
	}
	var B = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
	switch (a) {
		case 0:
			return "";
		case -1:
			return B.getText("QT_DUE_IN_ONE");
		case 1:
			return B.getText("QT_DAYS_OVERDUE_ONE");
		default:
			if (a < 0) {
				return B.getText("QT_DUE_IN")
			} else {
				return B.getText("QT_DAYS_OVERDUE")
			}
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDueState = function(d) {
	var a = 0,
		t, b = new Date();
	d = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(d);
	if (d === "") {
		return sap.ui.core.ValueState.None
	}
	if (d.getDate() !== b.getDate() || d.getMonth() !== b.getMonth() || d.getFullYear() !== b.getFullYear()) {
		t = b.valueOf() - d.valueOf();
		a = Math.floor(t / (24 * 60 * 60 * 1000))
	}
	if (a === 0) {
		return sap.ui.core.ValueState.Warning
	} else if (a < 0) {
		a = Math.abs(a);
		if (a > 1) {
			return sap.ui.core.ValueState.Success
		} else {
			return sap.ui.core.ValueState.Warning
		}
	}
	return sap.ui.core.ValueState.Error
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue = function(d) {
	var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
	var a = 0,
		t, c = new Date();
	d = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(d);
	if (d === "") {
		return b.getText("QT_GRP_WITHOUT")
	}
	if (d.getDate() !== c.getDate() || d.getMonth() !== c.getMonth() || d.getFullYear() !== c.getFullYear()) {
		t = d.valueOf() - c.valueOf();
		a = Math.ceil(t / (24 * 60 * 60 * 1000))
	}
	if (a < 0) {
		return b.getText("QT_GRP_OVER_COM")
	} else if (a >= 0 && a <= 1) {
		return b.getText("QT_GRP_APPROACH")
	} else if (a >= 2) {
		return b.getText("QT_GRP_FAR")
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentDate = function(d, u) {
	if (d) {
		var D = d.substring(6, 8) * 1;
		var M = d.substring(4, 6) * 1 - 1;
		var Y = d.substring(0, 4) * 1;
		var h = d.substring(8, 10) * 1;
		var m = d.substring(10, 12) * 1;
		var s = d.substring(12, 14) * 1;
		var a = new Date(Y, M, D, h, m, s);
		a = sap.ca.ui.model.format.DateFormat.getDateInstance({
			style: "medium"
		}, null).format(a);
		var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		return b.getText("QT_ATT_DOC_DATE", [a, u])
	}
};
i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentName = function(d) {
	if (!d) {
		var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		d = b.getText("QT_ATT_DOC_NAME")
	}
	return d
};