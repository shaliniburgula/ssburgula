/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.FragmentHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
i2d.qm.task.tracknconfirm.utils.FragmentHelper = function() {
	var c;
	var s = function(C, m) {
		if (!C) {
			return
		}
		var a = C.getModel("maxHits");
		if (a) {
			a.setData({
				maxHits: m
			})
		} else {
			a = new sap.ui.model.json.JSONModel({
				maxHits: m
			});
			C.setModel(a, "maxHits")
		}
	};
	var u = function(C, o) {
		if (!c) {
			return
		}
		c.removeAllContent();
		c.addContent(C);
		var a = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsDialogHeader", o);
		a.setModel(o.oApplicationFacade.getODataModel("i18n"), "i18n");
		c.setCustomHeader(a)
	};
	return {
		openFilterDialog: function(C) {
			if (!C) {
				return
			}
			if (!this.filterDialog) {
				this.filterDialog = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.ViewSettingsFilterDialog", C);
				this.filterDialog.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n");
				this.setFilterDialogModel();
				this.dateVBox = this.filterDialog.getFilterItems()[1].getCustomControl();
				this.dateVBox.addStyleClass("qt_dateFilterMargins");
				this.dateVBox.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
			}
			this.filterDialog.open()
		},
		setFilterDialogDateFilterCount: function(C) {
			if (!this.filterDialog) {
				return
			}
			this.filterDialog.getFilterItems()[1].setFilterCount(C);
			if (C === 0) {
				this.filterDialog.getFilterItems()[1].setSelected(false);
				return
			}
			this.filterDialog.getFilterItems()[1].setSelected(true)
		},
		resetFilterDialogDateFilter: function(p, P) {
			if (!this.filterDialog) {
				return
			}
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setDateValue();
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setValue(p);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].fireChange(true);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setDateValue();
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setValue(P);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].fireChange(true);
			if (!p && !P) {
				this.setFilterDialogDateFilterCount(0)
			} else {
				this.setFilterDialogDateFilterCount(1)
			}
		},
		setFilterDialogModel: function() {
			var S = i2d.qm.task.tracknconfirm.utils.StatusHelper;
			S.constructor();
			var a = S.getArrayColors();
			if (!$.isArray(a) || a.length < 1 || !this.filterDialog) {
				return
			}
			var m = new sap.ui.model.json.JSONModel({
				status1: null
			}, {
				status2: null
			}, {
				status3: null
			}, {
				status4: null
			});
			$.each(a, function(i, b) {
				switch (b.stateStatus) {
					case "I0154":
						m.getData().status1 = b.stateText;
						break;
					case "I0155":
						m.getData().status2 = b.stateText;
						break;
					case "I0156":
						m.getData().status3 = b.stateText;
						break
				}
			});
			this.filterDialog.getFilterItems()[0].setModel(m)
		},
		destroyFilterDialog: function() {
			if (!this.filterDialog) {
				return
			}
			this.filterDialog.destroy();
			this.filterDialog = null
		},
		openSortDialog: function(C) {
			if (!this.sortDialog) {
				this.sortDialog = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.ViewSettingsSortDialog", C);
				this.sortDialog.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
			}
			this.sortDialog.open()
		},
		destroySortDialog: function() {
			if (!this.sortDialog) {
				return
			}
			this.sortDialog.destroy();
			this.sortDialog = null
		},
		openCustSetDialog: function(C, m) {
			if (!c) {
				c = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsDialog", C);
				c.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
			}
			c.removeAllContent();
			if (!this.customSettingsList) {
				this.customSettingsList = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsList", C);
				this.customSettingsList.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
			}
			s(this.customSettingsList.getItems()[0], m);
			c.addContent(this.customSettingsList);
			c.destroyCustomHeader();
			if (c.isOpen() !== true) {
				c.open()
			}
		},
		loadCustSetIssuesNumber: function(C, m) {
			if (!c) {
				return
			}
			if (!this.customSettingsIssueNumber) {
				this.customSettingsIssueNumber = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsNumberOfIssues", C)
			}
			s(this.customSettingsIssueNumber, m);
			u(this.customSettingsIssueNumber, C)
		},
		closeCustSetDialog: function() {
			if (c.isOpen() !== false) {
				c.close()
			}
		},
		getCustSetMaxHitsTitle: function(m) {
			var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			if (m === "1") {
				return b.getText("QT_MAX_NUMBER_ONE")
			} else {
				return b.getText("QT_MAX_NUMBER", m)
			}
		},
		destroyCustSetDialog: function() {
			if (c) {
				c.destroyCustomHeader();
				c.destroy();
				c = null;
				this.customSettingsList.destroy();
				this.customSettingsList = null
			}
			if (this.customSettingsIssueNumber) {
				this.customSettingsIssueNumber.destroy();
				this.customSettingsIssueNumber = null
			}
		},
	}
}();