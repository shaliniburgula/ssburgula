/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.Formatter");i2d.qm.task.tracknconfirm.utils.Formatter={};
i2d.qm.task.tracknconfirm.utils.Formatter.formatTaskLongText=function(t){var d="----------";var r="";if(t&&t.indexOf(d)>=0){var D=d+d+d+d;var R=t.split(D);for(var i=0;i<R.length;i++){if(R[i].trim().length>0){r=r+R[i].trim()+"; "}}}else{r=t}return r};
