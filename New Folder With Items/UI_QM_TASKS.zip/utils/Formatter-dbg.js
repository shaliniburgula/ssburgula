/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.Formatter");


i2d.qm.task.tracknconfirm.utils.Formatter = {};

i2d.qm.task.tracknconfirm.utils.Formatter.formatTaskLongText = function (sText) {
	
	var sDash = "----------";
	var sResult = "";
	
	if (sText && sText.indexOf(sDash) >= 0) {
		
		var sDashes = sDash + sDash + sDash + sDash;
		var aResult = sText.split (sDashes);
		for (var i = 0; i < aResult.length; i++) {
			
			if (aResult[i].trim().length > 0) {
				sResult = sResult + aResult[i].trim() + "; ";
			}
		}
	} else {
		
		sResult = sText;
	}
	
	return sResult;
};