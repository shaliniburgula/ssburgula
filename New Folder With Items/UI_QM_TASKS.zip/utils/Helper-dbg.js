/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.Helper");

	i2d.qm.task.tracknconfirm.utils.Helper = {
		
			processChangeOperation : function(sPath, httpMethod, objOData, oController) {

				this.result = {};
				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

				var oModel = oController && oController.getView().getModel();
				if (!oModel) {
					// create model
					oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getServiceList()[0].serviceUrl);
				}
				var oChangeBatch = oModel.createBatchOperation(sPath, httpMethod, objOData);
				
				oModel.setUseBatch(true);
				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Change;
				this.arExpectedProperties = null;
				this.itemsPrefix = null;
				
				oModel.addBatchChangeOperations([ oChangeBatch ]);
				
				this.modelSubmitBatch(oModel);

				return this.result;
			},
			
			getAttStream : function(sNotificationID, sDocNum) {

				// Complete/FInish QT using jQuery
				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
				var sUrl = oAppConfig.getServiceList()[0].serviceUrl + oAppConfig.getServiceList()[0].QIAttachmentStream + "(Notification='" + sNotificationID + "',DocumentNumber='" + sDocNum + "')/$value";
				location.href = sUrl;
			},
			
			convertCollection : function(arODataProperties, arExpected) {
				var arResult = [];
				$.each(arODataProperties, function(index, arODataProperty) {
					var obj = {};
					if (arExpected && $.isArray(arExpected) && arExpected.length > 0) {
						for ( var i = 0; i < arExpected.length; i++) {
							obj[arExpected[i].output] = arODataProperty[arExpected[i].source];
						}
					} else {
						obj = arODataProperty;
					}
					arResult.push(obj);
				});
				return arResult;
			},
			
			getCollection : function(index, arExpectedProperties, oController, bIsSingleResult, itemsPrefix ) {
				if (!bIsSingleResult) {
					bIsSingleResult = false;
				}
				if (itemsPrefix) {
					this.itemsPrefix = itemsPrefix;
				} else {
					this.itemsPrefix = "items";
				}
				
				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
				this.result = [];
				// Ocontroller is a view in fact when is called from formatter
				var oModel = (oController && oController.getModel && oController.getModel()) || oController && oController.getView().getModel();
				if (!oModel) {
					// create model
					oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getServiceList()[0].serviceUrl);
				}
				this.arExpectedProperties = arExpectedProperties;
				oModel.setUseBatch(false);
				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Read;
				this.modelReadOperation(oModel, oAppConfig.getServiceList()[0].SetCollection[index]);
				if (bIsSingleResult && this.result.items) {
					return this.result.items.length >0 && this.result.items[0];
				} else {
					return this.result;
				}
				
			},
			
			getInteropServiceData : function(sPath) {
				

				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
				this.result = [];
				
				// create model	
				var oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getParams().InteropService.serviceUrl, true);

				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Read;
				this.arExpectedProperties = null;
				this.itemsPrefix = null;
				
				oModel.setUseBatch(false);		
				this.modelReadOperation(oModel, sPath);
				return this.result;
			},
			
			/**
			 * FIXME: BUG in sap.m.Bar control. The contentRight has a width a 0.
			 */
			resetFooterContentRightWidth : function(oController) {
				var oPage = oController.getView().getContent()[0];
				var rightBar = jQuery.sap.byId(oPage.getFooter().getId() + "-BarRight");
				var iRBWidth = rightBar.outerWidth(true);
				if (iRBWidth > 0) {
					oController.iRBWidth = iRBWidth;
				}
				if (rightBar.width() === 0 && oController.iRBWidth) {
					jQuery.sap.log.info('Update footer contentRight Width=' + oController.iRBWidth);
					rightBar.width(oController.iRBWidth);
				}
			},
			
			fConvert : function(sDate) {
				var oDate = sDate;
				if (typeof sDate === "string") {
					// Handle the format /Date(miliseconds)/
					if (sDate.indexOf("Date") !== -1) {
						sDate = sDate.substring(sDate.indexOf("(") + 1, sDate.indexOf(")"));
						sDate = new Number(sDate);
					}
					oDate = new Date(sDate);
				} else if (typeof sDate !== "object" || sDate === null) {
					oDate = "";
				}
				return oDate;
			},
			
			removeZeroLinkText : function(sText) {

				if (!sText || "" + sText === "0") {
					return "";
				}

				return sText;
			},
			
			displaySuccessMessage : function(oController, sSuccessMessage) {

				sap.m.MessageToast.show(sSuccessMessage);
				var oBindingContext = oController.getView().getBindingContext();
				var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
				sap.ui.getCore().getEventBus().publish(appId, "RefreshDetail", {
					context : oBindingContext
				});

			},
			
			/**
			 * Formats the provided oDate in UTC, regardless of the user settings. The OData backend service
			 * expects oDates in UTC format and also ignores any user customizations in SU01 
			 * @param ooDate the oDate to be formatted
			 */	
			convertToISODateTime : function(sDate){
				
				if($.isBlank(sDate)){
					return;
				}
				
				var date = new Date(sDate),
					timeZoneOffset = date.getTimezoneOffset();
				
				date.setHours(date.getHours() - ~~(timeZoneOffset / 60));
				date.setMinutes(date.getMinutes() - (timeZoneOffset / 60 - ~~(timeZoneOffset / 60)) * 60);
				
				return date.toISOString();
			},
			
			isValidDate : function(sDate){
				if ($.isBlank(sDate) || isNaN(Date.parse(sDate))){
					return false;
				}
					
				return true;
			},
			
			fnBatchSuccess : function(oData, oResponse, oErrResponse) {
				// handle the response
				var data, obj;
				var ProcessingModeEnum = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().ProcessingModeEnum;

				switch (this.ProcessingMode) {
					case ProcessingModeEnum.Read:
						data = oResponse.data.results;
						break;
					case ProcessingModeEnum.Change:
						data = oResponse.data.__batchResponses[0].__changeResponses && oResponse.data.__batchResponses[0].__changeResponses.length > 0 && oResponse.data.__batchResponses[0].__changeResponses[0].data;
						break;
				}		
				
				// data conversion if needed
				if (this.arExpectedProperties && data) {
					data = i2d.qm.task.tracknconfirm.utils.Helper.convertCollection(data, this.arExpectedProperties);
				}
				// set prefix if needed
				if (this.itemsPrefix ) {
					obj = {};
					obj[this.itemsPrefix] = data;
					this.result = obj;
				} else {
					this.result = data;
				};


				if (oErrResponse && oErrResponse.length > 0) {
					var oJson = oErrResponse[0].response.body;
					var oNewJ = $.parseJSON(oJson);
					this.result = {};
					this.result.error = oNewJ.error.message.value;
					jQuery.sap.log.error("Error occurs during batch processing: " + oNewJ.error.message.value);

					sap.ca.ui.message.showMessageBox({
						type : sap.ca.ui.message.Type.ERROR,
						message : oNewJ.error.message.value,
						details : oNewJ.error.message.value
					});
				};
			},

			fnBatchError : function(oError) {
				this.result.error = oError.message;
				jQuery.sap.log.error("Error occurs during batch processing: " + oError.message);
				sap.ca.ui.message.showMessageBox({
					type : sap.ca.ui.message.Type.ERROR,
					message : oError.message,
					details : oError.response.statusText
				});

			},
			
			modelSubmitBatch : function(oModel) {
				oModel.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false);
			},
			modelReadOperation : function(oModel, sPath) {
				oModel.read(sPath, null, null, false, $.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this));	
			},
			
			// setters needed by unit tests
			setProcessingMode : function(value){
				this.ProcessingMode = value;
			},
			setBatchResult : function(value){
				this.result = value;
			},
			setConversionProperties : function(value){
				this.arExpectedProperties = value;
			},
			setResultPrefix : function(value){
				this.itemsPrefix = value;
			},
			// getters
			getBatchResult : function(){
				return this.result;
			},
			getProcessingMode : function(){
				return this.ProcessingMode;
			},
			
			// end setters/getters

		
	};
}());	
