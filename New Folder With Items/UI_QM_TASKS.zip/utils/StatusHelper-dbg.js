/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.StatusHelper");
	jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");

	i2d.qm.task.tracknconfirm.utils.StatusHelper = {

		constructor : function(oView) {
			this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			this.STATUS_COLORS = "STATUS_COLORS";
			this.setArrayColors(this.getStatusSettings(oView));
		},

		statusStateBool : function(value) {
			var enableButton = true;

			if (value === "I0156") {
				enableButton = false;
			}
			return enableButton;
		},

		statusText : function(status) {
			var self = i2d.qm.task.tracknconfirm.utils.StatusHelper;
			// this = oView 
			self.constructor(this);
			
			if (self.getArrayColors()) {
				var result = $.grep(self.getArrayColors(), function(item) {
					return item.stateStatus === status;
	
				});
				if (result.length > 0){
					return result[0].stateText;
				} else {
					switch (status) {
					case "I0154":
						return this.oBundle.getText("QT_STATUS_NEW");
					case "I0155":
						return this.oBundle.getText("QT_STATUS_IN_PROCESS");
					case "I0156":
						return this.oBundle.getText("QT_STATUS_COMPLETED");
					case "I0157":
						return this.oBundle.getText("QT_STATUS_SUCCESSFUL");
					default:
						return "";
					}
				}
			}
		},

		getStatusSettings : function(oView) {
			var arStatusProperties = [
			   {output:"stateText", source:"Text"},
			   {output:"stateColor", source:"Color"},
			   {output:"stateStatus", source:"Status"}
			 ];	

			if (!this.getArrayColors()) {
				var batchResult = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(2, arStatusProperties, oView);
				var data = batchResult.items && batchResult.items.length >0 && batchResult.items;
				this.setArrayColors(data);
			}

			return this.getArrayColors();
		},

		getArrayColors : function() {
			return this.arStatusColors;
		},

		setArrayColors : function(arColors) {
			this.arStatusColors = arColors;
		},

	};
}());
