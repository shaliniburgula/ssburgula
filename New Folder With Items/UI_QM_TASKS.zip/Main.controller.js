/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("i2d.qm.task.tracknconfirm.Main", {
	onInit: function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Formatter");
		Storage.prototype.setObj = function(k, o) {
			try {
				this.setItem(k, JSON.stringify(o));
				return true
			} catch (e) {
				return false
			}
		};
		Storage.prototype.getObj = function(k) {
			return JSON.parse(this.getItem(k))
		};
		(function($) {
			$.isBlank = function(o) {
				return (!o || (typeof(o) == "string" && $.trim(o) === "") || ($.isPlainObject(o) && $.isEmptyObject(o)) || ($.isArray(o) && o.length ==
					0))
			}
		})(jQuery);
		sap.ca.scfld.md.Startup.init('i2d.qm.task.tracknconfirm', this)
	},
});