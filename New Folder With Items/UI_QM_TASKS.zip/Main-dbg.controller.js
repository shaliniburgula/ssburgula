/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */



sap.ui.controller("i2d.qm.task.tracknconfirm.Main", {

	onInit : function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Formatter");
		
		// extend local Storage object to support objects and array handling
		Storage.prototype.setObj = function(key, obj) { // EXC_JSHINT_003
			//In private browsing mode Safari and iOS Safari don't support setting localStorage.
			try {
				this.setItem(key, JSON.stringify(obj));
				return true;
			} catch (error) {
				return false;
			}	
		};
		Storage.prototype.getObj = function(key) { // EXC_JSHINT_003
		    return JSON.parse(this.getItem(key));
		};
		
		//extend jQuery object with isBlank function
		(function($){
			  $.isBlank = function(obj){
			    return(!obj || (typeof(obj) == "string" && $.trim(obj) === "") ||
			    		($.isPlainObject(obj) && $.isEmptyObject(obj)) ||
			    		($.isArray(obj) && obj.length == 0) 
			    	   );
			  };
			})(jQuery);
		
		sap.ca.scfld.md.Startup.init('i2d.qm.task.tracknconfirm', this);				
	},	
	
});