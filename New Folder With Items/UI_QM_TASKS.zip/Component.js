/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.Component");
jQuery.sap.require("i2d.qm.task.tracknconfirm.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
sap.ca.scfld.md.ComponentBase.extend("i2d.qm.task.tracknconfirm.Component", {
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name": "My Quality Tasks",
		"version": "1.0.0",
		"library": "i2d.qm.task.tracknconfirm",
		"includes": ["css/qt_style.css"],
		"dependencies": {
			"libs": ["sap.m", "sap.me"],
			"components": []
		},
		"config": {
			"resourceBundle": "i18n/i18n.properties",
			"titleResource": "",
			"icon": "sap-icon://Fiori2/F0317",
			"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/F0317_My_Quality_Tasks.ico",
			"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/57_iPhone_Desktop_Launch.png",
			"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/114_iPhone-Retina_Web_Clip.png",
			"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/72_iPad_Desktop_Launch.png",
			"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/144_iPad_Retina_Web_Clip.png",
			"startupImage320x460": "./resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png",
			"startupImage640x920": "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png",
			"startupImage640x1096": "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png",
			"startupImage768x1004": "./resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png",
			"startupImage748x1024": "./resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png",
			"startupImage1536x2008": "./resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png",
			"startupImage1496x2048": "./resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png"
		},
		viewPath: "i2d.qm.task.tracknconfirm.view",
		masterPageRoutes: {
			"master": {
				pattern: "",
				"view": "S2",
				"viewId": "TaskList"
			}
		},
		detailPageRoutes: {
			"detail": {
				pattern: "detail/{contextPath}",
				"view": "S3",
				"viewId": "TaskListDetail"
			}
		},
	}),
	createContent: function() {
		var v = {
			component: this
		};
		return sap.ui.view({
			viewName: "i2d.qm.task.tracknconfirm.Main",
			type: sap.ui.core.mvc.ViewType.XML,
			viewData: v
		})
	}
});