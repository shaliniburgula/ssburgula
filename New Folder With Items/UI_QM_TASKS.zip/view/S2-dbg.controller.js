/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.FragmentHelper");
jQuery.sap.require("sap.m.DatePicker");
jQuery.sap.require("sap.ca.scfld.md.app.MasterHeaderFooterHelper");

sap.ca.scfld.md.controller.ScfldMasterController.extend("i2d.qm.task.tracknconfirm.view.S2", {
	
	// TODO Reduce the size of the controler
	/**
	 * @override
	 * 
	 * Called by the UI5 runtime to init this controller
	 * 
	 */

	onInit : function() {
		// execute the onInit for the base class BaseMasterController
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		// Settings
		this.oMasterModel = new sap.ui.model.json.JSONModel({
			selectedFilter : "All",
			selectedSorter : "DueDate",
			toogleSubmit : false
		});
		this.getView().setModel(this.oMasterModel, "masterModel");
		
		// Retrieve the application bundle
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oGroupSorter;
		this.oFiltersDialog = null;
		this.oSettingsDialog = null;
		this.SETTINGS_NAME = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName;
		// get settings and store them locally
		this.objSettings = null;		
		this.getSettings(this.SETTINGS_NAME);
		//CSS Fix -remove leading zeros coming from oData
		if (this.objSettings.maxHits){
			this.objSettings.maxHits = parseInt(this.objSettings.maxHits, 10);
			if (isNaN(this.objSettings.maxHits)){
				jQuery.sap.log.error("Error with data, please check consistency of record. Default 30 issues displayed.");
				this.objSettings.maxHits = '30';
			}
		} //end of fix
		this.maxHits = this.objSettings.maxHits;
		this.setMaxHitsToList();
		this._showLoadingText(true);
		// Set the default filter-out completed tasks
		this.aTableFilters = [];
		var aFilterCompleted = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.NE, "I0156", "");
		this.aTableFilters = this.aTableFilters.concat(aFilterCompleted);

		var bus = sap.ui.getCore().getEventBus();
		var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
		bus.subscribe(appId, "RefreshDetail", this.handleRefresh, this);

		this.getList().attachUpdateFinished(this.handleUpdateFinished, this);	
		this.getList().attachSelectionChange(this.handleSelectionChange, this);
		
		this.oList = this.getList();
		this.oTemplate = this.oList.getItems()[0].clone();
		this.oList.bindItems("/QMTaskSet", this.oTemplate, null, this.aTableFilters);
		
		this.aFilterBy = [];
		this.dateFromUTC;
		this.dateToUTC;
		this.DateFromUTCValue;
		this.DateToUTCValue;
		this.previousDateFromUTC;
		this.previousDateToUTC;
		this.closeCustSetDialog = function(){
			this.changedMaxHits = undefined;
			i2d.qm.task.tracknconfirm.utils.FragmentHelper.closeCustSetDialog();
		};
		
		this.oSorter;

	},
	
	navToEmptyView : function(){
		// work around until release 1.16.6, which will contains fix for this bug
		this.showEmptyView("DETAIL_TITLE", "NO_ITEMS_AVAILABLE"); 
	}, 
	
	/**
	 * Display "Loading..." when the list is loading after search, filter,
	 * sort ... and display usual "No data" after
	 * @param bLoading
	 */
	_showLoadingText:function (bLoading) {
		if (bLoading) {
			this.getList().setNoDataText(this.resourceBundle.getText("QT_LOADING_TEXT"));
		} else {
			this.getList().setNoDataText(this.resourceBundle.getText("QT_NO_DATA_AVAILABLE"));
		}
	},
	
	getSettings : function(SETTINGS_NAME) {
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
	
		// try to get it from local Storage
	  this.objSettings = localStorage.getObj(SETTINGS_NAME);
		if (this.objSettings === null) {
			// read it from customizing
			var data = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(1, [], this, true);
			if (data) {
				this.objSettings = { maxHits : data.MaxHits };
				localStorage.setObj(SETTINGS_NAME, this.objSettings);
			}
			
		    // no connection to the service, use defaults
		    if (this.objSettings === null) {				
	    		this.objSettings = { maxHits : 30 };
			// store the object into local Storage for future usage
			localStorage.setObj(SETTINGS_NAME, this.objSettings);
		    }
		}
	},

	handleUpdateFinished : function(oControlEvent) {

		if (!jQuery.device.is.phone && (oControlEvent.getParameters().reason === "Filter"  || oControlEvent.getParameters().reason === "Change" || 
				oControlEvent.getParameters().reason === "Refresh" || oControlEvent.getParameters().reason === "Binding")){

			//this._selectDetail();

			if (this.oRouter._oRouter._prevMatchedRequest === "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {
				this.oList.removeSelections();
			}
			else if(this.oList.getSelectedItem()){
				var oBindingContext = this.oList.getSelectedItem().getBindingContext();
				this.handleSelectionChange(oControlEvent, oBindingContext);
			}
			if (this.getList().getItems().length == "0" ){
				this._showLoadingText(false);
			}else {
				this._showLoadingText(true);
			}
		}
	},
	
	handleSelectionChange : function(oControlEvent, oBindingContext) {
		if (!jQuery.device.is.phone){
			if(!oBindingContext){
				oBindingContext = oControlEvent.getParameter("listItem").getBindingContext();
			}
			var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
			sap.ui.getCore().getEventBus().publish(appId, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, {
				context : oBindingContext
			});
		}
	},

	/**
	 * Called by the UI5 runtime to cleanup this controller
	 */

	onExit : function() {
		// destroy dialogs
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroySortDialog();
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroyFilterDialog();
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroyCustSetDialog();
		
		var oListFooter = sap.ui.getCore().byId( this.getView().sId + "--footer");
		if(oListFooter && oListFooter.destroy) {
		  oListFooter.destroy();
		}
	},

	handleRefresh : function() {
		this.setMaxHitsToList();
		this.getList().removeSelections();
		this.getList().getBinding("items")._refresh();
	},
	
	setMaxHitsToList : function() {
		var oModel = this.getList().getModel();
		oModel.setCountSupported(false);
		oModel.setSizeLimit(this.objSettings.maxHits);
	},

	getHeaderFooterOptions : function() {

		return {
			sI18NMasterTitle : "MASTER_TITLE",

			buttonList : [],
			oFilterOptions : {
				onFilterPressed : $.proxy(this.onFilter, this)
			},
			oSortOptions : {
				onSortPressed : $.proxy(this.onSort, this)
			},
			oGroupOptions : {

				aGroupItems : [ {
					text : this.resourceBundle.getText("QT_CLEAR"),
					key : "None"
				}, {
					text : this.resourceBundle.getText("QT_DV_DUE_DATE"),
					key : "DueDate"
				}, {
					text : this.resourceBundle.getText("QT_TASK_CODE_TEXT"),
					key : "TaskCodeText"
				}, {
					text : this.resourceBundle.getText("QT_STATUS_TEXT"),
					key : "Status"
				} ],

				onGroupSelected : jQuery.proxy( function(sKey) {
					this.onGroup(sKey);
					jQuery.sap.log.info(sKey + " has been selected");

				}, this ),

			},
			aAdditionalSettingButtons : [ {
				sId : "Settings",
				sI18nBtnTxt : "QT_BUTTON_SETTINGS",
				sIcon : "sap-icon://action-settings",
				onBtnPressed : jQuery.proxy( function(oEvent) {
					this.onSettingsPressed();
				}, this )

			} ],

		};
	},

	/**
	 * @override
	 * 
	 * @param oItem
	 * @param sFilterPattern
	 * @returns {*}
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {
		if (oItem.isSelectable()) {
			if (sFilterPattern.substring(0, 1) === "#") {
				var sTail = sFilterPattern.substr(1);
				var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
				return sDescr.indexOf(sTail) === 0;
			} else {
				return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem, sFilterPattern);
			}
		}

	},

	/**
	 * @override
	 * 
	 * determines whether search is triggered with each change of the search
	 * field content (or only when the user explicitly starts the search).
	 * 
	 */

	isLiveSearch : function() {
		// CSS: 0000124432 2014 - Reset List's noDataText to 'No Quality Tasks Available' before a search
		this.getList().setNoDataText(this.resourceBundle.getText("QT_NO_DATA_AVAILABLE"));
		return false;
	},

	setInfoLabel : function(resourceId, sText, bInfoEnabled, sFilteredBy) {
		if (bInfoEnabled === null)
			bInfoEnabled = true;

		this.oMasterModel.setProperty('/toogleSubmit', bInfoEnabled);
		if (bInfoEnabled === false)
			return;

		var oLabelToolbar = this.getView().byId("labelTB");
		var toReplace = "";
		if (sText)
			toReplace = this.resourceBundle.getText(sText);
		else
			toReplace = sFilteredBy;
		var sText = this.resourceBundle.getText(resourceId, [ toReplace ]);
		oLabelToolbar.setText(sText);
		oLabelToolbar.setTooltip(sText);
	},	

	onGroup : function(sKey) {

		switch (sKey) {
		case "None":

			// Button None - Refresh to No Grouping
			// In case the list is already sorted we have to retrieve
			// the data again and reset sorting title
			if (this.oList.getBinding("items").isGrouped()) {
				this.oList.bindAggregation("items", {
					path : "/QMTaskSet",
					template : this.oTemplate,
					sorter: this.oSorter,
					filters : this.aTableFilters

				});

				this.registerMasterListBind(this.oList);
			}

			break;
		case "DueDate":
			var oDateSorter = new sap.ui.model.Sorter("DueDate", false, function(oContext) {
				var skey;

				skey = oContext.getProperty("DueDate");
				return {
					key : i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue(skey),
					text : i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue(skey)
				};

			});
			this.oGroupSorter = oDateSorter;
			this.oList.bindAggregation("items", {
				path : "/QMTaskSet",
				template : this.oTemplate,
				sorter : oDateSorter,
				filters : this.aTableFilters

			});

			this.registerMasterListBind(this.oList);

			break;

		case "TaskCodeText":
			var oTaskTypeSorter = new sap.ui.model.Sorter("TaskCodeText", false, true);
			this.oGroupSorter = oTaskTypeSorter;

			this.oList.bindAggregation("items", {
				path : "/QMTaskSet",
				template : this.oTemplate,
				sorter : oTaskTypeSorter,
				filters : this.aTableFilters

			});

			this.registerMasterListBind(this.oList);

			break;
		case "Status":
			var oStatusSorter = new sap.ui.model.Sorter("Status", false, function(oContext) {
				var sKey = oContext.getProperty("StatusText");
				return {
					key : sKey, // group
					text : "Task Status: " + sKey
				};
			});

			this.oGroupSorter = oStatusSorter;

			this.oList.bindAggregation("items", {
				path : "/QMTaskSet",
				template : this.oTemplate,
				sorter : oStatusSorter,
				filters : this.aTableFilters

			});

			this.registerMasterListBind(this.oList);

			break;
		}

	},

	setFilterInfoLabel : function(arFilterBy) {

		if (!$.isArray(arFilterBy) || arFilterBy.length < 1 ){
			this.setInfoLabel('', '', false, '');
			return;
		}
		
		var infoLabelText 	= "", 
			dueDate 		= this.resourceBundle.getText("QT_DV_DUE_DATE"),
			status 			= this.resourceBundle.getText("QT_STATUS_TEXT");
		
		$.each(arFilterBy, function(index, filterBy) {

			if (i2d.qm.task.tracknconfirm.utils.Helper.isValidDate(filterBy.oValue1)){
				
				if (filterBy.oValue1 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate && 
						filterBy.oValue2 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate){
					return false;
				}
				
				filterBy.oValue1 = filterBy.oValue1.substring(0, 10);
				filterBy.oValue2 = filterBy.oValue2.substring(0, 10);
				infoLabelText += dueDate + ": " + filterBy.oValue1 + ", " + filterBy.oValue2;
				
			}else if(filterBy.oValue1){
				if (infoLabelText.indexOf(status) === -1){
					infoLabelText += status + ": " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(filterBy.oValue1);
				}else {
					infoLabelText += ", " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(filterBy.oValue1);
				}
			}
			
		});
		
		infoLabelText += ";";
		
		this.setInfoLabel("QT_FILTERED_BY", null, true, infoLabelText);
	},

	onFilter : function(event){
		this.aFilterBy = [];
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openFilterDialog(this);
	},
	
	navBack : function() {
		window.history.back();
	},

	onAfterRendering : function() {
		i2d.qm.task.tracknconfirm.utils.Helper.resetFooterContentRightWidth(this);
	},
	
	onConfirmFilterDialog : function(oEvent){
		this._showLoadingText(true);
		var parameters 	= oEvent.getParameters();
		this.aTableFilters =[];
		
		if (this.invalidDateTo || this.invalidDateFrom) {
			
			this.setInfoLabel("QT_INVALID_DATES_ERROR", null, true, null);
			this._showLoadingText(false);
			return;
		}
		
		// check if "To Date" entered in filter is equal to or greater than "From Date"
		if ((new Date(this.dateToUTC)).getTime() < (new Date(this.dateFromUTC).getTime())) {
		 		
				this.setInfoLabel("QT_TO_DATE_AFTER_FROM_DATE_ERROR", null, true, null);
		 		this._showLoadingText(false);
		 		return;
		}

		
		$.each(parameters.filterItems, $.proxy(function(index, filterItem){
			if(filterItem.sId === "StatusNew" || filterItem.sId === "StatusInProcess" || filterItem.sId === "StatusCompleted" || filterItem.sId === "StatusPostponed"){
				this.aTableFilters.push(filterItem.getCustomData()[0].getValue().filters);
			}
		}, this));

		if (this.shouldCreateDateFilterObject()){
			this.aTableFilters.push(new sap.ui.model.Filter("DueDate", sap.ui.model.FilterOperator.BT, this.dateFromUTC, this.dateToUTC));
		}
		
		//Clear default values of dates if needed
		if (this.dateFromUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate){ 
			this.dateFromUTC = null;
		}
		
		if (this.dateToUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate){ 
			this.dateToUTC = null;
		}

		this.getList().getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);
		this.setFilterInfoLabel(this.aTableFilters);
		
		this.previousDateFromUTC = this.DateFromUTCValue;
		this.previousDateToUTC = this.DateToUTCValue;
	},
	
	onCancelFilterDialog : function(oEvent){
		//Because the Date filter is constructed via custom controls, the date pickers and the filter counter are manually reset. Previous values are restored
		this.DateFromUTCValue = this.previousDateFromUTC;
		this.DateToUTCValue = this.previousDateToUTC;
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.resetFilterDialogDateFilter(this.previousDateFromUTC, this.previousDateToUTC);
	},
	
	onChangeDateFrom : function(oEvent){
		//Preserve previous value for the case of canceling changes
		this.DateFromUTCValue = oEvent.getSource().mProperties.value;
		this.dateFromUTC = i2d.qm.task.tracknconfirm.utils.Helper.convertToISODateTime(oEvent.getSource().mProperties.dateValue);
		this.invalidDateFrom = oEvent.mParameters.invalidValue && !($.isBlank(oEvent.mParameters.newValue));
		this.setDateFilterCount();
	},
	
	onChangeDateTo : function(oEvent){
		//Preserve previous value for the case of canceling changes
		this.DateToUTCValue = oEvent.getSource().mProperties.value;
		this.dateToUTC = i2d.qm.task.tracknconfirm.utils.Helper.convertToISODateTime(oEvent.getSource().mProperties.dateValue);
		this.invalidDateTo = oEvent.mParameters.invalidValue && !($.isBlank(oEvent.mParameters.newValue));
		this.setDateFilterCount();
	},
	
	onResetFilterDialog : function(oEvent){
		//Because the Date filter is constructed via custom controls, the date pickers and the filter counter are manually reset
		this.DateFromUTCValue = null;
		this.DateToUTCValue = null;
		this.dateFromUTC = null;
		this.dateToUTC = null;
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.resetFilterDialogDateFilter();
	},
	
	shouldCreateDateFilterObject : function(){
		
		//If both dates are blank at the same time, no date filter object should be created 
		if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)){
			return false;
		}
	
		//Check if any of the dates should be set to its default value 
		if ($.isBlank(this.dateFromUTC)){
			this.dateFromUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate;
			return true;
		}
		
		if ($.isBlank(this.dateToUTC)){
			this.dateToUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate;
		}
		
		return true;
	}, 
	
	setDateFilterCount : function(){
		
		if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)){
			i2d.qm.task.tracknconfirm.utils.FragmentHelper.setFilterDialogDateFilterCount(0);
			return;
		}
		
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.setFilterDialogDateFilterCount(1);
	},
	
	onSort : function(oEvent){
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openSortDialog(this);
	},
	
	onConfirmSortDialog : function(oEvent){

		var parameters = oEvent.getParameters();
		
		//If no no sorted item was selected, return
		if(!parameters.sortItem){
			return;
		}
		
		this.oSorter = parameters.sortItem.getCustomData()[0].getValue().sorter;
		
		if(!this.oSorter){
			return;
		}
		
		//The event parameter for descending is true/false according to the user selection of Ascending/Descending on the popup
		this.oSorter.bDescending = parameters.sortDescending;
		this.getList().getBinding("items").sort(this.oSorter);
	},
	
	onConfirmCustSettingsDialog : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getAggregation("content")[0];
		
		//Check the value state of IssueNumber input
		if (elementContainer.getId() === "CustomSettingsIssuesNumber" && elementContainer.getContent()[1].getValueState() === sap.ui.core.ValueState.Error){
			return; //The state is error, thus return the focus of the IssueNumber input
		}
		
		if (this.changedMaxHits > 0 && this.objSettings.maxHits !== this.changedMaxHits){
			this.objSettings.maxHits = this.changedMaxHits;
			this.handleRefresh();
			localStorage.setObj(this.SETTINGS_NAME, this.objSettings);
		}
				
		this.closeCustSetDialog();
		
	},
	
	onCancelCustSettingsDialog : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getAggregation("content")[0];
		
		if (elementContainer.getId() === "CustomSettingsIssuesNumber"){
			var issuesNumberInput = elementContainer.getContent()[1];
			issuesNumberInput.setValueState(sap.ui.core.ValueState.None);
			issuesNumberInput.setValueStateText("");
		}
				
		this.closeCustSetDialog();
		
	},
	
	onCustSetDialogHeaderBack : function(oEvent){
		
		var issuesNumberInput = oEvent.getSource().getParent().getParent().getAggregation("content")[0].getContent()[1];
			
		if (issuesNumberInput.getValueState() === sap.ui.core.ValueState.Error ){
			return; //The state of the IssuesNumber input value is error, thus return the focus of the input anew
		}
		
		//Navigate back to the popup list with choices
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openCustSetDialog(this, issuesNumberInput.getValue());
		
	},

	onCustomSettingsIssues : function(oEvent){
		var maxHits = oEvent.getSource().getModel("maxHits").getData().maxHits;
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.loadCustSetIssuesNumber(this, maxHits);
	},
	
	onSettingsPressed : function(oEvent){
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits);
	},
	
	onChangeCustSetIssueNumber : function(oEvent){

		//"Not-a-Number" input validation is made on parsing fragment level by the framework. In case of NaN, the value is set to empty string, thus it should be checked only for blank 
		// CSS: 0000364969 2014. Framework validation for NaN does not work for Internet Explorer. Hence adding the check locally.
		if (isNaN(oEvent.getSource().getValue()) || $.isBlank(oEvent.getSource().getValue()) || oEvent.getSource().getValue() < 1){
			oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
			oEvent.getSource().setValueStateText(this.resourceBundle.getText("QT_INVALID_INPUT_ERROR"));
		}else{
			oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			oEvent.getSource().setValueStateText("");
		}
		
		//Remove leading zeros and possible decimal places with radix 10
		this.changedMaxHits = parseInt(oEvent.getSource().getValue(), 10);
		
	}
	
});