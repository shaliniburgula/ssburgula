/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.ErrorDialog");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.type.FileSize");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.InteropServiceHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Formatter");
sap.ca.scfld.md.controller.BaseDetailController.extend("i2d.qm.task.tracknconfirm.view.S3", {
	onInit: function() {
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		var v = this.getView();
		this.selectedValue = new sap.m.StandardListItem({
			key: "{key}",
			title: "{title}",
			active: true
		});
		this.oReassignTaskDialog = null;
		this.oPersonDialog = null;
		this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "detail") {
				var c = new sap.ui.model.Context(v.getModel(), '/' + e.getParameter("arguments").contextPath);
				v.setBindingContext(c)
			}
		}, this);
		var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		if (f) {
			this.oCrossAppNavigator = f && f("CrossApplicationNavigation")
		}
		var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
		sap.ui.getCore().getEventBus().subscribe(a, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected,
			this.handleListItemSelected, this);
		this.oHeaderFooterOptions = {
			bSuppressBookmarkButton: true,
			buttonList: [{
				sId: "QI_FINISH_TASK",
				sI18nBtnTxt: "QT_BUTTON_FINISH_TASK",
				onBtnPressed: jQuery.proxy(function(e) {
					this.onFinishTask(e)
				}, this),
			}, {
				sId: "QT_REASSIGN_TASK",
				sI18nBtnTxt: "QT_BUTTON_REASSIGN_TASK",
				onBtnPressed: jQuery.proxy(function(e) {
					this.onReassignTask(e)
				}, this)
			}],
		};
		this.setHeaderFooterOptions(this.oHeaderFooterOptions);
		this.oApplicationFacade.registerOnMasterListRefresh(this.onMasterRefresh, this)
	},
	onMasterRefresh: function(e) {
		var a = this.byId("ATTACHMENTS").getBinding("items");
		if (!a.bPendingRequest) {
			a._refresh()
		}
	},
	handleListItemSelected: function(c, e, d) {
		var m = this.getView().getModel();
		var s = i2d.qm.task.tracknconfirm.utils.StatusHelper.statusStateBool(m.getProperty("Status", d.context));
		var f = this.byId("QT_FEED_INPUT");
		if (f) {
			f.setValue("");
			f.setEnabled(s)
		}
		this.setBtnEnabled("QI_FINISH_TASK", s);
		this.setBtnEnabled("QT_REASSIGN_TASK", s)
	},
	onExit: function() {
		if (this.oReassignTaskDialog) {
			this.oReassignTaskDialog.destroy();
			this.oReassignTaskDialog = null
		}
		if (this.oPersonDialog) {
			this.oPersonDialog.destroy();
			this.oPersonDialog = null
		}
		if (this.oEmployeeLaunch) {
			this.oEmployeeLaunch.destroy();
			this.oEmployeeLaunch = null
		}
		var d = sap.ui.getCore().byId(this.getView().sId + "--detailFooter");
		if (d && d.destroy) {
			d.destroy()
		}
	},
	navToSubview: function() {
		this.oRouter.navTo("subDetail", {
			contextPath: this.getView().getBindingContext().sPath.substr(1)
		})
	},
	navToEmpty: function() {
		this.oRouter.navTo("noData", {
			viewTitle: "DETAIL_TITLE",
			languageKey: "NO_ITEMS_AVAILABLE"
		})
	},
	navBack: function() {
		window.history.back()
	},
	openBusinessCard: function(e) {
		var E = {};
		if (e) {
			var s = e.oSource;
			if (s) {
				var c = s.getBindingContext();
				var m = this.getView().getModel();
				if (c && m) {
					E = {
						name: m.getProperty("PartnerName", c),
						imgurl: "sap-icon://person-placeholder",
						contactmobile: m.getProperty("PartnerMobilePhone", c),
						contactphone: m.getProperty("PartnerWorkPhone", c),
						contactemail: m.getProperty("PartnerEmail", c),
						companyname: m.getProperty("PartnerCompany", c),
					};
					this.oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
					this.oEmployeeLaunch.openBy(s)
				}
			}
		}
	},
	fillSelectDialog: function(m, i, n, s) {
		var S = new sap.m.SelectDialog("SelectDialog1", {
			title: s,
			noDataText: n,
			search: jQuery.proxy(function(e) {
				var v = e.getParameter("value");
				if (v !== undefined) {
					this.filterDialog(v, S.getBinding("items"))
				}
			}, this),
			liveChange: jQuery.proxy(function(e) {
				var v = e.getParameter("value");
				if (v !== undefined) {
					this.filterDialog(v, S.getBinding("items"))
				}
			}, this)
		});
		S._list.setGrowing(true);
		S._list.setGrowingScrollToLoad(true);
		S.setModel(m);
		var t = new sap.ui.model.Sorter("FullName", false, false);
		var a = new sap.m.StandardListItem({
			key: "{UserName}",
			title: "{FullName}",
			active: true
		});
		S.bindAggregation("items", "/QMUserSet", a, t);
		S.attachConfirm(jQuery.proxy(function(e) {
			var b = e.getParameter("selectedItem");
			if (b) {
				i.setValue(b.getTitle());
				var p = b.getBindingContext().getPath().split("/");
				var c = p[p.length - 1];
				this.selectedValue.key = b.getBindingContext().getModel().oData[c].UserName;
				this.selectedValue.title = b.getTitle()
			}
		}, this));
		return S
	},
	filterDialog: function(v, i) {
		var f = [];
		if (v !== undefined) {
			if (v.length > 0) {
				v = v.substr(0, 1).toUpperCase() + v.substr(1)
			}
			var s = new sap.ui.model.Filter("FullName", sap.ui.model.FilterOperator.StartsWith, v);
			f.push(s);
			i.filter(f)
		}
	},
	onPersonSearch: function(e) {
		var c = this.mEventRegistry.valueHelpRequest[0].oData;
		if (c.oPersonDialog === null) c.oPersonDialog = c.fillSelectDialog(e.getSource().getModel(), this, c.oBundle.getText(
			"QT_PERSON_DIALOG_EMPTY_MSG"), c.oBundle.getText("QT_PERSON_DIALOG_TITLE"));
		var f = this.getValue();
		c.oPersonDialog.open(f);
		if (f !== undefined && f !== "") c.filterDialog(f, c.oPersonDialog.getBinding("items"));
		c.selectedValue.key = "";
		c.selectedValue.title = ""
	},
	onValidation: function(f) {
		var r = true;
		if (f.getValue() == "" || this.selectedValue.key == "") {
			r = false;
			if (f.setValueState) {
				f.setValueState(sap.ui.core.ValueState.Error);
				var t = "QT_INVALID_INPUT_ERROR";
				if (f.getValue() == "") {
					t = "QT_MISSING_INPUT_ERROR"
				}
				f.setValueStateText(this.oBundle.getText(t));
				r = false
			}
		} else if (f.setValueState) {
			f.setValueState(sap.ui.core.ValueState.None)
		}
		return r
	},
	createReassignTaskDialog: function(e) {
		var l = new sap.m.Label("Lbl1", {
			text: this.oBundle.getText("QT_REASSIGN_TASK_DLG_TO"),
			required: true
		});
		var i = new sap.m.Input("cbAssignTo", {
			showValueHelp: true,
			valueHelpRequest: [this, this.onPersonSearch],
			showValueStateMessage: true,
			showSuggestion: true,
			suggest: jQuery.proxy(function(e) {
				this.selectedValue.key = "";
				this.selectedValue.title = "";
				var v = e.getParameter("suggestValue");
				if (v !== undefined) {
					this.filterDialog(v, i.getBinding("suggestionItems"))
				}
			}, this),
			suggestionItemSelected: jQuery.proxy(function(e) {
				var v = e.getParameter("selectedItem");
				if (v !== undefined) {
					this.selectedValue.key = v.mProperties.key;
					this.selectedValue.title = v.mProperties.text
				}
			}, this)
		});
		i.setModel(this.getView().getModel());
		var a = new sap.ui.core.Item({
			key: "{UserName}",
			text: "{FullName}",
			active: true
		});
		i.bindAggregation("suggestionItems", "/QMUserSet", a);
		var L = new sap.m.Label("Lbl2", {
			text: this.oBundle.getText("QT_COMMENT")
		});
		var c = new sap.m.TextArea("taComment");
		var s = new sap.ui.layout.form.SimpleForm({
			maxContainerCols: 1,
			editable: true,
			labelMinWidth: 30,
			layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
			content: [l, i, L, c]
		});
		var d = new sap.m.Dialog({
			title: this.oBundle.getText("QT_REASSIGN_TASK_DIALOG"),
			stretchOnPhone: true
		});
		d.addContent(s);
		var r = new sap.m.Button({
			text: this.oBundle.getText("QT_CONFIRM_BTN"),
			press: jQuery.proxy(function() {
				if (this.onValidation(i)) {
					this.validationMessage = this.oBundle.getText("QT_REASSIGN_TXT_VALIDATION");
					var m = this.getView().getModel();
					var o = this.getView().getBindingContext();
					var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
					var b = {
						ModificationMode: A.getParams().TaskModificationMode.Reassign,
						NotificationID: m.getProperty("NotificationID", o),
						TaskNum: m.getProperty("TaskNum", o),
						TaskLongtext: c.getValue(),
						PartnerID: this.selectedValue.key
					};
					var f = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(A.getServiceList()[0].masterCollection + "(NotificationID='" +
						b.NotificationID + "',TaskNum='" + b.TaskNum + "')", A.getParams().HTTP_Method.PUT, b, this);
					d.close();
					i.setValue("");
					c.setValue("");
					this.selectedValue.key = "";
					this.selectedValue.title = "";
					if (!f || (f && !f.error)) {
						i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage)
					}
				}
			}, this)
		});
		d.setBeginButton(r);
		var C = new sap.m.Button({
			text: this.oBundle.getText("QT_BUTTON_CLOSE"),
			press: function() {
				d.close();
				i.setValue("");
				c.setValue("")
			}
		});
		d.setEndButton(C);
		return d
	},
	onNoteSubmit: function(e) {
		var m = this.getView().getModel();
		var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
		var c = this.getView().getBindingContext();
		var o = {
			ModificationMode: a.getParams().TaskModificationMode.AddNote,
			NotificationID: m.getProperty("NotificationID", c),
			TaskNum: m.getProperty("TaskNum", c),
			TaskLongtext: e.getParameter("value")
		};
		var r = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(a.getServiceList()[0].masterCollection + "(NotificationID='" + o.NotificationID +
			"',TaskNum='" + o.TaskNum + "')", a.getParams().HTTP_Method.PUT, o, this);
		if (!r || (r && !r.error)) {
			this.validationMessage = this.oBundle.getText("QT_NOTES_TXT_VALIDATION");
			i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
			var f = this.byId("QT_FEED_INPUT");
			f.setValue("")
		}
	},
	onReassignTask: function(e) {
		if (this.oReassignTaskDialog === null) this.oReassignTaskDialog = this.createReassignTaskDialog();
		var m = this.getView().getModel();
		var c = this.getView().getBindingContext();
		this.selectedValue.key = m.getProperty("PartnerID", c);
		this.selectedValue.title = m.getProperty("PartnerName", c);
		var p = this.oReassignTaskDialog.getContent()[0]._aElements[1];
		p.setValue(this.selectedValue.title);
		p.setValueState(sap.ui.core.ValueState.None);
		p.setValueStateText("");
		this.oReassignTaskDialog.open()
	},
	onListItemSelect: function(e) {
		var s = e.getSource();
		var m = this.getView().getModel();
		var c = s.getBindingContext();
		var N = m.getProperty("NotificationID", c);
		var D = m.getProperty("DocumentNumber", c);
		if (N && D) {
			i2d.qm.task.tracknconfirm.utils.Helper.getAttStream(N, D)
		}
	},
	onFinishTask: function(e) {
		var c = e.oSource.getBindingContext();
		this.validationMessage = this.oBundle.getText("QT_TXT_VALIDATION");
		var C = jQuery.proxy(function(r) {
			if (r) {
				jQuery.sap.log.debug("isConfirmed:" + r.isConfirmed);
				if (r.sNote) {
					jQuery.sap.log.debug(r.sNote)
				}
				if (r.isConfirmed) {
					var m = this.getView().getModel();
					var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
					var o = {
						ModificationMode: a.getParams().TaskModificationMode.Complete,
						NotificationID: m.getProperty("NotificationID", c),
						TaskNum: m.getProperty("TaskNum", c),
						TaskLongtext: r.sNote
					};
					var b = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(a.getServiceList()[0].masterCollection + "(NotificationID='" +
						o.NotificationID + "',TaskNum='" + o.TaskNum + "')", a.getParams().HTTP_Method.PUT, o, this);
					if (!b || (b && !b.error)) {
						i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage)
					}
				}
			}
		}, this);
		sap.ca.ui.dialog.confirmation.open({
			question: this.oBundle.getText("QT_COMPL_QUESTION"),
			showNote: true,
			title: this.oBundle.getText("QT_CONFIRM_TITLE"),
			confirmButtonLabel: this.oBundle.getText("QT_CONFIRM_BTN")
		}, C)
	},
	onAfterRendering: function() {
		i2d.qm.task.tracknconfirm.utils.Helper.resetFooterContentRightWidth(this);
		var b = jQuery.sap.byId("__button0");
		if (b) {
			b.addClass("sapMBtnEmphasized")
		}
	},
	onNotificationPress: function(e) {
		if (!e) {
			return
		}
		var l = e.getSource();
		var N = l.getText();
		var h = (this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target: {
				semanticObject: "QualityNotification",
				action: "displayFactSheet"
			},
			params: {
				"QualityNotification": N
			}
		}));
		if (h) {
			sap.m.URLHelper.redirect(h, true)
		}
	},
	onDefectPress: function(e) {
		var l = e.getSource();
		var D = l.getText();
		var Q = this.byId("QT_NOTIFICATION").getText();
		var h = (Q && D && this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target: {
				semanticObject: "QualityNotificationItem",
				action: "displayFactSheet"
			},
			params: {
				"QualityNotificationItem": D,
				"QualityNotification": Q
			}
		}));
		if (h) {
			sap.m.URLHelper.redirect(h, true)
		}
	}
});