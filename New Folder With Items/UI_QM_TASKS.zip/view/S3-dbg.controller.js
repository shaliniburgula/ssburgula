/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.ErrorDialog");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.type.FileSize");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.InteropServiceHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Formatter");

sap.ca.scfld.md.controller.BaseDetailController.extend("i2d.qm.task.tracknconfirm.view.S3", {

	onInit : function() {
		// execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);

		var view = this.getView();
		this.selectedValue = new sap.m.StandardListItem({
			key : "{key}",
			title : "{title}",
			active : true
		});
		this.oReassignTaskDialog = null;
		this.oPersonDialog = null;	
		
		this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {
				var context = new sap.ui.model.Context(view.getModel(), '/' + oEvent.getParameter("arguments").contextPath);
				view.setBindingContext(context);
				// Make sure the master is here
			}
		}, this);

		// init CrossApplicationNavigation object
		var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		if (fgetService) {
			this.oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
		}

		var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
		sap.ui.getCore().getEventBus().subscribe(appId, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, this.handleListItemSelected, this);

		this.oHeaderFooterOptions = {
			bSuppressBookmarkButton : true,
			buttonList : [ {
				sId : "QI_FINISH_TASK", // optional
				sI18nBtnTxt : "QT_BUTTON_FINISH_TASK",
				onBtnPressed : jQuery.proxy(function(evt) {
					this.onFinishTask(evt);
				}, this),
			}, {
				sId : "QT_REASSIGN_TASK", // optional
				sI18nBtnTxt : "QT_BUTTON_REASSIGN_TASK",
				onBtnPressed : jQuery.proxy(function(evt) {
					this.onReassignTask(evt);
				}, this)
			} ],
		};

		this.setHeaderFooterOptions(this.oHeaderFooterOptions);
		
		// register method for the event fired when the refresh button on the list is pressed (or back end search is done)	
	    this.oApplicationFacade.registerOnMasterListRefresh(this.onMasterRefresh, this);
	},
	
	onMasterRefresh : function(oEvent){
		// this method is executed when refresh button on the list is pressed (or a back end search is done - currently, we have client search) 
		// it is needed in order to refresh the data in the attachments (if changes are done in the back end)	
			var attItems = this.byId("ATTACHMENTS").getBinding("items");
			// in case the data is loaded 
			if (!attItems.bPendingRequest){
				attItems._refresh();
			}					
		},

	handleListItemSelected : function(sChannelId, sEventId, oData) {
		var oModel = this.getView().getModel();
		var bStatusState = i2d.qm.task.tracknconfirm.utils.StatusHelper.statusStateBool(oModel.getProperty("Status", oData.context));
	 
		var formElement = this.byId("QT_FEED_INPUT");
		if(formElement){
			formElement.setValue("");
			formElement.setEnabled(bStatusState);
		}
		this.setBtnEnabled("QI_FINISH_TASK", bStatusState);
		this.setBtnEnabled("QT_REASSIGN_TASK", bStatusState);
	},

	/**
	 * Called by the UI5 runtime to cleanup this controller
	 */

	onExit : function() {

		// destroy the control if needed
		if (this.oReassignTaskDialog) {
			this.oReassignTaskDialog.destroy();
			this.oReassignTaskDialog = null;
		}
		// destroy the control if needed
		if (this.oPersonDialog) {
			this.oPersonDialog.destroy();
			this.oPersonDialog = null;
		}
		
		// destroy the control if needed
		if (this.oEmployeeLaunch) {
			this.oEmployeeLaunch.destroy();
			this.oEmployeeLaunch = null;
		}
		
		var oDetailFooter = sap.ui.getCore().byId( this.getView().sId + "--detailFooter");
		if(oDetailFooter && oDetailFooter.destroy) {
			oDetailFooter.destroy();
		}
	},

	navToSubview : function() {
		this.oRouter.navTo("subDetail", {
			contextPath : this.getView().getBindingContext().sPath.substr(1)
		});
	},

	navToEmpty : function() {
		this.oRouter.navTo("noData", {
			viewTitle : "DETAIL_TITLE",
			languageKey : "NO_ITEMS_AVAILABLE"
		});
	},
	/**
	 * @override HACK for Full Screen & Master Detail Navigation
	 * @param oItem
	 */
	navBack : function() {
		// this.nav.back();
		window.history.back();
	},

	openBusinessCard : function(oEvent) {
		var oEmpData = {};

		// get control that triggeres the BusinessCard
		if (oEvent) {
			var oSource = oEvent.oSource;
			if (oSource) {
				var oContext = oSource.getBindingContext();
				var oModel = this.getView().getModel();
				if (oContext && oModel) {
					oEmpData = {
						name : oModel.getProperty("PartnerName", oContext),
						imgurl : "sap-icon://person-placeholder",// "img/home/default_contact_picture.png",
						// department:oModel.getProperty("Department",
						// oContext),
						contactmobile : oModel.getProperty("PartnerMobilePhone", oContext),
						contactphone : oModel.getProperty("PartnerWorkPhone", oContext),
						contactemail : oModel.getProperty("PartnerEmail", oContext),
						companyname : oModel.getProperty("PartnerCompany", oContext),
					// companyaddress:oModel.getProperty("CompanyAddress",
					// oContext)
					};

					// call 'Business Card' reuse component
					this.oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmpData);
					this.oEmployeeLaunch.openBy(oSource);
				}
			}
		}
	},

	fillSelectDialog : function(oModelList, oInput, noDataText, mSelectDialogTitle) {

		var oSelectDialog1 = new sap.m.SelectDialog("SelectDialog1", {
			title : mSelectDialogTitle,
			noDataText : noDataText,
			search : jQuery.proxy(function(oEvent) {
				var sVal = oEvent.getParameter("value");
				if (sVal !== undefined) {
					this.filterDialog(sVal, oSelectDialog1.getBinding("items"));
				}
			}, this),
			liveChange : jQuery.proxy(function(oEvent) {
				var sVal = oEvent.getParameter("value");
				if (sVal !== undefined) {
					this.filterDialog(sVal, oSelectDialog1.getBinding("items"));
				}
			}, this)
		});
		oSelectDialog1._list.setGrowing(true);
		oSelectDialog1._list.setGrowingScrollToLoad(true);
		
		// set model & bind Aggregation
		oSelectDialog1.setModel(oModelList);
		// create simple sorter by title
		var oTitleSorter = new sap.ui.model.Sorter("FullName", false, false);
		var itemTemplate = new sap.m.StandardListItem({
			key : "{UserName}",
			title : "{FullName}",
			active : true
		});
		oSelectDialog1.bindAggregation("items", "/QMUserSet", itemTemplate, oTitleSorter);
		// attach close listener
		oSelectDialog1.attachConfirm(jQuery.proxy(function(evt) {
			var selectedItem = evt.getParameter("selectedItem");
			if (selectedItem) {
				oInput.setValue(selectedItem.getTitle());
				var position = selectedItem.getBindingContext().getPath().split("/");
				var index = position[position.length - 1];
				this.selectedValue.key = selectedItem.getBindingContext().getModel().oData[index].UserName;
				this.selectedValue.title = selectedItem.getTitle();
			}
		}, this));

		return oSelectDialog1;
	},

	filterDialog : function(sVal, itemsBinding) {
		var filter = [];
		if (sVal !== undefined ) {
			if (sVal.length > 0 ) {
				sVal = sVal.substr(0,1).toUpperCase() + sVal.substr(1); 
			}
			
			// create the local filter to apply
			var selectFilter = new sap.ui.model.Filter("FullName", sap.ui.model.FilterOperator.StartsWith, sVal);
			filter.push(selectFilter);

			// and apply the filter to the bound items, and the
			// Select Dialog will update
			itemsBinding.filter(filter);
		}
	},

	onPersonSearch : function(oEvent) {
		// in case the person F4 help dialog is not initialized, then do it
		var controller = this.mEventRegistry.valueHelpRequest[0].oData;
		if (controller.oPersonDialog === null)
			controller.oPersonDialog = controller.fillSelectDialog(oEvent.getSource().getModel(), this, controller.oBundle.getText("QT_PERSON_DIALOG_EMPTY_MSG"), controller.oBundle.getText("QT_PERSON_DIALOG_TITLE"));

		// in all cases set it the input if there is any and open the dialog
		var filterValueTxt = this.getValue();
		controller.oPersonDialog.open(filterValueTxt);

		if (filterValueTxt !== undefined && filterValueTxt !== "")
			controller.filterDialog(filterValueTxt, controller.oPersonDialog.getBinding("items"));
		// clear the previous selection if any
		controller.selectedValue.key = "";
		controller.selectedValue.title = "";
	},

	onValidation : function(oField) {
		var result = true;
		// mandatory fields check
		if (oField.getValue() == "" || this.selectedValue.key == "") {
			// set the state to false
			result = false;
			if (oField.setValueState) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				// set different message according to the different errors -
				// empty mandatory field or invalid entry
				var textCode = "QT_INVALID_INPUT_ERROR";
				if (oField.getValue() == "") {
					textCode = "QT_MISSING_INPUT_ERROR";
				}

				oField.setValueStateText(this.oBundle.getText(textCode));
				result = false;
			}
		} else if (oField.setValueState) {
			oField.setValueState(sap.ui.core.ValueState.None);
		}

		return result;
	},

	createReassignTaskDialog : function(oEvent) {

		var oLbl1 = new sap.m.Label("Lbl1", {
			text : this.oBundle.getText("QT_REASSIGN_TASK_DLG_TO"),
			required : true
		});
		var oInputTo = new sap.m.Input("cbAssignTo", {
			showValueHelp : true,
			valueHelpRequest : [ this, this.onPersonSearch ],
			showValueStateMessage : true,
			showSuggestion : true,
			suggest : jQuery.proxy(function(oEvent) {
				this.selectedValue.key = "";
				this.selectedValue.title = "";
				var sVal = oEvent.getParameter("suggestValue");
				if (sVal !== undefined) {
					this.filterDialog(sVal, oInputTo.getBinding("suggestionItems"));
				}
			}, this),
			suggestionItemSelected : jQuery.proxy(function(oEvent) {
				// set selected value
				var sVal = oEvent.getParameter("selectedItem");
				if (sVal !== undefined) {
					this.selectedValue.key = sVal.mProperties.key;
					this.selectedValue.title = sVal.mProperties.text;
				}
			}, this)
		});
		// set model & bind Aggregation

		oInputTo.setModel(this.getView().getModel());

		var itemTemplate = new sap.ui.core.Item({
			key : "{UserName}",
			text : "{FullName}",
			active : true
		});
		oInputTo.bindAggregation("suggestionItems", "/QMUserSet", itemTemplate);

		var oLbl2 = new sap.m.Label("Lbl2", {
			text : this.oBundle.getText("QT_COMMENT")
		});
		var oComment = new sap.m.TextArea("taComment");

		var oSimpleForm = new sap.ui.layout.form.SimpleForm({
			maxContainerCols : 1,
			editable : true,
			labelMinWidth : 30,
			layout : sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
			content : [ oLbl1, oInputTo, oLbl2, oComment ]
		});

		var oDialog1 = new sap.m.Dialog({
			title : this.oBundle.getText("QT_REASSIGN_TASK_DIALOG"),
			stretchOnPhone : true
		});
		oDialog1.addContent(oSimpleForm);

		var oReassignButton = new sap.m.Button({
			text : this.oBundle.getText("QT_CONFIRM_BTN"),
			press : jQuery.proxy(function() {
				if (this.onValidation(oInputTo)) {
					this.validationMessage = this.oBundle.getText("QT_REASSIGN_TXT_VALIDATION");
					var oModel = this.getView().getModel();
					var oContext = this.getView().getBindingContext();
					var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

					var objOData = {
						ModificationMode : oAppConfig.getParams().TaskModificationMode.Reassign,
						NotificationID : oModel.getProperty("NotificationID", oContext),
						TaskNum : oModel.getProperty("TaskNum", oContext),
						TaskLongtext : oComment.getValue(),
						PartnerID : this.selectedValue.key
					};

					var result = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].masterCollection + "(NotificationID='" + objOData.NotificationID + "',TaskNum='" + objOData.TaskNum + "')", oAppConfig.getParams().HTTP_Method.PUT, objOData, this);
					oDialog1.close();
					// clear the input
					oInputTo.setValue("");
					oComment.setValue("");
					this.selectedValue.key = "";
					this.selectedValue.title = "";

					if (!result || (result && !result.error)) {
						i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
					}
				}
			}, this)
		});
		oDialog1.setBeginButton(oReassignButton);

		var oCloseButton = new sap.m.Button({
			text : this.oBundle.getText("QT_BUTTON_CLOSE"),
			press : function() {
				oDialog1.close();
				// clear the input
				oInputTo.setValue("");
				oComment.setValue("");
			}
		});
		oDialog1.setEndButton(oCloseButton);

		return oDialog1;
	},

	 
	onNoteSubmit : function(oEvent) {

		var oModel = this.getView().getModel();
		var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
		var oContext = this.getView().getBindingContext();
		var objOData = {
			ModificationMode : oAppConfig.getParams().TaskModificationMode.AddNote,
			NotificationID : oModel.getProperty("NotificationID", oContext),
			TaskNum : oModel.getProperty("TaskNum", oContext),
			TaskLongtext : oEvent.getParameter("value")
		};
		var result = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].masterCollection + "(NotificationID='" + objOData.NotificationID + "',TaskNum='" + objOData.TaskNum + "')", oAppConfig.getParams().HTTP_Method.PUT, objOData, this);

		if (!result || (result && !result.error)) {
			this.validationMessage = this.oBundle.getText("QT_NOTES_TXT_VALIDATION");

			i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
			var feedInputElement = this.byId("QT_FEED_INPUT");
			feedInputElement.setValue("");
		}

	},

	onReassignTask : function(oEvent) {
		// if the dialog does not exist yet, create it
		if (this.oReassignTaskDialog === null)
			this.oReassignTaskDialog = this.createReassignTaskDialog();

		// in all cases set the coordinator name as default for reassignment, if
		// any is set
		var oModel = this.getView().getModel();
		var oContext = this.getView().getBindingContext();
		this.selectedValue.key = oModel.getProperty("PartnerID", oContext);
		this.selectedValue.title = oModel.getProperty("PartnerName", oContext);
		var oPersonInput = this.oReassignTaskDialog.getContent()[0]._aElements[1];
		oPersonInput.setValue(this.selectedValue.title);
		oPersonInput.setValueState(sap.ui.core.ValueState.None);
		oPersonInput.setValueStateText("");
		// then open it
		this.oReassignTaskDialog.open();
	},

	onListItemSelect : function(oEvnt) {

		var oSelection = oEvnt.getSource();
		var oModel = this.getView().getModel();
		var oContext = oSelection.getBindingContext();
		var NotifNumber = oModel.getProperty("NotificationID", oContext);
		var DocNumber = oModel.getProperty("DocumentNumber", oContext);

		if (NotifNumber && DocNumber) {
			i2d.qm.task.tracknconfirm.utils.Helper.getAttStream(NotifNumber, DocNumber);
		}
	},

	onFinishTask : function(oEvent) {
		var oContext = oEvent.oSource.getBindingContext();
		this.validationMessage = this.oBundle.getText("QT_TXT_VALIDATION");

		// provide your callback function, so that you can get informed if the
		// end user confirms or cancels the dialog
		var fnClose = jQuery.proxy(function(oResult) {
			if (oResult) {
				jQuery.sap.log.debug("isConfirmed:" + oResult.isConfirmed);
				if (oResult.sNote) {
					jQuery.sap.log.debug(oResult.sNote);
				}
				if (oResult.isConfirmed) {
					var oModel = this.getView().getModel();
					var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

					var objOData = {
						ModificationMode : oAppConfig.getParams().TaskModificationMode.Complete,
						NotificationID : oModel.getProperty("NotificationID", oContext),
						TaskNum : oModel.getProperty("TaskNum", oContext),
						TaskLongtext : oResult.sNote
					};

					var result = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].masterCollection + "(NotificationID='" + objOData.NotificationID + "',TaskNum='" + objOData.TaskNum + "')", oAppConfig.getParams().HTTP_Method.PUT, objOData, this);
					if (!result || (result && !result.error)) {
						i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
					}
				}
			}

		}, this);

		// open the confirmation dialog
		sap.ca.ui.dialog.confirmation.open({
			question : this.oBundle.getText("QT_COMPL_QUESTION"),
			showNote : true,
			title : this.oBundle.getText("QT_CONFIRM_TITLE"),
			confirmButtonLabel : this.oBundle.getText("QT_CONFIRM_BTN")
		}, fnClose);

	},

	onAfterRendering : function() {
		i2d.qm.task.tracknconfirm.utils.Helper.resetFooterContentRightWidth(this);

		var oButton = jQuery.sap.byId("__button0");
		if (oButton) {
			oButton.addClass("sapMBtnEmphasized");
		}
	},

	onNotificationPress : function(oEvnt) {
		if (!oEvnt) {
			return;
		}
		var oLink = oEvnt.getSource();
		var NotifId = oLink.getText();
		var sHref = (this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target : {
				semanticObject : "QualityNotification",
				action : "displayFactSheet"
			},
			params : {
				"QualityNotification" : NotifId
			}
		}));

		if (sHref) {
			sap.m.URLHelper.redirect(sHref, true);
			// oLink.setHref(sHref);
			// oLink.firePress();
		}
	},

	onDefectPress : function(oEvnt) {
		var oLink = oEvnt.getSource();
		var DefectId = oLink.getText();
		var QualityNotification = this.byId("QT_NOTIFICATION").getText();
		var sHref = (QualityNotification && DefectId && this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target : {
				semanticObject : "QualityNotificationItem",
				action : "displayFactSheet"
			},
			params : {
				"QualityNotificationItem" : DefectId,
				"QualityNotification" : QualityNotification
			}
		}));
		if (sHref) {
			//open factsheet in new window
			sap.m.URLHelper.redirect(sHref, true);
		}
	}

});
