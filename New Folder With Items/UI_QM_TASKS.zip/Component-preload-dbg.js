jQuery.sap.registerPreloadedModules({
"name":"i2d/qm/task/tracknconfirm/Component-preload",
"version":"2.0",
"modules":{
	"i2d/qm/task/tracknconfirm/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// define a root UIComponent which exposes the main view
jQuery.sap.declare("i2d.qm.task.tracknconfirm.Component");
jQuery.sap.require("i2d.qm.task.tracknconfirm.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

sap.ca.scfld.md.ComponentBase.extend("i2d.qm.task.tracknconfirm.Component", {
	metadata : sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name" : "My Quality Tasks",
		"version" : "1.0.0",
		"library" : "i2d.qm.task.tracknconfirm",
		"includes" : ["css/qt_style.css"],
		"dependencies" : {
		"libs" : ["sap.m", "sap.me"],
		"components" : []
		},
		"config" : {
			"resourceBundle" : "i18n/i18n.properties",
			"titleResource" : "",
			"icon" : "sap-icon://Fiori2/F0317",
			"favIcon" : "./resources/sap/ca/ui/themes/base/img/favicon/F0317_My_Quality_Tasks.ico",
			"homeScreenIconPhone" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/57_iPhone_Desktop_Launch.png",
			"homeScreenIconPhone@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/114_iPhone-Retina_Web_Clip.png",
			"homeScreenIconTablet" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/72_iPad_Desktop_Launch.png",
			"homeScreenIconTablet@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0317_My_Quality_Tasks/144_iPad_Retina_Web_Clip.png",
			"startupImage320x460" : "./resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png",
			"startupImage640x920" : "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png",
			"startupImage640x1096" : "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png",
			"startupImage768x1004" : "./resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png",
			"startupImage748x1024" : "./resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png",
			"startupImage1536x2008" : "./resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png",
			"startupImage1496x2048" : "./resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png"
		},

		viewPath : "i2d.qm.task.tracknconfirm.view",
		
		masterPageRoutes : {
			"master" : {
				pattern : "",
				"view" : "S2",
				"viewId" : "TaskList"
				}
		},
		detailPageRoutes : {
			// we are using default settings
			"detail" : {
				pattern : "detail/{contextPath}",
				"view" : "S3",
				"viewId" : "TaskListDetail"
				}
		},
		
	}),

	/**
	 * Initialize the application
	 *
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {

		var oViewData = {
			component : this
		};
		return sap.ui.view({
			viewName : "i2d.qm.task.tracknconfirm.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	}

});

},
	"i2d/qm/task/tracknconfirm/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");


sap.ca.scfld.md.ConfigurationBase.extend("i2d.qm.task.tracknconfirm.Configuration", {	
		
	aServiceList : [ {
		name : "QM_TASK_SRV",
		masterCollection : "QMTaskSet",
		taskActions: ["ConfirmTask", "ReassignTask"],
		SetCollection : ["QMUserSet","QMSettingsSet", "QMTaskStatusSet"],
		QIAttachmentStream : "QMStreamSet",
		serviceUrl : ""+URI("/sap/opu/odata/sap/QM_TASK_SRV/"),
		isDefault : true,
		mockedDataSource : "model/metadata.xml"
	} ],
	
	GlobalParams : {
		settingsName : "objSettings",
		eventListItemSelected : "ListItemSelected",
		HTTP_Method : {
			 GET 	: "GET",
			 POST	: "POST",
			 PUT	: "PUT",
			 DELETE	: "DELETE",
			 MERGE	: "MERGE"
		},
		TaskModificationMode : {
			Reassign : 0,
			Complete : 1,
			AddNote  : 2
		},
		ProcessingModeEnum : {
								 Read : "Read", 
								 Batch : "ReadBatch", 
								 Change : "ChangeBatch"
							 },
							 
		InteropService	   : {
									name : "UI2/INTEROP",// "INTEROP service - check for cross app navigation availability
									linkCheck : "ResolveLink?linkId='QualityNotification-displayFactSheet'",		
									serviceUrl: URI("/sap/opu/odata/UI2/INTEROP/")
								},					 
		filterDialogDefaultFromDate : "1970-01-01T00:00:00.000Z",
		filterDialogDefaultToDate : "9999-12-31T00:00:00.000Z"
	},

	getServiceParams : function() {
		return this.oServiceParams;
	},

	
	/**
	 * @inherit
	 */
	getServiceList : function() {
		return this.aServiceList;
	},

	getMasterKeyAttributes : function() {
		return ["TaskNum", "NotificationID"];
	},
	
	getParams : function() {
		return this.GlobalParams;
	},
	
	getAppIdentifier : function() {
		return "i2d.qm.task.tracknconfirm";
	},
	

});



},
	"i2d/qm/task/tracknconfirm/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */



sap.ui.controller("i2d.qm.task.tracknconfirm.Main", {

	onInit : function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Formatter");
		
		// extend local Storage object to support objects and array handling
		Storage.prototype.setObj = function(key, obj) { // EXC_JSHINT_003
			//In private browsing mode Safari and iOS Safari don't support setting localStorage.
			try {
				this.setItem(key, JSON.stringify(obj));
				return true;
			} catch (error) {
				return false;
			}	
		};
		Storage.prototype.getObj = function(key) { // EXC_JSHINT_003
		    return JSON.parse(this.getItem(key));
		};
		
		//extend jQuery object with isBlank function
		(function($){
			  $.isBlank = function(obj){
			    return(!obj || (typeof(obj) == "string" && $.trim(obj) === "") ||
			    		($.isPlainObject(obj) && $.isEmptyObject(obj)) ||
			    		($.isArray(obj) && obj.length == 0) 
			    	   );
			  };
			})(jQuery);
		
		sap.ca.scfld.md.Startup.init('i2d.qm.task.tracknconfirm', this);				
	},	
	
});
},
	"i2d/qm/task/tracknconfirm/Main.view.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<core:View xmlns:core="sap.ui.core" \r\n\txmlns="sap.m" \r\ncontrollerName="i2d.qm.task.tracknconfirm.Main" \r\ndisplayBlock="true" \r\nheight="100%">\r\n\t<NavContainer id="fioriContent" showHeader="false">\r\n\t</NavContainer>\r\n</core:View>',
	"i2d/qm/task/tracknconfirm/fragments/CustomSettingsDialog.fragment.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<Dialog xmlns="sap.m" id="CustomSettingsDialog" title="{i18n>QT_SETTIGS_DIALOG_TITLE}" stretchOnPhone="true">\r\n\t<beginButton>\r\n\t\t<Button text="{i18n>QT_CONFIRM_BTN}" type="Default" press="onConfirmCustSettingsDialog"/>\r\n\t</beginButton>\r\n\t<endButton>\r\n\t\t<Button text="{i18n>QT_BUTTON_CLOSE}" type="Default" press="onCancelCustSettingsDialog"/>\r\n\t</endButton>\r\n</Dialog>',
	"i2d/qm/task/tracknconfirm/fragments/CustomSettingsDialogHeader.fragment.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<Bar xmlns="sap.m" id="CustSetDialogHeader">\r\n\t<contentLeft>\r\n\t\t<Button id="CustSetDialogHeaderBack" icon="sap-icon://nav-back" press="onCustSetDialogHeaderBack"/>\r\n\t</contentLeft>\r\n\t<contentMiddle>\r\n\t\t<Label id="CustSetDialogHeaderTitle" text="{i18n>QT_SETTIGS_DIALOG_TITLE}"/>\r\n\t</contentMiddle>\r\n</Bar>',
	"i2d/qm/task/tracknconfirm/fragments/CustomSettingsList.fragment.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<List xmlns="sap.m" id="CustomSettingsList">\r\n\t<items>\r\n\t\t<StandardListItem id="CustomSettingsIssues"\ttitle="{path:\'maxHits>/maxHits\', formatter:\'i2d.qm.task.tracknconfirm.utils.FragmentHelper.getCustSetMaxHitsTitle\'}" \r\n\t\t\ttype="Navigation" press="onCustomSettingsIssues"/>\r\n\t</items>\r\n</List>',
	"i2d/qm/task/tracknconfirm/fragments/CustomSettingsNumberOfIssues.fragment.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<SimpleForm xmlns="sap.ui.layout.form" id="CustomSettingsIssuesNumber" editable="true" labelMinWidth="30" layout="ResponsiveGridLayout">\r\n\t<content>\r\n\t\t<Label xmlns="sap.m" id="CustSeTIssueNumberLabel" text="{i18n>QT_TASKS_NUMBER}" labelFor="CustSetIssueNumberInput"/>\r\n\t\t<Input xmlns="sap.m" id="CustSetIssueNumberInput" showValueHelp="false" type="Number" value="{maxHits>/maxHits}" change="onChangeCustSetIssueNumber"></Input>\t\t\r\n\t</content>\r\n</SimpleForm>',
	"i2d/qm/task/tracknconfirm/fragments/ViewSettingsFilterDialog.fragment.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<ViewSettingsDialog xmlns="sap.m" id="FilterDialog" confirm="onConfirmFilterDialog" resetFilters="onResetFilterDialog" cancel="onCancelFilterDialog">\r\n\t<filterItems>\r\n\t\t<ViewSettingsFilterItem id="FiltertByStatus" key="1" text="{i18n>QT_STATUS_TEXT}">\r\n\t\t\t<items>\r\n\t\t\t\t<ViewSettingsItem id="StatusNew" key="1a" text="{path:\'/status1\'}" selected="true">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0154\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t\t<ViewSettingsItem id="StatusInProcess" key="1b" text="{path:\'/status2\'}" selected="true">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0155\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t\t<ViewSettingsItem id="StatusCompleted" key="1c" text="{path:\'/status3\'}" selected="false">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0156\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t</items>\r\n\t\t</ViewSettingsFilterItem>\r\n\t\t<ViewSettingsCustomItem id="FiltertByDate" key="2" text="{i18n>QT_DV_DUE_DATE}">\r\n\t\t\t<customControl>\r\n\t\t\t\t<VBox id="DatesContainer" fitContainer="true" direction="Column">\r\n\t\t\t\t\t<items>\r\n\t\t\t\t\t\t<Label id="DateFrom" design="Bold" text="{i18n>QT_FROM}" labelFor="DateFromPicker"/>\r\n\t\t\t\t\t\t<DatePicker xmlns="sap.m" id="DateFromPicker" width="10em" tooltip="{i18n>QT_FROM_TOOLTIP}" change="onChangeDateFrom"/>\r\n\t\t\t\t\t\t<Label id="DateTo" design="Bold" text="{i18n>QT_TO}" labelFor="DateToPicker"/>\r\n\t\t\t\t\t\t<DatePicker xmlns="sap.m" id="DateToPicker" width="10em" tooltip="{i18n>QT_TO_TOOLTIP}" change="onChangeDateTo"/>\r\n\t\t\t\t\t</items>\r\n\t\t\t\t</VBox>\r\n\t\t\t</customControl>\r\n\t\t</ViewSettingsCustomItem>\r\n\t</filterItems>\r\n</ViewSettingsDialog>',
	"i2d/qm/task/tracknconfirm/fragments/ViewSettingsSortDialog.fragment.xml":'<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<ViewSettingsDialog xmlns="sap.m" id="SortDialog" confirm="onConfirmSortDialog">\r\n\t<sortItems>\r\n\t\t<ViewSettingsItem id="DateSort" key="1" text="{i18n>QT_DV_DUE_DATE}" selected="false">\r\n\t\t\t<customData>\r\n\t\t\t\t<CustomData xmlns="sap.ui.core" value="{sorter: {path:\'DueDate\', descending:false}}"/>\r\n\t\t\t</customData>\r\n\t\t</ViewSettingsItem>\r\n\t\t<ViewSettingsItem id="StatusSort" key="2" text="{i18n>QT_STATUS_TEXT}" selected="false">\r\n\t\t\t<customData>\r\n\t\t\t\t<CustomData xmlns="sap.ui.core" value="{sorter: {path:\'Status\', descending:false}}"/>\r\n\t\t\t</customData>\r\n\t\t</ViewSettingsItem>\t\t\r\n\t</sortItems>\r\n</ViewSettingsDialog>',
	"i2d/qm/task/tracknconfirm/i18n/i18n.properties":'#<Describe your application/i18n file here; required for translation >\n# __ldi.translation.uuid=58f01e00-155d-11e3-8ffd-0800200c9a66\n# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=My Quality Tasks ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=Complete Task\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=Task completed\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=Comment\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=Are you sure you want to complete this task?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=Complete Task\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=My Quality Task\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=Task\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=Task Code\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=Description\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=Detailed Description\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=Start Date\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=Due Date\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=Quality Notification\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=Notification\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=Notification Type\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=Assigned To\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=Priority\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=Related Defect\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=Defect\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=Notes\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=Status\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=New\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=In Process\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=Completed\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=Successful\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=Today\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=Days to due date\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=Days overdue\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=Day to due date\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=Day overdue\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=Add\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=Note added\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=Reassign\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=Reassign Task\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=To\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=Choose Person\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=No persons available\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=Mandatory field\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=Invalid input\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=Task reassigned\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=Cancel\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=Settings \n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=Display {0} Tasks\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=Display 1 Task\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=Number of Tasks\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=To\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP= Enter end date for filtering\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP= Enter start date for filtering\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=From\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=Filtered by {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=Settings\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Overdue\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=Approaching Due Date\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=Far from Due Date\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=Without Due Date\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=None\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=Added on {0} by {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=No file name\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=Loading...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=No Quality Tasks Available\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=Invalid Date Entered\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=To Date should be equal to or later than From Date',
	"i2d/qm/task/tracknconfirm/i18n/i18n_ar.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=\\u0645\\u0647\\u0627\\u0645 \\u0627\\u0644\\u062C\\u0648\\u062F\\u0629 \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u064A ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=\\u0625\\u0643\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=\\u0627\\u0643\\u062A\\u0645\\u0644\\u062A \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=\\u062A\\u0639\\u0644\\u064A\\u0642\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0625\\u0643\\u0645\\u0627\\u0644 \\u0647\\u0630\\u0647 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629 \\u0628\\u0627\\u0644\\u0641\\u0639\\u0644\\u061F\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=\\u0625\\u0643\\u0645\\u0627\\u0644 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=\\u0645\\u0648\\u0627\\u0641\\u0642\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=\\u0645\\u0647\\u0645\\u0629 \\u0627\\u0644\\u062C\\u0648\\u062F\\u0629 \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u064A\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=\\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=\\u0631\\u0645\\u0632 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=\\u0627\\u0644\\u0648\\u0635\\u0641\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=\\u0648\\u0635\\u0641 \\u062A\\u0641\\u0635\\u064A\\u0644\\u064A\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0628\\u062F\\u0627\\u064A\\u0629\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=\\u0625\\u0634\\u0639\\u0627\\u0631 \\u0627\\u0644\\u062C\\u0648\\u062F\\u0629\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=\\u0627\\u0644\\u0625\\u0634\\u0639\\u0627\\u0631\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=\\u0646\\u0648\\u0639 \\u0627\\u0644\\u0625\\u0634\\u0639\\u0627\\u0631\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=\\u0645\\u0639\\u064A\\u0651\\u064E\\u0646 \\u0625\\u0644\\u0649\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=\\u0627\\u0644\\u0623\\u0641\\u0636\\u0644\\u064A\\u0629\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=\\u0627\\u0644\\u0639\\u064A\\u0628 \\u0630\\u0648 \\u0627\\u0644\\u0635\\u0644\\u0629\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=\\u0627\\u0644\\u0639\\u064A\\u0628\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=\\u0627\\u0644\\u062D\\u0627\\u0644\\u0629\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=\\u062C\\u062F\\u064A\\u062F\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=\\u0642\\u064A\\u062F \\u0627\\u0644\\u0645\\u0639\\u0627\\u0644\\u062C\\u0629\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=\\u0645\\u0643\\u062A\\u0645\\u0644\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=\\u062A\\u0645 \\u0628\\u0646\\u062C\\u0627\\u062D\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=\\u0627\\u0644\\u064A\\u0648\\u0645\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=\\u0639\\u062F\\u062F \\u0627\\u0644\\u0623\\u064A\\u0627\\u0645 \\u062D\\u062A\\u0649 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=\\u0639\\u062F\\u062F \\u0623\\u064A\\u0627\\u0645 \\u0627\\u0644\\u062A\\u0623\\u062E\\u064A\\u0631\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=\\u064A\\u0648\\u0645 \\u0648\\u0627\\u062D\\u062F \\u062D\\u062A\\u0649 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=\\u064A\\u0648\\u0645 \\u0627\\u0644\\u062A\\u0623\\u062E\\u064A\\u0631\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=\\u0625\\u0636\\u0627\\u0641\\u0629\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=\\u062A\\u0645\\u062A \\u0625\\u0636\\u0627\\u0641\\u0629 \\u0645\\u0644\\u0627\\u062D\\u0638\\u0629\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=\\u0625\\u0639\\u0627\\u062F\\u0629 \\u062A\\u0639\\u064A\\u064A\\u0646\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=\\u0625\\u0639\\u0627\\u062F\\u0629 \\u062A\\u0639\\u064A\\u064A\\u0646 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=\\u0625\\u0644\\u0649\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=\\u0627\\u062E\\u062A\\u064A\\u0627\\u0631 \\u0634\\u062E\\u0635\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=\\u0644\\u0627 \\u064A\\u062A\\u0648\\u0641\\u0631 \\u0623\\u064A \\u0623\\u0634\\u062E\\u0627\\u0635\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=\\u062D\\u0642\\u0644 \\u0625\\u0644\\u0632\\u0627\\u0645\\u064A\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=\\u0625\\u062F\\u062E\\u0627\\u0644 \\u063A\\u064A\\u0631 \\u0635\\u0627\\u0644\\u062D\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=\\u062A\\u0645\\u062A \\u0625\\u0639\\u0627\\u062F\\u0629 \\u062A\\u0639\\u064A\\u064A\\u0646 \\u0627\\u0644\\u0645\\u0647\\u0645\\u0629\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=\\u0625\\u0644\\u063A\\u0627\\u0621\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=\\u0625\\u0639\\u062F\\u0627\\u062F\\u0627\\u062A\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=\\u0639\\u0631\\u0636 {0} \\u0645\\u0646 \\u0627\\u0644\\u0645\\u0647\\u0627\\u0645\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=\\u0639\\u0631\\u0636 \\u0645\\u0647\\u0645\\u0629 \\u0648\\u0627\\u062D\\u062F\\u0629\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=\\u0639\\u062F\\u062F \\u0627\\u0644\\u0645\\u0647\\u0627\\u0645\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=\\u0625\\u0644\\u0649\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=\\u0623\\u062F\\u062E\\u0644 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0646\\u062A\\u0647\\u0627\\u0621 \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=\\u0623\\u062F\\u062E\\u0644 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0628\\u062F\\u0627\\u064A\\u0629 \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=\\u0645\\u0646\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=\\u062A\\u0645\\u062A \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629 \\u062D\\u0633\\u0628 {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=\\u0625\\u0639\\u062F\\u0627\\u062F\\u0627\\u062A\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=\\u0645\\u062A\\u0623\\u062E\\u0631\\u0629\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\\u0647\\u0627 \\u0642\\u0631\\u064A\\u0628\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\\u0647\\u0627 \\u0628\\u0639\\u064A\\u062F\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=\\u0628\\u062F\\u0648\\u0646 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0633\\u062A\\u062D\\u0642\\u0627\\u0642\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=\\u0644\\u0627 \\u0634\\u064A\\u0621\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=\\u062A\\u0645\\u062A \\u0627\\u0644\\u0625\\u0636\\u0627\\u0641\\u0629 \\u0641\\u064A {0} \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=\\u0644\\u0627 \\u064A\\u0648\\u062C\\u062F \\u0627\\u0633\\u0645 \\u0645\\u0644\\u0641\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=\\u062C\\u0627\\u0631\\u064D \\u0627\\u0644\\u062A\\u062D\\u0645\\u064A\\u0644...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0623\\u064A \\u0645\\u0647\\u0627\\u0645 \\u062C\\u0648\\u062F\\u0629\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=\\u062A\\u0645 \\u0625\\u062F\\u062E\\u0627\\u0644 \\u062A\\u0627\\u0631\\u064A\\u062E \\u063A\\u064A\\u0631 \\u0635\\u0627\\u0644\\u062D\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=\\u064A\\u062C\\u0628 \\u0623\\u0646 \\u062A\\u0643\\u0648\\u0646 \\u0642\\u064A\\u0645\\u0629 "\\u0625\\u0644\\u0649 \\u0627\\u0644\\u062A\\u0627\\u0631\\u064A\\u062E" \\u0645\\u0633\\u0627\\u0648\\u064A\\u0629 \\u0623\\u0648 \\u0644\\u0627\\u062D\\u0642\\u0629 \\u0644\\u0642\\u064A\\u0645\\u0629 "\\u0645\\u0646 \\u0627\\u0644\\u062A\\u0627\\u0631\\u064A\\u062E"\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_bg.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0438 \\u043F\\u043E \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=\\u041F\\u0440\\u0438\\u043A\\u043B. \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430\\u0442\\u0430 \\u0435 \\u043F\\u0440\\u0438\\u043A\\u043B\\u044E\\u0447\\u0435\\u043D\\u0430\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=\\u041A\\u043E\\u043C\\u0435\\u043D\\u0442\\u0430\\u0440\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=\\u0421\\u0438\\u0433\\u0443\\u0440\\u043D\\u0438 \\u043B\\u0438 \\u0441\\u0442\\u0435, \\u0447\\u0435 \\u0436\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u0434\\u0430 \\u043F\\u0440\\u0438\\u043A\\u043B\\u044E\\u0447\\u0438\\u0442\\u0435 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\\u0442\\u0430?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=\\u041F\\u0440\\u0438\\u043A\\u043B. \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0438 \\u0437\\u0430 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=\\u041A\\u043E\\u0434 \\u043D\\u0430 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E \\u043E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=\\u041D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=\\u041F\\u0430\\u0434\\u0435\\u0436\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=\\u0418\\u0437\\u0432\\u0435\\u0441\\u0442\\u0438\\u0435 \\u0437\\u0430 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=\\u0418\\u0437\\u0432\\u0435\\u0441\\u0442\\u0438\\u0435\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=\\u0412\\u0438\\u0434 \\u0438\\u0437\\u0432\\u0435\\u0441\\u0442\\u0438\\u0435\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D \\u043A\\u044A\\u043C\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=\\u041F\\u0440\\u0438\\u043E\\u0440\\u0438\\u0442\\u0435\\u0442\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=\\u0421\\u0432\\u044A\\u0440\\u0437\\u0430\\u043D \\u0434\\u0435\\u0444\\u0435\\u043A\\u0442\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=\\u0414\\u0435\\u0444\\u0435\\u043A\\u0442\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=\\u0411\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=\\u041D\\u043E\\u0432\\u0438\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=\\u0412 \\u043E\\u0431\\u0440\\u0430\\u0431\\u043E\\u0442\\u043A\\u0430\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=\\u0417\\u0430\\u0432\\u044A\\u0440\\u0448\\u0435\\u043D\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=\\u0423\\u0441\\u043F\\u0435\\u0448\\u0435\\u043D\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=\\u0414\\u043D\\u0435\\u0441\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=\\u0414\\u043D\\u0438 \\u0434\\u043E \\u043F\\u0430\\u0434\\u0435\\u0436\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=\\u041F\\u0440\\u043E\\u0441\\u0440\\u043E\\u0447\\u0435\\u043D\\u0438 \\u0434\\u043D\\u0438\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=\\u0414\\u0435\\u043D \\u0434\\u043E \\u043F\\u0430\\u0434\\u0435\\u0436\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=\\u041F\\u0440\\u043E\\u0441\\u0440\\u043E\\u0447\\u0435\\u043D \\u0434\\u0435\\u043D\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=\\u0414\\u043E\\u0431\\u0430\\u0432\\u044F\\u043D\\u0435\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=\\u0411\\u0435\\u043B\\u0435\\u0436\\u043A\\u0430\\u0442\\u0430 \\u0435 \\u0434\\u043E\\u0431\\u0430\\u0432\\u0435\\u043D\\u0430\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=\\u041F\\u043E\\u0432\\u0442. \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434.\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=\\u041F\\u043E\\u0432\\u0442\\u043E\\u0440\\u043D\\u043E \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=\\u0414\\u043E\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=\\u0418\\u0437\\u0431\\u043E\\u0440 \\u043D\\u0430 \\u043B\\u0438\\u0446\\u0435\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u043B\\u0438\\u0446\\u0430\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=\\u0417\\u0430\\u0434\\u044A\\u043B\\u0436\\u0438\\u0442\\u0435\\u043B\\u043D\\u043E \\u043F\\u043E\\u043B\\u0435\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=\\u041D\\u0435\\u0432\\u0430\\u043B\\u0438\\u0434\\u043D\\u043E \\u0432\\u044A\\u0432\\u0435\\u0436\\u0434\\u0430\\u043D\\u0435\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=\\u041F\\u043E\\u0432\\u0442\\u043E\\u0440\\u043D\\u043E \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D\\u0430 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=\\u041E\\u0442\\u043A\\u0430\\u0437\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=\\u041D\\u0430\\u0441\\u0442\\u0440\\u043E\\u0439\\u043A\\u0438\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435 {0} \\u0437\\u0430\\u0434\\u0430\\u0447\\u0438\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 1 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0430\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=\\u0411\\u0440\\u043E\\u0439 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0438\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=\\u0414\\u043E\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u0442\\u0435 \\u043A\\u0440\\u0430\\u0439\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430 \\u0437\\u0430 \\u0444\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D\\u0435\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u0442\\u0435 \\u043D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430 \\u0437\\u0430 \\u0444\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D\\u0435\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=\\u041E\\u0442\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=\\u0424\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D \\u043F\\u043E {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=\\u041D\\u0430\\u0441\\u0442\\u0440\\u043E\\u0439\\u043A\\u0438\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=\\u041F\\u0440\\u043E\\u0441\\u0440\\u043E\\u0447\\u0435\\u043D\\u0438\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=\\u041D\\u0430\\u0431\\u043B\\u0438\\u0436\\u0430\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0430\\u0434\\u0435\\u0436\\u0430\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=\\u0414\\u0430\\u043B\\u0435\\u0447 \\u043E\\u0442 \\u043F\\u0430\\u0434\\u0435\\u0436\\u0430\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=\\u0411\\u0435\\u0437 \\u043F\\u0430\\u0434\\u0435\\u0436\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=\\u041D\\u044F\\u043C\\u0430\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0435\\u043D \\u043D\\u0430 {0} \\u043E\\u0442 {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=\\u041D\\u044F\\u043C\\u0430 \\u0438\\u043C\\u0435 \\u043D\\u0430 \\u0444\\u0430\\u0439\\u043B\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=\\u0417\\u0430\\u0440\\u0435\\u0436\\u0434\\u0430\\u043D\\u0435...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0438 \\u0437\\u0430 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u043D\\u0430 \\u0435 \\u043D\\u0435\\u0432\\u0430\\u043B\\u0438\\u0434\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=\\u041A\\u0440\\u0430\\u0439\\u043D\\u0430\\u0442\\u0430 \\u0434\\u0430\\u0442\\u0430 \\u0442\\u0440\\u044F\\u0431\\u0432\\u0430 \\u0434\\u0430 \\u0441\\u044A\\u0432\\u043F\\u0430\\u0434\\u0430 \\u0438\\u043B\\u0438 \\u0434\\u0430 \\u0435 \\u043F\\u043E-\\u043A\\u044A\\u0441\\u043D\\u0430 \\u043E\\u0442 \\u043D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430\\u0442\\u0430 \\u0434\\u0430\\u0442\\u0430\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_cs.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Moje jakostn\\u00ED \\u00FAlohy ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Dokon\\u010Dit \\u00FAlohu\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=\\u00DAloha dokon\\u010Dena\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Koment\\u00E1\\u0159\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Chcete tuto \\u00FAlohu opravdu dokon\\u010Dit?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Dokon\\u010Dit \\u00FAlohu\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Moje jakostn\\u00ED \\u00FAloha\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=\\u00DAloha\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=K\\u00F3d \\u00FAlohy\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Popis\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Detailn\\u00ED popis\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Datum zah\\u00E1jen\\u00ED\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Term\\u00EDn spln\\u011Bn\\u00ED\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Hl\\u00E1\\u0161en\\u00ED jakosti\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Ozn\\u00E1men\\u00ED\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Typ ozn\\u00E1men\\u00ED\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=P\\u0159i\\u0159azeno k\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priorita\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Souvisej\\u00EDc\\u00ED z\\u00E1vada\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Z\\u00E1vada\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Pozn\\u00E1mky\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Stav\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Nov\\u00E1\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=Ve zpracov\\u00E1n\\u00ED\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Dokon\\u010Deno\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=\\u00DAsp\\u011B\\u0161n\\u00E9\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Dnes\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Dn\\u00ED do term\\u00EDnu\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=Dn\\u00ED po term\\u00EDnu\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Den do term\\u00EDnu\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=Den po term\\u00EDnu\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=P\\u0159idat\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Pozn\\u00E1mka p\\u0159id\\u00E1na\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Znovu p\\u0159i\\u0159adit\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Znovu p\\u0159i\\u0159adit \\u00FAlohu\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=Do\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Zvolit osobu\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 osoby\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Povinn\\u00E9 pole\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Neplatn\\u00E9 zad\\u00E1n\\u00ED\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=\\u00DAloha znovu p\\u0159i\\u0159azena\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Zru\\u0161it\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Nastaven\\u00ED\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Zobrazit {0} \\u00FAloh\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Zobrazit 1 \\u00FAlohu\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Po\\u010Det \\u00FAloh\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=Do\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Zadejte koncov\\u00E9 datum pro filtrov\\u00E1n\\u00ED\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Zadejte po\\u010D\\u00E1te\\u010Dn\\u00ED datum pro filtrov\\u00E1n\\u00ED\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Od\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtrov\\u00E1no podle {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Nastaven\\u00ED\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=Po term\\u00EDnu\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Bl\\u00ED\\u017E\\u00EDc\\u00ED se term\\u00EDn\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Daleko od term\\u00EDnu\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Bez term\\u00EDnu\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Nic\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=P\\u0159id\\u00E1no {0}, p\\u0159idal {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=\\u017D\\u00E1dn\\u00FD n\\u00E1zev souboru\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Zav\\u00E1d\\u00ED se...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 jakostn\\u00ED \\u00FAlohy\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Byla zad\\u00E1na neplatn\\u00E1 data\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Datum by m\\u011Blo b\\u00FDt stejn\\u00E9 nebo pozd\\u011Bj\\u0161\\u00ED ne\\u017E po\\u010D\\u00E1te\\u010Dn\\u00ED datum\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_de.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Meine Ma\\u00DFnahmen ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Abschlie\\u00DFen\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Ma\\u00DFnahme abgeschlossen\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Kommentar\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=M\\u00F6chten Sie diese Ma\\u00DFnahme abschlie\\u00DFen?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Ma\\u00DFnahme abschlie\\u00DFen\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Meine Ma\\u00DFnahme\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Ma\\u00DFnahme\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Ma\\u00DFnahmencode\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Beschreibung\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Detaillierte Beschreibung\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Startdatum\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=F\\u00E4lligkeitsdatum\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Qualit\\u00E4tsmeldung\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Meldung\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Meldungsart\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Zugeordnet zu\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priorit\\u00E4t\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Verwandter Fehler\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Fehler\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notizen\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Status\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Neu\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=In Bearbeitung\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Abgeschlossen\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Erfolgreich\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Heute\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Tage bis F\\u00E4lligkeitsdatum\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=Tage \\u00FCberf\\u00E4llig\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Tag bis F\\u00E4lligkeitsdatum\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=Tag \\u00FCberf\\u00E4llig\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Hinzuf\\u00FCgen\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Notiz hinzugef\\u00FCgt\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Neu zuordnen\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Ma\\u00DFnahme neu zuordnen\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=Zu\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Person w\\u00E4hlen\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Keine Personen verf\\u00FCgbar\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Mussfeld\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Ung\\u00FCltige Eingabe\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Ma\\u00DFnahme neu zugeordnet\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Abbrechen\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Einstellungen\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER={0} Ma\\u00DFnahmen anzeigen\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=1 Ma\\u00DFnahme anzeigen\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Anzahl Ma\\u00DFnahmen\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=Bis\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Enddatum zum Filtern eingeben\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Startdatum zum Filtern eingeben\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Von\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Gefiltert nach {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Einstellungen\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=\\u00DCberf\\u00E4llig\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Nahendes F\\u00E4lligkeitsdatum\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Weit vor F\\u00E4lligkeitsdatum\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Ohne F\\u00E4lligkeitsdatum\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Keine\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Hinzugef\\u00FCgt am {0} von {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Kein Dateiname\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Ladevorgang l\\u00E4uft...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Keine Qualit\\u00E4tsma\\u00DFnahmen verf\\u00FCgbar\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Ung\\u00FCltiges Datum eingegeben\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Bis-Datum soll gleich oder nach Von-Datum sein\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_en.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=My Quality Tasks ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Complete Task\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Task completed\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Comment\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Are you sure you want to complete this task?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Complete Task\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=My Quality Task\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Task\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Task Code\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Description\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Detailed Description\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Start Date\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Due Date\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Quality Notification\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Notification\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Notification Type\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Assigned To\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priority\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Related Defect\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Defect\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notes\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Status\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=New\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=In Process\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Completed\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Successful\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Today\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Days to due date\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=Days overdue\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Day to due date\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=Day overdue\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Add\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Note added\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Reassign\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Reassign Task\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=To\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Choose Person\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=No persons available\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Mandatory field\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Invalid input\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Task reassigned\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Cancel\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Settings\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Display {0} Tasks\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Display 1 Task\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Number of Tasks\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=To\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Enter end date for filtering\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Enter start date for filtering\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=From\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtered by {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Settings\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=Overdue\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Approaching Due Date\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Far from Due Date\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Without Due Date\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=None\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Added on {0} by {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=No file name\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Loading...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=No Quality Tasks Available\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Invalid date entered\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=To Date should be equal to or later than From Date\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_en_US_sappsd.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=[[[\\u039C\\u0177 \\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u0162\\u0105\\u015F\\u0137\\u015F ({0})]]]\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=[[[\\u0108\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113 \\u0162\\u0105\\u015F\\u0137]]]\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=[[[\\u0162\\u0105\\u015F\\u0137 \\u010B\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113\\u018C]]]\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=[[[\\u0108\\u014F\\u0271\\u0271\\u0113\\u014B\\u0163]]]\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=[[[\\u0100\\u0157\\u0113 \\u0177\\u014F\\u0171 \\u015F\\u0171\\u0157\\u0113 \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u010B\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113 \\u0163\\u0125\\u012F\\u015F \\u0163\\u0105\\u015F\\u0137?]]]\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=[[[\\u0108\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113 \\u0162\\u0105\\u015F\\u0137]]]\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=[[[\\u014E\\u0136]]]\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=[[[\\u039C\\u0177 \\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u0162\\u0105\\u015F\\u0137]]]\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=[[[\\u0162\\u0105\\u015F\\u0137]]]\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=[[[\\u0162\\u0105\\u015F\\u0137 \\u0108\\u014F\\u018C\\u0113]]]\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=[[[\\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B]]]\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=[[[\\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u0113\\u018C \\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B]]]\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=[[[\\u015C\\u0163\\u0105\\u0157\\u0163 \\u010E\\u0105\\u0163\\u0113]]]\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=[[[\\u010E\\u0171\\u0113 \\u010E\\u0105\\u0163\\u0113]]]\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=[[[\\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u0143\\u014F\\u0163\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B]]]\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=[[[\\u0143\\u014F\\u0163\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B]]]\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=[[[\\u0143\\u014F\\u0163\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B \\u0162\\u0177\\u03C1\\u0113]]]\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=[[[\\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0162\\u014F]]]\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=[[[\\u01A4\\u0157\\u012F\\u014F\\u0157\\u012F\\u0163\\u0177]]]\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=[[[\\u0158\\u0113\\u013A\\u0105\\u0163\\u0113\\u018C \\u010E\\u0113\\u0192\\u0113\\u010B\\u0163]]]\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=[[[\\u010E\\u0113\\u0192\\u0113\\u010B\\u0163]]]\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=[[[\\u0143\\u014F\\u0163\\u0113\\u015F]]]\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=[[[\\u015C\\u0163\\u0105\\u0163\\u0171\\u015F]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=[[[\\u0143\\u0113\\u0175]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=[[[\\u012C\\u014B \\u01A4\\u0157\\u014F\\u010B\\u0113\\u015F\\u015F]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=[[[\\u0108\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113\\u018C]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=[[[\\u015C\\u0171\\u010B\\u010B\\u0113\\u015F\\u015F\\u0192\\u0171\\u013A]]]\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=[[[\\u0162\\u014F\\u018C\\u0105\\u0177]]]\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=[[[\\u010E\\u0105\\u0177\\u015F \\u0163\\u014F \\u018C\\u0171\\u0113 \\u018C\\u0105\\u0163\\u0113]]]\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=[[[\\u010E\\u0105\\u0177\\u015F \\u014F\\u028B\\u0113\\u0157\\u018C\\u0171\\u0113]]]\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=[[[\\u010E\\u0105\\u0177 \\u0163\\u014F \\u018C\\u0171\\u0113 \\u018C\\u0105\\u0163\\u0113]]]\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=[[[\\u010E\\u0105\\u0177 \\u014F\\u028B\\u0113\\u0157\\u018C\\u0171\\u0113]]]\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=[[[\\u0100\\u018C\\u018C]]]\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=[[[\\u0143\\u014F\\u0163\\u0113 \\u0105\\u018C\\u018C\\u0113\\u018C]]]\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=[[[\\u0158\\u0113\\u0105\\u015F\\u015F\\u012F\\u011F\\u014B]]]\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=[[[\\u0158\\u0113\\u0105\\u015F\\u015F\\u012F\\u011F\\u014B \\u0162\\u0105\\u015F\\u0137]]]\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=[[[\\u0162\\u014F]]]\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=[[[\\u0108\\u0125\\u014F\\u014F\\u015F\\u0113 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B]]]\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=[[[\\u0143\\u014F \\u03C1\\u0113\\u0157\\u015F\\u014F\\u014B\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113]]]\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=[[[\\u039C\\u0105\\u014B\\u018C\\u0105\\u0163\\u014F\\u0157\\u0177 \\u0192\\u012F\\u0113\\u013A\\u018C]]]\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=[[[\\u012C\\u014B\\u028B\\u0105\\u013A\\u012F\\u018C \\u012F\\u014B\\u03C1\\u0171\\u0163]]]\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=[[[\\u0162\\u0105\\u015F\\u0137 \\u0157\\u0113\\u0105\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C]]]\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A]]]\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=[[[\\u015C\\u0113\\u0163\\u0163\\u012F\\u014B\\u011F\\u015F ]]]\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=[[[\\u010E\\u012F\\u015F\\u03C1\\u013A\\u0105\\u0177 {0} \\u0162\\u0105\\u015F\\u0137\\u015F]]]\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=[[[\\u010E\\u012F\\u015F\\u03C1\\u013A\\u0105\\u0177 1 \\u0162\\u0105\\u015F\\u0137]]]\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=[[[\\u0143\\u0171\\u0271\\u0183\\u0113\\u0157 \\u014F\\u0192 \\u0162\\u0105\\u015F\\u0137\\u015F]]]\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=[[[\\u0162\\u014F]]]\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=[[[\\u0114\\u014B\\u0163\\u0113\\u0157 \\u0113\\u014B\\u018C \\u018C\\u0105\\u0163\\u0113 \\u0192\\u014F\\u0157 \\u0192\\u012F\\u013A\\u0163\\u0113\\u0157\\u012F\\u014B\\u011F]]]\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=[[[\\u0114\\u014B\\u0163\\u0113\\u0157 \\u015F\\u0163\\u0105\\u0157\\u0163 \\u018C\\u0105\\u0163\\u0113 \\u0192\\u014F\\u0157 \\u0192\\u012F\\u013A\\u0163\\u0113\\u0157\\u012F\\u014B\\u011F]]]\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=[[[\\u0191\\u0157\\u014F\\u0271]]]\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=[[[\\u0191\\u012F\\u013A\\u0163\\u0113\\u0157\\u0113\\u018C \\u0183\\u0177 ]]]{0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=[[[\\u015C\\u0113\\u0163\\u0163\\u012F\\u014B\\u011F\\u015F]]]\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=[[[\\u014E\\u028B\\u0113\\u0157\\u018C\\u0171\\u0113]]]\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u0105\\u010B\\u0125\\u012F\\u014B\\u011F \\u010E\\u0171\\u0113 \\u010E\\u0105\\u0163\\u0113]]]\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=[[[\\u0191\\u0105\\u0157 \\u0192\\u0157\\u014F\\u0271 \\u010E\\u0171\\u0113 \\u010E\\u0105\\u0163\\u0113]]]\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=[[[\\u0174\\u012F\\u0163\\u0125\\u014F\\u0171\\u0163 \\u010E\\u0171\\u0113 \\u010E\\u0105\\u0163\\u0113]]]\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=[[[\\u0143\\u014F\\u014B\\u0113]]]\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=[[[\\u0100\\u018C\\u018C\\u0113\\u018C \\u014F\\u014B {0} \\u0183\\u0177 ]]]{1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=[[[\\u0143\\u014F \\u0192\\u012F\\u013A\\u0113 \\u014B\\u0105\\u0271\\u0113]]]\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=[[[\\u013B\\u014F\\u0105\\u018C\\u012F\\u014B\\u011F...]]]\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=[[[\\u0143\\u014F \\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u0162\\u0105\\u015F\\u0137\\u015F \\u0100\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113]]]\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=[[[\\u012C\\u014B\\u028B\\u0105\\u013A\\u012F\\u018C \\u010E\\u0105\\u0163\\u0113 \\u0114\\u014B\\u0163\\u0113\\u0157\\u0113\\u018C]]]\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=[[[\\u0162\\u014F \\u010E\\u0105\\u0163\\u0113 \\u015F\\u0125\\u014F\\u0171\\u013A\\u018C \\u0183\\u0113 \\u0113\\u01A3\\u0171\\u0105\\u013A \\u0163\\u014F \\u014F\\u0157 \\u013A\\u0105\\u0163\\u0113\\u0157 \\u0163\\u0125\\u0105\\u014B \\u0191\\u0157\\u014F\\u0271 \\u010E\\u0105\\u0163\\u0113]]]\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_en_US_saptrc.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=ijojDSJv1gCGBJD2WdKK/Q_My Quality Tasks ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=QN/DvuWxJVMDzUAa8x7cvw_Complete Task\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=cyw+x9kibPX9nAPMb94KvQ_Task completed\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=teHOZdTuqKG9ZCdptRPkpw_Comment\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=gFUvjtmZRX98kPSWPqX+LA_Are you sure you want to complete this task?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=6fks38ehEd5SJU7qOELv0g_Complete Task\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=8uVbCrEQZHL2q5umQK2mNQ_OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=lQfhkUg4SdFdg1kB2NKisQ_My Quality Task\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=7nm79GzF7Oa/kL+fGJqLpA_Task\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=I7+fzRmXrJOdad8JLgIh0g_Task Code\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=5Jc7x71T0sPVXFrLY1+U1g_Description\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=++TOAV5Mko81pZ4v8xV+SA_Detailed Description\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=skfVlXCowvHYotPIUowydw_Start Date\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=SNSc/i6+wgZp/U6H+5JlWw_Due Date\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=iamEGaOMpjhzdv3hcvQJfA_Quality Notification\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=NO8bSdEDmTFoPN5MhGHzHQ_Notification\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=V60WfxSRHuSotB/I+XEZ5g_Notification Type\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=gTGoAZ2MatmyoQYaEX6YKw_Assigned To\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=8MmzubU4rqWZWBHA1GgVgQ_Priority\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=R1ghs+gsds0wZK6V0er4nQ_Related Defect\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=N60kUhpeSC+LPGMPNq0S5A_Defect\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=HZvftcAcEzdcoPipkPsomw_Notes\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=TDosKtz966+Iamv6u14RRQ_Status\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=CxE6xALIilwhNKcueysZbQ_New\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=EbLfUcCJYB7pmyYEolZNbg_In Process\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=zA6ss1CK4yRAwEB//+6nuw_Completed\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=8RjfGnawhn8+pLA44891OQ_Successful\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=CMdQfcgyyLw9ooQUWEos0Q_Today\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=u7zNLN8/ETTB7xGa8hkMUg_Days to due date\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=3Y62gIduDL1LmFKYbmPKSA_Days overdue\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=golBlSQCAluXAbdL7idP/w_Day to due date\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=ZjKwz6d7anz6WC5aIgdciw_Day overdue\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=410umlIKiOE6SyT6BX4+ag_Add\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=FPNhJRoKFPZQ05IfoL7RKg_Note added\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=O03NdIMLMyBBKf6EveNHrQ_Reassign\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=RcPwUEtmfGicNBl0qKN8BA_Reassign Task\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=9brK/0Oo2cQKtu3N3s8hBQ_To\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=K50zCNC4GUGDoVvdaW1q8g_Choose Person\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=iq6XHFdCnP5gc/D+8JMMoA_No persons available\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=GeOYDm/5NBVXOSRX0xlQXA_Mandatory field\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=AvcbwGMvjC+nuWaGenqz6A_Invalid input\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=cJHNCpML11ZHMSVw6gyqEA_Task reassigned\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=p+hYjmCSmlEYd7Lw0rp3SQ_Cancel\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=jsca4Qehp/ePay7f2HxbEw_Settings \n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=E96OcKAH9dF5Sf9sOYjZsw_Display {0} Tasks\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=JDL36dy/Red7n23TLkcl1Q_Display 1 Task\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=jBR3oBa206hhYqXwhay8TA_Number of Tasks\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=t0maC4+g5/8Omkrff1a0jQ_To\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=5ZVYEfJra8N+PwF5Omy/8Q_Enter end date for filtering\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=7B1oCECZiK3b3cE7erC0vQ_Enter start date for filtering\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=qJ1qetDp23p2I2VyHHMoIQ_From\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=2KukVSC2M1Use07xUTuYRQ_Filtered by {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=ivnXGsALQ2MMhmyjn9bxIQ_Settings\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Z+KjSdIImO7NJSVFXli2cQ_Overdue\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=wkdXWLxRwGCTt/D8IZLUig_Approaching Due Date\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=4rr6DoWPqTZ1inclfNyDZw_Far from Due Date\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=VSNF8hDy1rd0wysMkrlMhg_Without Due Date\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=Apsdj2ZgKaNs7ZGab6RHPw_None\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=C8BmqMZNUwnKPOO1K96KVw_Added on {0} by {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=e6+gtkeBVunlAI7KmKPwYw_No file name\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=qED5wLBcPY5lVCqaDAyI9A_Loading...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=9WTzjbZn19smjZ9VLzQy0Q_No Quality Tasks Available\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=bbBO1iIBfIRrSQR2ahOF+w_Invalid Date Entered\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=iUjSmTesuyQqjynKVLBeLQ_To Date should be equal to or later than From Date\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_es.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Mis medidas de calidad ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Completar med.\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Medida completada\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Comentario\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=\\u00BFSeguro que desea completar esta medida?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Completar medida\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Mi medida de calidad\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Medida\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=C\\u00F3digo de medida\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Descripci\\u00F3n\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Descripci\\u00F3n detallada\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Fecha de inicio\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Fecha de vencimiento\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Aviso de calidad\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Aviso\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Clase de aviso\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Asignado a\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Prioridad\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Defecto relacionado\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Defecto\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notas\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Estado\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Nueva\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=En proceso\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Completada\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Correcta\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Hoy\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=D\\u00EDas para fecha de vencimiento\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=D\\u00EDas de retraso\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=D\\u00EDa para fecha de vencimiento\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=D\\u00EDa de retraso\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=A\\u00F1adir\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Nota a\\u00F1adida\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Reasignar\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Reasignar medida\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=Para\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Seleccionar persona\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=No hay personas disponibles\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Campo obligatorio\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Entrada no v\\u00E1lida\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Medida reasignada\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Cancelar\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Opciones\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Visualizar {0} medidas\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Visualizar 1 medida\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Cantidad de medidas\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=Hasta\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Introduzca la fecha de fin para filtrar\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Introduzca la fecha de inicio para filtrar\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Desde\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtrado por {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Opciones\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=Atraso\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Fecha de vencimiento pr\\u00F3xima\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Fecha de vencimiento lejana\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Sin fecha de vencimiento\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Ninguno\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=A\\u00F1adido el {0} por {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Sin nombre de fichero\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Cargando...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=No hay tareas de calidad disponibles\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Fecha no v\\u00E1lida indicada\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=La fecha de fin debe ser igual o posterior a la fecha de inicio\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_fr.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Mes interventions qualit\\u00E9 ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Terminer\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Intervention termin\\u00E9e\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Commentaire\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Voulez-vous vraiment terminer cette intervention ?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Terminer intervention\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Mon intervention qualit\\u00E9\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Intervention\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Code d\'intervention\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Description\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Description d\\u00E9taill\\u00E9e\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Date de d\\u00E9but\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=\\u00C9ch\\u00E9ance\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Avis QM\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Avis\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Type d\'avis\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Affect\\u00E9 \\u00E0\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priorit\\u00E9\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=D\\u00E9faut li\\u00E9\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=D\\u00E9faut\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notes\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Statut\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Nouv.\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=En cours de traitement\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Termin\\u00E9e\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Correctement termin\\u00E9e\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Aujourd\'hui\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=jours jusqu\'\\u00E0 l\'\\u00E9ch\\u00E9ance\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=jours de retard\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=jour jusqu\'\\u00E0 l\'\\u00E9ch\\u00E9ance\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=jour de retard\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Ajouter\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Note ajout\\u00E9e\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=R\\u00E9affecter\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=R\\u00E9affecter intervention\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=\\u00E0\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=S\\u00E9lectionner la personne\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Personne n\'est disponible\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Zone obligatoire\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Entr\\u00E9e non valide\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Intervention r\\u00E9affect\\u00E9e\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Interrompre\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Options\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Afficher {0} t\\u00E2ches\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Afficher une intervention\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Nombre d\'interventions\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=au\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Saisir date de fin pour le filtre\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Saisir date de d\\u00E9but pour le filtre\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=du\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtr\\u00E9 par {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Options\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=En retard\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Ech\\u00E9ance proche\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Ech\\u00E9ance loin\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Aucune \\u00E9ch\\u00E9ance\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=N\\u00E9ant\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Ajout\\u00E9 le {0} par {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Aucun nom de fichier\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Chargement...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Aucune intervention qualit\\u00E9 disponible\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Saisie de date erron\\u00E9e\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=La date de fin doit \\u00EAtre identique ou ult\\u00E9rieure \\u00E0 la date de d\\u00E9but.\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_hr.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=Moji zadaci kvalitete ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=Dovr\\u0161i zadatak\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=Zadatak dovr\\u0161en\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=Komentar\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=\\u017Delite li zaista dovr\\u0161iti ovaj zadatak?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=Dovr\\u0161i zadatak\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=U redu\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=Moji zadaci kvalitete\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=Zadatak\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=\\u0160ifra zadatka\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=Opis\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=Detaljni opis\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=Po\\u010Detni datum\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=Datum dospije\\u0107a\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=Obavijest o kvaliteti\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=Obavijest\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=Tip obavijesti\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=Dodijeljeno\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=Prioritet\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=Povezani nedostatak\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=Nedostatak\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=Bilje\\u0161ke\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=Status\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=Novo\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=U obradi\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=Dovr\\u0161en\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=Uspje\\u0161an\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=Danas\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=Dani do datuma dospije\\u0107a\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=Dani prekora\\u010Denja\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=Dan do datuma dospije\\u0107a\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=Dan prekora\\u010Denja\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=Dodaj\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=Bilje\\u0161ka dodana\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=Predod.\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=Predodijeli zadatak\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=Do\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=Izaberi osobu\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=Osobe nisu raspolo\\u017Eive\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=Obavezno polje\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=Neva\\u017Ee\\u0107i unos\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=Zadatak predodijeljen\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=Otka\\u017Ei\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=Postave\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=Prika\\u017Ei {0} zadataka\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=Prika\\u017Ei 1 zadatak\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=Broj zadataka\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=Do\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=Unesite zavr\\u0161ni datum za filtriranje\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=Unesite po\\u010Detni datum za filtriranje\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=Od\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=Filtrirano prema {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=Postave\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Prekora\\u010Deno\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=Pribli\\u017Eavanje datumu dospije\\u0107a\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=Daleko od datuma dospije\\u0107a\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=Bez datuma dospije\\u0107a\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=Nijedan\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=Dodano dana {0} od {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=Nema naziva datoteke\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=U\\u010Ditavanje...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=Zadaci kvalitete nisu raspolo\\u017Eivi\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=Unesen neva\\u017Ee\\u0107i datum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Datum do mora biti jednak datumu od ili prije njega\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_hu.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Saj\\u00E1t min\\u0151s\\u00E9g-tennival\\u00F3k ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Tenniv. lez\\u00E1r.\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Tennvial\\u00F3 lez\\u00E1rva\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Megjegyz\\u00E9s\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Val\\u00F3ban szeretn\\u00E9 befejezni ezt a tennival\\u00F3t?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Tennival\\u00F3 lez\\u00E1r\\u00E1sa\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=Rendben\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Saj\\u00E1t tennival\\u00F3k\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Tennival\\u00F3\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Tennival\\u00F3 k\\u00F3dja\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Le\\u00EDr\\u00E1s\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=R\\u00E9szletes le\\u00EDr\\u00E1s\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Kezd\\u0151 d\\u00E1tum\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Esed\\u00E9kess\\u00E9g d\\u00E1tuma\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Min\\u0151s\\u00E9gjelent\\u00E9s\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Jelent\\u00E9s\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Jelent\\u00E9sfajta\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Hozz\\u00E1rendelve a k\\u00F6vetkez\\u0151h\\u00F6z\\:\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priorit\\u00E1s\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Kapcsol\\u00F3d\\u00F3 hiba\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Hiba\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Megjegyz\\u00E9sek\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=St\\u00E1tus\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=\\u00DAj\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=Feldolgoz\\u00E1s alatt\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Befejez\\u0151d\\u00F6tt\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Sikeres\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Ma\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Az esed\\u00E9kess\\u00E9gi d\\u00E1tumig h\\u00E1tral\\u00E9v\\u0151 napok sz\\u00E1ma\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=K\\u00E9sedelmes napok\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Nap az esed\\u00E9kess\\u00E9gi d\\u00E1tumig\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=K\\u00E9sedelmes napok\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Hozz\\u00E1ad\\u00E1s\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Megjegyz\\u00E9s hozz\\u00E1ad\\u00E1sa\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=\\u00DAjb\\u00F3li hozz\\u00E1r.\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Tennival\\u00F3 \\u00FAjb\\u00F3li hozz\\u00E1rendel\\u00E9se\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=A k\\u00F6vetkez\\u0151h\\u00F6z\\:\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Szem\\u00E9ly kiv\\u00E1laszt\\u00E1sa\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Nem \\u00E9rhet\\u0151k el szem\\u00E9lyek\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=K\\u00F6telez\\u0151 mez\\u0151\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=\\u00C9rv\\u00E9nytelen bevitel\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Tennival\\u00F3 \\u00FAjb\\u00F3l hozz\\u00E1rendelve\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=M\\u00E9gse\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Be\\u00E1ll\\u00EDt\\u00E1sok\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Feladatok {0} megjelen\\u00EDt\\u00E9se\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=1 tennival\\u00F3 megjelen\\u00EDt\\u00E9se\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Tennival\\u00F3k sz\\u00E1ma\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=V\\u00E9ge\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Z\\u00E1r\\u00F3 d\\u00E1tum megad\\u00E1sa sz\\u0171r\\u00E9shez\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Kezd\\u0151 d\\u00E1tum megad\\u00E1sa sz\\u0171r\\u00E9shez\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Kezd\\u00E9s\\:\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Sz\\u0171r\\u00E9s k\\u00F6vetkez\\u0151 szerint\\: {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Be\\u00E1ll\\u00EDt\\u00E1sok\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=K\\u00E9sedelmes\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=K\\u00F6zeli esed\\u00E9kess\\u00E9gi d\\u00E1tum\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Esed\\u00E9kess\\u00E9gi d\\u00E1tumt\\u00F3l messze\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Esed\\u00E9kess\\u00E9gi d\\u00E1tum n\\u00E9lk\\u00FCl\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Nincs\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Hozz\\u00E1adta {0} {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Nincs f\\u00E1jln\\u00E9v\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Bet\\u00F6lt\\u00E9s...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Nem \\u00E1llnak rendelkez\\u00E9sre feladatok\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=A megadott d\\u00E1tum \\u00E9rv\\u00E9nytelen\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=A z\\u00E1r\\u00F3 d\\u00E1tum legfeljebb ugyanakkor, vagy k\\u00E9s\\u0151bb lehet mint a kezd\\u0151 d\\u00E1tum\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_it.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Le mie misure di qualit\\u00E0 ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Compl. misura\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Misura completata\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Commento\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Conferma il completamento di questa misura\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Completa misura\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=La mia misura di qualit\\u00E0\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Misura\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Codice misura\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Descrizione\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Descrizione dettagliata\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Data di inizio\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Data di scadenza\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Avviso di qualit\\u00E0\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Avviso\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Tipo di avviso\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Attribuito a\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priorit\\u00E0\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Difetto correlato\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Difetto\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Note\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Stato\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Nuovo\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=In elaborazione\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Completato\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Corretto\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Oggi\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Giorni alla scadenza\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=Giorni di ritardo\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Giorno alla scadenza\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=Giorno di ritardo\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Aggiungi\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Nota aggiunta\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Riattribuisci\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Riattribuisci misura\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=A\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Seleziona persona\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Nessuna persona disponibile\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Campo obbligatorio\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Input non valido\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Misura riattribuita\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Annulla\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Impostazioni\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Visualizza {0} misure\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Visualizza 1 misura\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Numero di misure\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=A\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Inserisci data di fine per filtro\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Inserisci data di inizio per filtro\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Da\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtrato in base a {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Impostazioni\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=In ritardo\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Scadenza imminente\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Scadenza lontana\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Senza scadenza\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Nessuno\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Aggiunto il {0} da {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Nessun nome file\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=In caricamento...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Nessuna misura di qualit\\u00E0 disponibile\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Data non valida inserita\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=La data di fine dovrebbe essere uguale o successiva alla data di inizio\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_iw.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D5\\u05EA \\u05D4\\u05D0\\u05D9\\u05DB\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9 ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=\\u05D4\\u05E9\\u05DC\\u05DD \\u05DE\\u05E9\\u05D9\\u05DE\\u05D4\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=\\u05D4\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05D4\\u05D5\\u05E9\\u05DC\\u05DE\\u05D4\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=\\u05D4\\u05E2\\u05E8\\u05D4\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=\\u05D4\\u05D0\\u05DD \\u05D0\\u05EA\\u05D4 \\u05D1\\u05D8\\u05D5\\u05D7 \\u05E9\\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D4\\u05E9\\u05DC\\u05D9\\u05DD \\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05D6\\u05D5?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=\\u05D4\\u05E9\\u05DC\\u05DD \\u05DE\\u05E9\\u05D9\\u05DE\\u05D4\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=\\u05DE\\u05E9\\u05D9\\u05DE\\u05EA \\u05D4\\u05D0\\u05D9\\u05DB\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=\\u05E7\\u05D5\\u05D3 \\u05DE\\u05E9\\u05D9\\u05DE\\u05D4\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8 \\u05DE\\u05E4\\u05D5\\u05E8\\u05D8\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05EA\\u05D7\\u05DC\\u05D4\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=\\u05DE\\u05D5\\u05E2\\u05D3 \\u05E4\\u05D9\\u05E8\\u05E2\\u05D5\\u05DF\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=\\u05D4\\u05D5\\u05D3\\u05E2\\u05EA \\u05D0\\u05D9\\u05DB\\u05D5\\u05EA\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=\\u05D4\\u05D5\\u05D3\\u05E2\\u05D4\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=\\u05E1\\u05D5\\u05D2 \\u05D4\\u05D5\\u05D3\\u05E2\\u05D4\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=\\u05DE\\u05D5\\u05E7\\u05E6\\u05D4 \\u05DC-\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=\\u05E2\\u05D3\\u05D9\\u05E4\\u05D5\\u05EA\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=\\u05E4\\u05D2\\u05DD \\u05E7\\u05E9\\u05D5\\u05E8\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=\\u05E4\\u05D2\\u05DD\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=\\u05D4\\u05E2\\u05E8\\u05D5\\u05EA\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=\\u05E1\\u05D8\\u05D0\\u05D8\\u05D5\\u05E1\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=\\u05D7\\u05D3\\u05E9\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=\\u05D1\\u05EA\\u05D4\\u05DC\\u05D9\\u05DA\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=\\u05D4\\u05D5\\u05E9\\u05DC\\u05DD\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=\\u05DE\\u05D5\\u05E6\\u05DC\\u05D7\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=\\u05D4\\u05D9\\u05D5\\u05DD\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=\\u05D9\\u05DE\\u05D9\\u05DD \\u05E2\\u05D3 \\u05DC\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05D9\\u05E2\\u05D3\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=\\u05D9\\u05DE\\u05D9\\u05DD \\u05D1\\u05D0\\u05D9\\u05D7\\u05D5\\u05E8\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=\\u05D9\\u05D5\\u05DD \\u05DC\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D9\\u05E2\\u05D3\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=\\u05D9\\u05D5\\u05DD \\u05D1\\u05D0\\u05D9\\u05D7\\u05D5\\u05E8\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=\\u05D4\\u05D5\\u05E1\\u05E3\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=\\u05D4\\u05E2\\u05E8\\u05D4 \\u05E0\\u05D5\\u05E1\\u05E4\\u05D4\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=\\u05D4\\u05E7\\u05E6\\u05D4 \\u05DE\\u05D7\\u05D3\\u05E9\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=\\u05D4\\u05E7\\u05E6\\u05D4 \\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05DE\\u05D7\\u05D3\\u05E9\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=\\u05E2\\u05D3\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=\\u05D1\\u05D7\\u05E8 \\u05D0\\u05D3\\u05DD\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=\\u05D0\\u05D9\\u05DF \\u05D0\\u05E0\\u05E9\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=\\u05E9\\u05D3\\u05D4 \\u05D7\\u05D5\\u05D1\\u05D4\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=\\u05E7\\u05DC\\u05D8 \\u05DC\\u05D0 \\u05D7\\u05D5\\u05E7\\u05D9\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=\\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05D4\\u05D5\\u05E7\\u05E6\\u05EA\\u05D4 \\u05DE\\u05D7\\u05D3\\u05E9\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=\\u05D1\\u05D8\\u05DC\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=\\u05D4\\u05D2\\u05D3\\u05E8\\u05D5\\u05EA\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=\\u05D4\\u05E6\\u05D2 {0} \\u05DE\\u05E9\\u05D9\\u05DE\\u05D5\\u05EA\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=\\u05D4\\u05E6\\u05D2 \\u05DE\\u05E9\\u05D9\\u05DE\\u05D4 \\u05D0\\u05D7\\u05EA\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=\\u05DE\\u05E1\\u05E4\\u05E8 \\u05DE\\u05E9\\u05D9\\u05DE\\u05D5\\u05EA\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=\\u05E2\\u05D3\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=\\u05D4\\u05D6\\u05DF \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05E1\\u05D9\\u05D5\\u05DD \\u05DC\\u05E1\\u05D9\\u05E0\\u05D5\\u05DF\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=\\u05D4\\u05D6\\u05DF \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05EA\\u05D7\\u05DC\\u05D4 \\u05DC\\u05E1\\u05D9\\u05E0\\u05D5\\u05DF\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=\\u05DE-\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=\\u05DE\\u05E1\\u05D5\\u05E0\\u05DF \\u05DC\\u05E4\\u05D9 {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=\\u05D4\\u05D2\\u05D3\\u05E8\\u05D5\\u05EA\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D9\\u05E2\\u05D3 \\u05E2\\u05D1\\u05E8\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=\\u05DE\\u05EA\\u05E7\\u05E8\\u05D1 \\u05DC\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05D9\\u05E2\\u05D3\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=\\u05E8\\u05D7\\u05D5\\u05E7 \\u05DE\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05D9\\u05E2\\u05D3\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=\\u05DC\\u05DC\\u05D0 \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D9\\u05E2\\u05D3\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=\\u05DC\\u05DC\\u05D0\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=\\u05E0\\u05D5\\u05E1\\u05E3 \\u05D1\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA {0} \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=\\u05D0\\u05D9\\u05DF \\u05E9\\u05DD \\u05E7\\u05D5\\u05D1\\u05E5\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=\\u05D8\\u05D5\\u05E2\\u05DF...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=\\u05D0\\u05D9\\u05DF \\u05DE\\u05E9\\u05D9\\u05DE\\u05D5\\u05EA \\u05D0\\u05D9\\u05DB\\u05D5\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D5\\u05EA\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=\\u05D4\\u05D5\\u05D6\\u05DF \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05DC\\u05D0 \\u05EA\\u05E7\\u05E3\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=\'\\u05E2\\u05D3 \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\' \\u05E6\\u05E8\\u05D9\\u05DA \\u05DC\\u05D4\\u05D9\\u05D5\\u05EA \\u05D6\\u05D4\\u05D4 \\u05DC\'\\u05DE\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\' \\u05D0\\u05D5 \\u05DC\\u05D7\\u05D5\\u05DC \\u05D0\\u05D7\\u05E8\\u05D9\\u05D5\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_ja.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=\\u54C1\\u8CEA\\u30BF\\u30B9\\u30AF ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=\\u30BF\\u30B9\\u30AF\\u5B8C\\u4E86\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=\\u30BF\\u30B9\\u30AF\\u3092\\u5B8C\\u4E86\\u3057\\u307E\\u3057\\u305F\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=\\u30B3\\u30E1\\u30F3\\u30C8\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=\\u3053\\u306E\\u30BF\\u30B9\\u30AF\\u3092\\u5B8C\\u4E86\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=\\u30BF\\u30B9\\u30AF\\u5B8C\\u4E86\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=\\u54C1\\u8CEA\\u30BF\\u30B9\\u30AF\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=\\u30BF\\u30B9\\u30AF\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=\\u30BF\\u30B9\\u30AF\\u30B3\\u30FC\\u30C9\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=\\u30C6\\u30AD\\u30B9\\u30C8\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=\\u8A73\\u7D30\\u30C6\\u30AD\\u30B9\\u30C8\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=\\u958B\\u59CB\\u65E5\\u4ED8\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=\\u671F\\u65E5\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=\\u54C1\\u8CEA\\u901A\\u77E5\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=\\u901A\\u77E5\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=\\u901A\\u77E5\\u30BF\\u30A4\\u30D7\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=\\u5272\\u5F53\\u5148\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=\\u512A\\u5148\\u5EA6\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=\\u95A2\\u9023\\u4E0D\\u826F\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=\\u4E0D\\u826F\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=\\u30E1\\u30E2\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=\\u30B9\\u30C6\\u30FC\\u30BF\\u30B9\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=\\u65B0\\u898F\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=\\u51E6\\u7406\\u4E2D\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=\\u5B8C\\u4E86\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=\\u6B63\\u5E38\\u7D42\\u4E86\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=\\u672C\\u65E5\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=\\u65E5 (\\u671F\\u65E5\\u307E\\u3067)\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=\\u65E5\\u671F\\u65E5\\u8D85\\u904E\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=\\u65E5 (\\u671F\\u65E5\\u307E\\u3067)\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=\\u65E5\\u671F\\u65E5\\u8D85\\u904E\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=\\u8FFD\\u52A0\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=\\u30E1\\u30E2\\u304C\\u8FFD\\u52A0\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=\\u518D\\u5272\\u5F53\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=\\u30BF\\u30B9\\u30AF\\u518D\\u5272\\u5F53\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=->\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=\\u4EBA\\u7269\\u9078\\u629E\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=\\u9078\\u629E\\u3067\\u304D\\u308B\\u4EBA\\u7269\\u304C\\u3044\\u307E\\u305B\\u3093\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=\\u5165\\u529B\\u5FC5\\u9808\\u9805\\u76EE\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=\\u5165\\u529B\\u304C\\u7121\\u52B9\\u3067\\u3059\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=\\u30BF\\u30B9\\u30AF\\u304C\\u518D\\u5272\\u5F53\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=\\u4E2D\\u6B62\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=\\u8A2D\\u5B9A\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER={0} \\u4EF6\\u306E\\u30BF\\u30B9\\u30AF\\u3092\\u8868\\u793A\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=1 \\u4EF6\\u306E\\u30BF\\u30B9\\u30AF\\u3092\\u8868\\u793A\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=\\u30BF\\u30B9\\u30AF\\u6570\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=\\u7D42\\u4E86\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=\\u30D5\\u30A3\\u30EB\\u30BF\\u306B\\u4F7F\\u7528\\u3059\\u308B\\u7D42\\u4E86\\u65E5\\u4ED8\\u3092\\u5165\\u529B\\u3057\\u307E\\u3059\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=\\u30D5\\u30A3\\u30EB\\u30BF\\u306B\\u4F7F\\u7528\\u3059\\u308B\\u958B\\u59CB\\u65E5\\u4ED8\\u3092\\u5165\\u529B\\u3057\\u307E\\u3059\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=\\u958B\\u59CB\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY={0} \\u3067\\u30D5\\u30A3\\u30EB\\u30BF\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=\\u8A2D\\u5B9A\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=\\u671F\\u65E5\\u8D85\\u904E\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=\\u307E\\u3082\\u306A\\u304F\\u671F\\u65E5\\u5230\\u6765\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=\\u671F\\u65E5\\u307E\\u3067\\u4F59\\u88D5\\u3042\\u308A\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=\\u671F\\u65E5\\u306A\\u3057\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=\\u306A\\u3057\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE={0} \\u306B {1} \\u306B\\u3088\\u3063\\u3066\\u8FFD\\u52A0\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=\\u30D5\\u30A1\\u30A4\\u30EB\\u540D\\u306A\\u3057\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=\\u30ED\\u30FC\\u30C9\\u4E2D...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=\\u54C1\\u8CEA\\u30BF\\u30B9\\u30AF\\u306A\\u3057\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=\\u5165\\u529B\\u3055\\u308C\\u305F\\u65E5\\u4ED8\\u306F\\u7121\\u52B9\\u3067\\u3059\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=\\u7D42\\u4E86\\u65E5\\u4ED8\\u306F\\u958B\\u59CB\\u65E5\\u4ED8\\u4EE5\\u964D\\u306E\\u65E5\\u4ED8\\u3067\\u306A\\u3051\\u308C\\u3070\\u306A\\u308A\\u307E\\u305B\\u3093\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_no.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Mine kvalitetstiltak ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Fullf\\u00F8r tiltak\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Tiltak fullf\\u00F8rt\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Kommentar\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Er du sikker p\\u00E5 at du vil fullf\\u00F8re dette tiltaket?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Fullf\\u00F8r tiltak\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Mitt kvalitetstiltak\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Tiltak\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Tiltakskode\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Beskrivelse\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Detaljert beskrivelse\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Startdato\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Forfallsdato\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Kvalitetsmelding\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Melding\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Meldingstype\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Tilordnet til\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Prioritet\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Relatert feil\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Feil\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Merknader\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Status\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Ny\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=Under behandling\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Fullf\\u00F8rt\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Utf\\u00F8rt\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=I dag\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Dager til forfallsdato\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=dager etter forfall\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Dag til forfallsdato\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=dag etter forfall\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Tilf\\u00F8y\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Merknad tilf\\u00F8yd\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Tilor. p\\u00E5 nytt\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Tilordne tiltak p\\u00E5 nytt\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=Til\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Velg person\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Ingen personer tilgjengelige\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Obligatorisk felt\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Ugyldige inndata\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Tiltak tilordnet p\\u00E5 nytt\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Avbryt\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Innstillinger\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Vis {0} tiltak\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Vis 1 tiltak\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Antall tiltak\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=Til\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Oppgi sluttdato for filtrering\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Oppgi startdato for filtrering\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Fra\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtrert etter {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Innstillinger\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=Forfalt\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Forfallsdato n\\u00E6rmer seg\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Langt fra forfallsdato\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Uten forfallsdato\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Ingen\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Tilf\\u00F8yd den {0} av {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Ingen filnavn\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Laster ...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Ingen tilgjengelige kvalitetstiltak\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Ugyldig dato oppgitt\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Til-dato m\\u00E5 v\\u00E6re lik eller ligge etter fra-dato\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_pl.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Moje zadania ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Zako\\u0144cz zad.\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Zadanie zako\\u0144czone\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Skomentuj\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Czy na pewno chcesz zako\\u0144czy\\u0107 to zadanie?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Zako\\u0144cz zadanie\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Moje zadanie\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Zadanie\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=Kod zadania\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Opis\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Opis szczeg\\u00F3\\u0142owy\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Data rozpocz\\u0119cia\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Termin\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Zawiadomienie QM\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Zawiadomienie\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Typ zawiadomienia\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Przypisane do\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Priorytet\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Powi\\u0105zana wada\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Wada\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notatki\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Status\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Nowe\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=W przetwarzaniu\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Zako\\u0144czone\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Pomy\\u015Blne\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Dzisiaj\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Dni do terminu\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=Dni po terminie\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Dzie\\u0144 do terminu\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=Dzie\\u0144 po terminie\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Dodaj\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Dodano notatk\\u0119\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Przypisz pon.\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Ponowne przypisanie zadania\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=Do\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Wyb\\u00F3r osoby\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Brak dost\\u0119pnych os\\u00F3b\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Pole obowi\\u0105zkowe\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Nieprawid\\u0142owy wpis\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Ponownie przypisano zadanie\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Anuluj\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Ustawienia\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Wy\\u015Bwietl nast\\u0119puj\\u0105c\\u0105 liczb\\u0119 zada\\u0144\\: {0}\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Wy\\u015Bwietl 1 zadanie\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=Liczba zada\\u0144\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=Do\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Wpisz dat\\u0119 ko\\u0144cow\\u0105 dla filtrowania\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Wpisz dat\\u0119 pocz\\u0105tkow\\u0105 dla filtrowania\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Od\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Przefiltrowane wed\\u0142ug {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Ustawienia\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=Zaleg\\u0142e\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Zbli\\u017Ca si\\u0119 termin\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Daleko od terminu\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Bez terminu\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Brak\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Dodane dnia {0} przez {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Brak nazwy pliku\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=\\u0141adowanie...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Brak zada\\u0144 dot. jako\\u015Bci\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Wprowadzono nieprawid\\u0142ow\\u0105 dat\\u0119\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Data Do nie powinna wypada\\u0107 wcze\\u015Bniej ni\\u017C Data Od\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_pt.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Minhas medidas de qualidade ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=Concl.medida\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=Medida conclu\\u00EDda\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=Coment\\u00E1rio\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Concluir essa medida?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=Concluir medida\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=OK\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Minhas medidas de qualidade\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=Medida\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=C\\u00F3d.medida\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Descri\\u00E7\\u00E3o\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Descri\\u00E7\\u00E3o detalhada\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Data de in\\u00EDcio\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Prazo\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Nota QM\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Nota\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Tipo de nota\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=Atribu\\u00EDdo a\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=Prioridade\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=Defeito relacionado\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Defeito\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notas\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Status\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Nova\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=Em andamento\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Conclu\\u00EDda\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Com \\u00EAxito\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Hoje\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Dias at\\u00E9 prazo\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=Dias em atraso\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Dia at\\u00E9 prazo\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=Dia em atraso\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Adicionar\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Nota adicionada\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Reatribuir\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=Reatribuir medida\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=At\\u00E9\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Selecionar pessoa\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Nenhuma pessoa dispon\\u00EDvel\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Campo obrigat\\u00F3rio\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Entrada inv\\u00E1lida\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=Medida reatribu\\u00EDda\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=Anular\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Configura\\u00E7\\u00F5es\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=Exibir {0} tarefas\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=Exibir 1 medida\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=N\\u00BA de medidas\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=At\\u00E9\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Inserir data final para filtragem\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Inserir data de in\\u00EDcio para filtragem\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=De\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtrado por {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Configura\\u00E7\\u00F5es\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=Em atraso\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Prazo pr\\u00F3ximo\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Longe do prazo\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Sem prazo\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Nenhum\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=Adicionado em {0} por {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Arquivo sem nome\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Carregando...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Nenhuma medida de qualidade dispon\\u00EDvel\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Data inv\\u00E1lida inserida\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=A data do fim deve ser igual ou posterior \\u00E0 data de in\\u00EDcio\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_ro.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=Sarcinile mele de calitate ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=Termin.sarcin\\u0103\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=Sarcin\\u0103 terminat\\u0103\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=Comentariu\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=Sigur dori\\u0163i s\\u0103 termina\\u0163i aceast\\u0103 m\\u0103sur\\u0103?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=Terminare m\\u0103sur\\u0103\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=M\\u0103sura mea de calitate\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=M\\u0103sur\\u0103\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=Cod de m\\u0103sur\\u0103\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=Descriere\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=Descriere detaliat\\u0103\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=Dat\\u0103 de \\u00EEnceput\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=Dat\\u0103 scaden\\u0163\\u0103\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=Notificare de calitate\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=Notificare\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=Tip notificare\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=Alocat la\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=Prioritate\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=Defect aferent\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=Defect\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=Note\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=Stare\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=Nou\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=\\u00CEn prelucrare\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=Terminat\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=Reu\\u015Fit\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=Ast\\u0103zi\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=Zile p\\u00E2n\\u0103 la dat\\u0103 scaden\\u0163\\u0103\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=Zile cu scaden\\u0163\\u0103 dep\\u0103\\u015Fit\\u0103\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=Zi p\\u00E2n\\u0103 la dat\\u0103 scaden\\u0163\\u0103\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=Zi cu scaden\\u0163\\u0103 dep\\u0103\\u015Fit\\u0103\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=Ad\\u0103ugare\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=Not\\u0103 ad\\u0103ugat\\u0103\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=Realocare\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=Realocare m\\u0103sur\\u0103\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=P\\u00E2n\\u0103 la\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=Alegere persoan\\u0103\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=F\\u0103r\\u0103 persoane disponibile\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=C\\u00E2mp de intrare obligatorie\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=Intrare nevalabil\\u0103\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=M\\u0103sur\\u0103 realocat\\u0103\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=Anulare\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=Set\\u0103ri\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=Afi\\u015Fare {0} sarcini\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=Afi\\u015Fare 1 m\\u0103sur\\u0103\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=Num\\u0103r de m\\u0103suri\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=P\\u00E2n\\u0103 la\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=Introduce\\u0163i data de sf\\u00E2r\\u015Fit pt.filtrare\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=Introduce\\u0163i data de \\u00EEnceput pt.filtrare\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=De la\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=Filtrat dup\\u0103 {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=Set\\u0103ri\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Cu scaden\\u0163\\u0103 dep\\u0103\\u015Fit\\u0103\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=Dat\\u0103 scaden\\u0163\\u0103 \\u00EEn apropiere\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=Departe de dat\\u0103 scaden\\u0163\\u0103\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=F\\u0103r\\u0103 dat\\u0103 scaden\\u0163\\u0103\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=Nimic\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=Ad\\u0103ugat pe {0} de {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=Niciun nume de fi\\u015Fier\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=\\u00CEnc\\u0103rcare ...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=F\\u0103r\\u0103 m\\u0103suri de calitate disponibile\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=Dat\\u0103 nevalabil\\u0103 introdus\\u0103\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Data p\\u00E2n\\u0103 la trebuie s\\u0103 fie identic\\u0103 sau dup\\u0103 Data de la\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_ru.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=\\u041C\\u043E\\u0438 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0438 \\u043F\\u043E \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=\\u0417\\u0430\\u0432\\u0435\\u0440\\u0448. \\u0437\\u0430\\u0434\\u0430\\u0447\\u0443\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=\\u0417\\u0430\\u0434\\u0430\\u0447\\u0430 \\u0437\\u0430\\u0432\\u0435\\u0440\\u0448\\u0435\\u043D\\u0430\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=\\u041A\\u043E\\u043C\\u043C\\u0435\\u043D\\u0442\\u0430\\u0440\\u0438\\u0439\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=\\u0417\\u0430\\u0432\\u0435\\u0440\\u0448\\u0438\\u0442\\u044C \\u044D\\u0442\\u0443 \\u0437\\u0430\\u0434\\u0430\\u0447\\u0443?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=\\u0417\\u0430\\u0432\\u0435\\u0440\\u0448\\u0438\\u0442\\u044C \\u0437\\u0430\\u0434\\u0430\\u0447\\u0443\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=\\u041E\\u041A\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=\\u041C\\u043E\\u0438 \\u043C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u044F \\u043F\\u043E \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=\\u041C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u0435\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=\\u041A\\u043E\\u0434 \\u043C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u044F\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0435 \\u043E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430\\u0447\\u0430\\u043B\\u0430\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=\\u0421\\u0440\\u043E\\u043A \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=\\u0421\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u0435 \\u043F\\u043E \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=\\u0421\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=\\u0422\\u0438\\u043F \\u0441\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=\\u041F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043E\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=\\u041F\\u0440\\u0438\\u043E\\u0440\\u0438\\u0442\\u0435\\u0442\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=\\u0421\\u0432\\u044F\\u0437\\u0430\\u043D\\u043D\\u044B\\u0439 \\u0434\\u0435\\u0444\\u0435\\u043A\\u0442\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=\\u0414\\u0435\\u0444\\u0435\\u043A\\u0442\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u044F\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=\\u041D\\u043E\\u0432\\u0430\\u044F\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=\\u0412 \\u043E\\u0431\\u0440\\u0430\\u0431\\u043E\\u0442\\u043A\\u0435\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=\\u0412\\u044B\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u043E\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=\\u0423\\u0441\\u043F\\u0435\\u0448\\u043D\\u043E\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=\\u0421\\u0435\\u0433\\u043E\\u0434\\u043D\\u044F\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=\\u0414\\u043D\\u0435\\u0439 \\u0434\\u043E \\u0441\\u0440\\u043E\\u043A\\u0430 \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=\\u0414\\u043D\\u0435\\u0439 \\u043F\\u0440\\u043E\\u0441\\u0440\\u043E\\u0447\\u043A\\u0438\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=\\u0414\\u0435\\u043D\\u044C \\u0434\\u043E \\u0441\\u0440\\u043E\\u043A\\u0430 \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=\\u0414\\u0435\\u043D\\u044C \\u043F\\u0440\\u043E\\u0441\\u0440\\u043E\\u0447\\u043A\\u0438\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u0442\\u044C\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u0435 \\u0434\\u043E\\u0431\\u0430\\u0432\\u043B\\u0435\\u043D\\u043E\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=\\u041F\\u0435\\u0440\\u0435\\u043F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0438\\u0442\\u044C\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=\\u041F\\u0435\\u0440\\u0435\\u043F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0438\\u0442\\u044C \\u043C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u0435\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=\\u041F\\u043E\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=\\u0412\\u044B\\u0431\\u0440\\u0430\\u0442\\u044C \\u043B\\u0438\\u0446\\u043E\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=\\u041B\\u0438\\u0446\\u0430 \\u043D\\u0435\\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=\\u041F\\u043E\\u043B\\u0435 \\u043E\\u0431\\u044F\\u0437\\u0430\\u0442\\u0435\\u043B\\u044C\\u043D\\u043E\\u0433\\u043E \\u0432\\u0432\\u043E\\u0434\\u0430\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=\\u041D\\u0435\\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0432\\u0432\\u043E\\u0434\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=\\u041C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u0435 \\u043F\\u0435\\u0440\\u0435\\u043F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043E\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=\\u041D\\u0430\\u0441\\u0442\\u0440\\u043E\\u0439\\u043A\\u0438\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=\\u041F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C {0} \\u0437\\u0430\\u0434.\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=\\u041F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C 1 \\u043C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u0435\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=\\u0427\\u0438\\u0441\\u043B\\u043E \\u043C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u0439\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=\\u041F\\u043E\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=\\u0412\\u0432\\u0435\\u0441\\u0442\\u0438 \\u043A\\u043E\\u043D\\u0435\\u0447\\u043D\\u0443\\u044E \\u0434\\u0430\\u0442\\u0443 \\u0434\\u043B\\u044F \\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=\\u0412\\u0432\\u0435\\u0441\\u0442\\u0438 \\u043D\\u0430\\u0447\\u0430\\u043B\\u044C\\u043D\\u0443\\u044E \\u0434\\u0430\\u0442\\u0443 \\u0434\\u043B\\u044F \\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=\\u0421\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=\\u041E\\u0442\\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u043E\\u0432\\u0430\\u043D\\u043E \\u043F\\u043E {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=\\u041D\\u0430\\u0441\\u0442\\u0440\\u043E\\u0439\\u043A\\u0438\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=\\u041F\\u0440\\u043E\\u0441\\u0440\\u043E\\u0447\\u0435\\u043D\\u043E\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=\\u041F\\u0440\\u0438\\u0431\\u043B\\u0438\\u0436\\u0430\\u044E\\u0449\\u0438\\u0439\\u0441\\u044F \\u0441\\u0440\\u043E\\u043A \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=\\u0414\\u0430\\u043B\\u0435\\u043A\\u043E \\u0434\\u043E \\u0441\\u0440\\u043E\\u043A\\u0430 \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=\\u0411\\u0435\\u0437 \\u0441\\u0440\\u043E\\u043A\\u0430 \\u0438\\u0441\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=\\u041D\\u0435\\u0442\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u043B {0} {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=\\u041D\\u0435\\u0442 \\u0438\\u043C\\u0435\\u043D\\u0438 \\u0444\\u0430\\u0439\\u043B\\u0430\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=\\u0417\\u0430\\u0433\\u0440\\u0443\\u0437\\u043A\\u0430...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=\\u041C\\u0435\\u0440\\u043E\\u043F\\u0440\\u0438\\u044F\\u0442\\u0438\\u044F \\u043F\\u043E \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u043D\\u0435\\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=\\u0412\\u0432\\u0435\\u0434\\u0435\\u043D\\u0430 \\u043D\\u0435\\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u0430\\u044F \\u0434\\u0430\\u0442\\u0430\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=\\u0414\\u0430\\u0442\\u0430 \\u043E\\u043A\\u043E\\u043D\\u0447\\u0430\\u043D\\u0438\\u044F \\u0434\\u043E\\u043B\\u0436\\u043D\\u0430 \\u0431\\u044B\\u0442\\u044C \\u043D\\u0435 \\u0440\\u0430\\u043D\\u044C\\u0448\\u0435 \\u0434\\u0430\\u0442\\u044B \\u043D\\u0430\\u0447\\u0430\\u043B\\u0430\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_sh.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=Moji zadaci kvaliteta ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=Zavr\\u0161i zadatak\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=Zadatak zavr\\u0161en\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=Komentar\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=Da li sigurno \\u017Eelite da zavr\\u0161ite ovaj zadatak?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=Zavr\\u0161i zadatak\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=Moj zadatak\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=Zadatak\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=\\u0160ifra zadatka\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=Opis\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=Detaljni opis\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=Datum po\\u010Detka\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=Datum dospe\\u0107a\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=Obave\\u0161tenje o kvalitetu\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=Obave\\u0161tenje\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=Tip obave\\u0161tenja\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=Dodeljeno\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=Prioritet\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=Povezani nedostatak\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=Gre\\u0161ka\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=Bele\\u0161ke\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=Status\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=Novo\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=U obradi\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=Zavr\\u0161eno\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=Uspe\\u0161no\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=Danas\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=Dani do datuma dospe\\u0107a\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=Dana zakasnelo\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=Dan do datuma dospe\\u0107a\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=Dan zakasnelo\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=Dodaj\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=Bele\\u0161ka dodata\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=Ponovo dodeli\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=Ponovo dodeli zadatak\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=Do\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=Izaberi lice\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=NEma dostupnog lica\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=Obavezno polje\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=Neva\\u017Ee\\u0107i unos\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=Zadatak ponovo dodeljen\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=Odustani\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=Pode\\u0161avanja\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=Prika\\u017Ei {0} zadataka\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=Prika\\u017Ei 1 zadatak\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=Broj zadataka\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=Do\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=Unesi datum zavr\\u0161etka za filtriranje\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=Unesi datum po\\u010Detka za filtriranje\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=Od\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=Filtrirano po {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=Pode\\u0161avanja\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Zastarelo\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=Blizu datuma dospe\\u0107a\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=Daleko od datuma dospe\\u0107a\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=Bez datuma dospe\\u0107a\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=Nijedan\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=Dodato {0} od strane {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=Nema naziva fajla\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=U\\u010Ditavanje...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=Zadaci kvaliteta nisu dostupni\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=Unet neva\\u017Ee\\u0107i datum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Datum zavr\\u0161etka treba da bude jednak datumu po\\u010Detka ili kasniji od njega\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_sk.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=Moje \\u00FAlohy kvality ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=Dokon\\u010Di\\u0165 \\u00FAlohu\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=\\u00DAloha dokon\\u010Den\\u00E1\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=Koment\\u00E1r\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=Naozaj chcete t\\u00FAto \\u00FAlohu dokon\\u010Di\\u0165?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=Dokon\\u010Di\\u0165 \\u00FAlohu\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=Moja \\u00FAloha kvality\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=\\u00DAloha\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=K\\u00F3d \\u00FAlohy\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=Popis\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=Detailn\\u00FD popis\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=Po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=Term\\u00EDn splnenia\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=Hl\\u00E1senie kvality\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=Hl\\u00E1senie\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=Druh hl\\u00E1senia\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=Priraden\\u00E9 k\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=Priorita\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=S\\u00FAvisiaca chyba\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=Chyba\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=Pozn\\u00E1mky\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=Stav\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=Nov\\u00E9\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=V spracovan\\u00ED\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=Dokon\\u010Den\\u00E9\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=\\u00DAspe\\u0161n\\u00E9\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=Dnes\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=dn\\u00ED do term\\u00EDnu\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=dn\\u00ED po term\\u00EDne\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=de\\u0148 do term\\u00EDnu\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=de\\u0148 po term\\u00EDne\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=Prida\\u0165\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=Pozn\\u00E1mka pridan\\u00E1\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=Znova priradi\\u0165\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=Znova priradi\\u0165 \\u00FAlohu\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=Pre\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=Zvoli\\u0165 osobu\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne osoby\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=Povinn\\u00E9 pole\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=Neplatn\\u00E9 zadanie\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=\\u00DAloha znova priraden\\u00E1\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=Zru\\u0161i\\u0165\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=Nastavenia\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=Zobrazi\\u0165 {0} \\u00FAloh\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=Zobrazi\\u0165 1 \\u00FAlohu\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=Po\\u010Det \\u00FAloh\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=Do\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=Zadajte koncov\\u00FD d\\u00E1tum pre filtrovanie\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=Zadajte po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum pre filtrovanie\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=Od\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=Filtrovan\\u00E9 pod\\u013Ea {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=Nastavenia\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Po term\\u00EDne\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=Bl\\u00ED\\u017Eiaci sa term\\u00EDn\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=\\u010Ealeko od term\\u00EDnu\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=Bez term\\u00EDnu\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=\\u017Diadne\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=Pridan\\u00E9 {0}, pridal {1}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=\\u017Diadny n\\u00E1zov s\\u00FAboru\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=Na\\u010D\\u00EDtava sa...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne \\u00FAlohy kvality\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=Bol zadan\\u00FD neplatn\\u00FD d\\u00E1tum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Koncov\\u00FD d\\u00E1tum mus\\u00ED by\\u0165 rovnak\\u00FD alebo neskor\\u0161\\u00ED ako po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_sl.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the section that lists all created quality tasks\nMASTER_TITLE=Moji ukrepi za kakovost ({0})\n\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\nQT_BUTTON_FINISH_TASK=Zaklju\\u010D.naloge\n\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\nQT_TXT_VALIDATION=Naloga zaklju\\u010Dena\n\n#XFLD: Label of the field in which you insert a comment when you reassign a task\nQT_COMMENT=Komentar\n\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\nQT_COMPL_QUESTION=Res \\u017Eelite zaklju\\u010Diti to nalogo?\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_TITLE=Zaklju\\u010Dek naloge\n\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\nQT_CONFIRM_BTN=OK\n\n#XTIT: Title of the task detail section that opens when you choose a task from the list\nDETAIL_TITLE=Moj ukrep za kakovost\n\n#XTIT: Title of the task details area\nQT_DV_TITLE_TASK_INFO=Naloga\n\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\nQT_TASK_CODE_TEXT=Koda naloge\n\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DESCR=Opis\n\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\nQT_DV_DETAIL_DESCR=Detajlni opis\n\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\nQT_DV_START_DATE=Datum za\\u010Detka\n\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_DV_DUE_DATE=Rok\n\n#XTIT: Title of the details area of the Quality Notification that is related to the task\nQT_DV_TITLE_QN_INFO=Obvestilo o kakovosti\n\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION=Obvestilo\n\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\nQT_DV_NOTIFICATION_TYPE=Vrsta obvestila\n\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\nQT_DV_ASSIGNED_TO=Dodeljeno za\n\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\nQT_DV_NOTIF_PRIORITY=Prioriteta\n\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\nQT_DV_REL_DEFECT=Povezana napaka\n\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\nQT_DV_DEFECT=Napaka\n\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\nQT_DV_TITLE_NOTES=Zabele\\u017Eke\n\n# Texts related to the status of a quality task\n\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\nQT_STATUS_TEXT=Status\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_NEW=Novo\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_IN_PROCESS=V obdelavi\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_COMPLETED=Zaklju\\u010Deno\n\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\nQT_STATUS_SUCCESSFUL=Uspe\\u0161no\n\n# Texts related to the due dates used in a quality task\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\nQT_TODAY=Danes\n\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN=Dnevi do datuma zapadlosti\n\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE=Zapadli dnevi\n\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DUE_IN_ONE=Dnevi do datuma zapadlosti\n\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\nQT_DAYS_OVERDUE_ONE=Zapadli dnevi\n\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\nQT_BUTTON_NOTE_SUBMIT=Dodajanje\n\n#XMSG: A message that appears after you add a note.\nQT_NOTES_TXT_VALIDATION=Zabele\\u017Eka dodana\n\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\nQT_BUTTON_REASSIGN_TASK=Predodelitev\n\n#XTIT: Label of the dialog with which you reassign a quality task\nQT_REASSIGN_TASK_DIALOG=Predodelitev naloge\n\n#XFLD: Label of the "To" field in the "Reassign task" dialog\nQT_REASSIGN_TASK_DLG_TO=Do\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \nQT_PERSON_DIALOG_TITLE=Izbira osebe\n\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \nQT_PERSON_DIALOG_EMPTY_MSG=Ni razpolo\\u017Eljivih oseb\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \nQT_MISSING_INPUT_ERROR=Obvezno polje\n\n#XMSG: Text of the message that indicates invalid user input in a field. \nQT_INVALID_INPUT_ERROR=Neveljaven vnos\n\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\nQT_REASSIGN_TXT_VALIDATION=Naloga predodeljena\n\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\nQT_BUTTON_CLOSE=Prekinitev\n\n#XTIT: Label of the settings dialog \nQT_SETTIGS_DIALOG_TITLE=Nastavitve\n\n#XFLD: Label of the max number quality tasks in the settings dialog\nQT_MAX_NUMBER=Prikaz {0} nalog\n\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \nQT_MAX_NUMBER_ONE=Prikaz 1 naloge\n\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \nQT_TASKS_NUMBER=\\u0160tevilo nalog\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_TO=Do\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQT_TO_TOOLTIP=Vnos datuma konca za filtriranje\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQT_FROM_TOOLTIP=Vnos datuma za\\u010Detka za filtriranje\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQT_FROM=Od\n\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\nQT_FILTERED_BY=Filtrirano po {0}\n\n#XBUT: Label of the settings dialog button\nQT_BUTTON_SETTINGS=Nastavitve\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_OVER_COM=Zapadlo\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_APPROACH=Datum zapadlosti se bli\\u017Ea\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_FAR=Dale\\u010D do datuma zapadlosti\n\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\nQT_GRP_WITHOUT=Brez datuma zapadlosti\n\n#XBUT: Label of the option that clears filtering and grouping of issues\nQT_CLEAR=Brez\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQT_ATT_DOC_DATE=Dodal {1} dne {0}\n\n#XFLD: Label indicating that the attached file has no name \nQT_ATT_DOC_NAME=Brez naziva datoteke\n\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \nQT_LOADING_TEXT=Nalaganje poteka ...\n\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\nQT_NO_DATA_AVAILABLE=Ni razpolo\\u017Eljivih ukrepov za kakovost\n\n#XMSG: Text of the message that indicates date values in filter are invalid \nQT_INVALID_DATES_ERROR=Vnesen neveljaven datum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Datum konca mora biti enak ali za Datumom za\\u010Detka\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_tr.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=Kalite g\\u00F6revlerim ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=G\\u00F6revi tamamla\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=G\\u00F6rev tamamland\\u0131\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=A\\u00E7\\u0131klama\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=Bu g\\u00F6revi tamamlamak istedi\\u011Finizden emin misiniz?\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=G\\u00F6revi tamamla\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=Tamam\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=Kalite g\\u00F6revim\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=G\\u00F6rev\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=G\\u00F6rev kodu\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=Tan\\u0131m\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=Ayr\\u0131nt\\u0131l\\u0131 tan\\u0131m\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=Ba\\u015Flang\\u0131\\u00E7 tarihi\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=Son tarih\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=Kalite bildirimi\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=Bildirim\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=Bildirim t\\u00FCr\\u00FC\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=\\u015Euna tayin edildi\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=\\u00D6ncelik\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=\\u0130li\\u015Fkili hata\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=Hata\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=Notlar\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=Durum\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=Yeni\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=\\u0130\\u015Fleniyor\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=Tamamland\\u0131\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=Ba\\u015Far\\u0131l\\u0131 oldu\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=Bug\\u00FCn\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=Son tarihe kadar g\\u00FCnler\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=S\\u00FCreyi ge\\u00E7en g\\u00FCnler\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=Son tarihe kadar g\\u00FCn\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=S\\u00FCreyi ge\\u00E7en g\\u00FCn\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=Ekle\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=Not eklendi\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=Yeniden tyn.et\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=G\\u00F6revi yeniden tayin et\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=Biti\\u015F\\:\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=Ki\\u015Fi se\\u00E7\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=Ki\\u015Fi mevcut de\\u011Fil\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=Zorunlu alan\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=Ge\\u00E7ersiz girdi\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=G\\u00F6rev yeniden tayin edildi\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=\\u0130ptal\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=Ayarlar\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER={0} g\\u00F6revleri g\\u00F6r\\u00FCnt\\u00FCle\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=1 g\\u00F6rev g\\u00F6r\\u00FCnt\\u00FCle\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=G\\u00F6rev say\\u0131s\\u0131\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=Biti\\u015F\\:\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=Filtreleme i\\u00E7in biti\\u015F tarihi girin\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=Filtreleme i\\u00E7in ba\\u015Flang\\u0131\\u00E7 tarihi girin\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=Ba\\u015Flang\\u0131\\u00E7\\:\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=Filtreleme \\u00F6l\\u00E7\\u00FCt\\u00FC {0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=Ayarlar\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=S\\u00FCresi ge\\u00E7mi\\u015F\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=Yakla\\u015Fan son tarih\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=Son tarihten uzak\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=Son tarih olmadan\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=Hi\\u00E7biri\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE={0} tarihinde {1} taraf\\u0131ndan eklendi\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=Dosya ad\\u0131 yok\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=Y\\u00FCkleniyor...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=Kalite g\\u00F6revleri mevcut de\\u011Fil\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=Ge\\u00E7ersiz tarih girildi\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=Biti\\u015F tarihi ba\\u015Flang\\u0131\\u00E7 tarihi ile ayn\\u0131 veya sonra olmal\\u0131\r\n',
	"i2d/qm/task/tracknconfirm/i18n/i18n_zh_CN.properties":'# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the section that lists all created quality tasks\r\nMASTER_TITLE=\\u6211\\u7684\\u8D28\\u91CF\\u95EE\\u9898 ({0})\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to finalize a quality task in the "My Quality Task" application\r\nQT_BUTTON_FINISH_TASK=\\u5B8C\\u6210\\u4EFB\\u52A1\r\n\r\n#XMSG: A message that appears after you choose the "Finish Task" pushbutton. Old message "Quality task status was successfully set to Completed"\r\nQT_TXT_VALIDATION=\\u4EFB\\u52A1\\u5DF2\\u5B8C\\u6210\r\n\r\n#XFLD: Label of the field in which you insert a comment when you reassign a task\r\nQT_COMMENT=\\u6CE8\\u91CA\r\n\r\n#XFLD: Label of the field in which you insert a comment when you finalize/reassign a task\r\nQT_COMPL_QUESTION=\\u662F\\u5426\\u786E\\u5B9A\\u8981\\u5B8C\\u6210\\u6B64\\u4EFB\\u52A1\\uFF1F\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_TITLE=\\u5B8C\\u6210\\u4EFB\\u52A1\r\n\r\n#XBUT: Label of the confirmation button of the dialog in which you enter a final comment on the task\r\nQT_CONFIRM_BTN=\\u786E\\u5B9A\r\n\r\n#XTIT: Title of the task detail section that opens when you choose a task from the list\r\nDETAIL_TITLE=\\u6211\\u7684\\u8D28\\u91CF\\u4EFB\\u52A1\r\n\r\n#XTIT: Title of the task details area\r\nQT_DV_TITLE_TASK_INFO=\\u4EFB\\u52A1\r\n\r\n#XMIT: (XBUT) Label indicating the type of a quality task. The label appears as an option of the pushbutton that you use for grouping quality tasks in the list.\r\nQT_TASK_CODE_TEXT=\\u4EFB\\u52A1\\u4EE3\\u7801\r\n\r\n#XFLD: Label of the "Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DESCR=\\u63CF\\u8FF0\r\n\r\n#XFLD: Label of the "Detailed Description" field that appears under the "Task" and "Quality Notification" areas\r\nQT_DV_DETAIL_DESCR=\\u8BE6\\u7EC6\\u63CF\\u8FF0\r\n\r\n#XFLD: Label of the "Start Date" field that appears under the "Task" area\r\nQT_DV_START_DATE=\\u5F00\\u59CB\\u65E5\\u671F\r\n\r\n#XFLD: Label of the "Due Date" field that appears under the "Task" area. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_DV_DUE_DATE=\\u5230\\u671F\\u65E5\\u671F\r\n\r\n#XTIT: Title of the details area of the Quality Notification that is related to the task\r\nQT_DV_TITLE_QN_INFO=\\u8D28\\u91CF\\u901A\\u77E5\r\n\r\n#XFLD: Label of the "Notification" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION=\\u901A\\u77E5\r\n\r\n#XFLD: Label of the "Notification Type" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIFICATION_TYPE=\\u901A\\u77E5\\u7C7B\\u578B\r\n\r\n#XFLD: Label of the "Coordinator" field that appears under the "Quality Notification" area\r\nQT_DV_ASSIGNED_TO=\\u5DF2\\u5206\\u914D\\u5230\r\n\r\n#XFLD: Label of the "Priority" field that appears under the "Quality Notification" area\r\nQT_DV_NOTIF_PRIORITY=\\u4F18\\u5148\\u7EA7\r\n\r\n#XFLD: Label of the "Related Defect" field that appears under the "Quality Notification" area\r\nQT_DV_REL_DEFECT=\\u76F8\\u5173\\u7F3A\\u9677\r\n\r\n#XFLD: Label of the "Defect" field that appears under the "Quality Notification" area\r\nQT_DV_DEFECT=\\u7F3A\\u9677\r\n\r\n#XTIT: Title of the notes area of a quality task. On the UI it is displayed as a flip chart icon\r\nQT_DV_TITLE_NOTES=\\u6CE8\\u91CA\r\n\r\n# Texts related to the status of a quality task\r\n\r\n#XFLD: (XMIT) Label of the "Status" field that appears in the list of quality tasks. The label also appears as an option of the pushbutton that you use for sorting the list of quality tasks.\r\nQT_STATUS_TEXT=\\u72B6\\u6001\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_NEW=\\u65B0\\u5EFA\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_IN_PROCESS=\\u5904\\u7406\\u4E2D\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_COMPLETED=\\u5DF2\\u5B8C\\u6210\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality task. The label also appears as an option of the pushbutton that you use for filtering the list of quality tasks.\r\nQT_STATUS_SUCCESSFUL=\\u6210\\u529F\r\n\r\n# Texts related to the due dates used in a quality task\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task.\r\nQT_TODAY=\\u4ECA\\u5929\r\n\r\n#XMSG: Message indicating the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN=\\u5230\\u5230\\u671F\\u65E5\\u7684\\u5929\\u6570\r\n\r\n#XMSG: Message indicating the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE=\\u903E\\u671F\\u5929\\u6570\r\n\r\n#XMSG: Message indicating 1 day the period in which the finalization of a quality task is required. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DUE_IN_ONE=\\u8DDD\\u5230\\u671F\\u65E5\\u5929\\u6570\r\n\r\n#XMSG: Message indicating 1 day the delay of a quality task. The message appears in the list of quality tasks and in the header of the selected task. There are 2 lines on the UI: the first one indicates number, and the second one this message.\r\nQT_DAYS_OVERDUE_ONE=\\u903E\\u671F\\u5929\\u6570\r\n\r\n#XBUT: Label of the pushbutton that is used to add notes to a quality task in the "My Quality Task" application\r\nQT_BUTTON_NOTE_SUBMIT=\\u6DFB\\u52A0\r\n\r\n#XMSG: A message that appears after you add a note.\r\nQT_NOTES_TXT_VALIDATION=\\u5DF2\\u6DFB\\u52A0\\u6CE8\\u91CA\r\n\r\n#XBUT, 14: Label of the pushbutton that is used to reassign a quality task in the "My Quality Task" application\r\nQT_BUTTON_REASSIGN_TASK=\\u91CD\\u65B0\\u5206\\u914D\r\n\r\n#XTIT: Label of the dialog with which you reassign a quality task\r\nQT_REASSIGN_TASK_DIALOG=\\u91CD\\u65B0\\u5206\\u914D\\u4EFB\\u52A1\r\n\r\n#XFLD: Label of the "To" field in the "Reassign task" dialog\r\nQT_REASSIGN_TASK_DLG_TO=\\u81F3\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Person" pushbutton in the reassign dialog \r\nQT_PERSON_DIALOG_TITLE=\\u9009\\u62E9\\u4EBA\\u5458\r\n\r\n#XMSG: Message for empty F4 dialog of the "Person" field in the reassign dialog \r\nQT_PERSON_DIALOG_EMPTY_MSG=\\u6CA1\\u6709\\u53EF\\u7528\\u4EBA\\u5458\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. \r\nQT_MISSING_INPUT_ERROR=\\u5FC5\\u586B\\u5B57\\u6BB5\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a field. \r\nQT_INVALID_INPUT_ERROR=\\u65E0\\u6548\\u8F93\\u5165\r\n\r\n#XMSG: A message that appears after you choose the "Reassign Task" pushbutton.\r\nQT_REASSIGN_TXT_VALIDATION=\\u5DF2\\u91CD\\u65B0\\u5206\\u914D\\u4EFB\\u52A1\r\n\r\n#XBUT: Label of the pushbutton that is used to cancel reassignment of a quality task in the "My Quality Task" application\r\nQT_BUTTON_CLOSE=\\u53D6\\u6D88\r\n\r\n#XTIT: Label of the settings dialog \r\nQT_SETTIGS_DIALOG_TITLE=\\u8BBE\\u7F6E\r\n\r\n#XFLD: Label of the max number quality tasks in the settings dialog\r\nQT_MAX_NUMBER=\\u663E\\u793A {0} \\u9879\\u4EFB\\u52A1\r\n\r\n#XFLD: Label of the max number (1) quality tasks in the settings dialog \r\nQT_MAX_NUMBER_ONE=\\u663E\\u793A 1 \\u9879\\u4EFB\\u52A1\r\n\r\n#XFLD: Label of the max number quality tasks in the input field from the settings dialog \r\nQT_TASKS_NUMBER=\\u4EFB\\u52A1\\u6570\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_TO=\\u81F3\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQT_TO_TOOLTIP=\\u8F93\\u5165\\u8FC7\\u6EE4\\u7684\\u7ED3\\u675F\\u65E5\\u671F\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQT_FROM_TOOLTIP=\\u8F93\\u5165\\u8FC7\\u6EE4\\u7684\\u5F00\\u59CB\\u65E5\\u671F\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQT_FROM=\\u4ECE\r\n\r\n#XTIT: Title in the list of issues indicating the filtering criterion of the entries. Filtered by {status}\r\nQT_FILTERED_BY=\\u8FC7\\u6EE4\\u6761\\u4EF6\\uFF1A{0}\r\n\r\n#XBUT: Label of the settings dialog button\r\nQT_BUTTON_SETTINGS=\\u8BBE\\u7F6E\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_OVER_COM=\\u903E\\u671F\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_APPROACH=\\u63A5\\u8FD1\\u5230\\u671F\\u65E5\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_FAR=\\u8FDC\\u79BB\\u5230\\u671F\\u65E5\r\n\r\n#XTIT: Title in the list of tasks, indicating grouping of tasks according to their due date\r\nQT_GRP_WITHOUT=\\u65E0\\u5230\\u671F\\u65E5\r\n\r\n#XBUT: Label of the option that clears filtering and grouping of issues\r\nQT_CLEAR=\\u65E0\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQT_ATT_DOC_DATE=\\u7531 {1} \\u4E8E {0} \\u6DFB\\u52A0\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQT_ATT_DOC_NAME=\\u65E0\\u6587\\u4EF6\\u540D\r\n\r\n#XTIT: Title in the list of tasks indicating that the list is in process and takes some more time than expected \r\nQT_LOADING_TEXT=\\u6B63\\u5728\\u52A0\\u8F7D...\r\n\r\n#XTIT: Title in the list of tasks indicating there are no quality tasks that match the filtering/grouping criteria.\r\nQT_NO_DATA_AVAILABLE=\\u65E0\\u8D28\\u91CF\\u4EFB\\u52A1\r\n\r\n#XMSG: Text of the message that indicates date values in filter are invalid \r\nQT_INVALID_DATES_ERROR=\\u8F93\\u5165\\u7684\\u65E5\\u671F\\u65E0\\u6548\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date"\r\nQT_TO_DATE_AFTER_FROM_DATE_ERROR=\\u622A\\u6B62\\u65E5\\u671F\\u4E0D\\u5F97\\u65E9\\u4E8E\\u8D77\\u59CB\\u65E5\\u671F\r\n',
	"i2d/qm/task/tracknconfirm/utils/DateTimeConversions.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

i2d.qm.task.tracknconfirm.utils.DateTimeConversions = {};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysAgo = function(sDate) {
	var formatterdaysAgo = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style : "daysAgo"
	}, null);
	if (sDate)
	{
		return formatterdaysAgo.format(sDate);
	}
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatMediumDate = function(sDate) {
	var formatterMedium = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style : "medium"
	}, null);
	if (sDate)
	{
		return formatterMedium.format(sDate);
	}
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatLongDate = function(sDate) {
	var formatterLong = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style : "long"
	}, null);
	if (sDate)
	{
		return formatterLong.format(sDate);
	}
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysNumber = function(sDate, sStatus) {
	if (sStatus === "I0156" || sStatus === "I0157")// completed or successful
	{
		return "";
	};

	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return "";
	}
	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = today.valueOf() - sDate.valueOf();
		daysDue = Math.floor(timePast / (24 * 60 * 60 * 1000));
	}
	var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
	
	if (daysDue === 0){
		return oBundle.getText("QT_TODAY");
	}else{
		return Math.abs(daysDue);		
	}

};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDue = function(sDate, sStatus) {

	if (sStatus === "I0156" || sStatus === "I0157")// completed or successful
	{
		return "";
	};

	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return "";
	}

	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = today.valueOf() - sDate.valueOf();
		daysDue = Math.floor(timePast / (24 * 60 * 60 * 1000));
	}

	var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

	switch (daysDue) {
	case 0:
		return "";//return oBundle.getText("QT_TODAY");
	case -1:
		return oBundle.getText("QT_DUE_IN_ONE");
	case 1:
		return oBundle.getText("QT_DAYS_OVERDUE_ONE");
	default:
		if (daysDue < 0) {
			return oBundle.getText("QT_DUE_IN");
		} else {
			return oBundle.getText("QT_DAYS_OVERDUE");
		}
	}

};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDueState = function(sDate) {
	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return sap.ui.core.ValueState.None;
	}

	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = today.valueOf() - sDate.valueOf();
		daysDue = Math.floor(timePast / (24 * 60 * 60 * 1000));
	}

	if (daysDue === 0) {
		return sap.ui.core.ValueState.Warning;

	} else if (daysDue < 0) {
		daysDue = Math.abs(daysDue);
		if (daysDue > 1)
		{
			return sap.ui.core.ValueState.Success;
		}
		else
		{
			return sap.ui.core.ValueState.Warning;
		}
	}

	return sap.ui.core.ValueState.Error;
};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue = function(sDate) {

	var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

	var daysDue = 0, timePast, today = new Date();

	sDate = i2d.qm.task.tracknconfirm.utils.Helper.fConvert(sDate);
	if (sDate === "") {
		return oBundle.getText("QT_GRP_WITHOUT");
	}

	// it's today if dates match
	if (sDate.getDate() !== today.getDate() || sDate.getMonth() !== today.getMonth() || sDate.getFullYear() !== today.getFullYear()) {
		timePast = sDate.valueOf() - today.valueOf();
		daysDue = Math.ceil(timePast / (24 * 60 * 60 * 1000));
	}

	if (daysDue < 0) {
		return oBundle.getText("QT_GRP_OVER_COM");
	} else if (daysDue >= 0 && daysDue <= 1) {
		return oBundle.getText("QT_GRP_APPROACH");
	} else if (daysDue >= 2) {
		return oBundle.getText("QT_GRP_FAR");
	}

};

i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentDate = function(sDate, sUser) {
	if (sDate) {
		// format is <d:CreatedAt>13092013154103</d:CreatedAt>
		var Day = sDate.substring(6, 8) * 1;
		var Month = sDate.substring(4, 6) * 1 - 1;// Month value 0-11
		var Year = sDate.substring(0, 4) * 1;
		var hh = sDate.substring(8, 10) * 1;
		var mm = sDate.substring(10, 12) * 1;
		var ss = sDate.substring(12, 14) * 1;

		var DateStr = new Date(Year, Month, Day, hh, mm, ss);

		DateStr = sap.ca.ui.model.format.DateFormat.getDateInstance({
			style : "medium"
		}, null).format(DateStr);
		var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

		return oBundle.getText("QT_ATT_DOC_DATE", [ DateStr, sUser ]);
	}
};


i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentName = function(sDocName) {
// in case the file is uploaded from the back end and has no name, then the other properties are also not displayed
// set text for missing name in order to solve the problem
	if(!sDocName){
		var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		sDocName = oBundle.getText("QT_ATT_DOC_NAME");
	}
	
	return sDocName;
};

},
	"i2d/qm/task/tracknconfirm/utils/ErrorDialog.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.ErrorDialog");
jQuery.sap.require("sap.ca.ui.message.message");

i2d.qm.task.tracknconfirm.utils.ErrorDialog = function(messages) {
	var _errorTxt = "";
	var _firstMsgTxtLine = "";
	var _detailmsg = "";
	var oSettings = "";
	
	if (typeof messages === "string") {
		oSettings = {
			message : messages,
			type : sap.ca.ui.message.Type.ERROR
		};
	}
	else if (messages instanceof Array) {

		for ( var i = 0; i < messages.length; i++) {
			_errorTxt = "";
			if (typeof messages[i] === "string") {
				_errorTxt = messages[i];
			}
			else if (typeof messages[i] === "object") {
				_errorTxt = messages[i].value;
			}
			if (i === 0) {
				_firstMsgTxtLine = _errorTxt;
			}
			else {
				_detailmsg = _detailmsg + _errorTxt + "\n";
			}
		}

		if (_detailmsg === "") { // do not show any details if none are there
			oSettings = {
				message : _firstMsgTxtLine,
				type : sap.ca.ui.message.Type.ERROR
			};
		}
		else {
			oSettings = {
				message : _firstMsgTxtLine,
				details : _detailmsg,
				type : sap.ca.ui.message.Type.ERROR
			};
		}

	}
	sap.ca.ui.message.showMessageBox(oSettings);
};

},
	"i2d/qm/task/tracknconfirm/utils/Formatter.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.Formatter");


i2d.qm.task.tracknconfirm.utils.Formatter = {};

i2d.qm.task.tracknconfirm.utils.Formatter.formatTaskLongText = function (sText) {
	
	var sDash = "----------";
	var sResult = "";
	
	if (sText && sText.indexOf(sDash) >= 0) {
		
		var sDashes = sDash + sDash + sDash + sDash;
		var aResult = sText.split (sDashes);
		for (var i = 0; i < aResult.length; i++) {
			
			if (aResult[i].trim().length > 0) {
				sResult = sResult + aResult[i].trim() + "; ";
			}
		}
	} else {
		
		sResult = sText;
	}
	
	return sResult;
};
},
	"i2d/qm/task/tracknconfirm/utils/FragmentHelper.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.FragmentHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");

i2d.qm.task.tracknconfirm.utils.FragmentHelper = function(){
	
	var customSettingsDialog;
	
	var setMaxHitsData = function(oControl, sMaxHits){
		
		if (!oControl){
			return;
		}
		
		//If the max hits has been already set for a control, then it should be overwritten
		var model = oControl.getModel("maxHits"); 
		
		if (model){
			model.setData({maxHits : sMaxHits});
		}else{
			model = new sap.ui.model.json.JSONModel({maxHits : sMaxHits});
			oControl.setModel(model, "maxHits");
		}
		
	};
	
	var updateCustSetDialogContent = function(oContent, oController){
		
		if (!customSettingsDialog){
			return;
		}
		
		customSettingsDialog.removeAllContent();
		customSettingsDialog.addContent(oContent);
		var customSettingsDialogHeader = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsDialogHeader", oController);
		customSettingsDialogHeader.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
		customSettingsDialog.setCustomHeader(customSettingsDialogHeader);
		
	};
	
	return {
		
		openFilterDialog: function(oController) {
			
			if(!oController){
				return;
			}
			
			if (!this.filterDialog) {
	            this.filterDialog = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.ViewSettingsFilterDialog", oController);
	            this.filterDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
	            this.setFilterDialogModel();
	            this.dateVBox = this.filterDialog.getFilterItems()[1].getCustomControl();
	            this.dateVBox.addStyleClass("qt_dateFilterMargins");
	            this.dateVBox.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
	        }

	        this.filterDialog.open();
			
		},
		
		setFilterDialogDateFilterCount: function(iCount){
			
			//iCount could be 0 or 1
			if (!this.filterDialog){
				return;
			}
			
			this.filterDialog.getFilterItems()[1].setFilterCount(iCount);
			
			if (iCount === 0){
				this.filterDialog.getFilterItems()[1].setSelected(false);
				return;
			}

			this.filterDialog.getFilterItems()[1].setSelected(true);
		},
		
		resetFilterDialogDateFilter: function(sPreviousDateFromUTC, sPreviousDateToUTC){
			if (!this.filterDialog){
				return;
			}
			
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setDateValue();
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setValue(sPreviousDateFromUTC);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].fireChange(true);
			
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setDateValue();
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setValue(sPreviousDateToUTC);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].fireChange(true);
			
			if (!sPreviousDateFromUTC && !sPreviousDateToUTC){
				this.setFilterDialogDateFilterCount(0);
			}else{
				this.setFilterDialogDateFilterCount(1);
			}
			
		},
		
		setFilterDialogModel : function(){
			var oStatusHelper = i2d.qm.task.tracknconfirm.utils.StatusHelper;
			oStatusHelper.constructor();
			var arStatusData = oStatusHelper.getArrayColors();
			
			if(!$.isArray(arStatusData) || arStatusData.length < 1 || !this.filterDialog){
				return;
			}

			var model = new sap.ui.model.json.JSONModel({status1 : null}, {status2 : null}, {status3 : null}, {status4 : null});
						
			$.each(arStatusData, function(index, statusData){
				
				switch (statusData.stateStatus) {
				case "I0154":
					model.getData().status1 = statusData.stateText;  
					break;
				case "I0155":
					model.getData().status2 = statusData.stateText;  
					break;
				case "I0156":
					model.getData().status3 = statusData.stateText;  
					break;				
				};
				
			});
			
			this.filterDialog.getFilterItems()[0].setModel(model);
		},
		
		destroyFilterDialog : function(){
			
			//Destroy Filter Dialog and all of its related controls
			if (!this.filterDialog){
				return;
			}
			
			this.filterDialog.destroy();
			this.filterDialog = null;
			
		},
		
		openSortDialog: function(oController) {
			
			if (!this.sortDialog){
	            this.sortDialog = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.ViewSettingsSortDialog", oController);
	            this.sortDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			}
			
	        this.sortDialog.open();
	        
		},
		
		destroySortDialog : function(){

			//Destroy Sort Dialog and all of its related controls
			if (!this.sortDialog){
				return;
			}
			
			this.sortDialog.destroy();
			this.sortDialog = null;
			
		},
		
		openCustSetDialog : function(oController, sMaxHits) {
			
			if (!customSettingsDialog){
				customSettingsDialog = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsDialog", oController);
				customSettingsDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			}
			
			//Reset dialog container
			customSettingsDialog.removeAllContent();
			
			//Load default container with Settings List
			if (!this.customSettingsList){
				this.customSettingsList = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsList", oController);
				this.customSettingsList.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			}

			setMaxHitsData(this.customSettingsList.getItems()[0], sMaxHits);
			customSettingsDialog.addContent(this.customSettingsList);
			customSettingsDialog.destroyCustomHeader();
			
			if (customSettingsDialog.isOpen() !== true){
				customSettingsDialog.open();
			}
			
		},
		
		loadCustSetIssuesNumber : function(oController, sMaxHits) {
			
			//In order to load Issues Number form, CustomSettingsDialog has to be loaded preliminary
			if (!customSettingsDialog){
				return;
			}
			
			if (!this.customSettingsIssueNumber){
				this.customSettingsIssueNumber = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.fragments.CustomSettingsNumberOfIssues", oController);
			}
			
			setMaxHitsData(this.customSettingsIssueNumber, sMaxHits);
			updateCustSetDialogContent(this.customSettingsIssueNumber, oController);
			
		},
		
		closeCustSetDialog: function() {
			if (customSettingsDialog.isOpen() !== false){
				customSettingsDialog.close();
			}
		},
		
		getCustSetMaxHitsTitle : function(sMaxHits){

			//Formatter method
			var bundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			
			if (sMaxHits === "1"){
				return bundle.getText("QT_MAX_NUMBER_ONE");
			}else{
				return bundle.getText("QT_MAX_NUMBER", sMaxHits);
			}
		},
		
		destroyCustSetDialog : function(){
			
			if (customSettingsDialog){
				customSettingsDialog.destroyCustomHeader();
				customSettingsDialog.destroy();
				customSettingsDialog = null;
				this.customSettingsList.destroy();
				this.customSettingsList = null;
			}
			
			if (this.customSettingsIssueNumber){
				this.customSettingsIssueNumber.destroy();
				this.customSettingsIssueNumber = null;
			}
			
		},

	};

}();


},
	"i2d/qm/task/tracknconfirm/utils/Helper.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.Helper");

	i2d.qm.task.tracknconfirm.utils.Helper = {
		
			processChangeOperation : function(sPath, httpMethod, objOData, oController) {

				this.result = {};
				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

				var oModel = oController && oController.getView().getModel();
				if (!oModel) {
					// create model
					oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getServiceList()[0].serviceUrl);
				}
				var oChangeBatch = oModel.createBatchOperation(sPath, httpMethod, objOData);
				
				oModel.setUseBatch(true);
				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Change;
				this.arExpectedProperties = null;
				this.itemsPrefix = null;
				
				oModel.addBatchChangeOperations([ oChangeBatch ]);
				
				this.modelSubmitBatch(oModel);

				return this.result;
			},
			
			getAttStream : function(sNotificationID, sDocNum) {

				// Complete/FInish QT using jQuery
				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
				var sUrl = oAppConfig.getServiceList()[0].serviceUrl + oAppConfig.getServiceList()[0].QIAttachmentStream + "(Notification='" + sNotificationID + "',DocumentNumber='" + sDocNum + "')/$value";
				location.href = sUrl;
			},
			
			convertCollection : function(arODataProperties, arExpected) {
				var arResult = [];
				$.each(arODataProperties, function(index, arODataProperty) {
					var obj = {};
					if (arExpected && $.isArray(arExpected) && arExpected.length > 0) {
						for ( var i = 0; i < arExpected.length; i++) {
							obj[arExpected[i].output] = arODataProperty[arExpected[i].source];
						}
					} else {
						obj = arODataProperty;
					}
					arResult.push(obj);
				});
				return arResult;
			},
			
			getCollection : function(index, arExpectedProperties, oController, bIsSingleResult, itemsPrefix ) {
				if (!bIsSingleResult) {
					bIsSingleResult = false;
				}
				if (itemsPrefix) {
					this.itemsPrefix = itemsPrefix;
				} else {
					this.itemsPrefix = "items";
				}
				
				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
				this.result = [];
				// Ocontroller is a view in fact when is called from formatter
				var oModel = (oController && oController.getModel && oController.getModel()) || oController && oController.getView().getModel();
				if (!oModel) {
					// create model
					oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getServiceList()[0].serviceUrl);
				}
				this.arExpectedProperties = arExpectedProperties;
				oModel.setUseBatch(false);
				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Read;
				this.modelReadOperation(oModel, oAppConfig.getServiceList()[0].SetCollection[index]);
				if (bIsSingleResult && this.result.items) {
					return this.result.items.length >0 && this.result.items[0];
				} else {
					return this.result;
				}
				
			},
			
			getInteropServiceData : function(sPath) {
				

				var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
				this.result = [];
				
				// create model	
				var oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getParams().InteropService.serviceUrl, true);

				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Read;
				this.arExpectedProperties = null;
				this.itemsPrefix = null;
				
				oModel.setUseBatch(false);		
				this.modelReadOperation(oModel, sPath);
				return this.result;
			},
			
			/**
			 * FIXME: BUG in sap.m.Bar control. The contentRight has a width a 0.
			 */
			resetFooterContentRightWidth : function(oController) {
				var oPage = oController.getView().getContent()[0];
				var rightBar = jQuery.sap.byId(oPage.getFooter().getId() + "-BarRight");
				var iRBWidth = rightBar.outerWidth(true);
				if (iRBWidth > 0) {
					oController.iRBWidth = iRBWidth;
				}
				if (rightBar.width() === 0 && oController.iRBWidth) {
					jQuery.sap.log.info('Update footer contentRight Width=' + oController.iRBWidth);
					rightBar.width(oController.iRBWidth);
				}
			},
			
			fConvert : function(sDate) {
				var oDate = sDate;
				if (typeof sDate === "string") {
					// Handle the format /Date(miliseconds)/
					if (sDate.indexOf("Date") !== -1) {
						sDate = sDate.substring(sDate.indexOf("(") + 1, sDate.indexOf(")"));
						sDate = new Number(sDate);
					}
					oDate = new Date(sDate);
				} else if (typeof sDate !== "object" || sDate === null) {
					oDate = "";
				}
				return oDate;
			},
			
			removeZeroLinkText : function(sText) {

				if (!sText || "" + sText === "0") {
					return "";
				}

				return sText;
			},
			
			displaySuccessMessage : function(oController, sSuccessMessage) {

				sap.m.MessageToast.show(sSuccessMessage);
				var oBindingContext = oController.getView().getBindingContext();
				var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
				sap.ui.getCore().getEventBus().publish(appId, "RefreshDetail", {
					context : oBindingContext
				});

			},
			
			/**
			 * Formats the provided oDate in UTC, regardless of the user settings. The OData backend service
			 * expects oDates in UTC format and also ignores any user customizations in SU01 
			 * @param ooDate the oDate to be formatted
			 */	
			convertToISODateTime : function(sDate){
				
				if($.isBlank(sDate)){
					return;
				}
				
				var date = new Date(sDate),
					timeZoneOffset = date.getTimezoneOffset();
				
				date.setHours(date.getHours() - ~~(timeZoneOffset / 60));
				date.setMinutes(date.getMinutes() - (timeZoneOffset / 60 - ~~(timeZoneOffset / 60)) * 60);
				
				return date.toISOString();
			},
			
			isValidDate : function(sDate){
				if ($.isBlank(sDate) || isNaN(Date.parse(sDate))){
					return false;
				}
					
				return true;
			},
			
			fnBatchSuccess : function(oData, oResponse, oErrResponse) {
				// handle the response
				var data, obj;
				var ProcessingModeEnum = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().ProcessingModeEnum;

				switch (this.ProcessingMode) {
					case ProcessingModeEnum.Read:
						data = oResponse.data.results;
						break;
					case ProcessingModeEnum.Change:
						data = oResponse.data.__batchResponses[0].__changeResponses && oResponse.data.__batchResponses[0].__changeResponses.length > 0 && oResponse.data.__batchResponses[0].__changeResponses[0].data;
						break;
				}		
				
				// data conversion if needed
				if (this.arExpectedProperties && data) {
					data = i2d.qm.task.tracknconfirm.utils.Helper.convertCollection(data, this.arExpectedProperties);
				}
				// set prefix if needed
				if (this.itemsPrefix ) {
					obj = {};
					obj[this.itemsPrefix] = data;
					this.result = obj;
				} else {
					this.result = data;
				};


				if (oErrResponse && oErrResponse.length > 0) {
					var oJson = oErrResponse[0].response.body;
					var oNewJ = $.parseJSON(oJson);
					this.result = {};
					this.result.error = oNewJ.error.message.value;
					jQuery.sap.log.error("Error occurs during batch processing: " + oNewJ.error.message.value);

					sap.ca.ui.message.showMessageBox({
						type : sap.ca.ui.message.Type.ERROR,
						message : oNewJ.error.message.value,
						details : oNewJ.error.message.value
					});
				};
			},

			fnBatchError : function(oError) {
				this.result.error = oError.message;
				jQuery.sap.log.error("Error occurs during batch processing: " + oError.message);
				sap.ca.ui.message.showMessageBox({
					type : sap.ca.ui.message.Type.ERROR,
					message : oError.message,
					details : oError.response.statusText
				});

			},
			
			modelSubmitBatch : function(oModel) {
				oModel.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false);
			},
			modelReadOperation : function(oModel, sPath) {
				oModel.read(sPath, null, null, false, $.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this));	
			},
			
			// setters needed by unit tests
			setProcessingMode : function(value){
				this.ProcessingMode = value;
			},
			setBatchResult : function(value){
				this.result = value;
			},
			setConversionProperties : function(value){
				this.arExpectedProperties = value;
			},
			setResultPrefix : function(value){
				this.itemsPrefix = value;
			},
			// getters
			getBatchResult : function(){
				return this.result;
			},
			getProcessingMode : function(){
				return this.ProcessingMode;
			},
			
			// end setters/getters

		
	};
}());	

},
	"i2d/qm/task/tracknconfirm/utils/InteropServiceHelper.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.InteropServiceHelper");
	jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
	
	i2d.qm.task.tracknconfirm.utils.InteropServiceHelper = {			
			
			isFactSheetExists : function () {
				//skip the check in local dev enviroment				
				if (location.hostname === "localhost") {
					return false;
				}
				if (this._bLinkExists === undefined) {
					var data = i2d.qm.task.tracknconfirm.utils.InteropServiceHelper.getServiceData();
			    	this._bLinkExists = (!$.isBlank(data)) && (data.length > 0);			    	
			    } 
				
				return this._bLinkExists;
			},
			
			
			getServiceData : function() {
				var sPath = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().InteropService.linkCheck;
		    	return i2d.qm.task.tracknconfirm.utils.Helper.getInteropServiceData(sPath);
			}
			
	};
}());

},
	"i2d/qm/task/tracknconfirm/utils/StatusHelper.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.task.tracknconfirm.utils.StatusHelper");
	jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");

	i2d.qm.task.tracknconfirm.utils.StatusHelper = {

		constructor : function(oView) {
			this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			this.STATUS_COLORS = "STATUS_COLORS";
			this.setArrayColors(this.getStatusSettings(oView));
		},

		statusStateBool : function(value) {
			var enableButton = true;

			if (value === "I0156") {
				enableButton = false;
			}
			return enableButton;
		},

		statusText : function(status) {
			var self = i2d.qm.task.tracknconfirm.utils.StatusHelper;
			// this = oView 
			self.constructor(this);
			
			if (self.getArrayColors()) {
				var result = $.grep(self.getArrayColors(), function(item) {
					return item.stateStatus === status;
	
				});
				if (result.length > 0){
					return result[0].stateText;
				} else {
					switch (status) {
					case "I0154":
						return this.oBundle.getText("QT_STATUS_NEW");
					case "I0155":
						return this.oBundle.getText("QT_STATUS_IN_PROCESS");
					case "I0156":
						return this.oBundle.getText("QT_STATUS_COMPLETED");
					case "I0157":
						return this.oBundle.getText("QT_STATUS_SUCCESSFUL");
					default:
						return "";
					}
				}
			}
		},

		getStatusSettings : function(oView) {
			var arStatusProperties = [
			   {output:"stateText", source:"Text"},
			   {output:"stateColor", source:"Color"},
			   {output:"stateStatus", source:"Status"}
			 ];	

			if (!this.getArrayColors()) {
				var batchResult = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(2, arStatusProperties, oView);
				var data = batchResult.items && batchResult.items.length >0 && batchResult.items;
				this.setArrayColors(data);
			}

			return this.getArrayColors();
		},

		getArrayColors : function() {
			return this.arStatusColors;
		},

		setArrayColors : function(arColors) {
			this.arStatusColors = arColors;
		},

	};
}());

},
	"i2d/qm/task/tracknconfirm/view/S2.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.FragmentHelper");
jQuery.sap.require("sap.m.DatePicker");
jQuery.sap.require("sap.ca.scfld.md.app.MasterHeaderFooterHelper");

sap.ca.scfld.md.controller.ScfldMasterController.extend("i2d.qm.task.tracknconfirm.view.S2", {
	
	// TODO Reduce the size of the controler

	/**
	 * @override
	 * 
	 * Called by the UI5 runtime to init this controller
	 * 
	 */

	onInit : function() {
		// execute the onInit for the base class BaseMasterController
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		// Settings
		this.oMasterModel = new sap.ui.model.json.JSONModel({
			selectedFilter : "All",
			selectedSorter : "DueDate",
			toogleSubmit : false
		});
		this.getView().setModel(this.oMasterModel, "masterModel");
		
		// Retrieve the application bundle
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oGroupSorter;
		this.oFiltersDialog = null;
		this.oSettingsDialog = null;
		this.SETTINGS_NAME = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName;
		// get settings and store them locally
		this.objSettings = null;		
		this.getSettings(this.SETTINGS_NAME);
		//CSS Fix -remove leading zeros coming from oData
		if (this.objSettings.maxHits){
			this.objSettings.maxHits = parseInt(this.objSettings.maxHits, 10);
			if (isNaN(this.objSettings.maxHits)){
				jQuery.sap.log.error("Error with data, please check consistency of record. Default 30 issues displayed.");
				this.objSettings.maxHits = '30';
			}
		} //end of fix
		this.maxHits = this.objSettings.maxHits;
		this.setMaxHitsToList();
		this._showLoadingText(true);
		// Set the default filter-out completed tasks
		this.aTableFilters = [];
		var aFilterCompleted = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.NE, "I0156", "");
		this.aTableFilters = this.aTableFilters.concat(aFilterCompleted);

		var bus = sap.ui.getCore().getEventBus();
		var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
		bus.subscribe(appId, "RefreshDetail", this.handleRefresh, this);

		this.getList().attachUpdateFinished(this.handleUpdateFinished, this);	
		this.getList().attachSelectionChange(this.handleSelectionChange, this);
		
		this.oList = this.getList();
		this.oTemplate = this.oList.getItems()[0].clone();
		this.oList.bindItems("/QMTaskSet", this.oTemplate, null, this.aTableFilters);
		
		this.aFilterBy = [];
		this.dateFromUTC;
		this.dateToUTC;
		this.DateFromUTCValue;
		this.DateToUTCValue;
		this.previousDateFromUTC;
		this.previousDateToUTC;
		this.closeCustSetDialog = function(){
			this.changedMaxHits = undefined;
			i2d.qm.task.tracknconfirm.utils.FragmentHelper.closeCustSetDialog();
		};
		
		this.oSorter;

	},
	
	navToEmptyView : function(){
		// work around until release 1.16.6, which will contains fix for this bug
		this.showEmptyView("DETAIL_TITLE", "NO_ITEMS_AVAILABLE"); 
	}, 
	
	/**
	 * Display "Loading..." when the list is loading after search, filter,
	 * sort ... and display usual "No data" after
	 * @param bLoading
	 */
	_showLoadingText:function (bLoading) {
		if (bLoading) {
			this.getList().setNoDataText(this.resourceBundle.getText("QT_LOADING_TEXT"));
		} else {
			this.getList().setNoDataText(this.resourceBundle.getText("QT_NO_DATA_AVAILABLE"));
		}
	},
	
	getSettings : function(SETTINGS_NAME) {
		jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
	
		// try to get it from local Storage
	  this.objSettings = localStorage.getObj(SETTINGS_NAME);
		if (this.objSettings === null) {
			// read it from customizing
			var data = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(1, [], this, true);
			if (data) {
				this.objSettings = { maxHits : data.MaxHits };
				localStorage.setObj(SETTINGS_NAME, this.objSettings);
			}
			
		    // no connection to the service, use defaults
		    if (this.objSettings === null) {				
	    		this.objSettings = { maxHits : 30 };
			// store the object into local Storage for future usage
			localStorage.setObj(SETTINGS_NAME, this.objSettings);
		    }
		}
	},

	handleUpdateFinished : function(oControlEvent) {

		if (!jQuery.device.is.phone && (oControlEvent.getParameters().reason === "Filter"  || oControlEvent.getParameters().reason === "Change" || 
				oControlEvent.getParameters().reason === "Refresh" || oControlEvent.getParameters().reason === "Binding")){

			//this._selectDetail();

			if (this.oRouter._oRouter._prevMatchedRequest === "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {
				this.oList.removeSelections();
			}
			else if(this.oList.getSelectedItem()){
				var oBindingContext = this.oList.getSelectedItem().getBindingContext();
				this.handleSelectionChange(oControlEvent, oBindingContext);
			}
			if (this.getList().getItems().length == "0" ){
				this._showLoadingText(false);
			}else {
				this._showLoadingText(true);
			}
		}
	},
	
	handleSelectionChange : function(oControlEvent, oBindingContext) {
		if (!jQuery.device.is.phone){
			if(!oBindingContext){
				oBindingContext = oControlEvent.getParameter("listItem").getBindingContext();
			}
			var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
			sap.ui.getCore().getEventBus().publish(appId, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, {
				context : oBindingContext
			});
		}
	},

	/**
	 * Called by the UI5 runtime to cleanup this controller
	 */

	onExit : function() {
		// destroy dialogs
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroySortDialog();
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroyFilterDialog();
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroyCustSetDialog();
		
		var oListFooter = sap.ui.getCore().byId( this.getView().sId + "--footer");
		if(oListFooter && oListFooter.destroy) {
		  oListFooter.destroy();
		}
	},

	handleRefresh : function() {
		this.setMaxHitsToList();
		this.getList().removeSelections();
		this.getList().getBinding("items")._refresh();
	},
	
	setMaxHitsToList : function() {
		var oModel = this.getList().getModel();
		oModel.setCountSupported(false);
		oModel.setSizeLimit(this.objSettings.maxHits);
	},

	getHeaderFooterOptions : function() {

		return {
			sI18NMasterTitle : "MASTER_TITLE",

			buttonList : [],
			oFilterOptions : {
				onFilterPressed : $.proxy(this.onFilter, this)
			},
			oSortOptions : {
				onSortPressed : $.proxy(this.onSort, this)
			},
			oGroupOptions : {

				aGroupItems : [ {
					text : this.resourceBundle.getText("QT_CLEAR"),
					key : "None"
				}, {
					text : this.resourceBundle.getText("QT_DV_DUE_DATE"),
					key : "DueDate"
				}, {
					text : this.resourceBundle.getText("QT_TASK_CODE_TEXT"),
					key : "TaskCodeText"
				}, {
					text : this.resourceBundle.getText("QT_STATUS_TEXT"),
					key : "Status"
				} ],

				onGroupSelected : jQuery.proxy( function(sKey) {
					this.onGroup(sKey);
					jQuery.sap.log.info(sKey + " has been selected");

				}, this ),

			},
			aAdditionalSettingButtons : [ {
				sId : "Settings",
				sI18nBtnTxt : "QT_BUTTON_SETTINGS",
				sIcon : "sap-icon://action-settings",
				onBtnPressed : jQuery.proxy( function(oEvent) {
					this.onSettingsPressed();
				}, this )

			} ],

		};
	},

	/**
	 * @override
	 * 
	 * @param oItem
	 * @param sFilterPattern
	 * @returns {*}
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {
		if (oItem.isSelectable()) {
			if (sFilterPattern.substring(0, 1) === "#") {
				var sTail = sFilterPattern.substr(1);
				var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
				return sDescr.indexOf(sTail) === 0;
			} else {
				return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem, sFilterPattern);
			}
		}

	},

	/**
	 * @override
	 * 
	 * determines whether search is triggered with each change of the search
	 * field content (or only when the user explicitly starts the search).
	 * 
	 */

	isLiveSearch : function() {
		// CSS: 0000124432 2014 - Reset List's noDataText to 'No Quality Tasks Available' before a search
		this.getList().setNoDataText(this.resourceBundle.getText("QT_NO_DATA_AVAILABLE"));
		return false;
	},

	setInfoLabel : function(resourceId, sText, bInfoEnabled, sFilteredBy) {
		if (bInfoEnabled === null)
			bInfoEnabled = true;

		this.oMasterModel.setProperty('/toogleSubmit', bInfoEnabled);
		if (bInfoEnabled === false)
			return;

		var oLabelToolbar = this.getView().byId("labelTB");
		var toReplace = "";
		if (sText)
			toReplace = this.resourceBundle.getText(sText);
		else
			toReplace = sFilteredBy;
		var sText = this.resourceBundle.getText(resourceId, [ toReplace ]);
		oLabelToolbar.setText(sText);
		oLabelToolbar.setTooltip(sText);
	},	

	onGroup : function(sKey) {

		switch (sKey) {
		case "None":

			// Button None - Refresh to No Grouping
			// In case the list is already sorted we have to retrieve
			// the data again and reset sorting title
			if (this.oList.getBinding("items").isGrouped()) {
				this.oList.bindAggregation("items", {
					path : "/QMTaskSet",
					template : this.oTemplate,
					sorter: this.oSorter,
					filters : this.aTableFilters

				});

				this.registerMasterListBind(this.oList);
			}

			break;
		case "DueDate":
			var oDateSorter = new sap.ui.model.Sorter("DueDate", false, function(oContext) {
				var skey;

				skey = oContext.getProperty("DueDate");
				return {
					key : i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue(skey),
					text : i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue(skey)
				};

			});
			this.oGroupSorter = oDateSorter;
			this.oList.bindAggregation("items", {
				path : "/QMTaskSet",
				template : this.oTemplate,
				sorter : oDateSorter,
				filters : this.aTableFilters

			});

			this.registerMasterListBind(this.oList);

			break;

		case "TaskCodeText":
			var oTaskTypeSorter = new sap.ui.model.Sorter("TaskCodeText", false, true);
			this.oGroupSorter = oTaskTypeSorter;

			this.oList.bindAggregation("items", {
				path : "/QMTaskSet",
				template : this.oTemplate,
				sorter : oTaskTypeSorter,
				filters : this.aTableFilters

			});

			this.registerMasterListBind(this.oList);

			break;
		case "Status":
			var oStatusSorter = new sap.ui.model.Sorter("Status", false, function(oContext) {
				var sKey = oContext.getProperty("StatusText");
				return {
					key : sKey, // group
					text : "Task Status: " + sKey
				};
			});

			this.oGroupSorter = oStatusSorter;

			this.oList.bindAggregation("items", {
				path : "/QMTaskSet",
				template : this.oTemplate,
				sorter : oStatusSorter,
				filters : this.aTableFilters

			});

			this.registerMasterListBind(this.oList);

			break;
		}

	},

	setFilterInfoLabel : function(arFilterBy) {

		if (!$.isArray(arFilterBy) || arFilterBy.length < 1 ){
			this.setInfoLabel('', '', false, '');
			return;
		}
		
		var infoLabelText 	= "", 
			dueDate 		= this.resourceBundle.getText("QT_DV_DUE_DATE"),
			status 			= this.resourceBundle.getText("QT_STATUS_TEXT");
		
		$.each(arFilterBy, function(index, filterBy) {

			if (i2d.qm.task.tracknconfirm.utils.Helper.isValidDate(filterBy.oValue1)){
				
				if (filterBy.oValue1 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate && 
						filterBy.oValue2 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate){
					return false;
				}
				
				filterBy.oValue1 = filterBy.oValue1.substring(0, 10);
				filterBy.oValue2 = filterBy.oValue2.substring(0, 10);
				infoLabelText += dueDate + ": " + filterBy.oValue1 + ", " + filterBy.oValue2;
				
			}else if(filterBy.oValue1){
				if (infoLabelText.indexOf(status) === -1){
					infoLabelText += status + ": " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(filterBy.oValue1);
				}else {
					infoLabelText += ", " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(filterBy.oValue1);
				}
			}
			
		});
		
		infoLabelText += ";";
		
		this.setInfoLabel("QT_FILTERED_BY", null, true, infoLabelText);
	},

	onFilter : function(event){
		this.aFilterBy = [];
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openFilterDialog(this);
	},
	
	navBack : function() {
		window.history.back();
	},

	onAfterRendering : function() {
		i2d.qm.task.tracknconfirm.utils.Helper.resetFooterContentRightWidth(this);
	},
	
	onConfirmFilterDialog : function(oEvent){
		this._showLoadingText(true);
		var parameters 	= oEvent.getParameters();
		this.aTableFilters =[];
		
		if (this.invalidDateTo || this.invalidDateFrom) {
			
			this.setInfoLabel("QT_INVALID_DATES_ERROR", null, true, null);
			this._showLoadingText(false);
			return;
		}
		
		// check if "To Date" entered in filter is equal to or greater than "From Date"
		if ((new Date(this.dateToUTC)).getTime() < (new Date(this.dateFromUTC).getTime())) {
		 		
				this.setInfoLabel("QT_TO_DATE_AFTER_FROM_DATE_ERROR", null, true, null);
		 		this._showLoadingText(false);
		 		return;
		}

		
		$.each(parameters.filterItems, $.proxy(function(index, filterItem){
			if(filterItem.sId === "StatusNew" || filterItem.sId === "StatusInProcess" || filterItem.sId === "StatusCompleted" || filterItem.sId === "StatusPostponed"){
				this.aTableFilters.push(filterItem.getCustomData()[0].getValue().filters);
			}
		}, this));

		if (this.shouldCreateDateFilterObject()){
			this.aTableFilters.push(new sap.ui.model.Filter("DueDate", sap.ui.model.FilterOperator.BT, this.dateFromUTC, this.dateToUTC));
		}
		
		//Clear default values of dates if needed
		if (this.dateFromUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate){ 
			this.dateFromUTC = null;
		}
		
		if (this.dateToUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate){ 
			this.dateToUTC = null;
		}

		this.getList().getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);
		this.setFilterInfoLabel(this.aTableFilters);
		
		this.previousDateFromUTC = this.DateFromUTCValue;
		this.previousDateToUTC = this.DateToUTCValue;
	},
	
	onCancelFilterDialog : function(oEvent){
		//Because the Date filter is constructed via custom controls, the date pickers and the filter counter are manually reset. Previous values are restored
		this.DateFromUTCValue = this.previousDateFromUTC;
		this.DateToUTCValue = this.previousDateToUTC;
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.resetFilterDialogDateFilter(this.previousDateFromUTC, this.previousDateToUTC);
	},
	
	onChangeDateFrom : function(oEvent){
		//Preserve previous value for the case of canceling changes
		this.DateFromUTCValue = oEvent.getSource().mProperties.value;
		this.dateFromUTC = i2d.qm.task.tracknconfirm.utils.Helper.convertToISODateTime(oEvent.getSource().mProperties.dateValue);
		this.invalidDateFrom = oEvent.mParameters.invalidValue && !($.isBlank(oEvent.mParameters.newValue));
		this.setDateFilterCount();
	},
	
	onChangeDateTo : function(oEvent){
		//Preserve previous value for the case of canceling changes
		this.DateToUTCValue = oEvent.getSource().mProperties.value;
		this.dateToUTC = i2d.qm.task.tracknconfirm.utils.Helper.convertToISODateTime(oEvent.getSource().mProperties.dateValue);
		this.invalidDateTo = oEvent.mParameters.invalidValue && !($.isBlank(oEvent.mParameters.newValue));
		this.setDateFilterCount();
	},
	
	onResetFilterDialog : function(oEvent){
		//Because the Date filter is constructed via custom controls, the date pickers and the filter counter are manually reset
		this.DateFromUTCValue = null;
		this.DateToUTCValue = null;
		this.dateFromUTC = null;
		this.dateToUTC = null;
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.resetFilterDialogDateFilter();
	},
	
	shouldCreateDateFilterObject : function(){
		
		//If both dates are blank at the same time, no date filter object should be created 
		if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)){
			return false;
		}
	
		//Check if any of the dates should be set to its default value 
		if ($.isBlank(this.dateFromUTC)){
			this.dateFromUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate;
			return true;
		}
		
		if ($.isBlank(this.dateToUTC)){
			this.dateToUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate;
		}
		
		return true;
	}, 
	
	setDateFilterCount : function(){
		
		if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)){
			i2d.qm.task.tracknconfirm.utils.FragmentHelper.setFilterDialogDateFilterCount(0);
			return;
		}
		
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.setFilterDialogDateFilterCount(1);
	},
	
	onSort : function(oEvent){
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openSortDialog(this);
	},
	
	onConfirmSortDialog : function(oEvent){

		var parameters = oEvent.getParameters();
		
		//If no no sorted item was selected, return
		if(!parameters.sortItem){
			return;
		}
		
		this.oSorter = parameters.sortItem.getCustomData()[0].getValue().sorter;
		
		if(!this.oSorter){
			return;
		}
		
		//The event parameter for descending is true/false according to the user selection of Ascending/Descending on the popup
		this.oSorter.bDescending = parameters.sortDescending;
		this.getList().getBinding("items").sort(this.oSorter);
	},
	
	onConfirmCustSettingsDialog : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getAggregation("content")[0];
		
		//Check the value state of IssueNumber input
		if (elementContainer.getId() === "CustomSettingsIssuesNumber" && elementContainer.getContent()[1].getValueState() === sap.ui.core.ValueState.Error){
			return; //The state is error, thus return the focus of the IssueNumber input
		}
		
		if (this.changedMaxHits > 0 && this.objSettings.maxHits !== this.changedMaxHits){
			this.objSettings.maxHits = this.changedMaxHits;
			this.handleRefresh();
			localStorage.setObj(this.SETTINGS_NAME, this.objSettings);
		}
				
		this.closeCustSetDialog();
		
	},
	
	onCancelCustSettingsDialog : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getAggregation("content")[0];
		
		if (elementContainer.getId() === "CustomSettingsIssuesNumber"){
			var issuesNumberInput = elementContainer.getContent()[1];
			issuesNumberInput.setValueState(sap.ui.core.ValueState.None);
			issuesNumberInput.setValueStateText("");
		}
				
		this.closeCustSetDialog();
		
	},
	
	onCustSetDialogHeaderBack : function(oEvent){
		
		var issuesNumberInput = oEvent.getSource().getParent().getParent().getAggregation("content")[0].getContent()[1];
			
		if (issuesNumberInput.getValueState() === sap.ui.core.ValueState.Error ){
			return; //The state of the IssuesNumber input value is error, thus return the focus of the input anew
		}
		
		//Navigate back to the popup list with choices
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openCustSetDialog(this, issuesNumberInput.getValue());
		
	},

	onCustomSettingsIssues : function(oEvent){
		var maxHits = oEvent.getSource().getModel("maxHits").getData().maxHits;
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.loadCustSetIssuesNumber(this, maxHits);
	},
	
	onSettingsPressed : function(oEvent){
		i2d.qm.task.tracknconfirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits);
	},
	
	onChangeCustSetIssueNumber : function(oEvent){

		//"Not-a-Number" input validation is made on parsing fragment level by the framework. In case of NaN, the value is set to empty string, thus it should be checked only for blank 
		// CSS: 0000364969 2014. Framework validation for NaN does not work for Internet Explorer. Hence adding the check locally.
		if (isNaN(oEvent.getSource().getValue()) || $.isBlank(oEvent.getSource().getValue()) || oEvent.getSource().getValue() < 1){
			oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
			oEvent.getSource().setValueStateText(this.resourceBundle.getText("QT_INVALID_INPUT_ERROR"));
		}else{
			oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			oEvent.getSource().setValueStateText("");
		}
		
		//Remove leading zeros and possible decimal places with radix 10
		this.changedMaxHits = parseInt(oEvent.getSource().getValue(), 10);
		
	}
	
});

},
	"i2d/qm/task/tracknconfirm/view/S2.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\tcontrollerName="i2d.qm.task.tracknconfirm.view.S2">\n\t<Page id="page" title="{i18n>MASTER_TITLE}" showNavButton="false">\n\t\t<content>\n\t\t<!-- \t\t\t\tvisible="{device>/isTouch}" -->\n\t\t\n\t\t\t<List id="list" select="_handleSelect" mode="{device>/listMode}">\n\t\t\t\t<infoToolbar>\n                    <Toolbar visible = "{masterModel>/toogleSubmit}">\n                        <content>\n                        \t<Label text="" id="labelTB" />\n                        </content>\n                    </Toolbar>\n                </infoToolbar>\n\t\t\t\t<ObjectListItem id="MAIN_LIST_ITEM" press="_handleItemPress"\n\t\t\t\t\ttype="{device>/listItemType}" title="{TaskShortText}" \n\t\t\t\t\tnumber="{parts:[{path:\'DueDate\'},{path:\'Status\'}], formatter :\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysNumber\'}"\n\t\t\t\t\tnumberState="{path : \'DueDate\', formatter : \'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDueState\'}" \n\t\t\t\t\tnumberUnit="{parts:[{path:\'DueDate\'},{path:\'Status\'}],formatter:\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDue\'}">\n\t\t\t\t\t\n\t\t\t\t\t<attributes>\n\t\t\t\t\t\t<ObjectAttribute id="ATTR1" text="{TaskCodeText}" />\n\t\t\t\t\t\t<ObjectAttribute id="StatusText" text="{path:\'Status\', formatter: \'i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText\'}" />\t\t\t\n\t\t\t\t\t</attributes>\n\t\t\t\t\t\n\t\t\t\t\n\t\t</ObjectListItem>\n\t\t\t</List>\n\t\t</content>\n\t\t\n\t\t<footer>\n\t\t\t<Bar id="footer">\t\n\n\t\t\t</Bar>\n\t\t</footer>\n\t</Page>\n</core:View>',
	"i2d/qm/task/tracknconfirm/view/S3.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.ErrorDialog");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.type.FileSize");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.InteropServiceHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Formatter");

sap.ca.scfld.md.controller.BaseDetailController.extend("i2d.qm.task.tracknconfirm.view.S3", {

	onInit : function() {
		// execute the onInit for the base class BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);

		var view = this.getView();
		this.selectedValue = new sap.m.StandardListItem({
			key : "{key}",
			title : "{title}",
			active : true
		});
		this.oReassignTaskDialog = null;
		this.oPersonDialog = null;	
		
		this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {
				var context = new sap.ui.model.Context(view.getModel(), '/' + oEvent.getParameter("arguments").contextPath);
				view.setBindingContext(context);
				// Make sure the master is here
			}
		}, this);

		// init CrossApplicationNavigation object
		var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		if (fgetService) {
			this.oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
		}

		var appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
		sap.ui.getCore().getEventBus().subscribe(appId, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, this.handleListItemSelected, this);

		this.oHeaderFooterOptions = {
			bSuppressBookmarkButton : true,
			buttonList : [ {
				sId : "QI_FINISH_TASK", // optional
				sI18nBtnTxt : "QT_BUTTON_FINISH_TASK",
				onBtnPressed : jQuery.proxy(function(evt) {
					this.onFinishTask(evt);
				}, this),
			}, {
				sId : "QT_REASSIGN_TASK", // optional
				sI18nBtnTxt : "QT_BUTTON_REASSIGN_TASK",
				onBtnPressed : jQuery.proxy(function(evt) {
					this.onReassignTask(evt);
				}, this)
			} ],
		};

		this.setHeaderFooterOptions(this.oHeaderFooterOptions);
		
		// register method for the event fired when the refresh button on the list is pressed (or back end search is done)	
	    this.oApplicationFacade.registerOnMasterListRefresh(this.onMasterRefresh, this);
	},
	
	onMasterRefresh : function(oEvent){
		// this method is executed when refresh button on the list is pressed (or a back end search is done - currently, we have client search) 
		// it is needed in order to refresh the data in the attachments (if changes are done in the back end)	
			var attItems = this.byId("ATTACHMENTS").getBinding("items");
			// in case the data is loaded 
			if (!attItems.bPendingRequest){
				attItems._refresh();
			}					
		},

	handleListItemSelected : function(sChannelId, sEventId, oData) {
		var oModel = this.getView().getModel();
		var bStatusState = i2d.qm.task.tracknconfirm.utils.StatusHelper.statusStateBool(oModel.getProperty("Status", oData.context));
	 
		var formElement = this.byId("QT_FEED_INPUT");
		if(formElement){
			formElement.setValue("");
			formElement.setEnabled(bStatusState);
		}
		this.setBtnEnabled("QI_FINISH_TASK", bStatusState);
		this.setBtnEnabled("QT_REASSIGN_TASK", bStatusState);
	},

	/**
	 * Called by the UI5 runtime to cleanup this controller
	 */

	onExit : function() {

		// destroy the control if needed
		if (this.oReassignTaskDialog) {
			this.oReassignTaskDialog.destroy();
			this.oReassignTaskDialog = null;
		}
		// destroy the control if needed
		if (this.oPersonDialog) {
			this.oPersonDialog.destroy();
			this.oPersonDialog = null;
		}
		
		// destroy the control if needed
		if (this.oEmployeeLaunch) {
			this.oEmployeeLaunch.destroy();
			this.oEmployeeLaunch = null;
		}
		
		var oDetailFooter = sap.ui.getCore().byId( this.getView().sId + "--detailFooter");
		if(oDetailFooter && oDetailFooter.destroy) {
			oDetailFooter.destroy();
		}
	},

	navToSubview : function() {
		this.oRouter.navTo("subDetail", {
			contextPath : this.getView().getBindingContext().sPath.substr(1)
		});
	},

	navToEmpty : function() {
		this.oRouter.navTo("noData", {
			viewTitle : "DETAIL_TITLE",
			languageKey : "NO_ITEMS_AVAILABLE"
		});
	},
	/**
	 * @override HACK for Full Screen & Master Detail Navigation
	 * @param oItem
	 */
	navBack : function() {
		// this.nav.back();
		window.history.back();
	},

	openBusinessCard : function(oEvent) {
		var oEmpData = {};

		// get control that triggeres the BusinessCard
		if (oEvent) {
			var oSource = oEvent.oSource;
			if (oSource) {
				var oContext = oSource.getBindingContext();
				var oModel = this.getView().getModel();
				if (oContext && oModel) {
					oEmpData = {
						name : oModel.getProperty("PartnerName", oContext),
						imgurl : "sap-icon://person-placeholder",// "img/home/default_contact_picture.png",
						// department:oModel.getProperty("Department",
						// oContext),
						contactmobile : oModel.getProperty("PartnerMobilePhone", oContext),
						contactphone : oModel.getProperty("PartnerWorkPhone", oContext),
						contactemail : oModel.getProperty("PartnerEmail", oContext),
						companyname : oModel.getProperty("PartnerCompany", oContext),
					// companyaddress:oModel.getProperty("CompanyAddress",
					// oContext)
					};

					// call 'Business Card' reuse component
					this.oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmpData);
					this.oEmployeeLaunch.openBy(oSource);
				}
			}
		}
	},

	fillSelectDialog : function(oModelList, oInput, noDataText, mSelectDialogTitle) {

		var oSelectDialog1 = new sap.m.SelectDialog("SelectDialog1", {
			title : mSelectDialogTitle,
			noDataText : noDataText,
			search : jQuery.proxy(function(oEvent) {
				var sVal = oEvent.getParameter("value");
				if (sVal !== undefined) {
					this.filterDialog(sVal, oSelectDialog1.getBinding("items"));
				}
			}, this),
			liveChange : jQuery.proxy(function(oEvent) {
				var sVal = oEvent.getParameter("value");
				if (sVal !== undefined) {
					this.filterDialog(sVal, oSelectDialog1.getBinding("items"));
				}
			}, this)
		});
		oSelectDialog1._list.setGrowing(true);
		oSelectDialog1._list.setGrowingScrollToLoad(true);
		
		// set model & bind Aggregation
		oSelectDialog1.setModel(oModelList);
		// create simple sorter by title
		var oTitleSorter = new sap.ui.model.Sorter("FullName", false, false);
		var itemTemplate = new sap.m.StandardListItem({
			key : "{UserName}",
			title : "{FullName}",
			active : true
		});
		oSelectDialog1.bindAggregation("items", "/QMUserSet", itemTemplate, oTitleSorter);
		// attach close listener
		oSelectDialog1.attachConfirm(jQuery.proxy(function(evt) {
			var selectedItem = evt.getParameter("selectedItem");
			if (selectedItem) {
				oInput.setValue(selectedItem.getTitle());
				var position = selectedItem.getBindingContext().getPath().split("/");
				var index = position[position.length - 1];
				this.selectedValue.key = selectedItem.getBindingContext().getModel().oData[index].UserName;
				this.selectedValue.title = selectedItem.getTitle();
			}
		}, this));

		return oSelectDialog1;
	},

	filterDialog : function(sVal, itemsBinding) {
		var filter = [];
		if (sVal !== undefined ) {
			if (sVal.length > 0 ) {
				sVal = sVal.substr(0,1).toUpperCase() + sVal.substr(1); 
			}
			
			// create the local filter to apply
			var selectFilter = new sap.ui.model.Filter("FullName", sap.ui.model.FilterOperator.StartsWith, sVal);
			filter.push(selectFilter);

			// and apply the filter to the bound items, and the
			// Select Dialog will update
			itemsBinding.filter(filter);
		}
	},

	onPersonSearch : function(oEvent) {
		// in case the person F4 help dialog is not initialized, then do it
		var controller = this.mEventRegistry.valueHelpRequest[0].oData;
		if (controller.oPersonDialog === null)
			controller.oPersonDialog = controller.fillSelectDialog(oEvent.getSource().getModel(), this, controller.oBundle.getText("QT_PERSON_DIALOG_EMPTY_MSG"), controller.oBundle.getText("QT_PERSON_DIALOG_TITLE"));

		// in all cases set it the input if there is any and open the dialog
		var filterValueTxt = this.getValue();
		controller.oPersonDialog.open(filterValueTxt);

		if (filterValueTxt !== undefined && filterValueTxt !== "")
			controller.filterDialog(filterValueTxt, controller.oPersonDialog.getBinding("items"));
		// clear the previous selection if any
		controller.selectedValue.key = "";
		controller.selectedValue.title = "";
	},

	onValidation : function(oField) {
		var result = true;
		// mandatory fields check
		if (oField.getValue() == "" || this.selectedValue.key == "") {
			// set the state to false
			result = false;
			if (oField.setValueState) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				// set different message according to the different errors -
				// empty mandatory field or invalid entry
				var textCode = "QT_INVALID_INPUT_ERROR";
				if (oField.getValue() == "") {
					textCode = "QT_MISSING_INPUT_ERROR";
				}

				oField.setValueStateText(this.oBundle.getText(textCode));
				result = false;
			}
		} else if (oField.setValueState) {
			oField.setValueState(sap.ui.core.ValueState.None);
		}

		return result;
	},

	createReassignTaskDialog : function(oEvent) {

		var oLbl1 = new sap.m.Label("Lbl1", {
			text : this.oBundle.getText("QT_REASSIGN_TASK_DLG_TO"),
			required : true
		});
		var oInputTo = new sap.m.Input("cbAssignTo", {
			showValueHelp : true,
			valueHelpRequest : [ this, this.onPersonSearch ],
			showValueStateMessage : true,
			showSuggestion : true,
			suggest : jQuery.proxy(function(oEvent) {
				this.selectedValue.key = "";
				this.selectedValue.title = "";
				var sVal = oEvent.getParameter("suggestValue");
				if (sVal !== undefined) {
					this.filterDialog(sVal, oInputTo.getBinding("suggestionItems"));
				}
			}, this),
			suggestionItemSelected : jQuery.proxy(function(oEvent) {
				// set selected value
				var sVal = oEvent.getParameter("selectedItem");
				if (sVal !== undefined) {
					this.selectedValue.key = sVal.mProperties.key;
					this.selectedValue.title = sVal.mProperties.text;
				}
			}, this)
		});
		// set model & bind Aggregation

		oInputTo.setModel(this.getView().getModel());

		var itemTemplate = new sap.ui.core.Item({
			key : "{UserName}",
			text : "{FullName}",
			active : true
		});
		oInputTo.bindAggregation("suggestionItems", "/QMUserSet", itemTemplate);

		var oLbl2 = new sap.m.Label("Lbl2", {
			text : this.oBundle.getText("QT_COMMENT")
		});
		var oComment = new sap.m.TextArea("taComment");

		var oSimpleForm = new sap.ui.layout.form.SimpleForm({
			maxContainerCols : 1,
			editable : true,
			labelMinWidth : 30,
			layout : sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
			content : [ oLbl1, oInputTo, oLbl2, oComment ]
		});

		var oDialog1 = new sap.m.Dialog({
			title : this.oBundle.getText("QT_REASSIGN_TASK_DIALOG"),
			stretchOnPhone : true
		});
		oDialog1.addContent(oSimpleForm);

		var oReassignButton = new sap.m.Button({
			text : this.oBundle.getText("QT_CONFIRM_BTN"),
			press : jQuery.proxy(function() {
				if (this.onValidation(oInputTo)) {
					this.validationMessage = this.oBundle.getText("QT_REASSIGN_TXT_VALIDATION");
					var oModel = this.getView().getModel();
					var oContext = this.getView().getBindingContext();
					var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

					var objOData = {
						ModificationMode : oAppConfig.getParams().TaskModificationMode.Reassign,
						NotificationID : oModel.getProperty("NotificationID", oContext),
						TaskNum : oModel.getProperty("TaskNum", oContext),
						TaskLongtext : oComment.getValue(),
						PartnerID : this.selectedValue.key
					};

					var result = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].masterCollection + "(NotificationID='" + objOData.NotificationID + "',TaskNum='" + objOData.TaskNum + "')", oAppConfig.getParams().HTTP_Method.PUT, objOData, this);
					oDialog1.close();
					// clear the input
					oInputTo.setValue("");
					oComment.setValue("");
					this.selectedValue.key = "";
					this.selectedValue.title = "";

					if (!result || (result && !result.error)) {
						i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
					}
				}
			}, this)
		});
		oDialog1.setBeginButton(oReassignButton);

		var oCloseButton = new sap.m.Button({
			text : this.oBundle.getText("QT_BUTTON_CLOSE"),
			press : function() {
				oDialog1.close();
				// clear the input
				oInputTo.setValue("");
				oComment.setValue("");
			}
		});
		oDialog1.setEndButton(oCloseButton);

		return oDialog1;
	},

	 
	onNoteSubmit : function(oEvent) {

		var oModel = this.getView().getModel();
		var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
		var oContext = this.getView().getBindingContext();
		var objOData = {
			ModificationMode : oAppConfig.getParams().TaskModificationMode.AddNote,
			NotificationID : oModel.getProperty("NotificationID", oContext),
			TaskNum : oModel.getProperty("TaskNum", oContext),
			TaskLongtext : oEvent.getParameter("value")
		};
		var result = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].masterCollection + "(NotificationID='" + objOData.NotificationID + "',TaskNum='" + objOData.TaskNum + "')", oAppConfig.getParams().HTTP_Method.PUT, objOData, this);

		if (!result || (result && !result.error)) {
			this.validationMessage = this.oBundle.getText("QT_NOTES_TXT_VALIDATION");

			i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
			var feedInputElement = this.byId("QT_FEED_INPUT");
			feedInputElement.setValue("");
		}

	},

	onReassignTask : function(oEvent) {
		// if the dialog does not exist yet, create it
		if (this.oReassignTaskDialog === null)
			this.oReassignTaskDialog = this.createReassignTaskDialog();

		// in all cases set the coordinator name as default for reassignment, if
		// any is set
		var oModel = this.getView().getModel();
		var oContext = this.getView().getBindingContext();
		this.selectedValue.key = oModel.getProperty("PartnerID", oContext);
		this.selectedValue.title = oModel.getProperty("PartnerName", oContext);
		var oPersonInput = this.oReassignTaskDialog.getContent()[0]._aElements[1];
		oPersonInput.setValue(this.selectedValue.title);
		oPersonInput.setValueState(sap.ui.core.ValueState.None);
		oPersonInput.setValueStateText("");
		// then open it
		this.oReassignTaskDialog.open();
	},

	onListItemSelect : function(oEvnt) {

		var oSelection = oEvnt.getSource();
		var oModel = this.getView().getModel();
		var oContext = oSelection.getBindingContext();
		var NotifNumber = oModel.getProperty("NotificationID", oContext);
		var DocNumber = oModel.getProperty("DocumentNumber", oContext);

		if (NotifNumber && DocNumber) {
			i2d.qm.task.tracknconfirm.utils.Helper.getAttStream(NotifNumber, DocNumber);
		}
	},

	onFinishTask : function(oEvent) {
		var oContext = oEvent.oSource.getBindingContext();
		this.validationMessage = this.oBundle.getText("QT_TXT_VALIDATION");

		// provide your callback function, so that you can get informed if the
		// end user confirms or cancels the dialog
		var fnClose = jQuery.proxy(function(oResult) {
			if (oResult) {
				jQuery.sap.log.debug("isConfirmed:" + oResult.isConfirmed);
				if (oResult.sNote) {
					jQuery.sap.log.debug(oResult.sNote);
				}
				if (oResult.isConfirmed) {
					var oModel = this.getView().getModel();
					var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

					var objOData = {
						ModificationMode : oAppConfig.getParams().TaskModificationMode.Complete,
						NotificationID : oModel.getProperty("NotificationID", oContext),
						TaskNum : oModel.getProperty("TaskNum", oContext),
						TaskLongtext : oResult.sNote
					};

					var result = i2d.qm.task.tracknconfirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].masterCollection + "(NotificationID='" + objOData.NotificationID + "',TaskNum='" + objOData.TaskNum + "')", oAppConfig.getParams().HTTP_Method.PUT, objOData, this);
					if (!result || (result && !result.error)) {
						i2d.qm.task.tracknconfirm.utils.Helper.displaySuccessMessage(this, this.validationMessage);
					}
				}
			}

		}, this);

		// open the confirmation dialog
		sap.ca.ui.dialog.confirmation.open({
			question : this.oBundle.getText("QT_COMPL_QUESTION"),
			showNote : true,
			title : this.oBundle.getText("QT_CONFIRM_TITLE"),
			confirmButtonLabel : this.oBundle.getText("QT_CONFIRM_BTN")
		}, fnClose);

	},

	onAfterRendering : function() {
		i2d.qm.task.tracknconfirm.utils.Helper.resetFooterContentRightWidth(this);

		var oButton = jQuery.sap.byId("__button0");
		if (oButton) {
			oButton.addClass("sapMBtnEmphasized");
		}
	},

	onNotificationPress : function(oEvnt) {
		if (!oEvnt) {
			return;
		}
		var oLink = oEvnt.getSource();
		var NotifId = oLink.getText();
		var sHref = (this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target : {
				semanticObject : "QualityNotification",
				action : "displayFactSheet"
			},
			params : {
				"QualityNotification" : NotifId
			}
		}));

		if (sHref) {
			sap.m.URLHelper.redirect(sHref, true);
			// oLink.setHref(sHref);
			// oLink.firePress();
		}
	},

	onDefectPress : function(oEvnt) {
		var oLink = oEvnt.getSource();
		var DefectId = oLink.getText();
		var QualityNotification = this.byId("QT_NOTIFICATION").getText();
		var sHref = (QualityNotification && DefectId && this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target : {
				semanticObject : "QualityNotificationItem",
				action : "displayFactSheet"
			},
			params : {
				"QualityNotificationItem" : DefectId,
				"QualityNotification" : QualityNotification
			}
		}));
		if (sHref) {
			//open factsheet in new window
			sap.m.URLHelper.redirect(sHref, true);
		}
	}

});

},
	"i2d/qm/task/tracknconfirm/view/S3.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:f="sap.ui.layout.form"\n\tcontrollerName="i2d.qm.task.tracknconfirm.view.S3">\n\t<Page title="{i18n>DETAIL_TITLE}" showNavButton="{device>/isPhone}"\n\t\tnavButtonPress="navBack">\n\t\t<content>\n\t\t\t<ObjectHeader title="{TaskShortText}"\n\t\t\t\tnumber="{parts:[{path:\'DueDate\'},{path:\'Status\'}], formatter :\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysNumber\'}"\n\t\t\t\tnumberState="{path : \'DueDate\', formatter : \'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDueState\'}"\n\t\t\t\tnumberUnit="{parts:[{path:\'DueDate\'},{path:\'Status\'}],formatter:\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatDaysDue\'}">\n\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute id="ATTR1" text="{TaskCodeText}" />\n\t\t\t\t\t<ObjectAttribute id="ATTR2" text="{path:\'Status\', formatter: \'i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText\'}" />\n\t\t\t\t</attributes>\n\n\n\t\t\t</ObjectHeader>\n\n\t\t\t<IconTabBar>\n\t\t\t\t<items>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://hint" iconColor="Default"\n\t\t\t\t\t\tkey="key1">\n\t\t\t\t\t\t<content>\n\t\t\t\t\t\t\t<core:ExtensionPoint name="extTaskInfo">\n\t\t\t\t\t\t\t\t<!-- Task Info -->\n\t\t\t\t\t\t\t\t<f:SimpleForm id="form1">\n\t\t\t\t\t\t\t\t\t<core:Title text="{i18n>QT_DV_TITLE_TASK_INFO}" />\n\t\t\t\t\t\t\t\t\t<!-- Task Long Description -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_TASK_LONG_DESCR" text="{i18n>QT_DV_DETAIL_DESCR}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_TASK_LONG_DESCR" text="{path:\'TaskLongtext\' , formatter:\'i2d.qm.task.tracknconfirm.utils.Formatter.formatTaskLongText\'}"  />\n\n\t\t\t\t\t\t\t\t\t<!-- Start Date -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_START_DATE" text="{i18n>QT_DV_START_DATE}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_START_DATE"\n\t\t\t\t\t\t\t\t\t\ttext="{path:\'StartDate\' , formatter:\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatMediumDate\'}" />\n\n\t\t\t\t\t\t\t\t\t<!--Due Date -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_DUE_DATE" text="{i18n>QT_DV_DUE_DATE}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_DUE_DATE"\n\t\t\t\t\t\t\t\t\t\ttext="{path:\'DueDate\' , formatter:\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatMediumDate\'}" />\n\n\t\t\t\t\t\t\t\t</f:SimpleForm>\n\n\t\t\t\t\t\t\t\t<!-- Quality Notification Info -->\n\t\t\t\t\t\t\t\t<f:SimpleForm id="form2">\n\t\t\t\t\t\t\t\t\t<core:Title text="{i18n>QT_DV_TITLE_QN_INFO}" />\n\t\t\t\t\t\t\t\t\t<!--Notification ID -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_NOTIFICATION" text="{i18n>QT_DV_NOTIFICATION}" />\n\t\t\t\t\t\t\t\t\t<Link id="QT_NOTIFICATION" text="{NotificationID}" press="onNotificationPress" \n\t\t\t\t\t\t\t\t\t\t\t\t\tenabled="{path:\'Notification\',formatter:\'i2d.qm.task.tracknconfirm.utils.InteropServiceHelper.isFactSheetExists\'}" />\n\n\t\t\t\t\t\t\t\t\t<!--Notification Type -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_NOTIFICATION_TYPE" text="{i18n>QT_DV_NOTIFICATION_TYPE}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_NOTIFICATION_TYPE" text="{NotifTypeText}" />\n\n\t\t\t\t\t\t\t\t\t<!-- Description -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_NOTIF_SHORT_TEXT" text="{i18n>QT_DV_DESCR}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_NOTIF_SHORT_TEXT" text="{NotifShortText}" />\n\t\t\t\t\t\t\t\t</f:SimpleForm>\n\t\t\t\t\t\t\t\t<f:SimpleForm id="form3">\n\t\t\t\t\t\t\t\t\t<!-- Coordinator -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_COORDINATOR" text="{i18n>QT_DV_ASSIGNED_TO}" />\n\t\t\t\t\t\t\t\t\t<Link id="QT_COORDINATOR" text="{PartnerName}" press="openBusinessCard" />\n\n\t\t\t\t\t\t\t\t\t<!-- Priority -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_NOTIF_PRIORITY" text="{i18n>QT_DV_NOTIF_PRIORITY}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_NOTIF_PRIORITY" text="{NotifPirorityText}" />\n\n\t\t\t\t\t\t\t\t</f:SimpleForm>\n\t\t\t\t\t\t\t\t<f:SimpleForm id="form4">\n\t\t\t\t\t\t\t\t\t<!-- Related To Defect -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_REL_DEFECT" text="{i18n>QT_DV_REL_DEFECT}" />\n\t\t\t\t\t\t\t\t\t<Link id="QT_REL_DEFECT"\n\t\t\t\t\t\t\t\t\t\ttext="{path:\'DefectRelNum\', formatter:\'i2d.qm.task.tracknconfirm.utils.Helper.removeZeroLinkText\'}"\n\t\t\t\t\t\t\t\t\t\tpress="onDefectPress" />\n\n\t\t\t\t\t\t\t\t\t<!-- Description -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_DEFECT_SHORT_TEXT" text="{i18n>QT_DV_DESCR}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_DEFECT_SHORT_TEXT" text="{DefectDescription}" />\n\n\t\t\t\t\t\t\t\t\t<!-- Defect -->\n\t\t\t\t\t\t\t\t\t<Label labelFor="QT_DEFECT" text="{i18n>QT_DV_DEFECT}" />\n\t\t\t\t\t\t\t\t\t<Text id="QT_DEFECT" text="{DefectCodeText}" />\n\n\t\t\t\t\t\t\t\t</f:SimpleForm>\n\t\t\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\n\t\t\t\t\t<!-- Notes -->\n\t\t\t\t\t<IconTabFilter icon="sap-icon://notes" iconColor="Default"\n\t\t\t\t\t\tid="NOTES_ICON_TAB" key="key2">\n\t\t\t\t\t\t<f:SimpleForm id="formNotes1">\n\n\t\t\t\t\t\t\t<FeedInput id="QT_FEED_INPUT" post="onNoteSubmit" showIcon="false" />\n\t\t\t\t\t\t\t\n\t\t\t\t\t\t</f:SimpleForm>\n\n\t\t\t\t\t\t<f:SimpleForm id="formNotes2">\n\t\t\t\t\t\t\t<List id="NOTES" showSeparators="Inner">\n\n\t\t\t\t\t\t\t\t<FeedListItem showIcon="false" text="{path:\'TaskLongtext\' , formatter:\'i2d.qm.task.tracknconfirm.utils.Formatter.formatTaskLongText\'}" />\n\n\t\t\t\t\t\t\t</List>\n\t\t\t\t\t\t</f:SimpleForm>\n\t\t\t\t\t</IconTabFilter>\n\n\t\t\t\t\t<!-- Attachments -->\n\t\t\t\t\t<IconTabFilter icon="sap-icon://attachment"\n\t\t\t\t\t\ticonColor="Default" count="{NotifAttCount}" key="key3" id="ATT_ICON_TAB">\n\n\t\t\t\t\t\t<List id="ATTACHMENTS" showSeparators="None"\n\t\t\t\t\t\t\titems="{QMNotifAttachmentSet}">\n\n\t\t\t\t\t\t\t<StandardListItem\n\t\t\t\t\t\t\t\ttitle="{path: \'DocOrigin\', formatter:\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentName\'}"\n\t\t\t\t\t\t\t\ticon="sap-icon://attachment-photo" type="Active" press="onListItemSelect"\n\t\t\t\t\t\t\t\tinfo="{path:\'DocFileSize\', type:\'sap.ca.ui.model.type.FileSize\', formatOptions : { style:\'short\'}}"\n\t\t\t\t\t\t\t\tdescription="{parts:[{path:\'CreatedAt\'},{path:\'CreatorName\'}],\n\t\t\t\t\t                                \t\tformatter:\'i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatAttachmentDate\'}" />\n\n\t\t\t\t\t\t</List>\n\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t</items>\n\t\t\t</IconTabBar>\n\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="detailFooter">\n\n\t\t\t</Bar>\n\t\t</footer>\n\t</Page>\n</core:View>'
}});
