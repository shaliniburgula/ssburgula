jQuery.sap.declare("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.Component");



// use the load function for getting the optimized preload file if present

sap.ui.component.load({

	name: "i2d.qm.task.tracknconfirm",



	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository

	url: "/sap/bc/ui5_ui5/sap/UI_QM_TASKS"



	// we use a URL relative to our own component

	// extension application is deployed with customer namespace

});



this.i2d.qm.task.tracknconfirm.Component.extend("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.Component", {

	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {

		"name": "My Quality Tasks",

		"version": "1.0.0",

		"library": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt",

		"includes": ["css/qt_style.css"],

		"dependencies": {

			"libs": ["sap.m", "sap.me"],

			"components": []

		},



		config: {

			"sap.ca.i18Nconfigs": {

				"bundleName": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.i18n.i18n"

			},

			"sap.ca.serviceConfigs": [

				{

					name: "",

					serviceUrl: "/sap/opu/odata/sap/ZQM_TASK_SRV/",

					isDefault: true,

					mockedDataSource: "./model/metadata.xml"

                }

            ]

		},



		viewPath: "i2d.qm.task.tracknconfirm.view",

		masterPageRoutes: {

		    /*	"masterHome": {

				pattern: "",

				"view": "home",

				"viewId": "home",

				"viewPath": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view",

				subroutes: [  

                            {  

                            pattern: "",

            			    "view" : "welcome",

            			    "viewId" : "welcome",

            			    "viewPath": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view"  

                             }  

                        ]  

			},*/

			"master": {

				pattern: "",

				"view": "S2",

				"viewId": "TaskList"

			}

			/*"tasksMaster" : {

			    pattern : "tasksMaster/{contextPath}",

			    "view" : "tasksMaster",

			    "viewId" : "tasksMaster",

			    "viewPath": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view"  

				

			}*/

			

		},

		detailPageRoutes: {

			"detail": {

				pattern: "detail/{contextPath}",

				"view": "S3",

				"viewId": "TaskListDetail"

			}

			/*"tasksDetail" :{

			    	pattern: "tasksDetail/{contextPath}",

				"view": "tasksDetail",

				"viewId": "tasksDetail",

				 "viewPath": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view"  

			}*/

		},

		fullScreenPageRoutes: {

			"addTask": {

				pattern: "addTask",

				"view": "AddTask",

				"viewPath": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view",

				"viewId": "AddTask"

			},
			"reAssign": {

				pattern: "reAssign/{contextPath}",

				"view": "ReAssign",

				"viewPath": "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view",

				"viewId": "ReAssign"

			}

		},

		customizing: {

			"sap.ui.viewReplacements": {

				"i2d.qm.task.tracknconfirm.view.S3": {

					viewName: "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.S3Custom",

					type: "XML"

				},

				"i2d.qm.task.tracknconfirm.view.S2": {

					viewName: "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.S2Custom",

					type: "XML"

				}

			},

			"sap.ui.controllerExtensions": {

				"i2d.qm.task.tracknconfirm.view.S3": {

					controllerName: "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.S3Custom"

				},

				"i2d.qm.task.tracknconfirm.view.S2": {

					controllerName: "i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.S2Custom"

				}

			}

		}

	})

});