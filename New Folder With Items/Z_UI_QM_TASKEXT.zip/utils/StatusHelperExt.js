/*

 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved

 */

(function() {

  'use strict';

  jQuery.sap.declare("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.StatusHelperExt");

  jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");

  i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.StatusHelperExt = {

    constructor: function(v) {

      this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();

      this.STATUS_COLORS = "STATUS_COLORS";

      this.setArrayColors(this.getStatusSettings(v))

    },
    
    taskStatus: function(v) {

      var e = true;

      if (v === "Task Completed") {

        e = false;

      }
      return e;
    },
      statusState: function(v) {

      var e = false;

      if (v === "I0156") {

        e = true;

      }

      return e

    },
    statusCompState: function(v) {

      var e = true;

      if (v !== "I0155") {

        e = false;

      }

      return e

    },
    statusStateBool: function(v,l) {

      var e = true;

          if(v !== "Forward to QA" && v!== "QA review and approval of Change control" && v!== "QA Approval for Major Changes")

      {

          e = false

      }

      if(e === true)

      {

          if((v === "Forward to QA" && l != "Assign to CFT Team") || (v === "QA review and approval of Change control" && l != "Assign Action Plan"))

          {

              e = false

          }

      }

      return e

    },
    
     statusCompTask: function(v,l,s) {
      var e = true;
          if(v !== "Forward to QA" && v!== "QA review and approval of Change control" && v!== "QA Approval for Major Changes")
      {
          e = false
      }
      if(e === true)
      {            //(v === "Forward to QA" && l != "CC Review by QA") ||
          if((v === "Forward to QA" && l != "CC Review by QA") || (v === "QA review and approval of Change control" && l !== "CC Approval by QA" )
          || (v === "QA Approval for Major Changes" && l !== "Closure by QA" ))
          {
              e = false
          }
          else if((v === "Forward to QA" && l === "CC Review by QA"))
          {
              e = false;
          }
      }
      return e
    },

    statusText: function(s) {

      var a = i2d.qm.task.tracknconfirm.utils.StatusHelper;

      a.constructor(this);

      if (a.getArrayColors()) {

        var r = $.grep(a.getArrayColors(), function(i) {

          return i.stateStatus === s

        });

        if (r.length > 0) {

          return r[0].stateText

        } else {

          switch (s) {

            case "I0154":

              return this.oBundle.getText("QT_STATUS_NEW");

            case "I0155":

              return this.oBundle.getText("QT_STATUS_IN_PROCESS");

            case "I0156":

              return this.oBundle.getText("QT_STATUS_COMPLETED");

            case "I0157":

              return this.oBundle.getText("QT_STATUS_SUCCESSFUL");

            default:

              return ""

          }

        }

      }

    },

    getStatusSettings: function(v) {

      var a = [{

        output: "stateText",

        source: "Text"

      }, {

        output: "stateColor",

        source: "Color"

      }, {

        output: "stateStatus",

        source: "Status"

      }];

      if (!this.getArrayColors()) {

        var b = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(2, a, v);

        var d = b.items && b.items.length > 0 && b.items;

        this.setArrayColors(d)

      }

      return this.getArrayColors()

    },

    getArrayColors: function() {

      return this.arStatusColors

    },

    setArrayColors: function(a) {

      this.arStatusColors = a

    },

  }

}());