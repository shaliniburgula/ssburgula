jQuery.sap.require("sap.m.MessageBox");

jQuery.sap.require("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.FragmentHelperExt");

jQuery.sap.require("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt");

var count = 0;

var selectedIndex1;

sap.ui.controller("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.AddTask", {

	/**

   * Called when a controller is instantiated and its View controls (if available) are already created.

   * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

   * @memberOf view.Task

   */

	onInit: function() {

		this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

		this._oRouter.attachRoutePatternMatched(this._handleRouteMatched, this);

		this.oBusy = new sap.m.BusyDialog();

		this.initStart = false;

		var taskList = {};

		var taskObj = [];

		taskList["myTasks"] = taskObj;

		var myTasksModel = new sap.ui.model.json.JSONModel();

		myTasksModel.setData(taskList);

		var tsModelData = myTasksModel.oData.myTasks;

		var taskData = {};

		//phase 2 with out AddNewTask end

		sap.ui.getCore().setModel(myTasksModel, "myTasksModel")

		this.getView().byId("idTaskDetails").setModel(myTasksModel);

		this.perResGetRequest();

		this.taskGetRequest();

		//console.log(myTasksModel);

	},

	_handleRouteMatched: function(oEvent) {

		var oParamaeters = oEvent.getParameter("name");

		if (oParamaeters !== "addTask") {

			return;

		}

		selectedItem = oEvent.getParameter("arguments").contextPath;

	},

	onClickRelease: function(e) {

		var o;

		var items = this.getView().byId("idTaskDetails").getItems();

		var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;

		var taskArrValue = [];

		var listArrValue = [];

		for (var n = 0; n < items.length; n++) {

			taskArrValue[n] = items[n].getAggregation("cells")[2].getValue();

			listArrValue[n] = items[n].getAggregation("cells")[6].getValue();

		}

		var systemCurDate = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.convertToISODateTime(new Date());

		var sysDate = new Date();

		sysDate.setDate(sysDate.getDate() + 61);

		var systemEndDate = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.convertToISODateTime(sysDate);

		systemCurDate = systemCurDate.split("T");

		systemEndDate = systemEndDate.split("T");

		var systemCurTime = systemCurDate[1].split(".");

		systemCurTime = systemCurTime[0];

		systemCurDate = systemCurDate[0];

		systemEndDate = systemEndDate[0];

		// systemCurTime= systemCurTime[0];

		var items = sap.ui.getCore().byId("AddTask--idTaskDetails").getItems();

		var itemsLen = items.length;

		var flag = true;

		for (var i = 0; i < itemsLen; i++) {

			if (items[i].getAggregation("cells")[5].getText().trim() === "") {

				flag = false;

				items[i].getAggregation("cells")[6].setValueState(sap.ui.core.ValueState.Error);

			}

			if (items[i].getAggregation("cells")[1].getText().trim() === "") {

				flag = false;

				items[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

			}

		}

		if (flag != false) {

			if (items.length > 0) {

				for (var i = 0; i < items.length; i++) {

					items[i].getAggregation("cells")[3].setText("TSRL"); // task status

					items[i].getAggregation("cells")[4].setText("QARV"); // user status

					items[i].getAggregation("cells")[7].setText(systemCurDate);

					items[i].getAggregation("cells")[8].setText(systemCurTime);

					items[i].getAggregation("cells")[9].setText(systemEndDate);

					items[i].getAggregation("cells")[10].setText(systemCurTime);

				}

			}

			this.getView().byId("idTaskDetails").getModel().refresh(true);

			items = this.getView().byId("idTaskDetails").getItems();

			for (var n = 0; n < listArrValue.length; n++) {

				items[n].getAggregation("cells")[2].setValue(taskArrValue[n]);

				items[n].getAggregation("cells")[6].setValue(listArrValue[n]);

			}

		}

		var items = sap.ui.getCore().byId("AddTask--idTaskDetails").getItems();

		var itemsLen = items.length;

		var taskCodeArray = [];

		for (var i = 0; i < itemsLen; i++) {

			var taskCode = items[i].getAggregation("cells")[1].getText();

			taskCodeArray.push(taskCode);

		}

		var taskCodeText = sap.ui.getCore().byId("TaskListDetail--ATTR1").getText();

		var releaseflag = true;

		var c015 = taskCodeArray.indexOf("C015");

		var c016 = taskCodeArray.indexOf("C016");

		var c018 = taskCodeArray.indexOf("C018");

		var c051 = taskCodeArray.indexOf("C051");

		var c052 = taskCodeArray.indexOf("C052");

		if (itemsLen > 0)

		{

			if (taskCodeText === "Forward to QA")

			{

				if (c015 === -1 && c016 === -1)

				{

					releaseflag = false;

					sap.m.MessageBox.alert("QA Approval tasks are mandate.. Please Add");

				}

			} else if (taskCodeText === "QA review and approval of Change control")

			{

				if (c018 === -1 && c051 === -1 && c052 === -1)

				{

					releaseflag = false;

					sap.m.MessageBox.alert("QA Closure tasks are mandate.. Please Add");

				}

			}

		}

		// check for task validation.

		var oTasks = [];

		var oTaskItem = {};

		var oParam = {};

		var m = sap.ui.getCore().byId("TaskListDetail").getModel();

		oParam.NotificationID = sap.ui.getCore().byId("TaskListDetail--objHeader").getTitle();

		var taskNum = parseInt(sap.ui.getCore().byId("TaskListDetail--QT_TASK_NUM").getText());

		var tsModel = sap.ui.getCore().getModel("myTasksModel");

		var tsModelData = tsModel.oData.myTasks;

		// item values for tasks

		if (releaseflag === true) {

			if (tsModelData.length > 0) {

				for (var g = 0; g < tsModelData.length; g++) {

					var taskKey = taskNum + (g + 1);

					var oTaskItem = {};

					var formattedStartDate;

					var formattedEndDate;

					if (tsModelData[g].startDate !== "") {

						formattedStartDate = tsModelData[g].startDate + "T00:00:00";

						formattedEndDate = tsModelData[g].endDate + "T00:00:00";

					} else {

						formattedStartDate = systemCurDate;

						formattedEndDate = systemEndDate;

					}

					oTaskItem.PlannedEndTime = this.setTimeFormat1(tsModelData[g].endTime);

					oTaskItem.PlannedEndDate = formattedEndDate;

					oTaskItem.PersonResponsible = tsModelData[g].perRes;

					oTaskItem.TaskShortText = tsModelData[g].taskText;

					oTaskItem.TaskCode = tsModelData[g].taskCode;

					oTaskItem.TaskCodeGroup = tsModelData[g].codeGroup;

					oTaskItem.TaskKey = "" + taskKey;

					oTaskItem.TaskSortNo = "" + taskKey;

					oTaskItem.TaskStatus = tsModelData[g].taskStatus;

					oTaskItem.UserStatus = tsModelData[g].userStatus;

					oTaskItem.TaskLongText = taskLongText;

					oTaskItem.NotificationID = sap.ui.getCore().byId("TaskListDetail--objHeader").getTitle();

					oTasks.push(oTaskItem);

				}

				oParam.QMTasksCreationSet = oTasks;

			}

			var that = this;

			var r = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.processChangeOperationTasknAttachments(a.getServiceList()[0].masterCollection,

				a.getParams().HTTP_Method.PUT, o, this, oParam);

			if (!r || (r && !r.error)) {

				sap.m.MessageBox.alert("Tasks Created successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction === "OK") {

							that._oRouter = sap.ui.core.UIComponent.getRouterFor(that);

							that._oRouter.navTo("master");

							sap.ui.getCore().byId("TaskList").getModel().refresh(true);

							sap.ui.getCore().getModel("myTasksModel").oData.myTasks = [];

							sap.ui.getCore().byId("AddTask--idTaskDetails").setModel(sap.ui.getCore().getModel("myTasksModel"));

							sap.ui.getCore().byId("AddTask--idTaskDetails").getModel().refresh(true);

						}

					}.bind(that)

				});

			}

		}

	},

	setTimeFormat1: function(cTime) {

		var systemCurTime = cTime.split(":");

		systemCurTime = "PT" + systemCurTime[0] + "H" + systemCurTime[1] + "M" + systemCurTime[2] + "S";

		return systemCurTime;

	},

	hasDuplicatesInRows: function(inArray) {

		for (var row = 0; row < inArray.length; row++) {

			for (var col = 0; col < inArray[row].length; col++) {

				var num = inArray[row][col];

				for (var otherRow = row + 1; otherRow < inArray.length; otherRow++) {

					if (num === inArray[otherRow][col]) {

						for (var otherCol = col + 1; otherCol < inArray[otherRow].length; otherCol++)

						{

							var value = inArray[row][otherCol];

							if (value === inArray[otherRow][otherCol])

							{

								return true;

							}

						}

					}

				}

			}

		}

		return false;

	},

	onNavBack: function() {

		var items = sap.ui.getCore().byId("AddTask--idTaskDetails").getItems();

		var itemsLen = items.length;

		var flag = true;

		var taskCodeArray = [];

		for (var i = 0; i < itemsLen; i++) {

			if (items[i].getAggregation("cells")[5].getText().trim() === "") {

				flag = false;

				items[i].getAggregation("cells")[6].setValueState(sap.ui.core.ValueState.Error);

			}

			if (items[i].getAggregation("cells")[1].getText().trim() === "") {

				flag = false;

				items[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

			}

			var taskCode = items[i].getAggregation("cells")[1].getText();

			taskCodeArray.push(taskCode);

		}

		var taskCodeText = sap.ui.getCore().byId("TaskListDetail--ATTR1").getText();

		var c015 = taskCodeArray.indexOf("C015");

		var c016 = taskCodeArray.indexOf("C016");

		var c018 = taskCodeArray.indexOf("C018");

		var c051 = taskCodeArray.indexOf("C051");

		var c052 = taskCodeArray.indexOf("C052");

		if (itemsLen > 0)

		{

			if (taskCodeText === "Forward to QA")

			{

				if (c015 === -1 && c016 === -1)

				{

					flag = false;

					sap.m.MessageBox.alert("QA Approval tasks are mandate.. Please Add");

				} else {

					var releaseFlag = true;

					for (var g = 0; g < items.length; g++) {

						if (items[g].getAggregation("cells")[3].getText() !== "TSRL") {

							releaseFlag = false;

						}

					}

					if (releaseFlag === false) {

						sap.m.MessageBox.alert("Please release the tasks");

						return false;

					}

				}

			} else

			if (taskCodeText === "QA review and approval of Change control")

			{

				if (c018 === -1 && c051 === -1 && c052 === -1)

				{

					flag = false;

					sap.m.MessageBox.alert("QA Closure tasks are mandate.. Please Add");

				} else {

					var releaseFlag = true;

					for (var g = 0; g < items.length; g++) {

						if (items[g].getAggregation("cells")[3].getText() !== "TSRL") {

							releaseFlag = false;

						}

					}

					if (releaseFlag === false) {

						sap.m.MessageBox.alert("Please release the tasks");

						return false;

					}

				}

			}

		}

		// phase 2 end

		if (flag) {

			i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.setTaskViewLoaded(true);

			window.history.back();

		}

		// phase 2 end

	},

	perResGetRequest: function() {

		this.colon = " : ";

		this.openingBracket = " (";

		this.closingBracket = ")";

		this.itemSet = new sap.ui.core.Item({

			key: "{key}" + this.colon + "{catalogType}" +

			this.colon + "{codeGroup}",

			text: "{title}" + this.openingBracket +

			"{category}" + this.closingBracket,

			active: true

		});

		// Person Responsible

		this.oPerResInput = this.byId("QI_ANT_LIST_NAME_TEXT_INPUT");

		var aTask = [];

		var bPerRes = [{

			output: "key",

			source: "PersonResponsible"

                                }, {

			output: "title",

			source: "ListName"

                                }, {

			output: "codeGroup",

			source: "PersonResponsible"

                                }, {

			output: "category",

			source: "PersonResponsible"

                                }, {

			output: "catalogType",

			source: "PersonResponsible"

                                }];

		aTask.push({

			indexCollection: 0,

			arConversionRules: bPerRes,

			itemsPrefix: "items"

		});

		var d = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.getCollectionPerRes(aTask, this);

		this.l = d && d.length > 0 && d[0];

		this.m = new sap.ui.model.json.JSONModel();

		this.m.setData(this.l);

		this.oPerResInput.setModel(this.m);

		this.getView().setModel(this.m, "perResModel");

		this.oPerResInput.bindAggregation("suggestionItems", "/items", this.itemSet);

		this.selectedPerRes = new sap.m.StandardListItem({

			key: "{key}",

			codeGroup: "{codeGroup}",

			category: "{category}",

			title: "{title}",

			catalogType: "{catalogType}",

			active: true

		});

	},

	onPerResSelect: function(e) {

		selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

		if (!this.PerResSelectDialog) {

			this.PerResSelectDialog = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils

			.FragmentHelperExt.createF4HelpSelectDialog(this,

				"PerResSelectDialog", this.oPerResInput.getModel()

			)

		}

		this.setInitialFilter(e.getSource()._lastValue, this.PerResSelectDialog)

	},

	filterDialog: function(v, i) {

		var f = [];

		var s = new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v);

		f.push(s);

		i.filter(f);

	},

	setInitialFilter: function(f, s) {

		f = f.split(this.openingBracket)[0];

		s.open(f);

		var i = s.getBinding("items");

		if (!$.isBlank(f)) {

			this.filterDialog(f, i)

		} else if (f === "" && i.aFilters.length > 0) {

			this.filterDialog(f, i)

		}

	},

	onSuggestionItemSelected: function(e) {

		var v = e.getParameter("selectedItem");

		if (v !== undefined) {

			var t = new sap.m.StandardListItem({

				key: "{key}",

				codeGroup: "{codeGroup}",

				category: "{category}",

				title: "{title}",

				catalogType: "{catalogType}"

			});

			var p = v.mProperties.key.split(this.colon);

			t.key = p[0];

			t.catalogType = p[1];

			t.codeGroup = p[2];

			p = v.mProperties.text.split(this.openingBracket);

			t.title = p[0];

			t.category = p[1].split(this.closingBracket)[0];

			//

			var items = this.getView().byId("idTaskDetails").getItems();

			selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

			items[selectedIndex1].getAggregation("cells")[6] = t.category;

			items[selectedIndex1].getAggregation("cells")[5].setText(t.key);

			this.array = [];

			for (var j = 0; j < items.length; j++) {

				var inputValue = items[j].getAggregation("cells")[1].getText();

				var inputPersValue = items[j].getAggregation("cells")[5].getText();

				this.arrayInner = new Array(2);

				this.arrayInner[0] = inputValue;

				this.arrayInner[1] = inputPersValue;

				this.array.push(this.arrayInner);

			}

			var flag = this.hasDuplicatesInRows(this.array);

			if (flag)

			{

				sap.m.MessageBox.alert("Same task cannot be assigned to same User");

				items[selectedIndex1].getAggregation("cells")[5].setText("");

				items[selectedIndex1].getAggregation("cells")[6].setValue("");

			}

			if (e.getSource() === this.oPerResInput) {

				this.selectedPerRes = t;

			}

		}

	},

	onSuggest: function(e) {

		var v = e.getParameter("suggestValue");

		selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

		if (v !== undefined) {

			this.byId(e.getSource().getId()).setModel(this.m);

			this.byId(e.getSource().getId()).bindAggregation("suggestionItems", "/items", this.itemSet);

			var oFilter = new sap.ui.model.Filter([

                          new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.Contains, v),

                          new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v)

                          ], false);

			e.getSource().getBinding("suggestionItems").filter([oFilter]);

			this.filterDialog(e.getSource().getBinding("suggestionItems").filter([oFilter]));

			//this.filterDialog(v, e.getSource().getBinding("suggestionItems"));

			if (e.getSource() === this.oPerResInput) {

				this.selectedPerRes = "";

			}

			e.getSource().setValueState(sap.ui.core.ValueState.None)

		}

	},

	searchDefectLocation: function(e) {

		var v = e.getParameter("value");

		if (v !== undefined) {

			var oFilter = new sap.ui.model.Filter([

                          new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.Contains, v),

                          new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v)

                          ], false);

			e.getSource().getBinding("items").filter([oFilter]);

			this.filterDialog(e.getSource().getBinding("items").filter([oFilter]));

			//this.filterDialog(v, e.getSource().getBinding("items"));

		}

	},

	cancelDefectSelectDialog: function(e) {},

	confirmDefectSelectDialog: function(e) {

		var s = e.getParameter("selectedItem");

		var items = this.getView().byId("idTaskDetails").getItems();

		var i;

		var p = s.oBindingContexts.undefined.sPath.split("/");

		if ("PerResSelectDialog" === e.getSource().sId) {

			i = items[selectedIndex1].getAggregation("cells")[6];

		}

		if (s) {

			var p = s.oBindingContexts.undefined.sPath.split("/");

			var a = p[p.length - 1];

			i.setValue(s.getTitle());

			i.setValueState(sap.ui.core.ValueState.None);

			var b = s.oBindingContexts.undefined.oModel.oData.items[a];

			this.array = [];

			for (var j = 0; j < items.length; j++) {

				var inputValue = items[j].getAggregation("cells")[1].getText();

				var inputPersValue = items[j].getAggregation("cells")[6].getValue();

				if (inputPersValue.indexOf("(") !== -1)

				{

					var p = inputPersValue.split("(");

					inputPersValue = p[0];

					inputPersValue = p[0].slice(0, -1);

				}

				this.arrayInner = new Array(2);

				this.arrayInner[0] = inputValue;

				this.arrayInner[1] = inputPersValue;

				this.array.push(this.arrayInner);

			}

			var flag = this.hasDuplicatesInRows(this.array);

			if (flag)

			{

				sap.m.MessageBox.alert("Same task cannot be assigned to same User");

				items[selectedIndex1].getAggregation("cells")[5].setText("");

				items[selectedIndex1].getAggregation("cells")[6].setValue("");

			} else

			{

				i.setValue(b.title);

				items[selectedIndex1].getAggregation("cells")[5].setText(b.key);

				items[selectedIndex1].getAggregation("cells")[6] = b;

			}

		}

	},

	listChanged: function(e) {

		selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

		var items = this.getView().byId("idTaskDetails").getItems();

		items[selectedIndex1].getAggregation("cells")[5].setText("");

		items[selectedIndex1].getAggregation("cells")[6].setValueState(sap.ui.core.ValueState.None);

		items[selectedIndex1].getAggregation("cells")[7].setText("");

		items[selectedIndex1].getAggregation("cells")[9].setText("");

	},

	onClickAddTask: function(e) {

		var myTasksModel = this.getView().byId("idTaskDetails").getModel();

		var items = this.getView().byId("idTaskDetails").getItems();

		var taskArrValue = [];

		var listArrValue = [];

		for (var n = 0; n < items.length; n++) {

			taskArrValue[n] = items[n].getAggregation("cells")[2].getValue();

			listArrValue[n] = items[n].getAggregation("cells")[6].getValue();

		}

		var tsModelData = myTasksModel.oData.myTasks;

		var taskData = {};

		taskData.codeGroup = "";

		taskData.taskCode = "";

		taskData.taskCodeText = "";

		taskData.taskStatus = "TSOS";

		taskData.userStatus = "INIT";

		taskData.perRes = "";

		taskData.listName = "";

		taskData.startDate = "";

		taskData.endDate = "";

		taskData.Updkz = "I";

		tsModelData.push(taskData);

		this.getView().byId("idTaskDetails").setModel(myTasksModel);

		this.getView().byId("idTaskDetails").getModel().refresh(true);

		items = this.getView().byId("idTaskDetails").getItems();

		for (var n = 0; n < listArrValue.length; n++) {

			items[n].getAggregation("cells")[2].setValue(taskArrValue[n]);

			items[n].getAggregation("cells")[6].setValue(listArrValue[n]);

		}

	},

	onClickDeleteTask: function(e) {

		var selectedList = this.getView().byId("idTaskDetails").getSelectedItems();

		for (var i = 0; i < selectedList.length; i++) {

			if (selectedList[i].getAggregation("cells")[11].getText() !== "")

				selectedList[i].getAggregation("cells")[11].setText("D");

		}

		if (selectedList.length > 0) {

			var items = this.getView().byId("idTaskDetails").getItems();

			var taskList = {};

			var taskObj = [];

			taskList["myTasks"] = taskObj;

			var myTasksModelNew = new sap.ui.model.json.JSONModel();

			myTasksModelNew.setData(taskList);

			var tsModelDataNew = myTasksModelNew.oData.myTasks;

			var count = 0;

			var taskArrValue = [];

			var listArrValue = [];

			for (var k = 0; k < items.length; k++) {

				if (items[k].getAggregation("cells")[11].getText() === "" || items[k].getAggregation("cells")[11].getText() === "I") {

					var taskData = {};

					taskData.codeGroup = items[k].getAggregation("cells")[0].getText();

					taskData.taskCode = items[k].getAggregation("cells")[1].getText();

					taskArrValue[count] = items[k].getAggregation("cells")[2].getValue();

					//taskData.taskCodeText = "Forward to HOD/Designee";

					taskData.taskStatus = items[k].getAggregation("cells")[3].getText();

					taskData.userStatus = items[k].getAggregation("cells")[4].getText();

					taskData.perRes = items[k].getAggregation("cells")[5].getText();

					listArrValue[count] = items[k].getAggregation("cells")[6].getValue();

					//taskData.listName = "";

					taskData.startDate = items[k].getAggregation("cells")[7].getText();

					taskData.startTime = items[k].getAggregation("cells")[8].getText();

					taskData.endDate = items[k].getAggregation("cells")[9].getText();

					taskData.endTime = items[k].getAggregation("cells")[10].getText();

					taskData.Updkz = items[k].getAggregation("cells")[11].getText();

					tsModelDataNew.push(taskData);

					count++;

				}

			}

			this.getView().byId("idTaskDetails").setModel(myTasksModelNew);

			this.getView().byId("idTaskDetails").getModel().refresh(true);

			sap.ui.getCore().getModel("myTasksModel").setData(this.getView().byId("idTaskDetails").getModel().getData());

			items = this.getView().byId("idTaskDetails").getItems();

			for (var n = 0; n < listArrValue.length; n++) {

				items[n].getAggregation("cells")[2].setValue(taskArrValue[n]);

				items[n].getAggregation("cells")[6].setValue(listArrValue[n]);

			}

		}

	},

	taskGetRequest: function() {

		var i = new sap.ui.core.Item({

			key: "{key}" + this.colon + "{catalogType}" +

			this.colon + "{codeGroup}",

			text: "{title}" + this.openingBracket +

			"{category}" + this.closingBracket,

			active: true

		});

		this.oTaskInput = this.byId("QI_ANT_TASK_CODE_INPUT");

		var aTask = [];

		var bTask = [{

			output: "key",

			source: "TaskCodeGroupText"

                                }, {

			output: "title",

			source: "TaskCodeText"

                                }, {

			output: "codeGroup",

			source: "TaskCodeGroup"

                                }, {

			output: "category",

			source: "TaskCode"

                                }, {

			output: "catalogType",

			source: "TaskCatalogType"

                                }];

		aTask.push({

			indexCollection: 0,

			arConversionRules: bTask,

			itemsPrefix: "items"

		});

		var taskArrList = {};

		var taskArr = [];

		taskArrList["items"] = taskArr;

		this.mTask = new sap.ui.model.json.JSONModel();

		this.oTaskInput.setModel(this.mTask);

		var tasksActPlan = ["C016", "C017", "C018", "C019", "C020", "C021", "C022", "C023", "C038", "C039", "C040", "C041", "C051", "C052",
			"C056"];

		var tasksQA = ["C003", "C004", "C005", "C006", "C007", "C008", "C009", "C010", "C011", "C012", "C013", "C014", "C015", "C024",

                    "C025", "C026", "C027", "C028", "C029", "C030", "C031", "C032", "C033", "C034", "C035", "C036", "C037",

                    "C042", "C043", "C044", "C045", "C046", "C047", "C048", "C049", "C050", "C053", "C054", "C055", "C057", "C058", "C059",
			"C060", "C061"];

		var taskCodeText = sap.ui.getCore().byId("TaskListDetail--ATTR1").getText();

		var dTask = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.getCollectionTask(aTask, this);

		this.lTask = dTask && dTask.length > 0 && dTask[0];

		for (var task = 0; task < this.lTask.items.length; task++) {

			var taskCode = this.lTask.items[task].category;

			if (taskCode != "C001" && taskCode != "C002") {

				if (taskCodeText === "Forward to QA")

				{

					for (var t = 0; t < tasksQA.length; t++)

					{

						if (taskCode === tasksQA[t])

						{

							taskArr.push(this.lTask.items[task]);

							break;

						}

					}

				} else if (taskCodeText === "QA review and approval of Change control" || taskCodeText === "QA Approval for Major Changes")

				{

					for (var t = 0; t < tasksActPlan.length; t++)

					{

						if (taskCode === tasksActPlan[t])

						{

							taskArr.push(this.lTask.items[task]);

							break;

						}

					}

				}

			}

		}

		this.mTask.setData(taskArrList);

		this.oTaskInput.setModel(this.mTask);

		this.oTaskInput.bindAggregation("suggestionItems", "/items", this.itemSet);

		this.selectedTaskCode = new sap.m.StandardListItem({

			key: "{key}",

			codeGroup: "{codeGroup}",

			category: "{category}",

			title: "{title}",

			catalogType: "{catalogType}",

			active: true

		});

		if (this.TaskSelectDialog) {

			try {

				this.TaskSelectDialog.destroy();

				this.TaskSelectDialog = null;

			} catch (e) {}

		}

	},

	onTaskSelect: function(e) {

		this.taskGetRequest();

		selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

		if (!this.TaskSelectDialog) {

			this.TaskSelectDialog = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils

			.FragmentHelperExt.createF4HelpSelectDialog(this,

				"TaskSelectDialog", this.oTaskInput.getModel()

			)

		}

		this.setInitialFilter(e.getSource()._lastValue, this.TaskSelectDialog)

	},

	taskChanged: function(e) {

		selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

		var items = this.getView().byId("idTaskDetails").getItems();

		items[selectedIndex1].getAggregation("cells")[0].setText("");

		items[selectedIndex1].getAggregation("cells")[1].setText("");

		items[selectedIndex1].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.None);

		items[selectedIndex1].getAggregation("cells")[7].setText("");

		items[selectedIndex1].getAggregation("cells")[9].setText("");

	},

	onSuggestionItemSelectedTask: function(e) {

		var v = e.getParameter("selectedItem");

		if (v !== undefined) {

			var t = new sap.m.StandardListItem({

				key: "{key}",

				codeGroup: "{codeGroup}",

				category: "{category}",

				title: "{title}",

				catalogType: "{catalogType}"

			});

			var p = v.mProperties.key.split(this.colon);

			t.key = p[0];

			t.catalogType = p[1];

			t.codeGroup = p[2];

			p = v.mProperties.text.split(this.openingBracket);

			t.title = p[0];

			t.category = p[1].split(this.closingBracket)[0];

			//

			var items = this.getView().byId("idTaskDetails").getItems();

			selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

			items[selectedIndex1].getAggregation("cells")[0].setText(t.codeGroup);

			items[selectedIndex1].getAggregation("cells")[1].setText(t.category);

			items[selectedIndex1].getAggregation("cells")[2] = t.title;

			if (e.getSource() === this.oTaskInput) {

				this.selectedTaskCode = t;

			}

			//

		}

	},

	onSuggestTask: function(e) {

		var v = e.getParameter("suggestValue");

		selectedIndex1 = parseInt(e.getSource().getId().split("idTaskDetails-")[1]);

		if (v !== undefined) {

			this.byId(e.getSource().getId()).setModel(this.mTask);

			this.byId(e.getSource().getId()).bindAggregation("suggestionItems", "/items", this.itemSet);

			var oFilter = new sap.ui.model.Filter([

                          new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.Contains, v),

                          new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v)

                          ], false);

			e.getSource().getBinding("suggestionItems").filter([oFilter]);

			this.filterDialog(e.getSource().getBinding("suggestionItems").filter([oFilter]));

			//this.filterDialog(v, e.getSource().getBinding("suggestionItems"));

			if (e.getSource() === this.oTaskInput) {

				this.selectedTaskCode = "";

			}

			e.getSource().setValueState(sap.ui.core.ValueState.None)

		}

	},

	confirmTaskSelectDialog: function(e) {

		var s = e.getParameter("selectedItem");

		var items = this.getView().byId("idTaskDetails").getItems();

		var i;

		var p = s.oBindingContexts.undefined.sPath.split("/");

		if ("TaskSelectDialog" === e.getSource().sId) {

			i = items[selectedIndex1].getAggregation("cells")[2];

		}

		if (s) {

			var p = s.oBindingContexts.undefined.sPath.split("/");

			var a = p[p.length - 1];

			i.setValue(s.getTitle());

			i.setValueState(sap.ui.core.ValueState.None);

			var b = s.oBindingContexts.undefined.oModel.oData.items[a];

			i.setValue(b.title);

			items[selectedIndex1].getAggregation("cells")[0].setText(b.codeGroup);

			items[selectedIndex1].getAggregation("cells")[1].setText(b.category);

			items[selectedIndex1].getAggregation("cells")[2] = b;

		}

	}

});