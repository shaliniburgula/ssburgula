/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
 var taskListName;
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.DateTimeConversions");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.StatusHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.StatusHelperExt");
jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.FragmentHelper");
jQuery.sap.require("sap.m.DatePicker");
jQuery.sap.require("sap.ca.scfld.md.app.MasterHeaderFooterHelper");
jQuery.sap.require("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.FragmentHelperExt");
sap.ui.controller("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.S2Custom", {
	onInit: function() {
	    
		   sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
	        	this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		this._oRouter.attachRoutePatternMatched(this._handleRouteMatched, this);
		
		   
	},
	_handleRouteMatched: function(oEvent) {
		var oParamaeters = oEvent.getParameter("name");
		if (oParamaeters != "master") {
			return;
		}
		
		    taskListName = oEvent.getParameter("arguments").contextPath;
	},
	navToEmptyView: function() {
		this.showEmptyView("DETAIL_TITLE", "NO_ITEMS_AVAILABLE");
	},
	  _showLoadingText: function(l) {
	    if (l) {
	      this.getList().setNoDataText(this.resourceBundle.getText("QT_LOADING_TEXT"))
	    } else {
	         sap.ui.getCore().byId("TaskList--masterpage").setTitle("My Tasks(0)");
	      this.getList().setNoDataText(this.resourceBundle.getText("QT_NO_DATA_AVAILABLE"))
	       this.getView().byId("list").setSelectedItem(0);
	    }
	  },
	  getSettings: function(S) {
	    jQuery.sap.require("i2d.qm.task.tracknconfirm.utils.Helper");
	    this.objSettings = localStorage.getObj(S);
	    if (this.objSettings === null) {
	      var d = i2d.qm.task.tracknconfirm.utils.Helper.getCollection(1, [], this, true);
	      if (d) {
	        this.objSettings = {
	          maxHits: d.MaxHits
	        };
	        localStorage.setObj(S, this.objSettings)
	      }
	      if (this.objSettings === null) {
	        this.objSettings = {
	          maxHits: 30
	        };
	        localStorage.setObj(S, this.objSettings)
	      }
	    }
	  },
	handleUpdateFinished: function(c) {

    var v = this.getView();

        var items = this.oList.getItems();
			this.oList.setSelectedItem(items[0]);
		//	sap.ui.getCore().byId("TaskList--list").fireSelect(items[0]);
		if(items.length>0)
		{
			var bindingContext = this.oList.getSelectedItem().getBindingContext().sPath;
			var sPath = bindingContext.split("/");
			this._oRouter.navTo("detail",{contextPath:sPath[1]});
		}
		else
		{
		    
		}
		if (!jQuery.device.is.phone && (c.getParameters().reason === "Filter" || c.getParameters().reason === "Change" || c.getParameters().reason ===
			"Refresh" || c.getParameters().reason === "Binding")) {
			if (this.oRouter._oRouter._prevMatchedRequest === "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {
				this.oList.removeSelections()
			} else if (this.oList.getSelectedItem()) {
				var b = this.oList.getSelectedItem().getBindingContext();
				this.handleSelectionChangeRefresh(c, b)
			}
			if (this.getList().getItems().length == "0") {
				this._showLoadingText(false)
			} else {
				this._showLoadingText(true)
			}
		}
	},
	handleSelectionChange: function(c, b) {
		if (!jQuery.device.is.phone) {
			if (!b) {
				b = c.getParameter("listItem").getBindingContext()
			}
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
			sap.ui.getCore().getEventBus().publish(a, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, {
				context: b
			})
		}

		var sPath = b.sPath;
		sPath = sPath.split("/");
		var taskCodeText = b.oModel.oData[sPath[1]].TaskCodeText;
		var notificationId = b.oModel.oData[sPath[1]].NotificationID;

		var dModel = new sap.ui.model.json.JSONModel();
		var oContext = this.getView().getBindingContext();
		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_TASK_SRV/", true, "", "");
		var path = "QMNotificationSelectionSet(NotificationID='" + notificationId + "',Notification='" + notificationId + "')";

		oDataModel.read(path, oContext, [], false, function(data) {
			dModel.setData(data);

		}, function(err) {
			console.log("inside failure");
		});
		sap.ui.getCore().setModel(dModel, "CCModel");
		sap.ui.getCore().byId("TaskListDetail").setModel(dModel, "CCModel");
		sap.ui.getCore().byId("TaskList").setModel(dModel, "CCModel");

	
	
		//Multiple Batches

		var batchModel = new sap.ui.model.json.JSONModel();
		var oDataModelBatch = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_NOTIF_SRV/", true, "", "");
		var pathBatch = "QMAssignedObjectsCreationSet?$filter=NotificationID eq '" + notificationId + "'";

		oDataModelBatch.read(pathBatch, oContext, [], false, function(data) {
			batchModel.setData(data);

		}, function(err) {
			console.log("inside failure");
		});
		sap.ui.getCore().setModel(batchModel, "BatchModel");
		sap.ui.getCore().byId("TaskListDetail--idTaskDetails").setModel(batchModel, "BatchModel");

		if (batchModel.oData.results.length <= 0) {
			sap.ui.getCore().byId("TaskListDetail--idMultipleBatches").setVisible(false);
			sap.ui.getCore().byId("TaskListDetail--idTaskDetails").setVisible(false);
		} else {
			sap.ui.getCore().byId("TaskListDetail--idMultipleBatches").setVisible(true);
			sap.ui.getCore().byId("TaskListDetail--idTaskDetails").setVisible(true);
		}

		if (taskCodeText == "Forward to QA") {
			var taskStatus = b.oModel.oData[sPath[1]].Status;
			if (taskStatus === "I0156") {
				sap.ui.getCore().byId("TaskListDetail--NOTES_ICON_TAB").setVisible(false);
				sap.ui.getCore().byId("TaskListDetail--fileUploader").setVisible(false);
		        sap.ui.getCore().byId("TaskListDetail--idFileTable").setVisible(false);
		        sap.ui.getCore().byId("TaskListDetail--idBtnUpload").setVisible(false);
			} else {
				sap.ui.getCore().byId("TaskListDetail--NOTES_ICON_TAB").setVisible(true);
					sap.ui.getCore().byId("TaskListDetail--fileUploader").setVisible(true);
		        sap.ui.getCore().byId("TaskListDetail--idFileTable").setVisible(true);
		        sap.ui.getCore().byId("TaskListDetail--idBtnUpload").setVisible(true);
			}
		} else {
			sap.ui.getCore().byId("TaskListDetail--NOTES_ICON_TAB").setVisible(false);
				sap.ui.getCore().byId("TaskListDetail--fileUploader").setVisible(false);
		        sap.ui.getCore().byId("TaskListDetail--idFileTable").setVisible(false);
		        sap.ui.getCore().byId("TaskListDetail--idBtnUpload").setVisible(false);

		}

		sap.ui.getCore().byId("TaskListDetail--QI_DESC_LONG_TEXT_INPUT").setValue("")

		var myjson = new sap.ui.model.json.JSONModel();
		var mydata = {
			"myFiles": [
                                                                ]
		};
		myjson.setData(mydata);
		sap.ui.getCore().byId("TaskListDetail--idFileTable").setModel(myjson);

		if (i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.getTaskViewLoaded()) {
			var currentTaskModel = sap.ui.getCore().getModel("myTasksModel");
			sap.ui.getCore().getModel("myTasksModel").oData.myTasks = [];

			sap.ui.getCore().byId("AddTask--idTaskDetails").setModel(sap.ui.getCore().getModel("myTasksModel"));
			sap.ui.getCore().byId("AddTask--idTaskDetails").getModel().refresh(true);
		}

	},

	onBeforeRendering: function() {
		

	},


	handleSelectionChangeRefresh: function(c, b) {
		if (!jQuery.device.is.phone) {
			if (!b) {
				b = c.getParameter("listItem").getBindingContext()
			}
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
			sap.ui.getCore().getEventBus().publish(a, sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().eventListItemSelected, {
				context: b
			})
		}

		var sPath = b.sPath;
		sPath = sPath.split("/");
		var taskCodeText = b.oModel.oData[sPath[1]].TaskCodeText;
		var notificationId = b.oModel.oData[sPath[1]].NotificationID;
        var taskNum = b.oModel.oData[sPath[1]].TaskNum;
		var dModel = new sap.ui.model.json.JSONModel();
		var oContext = this.getView().getBindingContext();
		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_TASK_SRV/", true, "", "");
		var path = "QMNotificationSelectionSet(NotificationID='" + notificationId + "',Notification='" + notificationId + "')";

		oDataModel.read(path, oContext, [], false, function(data) {
			dModel.setData(data);

		}, function(err) {
			console.log("inside failure");
		});
		sap.ui.getCore().setModel(dModel, "CCModel");
		sap.ui.getCore().byId("TaskListDetail").setModel(dModel, "CCModel");
        sap.ui.getCore().byId("TaskList").setModel(dModel, "CCModel");
        
       /* var model = sap.ui.getCore().getModel("CCModel").getData();
        var plant = model.Plant;
        var plantName = model.PlantName;
        
        var attr3  = plant +"-" +plantName;
        sap.ui.getCore().byId("TaskList--ATTR3").setText(attr3);*/
	
		//Multiple Batches

		var batchModel = new sap.ui.model.json.JSONModel();
		var oDataModelBatch = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_NOTIF_SRV/", true, "", "");
		var pathBatch = "QMAssignedObjectsCreationSet?$filter=NotificationID eq '" + notificationId + "'";

		oDataModelBatch.read(pathBatch, oContext, [], false, function(data) {
			batchModel.setData(data);

		}, function(err) {
			console.log("inside failure");
		});
		sap.ui.getCore().setModel(batchModel, "BatchModel");
		sap.ui.getCore().byId("TaskListDetail--idTaskDetails").setModel(batchModel, "BatchModel");

		if (batchModel.oData.results.length <= 0) {
			sap.ui.getCore().byId("TaskListDetail--idMultipleBatches").setVisible(false);
			sap.ui.getCore().byId("TaskListDetail--idTaskDetails").setVisible(false);
		} else {
			sap.ui.getCore().byId("TaskListDetail--idMultipleBatches").setVisible(true);
			sap.ui.getCore().byId("TaskListDetail--idTaskDetails").setVisible(true);
		}
		if (taskCodeText == "Forward to QA") {
			var taskStatus = b.oModel.oData[sPath[1]].Status;
			if (taskStatus === "I0156") {
				sap.ui.getCore().byId("TaskListDetail--NOTES_ICON_TAB").setVisible(false);
			} else {
				sap.ui.getCore().byId("TaskListDetail--NOTES_ICON_TAB").setVisible(true);
			}
		} else {
			sap.ui.getCore().byId("TaskListDetail--NOTES_ICON_TAB").setVisible(false);

		}

	},

	  onExit: function() {
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroySortDialog();
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroyFilterDialog();
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.destroyCustSetDialog();
	    var l = sap.ui.getCore().byId(this.getView().sId + "--footer");
	    if (l && l.destroy) {
	      l.destroy()
	    }
	  },
	  handleRefresh: function() {
	    this.setMaxHitsToList();
	    this.getList().removeSelections();
	    this.getList().getBinding("items")._refresh()
	  },
	  setMaxHitsToList: function() {
	    var m =  this.getList().getModel();
	    m.setCountSupported(false);
	    m.setSizeLimit(this.objSettings.maxHits)
	  },
	getHeaderFooterOptions: function() {
	    var numItems = this.getView().byId("list").getBinding("items").getLength();		
		 sap.ui.getCore().byId("TaskList--masterpage").setTitle("My Tasks("+numItems +")");
		 
		 var items = this.getView().byId("list").getItems();
		 this.getView().byId("list").setSelectedItem(items[0]);
		return {
		  
			sI18NMasterTitle: "My Tasks("+numItems +")",
			buttonList: [],
			oFilterOptions: {
				onFilterPressed: $.proxy(this.onFilter, this)
			},
			oSortOptions: {
				onSortPressed: $.proxy(this.onSort, this)
			},
			oGroupOptions: {
				aGroupItems: [{
					text: this.resourceBundle.getText("QT_CLEAR"),
					key: "None"
        }, {
					text: this.resourceBundle.getText("QT_DV_DUE_DATE"),
					key: "DueDate"
        }, {
					text: this.resourceBundle.getText("QT_TASK_CODE_TEXT"),
					key: "TaskCodeText"
        }, {
					text: this.resourceBundle.getText("QT_STATUS_TEXT"),
					key: "Status"
        }, {
					text: "Logical Status",
					key: "LogicalStatus"
        }
        ],
				onGroupSelected: jQuery.proxy(function(k) {
					this.onGroup(k);
					jQuery.sap.log.info(k + " has been selected")
				}, this),
			},
			aAdditionalSettingButtons: [{
				sId: "Settings",
				sI18nBtnTxt: "QT_BUTTON_SETTINGS",
				sIcon: "sap-icon://action-settings",
				onBtnPressed: jQuery.proxy(function(e) {
					this.onSettingsPressed()
				}, this)
      }],
		}
	},
	  applySearchPatternToListItem: function(i, f) {
	    if (i.isSelectable()) {
	      if (f.substring(0, 1) === "#") {
	        var t = f.substr(1);
	        var d = i.getBindingContext().getProperty("Name").toLowerCase();
	        return d.indexOf(t) === 0
	      } else {
	        return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
	      }
	    }
	  },
	  isLiveSearch: function() {
	    this.getList().setNoDataText(this.resourceBundle.getText("QT_NO_DATA_AVAILABLE"));
	    return false
	  },
	  setInfoLabel: function(r, t, i, f) {
	    if (i === null) i = true;
	    this.oMasterModel.setProperty('/toogleSubmit', i);
	    if (i === false) return;
	    var l = this.getView().byId("labelTB");
	    var a = "";
	    if (t) a = this.resourceBundle.getText(t);
	    else a = f;
	    var t = this.resourceBundle.getText(r, [a]);
	    l.setText(t);
	    l.setTooltip(t)
	  },
	  onGroup: function(k) {
	    switch (k) {
	      case "None":
	        if (this.oList.getBinding("items").isGrouped()) {
	          this.oList.bindAggregation("items", {
	            path: "/QMTaskSet",
	            template: this.oTemplate,
	            sorter: this.oSorter,
	            filters: this.aTableFilters
	          });
	          this.registerMasterListBind(this.oList)
	        }
	        break;
	      case "DueDate":
	        var d = new sap.ui.model.Sorter("DueDate", false, function(c) {
	          var a;
	          a = c.getProperty("DueDate");
	          return {
	            key: i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue(a),
	            text: i2d.qm.task.tracknconfirm.utils.DateTimeConversions.formatGroupDaysDue(a)
	          }
	        });
	        this.oGroupSorter = d;
	        this.oList.bindAggregation("items", {
	          path: "/QMTaskSet",
	          template: this.oTemplate,
	          sorter: d,
	          filters: this.aTableFilters
	        });
	        this.registerMasterListBind(this.oList);
	        break;
	      case "TaskCodeText":
	        var t = new sap.ui.model.Sorter("TaskCodeText", false, true);
	        this.oGroupSorter = t;
	        this.oList.bindAggregation("items", {
	          path: "/QMTaskSet",
	          template: this.oTemplate,
	          sorter: t,
	          filters: this.aTableFilters
	        });
	        this.registerMasterListBind(this.oList);
	        break;
	      case "Status":
	        var s = new sap.ui.model.Sorter("Status", false, function(c) {
	          var k = c.getProperty("StatusText");
	          return {
	            key: k,
	            text: "Task Status: " + k
	          }
	        });
	        this.oGroupSorter = s;
	        this.oList.bindAggregation("items", {
	          path: "/QMTaskSet",
	          template: this.oTemplate,
	          sorter: s,
	          filters: this.aTableFilters
	        });
	        this.registerMasterListBind(this.oList);
	        break;
	        case "LogicalStatus":
	       var l = new sap.ui.model.Sorter("LogicalStatus", false, true);
	        this.oGroupSorter = l;
	        this.oList.bindAggregation("items", {
	          path: "/QMTaskSet",
	          template: this.oTemplate,
	          sorter: l,
	          filters: this.aTableFilters
	        });
	        this.registerMasterListBind(this.oList);
	    }
	  },
	  setFilterInfoLabel: function(a) {
	    if (!$.isArray(a) || a.length < 1) {
	      this.setInfoLabel('', '', false, '');
	      return
	    }
	    var i = "",
	      d = this.resourceBundle.getText("QT_DV_DUE_DATE"),
	      s = this.resourceBundle.getText("QT_STATUS_TEXT");
	      l = "Logical Status";
	    $.each(a, function(b, f) {
	      if (i2d.qm.task.tracknconfirm.utils.Helper.isValidDate(f.oValue1)) {
	        if (f.oValue1 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate && f.oValue2 ===
	          sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate) {
	          return false
	        }
	        f.oValue1 = f.oValue1.substring(0, 10);
	        f.oValue2 = f.oValue2.substring(0, 10);
	        i += d + ": " + f.oValue1 + ", " + f.oValue2
	      } else if(f.sPath === s)
	      {if (f.oValue1) {
	        if (i.indexOf(s) === -1) {
	          i += s + ": " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(f.oValue1)
	        }else {
    	          i += ", " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(f.oValue1)
    	        }
	        
	        }}  else if(f.sPath === "LogicalStatus")
	      {
	      	if (i.indexOf(l) === -1) {
	          i +=" " + l + ": " + f.oValue1;
	        }else {
	            i += "," + f.oValue1;
	        }
	        
	      }
	        
	      
	    });
	    i += ";";
	    this.setInfoLabel("QT_FILTERED_BY", null, true, i)
	  },
	  onFilter: function(e) {
	    this.aFilterBy = [];
	    i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.FragmentHelperExt.openFilterDialog(this)
	  },
	  navBack: function() {
	    window.history.back()
	  },
	  onAfterRendering: function() {
	    i2d.qm.task.tracknconfirm.utils.Helper.resetFooterContentRightWidth(this)
	  },
	  onConfirmFilterDialog: function(e) {
	    this._showLoadingText(true);
	    var p = e.getParameters();
	    this.aTableFilters = [];
	    if (this.invalidDateTo || this.invalidDateFrom) {
	      this.setInfoLabel("QT_INVALID_DATES_ERROR", null, true, null);
	      this._showLoadingText(false);
	      return
	    }
	    if ((new Date(this.dateToUTC)).getTime() < (new Date(this.dateFromUTC).getTime())) {
	      this.setInfoLabel("QT_TO_DATE_AFTER_FROM_DATE_ERROR", null, true, null);
	      this._showLoadingText(false);
	      return
	    }
	    $.each(p.filterItems, $.proxy(function(i, f) {
	      if (f.sId === "StatusCCReview" || f.sId === "StatusCCPendingCFT" || f.sId === "StatusCCApproval" || f.sId === "StatusCCPendingAction" || f.sId === "StatusCCClosure" || f.sId === "StatusCCClosed" || f.sId === "StatusAction" || f.sId === "StatusCFTTeam" ||
	        f.sId === "StatusNew" || f.sId === "StatusInProcess" || f.sId === "StatusCompleted" || f.sId === "StatusPostponed") {
	        this.aTableFilters.push(f.getCustomData()[0].getValue().filters)
	      }
	    }, this));
	    if (this.shouldCreateDateFilterObject()) {
	      this.aTableFilters.push(new sap.ui.model.Filter("DueDate", sap.ui.model.FilterOperator.BT, this.dateFromUTC, this.dateToUTC))
	    }
	    if (this.dateFromUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate) {
	      this.dateFromUTC = null
	    }
	    if (this.dateToUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate) {
	      this.dateToUTC = null
	    }
	    this.getList().getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);
	    this.setFilterInfoLabel(this.aTableFilters);
	    this.previousDateFromUTC = this.DateFromUTCValue;
	    this.previousDateToUTC = this.DateToUTCValue
	  },
	  onCancelFilterDialog: function(e) {
	    this.DateFromUTCValue = this.previousDateFromUTC;
	    this.DateToUTCValue = this.previousDateToUTC;
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.resetFilterDialogDateFilter(this.previousDateFromUTC, this.previousDateToUTC)
	  },
	  onChangeDateFrom: function(e) {
	    this.DateFromUTCValue = e.getSource().mProperties.value;
	    this.dateFromUTC = i2d.qm.task.tracknconfirm.utils.Helper.convertToISODateTime(e.getSource().mProperties.dateValue);
	    this.invalidDateFrom = e.mParameters.invalidValue && !($.isBlank(e.mParameters.newValue));
	    this.setDateFilterCount()
	  },
	  onChangeDateTo: function(e) {
	    this.DateToUTCValue = e.getSource().mProperties.value;
	    this.dateToUTC = i2d.qm.task.tracknconfirm.utils.Helper.convertToISODateTime(e.getSource().mProperties.dateValue);
	    this.invalidDateTo = e.mParameters.invalidValue && !($.isBlank(e.mParameters.newValue));
	    this.setDateFilterCount()
	  },
	  onResetFilterDialog: function(e) {
	    this.DateFromUTCValue = null;
	    this.DateToUTCValue = null;
	    this.dateFromUTC = null;
	    this.dateToUTC = null;
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.resetFilterDialogDateFilter()
	  },
	  shouldCreateDateFilterObject: function() {
	    if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)) {
	      return false
	    }
	    if ($.isBlank(this.dateFromUTC)) {
	      this.dateFromUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate;
	      return true
	    }
	    if ($.isBlank(this.dateToUTC)) {
	      this.dateToUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate
	    }
	    return true
	  },
	  setDateFilterCount: function() {
	    if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)) {
	      i2d.qm.task.tracknconfirm.utils.FragmentHelper.setFilterDialogDateFilterCount(0);
	      return
	    }
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.setFilterDialogDateFilterCount(1)
	  },
	  onSort: function(e) {
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.openSortDialog(this)
	  },
	  onConfirmSortDialog: function(e) {
	    var p = e.getParameters();
	    if (!p.sortItem) {
	      return
	    }
	    this.oSorter = p.sortItem.getCustomData()[0].getValue().sorter;
	    if (!this.oSorter) {
	      return
	    }
	    this.oSorter.bDescending = p.sortDescending;
	    this.getList().getBinding("items").sort(this.oSorter)
	  },
	  onConfirmCustSettingsDialog: function(e) {
	    var a = e.getSource().getParent().getAggregation("content")[0];
	    if (a.getId() === "CustomSettingsIssuesNumber" && a.getContent()[1].getValueState() === sap.ui.core.ValueState.Error) {
	      return
	    }
	    if (this.changedMaxHits > 0 && this.objSettings.maxHits !== this.changedMaxHits) {
	      this.objSettings.maxHits = this.changedMaxHits;
	      this.handleRefresh();
	      localStorage.setObj(this.SETTINGS_NAME, this.objSettings)
	    }
	    this.closeCustSetDialog()
	  },
	  onCancelCustSettingsDialog: function(e) {
	    var a = e.getSource().getParent().getAggregation("content")[0];
	    if (a.getId() === "CustomSettingsIssuesNumber") {
	      var i = a.getContent()[1];
	      i.setValueState(sap.ui.core.ValueState.None);
	      i.setValueStateText("")
	    }
	    this.closeCustSetDialog()
	  },
	  onCustSetDialogHeaderBack: function(e) {
	    var i = e.getSource().getParent().getParent().getAggregation("content")[0].getContent()[1];
	    if (i.getValueState() === sap.ui.core.ValueState.Error) {
	      return
	    }
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.openCustSetDialog(this, i.getValue())
	  },
	  onCustomSettingsIssues: function(e) {
	    var m = e.getSource().getModel("maxHits").getData().maxHits;
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.loadCustSetIssuesNumber(this, m)
	  },
	  onSettingsPressed: function(e) {
	    i2d.qm.task.tracknconfirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits)
	  },
	  onChangeCustSetIssueNumber: function(e) {
	    if (isNaN(e.getSource().getValue()) || $.isBlank(e.getSource().getValue()) || e.getSource().getValue() < 1) {
	      e.getSource().setValueState(sap.ui.core.ValueState.Error);
	      e.getSource().setValueStateText(this.resourceBundle.getText("QT_INVALID_INPUT_ERROR"))
	    } else {
	      e.getSource().setValueState(sap.ui.core.ValueState.None);
	      e.getSource().setValueStateText("")
	    }
	    this.changedMaxHits = parseInt(e.getSource().getValue(), 10)
	  }
	
});