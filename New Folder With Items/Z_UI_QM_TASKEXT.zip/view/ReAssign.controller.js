jQuery.sap.require("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.StatusHelperExt");
jQuery.sap.require("sap.m.MessageBox");
var indexes = [];
var path;
sap.ui.controller("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.view.ReAssign", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.ReAssign
*/
	onInit: function() {
	    
	 this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
     this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 
      // Person Responsible
      
	this.itemSet = new sap.ui.core.Item({
      key: "{key}",
      text: "{title}" ,
      active: true
    });
  
    this.oPerResInput = this.getView().byId("QI_ANT_LIST_NAME_TEXT_INPUT");

    var aTask = [];

    var bPerRes = [{
      output: "key",
      source: "PersonResponsible"
                                }, {
      output: "title",
      source: "ListName"
                                }, {
      output: "codeGroup",
      source: "PersonResponsible"
                                }, {
      output: "category",
      source: "PersonResponsible"
                                }, {
      output: "catalogType",
      source: "PersonResponsible"
                                }];
    aTask.push({
      indexCollection: 0,
      arConversionRules: bPerRes,
      itemsPrefix: "items"
    });

    var d = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils.HelperExt.getCollectionPerRes(aTask, this);
    this.l = d && d.length > 0 && d[0];
    this.m = new sap.ui.model.json.JSONModel();
    this.m.setData(this.l);
    this.oPerResInput.setModel(this.m);

    this.getView().setModel(this.m, "perResModel");
    this.oPerResInput.bindAggregation("suggestionItems", "/items", this.itemSet);

    this.selectedPerRes = new sap.m.StandardListItem({
      key: "{key}",
      codeGroup: "{codeGroup}",
      category: "{category}",
      title: "{title}",
      catalogType: "{catalogType}",
      active: true
    });
	},


  _handleRouteMatched: function(oEvent)
  {
    var oParamaeters = oEvent.getParameter("name");
    if(oParamaeters!=="reAssign")
    {
    return;
    }

   path =  oEvent.getParameter("arguments").contextPath;

    	//Tasks Comments

		var dModelComments = new sap.ui.model.json.JSONModel();
		var oContextComments = this.getView().getBindingContext();
		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_TASK_SRV/", true, "", "");
		var pathComments = "QMTaskCommentsSet?$filter=NotificationID eq '" + path + "'";

		oDataModel.read(pathComments, oContextComments, [], false, function(data) {
			var comments = [];
			comments = data;
			dModelComments.setData(comments);

		}, function(err) {
			console.log("inside failure");
		});
		sap.ui.getCore().setModel(dModelComments, "CommentsModel");
		sap.ui.getCore().byId("ReAssign--idCommentsTable").setModel(dModelComments, "CommentsModel");
   
    
  },
perResGetRequest: function() {

    this.colon = " : ";
    this.openingBracket = " (";
    this.closingBracket = ")";

    this.itemSet = new sap.ui.core.Item({
      key: "{key}" + this.colon + "{catalogType}" +
        this.colon + "{codeGroup}",
      text: "{title}" + this.openingBracket +
        "{category}" + this.closingBracket,
      active: true
    });
  },

  onPerResSelect: function(e) {
    selectedIndex1 = parseInt(e.getSource().getId().split("idCommentsTable-")[1]);
    if (!this.PerResSelectDialogCustom) {
      this.PerResSelectDialogCustom = i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.utils
        .FragmentHelperExt.createF4HelpSelectDialog(this,
          "PerResSelectDialogCustom", this.oPerResInput.getModel()
      )
    }
   
    this.setInitialFilter(e.getSource()._lastValue, this.PerResSelectDialogCustom)

  },
  filterDialog: function(v, i) {
    var f = [];

    var s = new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v);
    f.push(s);
    i.filter(f);
  },

  setInitialFilter: function(f, s) {

    f = f.split(this.openingBracket)[0];
    s.open(f);
    var i = s.getBinding("items");
    if (!$.isBlank(f)) {
      this.filterDialog(f, i)
    } else if (f === "" && i.aFilters.length > 0) {
      this.filterDialog(f, i)
    }
  },
  onSuggestionItemSelected: function(e) {
      sap.ui.getCore().byId("ReAssign--DL_BTN_SAVETASK").setEnabled(true);
    var v = e.getParameter("selectedItem");
    if (v !== undefined) {
      var t = new sap.m.StandardListItem({
        key: "{key}",
        codeGroup: "{codeGroup}",
        category: "{category}",
        title: "{title}",
        catalogType: "{catalogType}"
      });

      var p = v.mProperties.key.split(this.colon);
      t.key = p[0];
          
    t.title = p[0];
      //t.category = p[1].split(this.closingBracket)[0];
      //
      var items = this.getView().byId("idCommentsTable").getItems();

      selectedIndex1 = parseInt(e.getSource().getId().split("idCommentsTable-")[1]);
      	items[selectedIndex1].getAggregation("cells")[2] = t.title;
			items[selectedIndex1].getAggregation("cells")[1].setText(t.key);
       
      if (e.getSource() === this.oPerResInput) {
        this.selectedPerRes = t;
      }
    }
  },

  onSuggest: function(e) {
     var v = e.getParameter("suggestValue");
    var selectedIndex1 = parseInt(e.getSource().getId().split("idCommentsTable-")[1]);
    indexes.push(selectedIndex1);
    if (v !== undefined) {
      this.byId(e.getSource().getId()).setModel(this.m);
      this.byId(e.getSource().getId()).bindAggregation("suggestionItems", "/items", this.itemSet);
      var oFilter = new sap.ui.model.Filter([
                          new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.Contains, v),
                          new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v)
                          ], false);
            e.getSource().getBinding("suggestionItems").filter([oFilter]);
            this.filterDialog(e.getSource().getBinding("suggestionItems").filter([oFilter]));
      //this.filterDialog(v, e.getSource().getBinding("suggestionItems"));
      if (e.getSource() === this.oPerResInput) {
        this.selectedPerRes = "";
      }
      e.getSource().setValueState(sap.ui.core.ValueState.None)
    }
  },
searchDefectLocation: function(e) {
    var v = e.getParameter("value");
    if (v !== undefined) {
    var oFilter = new sap.ui.model.Filter([
                          new sap.ui.model.Filter("category", sap.ui.model.FilterOperator.Contains, v),
                          new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v )
                          ], false);
      e.getSource().getBinding("items").filter([oFilter]);
      this.filterDialog(e.getSource().getBinding("items").filter([oFilter]));
      //this.filterDialog(v, e.getSource().getBinding("items"));
    }
  },
  cancelDefectSelectDialog: function(e) {},
  confirmDefectSelectDialog: function(e) {
    sap.ui.getCore().byId("ReAssign--DL_BTN_SAVETASK").setEnabled(true);
    var s = e.getParameter("selectedItem");
    var items = this.getView().byId("idCommentsTable").getItems();
    var i;
    var p = s.oBindingContexts.undefined.sPath.split("/");
    if ("PerResSelectDialogCustom" === e.getSource().sId) {
      i = items[selectedIndex1].getAggregation("cells")[2];
    
           
    indexes.push(selectedIndex1);
    }
    
    if (s) {

      var p = s.oBindingContexts.undefined.sPath.split("/");
      var a = p[p.length - 1];
      i.setValue(s.getTitle());

      i.setValueState(sap.ui.core.ValueState.None);
      var b = s.oBindingContexts.undefined.oModel.oData.items[a];
      items[selectedIndex1].getAggregation("cells")[1].setText(b.key);
	  items[selectedIndex1].getAggregation("cells")[2] = b;

    this.array = [];
    for (var j = 0; j < items.length; j++) {
    //  var inputValue = items[j].getAggregation("cells")[1].getText();
      var inputPersValue = items[j].getAggregation("cells")[2].getValue();
      if(inputPersValue.indexOf("(") !== -1)
      {
         var p =  inputPersValue.split("(");
          inputPersValue = p[0];
          inputPersValue = p[0].slice(0,-1);
      }
      this.arrayInner = new Array(2);
     // this.arrayInner[0] = inputValue;
      this.arrayInner[1] = inputPersValue;
      this.array.push(this.arrayInner);
    }
    }
},
navBack: function() {

	window.history.back()

	  },
	  
onReassign : function(){
		var o;
		var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
		// check for task validation.
    	var oTasks = [];

		var oTaskItem = {};

		var oParam = {};
		oParam.NotificationID = sap.ui.getCore().byId("TaskListDetail--objHeader").getTitle();
        var commentsModel = sap.ui.getCore().getModel("CommentsModel");

		var commModelData = commentsModel.oData.results;
	// item values for tasks
	  var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
        	var batchChanges = [];  
        	var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_TASK_SRV", true);

			if (commModelData.length > 0) {
                console.log(indexes);
				for (var g = 0; g < indexes.length; g++) {
                oTaskItem.ModificationMode=A.getParams().TaskModificationMode.Reassign;

	            oTaskItem.NotificationID= commModelData[indexes[g]].NotificationID;

	             oTaskItem.TaskNum = commModelData[indexes[g]].TaskNum;

	            oTaskItem.PartnerID= commModelData[indexes[g]].PartnerID;
	            oTaskItem.PartnerName = commModelData[indexes[g]].PartnerName;
				
					oTasks.push(oTaskItem);
                    batchChanges.push( oModel.createBatchOperation(A.getServiceList()[0].masterCollection + "(NotificationID='" +
                    commModelData[g].NotificationID + "',TaskNum='" + commModelData[g].TaskNum + "')", A.getParams().HTTP_Method.PUT, oTaskItem) ); 
				}
      
		oModel.addBatchChangeOperations(batchChanges);  
        	sap.ui.getCore().byId("ReAssign").setBusy(true);

			jQuery.sap.delayedCall(1500, this, function() {
        oModel.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false);
        
					});
			}	
},
onPressComments : function(e){
        var taskLongtxt;
      var path = parseInt(e.getSource().getId().split("idCommentsTable-")[1]);
        var commentsModel = sap.ui.getCore().getModel("CommentsModel");

		var taskLongText = commentsModel.oData.results[path].TaskLongtext;
	    if(taskLongText === ""){
	        taskLongtxt = "No Comments Provided";
	    }
	    else{
	        taskLongtxt = taskLongText;
	    }
    	var dialog = sap.ui.getCore().byId("idTasksComDialog");		
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("i2d.qm.task.tracknconfirm.Z_UI_QM_TASKExt.fragments.TaskComments", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		sap.ui.getCore().byId("idText").setText(taskLongtxt);
},
onClose : function(){
    	var dialog = sap.ui.getCore().byId("idTasksComDialog");		
    	dialog.close();
},
	fnBatchError: function(e) {
			this.result.error = e.message;
			indexes =[];
			sap.ui.getCore().byId("ReAssign").setBusy(false);
			jQuery.sap.log.error("Error occurs during batch processing: " + e.message);
			/*sap.ca.ui.message.showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: e.message,
				details: e.response.statusText
			})*/
		
				sap.m.MessageBox.alert("Error occurs during batch processing: " + e.message);
		},
		
		fnBatchSuccess: function(d, r, e) {
			if (e && e.length > 0) {
			    indexes = [];
				var j = e[0].response.body;
				var n = $.parseJSON(j);
				this.result = {};
				this.result.error = n.error.message.value;
				sap.ui.getCore().byId("ReAssign").setBusy(false);
				jQuery.sap.log.error("Error occurs during batch processing: " + n.error.message.value);
				sap.m.MessageBox.alert("Error occurs during batch processing: " + n.error.message.value);
				throw {
					message: n.error.message.value,
					details: n.error.message.value
				}
			
			}
			else
			{
			    var that = this;
			      indexes = [];
                            
			    	var dModelComments = new sap.ui.model.json.JSONModel();
                    var oContextComments = this.getView().getBindingContext();
                	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZQM_TASK_SRV/", true, "", "");
        		    var pathComments = "QMTaskCommentsSet?$filter=NotificationID eq '" + path + "'";
        
        		oDataModel.read(pathComments, oContextComments, [], false, function(data) {
        			var comments = [];
        			comments = data;
        			dModelComments.setData(comments);
        
        		}, function(err) {
        			console.log("inside failure");
        		});
        		sap.ui.getCore().setModel(dModelComments, "CommentsModel");
        			sap.ui.getCore().byId("ReAssign").setBusy(false);

				sap.m.MessageBox.alert("Tasks Updated successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction === "OK") {
                          
                    		sap.ui.getCore().byId("ReAssign--idCommentsTable").setModel(dModelComments, "CommentsModel");
						}

					}.bind(that)

				});
			}
		}
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.ReAssign
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.ReAssign
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.ReAssign
*/
//	onExit: function() {
//
//	}

});