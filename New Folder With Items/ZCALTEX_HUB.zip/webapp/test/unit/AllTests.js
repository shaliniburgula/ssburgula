sap.ui.define([
	"com/caltex/au/ZCALTEX_HUB/test/unit/controller/App.controller"
], function () {
	"use strict";
});