jQuery.sap.require("com.caltex.au.ZCALTEX_HUB.util.Formatter");
sap.ui.define([
"sap/ui/core/mvc/Controller",
"sap/ui/model/Filter"
], function(Controller,Filter) {
"use strict";

return Controller.extend("com.caltex.au.ZCALTEX_HUB.controller.INV", {
    onInit:function()
      {
      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this);


      },
      onBeforeRendering : function()
      {
      },
      _handleRouteMatched: function(oEvent)
      {
      var oParamaeters = oEvent.getParameter("name");
      if(oParamaeters!="Invoicepage")
      {
      return;
      }
      value =  oEvent.getParameter("arguments").contextPath;

      var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_HUB_FIORI_SRV/", true, "", "");
      var oContext = this.getView().getBindingContext();
      var dModel = new sap.ui.model.json.JSONModel();


      this.upload(oDataModel,dModel,oContext,value);

      this.HardCopy(oDataModel,dModel,oContext,value);

      this.inProcess(oDataModel,dModel,oContext,value);

      this.underDev(oDataModel,dModel,oContext,value);

      this.HoldPay(oDataModel,dModel,oContext,value);

      this.ClrPay(oDataModel,dModel,oContext,value);

      this.PayCrd(oDataModel,dModel,oContext,value);

      this.Rej(oDataModel,dModel,oContext,value);

      },
    onNavBack: function() {
    this._oRouter.navTo("hubpages");
    },

    upload : function(oDataModel,dModel,oContext,value)
    {
      var path ="InvcHub01Set?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status eq '01'";

      oDataModel.read(path, oContext, [], false, function (data) {
        dModel.setData(data);

      }, function (err) {
      console.log("inside failure");
      });
      sap.ui.getCore().setModel(dModel,"INVHubSetModel");
      sap.ui.getCore().byId("idINV").setModel(dModel,"INVHubSetModel");
      sap.ui.getCore().byId("idINV--idINVUpload").setModel(dModel);
    },
    HardCopy : function(oDataModel,dModel,oContext,value)
    {
        var dModelHC = new sap.ui.model.json.JSONModel();
            var pathHC ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status1 eq '02'";

        oDataModel.read(pathHC, oContext, [], false, function (data) {
        dModelHC.setData(data);

        }, function (err) {
        console.log("inside failure");
        });
        sap.ui.getCore().setModel(dModelHC,"INVHubHCSetModel");
        sap.ui.getCore().byId("idINV").setModel(dModelHC,"INVHubHCSetModel");
        sap.ui.getCore().byId("idINV--idINVHC").setModel(dModelHC);
    },
    inProcess : function(oDataModel,dModel,oContext,value)
    {
      var dModelInPr = new sap.ui.model.json.JSONModel();
           var pathInPr ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status1 eq '03'";

      oDataModel.read(pathInPr, oContext, [], false, function (data) {
      dModelInPr.setData(data);

      }, function (err) {
      console.log("inside failure");
      });
      sap.ui.getCore().setModel(dModelInPr,"INVHubInPrSetModel");
      sap.ui.getCore().byId("idINV").setModel(dModelInPr,"INVHubInPrSetModel");
      sap.ui.getCore().byId("idINV--idINVInProcess").setModel(dModelInPr);
    },
    underDev : function(oDataModel,dModel,oContext,value)
    {
      var dModelUD = new sap.ui.model.json.JSONModel();
           var pathUD ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status1 eq '04'";

        oDataModel.read(pathUD, oContext, [], false, function (data) {
        dModelUD.setData(data);

        }, function (err) {
        console.log("inside failure");
        });
        sap.ui.getCore().setModel(dModelUD,"INVHubUDSetModel");
        sap.ui.getCore().byId("idINV").setModel(dModelUD,"INVHubUDSetModel");
        sap.ui.getCore().byId("idINV--idINVUndDev").setModel(dModelUD);
    },

    HoldPay : function(oDataModel,dModel,oContext,value)
    {
      var dModelHoldPay = new sap.ui.model.json.JSONModel();
      var pathHoldPay ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status1 eq '05'";

      oDataModel.read(pathHoldPay, oContext, [], false, function (data) {
      dModelHoldPay.setData(data);

      }, function (err) {
      console.log("inside failure");
      });
      sap.ui.getCore().setModel(dModelHoldPay,"INVHubHPSetModel");
      sap.ui.getCore().byId("idINV").setModel(dModelHoldPay,"INVHubHPSetModel");
      sap.ui.getCore().byId("idINV--idINVHoldPay").setModel(dModelHoldPay);
    },

    ClrPay : function(oDataModel,dModel,oContext,value)
    {
      var dModelClrPay = new sap.ui.model.json.JSONModel();
      var pathClrPay ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status1 eq '06'";

      oDataModel.read(pathClrPay, oContext, [], false, function (data) {
      dModelClrPay.setData(data);

      }, function (err) {
      console.log("inside failure");
      });
      sap.ui.getCore().setModel(dModelClrPay,"INVHubCPSetModel");
      sap.ui.getCore().byId("idINV").setModel(dModelClrPay,"INVHubCPSetModel");
      sap.ui.getCore().byId("idINV--idINVClrPay").setModel(dModelClrPay);

    },
    PayCrd : function(oDataModel,dModel,oContext,value)
    {
      var dModelPayCrd = new sap.ui.model.json.JSONModel();
           var pathPayCrd ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '"+value+"' and Status1 eq '07'";

      oDataModel.read(pathPayCrd, oContext, [], false, function (data) {
      dModelPayCrd.setData(data);

      }, function (err) {
      console.log("inside failure");
      });
      sap.ui.getCore().setModel(dModelPayCrd,"INVHubPCSetModel");
      sap.ui.getCore().byId("idINV").setModel(dModelPayCrd,"INVHubPCSetModel");
      sap.ui.getCore().byId("idINV--idINVPayCrd").setModel(dModelPayCrd);
    },
    Rej : function(oDataModel,dModel,oContext,value)
    {
      var dModelRej = new sap.ui.model.json.JSONModel();
      var pathRej ="InvcHubSet?$filter=DataType eq 'INV' and DataRange eq 'M12' and Status1 eq '08'";

      oDataModel.read(pathRej, oContext, [], false, function (data) {
      dModelRej.setData(data);

      }, function (err) {
      console.log("inside failure");
      });
      sap.ui.getCore().setModel(dModelRej,"INVHubRejSetModel");
      sap.ui.getCore().byId("idINV").setModel(dModelRej,"INVHubRejSetModel");
      sap.ui.getCore().byId("idINV--idINVRej").setModel(dModelRej);

    }
});

});