jQuery.sap.require("com.caltex.au.ZCALTEX_HUB.util.Formatter");
var dModel = new sap.ui.model.json.JSONModel();	
var oContext ;
var oDataModel;
var dModelAck = new sap.ui.model.json.JSONModel();
var dModelConf = new sap.ui.model.json.JSONModel();
var inProcessArr = new Array();
var confirmArr = new Array();

sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter"
], function(Controller,Filter) {
  "use strict";

  return Controller.extend("drlhubpagesfiori.controller.PO", {
    onInit:function()
    {
      var dModel = new sap.ui.model.json.JSONModel();
      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      var  value="M03";
      oContext = this.getView().getBindingContext();
         oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_HUB_FIORI_SRV/", true, "", "");
          this.feedPOData(oDataModel,dModel,oContext,value);

        //this.feedPODataAck(oDataModel,dModelAck,oContext,value);
         
          this.feedPODataConf(oDataModel,dModel,oContext,value);


    },

  onSearch: function()
  {
    var filters = [];
    var searchString = sap.ui.getCore().byId("idPO--searchNewField").getValue();
    console.log(searchString);
    if (searchString && searchString.length > 0) {
      filters = [new sap.ui.model.Filter("PoObjectId", sap.ui.model.FilterOperator.Contains, searchString)];
      console.log("filters");
      console.log(filters);
    }
    // Update list binding
    sap.ui.getCore().byId("idPO--idPOtableNew").getBinding("items").filter(filters);


  },
    onBeforeRendering : function()
    {

    },
    onAfterRendering : function()
    {

    },


    feedPOData: function(oDataModel,dModel,oContext,value)
    {

       var path ="PoHubSet?$filter=DataType eq 'PO' and DataRange eq '"+value+"' and Status eq '01'";
          
        oDataModel.read(path, oContext, [], false, function (data) {

             dModel.setData(data);
                   
        }, function (err) {                              
          console.log("inside failure");                               
        });      

        sap.ui.getCore().setModel(dModel,"PoHubSetModel");
        sap.ui.getCore().byId("idPO").setModel(dModel,"PoHubSetModel");
        sap.ui.getCore().byId("idPO--idPOtableNew").setModel(dModel);

    },
  /*  feedPODataAck: function(oDataModel,dModelAck,oContext,value)
    {
       var pathAck ="PoHubSet?$filter=DataType eq 'PO' and DataRange eq '"+value+"' and Status eq '02'";
            
        oDataModel.read(pathAck, oContext, [], false, function (data) {

            
             for(var i =0 ; i <= data.results.length-1;i++)
               {
                  if(data.results[i].PoStatTxt != "Confirmed")
                    {
                      inProcessArr.push(data.results[i]);
                    }
               }
             
             dModelAck.setData(inProcessArr);

                   
        }, function (err) {                              
          console.log("inside failure");                               
        });      

        sap.ui.getCore().setModel(dModelAck,"PoHubACKSetModel");
        sap.ui.getCore().byId("idPO").setModel(dModelAck,"PoHubACKSetModel");
        sap.ui.getCore().byId("idPO--idPOtableAck").setModel(dModelAck);
    },*/
    feedPODataConf : function(oDataModel,dModelConf,oContext,value)
    {

      var dModelConf = new sap.ui.model.json.JSONModel();
      var pathAck ="PoHubSet?$filter=DataType eq 'PO' and DataRange eq '"+value+"' and Status eq '02'";
      oDataModel.read(pathAck, oContext, [], false, function (data) {

          
           for(var i =0 ; i <= data.results.length-1;i++)
             {
                if(data.results[i].PoStatTxt == "Confirmed")
                  {
                  confirmArr.push(data.results[i]);
                  }
             }
           
           dModelConf.setData(confirmArr);

             
      }, function (err) {                              
        console.log("inside failure");                               
      });      

      sap.ui.getCore().setModel(dModelConf,"PoHubconfSetModel");
      sap.ui.getCore().byId("idPO").setModel(dModelConf,"PoHubconfSetModel");
      sap.ui.getCore().byId("idPO--idPOtableconf").setModel(dModelConf);
    },
    onNavBack: function() {

        this._oRouter.navTo("hubpages");

    },

    onClickPODetails : function(oEvent){

      var context = oEvent.getSource().mProperties.text;
        sap.ui.getCore().byId("idPO").setBusy(true);
          jQuery.sap.delayedCall(5000, this, function() {
          this._oRouter.navTo("PODetailspage",{contextPath:context});
          sap.ui.getCore().byId("idPO").setBusy(false);
          });
    }

  });

});