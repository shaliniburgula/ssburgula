sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.caltex.au.ZCALTEX_HUB.controller.App", {
		onInit: function () {
			
		}
	});
});