jQuery.sap.declare("ui.s2p.srm.sc.track.ZSRM_SC_MON.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "ui.s2p.srm.sc.track",

	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/SRM_SC_MON"

	// we use a URL relative to our own component
	// extension application is deployed with customer namespace
});

this.ui.s2p.srm.sc.track.Component.extend("ui.s2p.srm.sc.track.ZSRM_SC_MON.Component", {
	metadata: {
		version: "1.0",

		config: {
		    	"sap.ca.i18Nconfigs": {

				"bundleName": "ui.s2p.srm.sc.track.ZSRM_SC_MON.i18n.i18n"

			}
		},

		customizing: {
		    "sap.ui.controllerExtensions": {
				"ui.s2p.srm.sc.track.view.S3": {
					controllerName: "ui.s2p.srm.sc.track.ZSRM_SC_MON.view.S3Custom"
				},
				"ui.s2p.srm.sc.track.view.S2": {
					controllerName: "ui.s2p.srm.sc.track.ZSRM_SC_MON.view.S2Custom"
				},
				
				"ui.s2p.srm.sc.track.view.ItemDetail": {
					controllerName: "ui.s2p.srm.sc.track.ZSRM_SC_MON.view.ItemDetailCustom"
				},
			},
			"sap.ui.viewReplacements": {
				"ui.s2p.srm.sc.track.view.S3": {
					viewName: "ui.s2p.srm.sc.track.ZSRM_SC_MON.view.S3Custom",
					type: "XML"
				},
				"ui.s2p.srm.sc.track.view.S2": {
					viewName: "ui.s2p.srm.sc.track.ZSRM_SC_MON.view.S2Custom",
					type: "XML"
				},
				
				"ui.s2p.srm.sc.track.view.ItemDetail": {
					viewName: "ui.s2p.srm.sc.track.ZSRM_SC_MON.view.ItemDetailCustom",
					type: "XML"
				}
			}
		}
	},
	init : function(){
	  
			$.isBlank = function(o) {
				return (!o || (typeof(o) == "string" && $.trim(o) === "") || ($.isPlainObject(o) && $.isEmptyObject(o)) || ($.isArray(o) && o.length ==
					0))
			}
		
	}
});