/*

 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved

 */

(function() {

	'use strict';

	jQuery.sap.declare("ui.s2p.srm.sc.track.ZSRM_SC_MON.util.HelperExt");
	ui.s2p.srm.sc.track.ZSRM_SC_MON.util.HelperExt = {

		ui5ToOdatadataForLocalFiltering: function(d) {
			var iDatadt = new Date(d);
			var month = (iDatadt.getMonth() + 1);
			var day = iDatadt.getDate()

			if ((iDatadt.getMonth() + 1).toString().length < 2) {
				month = '0' + (iDatadt.getMonth() + 1);
			}

			if ((iDatadt.getDate()).toString().length < 2) {
				day = '0' + iDatadt.getDate();
			}

			iDatadt = iDatadt.getFullYear() +
				'-' + month +
				'-' + day +
				'T' + "23" +
				':' + "59" +
				':' + "59";

			return iDatadt;

		},

		convertToISODateTime: function(d) {

			if ($.isBlank(d)) {

				return

			}

			var a = new Date(d),

				t = a.getTimezoneOffset();

			a.setHours(a.getHours() - ~~(t / 60));

			a.setMinutes(a.getMinutes() - (t / 60 - ~~(t / 60)) * 60);
			return a.toISOString();

		},

		isValidDate: function(d) {

			if (isNaN(Date.parse(d))) {

				return false

			}

			return true

		}

	}

}());