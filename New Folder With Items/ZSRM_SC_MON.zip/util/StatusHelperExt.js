/*

 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved

 */

(function() {

  'use strict';

  jQuery.sap.declare("ui.s2p.srm.sc.track.ZSRM_SC_MON.util.StatusHelperExt");

  ui.s2p.srm.sc.track.ZSRM_SC_MON.util.StatusHelperExt = {


    statusText: function(s) {

          switch (s) {

            case "I1009":

              return "Submitted";

            case "I1016":

              return "Book Cart Ordered";

            case "I1129":

              return "Approved";

            case "I1015":

              return "Awaiting Approval";

            default:

              return ""

          }


    },
    
    
		setFilterDialogDateFilterCount: function(C) {

			if (!this.filterDialog) {

				return

			}

			this.filterDialog.getFilterItems()[1].setFilterCount(C);

			if (C === 0) {

				this.filterDialog.getFilterItems()[1].setSelected(false);

				return

			}

			this.filterDialog.getFilterItems()[1].setSelected(true)

		},
        openFilterDialog: function(C) {
			if (!C) {
				return
			}
			if (!this.filterDialog) {
				this.filterDialog = sap.ui.xmlfragment("ui.s2p.srm.sc.track.ZSRM_SC_MON.fragments.ViewSettingsFilterDialog", C);
				this.dateVBox = this.filterDialog.getFilterItems()[1].getCustomControl();
			}
			this.filterDialog.open()
		},
		resetFilterDialogDateFilter: function(p, P) {

			if (!this.filterDialog) {

				return

			}

			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setDateValue();

			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setValue(p);

			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].fireChange(true);

			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setDateValue();

			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setValue(P);

			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].fireChange(true);

			if (!p && !P) {

				this.setFilterDialogDateFilterCount(0)

			} else {

				this.setFilterDialogDateFilterCount(1)

			}

		},

  }

}());