/**
 * App Controller (V1.0):
 * This controller is used to load the application acts like a photoframe
 *	
 * @author Shalini Sowmya Burgula
 * @date   03-04-2018
*/

sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("ZCT_STOCKIST.controller.App", {
		onInit: function()
		{
		//	this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		}
	});

});