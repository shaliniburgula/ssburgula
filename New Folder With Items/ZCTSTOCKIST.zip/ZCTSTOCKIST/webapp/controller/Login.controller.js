/**
 * Login controller (V1.0):
 * This controller is used to login to the application (stockist)
 *	
 * @author Shalini Sowmya Burgula
 * @date   03-04-2018
*/

var S = "";

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("ZCT_STOCKIST.controller.Login", {

		onLoginTap: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			S = "";
			var that = this;
            var result = this.checkValidations();
            if(result){
			window.sessionStorage;
			sessionStorage.clear();
			this.sUser = this.getView().byId("uid").getValue();
			this.sPassword = this.getView().byId("pasw").getValue();
			sessionStorage.setItem("sUser", this.sUser);
			sessionStorage.setItem("sPassword", this.sPassword);
			//sessionStorage.clear();

	//	var serviceURI = "http://sapnwg75q.mydrreddys.com:8005/sap/opu/odata/sap/ZCODE_SCAN1_SRV/";
		var serviceURI = "/sap/opu/odata/sap/ZCODE_SCAN1_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(serviceURI, true, sessionStorage.getItem("sUser"), sessionStorage.getItem(
				"sPassword"));

			var readPath = "BarCodeDetailsSet('')";
			oDataModel.read(readPath, null, null, false, function(responseBody, sucRes) {

				if (sucRes.data.Payer == "S") {
				       sessionStorage.setItem("sCustomer", sucRes.data.Payer);
					that._oRouter.navTo("Chart");
				}
			}, function(failRes) {

				sap.m.MessageBox.alert("Logon Failed");
			});
            }
		},
		checkValidations : function(){
		    	this.sUser = this.getView().byId("uid").getValue();
		    	this.sPassword = this.getView().byId("pasw").getValue();
		    var r = true;	
		    	if(this.sUser === ""){
		    	      this.getView().byId("uid").setValueState(sap.ui.core.ValueState.Error);
				    this.getView().byId("uid").setValueStateText("Enter User Id");
				    r = false;
		    	}
		    	if(this.sPassword === ""){
		    	     this.getView().byId("pasw").setValueState(sap.ui.core.ValueState.Error);
				    this.getView().byId("pasw").setValueStateText("Enter Password");
				    r = false;
		    	}
		    		if(!r){
			  
			    sap.m.MessageBox.alert("Please fill the details ");
    		
			}
		return r;
		}

	});
});