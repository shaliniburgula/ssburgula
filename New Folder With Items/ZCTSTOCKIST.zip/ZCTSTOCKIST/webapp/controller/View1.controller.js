var Latitude = undefined;
var Longitude = undefined;
var map = null;
var geocoder = new google.maps.Geocoder();
var formatedAddress = " ";
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("ZCT_STOCKIST.controller.View1", {
	      onInit : function(){
	        this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
	        this._oRouter.attachRoutePatternMatched(this.onRouteMatched, this);
	    },
		onscan: function() {
			var input = this.getView().byId("idBarCode");
			 navigator.geolocation.getCurrentPosition(this.onMapSuccess, this.onMapError, { enableHighAccuracy: true });

			cordova.plugins.barcodeScanner.scan(
				function(result) {
					input.setValue(result.text);
				},
				function(error) {
					sap.m.MessageBox.show("unable to scan due to improper barcode", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "ERROR",
						styleClass: "sapUiSizeCompact"
					});
				});
		},


		onMapSuccess: function(position) {

			Latitude = position.coords.latitude;
			Longitude = position.coords.longitude;

			// this.getMap(Latitude, Longitude);
			var mapOptions = {
				center: new google.maps.LatLng(Latitude, Longitude),
				zoom: 1,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};

			map = new google.maps.Map(document.getElementById("__component0---View1--map_canvas"), mapOptions);

			var latLong = new google.maps.LatLng(Latitude, Longitude);

			var marker = new google.maps.Marker({
				position: latLong
			});
			var that = this;
			marker.setMap(map);
			map.setZoom(15);
			map.setCenter(marker.getPosition());
			geocoder.geocode({
					latLng: latLong
				},
				function(responses) {
					if (responses && responses.length > 0) {
						formatedAddress = responses[0].formatted_address;
						//console.log(document.getElementById("__xmlview0--idAddress"));
						sap.m.MessageToast.show("You are at : " + formatedAddress);
					} else {
						sap.m.MessageToast.show('Not getting Any address for given latitude and longitude.');
					}
				});
		},

		// Get map by using coordinates 

		getMap: function(latitude, longitude) {

			var mapOptions = {
				center: new google.maps.LatLng(0, 0),
				zoom: 1,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};

			map = new google.maps.Map(document.getElementById("map"), mapOptions);

			var latLong = new google.maps.LatLng(latitude, longitude);

			var marker = new google.maps.Marker({
				position: latLong
			});

			marker.setMap(map);
			map.setZoom(15);
			map.setCenter(marker.getPosition());
		},

		// Success callback for watching your changing position 

		onMapWatchSuccess: function(position) {

			var updatedLatitude = position.coords.latitude;
			var updatedLongitude = position.coords.longitude;

			if (updatedLatitude != Latitude && updatedLongitude != Longitude) {

				Latitude = updatedLatitude;
				Longitude = updatedLongitude;

				this.getMap(updatedLatitude, updatedLongitude);
			}
		},

		// Error callback 

		onMapError: function(error) {
			console.log('code: ' + error.code + '\n' +
				'message: ' + error.message + '\n');
		},

		// Watch your changing position 

		watchMapPosition: function() {

			return navigator.geolocation.watchPosition(this.onMapWatchSuccess, this.onMapError, {
				enableHighAccuracy: true
			});
		},/*
		onPressOut : function(){
		    var deliveryNote = this.getView().byId("idBarCode").getValue();
		    var batch="xyz";
		    var fromLoc = formatedAddress;
		    	var oDataModel = new sap.ui.model.odata.ODataModel("http://sapnwg75d.mydrreddys.com:8001/sap/opu/odata/sap/ZCODE_SCAN1_SRV/", true); 
		    	var createPath = "BarCodeDetailsSet"
		    	
		    var		outObj = {
				DeliveryNote: deliveryNote,
				Batch: batch,
			    FromLocation :fromLoc
			};
		    	oDataModel.create(createPath, outObj, null, function(responseBody, sucRes) {
                    sap.m.MessageToast.show("Data saved successfully");
				}, function(failRes) {
					var errorBodyAdd = JSON.parse(failRes.response.body);
						sap.m.MessageBox.error("\\n Message: " + errorBodyAdd.error.message.value);

				});
		    
		},*/
		onPressIn : function(){
		   var barCode = this.getView().byId("idBarCode").getValue();
		    var inBarCodeArr = new Array();
		    inBarCodeArr = barCode.split(';');
		    var toLoc = formatedAddress;
		     if(toLoc !== "" && toLoc !== null && toLoc !== " "){
		    var oDataModel = new sap.ui.model.odata.ODataModel("http://sapnwg75q.mydrreddys.com:8005/sap/opu/odata/sap/ZCODE_SCAN1_SRV/", true,sessionStorage.getItem("sUser"),sessionStorage.getItem("sPassword")); 
		    //	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZCODE_SCAN1_SRV/", true, sessionStorage.getItem("sUser"),sessionStorage.getItem("sPassword")); 
		    	var updatePath = "BarCodeDetailsSet(DeliveryNote='"+inBarCodeArr[0]+"')";
		    	/*	var disYR = inBarCodeArr[1].substring(0, 4);
		    	var disMM = inBarCodeArr[1].substring(4,6);
		    	var disDD = inBarCodeArr[1].substring(6,8);*/
		    var		inObj = {
			/*	DeliveryNote: inBarCodeArr[0],
				DispatchDate: disYR+"-"+disMM+"-"+disDD+"-"+"T00:00:00",
			   // DeletionIndicator :inBarCodeArr[2],
			    Plant : inBarCodeArr[2] ,
			    Payer: inBarCodeArr[3],
			    TotalCases : inBarCodeArr[4],
			    VehicleNo : inBarCodeArr[5],
			    DestLocation : inBarCodeArr[6],*/
			    EndLocation : toLoc
			};
		    if(inBarCodeArr[3] ===  "0000"+sessionStorage.getItem("sUser").split('C')[1]){
		    	oDataModel.update(updatePath, inObj, null, function(responseBody, sucRes) {
                    sap.m.MessageBox.show("Data updated successfully");
				}, function(failRes) {
					var errorBodyUpdate = JSON.parse(failRes.response.body);
						sap.m.MessageBox.error("\\n Message: " + errorBodyUpdate.error.message.value);


				});
			}
			else
			{
			    sap.m.MessageBox.error("\\n Error Message: This dispatch doesnot belong to this customer" );
			}
		     }
		},
		onNavBack : function(){
		       this._oRouter.navTo("Chart");  
		},
	});
});