/**
 * Chart controller (V1.0):
 * This view loads the displays the chart and information about pending dispatches and not yet dispatched details.
 *	
 * @author Shalini Sowmya Burgula
 * @date   03-04-2018
*/

jQuery.sap.require("ZCT_STOCKIST.utils.Formatter");
var oDataModel;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	 "sap/ui/model/json/JSONModel",
	"ZCT_STOCKIST/utils/CustomFormatter"
], function(Controller, JSONModel, MessageBox, CustomFormatter) {
	"use strict";

	return Controller.extend("ZCT_STOCKIST.controller.Chart", {

     /**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf ZCT_STOCKIST.controller.Chart
	 */
		onInit: function(evt) {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.initCustomFormat();
		    this.onChartLoad();
		},
		
		/**
	 * Called when a controller is instantiated and loads the chart and details in a table to display
	 * @memberOf ZCT_STOCKIST.controller.Chart
	 */
	 
		onChartLoad: function(){
		    	var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
		  // oDataModel = new sap.ui.model.odata.ODataModel("http://sapnwg75q.mydrreddys.com:8005/sap/opu/odata/sap/ZCODE_SCAN1_SRV/", true, sessionStorage.getItem("sUser"),sessionStorage.getItem("sPassword"));
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZCODE_SCAN1_SRV/", true, sessionStorage.getItem("sUser"),sessionStorage.getItem("sPassword"));
			var dataModel = new sap.ui.model.json.JSONModel();
			var pathSet = "StckBarChart1Set?$filter=Months eq '12'";
	
			oDataModel.read(pathSet, null, null, false, function(r) {
				for (var j = 0; j < r.results.length; j++) {
					var ZexHrs = r.results[j].Target;
					r.results[j].Target = "";
					r.results[j].Target = parseFloat(ZexHrs);
					var ZConsHrs = r.results[j].ElapsedHrs;
					r.results[j].ElapsedHrs = "";
					r.results[j].ElapsedHrs = parseFloat(ZConsHrs);
					var ZRemHrs = parseFloat(ZexHrs) - parseFloat(ZConsHrs);
					r.results[j].RemHrs = "";
					r.results[j].RemHrs = parseFloat(ZRemHrs);
				}
				dataModel.setData(r);
			});
			//var	dataPath = "https://sapui5.hana.ondemand.com/sdk/test-resources/sap/viz/demokit/dataset/milk_production_testing_data/date_revenue_actual_forcast_target";
            var oRule1 = function (oContext) {
					var data = oVizFrame.getModel().getData().results;
					var bindingContext = oContext._context_row_number;
					var bindingData = data[bindingContext];
					var referenceMeasureValue = bindingData["Target"];
					if(referenceMeasureValue !== null && typeof referenceMeasureValue !== 'undefined') {
						if(bindingData["ElapsedHrs"] > referenceMeasureValue) {
						
								return true;
						} 
					} else
						return false;	
				};
			 var oRule2 = function (oContext) {
					var data = oVizFrame.getModel().getData().results;
					var bindingContext = oContext._context_row_number;
					var bindingData = data[bindingContext];
					var referenceMeasureValue = bindingData["Target"];
					if(referenceMeasureValue!=null && typeof referenceMeasureValue!='undefined') {
						if(bindingData["ElapsedHrs"] < referenceMeasureValue) {
						    var remHrs = bindingData["RemHrs"];
						    var totHrs = bindingData["Target"];
						    if(remHrs/totHrs > 0.5){
								return true;
						    }
						} 
					} else
						return false;	
				};
				 var oRule3 = function (oContext) {
					var data = oVizFrame.getModel().getData().results;
					var bindingContext = oContext._context_row_number;
					var bindingData = data[bindingContext];
					var referenceMeasureValue = bindingData["Target"];
					if(referenceMeasureValue!=null && typeof referenceMeasureValue!='undefined') {
						if(bindingData["ElapsedHrs"] < referenceMeasureValue) {
						    var remHrs = bindingData["RemHrs"];
						    var totHrs = bindingData["Target"];
						    if(remHrs/totHrs >= 0.25 && remHrs/totHrs < 0.5){
								return true;
						    }
						} 
					} else
						return false;	
				};
				 var oRule4 = function (oContext) {
					var data = oVizFrame.getModel().getData().results;
					var bindingContext = oContext._context_row_number;
					var bindingData = data[bindingContext];
					var referenceMeasureValue = bindingData["Target"];
					if(referenceMeasureValue!=null && typeof referenceMeasureValue!='undefined') {
						if(bindingData["ElapsedHrs"] < referenceMeasureValue) {
						    var remHrs = bindingData["RemHrs"];
						    var totHrs = bindingData["Target"];
						    if(remHrs/totHrs >= 0 && remHrs/totHrs < 0.25){
								return true;
						    }
						} 
					} else
						return false;	
				};
			var settingsModel = ({
				value: [["RemHrs", "ElapsedHrs", "Target"]],
				vizType: ["bullet"],
				dataset: [{
					dimensions: [{
						name: 'DispatchNo',
						value: "{DispatchNo}"
                    }],
					measures: [{
						name: 'ElapsedHrs',
						value: '{ElapsedHrs}'
                    }, {
						name: 'RemHrs',
						value: '{RemHrs}'
                   }, {
						name: 'Target',
						value: '{Target}'
                   }],
					data: {
						path: "/results"
					}
                }],
				rules: [{
					plotArea: {
					     
						dataPointStyle: {
							"rules": [
							    {
							        	"dataContext": {"ElapsedHrs": "*"},
							        
									"displayName": {
										"additionalColor": "Elapsed Hours"
									},
									"dataName": {
										"ElapsedHrs": "ElapsedHrs"
									}
							    },
								{
									callback: oRule1,
									"dataContext": {"Target": "*"},
									"properties": {
										"color": {
											"additionalColor": "sapUiChartPaletteSemanticBad"
										}/*,
										"pattern": {
											"additionalColor": "diagonalLightStripe"
										},*/
									},
									"displayName": {
										"additionalColor": "Delayed Hours"
									},
									"dataName": {
										"Target": "Target"
									}
                                },{
									callback: oRule2,
									"dataContext": {"Target": "*"},
									"properties": {
										"color": {
											"additionalColor": "sapUiChartPaletteSemanticGood"
										}/*,
										"pattern": {
											"additionalColor": "diagonalLightStripe"
										},*/
									},
									"displayName": {
										"additionalColor": ">50% Remaining Hours "
									},
									"dataName": {
										"Target": "Target"
									}
                                },{
									callback: oRule3,
									"dataContext": {"Target": "*"},
									"properties": {
										"color": {
											"additionalColor": "sapUiChartPaletteSequentialHue3Light1"
										}/*,
										"pattern": {
											"additionalColor": "diagonalLightStripe"
										},*/
									},
									"displayName": {
										"additionalColor": "between 25% to 50%  Remaining Hours"
									},
									"dataName": {
										"Target": "Target"
									}
                                },{
									callback: oRule4,
									"dataContext": {"Target": "*"},
									"properties": {
										"color": {
											"additionalColor": "sapUiChartPaletteSemanticCritical"
										}/*,
										"pattern": {
											"additionalColor": "diagonalLightStripe"
										},*/
									},
									"displayName": {
										"additionalColor": "between 0 to 25% Remaining Hours"
									},
									"dataName": {
										"Target": "Target"
									}
                                }
                                ]
						}
					}
                }],
				commonrules: {
					plotArea: {
						dataLabel: {
							formatString: CustomFormatter.FIORI_LABEL_SHORTFORMAT_2,
							visible: false
						},
						window: {
							start: "firstDataPoint",
							end: "lastDataPoint"
						}
					},
					legend: {
					    visible : true,
					  

					title: {
						visible: true,
						text:"Legend"
					}
				},
				/* legendGroup : {
                        layout : {
                            position : 'bottom'
                            
                        }
                     },*/
					valueAxis: {
						label: {
							formatString: CustomFormatter.FIORI_LABEL_SHORTFORMAT_10
						},
						title: {
							visible: false
						}
					},
					title: {
						visible: false
					},
					categoryAxis: {
						title: {
							visible: true,
							text:"Dispatches in Transit"
						}
					}
				}
			});
			var bindValue = settingsModel;
			var oSimpleForm = this.getView().byId("SimpleFormDisplay");
			var oPopOver = this.getView().byId("idPopOver");

	
			oVizFrame.setModel(dataModel);
			var oDataset = new sap.viz.ui5.data.FlattenedDataset(bindValue.dataset[0]);
			oVizFrame.setDataset(oDataset);
			oVizFrame.setVizType(bindValue.vizType[0]);
			oVizFrame.setVizProperties(bindValue.commonrules);
			oVizFrame.setVizProperties(bindValue.rules[0]);

			var feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': ["DispatchNo"]
				}),
			 feedActualValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "actualValues",
					'type': "Measure",
					'values': ["ElapsedHrs"]
				}),
				feedAdditionalValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "additionalValues",
					'type': "Measure",
					'values': ["RemHrs"]
				}),
				feedTargetValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "targetValues",
					'type': "Measure",
					'values': ["Target"]
				});
					oVizFrame.removeAllFeeds(); 
			oVizFrame.addFeed(feedCategoryAxis);
			oVizFrame.addFeed(feedTargetValues);
			oVizFrame.addFeed(feedActualValues);
			oVizFrame.addFeed(feedAdditionalValues);

			oPopOver.connect(oVizFrame.getVizUid());
			oPopOver.setFormatString(CustomFormatter.FIORI_LABEL_FORMAT_2);
            
            
              // dispatches more than 7 days
          	var dispatch7Json = new sap.ui.model.json.JSONModel();
			var data7Set = "StckMT7ChartSet?$filter=Months eq '12'";
			oDataModel.read(data7Set, null, null, false, function(r) {
				dispatch7Json.setData(r);
			//	plantJson.setSizeLimit(r.results);
			});
			sap.ui.getCore().setModel(dispatch7Json, "Master7Model");
		
			sap.ui.getCore().getModel("Master7Model").setSizeLimit(dispatch7Json.oData.results.length);
			this.getView().byId("__component0---Chart--table2").setModel(dispatch7Json, "Master7Model");
			
			
            // for not yet dispatched 
          	var dispatchJson = new sap.ui.model.json.JSONModel();
			var dataSet = "StckQRMasterSet";
			oDataModel.read(dataSet, null, null, false, function(r) {
				dispatchJson.setData(r);
			//	plantJson.setSizeLimit(r.results);
			});
			sap.ui.getCore().setModel(dispatchJson, "MasterModel");
			
			sap.ui.getCore().getModel("MasterModel").setSizeLimit(dispatchJson.oData.results.length);
			this.getView().byId("__component0---Chart--table1").setModel(dispatchJson, "MasterModel");
		},
    
    /**
	 * Called when a controller is instantiated and used for formatting the data 
	 * @memberOf ZCT_STOCKIST.controller.Chart
	 */
	 
		initCustomFormat: function() {
			CustomFormatter.registerCustomFormat();
		},
		
	/**
	 * Called when scan button is clicked , then that view is loaded
	 * @memberOf ZCT_STOCKIST.controller.Chart
	 */
	 
		onPressScan: function() {
			this._oRouter.navTo("View1");
		},
		
	 /**
	 * Called when page refresh button is pressed then chart data is loaded.
	 * @memberOf ZCT_STOCKIST.controller.Chart
	 */
		onPressRefresh : function(){
		    this.onChartLoad();
		}
	});
});