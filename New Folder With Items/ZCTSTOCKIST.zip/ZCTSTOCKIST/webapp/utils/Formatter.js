jQuery.sap.declare("ZCT_STOCKIST.utils.Formatter");

jQuery.sap.require("sap.ui.core.Element");

ZCT_STOCKIST.utils.Formatter = {

 
 	ui5ToOdatadataForLocalFiltering: function(data,timeVal) {
        if(data !== null){
			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = day+'-'+month+'-'+iDatadt.getFullYear();
	

	/*	var d = new Date(timeVal.ms);

		var s = d.getUTCSeconds();

		var h = d.getUTCHours();

		var m = d.getUTCMinutes();

		var value = h + ":" + m + ":" + s;

	    var dateTime = iDatadt +" "+ value;*/

			return iDatadt;
        }
}

};