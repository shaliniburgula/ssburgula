sap.ui.define([

	"sap/ui/core/mvc/Controller",

	'sap/m/MessageBox'

], function(Controller,MessageBox) {

	"use strict";



	return Controller.extend("zpms_admin.controller.YearSelection", {

		

		onprint_form:function(){

			this.showBusyIndicator(20000, 0);

			var view= this.getView();

			var that = this;

			sap.ui.getCore().username = view.byId("emp_no").getValue();

			sap.ui.getCore().Year_Sel = this.getView().byId("__YrSelect").getSelectedItem().getText();

			

			  //removing FY to year selection 

            

            sap.ui.getCore().Year_Sel = sap.ui.getCore().Year_Sel.split("FY ")[1];

            

			if(sap.ui.getCore().Year_Sel !== "" && sap.ui.getCore().username !== ""){

				sap.ui.getCore().username = this.pad_with_zeroes(sap.ui.getCore().username,8);

			this.entity1();

			}

			else{

				MessageBox.show("Fields should not be blank.");

				sap.ui.core.BusyIndicator.hide();

			}

			

		},

	 pad_with_zeroes:function(number, length) {

    var my_string = '' + number;

    while (my_string.length < length) {

        my_string = '0' + my_string;

    }



    return my_string;



},

		entity1: function(){

			var that = this;

			var odatamodel = this.getView().getModel();

			odatamodel.read("/ApprisalHeaderNewSet(EmpId='P" + sap.ui.getCore().username + "',FiscalYear='" + sap.ui.getCore().Year_Sel +

				"')?$format=json", null, null,

				true,

				function(oResponse) {

					sap.ui.getCore().USERDATA = oResponse;

					that.entity2();

				},

				function(oError) {

					var aa = JSON.parse(oError.response.body);

					sap.ui.core.BusyIndicator.hide();

					alert("Error "+aa.error.message.value);

					

				});

		},

		entity2:function(){

			var that = this;

			var odatamodel = this.getView().getModel();

			odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27P" + sap.ui.getCore().username +

				"%27%20and%20FiscalYear%20eq%20%27" + sap.ui.getCore().Year_Sel + "%27", null, null, false,

				function(oResponse) {

					sap.ui.getCore().GOALS = oResponse;

					that.form();

				},

				function(oError) {

					var aa = JSON.parse(oError.response.body);

					sap.ui.core.BusyIndicator.hide();

					alert("Error "+aa.error.message.value);

				});

		},

		form:function(){

			sap.ui.core.BusyIndicator.hide();

				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({

				pattern: "dd/MM/yyyy"

			});

			

				var j = 0;

				var k = 0;

				var odata = new Array();

				var odata_proj = new Array();

				var goal_data = sap.ui.getCore().GOALS.results;

				var idcnt = 0;



				for (var i = 0; i < goal_data.length; i++) {

					if (goal_data[i].GoalId === '0001') {

						odata[j] = goal_data[i];

						j++;

					}

				}

				for (i = 0; i < goal_data.length; i++) {

					if (goal_data[i].GoalId === '0002') {

						odata_proj[k] = goal_data[i];

						k++;

					}

				}



				var year = sap.ui.getCore().USERDATA.FiscalYear;

				var image = sap.ui.getCore().USERDATA.EmpImage;

			    	var EmpData = sap.ui.getCore().USERDATA;



				var Fname = EmpData.EmpName;

				var EmpCode = EmpData.EmpId;

				var Desig = EmpData.DesignText;

				var Unit = EmpData.UnitTex;

				var Depart = EmpData.DepartText;

				var band = EmpData.BandText;

				var L_1 = EmpData.ApprName;

				var L_2 = EmpData.OtherName;

				var Mmngr = EmpData.PartApprName;

				var L_1desgn = EmpData.ApprDesigText;

				var L_2desgn = EmpData.OtherDesigText;

				var Empstatus = EmpData.ApStatusName + "-" + EmpData.ApStatusSubName;

				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +

					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>"+EmpCode+" Performance Year "+year+"</title>" + "</head>" +

					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +

					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +

					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +

					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +

					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +

					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +

					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +

					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";


				table += "<tr>" + "<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +

					sap.ui.getCore().P_Fname + "</strong></p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +

					"</strong></p></td>" + "<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +

					EmpCode + "</p></td>" + "</tr>" + "<tr>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +

					"</strong></p></td>" + "<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +

					Desig + "</p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +

					sap.ui.getCore().P_deprt + "</strong></p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +

					"</tr>" + "<tr>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +

					"</strong></p></td>" + "<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +

					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +

					"</strong></p></td>" + "<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +

					L_2desgn + "</p></td>" + "</tr>" + "<tr>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>Document Status: </strong></p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Empstatus + "</p></td>" +

					"<td style='border: 1px solid #D4D4D4;' width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>"+

					"</strong></p></td>" + "<td style='border: 1px solid #D4D4D4;' width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +

					"</p></td>" + "</tr></table>" + "</div>" + "<div style='margin-bottom:10px;'>";



				//overall assetment comments

				table += "<h2 style='background-color: #872E6F; color:#FFFFFF; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Overall Assessment:</h2>";

				var Ovr_HF_Mng = sap.ui.getCore().USERDATA.HyrFbkTxt;

				table +=

					"<table style='border-spacing:0;'><tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Mid-Year Review:<p></strong></td></tr>" +

					"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

					(Ovr_HF_Mng) + "</p></td></tr>";



				var Ovr_Ann_EMP = sap.ui.getCore().USERDATA.OvrAchTxt;

				table +=

					"<tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Annual Review:<p></strong></td></tr>" +

					"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[Employee]: <p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

					(Ovr_Ann_EMP) + "</p></td></tr>";



				var Ovr_Ann_L1 = sap.ui.getCore().USERDATA.AnnLp1Txt;

				table +=

					"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[L+1]: <p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

					(Ovr_Ann_L1) + "</p></td></tr>";



				var Ovr_Ann_L2 = sap.ui.getCore().USERDATA.RvwRevTxt;

				table +=

					"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[L+2]: <p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

					(Ovr_Ann_L2) + "</p></td></tr>";



				var Ovr_Ann_ARC = sap.ui.getCore().USERDATA.ArcFbkTxt;

				table +=

					"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[ARC]: <p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

					(Ovr_Ann_ARC) + "</p></td></tr></table>";



				var temp = odata.length;

				if (temp !== 0) {



					table += "<h2 style='background-color: #872E6F; color:#FFFFFF; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +

						"</h2>"

					var data = odata;

					for (var i = 0; i < data.length; i++) {



						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #000000; border-spacing:0;'>" + "<tr>" +

							/*"<td style='border: 1px solid #D4D4D4;' colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +*/

							"<td style='border: 1px solid #D4D4D4;' colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							oDateFormat.format(data[i].GoalSdate) + "</p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							oDateFormat.format(data[i].GoalDate) + "</p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +

							"<td style='border: 1px solid #D4D4D4;' width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";

						var match = /\r|\n/.exec(data[i].KraText);

						if (match) {

							var arr100 = data[i].KraText.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = data[i].KraText;

						}



						table += finstr + "</p></td>" + "</tr>" + "<tr>" +

							"<td style='border: 1px solid #D4D4D4;' width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";

						var match = /\r|\n/.exec(data[i].KpiText);

						if (match) {

							var arr100 = data[i].KpiText.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = data[i].KpiText;

						}

						table += finstr + "</p></td>" + "</tr>";



						var HF_EMP = data[i].HyrEmpTxt;

						var match = /\r|\n/.exec(HF_EMP);

						if (match) {

							var arr100 = HF_EMP.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = HF_EMP;

						}

						table +=

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Mid-Year review:<p></strong></td></tr>" +

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr>";



						//mnagaer half year comment

						var HF_Mngr = data[i].HyrFbkTxt;

						var match = /\r|\n/.exec(HF_Mngr);

						if (match) {

							var arr100 = HF_Mngr.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = HF_Mngr;

						}

						table +=

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr>";



						//annual review 

						var ANN_EMP = data[i].SthFbkTxt;

						var match = /\r|\n/.exec(ANN_EMP);

						if (match) {

							var arr100 = ANN_EMP.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = ANN_EMP;

						}

						table +=

							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr>";

							

							//annual review mngr

						var ANN_EMP = data[i].AnnSlfVal;

						var match = /\r|\n/.exec(ANN_EMP);

						if (match) {

							var arr100 = ANN_EMP.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = ANN_EMP;

						}

						table +="<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr></table>";

					}

				}

				var func_goallen = odata_proj.length;

				if (func_goallen !== 0) {

					table += "<h2 style='background-color: #872E6F; color:#FFFFFF; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +

						"</h2>"

					var data = odata_proj;

					for (var i = 0; i < data.length; i++) {



						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #000000; border-spacing:0;'>" + "<tr>" +

							/*"<td style='border: 1px solid #D4D4D4;' colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +*/

							"<td style='border: 1px solid #D4D4D4;' colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							oDateFormat.format(data[i].GoalSdate) + "</p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							oDateFormat.format(data[i].GoalDate) + "</p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +

							"<td style='border: 1px solid #D4D4D4;' width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";

						var match = /\r|\n/.exec(data[i].KraText);

						if (match) {

							var arr100 = data[i].KraText.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = data[i].KraText;

						}



						table += finstr + "</p></td>" + "</tr>" + "<tr>" +

							"<td style='border: 1px solid #D4D4D4;' width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +

							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +

							"<td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";

						var match = /\r|\n/.exec(data[i].KpiText);

						if (match) {

							var arr100 = data[i].KpiText.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = data[i].KpiText;

						}

						table += finstr + "</p></td>" + "</tr>";



						var HF_EMP = data[i].HyrEmpTxt;

						var match = /\r|\n/.exec(HF_EMP);

						if (match) {

							var arr100 = HF_EMP.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = HF_EMP;

						}

						table +=

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Mid-Year review:<p></strong></td></tr>" +

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Employee: <p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr>";



						//mnagaer half year comment

						var HF_Mngr =  data[i].HyrFbkTxt;

						var match = /\r|\n/.exec(HF_Mngr);

						if (match) {

							var arr100 = HF_Mngr.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = HF_Mngr;

						}

						table +=

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr>";



						//annual review 

						var ANN_EMP = data[i].AnnSlfTxt

						var match = /\r|\n/.exec(ANN_EMP);

						if (match) {

							var arr100 = ANN_EMP.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = ANN_EMP;

						}

						table +=

							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +

							"<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr>";

							//annual review mngr

						var ANN_EMP = data[i].AnnLp1Txt;

						var match = /\r|\n/.exec(ANN_EMP);

						if (match) {

							var arr100 = ANN_EMP.split(match);

							var finstr = "";

							for (var j = 0; j < arr100.length; j++) {

								finstr = finstr + arr100[j] + "<br>"

							}

						} else {

							finstr = ANN_EMP;

						}

						table +="<tr><td style='border: 1px solid #D4D4D4;'><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td style='border: 1px solid #D4D4D4;' width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +

							(finstr) + "</p></td></tr></table>";

					}

				}

				table += "</div>" + "</div>" + "</body>" + "</html>";

				var ua = window.navigator.userAgent;

				var msie = ua.indexOf("MSIE ");



				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number

				{

					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");

					var printDocument = printPreview.document;

					printDocument.open();

					printDocument.write(table);

					printDocument.close();

				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {

					var wind = window.open("", "PrintWindow", "width=900px,height=900px");

					wind.document.write(table);

					wind.print();

					wind.close();

				}

			

			

		},



		



		/**

		 * Called when a controller is instantiated and its View controls (if available) are already created.

		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

		 * @memberOf zpms_admin.view.YearSelection

		 */

			onInit: function() {

				//PDF print global variable 

				sap.ui.getCore().P_title = "Performance Year"; //changed from performance management to Year

				sap.ui.getCore().P_empinfo = "Employee Information";

				sap.ui.getCore().P_Fname = "First Name:";

				sap.ui.getCore().P_empNO = "Employee Number:";

				sap.ui.getCore().P_desg = "Designation:";

				sap.ui.getCore().P_deprt = "Department:";

				sap.ui.getCore().P_L_1 = "L+1:";

				sap.ui.getCore().P_L_1_desg = "L+1 Designation:";

				sap.ui.getCore().P_L_2 = "L+2:";

				sap.ui.getCore().P_L_2_desg = "L+2 Designation:";

					sap.ui.getCore().mnu_func = "Functional Goals"; //changed from functional goal to goals

				sap.ui.getCore().mnu_proj = "Project Goals";//changed from  goal to goals

				sap.ui.getCore().fun_Complgoal_tital = "Add Compliance Goal";

				sap.ui.getCore().fun_owngoal_tital = "Add Functional Goal";

				sap.ui.getCore().fun_owngoal_KRA = "KRA/Goals";

				sap.ui.getCore().fun_owngoal_KPI = "KPI/Measurement";

				sap.ui.getCore().fun_owngoal_Weight = "Weight";

				sap.ui.getCore().fun_owngoal_startDt = "Start Date";

				sap.ui.getCore().fun_owngoal_complDt = "Completion Date";

				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

				

			},

			_handleRouteMatched:function(){

			

				var select = this.getView().byId("__YrSelect");

				var oModel = new sap.ui.model.json.JSONModel();

				var data = [];

				data.push({

					key: "0",

					value : ""

				});

				var yr = new Date().getFullYear();

				

				//logic for next year on after march 01

				var startYr = "2017";

				var startYr_Int = parseInt(startYr);

				for(var i=0;i<= yr-startYr_Int;i++){

				if(yr-i >  startYr_Int){

					var nxYr = startYr_Int+1+i;

					nxYr = nxYr.toString();

					if(nxYr.length === 4){

						nxYr = nxYr.substring(2);

					}

					data.push({

						key: startYr+i,

						value: "FY "+startYr+i +"-" + nxYr

					});

						

				}

				

				}

				var yr = new Date().getFullYear();

				if(new Date() >= new Date(yr+"/03/01 00:00:00")){

					var nxYr = yr+1;

					nxYr = nxYr.toString();

					if(nxYr.length === 4){

						nxYr = nxYr.substring(2);

					}

							data.push({

								key: yr,

								value: "FY "+yr +"-" + nxYr

							});

						}

				

				     

				oModel.setData({

					modelData: data

				});

        		select.setModel(oModel);

        		select.bindItems("/modelData",

                    new sap.ui.core.Item({

						key: "{key}",

						text: "{value}"

                    })

  );

				var aa=new Date().getFullYear();

			select.setSelectedKey(aa);

			},



		

			showBusyIndicator: function(iDuration, iDelay) {

			sap.ui.core.BusyIndicator.show(iDelay);



			if (iDuration && iDuration > 0) {

				if (this._sTimeoutId) {

					jQuery.sap.clearDelayedCall(this._sTimeoutId);

					this._sTimeoutId = null;

				}



				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {

					this.hideBusyIndicator();

				});

			}



		},

		hideBusyIndicator: function() {

			sap.ui.core.BusyIndicator.hide();

		},

			

			



		/**

		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

		 * (NOT before the first rendering! onInit() is used for that one!).

		 * @memberOf zpms_admin.view.YearSelection

		 */

		//	onBeforeRendering: function() {

		//

		//	},



		/**

		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

		 * This hook is the same one that SAPUI5 controls get after being rendered.

		 * @memberOf zpms_admin.view.YearSelection

		 */

			onAfterRendering: function() {

				var that = this;

				var aa= this.getView().byId("emp_no");

				aa.attachBrowserEvent('keypress', function(e){

     // check key code

     if(e.which == 13){

         that.onprint_form();

     }

});

			},



		/**

		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.

		 * @memberOf zpms_admin.view.YearSelection

		 */

		//	onExit: function() {

		//

		//	}



	});



});