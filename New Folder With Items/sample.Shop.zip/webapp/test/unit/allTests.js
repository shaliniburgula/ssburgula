sap.ui.define([
		"test/unit/model/formatter"
	], function() {
		"use strict";
	}
);