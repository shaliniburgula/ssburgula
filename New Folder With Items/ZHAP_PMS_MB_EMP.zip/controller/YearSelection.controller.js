sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller,History) {
	"use strict";

	return Controller.extend("com.drl.pmsmobile.controller.YearSelection", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.drl.pmsmobile.view.YearSelection
		 */
		onInit: function() {
			sap.ui.getCore().Year_Sel = "";
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);
			
			sap.ui.getCore().dialog = new sap.m.BusyDialog({
    		 text: 'Please wait...'
    		 });

		},
		_handleRouteMatched: function() {
			var select = this.getView().byId("__YrSelect");
			var oModel = new sap.ui.model.json.JSONModel();
			var data = [];
			data.push({
				key: "0",
				value: ""
			});
			var yr = new Date().getFullYear();

			//logic for next year on after march 01
			var startYr = "2017";
			var startYr_Int = parseInt(startYr);
			for (var i = 0; i <= yr - startYr_Int; i++) {
				if (yr - i > startYr_Int) {
					var nxYr = startYr_Int + 1 + i;
					nxYr = nxYr.toString();
					if (nxYr.length === 4) {
						nxYr = nxYr.substring(2);
					}
					data.push({
						key: startYr + i,
						value: startYr + i + "-" + nxYr
					});

				}

			}
			var yr = new Date().getFullYear();
			if (new Date() >= new Date(yr + "/03/01 00:00:00")) {
				var nxYr = yr + 1;
				nxYr = nxYr.toString();
				if (nxYr.length === 4) {
					nxYr = nxYr.substring(2);
				}
				data.push({
					key: yr,
					value: yr + "-" + nxYr
				});
			}

			oModel.setData({
				modelData: data
			});
			select.setModel(oModel);
			select.bindItems("/modelData",
				new sap.ui.core.Item({
					key: "{key}",
					text: "{value}"
				})
			);
			var aa = new Date().getFullYear();
			select.setSelectedKey(aa);
		},
		showBusyIndicator: function(iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);

			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}

				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {
					this.hideBusyIndicator();
				});
			}

		},
		hideBusyIndicator: function() {
			sap.ui.core.BusyIndicator.hide();
		},
		OnselectionYear: function() {
			/*sap.ui.core.BusyIndicator.show();*/
    		 sap.ui.getCore().dialog.open();
			/*	this.showBusyIndicator(20000, 0);*/
			/*	this.getView().setBusy(true);*/
			sap.ui.getCore().Year_Sel = this.getView().byId("__YrSelect").getSelectedItem().getText();
			if (sap.ui.getCore().Year_Sel !== "") {
				 
				sap.ui.core.UIComponent.getRouterFor(this).navTo("_Goalset", {});
				sap.ui.getCore().dialog.close();
			/*	sap.ui.core.BusyIndicator.hide();*/
			} else {
				sap.m.MessageToast.show("Please select valid appraisal year");
			}
		},
		onNavBack : function(){
		    var oHistory = History.getInstance();
		    var sPreviousHash = oHistory.getPreviousHash();
		    if(sPreviousHash !== undefined){
		        window.history.go(-1);
		    }
		    
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.drl.pmsmobile.view.YearSelection
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.drl.pmsmobile.view.YearSelection
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.drl.pmsmobile.view.YearSelection
		 */
		//	onExit: function() {
		//
		//	}

	});

});