sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/Dialog',
	'sap/m/Button',
	'sap/m/MessageToast',
	'sap/m/MessageBox',
	'sap/ui/core/routing/History'
], function(Controller, Dialog, Button, MessageToast, MessageBox) {

	return Controller.extend("com.drl.pmsmobile.controller.Goalset", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.drl.pmsmobile.view.Goalset
		 */
		onInit: function() {
			
		/*	this.showBusyIndicator(20000, 0);*/

			sap.ui.getCore().ordersThis = this;
			sap.ui.getCore().servicecallflag = 1;

			window.onbeforeunload = function(evt) {
				var message = 'Kindly logout before closing the browser';
				//sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ordersThis).navTo("_YearSelection",{});
				if (typeof evt == 'undefined') {
					evt = window.event;

				}
				if (evt) {
					evt.returnValue = message;

				}
				//sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ordersThis).navTo("_YearSelection",{});
				return message;
			};
			window.beforeunload = function(evt) {
				var message = 'Kindly Logout before Closing the Web Browser';
				if (typeof evt == 'undefined') {
					evt = window.event;
				}
				if (evt) {
					evt.returnValue = message;
				}
				// window.stop();
				// sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ordersThis).navTo("_YearSelection",{});
				return message;
			};
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

			var oDataProcessFlowLanesOnly = {
				lanes: [{
					id: "0",
					icon: "sap-icon://customize",
					label: "Goal Setting",
					position: 0,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
						value: 10
					}]
				}, {
					id: "1",
					icon: "sap-icon://hr-approval",
					label: "Goal Approval",
					position: 1
				}, {
					id: "2",
					icon: "sap-icon://survey",
					label: "Half Yearly",
					position: 2
				}, {
					id: "3",
					icon: "sap-icon://activity-assigned-to-goal",
					label: "Goal Revisit",
					position: 3
				}, {
					id: "4",
					icon: "sap-icon://hr-approval",
					label: "Goal Approval",
					position: 4
				}, {
					id: "5",
					icon: "sap-icon://approvals",
					label: "Annual Review",
					position: 5
				}, {
					id: "6",
					icon: "sap-icon://monitor-payments",
					label: "ARC",
					position: 6
				}, {
					id: "7",
					icon: "sap-icon://signature",
					label: "Final Sign Off",
					position: 7
				}]
			};

			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");

			viewPf2.byId("processflow2").updateModel();
			this.getView().addEventDelegate({
				onBeforeShow: function(evt) {
					//russian user bydefault language code
					//if(sap.ui.getCore().USERDATA.UnitText === "GG EM - Russia Rep office" || sap.ui.getCore().USERDATA.UnitText === "GG EM - Russia WOS"){
					//		sap.ui.getCore().ODThis.getView().getController().Russian_language();
					//}
				}
			});

		},
		showBusyIndicator: function(iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);

			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}

				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {
					this.hideBusyIndicator();
				});
			}

		},
		hideBusyIndicator: function() {
			sap.ui.core.BusyIndicator.hide();
		},

		/////////// print/PDF view of setted goal/////////////////////
	/*	onprint: function() {
			if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				var year = sap.ui.getCore().USERDATA.FiscalYear;
				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table id='GoalSetTable1' width='100%'>" + "<tr>" +
					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
				var EmpData = sap.ui.getCore().USERDATA;

				var Fname = EmpData.EmpName;
				var EmpCode = EmpData.EmpId;
				var Desig = EmpData.DesignText;
				var Unit = EmpData.UnitTex;
				var Depart = EmpData.DepartText;
				var band = EmpData.BandText;
				var L_1 = EmpData.ApprName;
				var L_2 = EmpData.OtherName;
				var Mmngr = EmpData.PartApprName;
				var L_1desgn = EmpData.ApprDesigText;
				var L_2desgn = EmpData.OtherDesigText;
				table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_Fname + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					EmpCode + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					Desig + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_deprt + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
					"</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";
				var temp = sap.ui.getCore().ODThis.getView().byId("Func_list").getModel().getData().modelData.length;
				if (temp !== 0) {

					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
						"</h2>"
					var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>"

						+ "</table>";
					}
				}
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list").getModel().getData().modelData.length;
				if (func_goallen !== 0) {
					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
						"</h2>"
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>" + "</table>";
					}
				}
				table += "</div>" + "</div>" + "</body>" + "</html>";
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");

				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
				{
					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
					var printDocument = printPreview.document;
					printDocument.open();
					printDocument.write(table);
					printDocument.close();
				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
					var wind = window.open("", "PrintWindow", "width=900px,height=900px");
					wind.document.write(table);
					wind.print();
					wind.close();
				}
			} 
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && (sap.ui.getCore().USERDATA.ApStatusSub == "" || sap.ui.getCore().USERDATA.ApStatusSub ==
					"3")) {

				//Getting Reviews for Function Golas
				var funcListRev = sap.ui.getCore().byId("Goalset--Func_list");
				var textAreaDataFun = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0].getEmbeddedControl().getItems()[0].getValue();
				})

				//Getting Reviews for Project Goals
				var projListRev = sap.ui.getCore().byId("Goalset--Proj_list");
				var textAreaDataProj = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0].getEmbeddedControl().getItems()[0].getValue();
				})

				var year = sap.ui.getCore().USERDATA.FiscalYear;
				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +
					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
				var EmpData = sap.ui.getCore().USERDATA;

				var Fname = EmpData.EmpName;
				var EmpCode = EmpData.EmpId;
				var Desig = EmpData.DesignText;
				var Unit = EmpData.UnitTex;
				var Depart = EmpData.DepartText;
				var band = EmpData.BandText;
				var L_1 = EmpData.ApprName;
				var L_2 = EmpData.OtherName;
				var Mmngr = EmpData.PartApprName;
				var L_1desgn = EmpData.ApprDesigText;
				var L_2desgn = EmpData.OtherDesigText;
				table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_Fname + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					EmpCode + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					Desig + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_deprt + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
					"</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";
				var temp = sap.ui.getCore().ODThis.getView().byId("Func_list").getModel().getData().modelData.length;
				if (temp !== 0) {

					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
						"</h2>"
					var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataFun[i] !== undefined ? textAreaDataFun[i] : "";
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>" + "</table>";
					}
				}
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list").getModel().getData().modelData.length;
				if (func_goallen !== 0) {
					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
						"</h2>"
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataProj[i] !== undefined ? textAreaDataProj[i] : "";
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>" + "</table>";
					}
				}
				table += "</div>" + "</div>" + "</body>" + "</html>";
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");

				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
				{
					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
					var printDocument = printPreview.document;
					printDocument.open();
					printDocument.write(table);
					printDocument.close();
				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
					var wind = window.open("", "PrintWindow", "width=900px,height=900px");
					wind.document.write(table);
					wind.print();
					wind.close();
				}
			} 
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && (sap.ui.getCore().USERDATA.ApStatusSub == "4" || sap.ui.getCore().USERDATA.ApStatusSub ==
					"5")) {

				//Getting Reviews for Function Golas EMP
				var funcListRev = sap.ui.getCore().byId("Goalset--Func_list");
				var textAreaDataFun = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var textAreaDataFun_MNGR = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				//Getting Reviews for Project Goals
				var projListRev = sap.ui.getCore().byId("Goalset--Proj_list");
				var textAreaDataProj = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var projListRev_MNGR = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				var year = sap.ui.getCore().USERDATA.FiscalYear;
				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +
					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
				var EmpData = sap.ui.getCore().USERDATA;

				var Fname = EmpData.EmpName;
				var EmpCode = EmpData.EmpId;
				var Desig = EmpData.DesignText;
				var Unit = EmpData.UnitTex;
				var Depart = EmpData.DepartText;
				var band = EmpData.BandText;
				var L_1 = EmpData.ApprName;
				var L_2 = EmpData.OtherName;
				var Mmngr = EmpData.PartApprName;
				var L_1desgn = EmpData.ApprDesigText;
				var L_2desgn = EmpData.OtherDesigText;
				table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_Fname + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					EmpCode + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					Desig + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_deprt + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
					"</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";

				//overall assetment comments
				table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Overall Assessment:</h2>";
				var Ovr_HF_Mng = sap.ui.getCore().byId("Goalset--_overallAsserTL").getText();
				table +=
					"<table><tr><td><strong><p style='font-size:15px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Half Yearly Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_HF_Mng) + "</p></td></tr>" + "</table>";

				var temp = sap.ui.getCore().ODThis.getView().byId("Func_list").getModel().getData().modelData.length;
				if (temp !== 0) {

					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
						"</h2>"
					var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataFun[i] !== undefined ? textAreaDataFun[i] : "";
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = textAreaDataFun_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>" + "</table>";
					}
				}
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list").getModel().getData().modelData.length;
				if (func_goallen !== 0) {
					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
						"</h2>"
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataProj[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Employee: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = projListRev_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>" + "</table>";
					}
				}
				table += "</div>" + "</div>" + "</body>" + "</html>";
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");

				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
				{
					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
					var printDocument = printPreview.document;
					printDocument.open();
					printDocument.write(table);
					printDocument.close();
				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
					var wind = window.open("", "PrintWindow", "width=900px,height=900px");
					wind.document.write(table);
					wind.print();
					wind.close();
				}
			} 
			else if ((sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "6") ||
					(sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "2")) {

				//Getting Reviews for Function Golas EMP
				var funcListRev = sap.ui.getCore().byId("Goalset--Func_list");
				var textAreaDataFun = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var textAreaDataFun_MNGR = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				//Getting Reviews for Project Goals
				var projListRev = sap.ui.getCore().byId("Goalset--Proj_list");
				var textAreaDataProj = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var projListRev_MNGR = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				//getting annual self
				var Annu_EMP = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[0]._textBox;
				})
				var Annu_Mngr = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[1]._textBox;
				})
				var Annu_proj_EMP = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[0]._textBox;
				})
				var Annu_proj_Mngr = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[1]._textBox;
				})

				var year = sap.ui.getCore().USERDATA.FiscalYear;
				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +
					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
				var EmpData = sap.ui.getCore().USERDATA;

				var Fname = EmpData.EmpName;
				var EmpCode = EmpData.EmpId;
				var Desig = EmpData.DesignText;
				var Unit = EmpData.UnitTex;
				var Depart = EmpData.DepartText;
				var band = EmpData.BandText;
				var L_1 = EmpData.ApprName;
				var L_2 = EmpData.OtherName;
				var Mmngr = EmpData.PartApprName;
				var L_1desgn = EmpData.ApprDesigText;
				var L_2desgn = EmpData.OtherDesigText;
				table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_Fname + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					EmpCode + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					Desig + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_deprt + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
					"</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";

				//overall assetment comments
				table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Overall Assessment:</h2>";
				var Ovr_HF_Mng = sap.ui.getCore().byId("Goalset--_overallAsserTL").getText();
				table +=
					"<table><tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Half Yearly Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_HF_Mng) + "</p></td></tr>";

				var Ovr_Ann_EMP = sap.ui.getCore().byId("Goalset--Annual_overallAsset_EMP").getText();
				table +=
					"<table><tr><td><strong><p style='font-size:15px; white-space: nowrap; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Annual Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_EMP) + "</p></td></tr></table>";

				var temp = sap.ui.getCore().ODThis.getView().byId("Func_list").getModel().getData().modelData.length;
				if (temp !== 0) {

					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
						"</h2>"
					var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataFun[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = textAreaDataFun_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review 
						var ANN_EMP = Annu_EMP[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review mngr
						var ANN_EMP = Annu_Mngr[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
					}
				}
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list").getModel().getData().modelData.length;
				if (func_goallen !== 0) {
					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
						"</h2>"
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataProj[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Employee: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = projListRev_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review 
						var ANN_EMP = Annu_proj_EMP[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";
							
							//annual review mngr
						var ANN_EMP = Annu_proj_Mngr[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +="<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
					}
				}
				table += "</div>" + "</div>" + "</body>" + "</html>";
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");

				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
				{
					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
					var printDocument = printPreview.document;
					printDocument.open();
					printDocument.write(table);
					printDocument.close();
				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
					var wind = window.open("", "PrintWindow", "width=900px,height=900px");
					wind.document.write(table);
					wind.print();
					wind.close();
				}
			} 
			else if ((sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "3") ||
					(sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "4")) {

				//Getting Reviews for Function Golas EMP
				var funcListRev = sap.ui.getCore().byId("Goalset--Func_list");
				var textAreaDataFun = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var textAreaDataFun_MNGR = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				//Getting Reviews for Project Goals
				var projListRev = sap.ui.getCore().byId("Goalset--Proj_list");
				var textAreaDataProj = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var projListRev_MNGR = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

			//getting annual self
				var Annu_EMP = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[0]._textBox;
				})
				var Annu_Mngr = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[1]._textBox;
				})
				var Annu_proj_EMP = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[0]._textBox;
				})
				var Annu_proj_Mngr = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[1]._textBox;
				})

				var year = sap.ui.getCore().USERDATA.FiscalYear;
				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +
					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
				var EmpData = sap.ui.getCore().USERDATA;

				var Fname = EmpData.EmpName;
				var EmpCode = EmpData.EmpId;
				var Desig = EmpData.DesignText;
				var Unit = EmpData.UnitTex;
				var Depart = EmpData.DepartText;
				var band = EmpData.BandText;
				var L_1 = EmpData.ApprName;
				var L_2 = EmpData.OtherName;
				var Mmngr = EmpData.PartApprName;
				var L_1desgn = EmpData.ApprDesigText;
				var L_2desgn = EmpData.OtherDesigText;
				table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_Fname + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					EmpCode + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					Desig + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_deprt + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
					"</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";

				//overall assetment comments
				table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Overall Assessment:</h2>";
				var Ovr_HF_Mng = sap.ui.getCore().byId("Goalset--_overallAsserTL").getText();
				table +=
					"<table><tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Half Yearly Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_HF_Mng) + "</p></td></tr>";

				var Ovr_Ann_EMP = sap.ui.getCore().byId("Goalset--Annual_overallAsset_EMP").getText();
				table +=
					"<tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Annual Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[Employee]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_EMP) + "</p></td></tr>";

				var Ovr_Ann_L1 = sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_mngr").getValue();
				table +=
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[L+1]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_L1) + "</p></td></tr>";

				var Ovr_Ann_L2 = sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_L2").getValue();
				table +=
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[L+2]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_L2) + "</p></td></tr></table>";

				var temp = sap.ui.getCore().ODThis.getView().byId("Func_list").getModel().getData().modelData.length;
				if (temp !== 0) {

					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
						"</h2>"
					var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataFun[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = textAreaDataFun_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review 
						var ANN_EMP = Annu_EMP[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";
							//annual review mngr
						var ANN_EMP = Annu_Mngr[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
					}
				}
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list").getModel().getData().modelData.length;
				if (func_goallen !== 0) {
					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
						"</h2>"
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataProj[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Employee: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = projListRev_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review 
						var ANN_EMP = Annu_proj_EMP[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";
							//annual review mngr
						var ANN_EMP = Annu_proj_Mngr[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
					}
				}
				table += "</div>" + "</div>" + "</body>" + "</html>";
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");

				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
				{
					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
					var printDocument = printPreview.document;
					printDocument.open();
					printDocument.write(table);
					printDocument.close();
				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
					var wind = window.open("", "PrintWindow", "width=900px,height=900px");
					wind.document.write(table);
					wind.print();
					wind.close();
				}
			}
			else if ((sap.ui.getCore().USERDATA.ApStatus == "5" || sap.ui.getCore().USERDATA.ApStatus == "9" || sap.ui.getCore().USERDATA.ApStatus ==
					"7") && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				//Getting Reviews for Function Golas EMP
				var funcListRev = sap.ui.getCore().byId("Goalset--Func_list");
				var textAreaDataFun = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var textAreaDataFun_MNGR = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				//Getting Reviews for Project Goals
				var projListRev = sap.ui.getCore().byId("Goalset--Proj_list");
				var textAreaDataProj = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[0]._textBox;
				})
				var projListRev_MNGR = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[4].getContent()[0].getContent()[1]._textBox;
				})

				//getting annual self
				var Annu_EMP = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[0]._textBox;
				})
				var Annu_Mngr = funcListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[1]._textBox;
				})
				var Annu_proj_EMP = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[0]._textBox;
				})
				var Annu_proj_Mngr = projListRev.getItems().map(function(e) {
					return e.getContent()[0].getItems()[0].getItems()[5].getContent()[0].getContent()[1]._textBox;
				})

				var year = sap.ui.getCore().USERDATA.FiscalYear;
				var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
					"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
					"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
					"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +
					"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
					"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
					"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
					"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
					"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
					sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
				var EmpData = sap.ui.getCore().USERDATA;

				var Fname = EmpData.EmpName;
				var EmpCode = EmpData.EmpId;
				var Desig = EmpData.DesignText;
				var Unit = EmpData.UnitTex;
				var Depart = EmpData.DepartText;
				var band = EmpData.BandText;
				var L_1 = EmpData.ApprName;
				var L_2 = EmpData.OtherName;
				var Mmngr = EmpData.PartApprName;
				var L_1desgn = EmpData.ApprDesigText;
				var L_2desgn = EmpData.OtherDesigText;
				table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_Fname + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					EmpCode + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					Desig + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
					sap.ui.getCore().P_deprt + "</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
					"</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
					"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
					"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
					"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
					L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";

				//overall assetment comments
				table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Overall Assessment:</h2>";
				var Ovr_HF_Mng = sap.ui.getCore().byId("Goalset--_overallAsserTL").getText();
				table +=
					"<table><tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Half Yearly Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_HF_Mng) + "</p></td></tr>";

				var Ovr_Ann_EMP = sap.ui.getCore().byId("Goalset--Annual_overallAsset_EMP").getText();
				table +=
					"<tr><td><strong><p style='font-size:15px; white-space: nowrap; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Annual Review:<p></strong></td></tr>" +
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[Employee]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_EMP) + "</p></td></tr>";

				var Ovr_Ann_L1 = sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_mngr").getValue();
				table +=
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[L+1]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_L1) + "</p></td></tr>";

				var Ovr_Ann_L2 = sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_L2").getValue();
				table +=
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[L+2]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_L2) + "</p></td></tr>";

				var Ovr_Ann_ARC = sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_ARC").getValue();
				table +=
					"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>[ARC]: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
					(Ovr_Ann_ARC) + "</p></td></tr></table>";

				var temp = sap.ui.getCore().ODThis.getView().byId("Func_list").getModel().getData().modelData.length;
				if (temp !== 0) {

					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
						"</h2>"
					var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataFun[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = textAreaDataFun_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review 
						var ANN_EMP = Annu_EMP[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";
							
							//annual review mngr
						var ANN_EMP = Annu_Mngr[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +="<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
					}
				}
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list").getModel().getData().modelData.length;
				if (func_goallen !== 0) {
					table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
						"</h2>"
					var data = func_goal.getModel().getData().modelData;
					for (var i = 0; i < data.length; i++) {

						table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
							"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
							"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
							"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalSdate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].GoalDate + "</p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
							"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KraText);
						if (match) {
							var arr100 = data[i].KraText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KraText;
						}

						table += finstr + "</p></td>" + "</tr>" + "<tr>" +
							"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
							sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
							"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; word-wrap: break-word; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
						var match = /\r|\n/.exec(data[i].KpiText);
						if (match) {
							var arr100 = data[i].KpiText.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = data[i].KpiText;
						}
						table += finstr + "</p></td>" + "</tr>";

						var HF_EMP = textAreaDataProj[i];
						var match = /\r|\n/.exec(HF_EMP);
						if (match) {
							var arr100 = HF_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Half Year review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Employee: <p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//mnagaer half year comment
						var HF_Mngr = projListRev_MNGR[i];
						var match = /\r|\n/.exec(HF_Mngr);
						if (match) {
							var arr100 = HF_Mngr.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = HF_Mngr;
						}
						table +=
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Manager :<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr>";

						//annual review 
						var ANN_EMP = Annu_proj_EMP[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +=
							"<tr><td><strong><p style='font-size:14px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'> Annual Review:<p></strong></td></tr>" +
							"<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Employee:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
							//annual review mngr
						var ANN_EMP = Annu_proj_Mngr[i];
						var match = /\r|\n/.exec(ANN_EMP);
						if (match) {
							var arr100 = ANN_EMP.split(match);
							var finstr = "";
							for (var j = 0; j < arr100.length; j++) {
								finstr = finstr + arr100[j] + "<br>"
							}
						} else {
							finstr = ANN_EMP;
						}
						table +="<tr><td><strong><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>Manager:<p></strong></td><td width='90%' colspan='14'><p style='font-size:12px; word-wrap: break-word; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
							(finstr) + "</p></td></tr></table>";
					}
				}
				table += "</div>" + "</div>" + "</body>" + "</html>";
				var ua = window.navigator.userAgent;
				var msie = ua.indexOf("MSIE ");

				if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
				{
					var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
					var printDocument = printPreview.document;
					printDocument.open();
					printDocument.write(table);
					printDocument.close();
				} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
					var wind = window.open("", "PrintWindow", "width=900px,height=900px");
					wind.document.write(table);
					wind.print();
					wind.close();
				}
			}
		},*/

		///////////// Open menu button for Add goal /////////////
		handlePressOpenMenu: function(oEvent) {
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sap.ui.getCore().Perf_path_text);
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sap.ui.getCore().Goal_header);
			var oButton = oEvent.getSource();

			// create menu only once
			if (!this._menu) {
				this._menu = sap.ui.xmlfragment(
					"com.drl.pmsmobile.view.Menu",
					this
				);
				this.getView().addDependent(this._menu);
				if (sap.ui.getCore().USERDATA.BandText === "R4" || sap.ui.getCore().USERDATA.BandText === "R5" || sap.ui.getCore().USERDATA.BandText ===
					"R6" || sap.ui.getCore().USERDATA.BandText === "R7A" || sap.ui.getCore().USERDATA.BandText === "R7B" || sap.ui.getCore().USERDATA
					.BandText === "R8" || sap.ui.getCore().USERDATA.BandText === "CEO" || sap.ui.getCore().USERDATA.BandText === "COO" || sap.ui.getCore()
					.USERDATA.BandText === "Chairman") {
					sap.ui.getCore().byId("mnuscore").setVisible(true);
				} else {
					sap.ui.getCore().byId("mnuscore").setVisible(false);
				}

				if (sap.ui.getCore().USERDATA.UnitText === "North America" || sap.ui.getCore().USERDATA.UnitText === "Generics - US" || sap.ui.getCore()
					.USERDATA.UnitText ===
					"API - US" || sap.ui.getCore().USERDATA.UnitText === "Promius Pharma LLC - US" || sap.ui.getCore().USERDATA.UnitText === "R7B" ||
					sap.ui.getCore().USERDATA
					.UnitText === "Proprietary products - US" || sap.ui.getCore().USERDATA.UnitText === "Louisiana LLC - US" || sap.ui.getCore().USERDATA
					.UnitText === "Biologics - US" || sap.ui.getCore()
					.USERDATA.UnitText === "CPS - US" || sap.ui.getCore()
					.USERDATA.UnitText === "Tennessee LLC - US" || sap.ui.getCore()
					.USERDATA.UnitText === "DRL New York Inc. - US" || sap.ui.getCore()
					.USERDATA.UnitText === "Aurigene US" || sap.ui.getCore()
					.USERDATA.UnitText === "Dr. Reddy’s Labs Canada, Inc.") {
					sap.ui.getCore().byId("mnuComl").setVisible(true);
				} else {
					sap.ui.getCore().byId("mnuComl").setVisible(false);
				}
				sap.ui.getCore().byId("mnuFun").setText(sap.ui.getCore().mnu_func);
				sap.ui.getCore().byId("mnuProj").setText(sap.ui.getCore().mnu_proj);
				sap.ui.getCore().byId("mnuscore").setText(sap.ui.getCore().mnu_score);
				sap.ui.getCore().byId("mnuFunOwn").setText(sap.ui.getCore().mnu_own);
				sap.ui.getCore().byId("mnuProjOwn").setText(sap.ui.getCore().mnu_own);

				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sap.ui.getCore().Perf_path_text);
				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sap.ui.getCore().Goal_header);
				// 		    //change laugage if user is russsian
				// 		    if(sap.ui.getCore().USERDATA.UnitText === "RU01" || sap.ui.getCore().USERDATA.UnitText === "RU02"){
				// 		    jQuery.sap.require("jquery.sap.resources");

				// 					var sLocale = "ru";
				// 					var oBundle = jQuery.sap.resources({
				// 						url: "i18n/i18n.properties",
				// 						locale: sLocale
				// 					});

				// 		var sMsg1 = oBundle.getText("FunctionalGoals");
				// 		sap.ui.getCore().byId("mnuFun").setText(sMsg1);

				// 		var sMsg2 = oBundle.getText("ProjectGoals");
				// 		sap.ui.getCore().byId("mnuProj").setText(sMsg2);

				// 		var sMsg3 = oBundle.getText("Scorecard");
				// 		sap.ui.getCore().byId("mnuscore").setText(sMsg3);

				// 		var sMsg4 = oBundle.getText("owngoal");
				// 		sap.ui.getCore().byId("mnuFunOwn").setText(sMsg4);

				// 		var sMsg5 = oBundle.getText("owngoal");
				// 		sap.ui.getCore().byId("mnuProjOwn").setText(sMsg5);

				// }
			}
			sap.ui.getCore().byId("mnuFun").setText(sap.ui.getCore().mnu_func);
			sap.ui.getCore().byId("mnuProj").setText(sap.ui.getCore().mnu_proj);
			sap.ui.getCore().byId("mnuscore").setText(sap.ui.getCore().mnu_score);
			sap.ui.getCore().byId("mnuFunOwn").setText(sap.ui.getCore().mnu_own);
			sap.ui.getCore().byId("mnuProjOwn").setText(sap.ui.getCore().mnu_own);
			var eDock = sap.ui.core.Popup.Dock;
			this._menu.open(this._bKeyboard, oButton, eDock.BeginTop, eDock.BeginBottom, oButton);
		},

		///////////////// Opening popup for function compliance goal /////////////////////
		handle_fun_compl: function(oEvent) {
			var oView = sap.ui.getCore().ODThis.getView();

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Complgoal", this);
				
			/*	var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("fungoal_progInd");
				var value = progressBR.getPercentValue();
				fungoal_progInd.setDisplayValue("Overall Weightage " + value + " %");
				fungoal_progInd.setPercentValue(value);
				if (0 <= value && value <= 40) {
					fungoal_progInd.setState("Error");
				} else if (41 <= value && value <= 80) {
					fungoal_progInd.setState("Warning");
				} else if (81 <= value && value <= 100) {
					fungoal_progInd.setState("Success");
				}*/

				var start_date = oView.byId("DP2_start");
				var year = new Date().getFullYear();
				var statDt = new Date(year + "/04/01");
				start_date.setValue(oDateFormat.format(statDt));
				//31-03-2018
				var end_date = oView.byId("DP2");
				var year = new Date().getFullYear() + 1;
				var endDt = new Date(year + "/03/31");
				end_date.setValue(oDateFormat.format(endDt));

				this.getView().byId("ComplGoal").setTitle(sap.ui.getCore().fun_Complgoal_tital);
				this.getView().byId("Lbl_KRA").setText(sap.ui.getCore().fun_owngoal_KRA);
				this.getView().byId("Lbl_KPI").setText(sap.ui.getCore().fun_owngoal_KPI);
				this.getView().byId("Lbl_wtg").setText(sap.ui.getCore().fun_owngoal_Weight);
				this.getView().byId("Lbl_SrtDT").setText(sap.ui.getCore().fun_owngoal_startDt);
				this.getView().byId("Lbl_ComDT").setText(sap.ui.getCore().fun_owngoal_complDt);
				this.getView().byId("btn_scr_save").setText(sap.ui.getCore().save_btn);
				this.getView().byId("btn_scr_cancel").setText(sap.ui.getCore().cancel_btn);

				//////// for compliance goal add one goal //////////
				var KRA = "Compliance Goal";
				var KPI =
					"Adherence to Dr. Reddy's Code of Business Conduct and Ethics (“CoBE”), as well as all Company policies and procedures, and all relevant laws and regulations. Attendance and/or completion of required training (e.g. Annual Compliance Refresher Training); affirmations (e.g. Annual CoBE Quiz); Compliance Certifications (as per role); and, any other Compliance-related deliverables, by the deadlines that are established and communicated.";
				var wtf = "5";
				this.getView().byId("KRAVal").setValue(KRA);
				this.getView().byId("KPIVal").setValue(KPI);
				this.getView().byId("wtgVal").setValue(wtf);

				// 		//change laugage if user is russsian
				// 		    if(sap.ui.getCore().USERDATA.UnitText === "RU01" || sap.ui.getCore().USERDATA.UnitText === "RU02"){
				// 		    jQuery.sap.require("jquery.sap.resources");

				// 					var sLocale = "ru";
				// 					var oBundle = jQuery.sap.resources({
				// 						url: "i18n/i18n.properties",
				// 						locale: sLocale
				// 					});

				// 		var sMsg1 = oBundle.getText("FunctionalGoals");
				// 		sap.ui.getCore().byId("mnuFun").setText(sMsg1);

				// 		var sMsg2 = oBundle.getText("ProjectGoals");
				// 		sap.ui.getCore().byId("mnuProj").setText(sMsg2);

				// 		var sMsg3 = oBundle.getText("Scorecard");
				// 		sap.ui.getCore().byId("mnuscore").setText(sMsg3);

				// 		var sMsg4 = oBundle.getText("owngoal");
				// 		sap.ui.getCore().byId("mnuFunOwn").setText(sMsg4);

				// 		var sMsg5 = oBundle.getText("owngoal");
				// 		sap.ui.getCore().byId("mnuProjOwn").setText(sMsg5);

				// }

				// start_date.setMinDate(new Date("2017-04-01 11:12"));
				// start_date.setMaxDate(new Date("2018-03-31 11:12"));

				// end_date.setMaxDate(endDt);
				// end_date.setMinDate(statDt);

				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			oDialog.open();
		},
		/////////   open popup for function own goal
		handle_fun_own: function(oEvent) {
			var oView = sap.ui.getCore().ODThis.getView();

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Owngoal", this);
			/* 17 July	
			var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("fungoal_progInd");
				var value = progressBR.getPercentValue();
				fungoal_progInd.setDisplayValue("Overall Weightage " + value + " %");
				fungoal_progInd.setPercentValue(value);
				if (0 <= value && value <= 40) {
					fungoal_progInd.setState("Error");
				} else if (41 <= value && value <= 80) {
					fungoal_progInd.setState("Warning");
				} else if (81 <= value && value <= 100) {
					fungoal_progInd.setState("Success");
				}*/

				var start_date = oView.byId("DP2_start");
				var year = new Date().getFullYear();
				var statDt = new Date(year + "/04/01");
				start_date.setValue(oDateFormat.format(statDt));
				//31-03-2018
				var end_date = oView.byId("DP2");
				var year = new Date().getFullYear() + 1;
				var endDt = new Date(year + "/03/31");
				end_date.setValue(oDateFormat.format(endDt));

				this.getView().byId("OwnGoal").setTitle(sap.ui.getCore().fun_owngoal_tital);
				this.getView().byId("Lbl_KRA").setText(sap.ui.getCore().fun_owngoal_KRA);
				this.getView().byId("Lbl_KPI").setText(sap.ui.getCore().fun_owngoal_KPI);
				this.getView().byId("Lbl_wtg").setText(sap.ui.getCore().fun_owngoal_Weight);
				this.getView().byId("Lbl_SrtDT").setText(sap.ui.getCore().fun_owngoal_startDt);
				this.getView().byId("Lbl_ComDT").setText(sap.ui.getCore().fun_owngoal_complDt);
				this.getView().byId("btn_scr_save").setText(sap.ui.getCore().save_btn);
				this.getView().byId("btn_scr_cancel").setText(sap.ui.getCore().cancel_btn);

				oView.addDependent(oDialog);
			}

			oDialog.open();
		},

		////////////////////////// event on date change for start/complition date //////////////////////////////
		handleChange: function() {
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sap.ui.getCore().Perf_path_text);
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sap.ui.getCore().Goal_header);
			var oView = sap.ui.getCore().ODThis.getView();

			var start_date = oView.byId("DP2_start");
			var end_date = oView.byId("DP2");
			var year = new Date().getFullYear();
			var statDt = new Date(year + "/04/01 00:00:00");
			var year2 = new Date().getFullYear() + 1;
			var endDt = new Date(year2 + "/03/31 00:00:00");
			var Sel_date = new Date(start_date.getValue());
			var Sel_date_tr = new Date(end_date.getValue());
			if (Sel_date < statDt || Sel_date > endDt) {
				this.getView().byId("DP2_start").setValueState("Error");
				this.getView().byId("DP2_start").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
			} else {
				this.getView().byId("DP2_start").setValueState("None");
			}
			if (Sel_date_tr < statDt || Sel_date_tr > endDt) {
				this.getView().byId("DP2").setValueState("Error");
				this.getView().byId("DP2").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
			} else {
				this.getView().byId("DP2").setValueState("None");
			}

		},

		////////////////////////// event on date change for start/complition date for project goal //////////////////////////////		
		handleChange_proj: function() {
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sap.ui.getCore().Perf_path_text);
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sap.ui.getCore().Goal_header);
			var oView = sap.ui.getCore().ODThis.getView();
			var start_date = oView.byId("DP2_start_proj");
			var end_date = oView.byId("DP2_proj");
			var year = new Date().getFullYear();
			var statDt = new Date(year + "/04/01 00:00:00");
			var year2 = new Date().getFullYear() + 1;
			var endDt = new Date(year2 + "/03/31 00:00:00");
			var Sel_date = new Date(start_date.getValue());
			var Sel_Enddate = new Date(end_date.getValue());
			if (Sel_date < statDt || Sel_date > endDt) {
				this.getView().byId("DP2_start_proj").setValueState("Error");
				this.getView().byId("DP2_start_proj").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
			} else {
				this.getView().byId("DP2_proj").setValueState("None");
			}
			if (Sel_Enddate < statDt || Sel_Enddate > endDt) {
				this.getView().byId("DP2_proj").setValueState("Error");
				this.getView().byId("DP2_proj").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
			} else {
				this.getView().byId("DP2_proj").setValueState("None");
			}

		},

		/////////////////////////// edit project goal by pressing over there ///////////////////////////
		handle_proj_own: function(oEvent) {
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sap.ui.getCore().Perf_path_text);
			sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sap.ui.getCore().Goal_header);
			var oView = sap.ui.getCore().ODThis.getView();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Owngoal_proj", this);

			/* 17july
			var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("projgoal_progInd");
				var value = progressBR.getPercentValue();
				fungoal_progInd.setDisplayValue("Overall Weightage " + value + " %");
				fungoal_progInd.setPercentValue(value);
				if (0 <= value && value <= 40) {
					fungoal_progInd.setState("Error");
				} else if (41 <= value && value <= 80) {
					fungoal_progInd.setState("Warning");
				} else if (81 <= value && value <= 100) {
					fungoal_progInd.setState("Success");
				}*/

				// var start_date = oView.byId("DP2_start_proj");
				// start_date.setValue(oDateFormat.format(new Date()));

				var start_date = oView.byId("DP2_start_proj");
				var year = new Date().getFullYear();
				var statDt = new Date(year + "/Apr/01");
				start_date.setValue(oDateFormat.format(statDt));

				//31-03-2018
				var end_date = oView.byId("DP2_proj");
				var year = new Date().getFullYear() + 1;
				var endDt = new Date(year + "/Mar/31");
				end_date.setValue(oDateFormat.format(endDt));

				this.getView().byId("OwnGoal_proj").setTitle(sap.ui.getCore().proj_owngoal_tital);
				this.getView().byId("Lbl_KRA_proj").setText(sap.ui.getCore().fun_owngoal_KRA);
				this.getView().byId("Lbl_KPI_proj").setText(sap.ui.getCore().fun_owngoal_KPI);
				this.getView().byId("Lbl_wtg_proj").setText(sap.ui.getCore().fun_owngoal_Weight);
				this.getView().byId("Lbl_SrtDT_proj").setText(sap.ui.getCore().fun_owngoal_startDt);
				this.getView().byId("Lbl_ComDT_proj").setText(sap.ui.getCore().fun_owngoal_complDt);
				this.getView().byId("btn_scr_save").setText(sap.ui.getCore().save_btn);
				this.getView().byId("btn_scr_cancel").setText(sap.ui.getCore().cancel_btn);

				// start_date.setMaxDate(endDt);
				// start_date.setMinDate(statDt);
				// end_date.setMaxDate(endDt);
				// end_date.setMinDate(statDt);

				// connect dialog to view (models, lifecycle)
				//	this.getView().byId("IntVal").setValue("Add Project Name , Project Manager Name");
				oView.addDependent(oDialog);
			}

			oDialog.open();
		},

		//////////////////////// set image of EMP, get setted goals/////////////////////////////
		_handleRouteMatched: function() {

			try {
			/*	this.showBusyIndicator(20000, 0);*/
				sap.ui.getCore().SAVEFLAG = 0;

				sap.ui.getCore().username = sap.ushell.Container.getUser().getId();
			//sap.ui.getCore().username =	com.drl.pmsmobile.dev.devapp.devLogon.appContext.registrationContext.user;
			/*	sap.ui.getCore().username = 'P00047423';*/
				//sap.ui.getCore().username = 'P00044417';
			
			
			
				sap.ui.getCore().ODThis = this;
				sap.ui.getCore().fun_Complgoal_tital = "Add Compliance Goal";
				sap.ui.getCore().fun_owngoal_tital = "Add Functional Goal";
				sap.ui.getCore().fun_owngoal_KRA = "KRA/Goals";
				sap.ui.getCore().fun_owngoal_KPI = "KPI/Measurement";
				sap.ui.getCore().fun_owngoal_Weight = "Weight";
				sap.ui.getCore().fun_owngoal_startDt = "Start Date:";
				sap.ui.getCore().fun_owngoal_complDt = "Completion Date";

				//english text show
				sap.ui.getCore().mnu_func = "Functional Goal";
				sap.ui.getCore().mnu_proj = "Project Goal";
				sap.ui.getCore().mnu_score = "Score Card";
				sap.ui.getCore().mnu_own = "Own Goal";
				sap.ui.getCore().save_btn = "Add Goal";
				sap.ui.getCore().cancel_btn = "Cancel";
				sap.ui.getCore().scorecard_tbl_header = "Respective Scorecard";
				sap.ui.getCore().goallib_header = "Goal Library";
				sap.ui.getCore().Perf_path_text = "Performace Path";
				sap.ui.getCore().Goal_header = "Goal";

				//PDF print global variable 
				sap.ui.getCore().P_title = "Performance Management";
				sap.ui.getCore().P_empinfo = "Employee Information";
				sap.ui.getCore().P_Fname = "First Name:";
				sap.ui.getCore().P_empNO = "Employee Number:";
				sap.ui.getCore().P_desg = "Designation:";
				sap.ui.getCore().P_deprt = "Department:";
				sap.ui.getCore().P_L_1 = "L+1:";
				sap.ui.getCore().P_L_1_desg = "L+1 Designation:";
				sap.ui.getCore().P_L_2 = "L+2:";
				sap.ui.getCore().P_L_2_desg = "L+2 Designation:";

				sap.ui.getCore().scorecard_header =
					"After selecting the relevant Scorecard, please scroll down to view the Scorecard related Goals.  You may choose your preferred goals by clicking the checkbox next to them.";

				//image code
				var Logo =
					"data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=";
				this.getView().byId("goal_pic_id").setSrc(Logo);

				if (sap.ui.getCore().servicecallflag === 1) {
					this.servicecall();
				}
			} catch (e) {
				console.log(e);
			}

		},
		handle_fun:function(){
			if (sap.ui.getCore().USERDATA.UnitText === "GG EM - Russia Rep office" || sap.ui.getCore().USERDATA.UnitText ===
					"GG EM - Russia WOS") {
					sap.ui.getCore().ODThis.getView().getController().Russian_language();
				}
				//performance path according to status of user
				this.perf_path_update();

				//view handing according to status 
				this.view_handle();

				var view = this.getView();

				view.getController().aData = [];
				view.getController().aData_proj = [];
				sap.ui.getCore().cntwtg = 0;

		
			var progressBR = this.getView().byId("Proc_indicator");

				this.getView().getController().setHeaderDet();
				this.getView().getController().goalsGET();

				//Overall Weightage calculation 
			/* 17july
			var goals = sap.ui.getCore().GOALS.results;

				if (goals !== undefined) {

					var wtg_calc = 0;
					for (var i = 0; i < goals.length; i++) {
						wtg_calc = wtg_calc + parseInt(goals[i].Weightage);
					}
					progressBR.setDisplayValue("Overall Weightage " + wtg_calc + " %");
					progressBR.setPercentValue(wtg_calc);

					//color logic for progres bar
					if (0 <= wtg_calc && wtg_calc <= 40) {
						progressBR.setState("Error");
					} else if (41 <= wtg_calc && wtg_calc <= 80) {
						progressBR.setState("Warning");
					} else if (81 <= wtg_calc && wtg_calc <= 100) {
						progressBR.setState("Success");
					}

				}*/
				var userInfo = sap.ui.getCore().USERDATA;
				this.onAfterRendering1();
		},
		view_handle: function() {
			//goalsetting by EMP
			if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "") {

				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Active");
				b.setType("Active");
			/*
			Anuja
			a1.setMode("Delete");
				b1.setMode("Delete");*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(false);
				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(false);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				//button status code
			/*	this.getView().byId("btn_save_goalSet").setEnabled(true);*/
/*				this.getView().byId("btn_submit_GoalSet").setEnabled(true);*/

			/*	this.getView().byId("openMenu").setEnabled(true);
				this.getView().byId("GOAL_LIB").setEnabled(true);*/

			}
			//goal appover by manager
			else if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "3") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");
				//save and submit button disabl code
			/*	this.getView().byId("btn_save_goalSet").setEnabled(false);*/
				/*this.getView().byId("btn_submit_GoalSet").setEnabled(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(false);
				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(false);
			}
			//half year employee
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setEnabled(true);*/
			/*	this.getView().byId("btn_submit_GoalSet").setEnabled(true);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
			/*	panel.setExpanded(false);*/
				panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
			/*	panel.setExpanded(false);*/
				panel.setExpanded(true);
				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				//mngr comment section should hide
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(false);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(false);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(false);

			}
			//half year comment by manager
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "3") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");
/*
				this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

				/*this.getView().byId("btn_save_goalSet").setEnabled(false);*/
			/*	this.getView().byId("btn_submit_GoalSet").setEnabled(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);
*/
				//mngr comment section should hide
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(false);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(false);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(false);
				
				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image to over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);
				//set value to halfyear assetment
				var Hyr_FBK = this.getView().byId("_overAllCMNT");
			/*	Hyr_FBK.setValue(sap.ui.getCore().USERDATA.HyrFbkTxt);*/
				Hyr_FBK.setText(sap.ui.getCore().USERDATA.HyrFbkTxt); //5thJuly

			}
			//goal revisit by emp
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "4") {
				//goal rivisit
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Active");
				b.setType("Active");
			/*
			Anuja
			a1.setMode("Delete");
				b1.setMode("Delete");*/

			/*	this.getView().byId("openMenu").setVisible(true);
				this.getView().byId("GOAL_LIB").setVisible(true);*/
		
		/*	this.getView().byId("Proc_indicator").setVisible(true);*/
			this.getView().byId("Proc_indicator").setVisible(false);
			
		

			/*	this.getView().byId("btn_save_goalSet").setEnabled(true);*/
			/*	this.getView().byId("btn_submit_GoalSet").setEnabled(true);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
			/*	panel.setExpanded(false);*/
				panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
			/*	panel.setExpanded(false);*/
				panel.setExpanded(true);

				// coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				//mngr comment section should hide
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_AnnualAsset");
				panel.setVisible(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image to over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);
				//set value to halfyear assetment
				this.getView().byId("_overallAsserTL").destroyEmbeddedControl();
				this.getView().byId("_overallAsserTL").setText(sap.ui.getCore().USERDATA.HyrFbkTxt);
				// var Hyr_FBK = this.getView().byId("_overAllCMNT");
				// Hyr_FBK.setValue(sap.ui.getCore().USERDATA.HyrFbkTxt);
				// Hyr_FBK.setEditable(false);

			}
			//goal approver by manager 
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "5") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setEnabled(false);*/
/*				this.getView().byId("btn_submit_GoalSet").setEnabled(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//mngr comment section should hide
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_AnnualAsset");
				panel.setVisible(false);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				// //mngr comment disable
				// this.getView().byId("_overAllCMNT").setEditable(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image to over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set value to halfyear assetment
				var Hyr_FBK = this.getView().byId("_overallAsserTL");
				Hyr_FBK.destroyEmbeddedControl();
				Hyr_FBK.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

			}
			//annual self appraisal by EMP
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "6") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setEnabled(true);*/
/*				this.getView().byId("btn_submit_GoalSet").setEnabled(true);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				/*	panel.setExpanded(false); *///11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				/*	panel.setExpanded(false); *///11july
					panel.setExpanded(true);

				//mngr comment section should visible
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				//set value to halfyear assetment
				var Hyr_FBK_TL = this.getView().byId("_overallAsserTL").destroyEmbeddedControl();
				Hyr_FBK_TL.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);
				// var Hyr_FBK = this.getView().byId("_overAllCMNT");
				// Hyr_FBK.setValue(sap.ui.getCore().USERDATA.HyrFbkTxt);
				// //mngr comment disable
				// this.getView().byId("_overAllCMNT").setEditable(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				//set image manager to half year review over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set image EMP to annual review over all assetment 
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_overallAsset_mngr").setDateTime(new Date());
				this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//Ann self appraisal text
			/*	this.getView().byId("Goalset--Annual_overAllCMNT_EMP").setValue(sap.ui.getCore().USERDATA.OvrAchTxt);*/
				var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				ANN_EMP.destroyEmbeddedControl();
				ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

				//hide manager annual overall assetment comment
				this.getView().byId("Annual_overallAsset_mngr").setVisible(false);

			}
			//annual by L+1
			else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "2") {

				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");
/*
				this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setVisible(false);*/
/*				this.getView().byId("btn_submit_GoalSet").setVisible(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
				/*panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);

				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);

				//mngr comment section should visible
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);

				//mngr comment disable
			/*	this.getView().byId("_overAllCMNT").setEditable(false);*/

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				//set image manager to half year review over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set image EMP to annual review over all assetment 
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				// //set image manager to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//destore embbeded comtrol from timeline
				var HY_L1 = this.getView().byId("_overallAsserTL");
				HY_L1.destroyEmbeddedControl();
				HY_L1.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

				var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				ANN_EMP.destroyEmbeddedControl();
				ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

				// //annual L+1 comment get
				// this.getView().byId("Ann_L1_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				// this.getView().byId("Ann_L1_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				// var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				// Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.AnnLp1Txt);
				// //annual L+1 comment get
				// var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr_stack");
				// Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.SthFbkTxt);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

			}
			//annual by L+2
			else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "3") {
				
				var a = this.getView().byId("func_ObjList");
    var b = this.getView().byId("proj_ObjList");
    var a1 = this.getView().byId("Func_list");
    var b1 = this.getView().byId("Proj_list");
    a.setType("Inactive");
    b.setType("Inactive");
    a1.setMode("None");
    b1.setMode("None");

   /* this.getView().byId("openMenu").setVisible(false);
    this.getView().byId("GOAL_LIB").setVisible(false);*/
    this.getView().byId("Proc_indicator").setVisible(false);

    /*this.getView().byId("btn_save_goalSet").setVisible(false);
    this.getView().byId("btn_submit_GoalSet").setVisible(false);*/

    //half year review comment panel hide
    var panel = this.getView().byId("PNL_halfyrcmnt");
    panel.setVisible(true);
    //half year comment panel expand false
  /*  panel.setExpanded(true);*/
  /*	panel.setExpanded(false);*/ //11july
  	panel.setExpanded(true);
    var panel = this.getView().byId("PNL_halfyrcmnt_proj");
    panel.setVisible(true);
    //half year comment panel expand false
   /* panel.setExpanded(true);*/
   /*	panel.setExpanded(false);*/ //11july
	panel.setExpanded(true);
    //Final sign off panel hide
   /* this.getView().byId("Fnl_sign").setVisible(false);*/

    // annual eview coment panel hide
    var panel = this.getView().byId("PNL_annualRevw");
    panel.setVisible(true);
    /*	panel.setExpanded(false); *///11july
    	panel.setExpanded(true);
    var panel = this.getView().byId("PNL_annualRevw_proj");
    panel.setVisible(true);
    /*	panel.setExpanded(false);*/ //11july
    	panel.setExpanded(true);

    //mngr comment section should visible
    this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
    this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

    //overall assesment
    var panel = this.getView().byId("PNL_OverAllAsset");
    panel.setVisible(true);
    /*	panel.setExpanded(false);*/ //11july
	panel.setExpanded(true);
    //mngr comment disable
  /*  this.getView().byId("_overAllCMNT").setEditable(false);*/

    //set date time of timeline
    var Hy_OVRASS_Date = new Date();
    if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
     var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

     var y = datetime.substring(0, 3);
     var y = datetime.substring(0, 4);
     var m = datetime.substring(4, 6);
     var d = datetime.substring(6, 8);
     var H = datetime.substring(8, 10);
     var Min = datetime.substring(10, 12);
     var sec = datetime.substring(12, 14);
     Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
    }

    //set image manager to half year review over all assetment 
    this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
    this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
    this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

    //set image EMP to annual review over all assetment 
    //set date time of timeline
    var An_SLF_Date = new Date();
    if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
     var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
     var y = datetime.substring(0, 3);
     var y = datetime.substring(0, 4);
     var m = datetime.substring(4, 6);
     var d = datetime.substring(6, 8);
     var H = datetime.substring(8, 10);
     var Min = datetime.substring(10, 12);
     var sec = datetime.substring(12, 14);
     An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
    }
    this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
    this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
    this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

    //set date time of timeline
    var An_L1_Date = new Date();
    if (sap.ui.getCore().USERDATA.ANN_LP1_DAT !== "") {
     var datetime = sap.ui.getCore().USERDATA.ANN_LP1_DAT;
     var y = datetime.substring(0, 3);
     var y = datetime.substring(0, 4);
     var m = datetime.substring(4, 6);
     var d = datetime.substring(6, 8);
     var H = datetime.substring(8, 10);
     var Min = datetime.substring(10, 12);
     var sec = datetime.substring(12, 14);
     An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
    }
    //set image manager to annual review over all assetment 
    this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
    this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
    this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName);

    //set date time of timeline
    var An_L1_Date = new Date();
    if (sap.ui.getCore().USERDATA.RVW_REV_DAT !== "") {
     var datetime = sap.ui.getCore().USERDATA.RVW_REV_DAT;
     var y = datetime.substring(0, 3);
     var y = datetime.substring(0, 4);
     var m = datetime.substring(4, 6);
     var d = datetime.substring(6, 8);
     var H = datetime.substring(8, 10);
     var Min = datetime.substring(10, 12);
     var sec = datetime.substring(12, 14);
     An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
    }
    //set image manager to annual review over all assetment 
    this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA.OtherImage);
    this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L1_Date);
    this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA.OtherName);

    //manager annual overall assetment comment
    this.getView().byId("Annual_overallAsset_mngr").setVisible(true);

    //destore embbeded comtrol from timeline
    var HY_L1 = this.getView().byId("_overallAsserTL");
    HY_L1.destroyEmbeddedControl();
    HY_L1.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

    var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
    ANN_EMP.destroyEmbeddedControl();
    ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

    //annual L+1 comment get
    this.getView().byId("Ann_L1_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
    this.getView().byId("Ann_L1_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
    var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
   /* Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.AnnLp1Txt);*/
   Ann_l1_txt.setText(sap.ui.getCore().USERDATA.AnnLp1Txt); //5thJuly
    var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr_stack");
   /* Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.SthFbkTxt);*/
   Ann_l1_txt.setText(sap.ui.getCore().USERDATA.AnnLp1Txt); //5thJuly
    //get Annual L+2 data
    this.getView().byId("Ann_L2_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
    this.getView().byId("Ann_L2_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
    var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
    /*Ann_l2_txt.setValue(sap.ui.getCore().USERDATA.RvwRevTxt);*/
    Ann_l2_txt.setText(sap.ui.getCore().USERDATA.RvwRevTxt); //5thJuly
				
			}
			//annual by ARC
			else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "4") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setVisible(false);*/
/*				this.getView().byId("btn_submit_GoalSet").setVisible(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//half year comment panel expand false
				/*panel.setExpanded(true);*/
				/*	panel.setExpanded(false); *///11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				/*	panel.setExpanded(false); *///11july
				panel.setExpanded(true);
				//mngr comment section should visible
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
						panel.setExpanded(true);

				// 	//overall comment hide
				// this.getView().byId("Annual_overallAsset_mngr").setVisible(true);
				// this.getView().byId("Annual_overallAsset_Lp2").setVisible(true);
				// this.getView().byId("Annual_ARC").setVisible(true);

				//mngr comment disable
			/*	this.getView().byId("_overAllCMNT").setEditable(false);*/

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				//set image manager to half year review over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set image EMP to annual review over all assetment 
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA.OtherImage);
				this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L1_Date);
				this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA.OtherName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.FIN_APP_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.FIN_APP_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//ARC timeline set
				this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_ARC").setDateTime(An_L1_Date);
				this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//manager annual overall assetment comment
				this.getView().byId("Annual_overallAsset_mngr").setVisible(true);

				//destore embbeded comtrol from timeline
				var HY_L1 = this.getView().byId("_overallAsserTL");
				HY_L1.destroyEmbeddedControl();
				HY_L1.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

				var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				ANN_EMP.destroyEmbeddedControl();
				ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

				//annual L+1 comment get
				this.getView().byId("Ann_L1_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L1_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				/*Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.AnnLp1Txt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.AnnLp1Txt); //5thjuly
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr_stack");
			/*	Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.SthFbkTxt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.SthFbkTxt); //5thjuly
				//get Annual L+2 data
				this.getView().byId("Ann_L2_rating").setText(sap.ui.getCore().USERDATA.RvwRevVal);
				this.getView().byId("Ann_L2_Poifact").setText(sap.ui.getCore().USERDATA.PftLp2Val);
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
				/*Ann_l2_txt.setValue(sap.ui.getCore().USERDATA.RvwRevTxt);*/
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA.RvwRevTxt); //5thJuly

				//get ARC data
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA.PntFctVal);
				/*this.getView().byId("Annual_overAllCMNT_ARC").setValue(sap.ui.getCore().USERDATA.ArcFbkTxt);*/
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA.ArcFbkTxt); //5thJuly
			}
			//complete
			else if (sap.ui.getCore().USERDATA.ApStatus == "5" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setVisible(false);*/
/*				this.getView().byId("btn_submit_GoalSet").setVisible(true);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(true);*/

				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
					/*panel.setExpanded(false);*/ //11july
						panel.setExpanded(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
					/*panel.setExpanded(false);*/ //11july
						panel.setExpanded(true);

				//mngr comment section should visible
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
					/*panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				//overall comment hide
				// this.getView().byId("Annual_overallAsset_mngr").setVisible(true);
				// this.getView().byId("Annual_overallAsset_Lp2").setVisible(true);
				// this.getView().byId("Annual_ARC").setVisible(true);

				//mngr comment disable
				/*this.getView().byId("_overAllCMNT").setEditable(false);*/

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				//set image manager to half year review over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set image EMP to annual review over all assetment 
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName + "[L+1]");

				//set date time of timeline
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA.OtherImage);
				this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA.OtherName + "[L+2]");

				//ARC timeline set
				//set date time of timeline
				var An_ARC_Date = new Date();
				if (sap.ui.getCore().USERDATA.FIN_APP_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.FIN_APP_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_ARC_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_ARC").setDateTime(An_ARC_Date);
				this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA.ApprName + "[ARC]");

				//manager annual overall assetment comment
				this.getView().byId("Annual_overallAsset_mngr").setVisible(true);

				//destore embbeded comtrol from timeline
				var HY_L1 = this.getView().byId("_overallAsserTL");
				HY_L1.destroyEmbeddedControl();
				HY_L1.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

				var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				ANN_EMP.destroyEmbeddedControl();
				ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

				//annual L+1 comment get
				this.getView().byId("Ann_L1_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L1_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				/*Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.AnnLp1Txt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.AnnLp1Txt); //5thjuly
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr_stack");
			/*	Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.SthFbkTxt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.SthFbkTxt); //5thjuly
				//get Annual L+2 data
				this.getView().byId("Ann_L2_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L2_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
				/*Ann_l2_txt.setValue(sap.ui.getCore().USERDATA.RvwRevTxt);*/
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA.RvwRevTxt); //5thJuly

				//get ARC data
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA.PntFctVal);
				/*this.getView().byId("Annual_overAllCMNT_ARC").setValue(sap.ui.getCore().USERDATA.ArcFbkTxt);*/
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA.ArcFbkTxt);//5thJuly
			}
			//disagree complete
			else if (sap.ui.getCore().USERDATA.ApStatus == "6" && sap.ui.getCore().USERDATA.ApStatusSub == "") {

				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setVisible(false);*/
/*				this.getView().byId("btn_submit_GoalSet").setVisible(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//half year comment panel expand false
				/*panel.setExpanded(true);*/
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);

				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				/*	panel.setExpanded(false); *///11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
					/*panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				//mngr comment section should visible
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
					/*panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				//overall comment hide
				// this.getView().byId("Annual_overallAsset_mngr").setVisible(true);
				// this.getView().byId("Annual_overallAsset_Lp2").setVisible(true);
				// this.getView().byId("Annual_ARC").setVisible(true);

				//mngr comment disable
			/*	this.getView().byId("_overAllCMNT").setEditable(false);*/

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				//set image manager to half year review over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set image EMP to annual review over all assetment 
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set date time of timeline
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA.OtherImage);
				this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA.OtherName);

				//ARC timeline set
				//set date time of timeline
				var An_ARC_Date = new Date();
				if (sap.ui.getCore().USERDATA.FIN_APP_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.FIN_APP_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_ARC_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_ARC_Date);
				this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//manager annual overall assetment comment
				this.getView().byId("Annual_overallAsset_mngr").setVisible(true);

				//destore embbeded comtrol from timeline
				var HY_L1 = this.getView().byId("_overallAsserTL");
				HY_L1.destroyEmbeddedControl();
				HY_L1.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

				var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				ANN_EMP.destroyEmbeddedControl();
				ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

				//annual L+1 comment get
				this.getView().byId("Ann_L1_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L1_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
			/*	Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.AnnLp1Txt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.AnnLp1Txt); //5thjuly
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr_stack");
				/*Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.SthFbkTxt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.SthFbkTxt); //5thjuly
				//get Annual L+2 data
				this.getView().byId("Ann_L2_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L2_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
				/*Ann_l2_txt.setValue(sap.ui.getCore().USERDATA.RvwRevTxt);*/
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA.RvwRevTxt); //5thJuly

				//get ARC data
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA.PntFctVal);
						/*this.getView().byId("Annual_overAllCMNT_ARC").setValue(sap.ui.getCore().USERDATA.ArcFbkTxt);*/
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA.ArcFbkTxt); //5thJuly
			}
			//agree complete 
			else if (sap.ui.getCore().USERDATA.ApStatus == "7" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				var a = this.getView().byId("func_ObjList");
				var b = this.getView().byId("proj_ObjList");
				var a1 = this.getView().byId("Func_list");
				var b1 = this.getView().byId("Proj_list");
				a.setType("Inactive");
				b.setType("Inactive");
				a1.setMode("None");
				b1.setMode("None");

			/*	this.getView().byId("openMenu").setVisible(false);
				this.getView().byId("GOAL_LIB").setVisible(false);*/
				this.getView().byId("Proc_indicator").setVisible(false);

			/*	this.getView().byId("btn_save_goalSet").setVisible(false);*/
			/*	this.getView().byId("btn_submit_GoalSet").setVisible(false);*/

				//half year review comment panel hide
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
			/*	panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//half year comment panel expand false
			/*	panel.setExpanded(true);*/
				/*panel.setExpanded(false);*/ //11july
				panel.setExpanded(true);
				//Final sign off panel hide
			/*	this.getView().byId("Fnl_sign").setVisible(false);*/

				// annual eview coment panel hide
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				/*	panel.setExpanded(false); *///11july
					panel.setExpanded(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				/*	panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				//mngr comment section should visible
				this.getView().byId("_idTimelineItem_mngrcmnt").setVisible(true);
				this.getView().byId("_idTimelineItem_proj_mngrcmnt").setVisible(true);

				//overall assesment
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
					/*panel.setExpanded(false);*/ //11july
					panel.setExpanded(true);
				//overall comment hide
				// this.getView().byId("Annual_overallAsset_mngr").setVisible(true);
				// this.getView().byId("Annual_overallAsset_Lp2").setVisible(true);
				// this.getView().byId("Annual_ARC").setVisible(true);

				//mngr comment disable
			/*	this.getView().byId("_overAllCMNT").setEditable(false);*/

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				//set image manager to half year review over all assetment 
				this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set image EMP to annual review over all assetment 
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//set date time of timeline
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set image manager to annual review over all assetment 
				this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA.OtherImage);
				this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA.OtherName);

				//ARC timeline set
				//set date time of timeline
				var An_ARC_Date = new Date();
				if (sap.ui.getCore().USERDATA.FIN_APP_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA.FIN_APP_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_ARC_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				this.getView().byId("Annual_ARC").setDateTime(An_ARC_Date);
				this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA.ApprName);

				//manager annual overall assetment comment
				this.getView().byId("Annual_overallAsset_mngr").setVisible(true);

				//destore embbeded comtrol from timeline
				var HY_L1 = this.getView().byId("_overallAsserTL");
				HY_L1.destroyEmbeddedControl();
				HY_L1.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);

				var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				ANN_EMP.destroyEmbeddedControl();
				ANN_EMP.setText(sap.ui.getCore().USERDATA.OvrAchTxt);

				//annual L+1 comment get
				this.getView().byId("Ann_L1_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L1_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				/*Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.AnnLp1Txt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.AnnLp1Txt); //5thjuly
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr_stack");
				/*Ann_l1_txt.setValue(sap.ui.getCore().USERDATA.SthFbkTxt);*/
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA.SthFbkTxt); //5thjuly
				//get Annual L+2 data
				this.getView().byId("Ann_L2_rating").setText(sap.ui.getCore().USERDATA.AnnLp1Val);
				this.getView().byId("Ann_L2_Poifact").setText(sap.ui.getCore().USERDATA.PftLp1Val);
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
			/*	Ann_l2_txt.setValue(sap.ui.getCore().USERDATA.RvwRevTxt);*/
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA.RvwRevTxt);  //5thJuly
				

				//get ARC data
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA.PntFctVal);
			/*	this.getView().byId("Annual_overAllCMNT_ARC").setValue(sap.ui.getCore().USERDATA.ArcFbkTxt);*/
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA.ArcFbkTxt); //5thJuly
			}

		},

		perf_path_update: function() {
			var userInfo = sap.ui.getCore().USERDATA;
			if (userInfo.ApStatus === "2" && userInfo.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://customize",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 1
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "2" && userInfo.ApStatusSub === "3") {

				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "3" && userInfo.ApStatusSub === "" || userInfo.ApStatus === "3" && userInfo.ApStatusSub === "3") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "3" && userInfo.ApStatusSub === "4") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "3" && userInfo.ApStatusSub === "5") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "3" && userInfo.ApStatusSub === "6") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review self appraisal",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "4" && userInfo.ApStatusSub === "2") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review L+1",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "4" && userInfo.ApStatusSub === "3") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review L+2",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "4" && userInfo.ApStatusSub === "4") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "5" && userInfo.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review ARC",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			} else if (userInfo.ApStatus === "7" && userInfo.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://accept",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://accept",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review ARC",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();

			}
		},

		timeline_dataset: function() {
			var goals = sap.ui.getCore().GOALS.results;
			var functionalGoals = [];
			var projectGoals = [];
			for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0001') {
					functionalGoals.push(goals[i]);
				} else if (goals[i].GoalId === '0002') {
					projectGoals.push(goals[i]);
				}
			}
			for (var i = 0; i < functionalGoals.length; i++) {
				//set date time of timeline
				var Hy_Emp_Date = new Date();
				if (functionalGoals[i].HYR_EMP_DAT !== "") {
					var datetime = functionalGoals[i].HYR_EMP_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setDateTime(Hy_Emp_Date);
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);

			}
			for (var i = 0; i < projectGoals.length; i++) {
				var Hy_Emp_Date = new Date();
				if (projectGoals[i].HYR_EMP_DAT !== "") {
					//set date time of timeline
					var datetime = projectGoals[i].HYR_EMP_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setDateTime(Hy_Emp_Date);
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
			}
		},
		Annual_timeline_dataset: function() {
			var goals = sap.ui.getCore().GOALS.results;
			var functionalGoals = [];
			var projectGoals = [];
			for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0001') {
					functionalGoals.push(goals[i]);
				} else if (goals[i].GoalId === '0002') {
					projectGoals.push(goals[i]);
				}
			}
			for (var i = 0; i < functionalGoals.length; i++) {
				//set date time of timeline
				var Ann_Emp_Date = new Date();
				if (functionalGoals[i].ANN_SLF_DAT !== "") {
					var datetime = functionalGoals[i].ANN_SLF_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Ann_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set EMP photo and datetime
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setDateTime(Ann_Emp_Date);
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);

				//set manager photo and datetime
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(new Date());
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
			}
			for (var i = 0; i < projectGoals.length; i++) {
				//set date time of timeline
				var Ann_Emp_Date = new Date();
				if (projectGoals[i].ANN_SLF_DAT !== "") {
					var datetime = projectGoals[i].ANN_SLF_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Ann_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//set EMP photo and datetime
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setDateTime(Ann_Emp_Date);
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
				//set manager photo and datetime
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA
					.ApproverImage);
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(new Date());
				sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA
					.ApprName);
			}
		},

		half_year_save: function() {

			var that = this;
			sap.ui.getCore().SAVEFLAG = 0;
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd"
			});
			var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHMMss"
			});

			sap.ui.getCore().BatchOprAll = new Array();
			var oModel = this.getView().getModel();
			var _POSTCONTEXT = "ApprisalGoalsNewSet";

			var odatamodel = this.getView().getModel();

			this.showBusyIndicator(20000, 0);
			var user_Data = sap.ui.getCore().USERDATA;

			var flag = 0;

			var j = 0;
			var k = 0;
			var odata = new Array();
			var odata_proj = new Array();
			var goal_data = sap.ui.getCore().GOALS.results;
			var idcnt = 0;

			for (var i = 0; i < goal_data.length; i++) {
				if (goal_data[i].GoalId === '0001') {
					odata[j] = goal_data[i];
					j++;
				}
			}
			for (i = 0; i < goal_data.length; i++) {
				if (goal_data[i].GoalId === '0002') {
					odata_proj[k] = goal_data[i];
					k++;
				}
			}
			var GoDate_half = oDateformat_half.format(new Date());
			for (i = 0; i < odata.length; i++) {
				var kra = odata[i].KraText;
				var kpi = odata[i].KpiText;
				var wtg = odata[i].Weightage;
				//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
				var GoalDate = odata[i].GoalDate;
				var GoalName = odata[i].GoalName;
				var HyrEmpTxt = sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).getValue();
				var GoalSdate = odata[i].GoalSdate;

				var GoalItemId = odata[i].GoalItemId;

				var POSTENTRY = {
					HyrEmpTxt: HyrEmpTxt,
					HYR_EMP_DAT: GoDate_half
				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
					"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

			}

			//project goals save logic
			var idcnt = 0;
			for (i = 0; i < odata_proj.length; i++) {
				kra = odata_proj[i].KraText;
				kpi = odata_proj[i].KpiText;
				wtg = odata_proj[i].Weightage;
				//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
				var GoalName = odata_proj[i].GoalName;
				GoalDate = odata_proj[i].GoalDate;
				var HyrEmpTxt_proj = sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).getValue();
				var GoalSdate = odata_proj[i].GoalSdate;

				var GoalItemId = odata_proj[i].GoalItemId;
				var POSTENTRY = {
					HyrEmpTxt: HyrEmpTxt_proj,
					HYR_EMP_DAT: GoDate_half
				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
					"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

			}

			console.log(sap.ui.getCore().BatchOprAll);
			oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
			//oModel.addBatchReadOperations("PARAM_DET");
			oModel.setUseBatch(true);
			oModel.submitBatch(function(data) {
				oModel.refresh();

				//sap.m.MessageToast.show("Saved Successfully");
				if (data.__batchResponses[0].__changeResponses) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Saved Successfully");

					//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
				} else {
					//sap.m.MessageToast.show("Please check network connection");
					jQuery.sap.log.info(data.__batchResponses[0].message);
					sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
					sap.ui.core.BusyIndicator.hide();
				}
			}, function(err) {
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
				jQuery.sap.log.info("Error occurred", err);
			});

		},
		half_year_submit:function(){
			

			var that = this;
			sap.ui.getCore().SAVEFLAG = 0;
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd"
			});
			var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyyMMddHHMMss"
			});

			sap.ui.getCore().BatchOprAll = new Array();
			var oModel = this.getView().getModel();
			var _POSTCONTEXT = "ApprisalGoalsNewSet";

			var odatamodel = this.getView().getModel();

			this.showBusyIndicator(20000, 0);
			var user_Data = sap.ui.getCore().USERDATA;

			var flag = 0;

			var j = 0;
			var k = 0;
			var odata = new Array();
			var odata_proj = new Array();
			var goal_data = sap.ui.getCore().GOALS.results;
			var idcnt = 0;

			for (var i = 0; i < goal_data.length; i++) {
				if (goal_data[i].GoalId === '0001') {
					odata[j] = goal_data[i];
					j++;
				}
			}
			for (i = 0; i < goal_data.length; i++) {
				if (goal_data[i].GoalId === '0002') {
					odata_proj[k] = goal_data[i];
					k++;
				}
			}
			var GoDate_half = oDateformat_half.format(new Date());
			for (i = 0; i < odata.length; i++) {
				var kra = odata[i].KraText;
				var kpi = odata[i].KpiText;
				var wtg = odata[i].Weightage;
				//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
				var GoalDate = odata[i].GoalDate;
				var GoalName = odata[i].GoalName;
				var HyrEmpTxt = sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).getValue();
				var GoalSdate = odata[i].GoalSdate;

				var GoalItemId = odata[i].GoalItemId;

				var POSTENTRY = {
					HyrEmpTxt: HyrEmpTxt,
					HYR_EMP_DAT: GoDate_half
				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
					"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

			}

			//project goals save logic
			var idcnt = 0;
			for (i = 0; i < odata_proj.length; i++) {
				kra = odata_proj[i].KraText;
				kpi = odata_proj[i].KpiText;
				wtg = odata_proj[i].Weightage;
				//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
				var GoalName = odata_proj[i].GoalName;
				GoalDate = odata_proj[i].GoalDate;
				var HyrEmpTxt_proj = sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).getValue();
				var GoalSdate = odata_proj[i].GoalSdate;

				var GoalItemId = odata_proj[i].GoalItemId;
				var POSTENTRY = {
					HyrEmpTxt: HyrEmpTxt_proj,
					HYR_EMP_DAT: GoDate_half
				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
					"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

			}

			console.log(sap.ui.getCore().BatchOprAll);
			oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
			//oModel.addBatchReadOperations("PARAM_DET");
			oModel.setUseBatch(true);
			oModel.submitBatch(function(data) {
				oModel.refresh();

				//sap.m.MessageToast.show("Saved Successfully");
				if (data.__batchResponses[0].__changeResponses) {
					//sap.ui.core.BusyIndicator.hide();
					//sap.m.MessageToast.show("Saved Successfully");
				
						//this.onsave_batch();
						var UserData = sap.ui.getCore().USERDATA;
						//var oModel = this.getView().getModel();
						var _UPDATESTATUS = "EmployeeStatusSet";

						var POSTENTRY = {
							"EmpCode": UserData.EmpCode,
							"FiscalYear": UserData.FiscalYear,
							"ActionFlag": "A",
							"EmpId": UserData.EmpId,
							"ActionComments": ""

						};

						oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')",
							POSTENTRY,
							null,
							function() {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("Submitted Sucessfully for approval");
								sap.ui.core.UIComponent.getRouterFor(that).navTo("_AfterSubmit", {});
							},
							function(oError) {
								var aa = JSON.parse(oError.response.body);
					
								alert("Error "+aa.error.message.value);
								sap.ui.core.BusyIndicator.hide();
							});

					//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
				} else {
					//sap.m.MessageToast.show("Please check network connection");
					jQuery.sap.log.info(data.__batchResponses[0].message);
					sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
					sap.ui.core.BusyIndicator.hide();
				}
			}, function(err) {
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
				jQuery.sap.log.info("Error occurred", err);
			});

		
		},

		

		//////////////////////// get saved goals ////////////////////////
		goalsGET: function() {
			try {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}

				}
				//functional goal set
				var dat = sap.ui.getCore().ODThis.getView().getController().aData;
				dat = dat.concat(functionalGoals);
				sap.ui.getCore().ODThis.getView().getController().aData = dat;
				var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
				var oModel = new sap.ui.model.json.JSONModel();
				var dt = [];
				var goaldate,goalsdate;

				for (var ii = 0; ii < dat.length; ii++) {
					var wtg = parseInt(dat[ii].Weightage);
					if(dat[ii].GoalDate instanceof Date){
						goaldate = oDateFormat.format(dat[ii].GoalDate);
					}else{
						goaldate = dat[ii].GoalDate;
					}
					if(dat[ii].GoalSdate instanceof Date){
						goalsdate = oDateFormat.format(dat[ii].GoalSdate);
					}else{
						goalsdate = dat[ii].GoalSdate;
					}
					dt.push({
						"EmpId": dat[ii].EmpId,
						"GoalId": dat[ii].GoalId,
						"GoalItemId": dat[ii].GoalItemId,
						"GoalName": dat[ii].GoalName,
						"Weightage": wtg + "%",
						"KraText": dat[ii].KraText,
						"KpiText": dat[ii].KpiText,
						"GoalDate": goaldate,
						"GoalSdate": goalsdate
					});
				}
				oModel.setData({
					modelData: dt
				});
				list.setModel(oModel);
				var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
				list.bindItems("/modelData", objlist);

				//project goal set
				dat = sap.ui.getCore().ODThis.getView().getController().aData_proj;
				dat = dat.concat(projectGoals);
				sap.ui.getCore().ODThis.getView().getController().aData_proj = dat;
				list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				oModel = new sap.ui.model.json.JSONModel();
				dt = [];

				for (ii = 0; ii < dat.length; ii++) {
					wtg = parseInt(dat[ii].Weightage);
					dt.push({
						"EmpId": dat[ii].EmpId,
						"GoalId": dat[ii].GoalId,
						"GoalItemId": dat[ii].GoalItemId,
						"GoalName": dat[ii].GoalName,
						"Weightage": wtg + "%",
						"KraText": dat[ii].KraText,
						"KpiText": dat[ii].KpiText,
						"GoalDate": oDateFormat.format(dat[ii].GoalDate),
						"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
					});
				}
				oModel.setData({
					modelData: dt
				});
				list.setModel(oModel);
				var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList");
				list.bindItems("/modelData", objlist);

				// 			var userInfo = sap.ui.getCore().USERDATA;
				// if(userInfo.ApStatus === "2" && userInfo.ApStatusSub === "3"){
				// 	this.getView().byId("func_ObjList").setType("Inactive");
				// 	this.getView().byId("proj_ObjList").setType("Inactive");
				// }
				// else{
				// 	this.getView().byId("func_ObjList").setType("Active");
				// 	this.getView().byId("proj_ObjList").setType("Active");
				// }
				// for(var i=0;i<functionalGoals.length;i++){
				// //set delete button tool tip
				// sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Func_list-"+i+"-imgDel").setTooltip("Delete");
				// }
				// for(var i=0;i<projectGoals.length;i++){
				// //set delete button tool tip
				// sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Proj_list-"+i+"-imgDel").setTooltip("Delete");
				// }

			} catch (e) {
				console.log(e);
			}
		},

		////////////////////// set employee header information /////////////////////////////
		setHeaderDet: function() {
			var HDR_INFO = sap.ui.getCore().USERDATA;
			this.byId("HD").setObjectTitle(HDR_INFO.EmpName + " |");
			this.byId("HD").setObjectSubtitle(HDR_INFO.DesignText);
			this.byId("HD").setObjectImageURI(sap.ui.getCore().USERDATA.EmpImage);
			this.byId("HD_empcode").setText(" : " + HDR_INFO.EmpId);
			this.byId("HD_roleB").setText(" : " + HDR_INFO.BandText);
			this.byId("HD_dept").setText(" : " + HDR_INFO.DepartText);
			this.byId("HD_unit").setText(" : " + HDR_INFO.UnitText);
			this.byId("HD_mngNM").setText(" : " + HDR_INFO.ApprName);
			this.byId("HD_revNM").setText(" : " + HDR_INFO.OtherName);
			this.byId("HD_mmngr").setText(" : " + HDR_INFO.PartApprName);

		},

		onBeforeRendering: function() {},

		///////////////////////// get need service odata call //////////////////////////////
		servicecall: function() {
			if(sap.ui.getCore().Year_Sel === undefined || sap.ui.getCore().Year_Sel === ""){
			sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ordersThis).navTo("_YearSelection",{});
			}else{
			
			var that = this;

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var odatamodel = this.getView().getModel();
			odatamodel.read("/ApprisalHeaderNewSet(EmpId='" + sap.ui.getCore().username + "',FiscalYear='" + sap.ui.getCore().Year_Sel +
				"')?$format=json", null, null,
				true,
				function(oResponse) {
					sap.ui.getCore().USERDATA = oResponse;
					that.entity2();
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);
					
					alert("Error "+aa.error.message.value);
					sap.ui.getCore().servicecallflag = 0;
					sap.ui.core.UIComponent.getRouterFor(that).navTo("_noDocFoud", {});
				});
			}
		},
		entity2: function(){
			var that = this;

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var odatamodel = this.getView().getModel();
			odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
				"%27%20and%20FiscalYear%20eq%20%27" + sap.ui.getCore().Year_Sel + "%27", null, null, true,
				function(oResponse) {
					sap.ui.getCore().GOALS = oResponse;
					that.handle_fun();
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);
					
					alert("Error "+aa.error.message.value);
					sap.ui.getCore().servicecallflag = 0;
					sap.ui.core.UIComponent.getRouterFor(that).navTo("_noDocFoud", {});
				});
			// odatamodel.read("/ReporteesListSet?$filter=EmpIdM%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false, function(oResponse) {
			// 	sap.ui.getCore().ReporteesList = oResponse;
			// });
			if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				odatamodel.read("/ScoreCardTreeSet", null, null, true, function(oResponse) {
					sap.ui.getCore().ScoreCardTree = oResponse;
				});
				odatamodel.read("/ScoreCardGoalSet", null, null, true, function(oResponse) {
					sap.ui.getCore().ScoreCardGoalSet = oResponse;
				});
			} 
		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf hr.view.Goalset
		 */
		 	toJquery: function() {
		 		
		 		var setLevel = sap.ui.getCore().byId("Goalset--processflow2");
		 		setLevel.setZoomLevel("Four");

		/*	console.log('In jquery');

			$("#__container1--Grid").css({
				'margin-left': '5%'
			});
			$("#Goalset--PNL_OverAllAsset").css({
				'margin-left': '5%'
			});*/

			/*var width = ((screen.height).toString()).concat("px");
				var height = ((screen.width).toString()).concat("px");
				$("#Goalset--Func_list").css({'margin-left':'4.5%'});
		 		$("#Goalset--Proj_list").css({'margin-left':'4.5%'});
		 		$("#Goalset--PNL_OverAllAsset").css({'margin-left':'10%'});*/
		},
		onAfterRendering1: function() {
				this.toJquery();
				
			sap.ui.getCore().Aftersubmit1 = "Document submitted successfully";
			sap.ui.getCore().Aftersubmit2 = "You can close the window.";

			this.getView().getController().Del_tooltip();
			var view = this.getView();
			//auto save 
			if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				setInterval(function() {
						console.log("Removed save");
				/*
			
				view.getController().onsave_batch();*/

					// ChangeC();	
				}, 180000);
			}
			if (sap.ui.getCore().USERDATA.ApStatus === "3" && sap.ui.getCore().USERDATA.ApStatusSub === "") {
				this.getView().getController().timeline_dataset();
				
				//data GET for haf year employee
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//set timeline text area text
					/*sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setValue(functionalGoals[i].HyrEmpTxt);*/
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
				    sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt); // settext is of timeline
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//set timeline text area text
				/*	sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setValue(projectGoals[i].HyrEmpTxt);*/
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
    			 sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
				}

			} else if (sap.ui.getCore().USERDATA.ApStatus === "3" && sap.ui.getCore().USERDATA.ApStatusSub === "3") {
				this.getView().getController().timeline_dataset();
				//not able to edit data 
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//get timeline text area text
					//sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setEditable(false);
					//set timeline text area text
					//sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setValue(functionalGoals[i].HyrEmpTxt);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//get timeline text area text
					//sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setEditable(false);
					//set timeline text area text
					//sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setValue(projectGoals[i].HyrEmpTxt);
				}
			} else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "4") {
				//this.getView().getController().timeline_dataset();
				//not able to edit data 
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					// //get timeline text area text
					// var mngr_cmnt = sap.ui.getCore().byId("Goalset--_timelineText_mngrcmnt-Goalset--Func_list-" + i);
					// mngr_cmnt.setEditable(false);
					// mngr_cmnt.setValue(functionalGoals[i].HyrFbkTxt);
					
					var Hy_Emp_Date = new Date();
				if(functionalGoals[i].HYR_EMP_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_EMP_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Emp_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//employee half year timeline
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setDateTime(Hy_Emp_Date);
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
				
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					
				// //get timeline text area text
				// 	sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setEditable(false);
				// 	sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setValue(functionalGoals[i].HyrEmpTxt);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
				//employee timeline datetime
					var Hy_Emp_Date = new Date();
				if(projectGoals[i].HYR_EMP_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_EMP_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Emp_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					// var mngr_cmnt = sap.ui.getCore().byId("Goalset--_timelineText_proj_mngrcmnt-Goalset--Proj_list-" + i);
					// mngr_cmnt.setEditable(false);
					// mngr_cmnt.setValue(projectGoals[i].HyrFbkTxt);
					
					//employee half year timeline
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setDateTime(Hy_Emp_Date);
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
				//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
				}

				//add new goal and set image of emp
				var fun_new = this.getView().byId("Func_list").getModel().getData().modelData;
				if (fun_new !== undefined) {
					if (fun_new.length > functionalGoals.length) {
						for (var i = 0; i < fun_new.length; i++) {
							//HF employee
							sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
							sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setEditable(false);
							
							//HF manager
							sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
							sap.ui.getCore().byId("Goalset--_timelineText_mngrcmnt-Goalset--Func_list-" + i).setEditable(false);
						}
					}
				}

				var proj_new = this.getView().byId("Proj_list").getModel().getData().modelData;
				if (proj_new !== undefined) {
					if (proj_new.length > projectGoals.length) {
						for (var i = 0; i < proj_new.length; i++) {
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
							sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setEditable(false);
							
							//HF manager
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
							sap.ui.getCore().byId("Goalset--_timelineText_proj_mngrcmnt-Goalset--Proj_list-" + i).setEditable(false);
							
						}
					}
				}
			} else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "5") {
				
				//this.getView().getController().timeline_dataset();
				//not able to edit data 
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					// var mngr_cmnt = sap.ui.getCore().byId("Goalset--_timelineText_mngrcmnt-Goalset--Func_list-" + i);
					// mngr_cmnt.setEditable(false);
					// mngr_cmnt.setValue(functionalGoals[i].HyrFbkTxt);
					
					var Hy_Emp_Date = new Date();
				if(functionalGoals[i].HYR_EMP_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_EMP_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Emp_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//employee half year timeline
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setDateTime(Hy_Emp_Date);
				sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
				// //get timeline text area text
				// 	sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setEditable(false);
				// 	sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setValue(functionalGoals[i].HyrEmpTxt);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
				//employee timeline datetime
					var Hy_Emp_Date = new Date();
				if(projectGoals[i].HYR_EMP_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_EMP_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Emp_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					// var mngr_cmnt = sap.ui.getCore().byId("Goalset--_timelineText_proj_mngrcmnt-Goalset--Proj_list-" + i);
					// mngr_cmnt.setEditable(false);
					// mngr_cmnt.setValue(projectGoals[i].HyrFbkTxt);
					
					//employee half year timeline
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setDateTime(Hy_Emp_Date);
				sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
				// //get timeline text area text
				// 	sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setEditable(false);
				// 	sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setValue(projectGoals[i].HyrEmpTxt);
					
				}

				//add new goal and set image of emp
				var fun_new = this.getView().byId("Func_list").getModel().getData().modelData;
				if (fun_new !== undefined) {
					if (fun_new.length > functionalGoals.length) {
						for (var i = 0; i < fun_new.length; i++) {
							//HF employee
							sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
							sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setEditable(false);
							
							//HF manager
							sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
							sap.ui.getCore().byId("Goalset--_timelineText_mngrcmnt-Goalset--Func_list-" + i).setEditable(false);
						}
					}
				}

				var proj_new = this.getView().byId("Proj_list").getModel().getData().modelData;
				if (proj_new !== undefined) {
					if (proj_new.length > projectGoals.length) {
						for (var i = 0; i < proj_new.length; i++) {
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.EmpImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.EmpName);
							sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setEditable(false);
							
							//HF manager
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(new Date());
							sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
							sap.ui.getCore().byId("Goalset--_timelineText_proj_mngrcmnt-Goalset--Proj_list-" + i).setEditable(false);
							
						}
					}
				}
			
			}else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "6") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					// sap.ui.getCore().byId("Goalset--_timelineText-Goalset--Func_list-" + i).setEditable(false);
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					// sap.ui.getCore().byId("Goalset--_timelineText_mngrcmnt-Goalset--Func_list-" + i).setEditable(false);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					//annual mngr cmnt hide
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-"+i).setVisible(false);
					
					//annual self apprraisal comment 
				/*	sap.ui.getCore().byId("Goalset--Annual_timelineText_EMP-Goalset--Func_list-" + i).setValue(functionalGoals[i].AnnSlfTxt);*/
				
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//sap.ui.getCore().byId("Goalset--_timelineText_proj-Goalset--Proj_list-" + i).setEditable(false);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//mngr comment editable false
				//	sap.ui.getCore().byId("Goalset--_timelineText_proj_mngrcmnt-Goalset--Proj_list-" + i).setEditable(false);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					

					//annual mngr cmnt hide
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setVisible(false);
					
					//annual self apprraisal comment 
				/*	sap.ui.getCore().byId("Goalset--Annual_timelineText_proj_EMP-Goalset--Proj_list-" + i).setValue(projectGoals[i].AnnSlfTxt);*/
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				//overall comment hide
				this.getView().byId("Annual_overallAsset_mngr").setVisible(false);
				this.getView().byId("Annual_overallAsset_Lp2").setVisible(false);
				this.getView().byId("Annual_ARC").setVisible(false);
			}else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "2") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(projectGoals);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
					//overall comment hide
				this.getView().byId("Annual_overallAsset_mngr").setVisible(false);
				this.getView().byId("Annual_overallAsset_Lp2").setVisible(false);
				this.getView().byId("Annual_ARC").setVisible(false);
				var aa=this.getView().byId("PNL_AnnualAsset")
				aa.$().removeClass("_classPNLInner");
				aa.$().addClass("_classPNLInner_2");
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "3") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
					
						//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
						//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				//overall comment hide
				this.getView().byId("Annual_overallAsset_mngr").setVisible(false);
				this.getView().byId("Annual_overallAsset_Lp2").setVisible(false);
				this.getView().byId("Annual_ARC").setVisible(false);
				var aa=this.getView().byId("PNL_AnnualAsset")
				aa.$().removeClass("_classPNLInner");
				aa.$().addClass("_classPNLInner_2");
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "4") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
					
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				this.getView().byId("Annual_overallAsset_mngr").setVisible(false);
				this.getView().byId("Annual_overallAsset_Lp2").setVisible(false);
				this.getView().byId("Annual_ARC").setVisible(false);
				var aa=this.getView().byId("PNL_AnnualAsset")
				aa.$().removeClass("_classPNLInner");
				aa.$().addClass("_classPNLInner_2");
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "5" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				this.getView().byId("Annual_overallAsset_mngr").setVisible(true);
				this.getView().byId("Annual_overallAsset_Lp2").setVisible(true);
				this.getView().byId("Annual_ARC").setVisible(true);
				sap.ui.getCore().byId("Goalset--Hbox_L1").removeAllItems();
				sap.ui.getCore().byId("Goalset--Hbox2_L1").removeAllItems();
				sap.ui.getCore().byId("Goalset--Hbox_L2").removeAllItems();
				sap.ui.getCore().byId("Goalset--Hbox2_L2").removeAllItems();
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "6" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
						//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "7" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "9" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				this.getView().getController().timeline_dataset();
				this.getView().getController().Annual_timeline_dataset();

				//not able to edit data and manager timeline data setting
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					//get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].HyrFbkTxt);
					
					//ANN comment set EMP
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_EMP-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnSlfTxt);
					//ANN comment set L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setText(functionalGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(functionalGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_mngrcmnt-Goalset--Func_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//get timeline text area text
					//HY get timeline text area text
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].HyrFbkTxt);
					
					//ANN comment editable false
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_EMP-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnSlfTxt);
					//ANN comment editable false L+1
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Goalset--Annual_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setText(projectGoals[i].AnnLp1Txt);
				
					//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if(projectGoals[i].HYR_FBK_DAT !== ""){
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;
					
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_Mngr_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
					//mngr timeline data set
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserPicture(sap.ui.getCore().USERDATA.ApproverImage);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setDateTime(Hy_Mngr_Date);
					sap.ui.getCore().byId("Goalset--_idTimelineItem_proj_mngrcmnt-Goalset--Proj_list-" + i).setUserName(sap.ui.getCore().USERDATA.ApprName);
				}
			}
			sap.ui.core.BusyIndicator.hide();

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf hr.view.Goalset
		 */
		//	onExit: function() {
		//
		//	}

		//Delete button tooltip code
		Del_tooltip: function() {
			try {

				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				if (sap.ui.getCore().USERDATA.ApStatus === "2" && sap.ui.getCore().USERDATA.ApStatusSub === "") {
					for (var i = 0; i < functionalGoals.length; i++) {
						//set delete button tool tip
						console.log('Removed del');
					/*
					Anuja
					sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Func_list-" + i + "-imgDel").setTooltip("Delete");*/
					}
					for (var i = 0; i < projectGoals.length; i++) {
						//set delete button tool tip
							console.log('Removed del');
					/*
					Anuja
						sap.ui.getCore().byId("Goalset--proj_ObjList-Goalset--Proj_list-" + i + "-imgDel").setTooltip("Delete");*/
					}

					//add new goal and set delete tooltip
					var fun_new = this.getView().byId("Func_list").getModel().getData().modelData;
					if (fun_new !== undefined) {
						if (fun_new.length > functionalGoals.length) {
							for (var i = 0; i < fun_new.length; i++) {
								//set delete button tool tip
								console.log('Removed del');
					/*
					Anuja
								sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Func_list-" + i + "-imgDel").setTooltip("Delete");*/
								
							}
						}
					}

					var proj_new = this.getView().byId("Proj_list").getModel().getData().modelData;
					if (proj_new !== undefined) {
						if (proj_new.length > projectGoals.length) {
							for (var i = 0; i < proj_new.length; i++) {
								//set delete button tool tip
									console.log('Removed del');
					/*
					Anuja
								sap.ui.getCore().byId("Goalset--proj_ObjList-Goalset--Proj_list-" + i + "-imgDel").setTooltip("Delete");*/
							}
						}
					}
				} else if (sap.ui.getCore().USERDATA.ApStatus === "3" && sap.ui.getCore().USERDATA.ApStatusSub === "4") {
					for (var i = 0; i < functionalGoals.length; i++) {
						//set delete button tool tip
							console.log('Removed del');
					/*
					Anuja
						sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Func_list-" + i + "-imgDel").setVisible(false);*/
					}
					for (var i = 0; i < projectGoals.length; i++) {
						//set delete button tool tip
							console.log('Removed del');
					/*
					Anuja
						sap.ui.getCore().byId("Goalset--proj_ObjList-Goalset--Proj_list-" + i + "-imgDel").setVisible(false);*/
					}

					//add new goal and set delete tooltip
					var fun_new = this.getView().byId("Func_list").getModel().getData().modelData;
					if (fun_new !== undefined) {
						if (fun_new.length > functionalGoals.length) {
							for (var i = 0; i < fun_new.length; i++) {
								//set delete button tool tip
									console.log('Removed del');
					/*
					Anuja
								sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Func_list-" + i + "-imgDel").setTooltip("Delete");*/
							}
						}
					}

					var proj_new = this.getView().byId("Proj_list").getModel().getData().modelData;
					if (proj_new !== undefined) {
						if (proj_new.length > projectGoals.length) {
							for (var i = 0; i < proj_new.length; i++) {
								//set delete button tool tip
									console.log('Removed del');
					/*
					Anuja
								sap.ui.getCore().byId("Goalset--proj_ObjList-Goalset--Proj_list-" + i + "-imgDel").setTooltip("Delete");*/
							}
						}
					}
				} else {
					for (var i = 0; i < functionalGoals.length; i++) {
						//set delete button tool tip
						sap.ui.getCore().byId("Goalset--func_ObjList-Goalset--Func_list-" + i).destroyTooltip();
					}
					for (var i = 0; i < projectGoals.length; i++) {
						//set delete button tool tip
						sap.ui.getCore().byId("Goalset--proj_ObjList-Goalset--Proj_list-" + i).destroyTooltip();
					}

				}
			} catch (e) {
				console.log(e);
			}
		},

		/////////////////// old code for open functiona goal popup///////////////////////////////
		onADD_Func: function(oEvent) {
			var view = this.getView();
			sap.ui.getCore().flag = 0;
			var dialog = new Dialog({
				title: 'Functional Goal',
				contentWidth: "550px",
				contentHeight: "300px",
				resizable: true,
				content: [
					new sap.m.Label({
						text: "Theme/Strategic Intent"
					}),
					new sap.m.Input("IntVal", {

					}),
					new sap.m.Label({
						text: "Weightage"
					}),
					new sap.m.Input("wtgVal", {
						type: "Number"
					}),
					new sap.m.Label({
						text: "KRA/Goals",
						width: "100%"
					}),
					new sap.m.TextArea("KRAVal", {
						rows: 5,
						cols: 50
					}),
					new sap.m.Label({
						text: "KPI/Measurment",
						width: "100%"
					}),
					new sap.m.TextArea("KPIVal", {
						rows: 5,
						cols: 50
					})
				],
				beginButton: new Button({
					text: 'Ok',
					press: function() {

						view.getController().addDataToTable(view);
						if (sap.ui.getCore().flag === 0) {
							dialog.close();
						}
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			//to get access to the global model
			this.getView().addDependent(dialog);
			dialog.open();
		},

		/////////////////////////////////// Open popup of functiona goal own goal /////////////////////
		owngoal_Add: function(view) {
			//	view.getController().aData = [];
			try {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});

				var dialog = this.getView().byId("OwnGoal");
				//	var intent = this.getView().byId("IntVal").getValue();
				var wtg = this.getView().byId("wtgVal").getValue();
				if (wtg !== "") {
					wtg = parseInt(wtg);
				}
				var kra = this.getView().byId("KRAVal").getValue();
				var kpi = this.getView().byId("KPIVal").getValue();
				var startDt = this.getView().byId("DP2_start").getValue();
				//startDt = oDateFormat.format(new Date(startDt));
				var year = new Date().getFullYear();
				var statDt = new Date(year + "/04/01 00:00:00");
				var year2 = new Date().getFullYear() + 1;
				var endDt = new Date(year2 + "/03/31 00:00:00");
				if (new Date(startDt) < statDt || new Date(startDt) > endDt) {
					startDt = "In";
				}
				var targetDt = this.getView().byId("DP2").getValue();
				//targetDt = oDateFormat.format(new Date(targetDt));
				if (new Date(targetDt) < statDt || new Date(targetDt) > endDt) {
					targetDt = "In";
				}

				//validation for wtg should not blank
				if (wtg !== "" && kra !== "" && kpi !== "" && targetDt !== "" && startDt !== "" && targetDt !== "In" && startDt !== "In") {

					if (sap.ui.getCore().index !== undefined) {
						var modeldata = this.getView().byId("Func_list").getModel().getData().modelData[sap.ui.getCore().index];
						var edit_wtg = modeldata.Weightage;
						var cntwtg = 0;
						var progressBR = this.getView().byId("Proc_indicator");
						var last_wtg = progressBR.getPercentValue();
						cntwtg = (parseInt(last_wtg) - parseInt(edit_wtg)) + parseInt(wtg);
						if (cntwtg <= 100) {
							//modeldata.intent = intent;
							modeldata.KpiText = kpi;
							modeldata.KraText = kra;
							modeldata.Weightage = wtg + "%";
							modeldata.GoalSdate = startDt;
							modeldata.GoalDate = targetDt;
							modeldata.GoalName = "Own Goal";

							var dat = this.getView().byId("Func_list").getModel().getData().modelData;
							var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modelData: dat
							});
							list.setModel(oModel);
							var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
							list.bindItems("/modelData", objlist);

							//Overall Weightage calculation 
							var list_calc = list.getModel().getData().modelData;
							var wtg_calc = 0;
							for (var i = 0; i < list_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
							}
							var list_proj = sap.ui.getCore().ODThis.getView().byId("Proj_list");
							var list_proj_calc = list_proj.getModel().getData();
							if (list_proj_calc !== null) {
								list_proj_calc = list_proj.getModel().getData().modelData;
								for (i = 0; i < list_proj_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
								}
							}
							var progressBR = this.getView().byId("Proc_indicator");
							progressBR.setDisplayValue("Overall Weightage " + wtg_calc + "%");
							progressBR.setPercentValue(wtg_calc);
							if (0 <= wtg_calc && wtg_calc <= 40) {
								progressBR.setState("Error");
							} else if (41 <= wtg_calc && wtg_calc <= 80) {
								progressBR.setState("Warning");
							} else if (81 <= wtg_calc && wtg_calc <= 100) {
								progressBR.setState("Success");
							}

							sap.ui.getCore().index = undefined;
							dialog.destroy();
							dialog.close();
						} else {
							MessageToast.show("you can not add weightage more than 100");
						}

					} else {
						var cntwtg = 0;
						var progressBR = this.getView().byId("Proc_indicator");
						var last_wtg = progressBR.getPercentValue();
						cntwtg = parseInt(last_wtg) + parseInt(wtg);
						//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
						//view.getController().checkwtg();
						if (cntwtg <= 100) {
							sap.ui.getCore().flag = 0;
							var subaData = [{
								//intent: intent,
								Weightage: wtg + "%",
								KraText: kra,
								KpiText: kpi,
								GoalSdate: startDt,
								GoalDate: targetDt,
								GoalName: "Own Goal"
							}];

							var dat = this.getView().byId("Func_list").getModel().getData().modelData;
							dat.push(subaData[0]);
							var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modelData: dat
							});
							list.setModel(oModel);
							var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
							list.bindItems("/modelData", objlist);
							//view.byId("scenariolB").addRow(row);

							//Overall Weightage calculation 
							var list_calc = list.getModel().getData().modelData;
							var wtg_calc = 0;
							for (var i = 0; i < list_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
							}
							var list_proj = sap.ui.getCore().ODThis.getView().byId("Proj_list");
							var list_proj_calc = list_proj.getModel().getData();
							if (list_proj_calc !== null) {
								list_proj_calc = list_proj.getModel().getData().modelData;
								for (i = 0; i < list_proj_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
								}
							}
							var progressBR = this.getView().byId("Proc_indicator");
							progressBR.setDisplayValue("Overall Weightage " + wtg_calc + "%");
							progressBR.setPercentValue(wtg_calc);
							if (0 <= wtg_calc && wtg_calc <= 40) {
								progressBR.setState("Error");
							} else if (41 <= wtg_calc && wtg_calc <= 80) {
								progressBR.setState("Warning");
							} else if (81 <= wtg_calc && wtg_calc <= 100) {
								progressBR.setState("Success");
							}
							MessageToast.show('Added!');
							dialog.destroy();
							dialog.close();
						} else {
							//sap.ui.getCore().flag = 1;
							//sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
							MessageToast.show("you can not add weightage more than 100");

						}
					}
				} else {
					var year = new Date().getFullYear();
					var year2 = new Date().getFullYear() + 1;
					if (wtg === "") {
						this.getView().byId("wtgVal").setValueState("Error");
						this.getView().byId("wtgVal").setValueStateText("Should not blank");
					} else {
						this.getView().byId("wtgVal").setValueState("None");
					}
					if (kra === "") {
						this.getView().byId("KRAVal").setValueState("Error");
						this.getView().byId("KRAVal").setValueStateText("Should not blank");
					} else {
						this.getView().byId("KRAVal").setValueState("None");
					}
					if (kpi === "") {
						this.getView().byId("KPIVal").setValueState("Error");
						this.getView().byId("KPIVal").setValueStateText("Should not blank");
					} else {
						this.getView().byId("KPIVal").setValueState("None");
					}
					if (targetDt === "") {
						this.getView().byId("DP2").setValueState("Error");
						this.getView().byId("DP2").setValueStateText("Should not blank");
					} else {
						this.getView().byId("DP2").setValueState("None");
					}
					if (startDt === "") {
						this.getView().byId("DP2_start").setValueState("Error");
						this.getView().byId("DP2_start").setValueStateText("Should not blank");
					} else {
						this.getView().byId("DP2_start").setValueState("None");
					}
					if (startDt === "In") {
						this.getView().byId("DP2_start").setValueState("Error");
						this.getView().byId("DP2_start").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
					} else {
						this.getView().byId("DP2_start").setValueState("None");
					}
					if (startDt === "In") {
						this.getView().byId("DP2").setValueState("Error");
						this.getView().byId("DP2").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
					} else {
						this.getView().byId("DP2").setValueState("None");
					}
				}

			} catch (e) {
				console.log(e);
			}

		},

		//////////////////////// open popup of own goal for project goal/////////////////////////
		owngoal_Add_proj: function(view) {
			//	view.getController().aData = [];
			try {

				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
				var dialog = this.getView().byId("OwnGoal_proj");
				//var intent = this.getView().byId("IntVal_proj").getValue();
				var wtg = this.getView().byId("wtgVal_proj").getValue();
				if (wtg !== "") {
					wtg = parseInt(wtg);
				}
				var kra = this.getView().byId("KRAVal_proj").getValue();
				var kpi = this.getView().byId("KPIVal_proj").getValue();
				var startDt = this.getView().byId("DP2_start_proj").getValue();
				//startDt = oDateFormat.format(new Date(startDt));
				var year = new Date().getFullYear();
				var statDt = new Date(year + "/04/01 00:00:00");
				var year2 = new Date().getFullYear() + 1;
				var endDt = new Date(year2 + "/03/31 00:00:00");
				if (new Date(startDt) < statDt || new Date(startDt) > endDt) {
					startDt = "In";
				}
				var targetDt = this.getView().byId("DP2_proj").getValue();
				//targetDt = oDateFormat.format(new Date(targetDt));
				if (new Date(targetDt) < statDt || new Date(targetDt) > endDt) {
					targetDt = "In";
				}

				//validation for wtg shoud not blank
				if (wtg !== "" && kra !== "" && kpi !== "" && targetDt !== "" && startDt !== "" && targetDt !== "In" && startDt !== "In") {

					if (sap.ui.getCore().index_proj !== undefined) {
						var modeldata = this.getView().byId("Proj_list").getModel().getData().modelData[sap.ui.getCore().index_proj];
						var edit_wtg = modeldata.Weightage;
						var cntwtg = 0;
						var progressBR = this.getView().byId("Proc_indicator");
						var last_wtg = progressBR.getPercentValue();
						cntwtg = (parseInt(last_wtg) - parseInt(edit_wtg)) + parseInt(wtg);
						if (cntwtg <= 100) {
							//modeldata.intent = intent;
							modeldata.KpiText = kpi;
							modeldata.KraText = kra;
							modeldata.Weightage = wtg + "%";
							modeldata.GoalSdate = startDt;
							modeldata.GoalDate = targetDt;
							modeldata.GoalName = "Own Goal";

							var dat = this.getView().byId("Proj_list").getModel().getData().modelData;
							var list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modelData: dat
							});
							list.setModel(oModel);
							var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList");
							list.bindItems("/modelData", objlist);

							//Overall Weightage calculation 
							var list_func = sap.ui.getCore().ODThis.getView().byId("Func_list");
							var list_calc = list_func.getModel().getData();
							var wtg_calc = 0;
							if (list_calc !== null) {

								list_calc = list_func.getModel().getData().modelData;
								for (var i = 0; i < list_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
								}
							}
							var list_proj_calc = list.getModel().getData().modelData;
							if (list_proj_calc !== null) {
								for (i = 0; i < list_proj_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
								}
							}
							var progressBR = this.getView().byId("Proc_indicator");
							progressBR.setDisplayValue("Overall Weightage " + wtg_calc + "%");
							progressBR.setPercentValue(wtg_calc);
							if (0 <= wtg_calc && wtg_calc <= 40) {
								progressBR.setState("Error");
							} else if (41 <= wtg_calc && wtg_calc <= 80) {
								progressBR.setState("Warning");
							} else if (81 <= wtg_calc && wtg_calc <= 100) {
								progressBR.setState("Success");
							}

							sap.ui.getCore().index_proj = undefined;
							dialog.destroy();
							dialog.close();
						} else {
							MessageToast.show("you can not add weightage more than 100");
						}
					} else {
						var cntwtg = 0;
						var progressBR = this.getView().byId("Proc_indicator");
						var last_wtg = progressBR.getPercentValue();
						cntwtg = parseInt(last_wtg) + parseInt(wtg);
						//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
						//view.getController().checkwtg();
						if (cntwtg <= 100) {
							sap.ui.getCore().flag = 0;
							var subaData = [{
								//	intent: intent,
								Weightage: wtg + "%",
								KraText: kra,
								KpiText: kpi,
								GoalSdate: startDt,
								GoalDate: targetDt,
								GoalName: "Own Goal"
							}];

							var dat = this.getView().byId("Proj_list").getModel().getData().modelData;
							dat.push(subaData[0]);
							var list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modelData: dat
							});
							list.setModel(oModel);
							var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList");
							list.bindItems("/modelData", objlist);
							//view.byId("scenariolB").addRow(row);

							//Overall Weightage calculation 
							var list_func = sap.ui.getCore().ODThis.getView().byId("Func_list");
							var list_calc = list_func.getModel().getData();
							var wtg_calc = 0;
							if (list_calc !== null) {

								list_calc = list_func.getModel().getData().modelData;
								for (var i = 0; i < list_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
								}
							}
							var list_proj_calc = list.getModel().getData().modelData;
							if (list_proj_calc !== null) {
								for (i = 0; i < list_proj_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
								}
							}
							var progressBR = this.getView().byId("Proc_indicator");
							progressBR.setDisplayValue("Overall Weightage " + wtg_calc + "%");
							progressBR.setPercentValue(wtg_calc);
							if (0 <= wtg_calc && wtg_calc <= 40) {
								progressBR.setState("Error");
							} else if (41 <= wtg_calc && wtg_calc <= 80) {
								progressBR.setState("Warning");
							} else if (81 <= wtg_calc && wtg_calc <= 100) {
								progressBR.setState("Success");
							}

							MessageToast.show('Added!');
							dialog.destroy();
							dialog.close();
						} else {
							//sap.ui.getCore().flag = 1;
							//	sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
							MessageToast.show("you can not add weightage more than 100");

						}
					}
				} else {
					if (wtg === "") {
						this.getView().byId("wtgVal_proj").setValueState("Error");
						this.getView().byId("wtgVal_proj").setValueStateText("Should not blank");
					} else {
						this.getView().byId("wtgVal_proj").setValueState("None");
					}
					if (kra === "") {
						this.getView().byId("KRAVal_proj").setValueState("Error");
						this.getView().byId("KRAVal_proj").setValueStateText("Should not blank");
					} else {
						this.getView().byId("KRAVal_proj").setValueState("None");
					}
					if (kpi === "") {
						this.getView().byId("KPIVal_proj").setValueState("Error");
						this.getView().byId("KPIVal_proj").setValueStateText("Should not blank");
					} else {
						this.getView().byId("KPIVal_proj").setValueState("None");
					}
					if (targetDt === "") {
						this.getView().byId("DP2_proj").setValueState("Error");
						this.getView().byId("DP2_proj").setValueStateText("Should not blank");
					} else {
						this.getView().byId("DP2_proj").setValueState("None");
					}
					if (startDt === "") {
						this.getView().byId("DP2_start_proj").setValueState("Error");
						this.getView().byId("DP2_start_proj").setValueStateText("Should not blank");
					} else {
						this.getView().byId("DP2_start_proj").setValueState("None");
					}
					if (startDt === "In") {
						this.getView().byId("DP2_start_proj").setValueState("Error");
						this.getView().byId("DP2_start_proj").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
					} else {
						this.getView().byId("DP2_start_proj").setValueState("None");
					}
					if (startDt === "In") {
						this.getView().byId("DP2_proj").setValueState("Error");
						this.getView().byId("DP2_proj").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
					} else {
						this.getView().byId("DP2_proj").setValueState("None");
					}
				}

			} catch (e) {
				console.log(e);
			}

		},
		Comlgoal_Add: function(view) {
			//	view.getController().aData = [];
			try {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});

				var dialog = this.getView().byId("ComplGoal");
				//	var intent = this.getView().byId("IntVal").getValue();
				var wtg = this.getView().byId("wtgVal").getValue();
				if (wtg !== "") {
					wtg = parseInt(wtg);
				}
				var kra = this.getView().byId("KRAVal").getValue();
				var kpi = this.getView().byId("KPIVal").getValue();
				var startDt = this.getView().byId("DP2_start").getValue();
				//startDt = oDateFormat.format(new Date(startDt));
				var year = new Date().getFullYear();
				var statDt = new Date(year + "/04/01 00:00:00");
				var year2 = new Date().getFullYear() + 1;
				var endDt = new Date(year2 + "/03/31 00:00:00");
				if (new Date(startDt) < statDt || new Date(startDt) > endDt) {
					startDt = "In";
				}
				var targetDt = this.getView().byId("DP2").getValue();
				//targetDt = oDateFormat.format(new Date(targetDt));
				if (new Date(targetDt) < statDt || new Date(targetDt) > endDt) {
					targetDt = "In";
				}

				//validation for wtg should not blank
				if (wtg !== "" && kra !== "" && kpi !== "" && targetDt !== "" && startDt !== "" && targetDt !== "In" && startDt !== "In") {

					if (sap.ui.getCore().index !== undefined) {
						var modeldata = this.getView().byId("Func_list").getModel().getData().modelData[sap.ui.getCore().index];
						var edit_wtg = modeldata.Weightage;
						var cntwtg = 0;
						var progressBR = this.getView().byId("Proc_indicator");
						var last_wtg = progressBR.getPercentValue();
						cntwtg = (parseInt(last_wtg) - parseInt(edit_wtg)) + parseInt(wtg);
						if (cntwtg <= 100) {
							//modeldata.intent = intent;
							modeldata.KpiText = kpi;
							modeldata.KraText = kra;
							modeldata.Weightage = wtg + "%";
							modeldata.GoalSdate = startDt;
							modeldata.GoalDate = targetDt;
							modeldata.GoalName = "Compliance Goal";

							var dat = this.getView().byId("Func_list").getModel().getData().modelData;
							var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modelData: dat
							});
							list.setModel(oModel);
							var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
							list.bindItems("/modelData", objlist);

							//Overall Weightage calculation 
							var list_calc = list.getModel().getData().modelData;
							var wtg_calc = 0;
							for (var i = 0; i < list_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
							}
							var list_proj = sap.ui.getCore().ODThis.getView().byId("Proj_list");
							var list_proj_calc = list_proj.getModel().getData();
							if (list_proj_calc !== null) {
								list_proj_calc = list_proj.getModel().getData().modelData;
								for (i = 0; i < list_proj_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
								}
							}
							var progressBR = this.getView().byId("Proc_indicator");
							progressBR.setDisplayValue("Overall Weightage " + wtg_calc + "%");
							progressBR.setPercentValue(wtg_calc);
							if (0 <= wtg_calc && wtg_calc <= 40) {
								progressBR.setState("Error");
							} else if (41 <= wtg_calc && wtg_calc <= 80) {
								progressBR.setState("Warning");
							} else if (81 <= wtg_calc && wtg_calc <= 100) {
								progressBR.setState("Success");
							}

							sap.ui.getCore().index = undefined;
							dialog.destroy();
							dialog.close();
						} else {
							MessageToast.show("you can not add weightage more than 100");
						}

					} else {
						var cntwtg = 0;
						var progressBR = this.getView().byId("Proc_indicator");
						var last_wtg = progressBR.getPercentValue();
						cntwtg = parseInt(last_wtg) + parseInt(wtg);
						//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
						//view.getController().checkwtg();
						if (cntwtg <= 100) {
							sap.ui.getCore().flag = 0;
							var subaData = [{
								//intent: intent,
								Weightage: wtg + "%",
								KraText: kra,
								KpiText: kpi,
								GoalSdate: startDt,
								GoalDate: targetDt,
								GoalName: "Compliance Goal"
							}];

							var dat = this.getView().byId("Func_list").getModel().getData().modelData;
							dat.push(subaData[0]);
							var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modelData: dat
							});
							list.setModel(oModel);
							var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
							list.bindItems("/modelData", objlist);
							//view.byId("scenariolB").addRow(row);

							//Overall Weightage calculation 
							var list_calc = list.getModel().getData().modelData;
							var wtg_calc = 0;
							for (var i = 0; i < list_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
							}
							var list_proj = sap.ui.getCore().ODThis.getView().byId("Proj_list");
							var list_proj_calc = list_proj.getModel().getData();
							if (list_proj_calc !== null) {
								list_proj_calc = list_proj.getModel().getData().modelData;
								for (i = 0; i < list_proj_calc.length; i++) {
									wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
								}
							}
							var progressBR = this.getView().byId("Proc_indicator");
							progressBR.setDisplayValue("Overall Weightage " + wtg_calc + "%");
							progressBR.setPercentValue(wtg_calc);
							if (0 <= wtg_calc && wtg_calc <= 40) {
								progressBR.setState("Error");
							} else if (41 <= wtg_calc && wtg_calc <= 80) {
								progressBR.setState("Warning");
							} else if (81 <= wtg_calc && wtg_calc <= 100) {
								progressBR.setState("Success");
							}
							MessageToast.show('Added!');
							dialog.destroy();
							dialog.close();
						} else {
							//sap.ui.getCore().flag = 1;
							//sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
							MessageToast.show("you can not add weightage more than 100");

						}
					}
				} else {
					var year = new Date().getFullYear();
					var year2 = new Date().getFullYear() + 1;
					if (wtg === "") {
						this.getView().byId("wtgVal").setValueState("Error");
						this.getView().byId("wtgVal").setValueStateText("Should not blank");
					} else {
						this.getView().byId("wtgVal").setValueState("None");
					}
					if (kra === "") {
						this.getView().byId("KRAVal").setValueState("Error");
						this.getView().byId("KRAVal").setValueStateText("Should not blank");
					} else {
						this.getView().byId("KRAVal").setValueState("None");
					}
					if (kpi === "") {
						this.getView().byId("KPIVal").setValueState("Error");
						this.getView().byId("KPIVal").setValueStateText("Should not blank");
					} else {
						this.getView().byId("KPIVal").setValueState("None");
					}
					if (targetDt === "") {
						this.getView().byId("DP2").setValueState("Error");
						this.getView().byId("DP2").setValueStateText("Should not blank");
					} else {
						this.getView().byId("DP2").setValueState("None");
					}
					if (startDt === "") {
						this.getView().byId("DP2_start").setValueState("Error");
						this.getView().byId("DP2_start").setValueStateText("Should not blank");
					} else {
						this.getView().byId("DP2_start").setValueState("None");
					}
					if (startDt === "In") {
						this.getView().byId("DP2_start").setValueState("Error");
						this.getView().byId("DP2_start").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
					} else {
						this.getView().byId("DP2_start").setValueState("None");
					}
					if (startDt === "In") {
						this.getView().byId("DP2").setValueState("Error");
						this.getView().byId("DP2").setValueStateText("Please select date from 01/04/" + year + " to 31/03/" + year2);
					} else {
						this.getView().byId("DP2").setValueState("None");
					}
				}

			} catch (e) {
				console.log(e);
			}

		},

		onCloseDialog: function() {
			var dialog = this.getView().byId("OwnGoal");
			dialog.destroy();
			dialog.close();
		},
		onCloseDialog_proj: function() {
			var dialog = this.getView().byId("OwnGoal_proj");
			dialog.destroy();
			dialog.close();
		},
		onfunc_list: function(evt) {
			var data = evt.getSource().getBindingContext().getObject();
			var oView = sap.ui.getCore().ODThis.getView();
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Owngoal", this); //14july
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			//update wtg meter inside goal popup
			var progressBR = this.getView().byId("Proc_indicator");
			var fungoal_progInd = this.getView().byId("fungoal_progInd");
			var value = progressBR.getPercentValue();
			fungoal_progInd.setDisplayValue("Overall Weightage " + value + " %");
			fungoal_progInd.setPercentValue(value);
			if (0 <= value && value <= 40) {
				fungoal_progInd.setState("Error");
			} else if (41 <= value && value <= 80) {
				fungoal_progInd.setState("Warning");
			} else if (81 <= value && value <= 100) {
				fungoal_progInd.setState("Success");
			}
			//this.getView().byId("IntVal").setValue(data.intent);
			//change popup header for edit goal
			this.getView().byId("OwnGoal").setTitle("Edit Functional Goal");

			//set other property 
			this.getView().byId("KRAVal").setValue(data.KraText);
			var wtg = data.Weightage;
			wtg = parseInt(wtg);
			this.getView().byId("wtgVal").setValue(wtg);
			this.getView().byId("DP2_start").setValue(data.GoalSdate);
			this.getView().byId("DP2").setValue(data.GoalDate);
			this.getView().byId("KPIVal").setValue(data.KpiText);
			
			var path = evt.getSource().getBindingContext().getPath();
			var index = parseInt(path.substring(path.lastIndexOf('/') + 1));
			
			//data GET for haf year employee
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} 
				}

			if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "4" && index < functionalGoals.length) {
				this.getView().byId("KRAVal").setEditable(false);
				this.getView().byId("KPIVal").setEditable(false);
				this.getView().byId("DP2_start").setEditable(false);
				this.getView().byId("DP2").setEditable(false);
			}

			var path = evt.getSource().getBindingContext().getPath();
			sap.ui.getCore().index = parseInt(path.substring(path.lastIndexOf('/') + 1));

			oDialog.open();

		},
		onproj_list: function(evt) {
			var data = evt.getSource().getBindingContext().getObject();
			var oView = sap.ui.getCore().ODThis.getView();
			var oDialog = oView.byId("OwnGoal_proj");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Owngoal_proj", this);//14ju
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			var progressBR = this.getView().byId("Proc_indicator");
			var fungoal_progInd = this.getView().byId("projgoal_progInd");
			var value = progressBR.getPercentValue();
			fungoal_progInd.setDisplayValue("Overall Weightage " + value + " %");
			fungoal_progInd.setPercentValue(value);
			if (0 <= value && value <= 40) {
				fungoal_progInd.setState("Error");
			} else if (41 <= value && value <= 80) {
				fungoal_progInd.setState("Warning");
			} else if (81 <= value && value <= 100) {
				fungoal_progInd.setState("Success");
			}
			//this.getView().byId("IntVal_proj").setValue(data.intent);

			//change popup header for edit goal
			this.getView().byId("OwnGoal_proj").setTitle("Edit Project Goal");

			this.getView().byId("KRAVal_proj").setValue(data.KraText);
			var wtg = data.Weightage;
			wtg = parseInt(wtg);
			this.getView().byId("wtgVal_proj").setValue(wtg);
			this.getView().byId("DP2_start_proj").setValue(data.GoalSdate);
			this.getView().byId("DP2_proj").setValue(data.GoalDate);
			this.getView().byId("KPIVal_proj").setValue(data.KpiText);
			
			var path = evt.getSource().getBindingContext().getPath();
			var index = parseInt(path.substring(path.lastIndexOf('/') + 1));
			
			//data GET for haf year employee
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				
			//for goal revisit logic
			if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "4" && index < projectGoals.length) {
				this.getView().byId("KRAVal_proj").setEditable(false);
				this.getView().byId("KPIVal_proj").setEditable(false);
				this.getView().byId("DP2_start_proj").setEditable(false);
				this.getView().byId("DP2_proj").setEditable(false);
			}

			var path = evt.getSource().getBindingContext().getPath();
			sap.ui.getCore().index_proj = parseInt(path.substring(path.lastIndexOf('/') + 1));

			oDialog.open();

		},
		removeFuncGol: function(evt) {
			try {
				var odatamodel = this.getView().getModel();
				var event1 = evt.getSource();
				var item = evt.getParameter('listItem');
				var dialog = new Dialog({
					title: 'Confirm',
					type: 'Message',
					contentWidth: "400px",
					content: [new sap.m.Label({
						width: "100%",
						text: "Are you sure you want to delete this goal?",
						placeholder: ""
					})],
					beginButton: new Button({
						text: 'Ok',
						press: function() {
							odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
								"%27%20and%20FiscalYear%20eq%20%27" + sap.ui.getCore().Year_Sel + "%27", null, null, false,
								function(oResponse) {
									sap.ui.getCore().GOALS = oResponse;
								});

							var item1 = sap.ui.getCore().GOALS.results.filter(function(item1) {
								if (item1.GoalId == '0001') {
									return item1;
								}
							});
							sap.ui.getCore().fungoallist = item1;
							//row deletioin code 
							var oList = event1;

							var m = oList.getModel();
							var d = m.getData();
							var modeldata = d.modelData;
							var path = item.getBindingContext().getPath();
							var index = parseInt(path.substring(path.lastIndexOf('/') + 1));
							if (sap.ui.getCore().fungoallist.length <= index) {
								var wtgDel = modeldata[index].Weightage;
								var progressBR = sap.ui.getCore().ODThis.getView().byId("Proc_indicator");
								var last_wtg = progressBR.getPercentValue();
								var updated_wtg = parseInt(last_wtg) - parseInt(wtgDel);

								progressBR.setDisplayValue("Overall Weightage " + updated_wtg + " %");
								progressBR.setPercentValue(updated_wtg);
								if (0 <= updated_wtg && updated_wtg <= 40) {
									progressBR.setState("Error");
								} else if (41 <= updated_wtg && updated_wtg <= 80) {
									progressBR.setState("Warning");
								} else if (81 <= updated_wtg && updated_wtg <= 100) {
									progressBR.setState("Success");
								}
								modeldata.splice(index, 1);
								m.setData(d);

								MessageToast.show('Removed!');
							} else {
								var GoalItemId = sap.ui.getCore().fungoallist[index].GoalItemId;
								var oModel = sap.ui.getCore().ODThis.getView().getModel();
								var FiscalYear = sap.ui.getCore().USERDATA.FiscalYear;
								oModel.remove("/ApprisalGoalsNewSet(FiscalYear='" + FiscalYear + "',EmpId='" + sap.ui.getCore().username +
									"',GoalId='0001',GoalItemId='" + GoalItemId + "')", null,
									function(data, response) {
										sap.m.MessageToast.show("Deleted successfully");
										//update progress bar 
										var wtgDel = modeldata[index].Weightage.replace('%', '');
										var progressBR = sap.ui.getCore().ODThis.getView().byId("Proc_indicator");
										var last_wtg = progressBR.getPercentValue();
										var updated_wtg = parseInt(last_wtg) - parseInt(wtgDel);

										progressBR.setDisplayValue("Overall Weightage " + updated_wtg + " %");
										progressBR.setPercentValue(updated_wtg);
										if (0 <= updated_wtg && updated_wtg <= 40) {
											progressBR.setState("Error");
										} else if (41 <= updated_wtg && updated_wtg <= 80) {
											progressBR.setState("Warning");
										} else if (81 <= updated_wtg && updated_wtg <= 100) {
											progressBR.setState("Success");
										}
										modeldata.splice(index, 1);
										m.setData(d);

										MessageToast.show('Removed!');
									},
									function(error) {
										console.log("RecAssign Update Error : Go Online");
									});
							}

							dialog.close();

						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				dialog.open();

			} catch (e) {
				console.log(e);
			}
		},
		removeProjGol: function(evt) {
			try {
				var odatamodel = this.getView().getModel();
				var event1 = evt.getSource();
				var item = evt.getParameter('listItem');
				var dialog = new Dialog({
					title: 'Confirm',
					type: 'Message',
					contentWidth: "400px",
					content: [new sap.m.Label({
						width: "100%",
						text: "Are you sure you want to delete this goal?",
						placeholder: ""
					})],
					beginButton: new Button({
						text: 'Ok',
						press: function() {
							odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
								"%27%20and%20FiscalYear%20eq%20%27" + sap.ui.getCore().Year_Sel + "%27", null, null, false,
								function(oResponse) {
									sap.ui.getCore().GOALS = oResponse;
								});
							var item1 = sap.ui.getCore().GOALS.results.filter(function(item1) {
								if (item1.GoalId == '0002') {
									return item1;
								}
							});
							sap.ui.getCore().projgoallist = item1;
							//row deletioin code 
							var oList = event1;

							var m = oList.getModel();
							var d = m.getData();
							var modeldata = d.modelData;

							var path = item.getBindingContext().getPath();
							var index = parseInt(path.substring(path.lastIndexOf('/') + 1));
							if (sap.ui.getCore().projgoallist.length <= index) {
								var wtgDel = modeldata[index].Weightage;
								var progressBR = sap.ui.getCore().ODThis.getView().byId("Proc_indicator");
								var last_wtg = progressBR.getPercentValue();
								var updated_wtg = parseInt(last_wtg) - parseInt(wtgDel);

								progressBR.setDisplayValue("Overall Weightage " + updated_wtg + " %");
								progressBR.setPercentValue(updated_wtg);
								if (0 <= updated_wtg && updated_wtg <= 40) {
									progressBR.setState("Error");
								} else if (41 <= updated_wtg && updated_wtg <= 80) {
									progressBR.setState("Warning");
								} else if (81 <= updated_wtg && updated_wtg <= 100) {
									progressBR.setState("Success");
								}
								modeldata.splice(index, 1);
								m.setData(d);

								MessageToast.show('Removed!');
							} else {
								var GoalItemId = sap.ui.getCore().projgoallist[index].GoalItemId;
								var oModel = sap.ui.getCore().ODThis.getView().getModel();
								var FiscalYear = sap.ui.getCore().USERDATA.FiscalYear;
								oModel.remove("/ApprisalGoalsNewSet(FiscalYear='" + FiscalYear + "',EmpId='" + sap.ui.getCore().username +
									"',GoalId='0002',GoalItemId='" + GoalItemId + "')", null,
									function() {
										sap.m.MessageToast.show("Deleted successfully");
										//update progress bar 
										var wtgDel = modeldata[index].Weightage.replace('%', '');
										var progressBR = sap.ui.getCore().ODThis.getView().byId("Proc_indicator");
										var last_wtg = progressBR.getPercentValue();
										var updated_wtg = parseInt(last_wtg) - parseInt(wtgDel);

										progressBR.setDisplayValue("Overall Weightage " + updated_wtg + " %");
										progressBR.setPercentValue(updated_wtg);
										if (0 <= updated_wtg && updated_wtg <= 40) {
											progressBR.setState("Error");
										} else if (41 <= updated_wtg && updated_wtg <= 80) {
											progressBR.setState("Warning");
										} else if (81 <= updated_wtg && updated_wtg <= 100) {
											progressBR.setState("Success");
										}
										modeldata.splice(index, 1);
										m.setData(d);

										MessageToast.show('Removed!');
									},
									function(error) {
										console.log("RecAssign Update Error : Go Online");
									});
							}
							dialog.close();
						}

					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				dialog.open();
			} catch (e) {
				console.log(e);
			}
		},

		handleLineItemPress_func: function(evt) {
			var data = evt.getSource().getBindingContext().getObject();

			var view = sap.ui.getCore().ODThis.getView();
			sap.ui.getCore().flag = 0;
			var dialog = new Dialog({
				title: 'Functional Goal',
				contentWidth: "550px",
				contentHeight: "300px",
				resizable: true,
				content: [
					new sap.m.Label({
						text: "Theme/Strategic Intent"
					}),
					new sap.m.Input({
						value: data.intent
					}),
					new sap.m.Label({
						text: "Weightage"
					}),
					new sap.m.Input({
						value: data.wtg
					}),
					new sap.m.Label({
						text: "KRA/Goals",
						width: "100%"
					}),
					new sap.m.TextArea({
						rows: 5,
						cols: 50,
						value: data.kra
					}),
					new sap.m.Label({
						text: "KPI/Measurment",
						width: "100%"
					}),
					new sap.m.TextArea({
						rows: 5,
						cols: 50,
						value: data.kpi
					})
				],
				beginButton: new Button({
					text: 'Edit',
					press: function() {

						view.getController().addDataToTable(view);
						if (sap.ui.getCore().flag === 0) {
							dialog.close();
						}
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			//to get access to the global model
			view.addDependent(dialog);
			dialog.open();

		},

		//check weightage count for meter
		checkwtg: function() {
			if (sap.ui.getCore().cntwtg > 100) {
				alert("you cant add weightage more than 100");
				return;
			}

		},

		onADD_Proj: function(oEvent) {
			var view = this.getView();
			sap.ui.getCore().flag = 0;
			try {
				var dialog = new Dialog({
					title: 'Project Goal',
					contentWidth: "550px",
					contentHeight: "300px",
					resizable: true,
					content: [
						new sap.m.Label({
							text: "Theme/Strategic Intent"
						}),
						new sap.m.Input("IntVal_proj", {

						}),
						new sap.m.Label({
							text: "Weightage"
						}),
						new sap.m.Input("wtgVal_proj", {
							type: "Number"
						}),
						new sap.m.Label({
							text: "KRA/Goals",
							width: "100%"
						}),
						new sap.m.TextArea("KRAVal_proj", {
							rows: 5,
							cols: 50
						}),
						new sap.m.Label({
							text: "KPI/Measurment",
							width: "100%"
						}),
						new sap.m.TextArea("KPIVal_proj", {
							rows: 5,
							cols: 50
						})
					],
					beginButton: new Button({
						text: 'Ok',
						press: function() {

							view.getController().addDataToTable_proj(view);
							if (sap.ui.getCore().flag === 0) {
								dialog.close();
							}
						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				//to get access to the global model
				this.getView().addDependent(dialog);
				dialog.open();
			} catch (e) {
				console.log(e);
			}
		},
		addDataToTable_proj: function(view) {

			//	view.getController().aData = [];
			var intent = sap.ui.getCore().byId("IntVal_proj").getValue();
			var wtg = sap.ui.getCore().byId("wtgVal_proj").getValue();
			var kra = sap.ui.getCore().byId("KRAVal_proj").getValue();
			var kpi = sap.ui.getCore().byId("KPIVal_proj").getValue();
			sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) + parseInt(wtg);
			//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
			//view.getController().checkwtg();
			if (sap.ui.getCore().cntwtg <= 100) {
				sap.ui.getCore().flag = 0;
				var subaData = [{
					intent: intent,
					wtg: wtg,
					kra: kra,
					kpi: kpi

				}];

				var dat = view.getController().aData_proj;
				dat.push(subaData[0]);
				var oTable = view.byId("PrjGLTbl");
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: dat
				});
				oTable.setModel(oModel);
				var template = new sap.m.ColumnListItem({
					type: "Navigation",

					cells: [
						new sap.m.Label({
							text: "{intent}"
						}),
						new sap.m.Label({
							text: "{wtg}"
						}),
						new sap.m.TextArea({
							value: "{kra}"
						}),
						new sap.m.TextArea({
							value: "{kpi}"
						})/*,
						new sap.m.Button({
							icon: "sap-icon://delete",
							text: "",
							press: view.getController().removeprojGol

						})*/
					]
				});
				oTable.bindItems("/modelData", template);
				//view.byId("scenariolB").addRow(row);
				var progressBR = this.getView().byId("Proc_indicator");
				progressBR.setDisplayValue("Overall Weightage " + sap.ui.getCore().cntwtg + " %");
				progressBR.setPercentValue(sap.ui.getCore().cntwtg);
				if (0 <= sap.ui.getCore().cntwtg && sap.ui.getCore().cntwtg <= 40) {
					progressBR.setState("Error");
				} else if (41 <= sap.ui.getCore().cntwtg && sap.ui.getCore().cntwtg <= 80) {
					progressBR.setState("Warning");
				} else if (81 <= sap.ui.getCore().cntwtg && sap.ui.getCore().cntwtg <= 100) {
					progressBR.setState("Success");
				}
				MessageToast.show('Added!');
			} else {
				sap.ui.getCore().flag = 1;
				sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
				MessageToast.show("you can not add weightage more than 100");

			}

		},
		submitforAPR: function() {
			var progressBR = this.getView().byId("Proc_indicator");
			var wtg = progressBR.getPercentValue();
			if (wtg !== 100) {
				MessageToast.show("Please ensure overall weightage is 100%");
			}
		},
		onNavBack: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("_Login");

		},
		onsavetemp: function() {
			var oModel = this.getView().getModel();
			sap.ui.getCore().BatchOprAll = new Array();
			var _POSTCONTEXT = "ApprisalGoalsNewSet";
			var POSTENTRY = {
				EmpId: "P00003061",
				GoalId: "0001",
				GoalItemId: "0007",
				GoalName: "P00003061",
				Weightage: "10",
				KraText: "kra",
				KpiText: "kpi",
				GoalDate: null,
				StatusField: ""

			};
			var POSTENTRY1 = {
				EmpId: "P00003061",
				GoalId: "0001",
				GoalItemId: "0008",
				GoalName: "P00003061",
				Weightage: "10",
				KraText: "kra",
				KpiText: "kpi",
				GoalDate: null,
				StatusField: ""

			};
			sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY));
			sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY1));

			console.log(sap.ui.getCore().BatchOprAll);
			oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
			//oModel.addBatchReadOperations("PARAM_DET");

			oModel.submitBatch(function(data) {
				//oModel.refresh();
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageToast.show("Saved Successfully");
				if (data.__batchResponses[0].__changeResponses) {
					sap.m.MessageToast.show("Saved Successfully");
					jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
				} else {
					jQuery.sap.log.info(data.__batchResponses[0].message);
				}

			}, function(err) {
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageToast.show("A connection with the server could not be established");
				jQuery.sap.log.info("Error occurred", err);
			});
		},
	/*	onsave_batch: function() {
			//this.showBusyIndicator(20000, 0);

			//this.getView().setBusy(true);
			//sap.ui.core.BusyIndicator.show(0);
			if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});

				var func_list = sap.ui.getCore().ODThis.getView().byId("Func_list");
				var data = func_list.getModel().getData().modelData;

				var proj_list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var data_proj = proj_list.getModel().getData().modelData;

				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();

				odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
					"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false,
					function(oResponse) {
						sap.ui.getCore().GOALS = oResponse;
					});
				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}

				var Alcount = odata.length;
				var cnt = odata.length;
				for (i = 0; i < data.length; i++) {
					var kra = data[i].KraText;
					var kpi = data[i].KpiText;
					var wtg = data[i].Weightage;
					wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = data[i].GoalDate;
					var GoalName = data[i].GoalName;
					var temp = GoalDate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalDate = temp[2] + "-" + mnth + "-" + temp[0];
					if (GoalDate !== null && GoalDate !== "") {
						GoalDate = new Date(GoalDate);
					}
					var GoalSdate = data[i].GoalSdate;
					var temp = GoalSdate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
					if (GoalSdate !== null && GoalSdate !== "") {
						GoalSdate = new Date(GoalSdate);
					}
					//GoalDate = oDateFormat.format(GoalDate);
					if (Alcount >= 1) {
						flag = 1;
						Alcount--;
					} else {
						flag = 0;
						cnt++;
					}
					if (flag === 0) {

						var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0001",
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalItemId: "" + cnt,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

					} else {

						var GoalItemId = odata[idcnt].GoalItemId;

						var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0001",
							GoalItemId: GoalItemId,
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0001',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

						idcnt++;
					}

				}

				//project goals save logic
				var idcnt = 0;
				var Alcount_proj = odata_proj.length;
				var cnt_proj = odata_proj.length;
				for (i = 0; i < data_proj.length; i++) {
					kra = data_proj[i].KraText;
					kpi = data_proj[i].KpiText;
					wtg = data_proj[i].Weightage;
					wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = data_proj[i].GoalName;
					GoalDate = data_proj[i].GoalDate;
					var temp = GoalDate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalDate = temp[2] + "-" + mnth + "-" + temp[0];

					if (GoalDate !== null && GoalDate !== "") {
						GoalDate = new Date(GoalDate);
					}
					var GoalSdate = data_proj[i].GoalSdate;
					var temp = GoalSdate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
					if (GoalSdate !== null && GoalSdate !== "") {
						GoalSdate = new Date(GoalSdate);
					}
					//GoalDate = oDateFormat.format(GoalDate);
					if (Alcount_proj >= 1) {
						flag = 1;
						Alcount_proj--;
					} else {
						flag = 0;
						cnt_proj++;
					}
					if (flag === 0) {

						var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0002",
							GoalItemId: "" + cnt_proj,
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

					} else {

						var GoalItemId = odata_proj[idcnt].GoalItemId;
						var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0002",
							GoalItemId: GoalItemId,
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0002',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

						idcnt++;
					}

				}

				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established");
					jQuery.sap.log.info("Error occurred", err);
				});
				
				
				// if(sap.ui.getCore().SAVEFLAG === 1){
				// 	sap.m.MessageToast.show("Please check network connectivity");
				// }else{
				// 	sap.m.MessageToast.show("Saved successfully");
				// }
			} else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
				this.getView().getController().half_year_save();
			}else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "4") {
				
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});

				var func_list = sap.ui.getCore().ODThis.getView().byId("Func_list");
				var data = func_list.getModel().getData().modelData;

				var proj_list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
				var data_proj = proj_list.getModel().getData().modelData;

				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();

				odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
					"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false,
					function(oResponse) {
						sap.ui.getCore().GOALS = oResponse;
					});
				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}

				var Alcount = odata.length;
				var cnt = odata.length;
				for (i = 0; i < data.length; i++) {
					var kra = data[i].KraText;
					var kpi = data[i].KpiText;
					var wtg = data[i].Weightage;
					wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = data[i].GoalDate;
					var GoalName = data[i].GoalName;
					var temp = GoalDate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalDate = temp[2] + "-" + mnth + "-" + temp[0];
					if (GoalDate !== null && GoalDate !== "") {
						GoalDate = new Date(GoalDate);
					}
					var GoalSdate = data[i].GoalSdate;
					var temp = GoalSdate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
					if (GoalSdate !== null && GoalSdate !== "") {
						GoalSdate = new Date(GoalSdate);
					}
					//GoalDate = oDateFormat.format(GoalDate);
					if (Alcount >= 1) {
						flag = 1;
						Alcount--;
					} else {
						flag = 0;
						cnt++;
					}
					if (flag === 0) {

						var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0001",
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalItemId: "" + cnt,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,
							HyrEmpTxt : "",
							HyrFbkTxt : "",
							AnnSlfTxt : "",
							OvrAchTxt : "",
							PrtAppTxt : "",
							SthFbkTxt : "",
							AnnLp1Txt : "",
							PftLp1Txt : "",
							RvwRevTxt : "",
							PftLp2Txt : "",
							FinAppTxt : "",
							PntFctTxt : "",
							ArcFbkTxt : "",
							KraVal : "",
							WeightVal : "",
							KpiVal : "",
							HyrEmpVal : "",
							HyrFbkVal : "",
							AnnSlfVal : "",
							OvrAchVal : "",
							PrtAppVal : "",
							SthFbkVal : "",
							AnnLp1Val : "",
							PftLp1Val : "",
							RvwRevVal : "",
							PftLp2Val : "",
							FinAppVal : "",
							PntFctVal : "",
							ArcFbkVal : "",
							WEIGHT_DAT : "",
							KPI_DAT : "",
							HYR_EMP_DAT : "",
							KRA_DAT : "",
							HYR_FBK_DAT : "",
							ANN_SLF_DAT : "",
							OVR_ACH_DAT : "",
							PRT_APP_DAT : "",
							STH_FBK_DAT : "",
							ANN_LP1_DAT : "",
							PFT_LP1_DAT : "",
							RVW_REV_DAT : "",
							PFT_LP2_DAT : "",
							FIN_APP_DAT : "",
							PNT_FCT_DAT : "",
							ARC_FBK_DAT : ""

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

					} else {

						var GoalItemId = odata[idcnt].GoalItemId;

						var POSTENTRY = {
							// EmpId: sap.ui.getCore().username,
							// GoalId: "0001",
							// GoalItemId: GoalItemId,
							// FiscalYear: ""+sap.ui.getCore().Year_Sel+"",
							// EmpCode: user_Data.EmpCode,
							// GoalName: GoalName,
							Weightage: wtg
							// KraText: kra,
							// KpiText: kpi,
							// GoalDate: GoalDate,
							// GoalSdate: GoalSdate,
							// HyrEmpTxt : odata[idcnt].HyrEmpTxt,
							// HyrFbkTxt : odata[idcnt].HyrFbkTxt,
							// AnnSlfTxt : odata[idcnt].AnnSlfTxt,
							// OvrAchTxt : odata[idcnt].OvrAchTxt,
							// PrtAppTxt : odata[idcnt].PrtAppTxt,
							// SthFbkTxt : odata[idcnt].SthFbkTxt,
							// AnnLp1Txt : odata[idcnt].AnnLp1Txt,
							// PftLp1Txt : odata[idcnt].PftLp1Txt,
							// RvwRevTxt : odata[idcnt].RvwRevTxt,
							// PftLp2Txt : odata[idcnt].PftLp2Txt,
							// FinAppTxt : odata[idcnt].FinAppTxt,
							// PntFctTxt : odata[idcnt].PntFctTxt,
							// ArcFbkTxt : odata[idcnt].ArcFbkTxt,
							// KraVal : odata[idcnt].KraVal,
							// WeightVal : odata[idcnt].WeightVal,
							// KpiVal : odata[idcnt].KpiVal,
							// HyrEmpVal : odata[idcnt].HyrEmpVal,
							// HyrFbkVal : odata[idcnt].HyrFbkVal,
							// AnnSlfVal : odata[idcnt].AnnSlfVal,
							// OvrAchVal : odata[idcnt].OvrAchVal,
							// PrtAppVal : odata[idcnt].PrtAppVal,
							// SthFbkVal : odata[idcnt].SthFbkVal,
							// AnnLp1Val : odata[idcnt].AnnLp1Val,
							// PftLp1Val : odata[idcnt].PftLp1Val,
							// RvwRevVal : odata[idcnt].RvwRevVal,
							// PftLp2Val : odata[idcnt].PftLp2Val,
							// FinAppVal : odata[idcnt].FinAppVal,
							// PntFctVal : odata[idcnt].PntFctVal,
							// ArcFbkVal : odata[idcnt].ArcFbkVal
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0001',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

						idcnt++;
					}

				}

				//project goals save logic
				var idcnt = 0;
				var Alcount_proj = odata_proj.length;
				var cnt_proj = odata_proj.length;
				for (i = 0; i < data_proj.length; i++) {
					kra = data_proj[i].KraText;
					kpi = data_proj[i].KpiText;
					wtg = data_proj[i].Weightage;
					wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = data_proj[i].GoalName;
					GoalDate = data_proj[i].GoalDate;
					var temp = GoalDate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalDate = temp[2] + "-" + mnth + "-" + temp[0];

					if (GoalDate !== null && GoalDate !== "") {
						GoalDate = new Date(GoalDate);
					}
					var GoalSdate = data_proj[i].GoalSdate;
					var temp = GoalSdate.split("-");
					var mnth;
					if (temp[1] === "Jan") {
						mnth = "01";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Feb") {
						mnth = "02";
					} else if (temp[1] === "Mar") {
						mnth = "03";
					} else if (temp[1] === "Apr") {
						mnth = "04";
					} else if (temp[1] === "May") {
						mnth = "05";
					} else if (temp[1] === "Jun") {
						mnth = "06";
					} else if (temp[1] === "Jul") {
						mnth = "07";
					} else if (temp[1] === "Aug") {
						mnth = "08";
					} else if (temp[1] === "Sep") {
						mnth = "09";
					} else if (temp[1] === "Oct") {
						mnth = "10";
					} else if (temp[1] === "Nov") {
						mnth = "11";
					} else if (temp[1] === "Dec") {
						mnth = "12";
					}
					GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
					if (GoalSdate !== null && GoalSdate !== "") {
						GoalSdate = new Date(GoalSdate);
					}
					//GoalDate = oDateFormat.format(GoalDate);
					if (Alcount_proj >= 1) {
						flag = 1;
						Alcount_proj--;
					} else {
						flag = 0;
						cnt_proj++;
					}
					if (flag === 0) {

						var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0002",
							GoalItemId: "" + cnt_proj,
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,
							HyrEmpTxt : "",
							HyrFbkTxt : "",
							AnnSlfTxt : "",
							OvrAchTxt : "",
							PrtAppTxt : "",
							SthFbkTxt : "",
							AnnLp1Txt : "",
							PftLp1Txt : "",
							RvwRevTxt : "",
							PftLp2Txt : "",
							FinAppTxt : "",
							PntFctTxt : "",
							ArcFbkTxt : "",
							KraVal : "",
							WeightVal : "",
							KpiVal : "",
							HyrEmpVal : "",
							HyrFbkVal : "",
							AnnSlfVal : "",
							OvrAchVal : "",
							PrtAppVal : "",
							SthFbkVal : "",
							AnnLp1Val : "",
							PftLp1Val : "",
							RvwRevVal : "",
							PftLp2Val : "",
							FinAppVal : "",
							PntFctVal : "",
							ArcFbkVal : "",
							WEIGHT_DAT : "",
							KPI_DAT : "",
							HYR_EMP_DAT : "",
							KRA_DAT : "",
							HYR_FBK_DAT : "",
							ANN_SLF_DAT : "",
							OVR_ACH_DAT : "",
							PRT_APP_DAT : "",
							STH_FBK_DAT : "",
							ANN_LP1_DAT : "",
							PFT_LP1_DAT : "",
							RVW_REV_DAT : "",
							PFT_LP2_DAT : "",
							FIN_APP_DAT : "",
							PNT_FCT_DAT : "",
							ARC_FBK_DAT : ""

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

					} else {

						var GoalItemId = odata_proj[idcnt].GoalItemId;
						var POSTENTRY = {
							// EmpId: sap.ui.getCore().username,
							// GoalId: "0002",
							// GoalItemId: GoalItemId,
							// FiscalYear: ""+sap.ui.getCore().Year_Sel+"",
							// EmpCode: user_Data.EmpCode,
							// GoalName: GoalName,
							Weightage: wtg
							// KraText: kra,
							// KpiText: kpi,
							// GoalDate: GoalDate,
							// GoalSdate: GoalSdate,
							// HyrEmpTxt : odata_proj[idcnt].HyrEmpTxt,
							// HyrFbkTxt : odata_proj[idcnt].HyrFbkTxt,
							// AnnSlfTxt : odata_proj[idcnt].AnnSlfTxt,
							// OvrAchTxt : odata_proj[idcnt].OvrAchTxt,
							// PrtAppTxt : odata_proj[idcnt].PrtAppTxt,
							// SthFbkTxt : odata_proj[idcnt].SthFbkTxt,
							// AnnLp1Txt : odata_proj[idcnt].AnnLp1Txt,
							// PftLp1Txt : odata_proj[idcnt].PftLp1Txt,
							// RvwRevTxt : odata_proj[idcnt].RvwRevTxt,
							// PftLp2Txt : odata_proj[idcnt].PftLp2Txt,
							// FinAppTxt : odata_proj[idcnt].FinAppTxt,
							// PntFctTxt : odata_proj[idcnt].PntFctTxt,
							// ArcFbkTxt : odata_proj[idcnt].ArcFbkTxt,
							// KraVal : odata_proj[idcnt].KraVal,
							// WeightVal : odata_proj[idcnt].WeightVal,
							// KpiVal : odata_proj[idcnt].KpiVal,
							// HyrEmpVal : odata_proj[idcnt].HyrEmpVal,
							// HyrFbkVal : odata_proj[idcnt].HyrFbkVal,
							// AnnSlfVal : odata_proj[idcnt].AnnSlfVal,
							// OvrAchVal : odata_proj[idcnt].OvrAchVal,
							// PrtAppVal : odata_proj[idcnt].PrtAppVal,
							// SthFbkVal : odata_proj[idcnt].SthFbkVal,
							// AnnLp1Val : odata_proj[idcnt].AnnLp1Val,
							// PftLp1Val : odata_proj[idcnt].PftLp1Val,
							// RvwRevVal : odata_proj[idcnt].RvwRevVal,
							// PftLp2Val : odata_proj[idcnt].PftLp2Val,
							// FinAppVal : odata_proj[idcnt].FinAppVal,
							// PntFctVal : odata_proj[idcnt].PntFctVal,
							// ArcFbkVal : odata_proj[idcnt].ArcFbkVal

						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0002',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

						idcnt++;
					}

				}

				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established");
					jQuery.sap.log.info("Error occurred", err);
				});
				// if(sap.ui.getCore().SAVEFLAG === 1){
				// 	sap.m.MessageToast.show("Please check network connectivity");
				// }else{
				// 	sap.m.MessageToast.show("Saved successfully");
				// }
			
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "6"){
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});


				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();
				
				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}
				var GoDate_Ann = oDateformat_half.format(new Date());
				for (i = 0; i < odata.length; i++) {
					var kra = odata[i].KraText;
					var kpi = odata[i].KpiText;
					var wtg = odata[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = odata[i].GoalDate;
					var GoalName = odata[i].GoalName;
					var AnnEmpTxt = sap.ui.getCore().byId("Goalset--Annual_timelineText_EMP-Goalset--Func_list-" + i).getValue();
					var GoalSdate = odata[i].GoalSdate;

						var GoalItemId = odata[i].GoalItemId;
						

						var POSTENTRY = {
							AnnSlfTxt : AnnEmpTxt,
							ANN_SLF_DAT : GoDate_Ann
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel +"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}

				//project goals save logic
				var idcnt = 0;
				for (i = 0; i < odata_proj.length; i++) {
					kra = odata_proj[i].KraText;
					kpi = odata_proj[i].KpiText;
					wtg = odata_proj[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = odata_proj[i].GoalName;
					GoalDate = odata_proj[i].GoalDate;
					var AnnEmpTxt_proj = sap.ui.getCore().byId("Goalset--Annual_timelineText_proj_EMP-Goalset--Proj_list-" + i).getValue();
					var GoalSdate = odata_proj[i].GoalSdate;

						var GoalItemId = odata_proj[i].GoalItemId;
						var POSTENTRY = {
							AnnSlfTxt : AnnEmpTxt_proj,
							ANN_SLF_DAT : GoDate_Ann
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel +"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}
				
				//over all assetment comment saving
			var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";
			 var OVRL_Ann_EMP =  sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_EMP").getValue();
			 
					var Ann_EMP_date = oDateformat_half.format(new Date());
				
			 var POSTENTRY = {
				OvrAchTxt : OVRL_Ann_EMP,
				OVR_ACH_DAT : Ann_EMP_date
			 };
			 sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));


				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.m.MessageToast.show("A connection with the server could not be established"+err.message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established"+err.message);
					jQuery.sap.log.info("Error occurred", err);
				});
			
		
			}
			else if (sap.ui.getCore().USERDATA.ApStatus == "4" && sap.ui.getCore().USERDATA.ApStatusSub == "2"){
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});


				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();
				
				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}
				var GoDate_Ann = oDateformat_half.format(new Date());
				for (i = 0; i < odata.length; i++) {
					var kra = odata[i].KraText;
					var kpi = odata[i].KpiText;
					var wtg = odata[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = odata[i].GoalDate;
					var GoalName = odata[i].GoalName;
					var AnnL1Txt = sap.ui.getCore().byId("Goalset--Annual_timelineText_mngrcmnt-Goalset--Func_list-" + i).getValue();
					var GoalSdate = odata[i].GoalSdate;

						var GoalItemId = odata[i].GoalItemId;
						

						var POSTENTRY = {
							AnnLp1Txt : AnnL1Txt,
							ANN_LP1_DAT : GoDate_Ann
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel +"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}

				//project goals save logic
				var idcnt = 0;
				for (i = 0; i < odata_proj.length; i++) {
					kra = odata_proj[i].KraText;
					kpi = odata_proj[i].KpiText;
					wtg = odata_proj[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = odata_proj[i].GoalName;
					GoalDate = odata_proj[i].GoalDate;
					var AnnL1Txt_proj = sap.ui.getCore().byId("Goalset--Annual_timelineText_proj_mngrcmnt-Goalset--Proj_list-" + i).getValue();
					var GoalSdate = odata_proj[i].GoalSdate;

						var GoalItemId = odata_proj[i].GoalItemId;
						var POSTENTRY = {
							AnnLp1Txt : AnnL1Txt_proj,
							ANN_LP1_DAT : GoDate_Ann
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel +"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}
				
				//over all assetment comment saving
			var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";
			 var OVRL_Ann_L1 =  sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_mngr").getValue();
			 
					var Ann_L1_date = oDateformat_half.format(new Date());
				
			 var POSTENTRY = {
				AnnLp1Txt : OVRL_Ann_L1,
				ANN_LP1_DAT : Ann_L1_date
			 };
			 sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));


				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.m.MessageToast.show("A connection with the server could not be established"+err.message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established"+err.message);
					jQuery.sap.log.info("Error occurred", err);
				});
			
		
			}

		},*/

		// onsave: function() {
		// 	//this.showBusyIndicator(20000, 0);
		// 	//this.getView().setBusy(true);
		// 	//sap.ui.core.BusyIndicator.show(0);
		// 	if(sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == ""){
		// 	var that = this;
		// 	sap.ui.getCore().SAVEFLAG = 0;
		// 	var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
		// 		pattern: "yyyy-MM-dd"
		// 	});

		// 	var func_list = sap.ui.getCore().ODThis.getView().byId("Func_list");
		// 	var data = func_list.getModel().getData().modelData;

		// 	var proj_list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
		// 	var data_proj = proj_list.getModel().getData().modelData;

		// 	sap.ui.getCore().BatchOprAll = new Array();
		// 	var oModel = this.getView().getModel();
		// 	var _POSTCONTEXT = "ApprisalGoalsNewSet";

		// 	var odatamodel = this.getView().getModel();

		// 	odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
		// 		"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false,
		// 		function(oResponse) {
		// 			sap.ui.getCore().GOALS = oResponse;
		// 		});

		// 	var user_Data = sap.ui.getCore().USERDATA;

		// 	var flag = 0;

		// 	var j = 0;
		// 	var k = 0;
		// 	var odata = new Array();
		// 	var odata_proj = new Array();
		// 	var goal_data = sap.ui.getCore().GOALS.results;
		// 	var idcnt = 0;

		// 	for (var i = 0; i < goal_data.length; i++) {
		// 		if (goal_data[i].GoalId === '0001') {
		// 			odata[j] = goal_data[i];
		// 			j++;
		// 		}
		// 	}
		// 	for (i = 0; i < goal_data.length; i++) {
		// 		if (goal_data[i].GoalId === '0002') {
		// 			odata_proj[k] = goal_data[i];
		// 			k++;
		// 		}
		// 	}

		// 	var Alcount = odata.length;
		// 	var cnt = odata.length;
		// 	for (i = 0; i < data.length; i++) {
		// 		var kra = data[i].KraText;
		// 		var kpi = data[i].KpiText;
		// 		var wtg = data[i].Weightage;
		// 		wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
		// 		var GoalDate = data[i].GoalDate;
		// 		var GoalName = data[i].GoalName;
		// 		var temp = GoalDate.split("-");
		// 		var mnth;
		// 		if (temp[1] === "Jan") {
		// 			mnth = "01";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Mar") {
		// 			mnth = "03";
		// 		} else if (temp[1] === "Apr") {
		// 			mnth = "04";
		// 		} else if (temp[1] === "May") {
		// 			mnth = "05";
		// 		} else if (temp[1] === "Jun") {
		// 			mnth = "06";
		// 		} else if (temp[1] === "Jul") {
		// 			mnth = "07";
		// 		} else if (temp[1] === "Aug") {
		// 			mnth = "08";
		// 		} else if (temp[1] === "Sep") {
		// 			mnth = "09";
		// 		} else if (temp[1] === "Oct") {
		// 			mnth = "10";
		// 		} else if (temp[1] === "Nov") {
		// 			mnth = "11";
		// 		} else if (temp[1] === "Dec") {
		// 			mnth = "12";
		// 		}
		// 		GoalDate = temp[2] + "-" + mnth + "-" + temp[0];
		// 		if (GoalDate !== null && GoalDate !== "") {
		// 			GoalDate = new Date(GoalDate);
		// 		}
		// 		var GoalSdate = data[i].GoalSdate;
		// 		var temp = GoalSdate.split("-");
		// 		var mnth;
		// 		if (temp[1] === "Jan") {
		// 			mnth = "01";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Mar") {
		// 			mnth = "03";
		// 		} else if (temp[1] === "Apr") {
		// 			mnth = "04";
		// 		} else if (temp[1] === "May") {
		// 			mnth = "05";
		// 		} else if (temp[1] === "Jun") {
		// 			mnth = "06";
		// 		} else if (temp[1] === "Jul") {
		// 			mnth = "07";
		// 		} else if (temp[1] === "Aug") {
		// 			mnth = "08";
		// 		} else if (temp[1] === "Sep") {
		// 			mnth = "09";
		// 		} else if (temp[1] === "Oct") {
		// 			mnth = "10";
		// 		} else if (temp[1] === "Nov") {
		// 			mnth = "11";
		// 		} else if (temp[1] === "Dec") {
		// 			mnth = "12";
		// 		}
		// 		GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
		// 		if (GoalSdate !== null && GoalSdate !== "") {
		// 			GoalSdate = new Date(GoalSdate);
		// 		}
		// 		//GoalDate = oDateFormat.format(GoalDate);
		// 		if (Alcount >= 1) {
		// 			flag = 1;
		// 			Alcount--;
		// 		} else {
		// 			flag = 0;
		// 			cnt++;
		// 		}
		// 		if (flag === 0) {

		// 			var POSTENTRY = {
		// 				EmpId: sap.ui.getCore().username,
		// 				GoalId: "0001",
		// 				FiscalYear: sap.ui.getCore().Year_Sel,
		// 				EmpCode: user_Data.EmpCode,
		// 				GoalItemId: "" + cnt,
		// 				GoalName: GoalName,
		// 				Weightage: wtg,
		// 				KraText: kra,
		// 				KpiText: kpi,
		// 				GoalDate: GoalDate,
		// 				GoalSdate: GoalSdate

		// 			};
		// 			//sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY)); 
		// 			oModel.create(_POSTCONTEXT, POSTENTRY, null, function() {
		// 				//sap.m.MessageToast.show("Saved successfully");

		// 			}, function(error) {
		// 				sap.ui.getCore().SAVEFLAG = 1;
		// 				console.log(error.message);
		// 				//sap.ui.getCore().ordersThis.showAlert(error.message);

		// 				//	alert("Update Failed");
		// 			});
		// 		} else {

		// 			var GoalItemId = odata[idcnt].GoalItemId;

		// 			var POSTENTRY = {
		// 				EmpId: sap.ui.getCore().username,
		// 				GoalId: "0001",
		// 				GoalItemId: GoalItemId,
		// 				FiscalYear: sap.ui.getCore().Year_Sel,
		// 				EmpCode: user_Data.EmpCode,
		// 				GoalName: GoalName,
		// 				Weightage: wtg,
		// 				KraText: kra,
		// 				KpiText: kpi,
		// 				GoalDate: GoalDate,
		// 				GoalSdate: GoalSdate

		// 			};
		// 			//sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT+"(EmpId='"+sap.ui.getCore().username+"',GoalId='0001',GoalItemId='"+GoalItemId+"')", "PUT", POSTENTRY));
		// 			oModel.update(_POSTCONTEXT + "(FiscalYear='"+sap.ui.getCore().Year_Sel+"',EmpId='" + sap.ui.getCore().username + "',GoalId='0001',GoalItemId='" +
		// 				GoalItemId + "')", POSTENTRY, null,
		// 				function() {
		// 					//sap.m.MessageToast.show("Saved successfully");

		// 				},
		// 				function(error) {

		// 					alert("Please check your network connectivity");
		// 						sap.ui.getCore().SAVEFLAG = 1;
		// 				});
		// 			idcnt++;
		// 		}

		// 	}

		// 	//project goals save logic
		// 	var idcnt = 0;
		// 	var Alcount_proj = odata_proj.length;
		// 	var cnt_proj = odata_proj.length;
		// 	for (i = 0; i < data_proj.length; i++) {
		// 		kra = data_proj[i].KraText;
		// 		kpi = data_proj[i].KpiText;
		// 		wtg = data_proj[i].Weightage;
		// 		wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
		// 		var GoalName = data_proj[i].GoalName;
		// 		GoalDate = data_proj[i].GoalDate;
		// 		var temp = GoalDate.split("-");
		// 		var mnth;
		// 		if (temp[1] === "Jan") {
		// 			mnth = "01";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Mar") {
		// 			mnth = "03";
		// 		} else if (temp[1] === "Apr") {
		// 			mnth = "04";
		// 		} else if (temp[1] === "May") {
		// 			mnth = "05";
		// 		} else if (temp[1] === "Jun") {
		// 			mnth = "06";
		// 		} else if (temp[1] === "Jul") {
		// 			mnth = "07";
		// 		} else if (temp[1] === "Aug") {
		// 			mnth = "08";
		// 		} else if (temp[1] === "Sep") {
		// 			mnth = "09";
		// 		} else if (temp[1] === "Oct") {
		// 			mnth = "10";
		// 		} else if (temp[1] === "Nov") {
		// 			mnth = "11";
		// 		} else if (temp[1] === "Dec") {
		// 			mnth = "12";
		// 		}
		// 		GoalDate = temp[2] + "-" + mnth + "-" + temp[0];

		// 		if (GoalDate !== null && GoalDate !== "") {
		// 			GoalDate = new Date(GoalDate);
		// 		}
		// 		var GoalSdate = data_proj[i].GoalSdate;
		// 		var temp = GoalSdate.split("-");
		// 		var mnth;
		// 		if (temp[1] === "Jan") {
		// 			mnth = "01";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Feb") {
		// 			mnth = "02";
		// 		} else if (temp[1] === "Mar") {
		// 			mnth = "03";
		// 		} else if (temp[1] === "Apr") {
		// 			mnth = "04";
		// 		} else if (temp[1] === "May") {
		// 			mnth = "05";
		// 		} else if (temp[1] === "Jun") {
		// 			mnth = "06";
		// 		} else if (temp[1] === "Jul") {
		// 			mnth = "07";
		// 		} else if (temp[1] === "Aug") {
		// 			mnth = "08";
		// 		} else if (temp[1] === "Sep") {
		// 			mnth = "09";
		// 		} else if (temp[1] === "Oct") {
		// 			mnth = "10";
		// 		} else if (temp[1] === "Nov") {
		// 			mnth = "11";
		// 		} else if (temp[1] === "Dec") {
		// 			mnth = "12";
		// 		}
		// 		GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
		// 		if (GoalSdate !== null && GoalSdate !== "") {
		// 			GoalSdate = new Date(GoalSdate);
		// 		}
		// 		//GoalDate = oDateFormat.format(GoalDate);
		// 		if (Alcount_proj >= 1) {
		// 			flag = 1;
		// 			Alcount_proj--;
		// 		} else {
		// 			flag = 0;
		// 			cnt_proj++;
		// 		}
		// 		if (flag === 0) {

		// 			var POSTENTRY = {
		// 				EmpId: sap.ui.getCore().username,
		// 				GoalId: "0002",
		// 				GoalItemId: "" + cnt_proj,
		// 				FiscalYear: sap.ui.getCore().Year_Sel,
		// 				EmpCode: user_Data.EmpCode,
		// 				GoalName: GoalName,
		// 				Weightage: wtg,
		// 				KraText: kra,
		// 				KpiText: kpi,
		// 				GoalDate: GoalDate,
		// 				GoalSdate: GoalSdate

		// 			};
		// 			//sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY));
		// 			oModel.create(_POSTCONTEXT, POSTENTRY, null, function() {
		// 				that.getView().setBusy(false);
		// 				//sap.m.MessageToast.show("Saved successfully");

		// 			}, function(error) {
		// 				that.getView().setBusy(false);
		// 				sap.ui.getCore().SAVEFLAG = 1;
		// 				console.log(error.message);
		// 				//sap.ui.getCore().ordersThis.showAlert(error.message);

		// 				//	alert("Update Failed");
		// 			});
		// 		} else {

		// 			var GoalItemId = odata_proj[idcnt].GoalItemId;
		// 			var POSTENTRY = {
		// 				EmpId: sap.ui.getCore().username,
		// 				GoalId: "0002",
		// 				GoalItemId: GoalItemId,
		// 				FiscalYear: sap.ui.getCore().Year_Sel,
		// 				EmpCode: user_Data.EmpCode,
		// 				GoalName: GoalName,
		// 				Weightage: wtg,
		// 				KraText: kra,
		// 				KpiText: kpi,
		// 				GoalDate: GoalDate,
		// 				GoalSdate: GoalSdate

		// 			};
		// 			oModel.update(_POSTCONTEXT + "(FiscalYear='"+sap.ui.getCore().Year_Sel+"',EmpId='" + sap.ui.getCore().username + "',GoalId='0002',GoalItemId='" +
		// 				GoalItemId + "')", POSTENTRY, null,
		// 				function() {
		// 					that.getView().setBusy(false);
		// 					//sap.m.MessageToast.show("Saved successfully");

		// 				},
		// 				function(error) {
		// 					that.getView().setBusy(false);
		// 					sap.ui.getCore().SAVEFLAG = 1;
		// 					console.log("Network issue");
		// 				});
		// 			idcnt++;
		// 		}

		// 	}

		// 	sap.ui.core.BusyIndicator.hide();

		// 	if(sap.ui.getCore().SAVEFLAG === 1){
		// 		sap.m.MessageToast.show("Please check network connectivity");
		// 	}else{
		// 		sap.m.MessageToast.show("Saved successfully");
		// 	}
		// 	}
		// 	else if(sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == ""){
		// 		this.getView().getController().half_year_save();
		// 	}
		// },
		Perfor_path_Update: function() {
			var userInfo = sap.ui.getCore().USERDATA;
			if (userInfo.ApStatus === "2" && userInfo.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
							id: "0",
							icon: "sap-icon://accept",
							label: "Goal Setting",
							position: 0,
							state: [{
								state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
								value: 10
							}]
						}, {
							id: "1",
							icon: "sap-icon://hr-approval",
							label: "Goal Approval",
							position: 1,
							state: [{
								state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
								value: 10
							}]
						}, {
							id: "2",
							icon: "sap-icon://survey",
							label: "Half Yearly",
							position: 2
						},
						//, {
						// 	id: "3",
						// 	icon: "sap-icon://activity-assigned-to-goal",
						// 	label: "Goal Revisit",
						// 	position: 3
						// }, {
						// 	id: "4",
						// 	icon: "sap-icon://hr-approval",
						// 	label: "Goal Approval",
						// 	position: 4
						// }, 
						{
							id: "6",
							icon: "sap-icon://approvals",
							label: "Annual Review",
							position: 3
						}, {
							id: "7",
							icon: "sap-icon://monitor-payments",
							label: "ARC",
							position: 4
						}, {
							id: "8",
							icon: "sap-icon://signature",
							label: "Final Sign Off",
							position: 5
						}
					]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			}
		},
		onsubmit: function() {
			try {
				//sap.ui.core.UIComponent.getRouterFor(this).navTo("_AfterSubmit",{});
				if (sap.ui.getCore().USERDATA.ApStatus == "2" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
					var progressBR = this.getView().byId("Proc_indicator");
					var curr_wtg = progressBR.getPercentValue();
					if (parseInt(curr_wtg) === 100) {
						var that = this;
						//this.onsave_batch();
						var UserData = sap.ui.getCore().USERDATA;
						var oModel = this.getView().getModel();
						
						///////////////////////// save before submit /////////////////////////////////////

						//this.showBusyIndicator(20000, 0);

						//this.getView().setBusy(true);
						//sap.ui.core.BusyIndicator.show(0);

						var that = this;
						sap.ui.getCore().SAVEFLAG = 0;
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyy-MM-dd"
						});

						var func_list = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var data = func_list.getModel().getData().modelData;

						var proj_list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
						var data_proj = proj_list.getModel().getData().modelData;

						sap.ui.getCore().BatchOprAll = new Array();
						var oModel = this.getView().getModel();
						var _POSTCONTEXT = "ApprisalGoalsNewSet";

						var odatamodel = this.getView().getModel();

						odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
							"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false,
							function(oResponse) {
								sap.ui.getCore().GOALS = oResponse;
							});
						this.showBusyIndicator(20000, 0);
						var user_Data = sap.ui.getCore().USERDATA;

						var flag = 0;

						var j = 0;
						var k = 0;
						var odata = new Array();
						var odata_proj = new Array();
						var goal_data = sap.ui.getCore().GOALS.results;
						var idcnt = 0;

						for (var i = 0; i < goal_data.length; i++) {
							if (goal_data[i].GoalId === '0001') {
								odata[j] = goal_data[i];
								j++;
							}
						}
						for (i = 0; i < goal_data.length; i++) {
							if (goal_data[i].GoalId === '0002') {
								odata_proj[k] = goal_data[i];
								k++;
							}
						}

						var Alcount = odata.length;
						var cnt = odata.length;
						for (i = 0; i < data.length; i++) {
							var kra = data[i].KraText;
							var kpi = data[i].KpiText;
							var wtg = data[i].Weightage;
							wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
							var GoalDate = data[i].GoalDate;
							var GoalName = data[i].GoalName;
							var temp = GoalDate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalDate = temp[2] + "-" + mnth + "-" + temp[0];
							if (GoalDate !== null && GoalDate !== "") {
								GoalDate = new Date(GoalDate);
							}
							var GoalSdate = data[i].GoalSdate;
							var temp = GoalSdate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
							if (GoalSdate !== null && GoalSdate !== "") {
								GoalSdate = new Date(GoalSdate);
							}
							//GoalDate = oDateFormat.format(GoalDate);
							if (Alcount >= 1) {
								flag = 1;
								Alcount--;
							} else {
								flag = 0;
								cnt++;
							}
							if (flag === 0) {

								var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0001",
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalItemId: "" + cnt,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,
							HyrEmpTxt : "",
							HyrFbkTxt : "",
							AnnSlfTxt : "",
							OvrAchTxt : "",
							PrtAppTxt : "",
							SthFbkTxt : "",
							AnnLp1Txt : "",
							PftLp1Txt : "",
							RvwRevTxt : "",
							PftLp2Txt : "",
							FinAppTxt : "",
							PntFctTxt : "",
							ArcFbkTxt : "",
							KraVal : "",
							WeightVal : "",
							KpiVal : "",
							HyrEmpVal : "",
							HyrFbkVal : "",
							AnnSlfVal : "",
							OvrAchVal : "",
							PrtAppVal : "",
							SthFbkVal : "",
							AnnLp1Val : "",
							PftLp1Val : "",
							RvwRevVal : "",
							PftLp2Val : "",
							FinAppVal : "",
							PntFctVal : "",
							ArcFbkVal : ""

						};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

							} else {

								var GoalItemId = odata[idcnt].GoalItemId;

								var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0001",
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalItemId: "" + cnt,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,
							HyrEmpTxt : "",
							HyrFbkTxt : "",
							AnnSlfTxt : "",
							OvrAchTxt : "",
							PrtAppTxt : "",
							SthFbkTxt : "",
							AnnLp1Txt : "",
							PftLp1Txt : "",
							RvwRevTxt : "",
							PftLp2Txt : "",
							FinAppTxt : "",
							PntFctTxt : "",
							ArcFbkTxt : "",
							KraVal : "",
							WeightVal : "",
							KpiVal : "",
							HyrEmpVal : "",
							HyrFbkVal : "",
							AnnSlfVal : "",
							OvrAchVal : "",
							PrtAppVal : "",
							SthFbkVal : "",
							AnnLp1Val : "",
							PftLp1Val : "",
							RvwRevVal : "",
							PftLp2Val : "",
							FinAppVal : "",
							PntFctVal : "",
							ArcFbkVal : ""

						};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
									"',GoalId='0001',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

								idcnt++;
							}

						}

						//project goals save logic
						var idcnt = 0;
						var Alcount_proj = odata_proj.length;
						var cnt_proj = odata_proj.length;
						for (i = 0; i < data_proj.length; i++) {
							kra = data_proj[i].KraText;
							kpi = data_proj[i].KpiText;
							wtg = data_proj[i].Weightage;
							wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
							var GoalName = data_proj[i].GoalName;
							GoalDate = data_proj[i].GoalDate;
							var temp = GoalDate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalDate = temp[2] + "-" + mnth + "-" + temp[0];

							if (GoalDate !== null && GoalDate !== "") {
								GoalDate = new Date(GoalDate);
							}
							var GoalSdate = data_proj[i].GoalSdate;
							var temp = GoalSdate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
							if (GoalSdate !== null && GoalSdate !== "") {
								GoalSdate = new Date(GoalSdate);
							}
							//GoalDate = oDateFormat.format(GoalDate);
							if (Alcount_proj >= 1) {
								flag = 1;
								Alcount_proj--;
							} else {
								flag = 0;
								cnt_proj++;
							}
							if (flag === 0) {

								var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0002",
							GoalItemId: "" + cnt_proj,
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,
							HyrEmpTxt : "",
							HyrFbkTxt : "",
							AnnSlfTxt : "",
							OvrAchTxt : "",
							PrtAppTxt : "",
							SthFbkTxt : "",
							AnnLp1Txt : "",
							PftLp1Txt : "",
							RvwRevTxt : "",
							PftLp2Txt : "",
							FinAppTxt : "",
							PntFctTxt : "",
							ArcFbkTxt : "",
							KraVal : "",
							WeightVal : "",
							KpiVal : "",
							HyrEmpVal : "",
							HyrFbkVal : "",
							AnnSlfVal : "",
							OvrAchVal : "",
							PrtAppVal : "",
							SthFbkVal : "",
							AnnLp1Val : "",
							PftLp1Val : "",
							RvwRevVal : "",
							PftLp2Val : "",
							FinAppVal : "",
							PntFctVal : "",
							ArcFbkVal : ""

						};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

							} else {

								var GoalItemId = odata_proj[idcnt].GoalItemId;
								var POSTENTRY = {
							EmpId: sap.ui.getCore().username,
							GoalId: "0002",
							GoalItemId: "" + cnt_proj,
							FiscalYear: ""+sap.ui.getCore().Year_Sel,
							EmpCode: user_Data.EmpCode,
							GoalName: GoalName,
							Weightage: wtg,
							KraText: kra,
							KpiText: kpi,
							GoalDate: GoalDate,
							GoalSdate: GoalSdate,
							HyrEmpTxt : "",
							HyrFbkTxt : "",
							AnnSlfTxt : "",
							OvrAchTxt : "",
							PrtAppTxt : "",
							SthFbkTxt : "",
							AnnLp1Txt : "",
							PftLp1Txt : "",
							RvwRevTxt : "",
							PftLp2Txt : "",
							FinAppTxt : "",
							PntFctTxt : "",
							ArcFbkTxt : "",
							KraVal : "",
							WeightVal : "",
							KpiVal : "",
							HyrEmpVal : "",
							HyrFbkVal : "",
							AnnSlfVal : "",
							OvrAchVal : "",
							PrtAppVal : "",
							SthFbkVal : "",
							AnnLp1Val : "",
							PftLp1Val : "",
							RvwRevVal : "",
							PftLp2Val : "",
							FinAppVal : "",
							PntFctVal : "",
							ArcFbkVal : ""

						};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
									"',GoalId='0002',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

								idcnt++;
							}

						}

						//////////////////////// save end before submit ////////////////////////////////////

						console.log(sap.ui.getCore().BatchOprAll);
						oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
						//oModel.addBatchReadOperations("PARAM_DET");
						oModel.setUseBatch(true);
						oModel.submitBatch(function(data) {
							oModel.refresh();

							//sap.m.MessageToast.show("Saved Successfully");
							if (data.__batchResponses[0].__changeResponses) {
								sap.ui.core.BusyIndicator.hide();
								//sap.m.MessageToast.show("Submit sucessfully");

								sap.m.MessageToast.show("Submitted Sucessfully for approval");
								var _UPDATESTATUS = "EmployeeStatusSet";

						var POSTENTRY = {
							"EmpCode": UserData.EmpCode,
							"FiscalYear": UserData.FiscalYear,
							"ActionFlag": "A",
							"EmpId": UserData.EmpId,
							"ActionComments": ""

						};

						oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')",
							POSTENTRY,
							null,
							function() {

							},
							function(error) {
								/*if (sap.ui.getCore().checkConnection) {
									sap.OData.removeHttpClient();
								}*/
								console.log("not saved" + error);
							});
								var a = that.getView().byId("func_ObjList");
								var b = that.getView().byId("proj_ObjList");
								var a1 = that.getView().byId("Func_list");
								var b1 = that.getView().byId("Proj_list");
								a.setType("Inactive");
								b.setType("Inactive");
								a1.setMode("None");
								b1.setMode("None");

								//disable save and submit button
								/*that.getView().byId("btn_save_goalSet").setEnabled(false);*/
							/*	that.getView().byId("btn_submit_GoalSet").setEnabled(false);*/
							/*	that.getView().byId("openMenu").setEnabled(false);
								that.getView().byId("GOAL_LIB").setEnabled(false);*/

								that.getView().getController().Perfor_path_Update();

								sap.ui.core.UIComponent.getRouterFor(that).navTo("_AfterSubmit", {});
							} else {
								//sap.m.MessageToast.show("Please check network connection");
								jQuery.sap.log.info(data.__batchResponses[0].message);
								sap.ui.core.BusyIndicator.hide();
							}
						}, function(err) {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show("A connection with the server could not be established");
							jQuery.sap.log.info("Error occurred", err);
						});
						
						

					} else {
						MessageToast.show("Weights for this section should add up to 100. Currently they add up to " + curr_wtg);
					}
				} else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
					this.getView().getController().half_year_submit();
				}else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "4") {
					this.getView().getController().goal_rivisit_EMP_submit();
				}else if (sap.ui.getCore().USERDATA.ApStatus == "3" && sap.ui.getCore().USERDATA.ApStatusSub == "6") {
					this.getView().getController().Ann_Self_EMP_submit();
				}else if (sap.ui.getCore().USERDATA.ApStatus == "5" && sap.ui.getCore().USERDATA.ApStatusSub == "") {
					this.getView().getController().Ann_Complete_submit();
				}
			} catch (e) {
				console.log(e);
			}
		},
		goal_rivisit_EMP_submit:function(){
			
					var progressBR = this.getView().byId("Proc_indicator");
					var curr_wtg = progressBR.getPercentValue();
					if (parseInt(curr_wtg) === 100) {
						var that = this;
						//this.onsave_batch();
						var UserData = sap.ui.getCore().USERDATA;
						var oModel = this.getView().getModel();
						
						///////////////////////// save before submit /////////////////////////////////////

						//this.showBusyIndicator(20000, 0);

						//this.getView().setBusy(true);
						//sap.ui.core.BusyIndicator.show(0);

						var that = this;
						sap.ui.getCore().SAVEFLAG = 0;
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "yyyy-MM-dd"
						});

						var func_list = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var data = func_list.getModel().getData().modelData;

						var proj_list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
						var data_proj = proj_list.getModel().getData().modelData;

						sap.ui.getCore().BatchOprAll = new Array();
						var oModel = this.getView().getModel();
						var _POSTCONTEXT = "ApprisalGoalsNewSet";

						var odatamodel = this.getView().getModel();

						odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username +
							"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false,
							function(oResponse) {
								sap.ui.getCore().GOALS = oResponse;
							});
						this.showBusyIndicator(20000, 0);
						var user_Data = sap.ui.getCore().USERDATA;

						var flag = 0;

						var j = 0;
						var k = 0;
						var odata = new Array();
						var odata_proj = new Array();
						var goal_data = sap.ui.getCore().GOALS.results;
						var idcnt = 0;

						for (var i = 0; i < goal_data.length; i++) {
							if (goal_data[i].GoalId === '0001') {
								odata[j] = goal_data[i];
								j++;
							}
						}
						for (i = 0; i < goal_data.length; i++) {
							if (goal_data[i].GoalId === '0002') {
								odata_proj[k] = goal_data[i];
								k++;
							}
						}

						var Alcount = odata.length;
						var cnt = odata.length;
						for (i = 0; i < data.length; i++) {
							var kra = data[i].KraText;
							var kpi = data[i].KpiText;
							var wtg = data[i].Weightage;
							wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
							var GoalDate = data[i].GoalDate;
							var GoalName = data[i].GoalName;
							var temp = GoalDate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalDate = temp[2] + "-" + mnth + "-" + temp[0];
							if (GoalDate !== null && GoalDate !== "") {
								GoalDate = new Date(GoalDate);
							}
							var GoalSdate = data[i].GoalSdate;
							var temp = GoalSdate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
							if (GoalSdate !== null && GoalSdate !== "") {
								GoalSdate = new Date(GoalSdate);
							}
							//GoalDate = oDateFormat.format(GoalDate);
							if (Alcount >= 1) {
								flag = 1;
								Alcount--;
							} else {
								flag = 0;
								cnt++;
							}
							if (flag === 0) {

								var POSTENTRY = {
									EmpId: sap.ui.getCore().username,
									GoalId: "0001",
									FiscalYear: ""+sap.ui.getCore().Year_Sel,
									EmpCode: user_Data.EmpCode,
									GoalItemId: "" + cnt,
									GoalName: GoalName,
									Weightage: wtg,
									KraText: kra,
									KpiText: kpi,
									GoalDate: GoalDate,
									GoalSdate: GoalSdate

								};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

							} else {

								var GoalItemId = odata[idcnt].GoalItemId;

								var POSTENTRY = {
									EmpId: sap.ui.getCore().username,
									GoalId: "0001",
									GoalItemId: GoalItemId,
									FiscalYear: ""+sap.ui.getCore().Year_Sel,
									EmpCode: user_Data.EmpCode,
									GoalName: GoalName,
									Weightage: wtg,
									KraText: kra,
									KpiText: kpi,
									GoalDate: GoalDate,
									GoalSdate: GoalSdate

								};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
									"',GoalId='0001',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

								idcnt++;
							}

						}

						//project goals save logic
						var idcnt = 0;
						var Alcount_proj = odata_proj.length;
						var cnt_proj = odata_proj.length;
						for (i = 0; i < data_proj.length; i++) {
							kra = data_proj[i].KraText;
							kpi = data_proj[i].KpiText;
							wtg = data_proj[i].Weightage;
							wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
							var GoalName = data_proj[i].GoalName;
							GoalDate = data_proj[i].GoalDate;
							var temp = GoalDate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalDate = temp[2] + "-" + mnth + "-" + temp[0];

							if (GoalDate !== null && GoalDate !== "") {
								GoalDate = new Date(GoalDate);
							}
							var GoalSdate = data_proj[i].GoalSdate;
							var temp = GoalSdate.split("-");
							var mnth;
							if (temp[1] === "Jan") {
								mnth = "01";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Feb") {
								mnth = "02";
							} else if (temp[1] === "Mar") {
								mnth = "03";
							} else if (temp[1] === "Apr") {
								mnth = "04";
							} else if (temp[1] === "May") {
								mnth = "05";
							} else if (temp[1] === "Jun") {
								mnth = "06";
							} else if (temp[1] === "Jul") {
								mnth = "07";
							} else if (temp[1] === "Aug") {
								mnth = "08";
							} else if (temp[1] === "Sep") {
								mnth = "09";
							} else if (temp[1] === "Oct") {
								mnth = "10";
							} else if (temp[1] === "Nov") {
								mnth = "11";
							} else if (temp[1] === "Dec") {
								mnth = "12";
							}
							GoalSdate = temp[2] + "-" + mnth + "-" + temp[0];
							if (GoalSdate !== null && GoalSdate !== "") {
								GoalSdate = new Date(GoalSdate);
							}
							//GoalDate = oDateFormat.format(GoalDate);
							if (Alcount_proj >= 1) {
								flag = 1;
								Alcount_proj--;
							} else {
								flag = 0;
								cnt_proj++;
							}
							if (flag === 0) {

								var POSTENTRY = {
									EmpId: sap.ui.getCore().username,
									GoalId: "0002",
									GoalItemId: "" + cnt_proj,
									FiscalYear: ""+sap.ui.getCore().Year_Sel,
									EmpCode: user_Data.EmpCode,
									GoalName: GoalName,
									Weightage: wtg,
									KraText: kra,
									KpiText: kpi,
									GoalDate: GoalDate,
									GoalSdate: GoalSdate

								};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY, null));

							} else {

								var GoalItemId = odata_proj[idcnt].GoalItemId;
								var POSTENTRY = {
									EmpId: sap.ui.getCore().username,
									GoalId: "0002",
									GoalItemId: GoalItemId,
									FiscalYear: ""+sap.ui.getCore().Year_Sel,
									EmpCode: user_Data.EmpCode,
									GoalName: GoalName,
									Weightage: wtg,
									KraText: kra,
									KpiText: kpi,
									GoalDate: GoalDate,
									GoalSdate: GoalSdate

								};
								sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
									"',GoalId='0002',FiscalYear='"+sap.ui.getCore().Year_Sel+"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

								idcnt++;
							}

						}

						//////////////////////// save end before submit ////////////////////////////////////

						console.log(sap.ui.getCore().BatchOprAll);
						oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
						//oModel.addBatchReadOperations("PARAM_DET");
						oModel.setUseBatch(true);
						oModel.submitBatch(function(data) {
							oModel.refresh();

							//sap.m.MessageToast.show("Saved Successfully");
							if (data.__batchResponses[0].__changeResponses) {
								
								//sap.m.MessageToast.show("Submit sucessfully");

								sap.m.MessageToast.show("Submitted Sucessfully for approval");
								var a = that.getView().byId("func_ObjList");
								var b = that.getView().byId("proj_ObjList");
								var a1 = that.getView().byId("Func_list");
								var b1 = that.getView().byId("Proj_list");
								a.setType("Inactive");
								b.setType("Inactive");
								a1.setMode("None");
								b1.setMode("None");

								//disable save and submit button
							/*	that.getView().byId("btn_save_goalSet").setEnabled(false);*/
							/*	that.getView().byId("btn_submit_GoalSet").setEnabled(false);*/
							/*	that.getView().byId("openMenu").setEnabled(false);
								that.getView().byId("GOAL_LIB").setEnabled(false);*/

								that.getView().getController().Perfor_path_Update();
								
								var _UPDATESTATUS = "EmployeeStatusSet";

						var POSTENTRY = {
							"EmpCode": UserData.EmpCode,
							"FiscalYear": UserData.FiscalYear,
							"ActionFlag": "A",
							"EmpId": UserData.EmpId,
							"ActionComments": ""

						};

						oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')",
							POSTENTRY,
							null,
							function() {
								sap.ui.core.BusyIndicator.hide();
								sap.ui.core.UIComponent.getRouterFor(that).navTo("_AfterSubmit", {});
							},
							function(error) {
								/*if (sap.ui.getCore().checkConnection) {
									sap.OData.removeHttpClient();
								}*/
								console.log("not saved" + error);
							});

								

								//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
							} else {
								//sap.m.MessageToast.show("Please check network connection");
								jQuery.sap.log.info(data.__batchResponses[0].message);
								sap.ui.core.BusyIndicator.hide();
							}
						}, function(err) {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show("A connection with the server could not be established");
							jQuery.sap.log.info("Error occurred", err);
						});

					} else {
						MessageToast.show("Weights for this section should add up to 100. Currently they add up to " + curr_wtg);
					}
				
		},
		Ann_Self_EMP_submit: function(){
			
			
			var goals = sap.ui.getCore().GOALS.results;
			var functionalGoals = [];
			var projectGoals = [];
			var that = this;
			for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0001') {
					functionalGoals.push(goals[i]);
				} else if (goals[i].GoalId === '0002') {
					projectGoals.push(goals[i]);
				}
			}
			var flag = 1;
			for (var i = 0; i < functionalGoals.length; i++) {
				//get timeline text area text
				var TextVal = sap.ui.getCore().byId("Goalset--Annual_timelineText_EMP-Goalset--Func_list-" + i).getValue();
				if (TextVal == "" || TextVal == " ") {
					flag = 0;
				}
			}
			for (var i = 0; i < projectGoals.length; i++) {
				//get timeline text area text
				var TextVal = sap.ui.getCore().byId("Goalset--Annual_timelineText_proj_EMP-Goalset--Proj_list-" + i).getValue();
				if (TextVal == "" || TextVal == " ") {
					flag = 0;
				}
				//sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Proj_list-"+i).setDateTime(new Date());
				//sap.ui.getCore().byId("Goalset--_idTimelineItem-Goalset--Func_list-"+i).setUserName(sap.ui.getCore().USERDATA.EmpName);
			}
			var Ann_Ovr_EMP = sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_EMP").getValue();
			if(Ann_Ovr_EMP == "" || Ann_Ovr_EMP == " "){
				flag = 0;
			}
			if (flag === 0) {
				//MessageToast.show("Half Yearly assessment not done for goal Own Goal.");
				sap.m.MessageBox.error("Annual self assessment not done for goal.");
			}

			else{
				
				var that = this;
						//this.onsave_batch();
						var UserData = sap.ui.getCore().USERDATA;
						var oModel = this.getView().getModel();
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});


				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();
				
				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}
				var GoDate_Ann = oDateformat_half.format(new Date());
				for (i = 0; i < odata.length; i++) {
					var kra = odata[i].KraText;
					var kpi = odata[i].KpiText;
					var wtg = odata[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = odata[i].GoalDate;
					var GoalName = odata[i].GoalName;
					var AnnEmpTxt = sap.ui.getCore().byId("Goalset--Annual_timelineText_EMP-Goalset--Func_list-" + i).getValue();
					var GoalSdate = odata[i].GoalSdate;

						var GoalItemId = odata[i].GoalItemId;
						

						var POSTENTRY = {
							AnnSlfTxt : AnnEmpTxt,
							ANN_SLF_DAT : GoDate_Ann
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel +"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}

				//project goals save logic
				var idcnt = 0;
				for (i = 0; i < odata_proj.length; i++) {
					kra = odata_proj[i].KraText;
					kpi = odata_proj[i].KpiText;
					wtg = odata_proj[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = odata_proj[i].GoalName;
					GoalDate = odata_proj[i].GoalDate;
					var AnnEmpTxt_proj = sap.ui.getCore().byId("Goalset--Annual_timelineText_proj_EMP-Goalset--Proj_list-" + i).getValue();
					var GoalSdate = odata_proj[i].GoalSdate;

						var GoalItemId = odata_proj[i].GoalItemId;
						var POSTENTRY = {
							AnnSlfTxt : AnnEmpTxt_proj,
							ANN_SLF_DAT : GoDate_Ann
						};
						sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + sap.ui.getCore().username +
							"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel +"',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}
				
				//over all assetment comment saving
			var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";
			 var OVRL_Ann_EMP =  sap.ui.getCore().byId("Goalset--Annual_overAllCMNT_EMP").getValue();
			 
					var Ann_EMP_date = oDateformat_half.format(new Date());
				
			 var POSTENTRY = {
				OvrAchTxt : OVRL_Ann_EMP,
				OVR_ACH_DAT : Ann_EMP_date
			 };
			 sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));


				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						
						sap.m.MessageToast.show("Saved Successfully");
						var _UPDATESTATUS = "EmployeeStatusSet";

						var POSTENTRY = {
							"EmpCode": UserData.EmpCode,
							"FiscalYear": UserData.FiscalYear,
							"ActionFlag": "A",
							"EmpId": UserData.EmpId,
							"ActionComments": ""

						};

						oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')",
							POSTENTRY,
							null,
							function() {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("Submitted Sucessfully for approval");
								sap.ui.core.UIComponent.getRouterFor(that).navTo("_AfterSubmit", {});
							},
							function(oError) {
								var aa = JSON.parse(oError.response.body);
					
								alert("Error "+aa.error.message.value);
								sap.ui.core.BusyIndicator.hide();
							});

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.m.MessageToast.show("A connection with the server could not be established"+err.message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established"+err.message);
					jQuery.sap.log.info("Error occurred", err);
				});
			}
		
		},
		Ann_Complete_submit:function(){
			var that = this;
				var selectedkey = this.getView().byId("_Radio_grp_FNSIGN").getSelectedIndex();
				if (selectedkey === 0) {
				var Comp_cmnt = this.getView().byId("Fin_Sign").getValue();
					//user status update
					var UserData = sap.ui.getCore().USERDATA;
					var oModel = this.getView().getModel();
					var _UPDATESTATUS = "EmployeeStatusSet";

					var POSTENTRY = {
						"EmpCode": UserData.EmpCode,
						"FiscalYear": UserData.FiscalYear,
						"ActionFlag": "A",
						"EmpId": UserData.EmpId,
						"ActionComments": Comp_cmnt

					};
					oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
						null,
						function() {
							sap.m.MessageToast.show("Submitted successfully");
							sap.ui.core.UIComponent.getRouterFor(that).navTo("_AfterSubmit", {});
						},
						function(error) {
							/*if (sap.ui.getCore().checkConnection) {
								sap.OData.removeHttpClient();
							}*/
							console.log("Approve Error");
						});
				}else{
					
				var Comp_cmnt = this.getView().byId("Fin_Sign").getValue();
					//user status update
					var UserData = sap.ui.getCore().USERDATA;
					var oModel = this.getView().getModel();
					var _UPDATESTATUS = "EmployeeStatusSet";

					var POSTENTRY = {
						"EmpCode": UserData.EmpCode,
						"FiscalYear": UserData.FiscalYear,
						"ActionFlag": "R",
						"EmpId": UserData.EmpId,
						"ActionComments": Comp_cmnt

					};
					oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
						null,
						function() {
							sap.m.MessageToast.show("Submitted successfully");
							sap.ui.core.UIComponent.getRouterFor(that).navTo("_AfterSubmit", {});
						},
						function(error) {
							/*if (sap.ui.getCore().checkConnection) {
								sap.OData.removeHttpClient();
							}*/
							console.log("Approve Error");
						});
				
				}
					
				
				
		},
		handle_fun_score: function(oEvent) {
			var oView = sap.ui.getCore().ODThis.getView();

			var oDialog = oView.byId("ScoreCard");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Score_Card", this);//14july
				var oTable = this.getView().byId("treeTable");

				var oModel = new sap.ui.model.json.JSONModel({
					useBatch: true
				});
				sap.ui.getCore().ScoreCardTree.results[0].PARENT_NODE_ID = null;
				var res = this.group(sap.ui.getCore().ScoreCardTree.results);
				sap.ui.getCore().ScoreCardTreeset = res;
				oModel.setData({
					items: res
				});
				oTable.setModel(oModel);

				var score_head = this.getView().byId("Goalset--Score_header").mAggregations.label;
				score_head.setText(sap.ui.getCore().scorecard_header);
				this.getView().byId("ScoreCard").setTitle(sap.ui.getCore().mnu_score);
				this.getView().byId("btn_scr_save").setText(sap.ui.getCore().save_btn);
				this.getView().byId("btn_scr_cancel").setText(sap.ui.getCore().cancel_btn);

				oView.addDependent(oDialog);
			}

			oDialog.open();
		},
		group: function(arr) {
			var t = {};
			for (var i = 0; i < arr.length; i++) {
				if (!arr[i].NODE_ID) { //'object found without id!'
					sap.m.MessageToast.show("object found without id!");
				}
				t[arr[i].NODE_ID] = arr[i];
			}
			var result = [];
			for (var i = 0; i < arr.length; i++) {
				if (!arr[i].PARENT_NODE_ID) {
					result.push(arr[i]);
				} else {
					var parent = t[arr[i].PARENT_NODE_ID];
					if (!parent) {
						sap.m.MessageToast.show("parent with id " + arr[i].PARENT_NODE_ID + " not found!");
					}
					var items = parent.items;
					if (!items) {
						items = [];
						parent.items = items;
					}
					items.push(arr[i]);
				}
			}
			return result;
		},
		onrowchange: function(oEvent) {
			var a = oEvent.getSource();
			var b = a.getRows()[oEvent.getParameters().rowIndex];
			var c = b.getCells()[0].getText();
			var nodeid;
			for (var i = 0; i < sap.ui.getCore().ScoreCardTree.results.length; i++) {
				if (sap.ui.getCore().ScoreCardTree.results[i].NODE_TEXT === c) {
					nodeid = sap.ui.getCore().ScoreCardTree.results[i].NODE_ID;
				}
			}
			var item = sap.ui.getCore().ScoreCardGoalSet.results.filter(function(item) {
				if (item.PARENT_NODE_ID == nodeid) {
					return item;
				}
			});

			var pnl = this.getView().byId("pnlResp");
			var tblresp = sap.ui.getCore().byId("tblRespScore");
			if (tblresp != undefined) {
				sap.ui.getCore().byId("tblRespScore").destroy();
			}
			var oTable1 = new sap.m.Table({
				id: "tblRespScore",
				headerText: "Respective Scorecard",
				width: "auto",
				layout: "ResponsiveGridLayout",
				fixedLayout: false,
				showSeparators: "All",
				mode: "MultiSelect"
			}).addStyleClass("tblmrgin score");
			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "45%",
				header: new sap.m.Label({
					text: "KRA/Goals",
					design: "Bold"
				})
			}));

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "45%",
				header: new sap.m.Label({
					text: "KPI/Measurement",
					design: "Bold"
				})
			}));

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "10%",
				header: new sap.m.Label({
					text: "Weightage(%)",
					design: "Bold"
				})
			}));
			var oModel100 = new sap.ui.model.json.JSONModel();
			oModel100.setData({
				modelData100: item
			});
			oTable1.bindItems("/modelData100", new sap.m.ColumnListItem({
				cells: [new sap.m.Text({
						text: "{KPA_TEXT}"
					}).addStyleClass("txttbl"),
					new sap.m.Text({
						text: "{KPI_TEXT}"
					}).addStyleClass("txttbl"),
					new sap.m.Text({
						text: '{WEIGHTAGE}'
					})
				]
			}));
			oTable1.setModel(oModel100);

			//change launguage 
			oTable1.setHeaderText(sap.ui.getCore().scorecard_tbl_header);

			oTable1.placeAt(pnl);
		},
		GoalLib_Add_proj: function() {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var otable = this.getView().byId("tblGoalLib");
			var arr = otable.getSelectedIndices();
			sap.ui.getCore().gollibScore = [];
			for (var i = 0; i < arr.length; i++) {
				sap.ui.getCore().gollibScore.push(otable.getModel().getData().items[arr[i]]);
			}

			var dat = this.getView().byId("Func_list").getModel().getData().modelData;
			sap.ui.getCore().ODThis.getView().getController().aData = dat;
			var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
			var oModel = new sap.ui.model.json.JSONModel();
			var dt = sap.ui.getCore().ODThis.getView().getController().aData;
			var year = new Date().getFullYear();
			var statDt = new Date(year + "/04/01");
			var year2 = new Date().getFullYear() + 1;
			var endDt = new Date(year2 + "/03/31");
			var tempwtg = 0;
			for (var ii = 0; ii < sap.ui.getCore().gollibScore.length; ii++) {
				var wtg = sap.ui.getCore().gollibScore[ii].Weightage;
				tempwtg = parseInt(tempwtg) + parseInt(wtg);
			}
			//weightage meter logic
		/*	var cntwtg = 0;
			var edit_wtg = tempwtg;
			var progressBR = this.getView().byId("Proc_indicator");
			var last_wtg = progressBR.getPercentValue();

			cntwtg = parseInt(tempwtg) + parseInt(last_wtg);
			if (cntwtg <= 100) {
				for (var ii = 0; ii < sap.ui.getCore().gollibScore.length; ii++) {
					var wtg = sap.ui.getCore().gollibScore[ii].Weightage;

					dt.push({
						"EmpId": "",
						"GoalId": "",
						"GoalItemId": "",
						"GoalName": "Own Goal",
						"Weightage": wtg + "%",
						"KraText": sap.ui.getCore().gollibScore[ii].KraText,
						"KpiText": sap.ui.getCore().gollibScore[ii].KpiText,
						"GoalDate": oDateFormat.format(endDt),
						"GoalSdate": oDateFormat.format(statDt)
					});
				}

				oModel.setData({
					modelData: dt
				});
				list.setModel(oModel);
				var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
				list.bindItems("/modelData", objlist);
				//update wtg meter 
				var progressBR = this.getView().byId("Proc_indicator");
				progressBR.setDisplayValue("Overall Weightage " + cntwtg + "%");
				progressBR.setPercentValue(cntwtg);
				if (0 <= cntwtg && cntwtg <= 40) {
					progressBR.setState("Error");
				} else if (41 <= cntwtg && cntwtg <= 80) {
					progressBR.setState("Warning");
				} else if (81 <= cntwtg && cntwtg <= 100) {
					progressBR.setState("Success");
				}

				var dialog = this.getView().byId("GoalLib");
				dialog.destroy();
				dialog.close();
			} else {
				MessageToast.show("you can not add weightage more than 100");
			}*/
			
		},
		ScoreCard_Add_proj: function() {

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var otable = sap.ui.getCore().byId("tblRespScore");
			var abc = otable.getSelectedContextPaths();
			var arr = [];
			var cnt = 0;
			for (var i = 0; i < abc.length; i++) {
				arr[cnt] = parseInt(abc[i].split('/')[2]);
				cnt++;
			}
			sap.ui.getCore().FinScore = [];
			for (var i = 0; i < arr.length; i++) {
				sap.ui.getCore().FinScore.push(otable.getModel().getData().modelData100[arr[i]]);
			}

			var dat = this.getView().byId("Func_list").getModel().getData().modelData;
			sap.ui.getCore().ODThis.getView().getController().aData = dat;
			var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
			var oModel = new sap.ui.model.json.JSONModel();
			var dt = this.getView().byId("Func_list").getModel().getData().modelData;
			var year = new Date().getFullYear();
			var statDt = new Date(year + "/04/01");
			var year2 = new Date().getFullYear() + 1;
			var endDt = new Date(year2 + "/03/31");
			var tempwtg = 0;
			for (var ii = 0; ii < sap.ui.getCore().FinScore.length; ii++) {
				var wtg = sap.ui.getCore().FinScore[ii].WEIGHTAGE;
				tempwtg = parseInt(tempwtg) + parseInt(wtg);
			}
			//weightage meter logic
			var cntwtg = 0;
			var edit_wtg = tempwtg;
		/*	var progressBR = this.getView().byId("Proc_indicator");
			var last_wtg = progressBR.getPercentValue();

			cntwtg = parseInt(tempwtg) + parseInt(last_wtg);
			if (cntwtg <= 100) {

				for (var ii = 0; ii < sap.ui.getCore().FinScore.length; ii++) {
					var wtg = sap.ui.getCore().FinScore[ii].WEIGHTAGE;
					tempwtg = parseInt(tempwtg) + parseInt(wtg);
					dt.push({
						"EmpId": "",
						"GoalId": "",
						"GoalItemId": "",
						"GoalName": "Score Card",
						"Weightage": wtg + "%",
						"KraText": sap.ui.getCore().FinScore[ii].KPA_TEXT,
						"KpiText": sap.ui.getCore().FinScore[ii].KPI_TEXT,
						"GoalDate": oDateFormat.format(endDt),
						"GoalSdate": oDateFormat.format(statDt)
					});
				}

				oModel.setData({
					modelData: dt
				});
				list.setModel(oModel);
				var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
				list.bindItems("/modelData", objlist);

				//update wtg meter 
				var progressBR = this.getView().byId("Proc_indicator");
				progressBR.setDisplayValue("Overall Weightage " + cntwtg + "%");
				progressBR.setPercentValue(cntwtg);
				if (0 <= cntwtg && cntwtg <= 40) {
					progressBR.setState("Error");
				} else if (41 <= cntwtg && cntwtg <= 80) {
					progressBR.setState("Warning");
				} else if (81 <= cntwtg && cntwtg <= 100) {
					progressBR.setState("Success");
				}

				var dialog = this.getView().byId("ScoreCard");
				dialog.destroy();
				dialog.close();
			} else {
				MessageToast.show("you can not add weightage more than 100");
			}*/
		},
		handle_goal_lib: function() {
			var odatamodel = this.getView().getModel();
			odatamodel.read("GoalLibararySet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username + "%27", null, null, false, function(
				oResponse) {
				sap.ui.getCore().GoalLibarary = oResponse;
			});
			var oView = sap.ui.getCore().ODThis.getView();

			var oDialog = oView.byId("GoalLib");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsmobile.view.Goal_Lib", this).addStyleClass("sapUiSizeCompact"); //14july
				var aa = this.getView().byId("tblGoalLib").mAggregations.title;
				aa.setText(sap.ui.getCore().goallib_header);
				this.getView().byId("GoalLib").setTitle(sap.ui.getCore().goallib_header);
				var oTable1 = this.getView().byId("tblGoalLib");

				var oControl1 = new sap.m.Text({
					text: "{KraText}",
					textAlign: "Left"
				}).addStyleClass("txttbl");
				var oColumn1 = new sap.ui.table.Column({
					multiLabels: [
						new sap.m.Label({
							text: "KRA"
						})
					],
					width: "40%",
					template: oControl1,
					hAlign: "Center",
					resizable: false,
					autoResizable: false
				});
				oTable1.addColumn(oColumn1, {
					resizable: false,
					autoResizable: false
				});
				var oControl1 = new sap.m.Text({
					text: "{KpiText}",
					textAlign: "Left"
				}).addStyleClass("txttbl");
				var oColumn1 = new sap.ui.table.Column({
					multiLabels: [
						new sap.m.Label({
							text: "KPI"
						})
					],
					width: "40%",
					template: oControl1,
					hAlign: "Center",
					resizable: false,
					autoResizable: false
				});
				oTable1.addColumn(oColumn1, {
					resizable: false,
					autoResizable: false
				});
				var oControl1 = new sap.m.Text({
					text: "{Weightage}",
					textAlign: "Center"
				});
				var oColumn1 = new sap.ui.table.Column({
					multiLabels: [
						new sap.m.Label({
							text: "Weightage(%)"
						})
					],
					width: "20%",
					template: oControl1,
					hAlign: "Center",
					resizable: false,
					autoResizable: false
				});
				oTable1.addColumn(oColumn1, {
					resizable: false,
					autoResizable: false
				});
				var oModel = new sap.ui.model.json.JSONModel();
				//sap.ui.getCore().ScoreCardTree.results[0].PARENT_NODE_ID = null;
				var res = sap.ui.getCore().GoalLibarary.results;
				//sap.ui.getCore().ScoreCardTreeset = res;
				oModel.setData({
					items: res
				});
				oTable1.setModel(oModel);
				oTable1.setVisibleRowCount(res.length);

				this.getView().byId("btn_scr_save").setText(sap.ui.getCore().save_btn);
				this.getView().byId("btn_scr_cancel").setText(sap.ui.getCore().cancel_btn);

				oView.addDependent(oDialog);
			}
			oDialog.open();
		},
		onCloseScoreCard: function() {
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
		},
		onCloseGoalLib: function() {
			var dialog = this.getView().byId("GoalLib");
			dialog.destroy();
			dialog.close();
		},
		///////////////////////Setting for leng.//////////////////////////

		onSettingLang: function() {
			sap.ui.getCore().ordersThis._getDialog007().open();

		},
		_getDialog007: function() {
			if (!this._oDialog007) {
				this._oDialog007 = sap.ui.xmlfragment("com.drl.pmsmobile.view.Setting", this);//14july
				this.getView().addDependent(this._oDialog007);
			}
			return this._oDialog007;
		},

		Russian_language: function() {
						try{
			// var sLocale = "ru";
			// var oBundle = jQuery.sap.resources({
			// 	url: "css/i18n.properties",
			// 	locale: sLocale
			// });
			var oRootPath = jQuery.sap.getModulePath("com.drl.pmsmobile"); //14july
			// set i18n model
			var oBundle = new sap.ui.model.resource.ResourceModel({
				bundleUrl: oRootPath + "/i18n/i18n_ru.properties"
			});
			oBundle = oBundle._oResourceBundle;
			/* var sLocale = sap.ui.getCore().getConfiguration().getLanguage();*/

			var sMsg1 = oBundle.getText("MyPerformance");
			this.getView().byId("MyPerformance_Title").setText(sMsg1);

			var sMsg2 = oBundle.getText("EMPcode");
			this.getView().byId("HD_empcode0").setText(sMsg2);

			var sMsg3 = oBundle.getText("RoleBand");
			this.getView().byId("HD_roleB0").setText(sMsg3);

			var sMsg4 = oBundle.getText("Department");
			this.getView().byId("HD_dept0").setText(sMsg4);

			var sMsg5 = oBundle.getText("UnitBU");
			this.getView().byId("HD_unit0").setText(sMsg5);

			var sMsg6 = oBundle.getText("Manager");
			this.getView().byId("HD_mngNM0").setText(sMsg6);

			var sMsg7 = oBundle.getText("Reviewer");
			this.getView().byId("HD_revNM0").setText(sMsg7);

			var sMsg8 = oBundle.getText("Matrixmanager");
			this.getView().byId("HD_mmngr0").setText(sMsg8);

			var sMsg9 = oBundle.getText("PerformancePath");
			sap.ui.getCore().Perf_path_text = sMsg9;
			this.getView().byId("PerformancePathID").setTitle(sMsg9);

			var sMsg10 = oBundle.getText("Goal");
			sap.ui.getCore().Goal_header = sMsg10;
			this.getView().byId("GoalID").setTitle(sMsg10);
			this.getView().byId("GoalID").setTitle(sMsg10);

			var sMsg11 = oBundle.getText("Add");
			this.getView().byId("openMenu").setText(sMsg11);

			/*var sMsg12 = oBundle.getText("OverallWeightage");
			this.getView().byId("Proc_indicator").setDisplayValue(sMsg12);*/

			var sMsg13 = oBundle.getText("FunctionalGoals");
			this.getView().byId("FunctionalGoalsID").setHeaderText(sMsg13);

			var sMsg14 = oBundle.getText("KPIMeasure");
			this.getView().byId("KPIMeasureID").setTitle(sMsg14);

			var sMsg15 = oBundle.getText("StartDate");
			this.getView().byId("StartDateID").setTitle(sMsg15);

			var sMsg16 = oBundle.getText("Completiondate");
			this.getView().byId("CompletiondateID").setTitle(sMsg16);

			var sMsg17 = oBundle.getText("ProjectGoals");
			this.getView().byId("ProjectGoalsID").setHeaderText(sMsg17);

			var sMsg18 = oBundle.getText("KPIMeasure");
			this.getView().byId("KPIMeasureID").setTitle(sMsg18);

			var sMsg19 = oBundle.getText("StartDate");
			this.getView().byId("StartDateID").setTitle(sMsg19);

			var sMsg20 = oBundle.getText("Completiondate");
			this.getView().byId("CompletiondateID").setTitle(sMsg20);

			var sMsg21 = oBundle.getText("GoalLibrary");
			this.getView().byId("GOAL_LIB").setText(sMsg21);

			var sMsg22 = oBundle.getText("Perf_GoalSetting");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-0").setText(sMsg22);

			var sMsg23 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-1").setText(sMsg23);

			var sMsg24 = oBundle.getText("Perf_halfyearly");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-2").setText(sMsg24);

			var sMsg25 = oBundle.getText("GoalRevisit");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-3").setText(sMsg25);
			
			var sMsg27 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-4").setText(sMsg27);

			var sMsg26 = oBundle.getText("Perf_annualReview");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-5").setText(sMsg26);

			var sMsg26 = oBundle.getText("Perf_ARC");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-6").setText(sMsg26);
			
			var sMsg26 = oBundle.getText("Perf_Finalsignoff");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-7").setText(sMsg26);
			

			var sMsg28 = oBundle.getText("Submit");
			this.getView().byId("btn_submit_GoalSet").setText(sMsg28);

			sap.ui.getCore().save_btn = oBundle.getText("Add_goal");
			sap.ui.getCore().cancel_btn = oBundle.getText("cancel");

			sap.ui.getCore().fun_owngoal_tital = oBundle.getText("AddFunctionalGoal");
			sap.ui.getCore().fun_owngoal_KRA = oBundle.getText("KRA_Goals");
			sap.ui.getCore().fun_owngoal_KPI = oBundle.getText("KPIMeasure");
			sap.ui.getCore().fun_owngoal_Weight = oBundle.getText("Weight");
			sap.ui.getCore().fun_owngoal_startDt = oBundle.getText("StartDate");
			sap.ui.getCore().fun_owngoal_complDt = oBundle.getText("CompletionDate");

			sap.ui.getCore().proj_owngoal_tital = oBundle.getText("AddProjectGoal");

			sap.ui.getCore().mnu_func = oBundle.getText("FunctionalGoals");
			sap.ui.getCore().mnu_proj = oBundle.getText("ProjectGoals");
			sap.ui.getCore().mnu_score = oBundle.getText("Scorecard");
			sap.ui.getCore().mnu_own = oBundle.getText("owngoal");

			sap.ui.getCore().scorecard_header = oBundle.getText("scorecard_text");
			sap.ui.getCore().scorecard_tbl_header = oBundle.getText("scorecard_tbl_head");

			sap.ui.getCore().goallib_header = oBundle.getText("goal_library");

			sap.ui.getCore().Aftersubmit1 = oBundle.getText("AfterSubmit1");
			sap.ui.getCore().Aftersubmit2 = oBundle.getText("AfterSubmit2");

			sap.ui.getCore().P_title = oBundle.getText("P_title");
			sap.ui.getCore().P_empinfo = oBundle.getText("P_empinfo");
			sap.ui.getCore().P_Fname = oBundle.getText("P_Fname");
			sap.ui.getCore().P_empNO = oBundle.getText("P_empNO");
			sap.ui.getCore().P_desg = oBundle.getText("P_desg");
			sap.ui.getCore().P_deprt = oBundle.getText("P_deprt");
			sap.ui.getCore().P_L_1 = oBundle.getText("P_L_1");
			sap.ui.getCore().P_L_1_desg = oBundle.getText("P_L_1_desg");
			sap.ui.getCore().P_L_2 = oBundle.getText("P_L_2");
			sap.ui.getCore().P_L_2_desg = oBundle.getText("P_L_2_desg");
			
			var sMsg = oBundle.getText("OverallAssessment");
				this.getView().byId("PNL_OverAllAsset").setHeaderText(sMsg);
				var sMsg = oBundle.getText("HalfYearReview");
				this.getView().byId("PNL_HalfYearReview").setHeaderText(sMsg);
				var sMsgH = oBundle.getText("HalfYearlyComments");
			//	this.getView().byId("PNL_halfyrcmnt").setHeaderText(sMsg);
				var sMsgA = oBundle.getText("AnnualComments");
			//	this.getView().byId("PNL_annualRevw").setHeaderText(sMsg);
			
			//data GET for haf year employee
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//set timeline text area text
					sap.ui.getCore().byId("Goalset--PNL_halfyrcmnt-Goalset--Func_list-" + i).setHeaderText(sMsgH);
					sap.ui.getCore().byId("Goalset--PNL_annualRevw-Goalset--Func_list-" + i).setHeaderText(sMsgA);
					
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//set timeline text area text
					sap.ui.getCore().byId("Goalset--PNL_halfyrcmnt_proj-Goalset--Proj_list-" + i).setHeaderText(sMsgH);
					sap.ui.getCore().byId("Goalset--PNL_annualRevw_proj-Goalset--Proj_list-" + i).setHeaderText(sMsgA);
				}
				
				var sMsg = oBundle.getText("FNSText1");
				this.getView().byId("FNS_L1").setText(sMsg);
				var sMsg = oBundle.getText("FNSText2");
				this.getView().byId("FNS_L1").setText(sMsg);
				var sMsg = oBundle.getText("Agree");
				this.getView().byId("_agree").setText(sMsg);
				var sMsg = oBundle.getText("Disagree");
				this.getView().byId("_notagree").setText(sMsg);
			}catch(e){console.log(e);}
		

		},

		onSettingSave: function() {
							try{
			jQuery.sap.require("jquery.sap.resources");
			var lang_select = sap.ui.getCore().byId("CBOX_Leng_setting");
			var selectIndex1 = lang_select.getSelectedIndex();

			if (selectIndex1 == 2) {

				var oRootPath = jQuery.sap.getModulePath("com.drl.pmsmobile");//14july
				// set i18n model
				var oBundle = new sap.ui.model.resource.ResourceModel({
					bundleUrl: oRootPath + "/i18n/i18n_ru.properties"

				});

				oBundle = oBundle._oResourceBundle;

				// var sLocale = "ru";
				// var oBundle = jQuery.sap.resources({
				// 	url: "css/i18n.properties",
				// 	locale: sLocale
				// });
				/* var sLocale = sap.ui.getCore().getConfiguration().getLanguage();*/

				var sMsg1 = oBundle.getText("MyPerformance");
				this.getView().byId("MyPerformance_Title").setText(sMsg1);

				var sMsg2 = oBundle.getText("EMPcode");
				this.getView().byId("HD_empcode0").setText(sMsg2);

				var sMsg3 = oBundle.getText("RoleBand");
				this.getView().byId("HD_roleB0").setText(sMsg3);

				var sMsg4 = oBundle.getText("Department");
				this.getView().byId("HD_dept0").setText(sMsg4);

				var sMsg5 = oBundle.getText("UnitBU");
				this.getView().byId("HD_unit0").setText(sMsg5);

				var sMsg6 = oBundle.getText("Manager");
				this.getView().byId("HD_mngNM0").setText(sMsg6);

				var sMsg7 = oBundle.getText("Reviewer");
				this.getView().byId("HD_revNM0").setText(sMsg7);

				var sMsg8 = oBundle.getText("Matrixmanager");
				this.getView().byId("HD_mmngr0").setText(sMsg8);

				var sMsg9 = oBundle.getText("PerformancePath");
				sap.ui.getCore().Perf_path_text = sMsg9;
				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sMsg9);

				var sMsg10 = oBundle.getText("Goal");
				sap.ui.getCore().Goal_header = sMsg10;
				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sMsg10);

				sap.ui.getCore().byId("Goalset--GoalID").setTitle(sMsg10);

				var sMsg11 = oBundle.getText("Add");
				this.getView().byId("openMenu").setText(sMsg11);

				/*var sMsg12 = oBundle.getText("OverallWeightage");
				this.getView().byId("Proc_indicator").setDisplayValue(sMsg12);*/

				var sMsg13 = oBundle.getText("FunctionalGoals");
				this.getView().byId("FunctionalGoalsID").setHeaderText(sMsg13);

				var sMsg14 = oBundle.getText("KPIMeasure");
				this.getView().byId("KPIMeasureID").setTitle(sMsg14);

				var sMsg15 = oBundle.getText("StartDate");
				this.getView().byId("StartDateID").setTitle(sMsg15);

				var sMsg16 = oBundle.getText("Completiondate");
				this.getView().byId("CompletiondateID").setTitle(sMsg16);

				var sMsg17 = oBundle.getText("ProjectGoals");
				this.getView().byId("ProjectGoalsID").setHeaderText(sMsg17);

				var sMsg18 = oBundle.getText("KPIMeasure");
				this.getView().byId("KPIMeasureID").setTitle(sMsg18);

				var sMsg19 = oBundle.getText("StartDate");
				this.getView().byId("StartDateID").setTitle(sMsg19);

				var sMsg20 = oBundle.getText("Completiondate");
				this.getView().byId("CompletiondateID").setTitle(sMsg20);

				var sMsg21 = oBundle.getText("GoalLibrary");
				this.getView().byId("GOAL_LIB").setText(sMsg21);

				var sMsg22 = oBundle.getText("Perf_GoalSetting");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-0").setText(sMsg22);

			var sMsg23 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-1").setText(sMsg23);

			var sMsg24 = oBundle.getText("Perf_halfyearly");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-2").setText(sMsg24);

			var sMsg25 = oBundle.getText("GoalRevisit");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-3").setText(sMsg25);
			
			var sMsg27 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-4").setText(sMsg27);

			var sMsg26 = oBundle.getText("Perf_annualReview");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-5").setText(sMsg26);

			var sMsg26 = oBundle.getText("Perf_ARC");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-6").setText(sMsg26);
			
			var sMsg26 = oBundle.getText("Perf_Finalsignoff");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-7").setText(sMsg26);

				var sMsg28 = oBundle.getText("Submit");
				this.getView().byId("btn_submit_GoalSet").setText(sMsg28);

				sap.ui.getCore().save_btn = oBundle.getText("Add_goal");
				sap.ui.getCore().cancel_btn = oBundle.getText("cancel");

				sap.ui.getCore().fun_owngoal_tital = oBundle.getText("AddFunctionalGoal");
				sap.ui.getCore().fun_owngoal_KRA = oBundle.getText("KRA_Goals");
				sap.ui.getCore().fun_owngoal_KPI = oBundle.getText("KPIMeasure");
				sap.ui.getCore().fun_owngoal_Weight = oBundle.getText("Weight");
				sap.ui.getCore().fun_owngoal_startDt = oBundle.getText("StartDate");
				sap.ui.getCore().fun_owngoal_complDt = oBundle.getText("CompletionDate");

				sap.ui.getCore().proj_owngoal_tital = oBundle.getText("AddProjectGoal");

				sap.ui.getCore().mnu_func = oBundle.getText("FunctionalGoals");
				sap.ui.getCore().mnu_proj = oBundle.getText("ProjectGoals");
				sap.ui.getCore().mnu_score = oBundle.getText("Scorecard");
				sap.ui.getCore().mnu_own = oBundle.getText("owngoal");

				sap.ui.getCore().scorecard_header = oBundle.getText("scorecard_text");
				sap.ui.getCore().scorecard_tbl_header = oBundle.getText("scorecard_tbl_head");

				sap.ui.getCore().goallib_header = oBundle.getText("goal_library");

				sap.ui.getCore().Aftersubmit1 = oBundle.getText("AfterSubmit1");
				sap.ui.getCore().Aftersubmit2 = oBundle.getText("AfterSubmit2");

				sap.ui.getCore().P_title = oBundle.getText("P_title");
				sap.ui.getCore().P_empinfo = oBundle.getText("P_empinfo");
				sap.ui.getCore().P_Fname = oBundle.getText("P_Fname");
				sap.ui.getCore().P_empNO = oBundle.getText("P_empNO");
				sap.ui.getCore().P_desg = oBundle.getText("P_desg");
				sap.ui.getCore().P_deprt = oBundle.getText("P_deprt");
				sap.ui.getCore().P_L_1 = oBundle.getText("P_L_1");
				sap.ui.getCore().P_L_1_desg = oBundle.getText("P_L_1_desg");
				sap.ui.getCore().P_L_2 = oBundle.getText("P_L_2");
				sap.ui.getCore().P_L_2_desg = oBundle.getText("P_L_2_desg");

				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sMsg9);
				
				var sMsg = oBundle.getText("OverallAssessment");
				this.getView().byId("PNL_OverAllAsset").setHeaderText(sMsg);
				var sMsg = oBundle.getText("HalfYearReview");
				this.getView().byId("PNL_HalfYearReview").setHeaderText(sMsg);
				var sMsg = oBundle.getText("AnnualReview");
				this.getView().byId("PNL_AnnualAsset").setHeaderText(sMsg);
				var sMsgH = oBundle.getText("HalfYearlyComments");
				//this.getView().byId("PNL_halfyrcmnt").c
				var sMsgA = oBundle.getText("AnnualComments");
				//this.getView().byId("PNL_annualRevw").setHeaderText(sMsg);
				//data GET for haf year employee
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//set timeline text area text
					sap.ui.getCore().byId("Goalset--PNL_halfyrcmnt-Goalset--Func_list-" + i).setHeaderText(sMsgH);
					sap.ui.getCore().byId("Goalset--PNL_annualRevw-Goalset--Func_list-" + i).setHeaderText(sMsgA);
					
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//set timeline text area text
					sap.ui.getCore().byId("Goalset--PNL_halfyrcmnt_proj-Goalset--Proj_list-" + i).setHeaderText(sMsgH);
					sap.ui.getCore().byId("Goalset--PNL_annualRevw_proj-Goalset--Proj_list-" + i).setHeaderText(sMsgA);
				}
				var sMsg = oBundle.getText("FNSText1");
				this.getView().byId("FNS_L1").setText(sMsg);
				var sMsg = oBundle.getText("FNSText2");
				this.getView().byId("FNS_L1").setText(sMsg);
				var sMsg = oBundle.getText("Agree");
				this.getView().byId("_agree").setText(sMsg);
				var sMsg = oBundle.getText("Disagree");
				this.getView().byId("_notagree").setText(sMsg);
				
			} else if (selectIndex1 == 1) {

				// var sLocale = "en";
				// var oBundle = jQuery.sap.resources({
				// 	url: "css/i18n.properties",
				// 	locale: sLocale
				// });
				var oRootPath = jQuery.sap.getModulePath("com.drl.pmsmobile"); //14july
				// set i18n model
				var oBundle = new sap.ui.model.resource.ResourceModel({
					bundleUrl: oRootPath + "/i18n/i18n_en.properties"

				});

				oBundle = oBundle._oResourceBundle;
				/* var sLocale = sap.ui.getCore().getConfiguration().getLanguage();*/

				var sMsg1 = oBundle.getText("MyPerformance");
				this.getView().byId("MyPerformance_Title").setText(sMsg1);

				var sMsg2 = oBundle.getText("EMPcode");
				this.getView().byId("HD_empcode0").setText(sMsg2);

				var sMsg3 = oBundle.getText("RoleBand");
				this.getView().byId("HD_roleB0").setText(sMsg3);

				var sMsg4 = oBundle.getText("Department");
				this.getView().byId("HD_dept0").setText(sMsg4);

				var sMsg5 = oBundle.getText("UnitBU");
				this.getView().byId("HD_unit0").setText(sMsg5);

				var sMsg6 = oBundle.getText("Manager");
				this.getView().byId("HD_mngNM0").setText(sMsg6);

				var sMsg7 = oBundle.getText("Reviewer");
				this.getView().byId("HD_revNM0").setText(sMsg7);

				var sMsg8 = oBundle.getText("Matrixmanager");
				this.getView().byId("HD_mmngr0").setText(sMsg8);

				var sMsg9 = oBundle.getText("PerformancePath");
				sap.ui.getCore().Perf_path_text = sMsg9;
				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sMsg9);

				var sMsg10 = oBundle.getText("Goal");
				sap.ui.getCore().Goal_header = sMsg10;
				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--GoalID-anchor").setText(sMsg10);
				sap.ui.getCore().byId("Goalset--GoalID").setTitle(sMsg10);

				var sMsg11 = oBundle.getText("Add");
				this.getView().byId("openMenu").setText(sMsg11);

				/*var sMsg12 = oBundle.getText("OverallWeightage");
				this.getView().byId("Proc_indicator").setDisplayValue(sMsg12);*/

				var sMsg13 = oBundle.getText("FunctionalGoals");
				this.getView().byId("FunctionalGoalsID").setHeaderText(sMsg13);

				var sMsg14 = oBundle.getText("KPIMeasure");
				this.getView().byId("KPIMeasureID").setTitle(sMsg14);

				var sMsg15 = oBundle.getText("StartDate");
				this.getView().byId("StartDateID").setTitle(sMsg15);

				var sMsg16 = oBundle.getText("Completiondate");
				this.getView().byId("CompletiondateID").setTitle(sMsg16);

				var sMsg17 = oBundle.getText("ProjectGoals");
				this.getView().byId("ProjectGoalsID").setHeaderText(sMsg17);

				var sMsg18 = oBundle.getText("KPIMeasure");
				this.getView().byId("KPIMeasureID").setTitle(sMsg18);

				var sMsg19 = oBundle.getText("StartDate");
				this.getView().byId("StartDateID").setTitle(sMsg19);

				var sMsg20 = oBundle.getText("Completiondate");
				this.getView().byId("CompletiondateID").setTitle(sMsg20);

				var sMsg21 = oBundle.getText("GoalLibrary");
				this.getView().byId("GOAL_LIB").setText(sMsg21);

			var sMsg22 = oBundle.getText("Perf_GoalSetting");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-0").setText(sMsg22);

			var sMsg23 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-1").setText(sMsg23);

			var sMsg24 = oBundle.getText("Perf_halfyearly");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-2").setText(sMsg24);

			var sMsg25 = oBundle.getText("GoalRevisit");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-3").setText(sMsg25);
			
			var sMsg27 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-4").setText(sMsg27);

			var sMsg26 = oBundle.getText("Perf_annualReview");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-5").setText(sMsg26);

			var sMsg26 = oBundle.getText("Perf_ARC");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-6").setText(sMsg26);
			
			var sMsg26 = oBundle.getText("Perf_Finalsignoff");
			sap.ui.getCore().byId("__header0-Goalset--processflow2-7").setText(sMsg26);

				var sMsg28 = oBundle.getText("Submit");
				this.getView().byId("btn_submit_GoalSet").setText(sMsg28);

				sap.ui.getCore().save_btn = oBundle.getText("Add_goal");
				sap.ui.getCore().cancel_btn = oBundle.getText("cancel");

				sap.ui.getCore().fun_owngoal_tital = oBundle.getText("AddFunctionalGoal");
				sap.ui.getCore().fun_owngoal_KRA = oBundle.getText("KRA_Goals");
				sap.ui.getCore().fun_owngoal_KPI = oBundle.getText("KPIMeasure");
				sap.ui.getCore().fun_owngoal_Weight = oBundle.getText("Weight");
				sap.ui.getCore().fun_owngoal_startDt = oBundle.getText("StartDate");
				sap.ui.getCore().fun_owngoal_complDt = oBundle.getText("CompletionDate");

				sap.ui.getCore().proj_owngoal_tital = oBundle.getText("AddProjectGoal");

				sap.ui.getCore().mnu_func = oBundle.getText("FunctionalGoals");
				sap.ui.getCore().mnu_proj = oBundle.getText("ProjectGoals");
				sap.ui.getCore().mnu_score = oBundle.getText("Scorecard");
				sap.ui.getCore().mnu_own = oBundle.getText("owngoal");

				sap.ui.getCore().scorecard_header = oBundle.getText("scorecard_text");
				sap.ui.getCore().scorecard_tbl_header = oBundle.getText("scorecard_tbl_head");

				sap.ui.getCore().goallib_header = oBundle.getText("goal_library");

				sap.ui.getCore().Aftersubmit1 = oBundle.getText("AfterSubmit1");
				sap.ui.getCore().Aftersubmit2 = oBundle.getText("AfterSubmit2");

				sap.ui.getCore().P_title = oBundle.getText("P_title");
				sap.ui.getCore().P_empinfo = oBundle.getText("P_empinfo");
				sap.ui.getCore().P_Fname = oBundle.getText("P_Fname");
				sap.ui.getCore().P_empNO = oBundle.getText("P_empNO");
				sap.ui.getCore().P_desg = oBundle.getText("P_desg");
				sap.ui.getCore().P_deprt = oBundle.getText("P_deprt");
				sap.ui.getCore().P_L_1 = oBundle.getText("P_L_1");
				sap.ui.getCore().P_L_1_desg = oBundle.getText("P_L_1_desg");
				sap.ui.getCore().P_L_2 = oBundle.getText("P_L_2");
				sap.ui.getCore().P_L_2_desg = oBundle.getText("P_L_2_desg");

				sap.ui.getCore().byId("Goalset--ObjectPageLayout-anchBar-Goalset--PerformancePathID-anchor").setText(sMsg9);
				
				var sMsg = oBundle.getText("OverallAssessment");
				this.getView().byId("PNL_OverAllAsset").setHeaderText(sMsg);
				var sMsg = oBundle.getText("HalfYearReview");
				this.getView().byId("PNL_HalfYearReview").setHeaderText(sMsg);
				var sMsg = oBundle.getText("HalfYearlyComments");
				//this.getView().byId("PNL_halfyrcmnt").setHeaderText(sMsg);
				var sMsg = oBundle.getText("AnnualComments");
			//	this.getView().byId("PNL_annualRevw").setHeaderText(sMsg);
				//data GET for haf year employee
				var goals = sap.ui.getCore().GOALS.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//set timeline text area text
					sap.ui.getCore().byId("Goalset--PNL_halfyrcmnt-Goalset--Func_list-" + i).setHeaderText(sMsgH);
					sap.ui.getCore().byId("Goalset--PNL_annualRevw-Goalset--Func_list-" + i).setHeaderText(sMsgA);
					
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//set timeline text area text
					sap.ui.getCore().byId("Goalset--PNL_halfyrcmnt_proj-Goalset--Proj_list-" + i).setHeaderText(sMsgH);
					sap.ui.getCore().byId("Goalset--PNL_annualRevw_proj-Goalset--Proj_list-" + i).setHeaderText(sMsgA);
				}
			
				var sMsg = oBundle.getText("FNSText1");
				this.getView().byId("FNS_L1").setText(sMsg);
				var sMsg = oBundle.getText("FNSText2");
				this.getView().byId("FNS_L1").setText(sMsg);
				var sMsg = oBundle.getText("Agree");
				this.getView().byId("_agree").setText(sMsg);
				var sMsg = oBundle.getText("Disagree");
				this.getView().byId("_notagree").setText(sMsg);

			}

			sap.ui.getCore().ordersThis._getDialog007().close();
			}catch(e){console.log("Language change exception"+e);}
		

		},
		onSettingCancel: function() {
			sap.ui.getCore().ordersThis._getDialog007().close();
		},
		onSlider_change: function(evt) {
			var curr_progg = evt.getProgress();
		},
		onNavBack : function(){
		   
	            this.getOwnerComponent().getRouter().navTo("YearSelection");
		}

	});

});