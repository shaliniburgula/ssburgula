/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("i2d.qm.qualityissue.confirm.Configuration", {

	aServiceList : [{
		name : "QM_NOTIF_SRV",// 
		masterCollection : "QMNotificationSelectionSet",
		createCollection : "QMNotificationCreationSet",
		QIAttachmentsCreate : "QMAttachmentCreationSet",
		QIAttachmentsRead : "QMNotificationSelectionSet",
		QIAttachmentGet : "GetAttData",
		QIAttachmentStream : "QMStreamSet",
		SelectionSetCollection : [ "QMDefectSelectionSet", "QMCategorySelectionSet", "QMPlantsSet", "QMSettingsSet", "QMStatusSet" ],
		serviceUrl: "" + URI("/sap/opu/odata/sap/QM_NOTIF_SRV/"),
        isDefault: true,
        mockedDataSource: "model/metadata.xml",
        useBatch: true 	
	} ],
	GlobalParams : {
		settingsName : "QI_objSettings",
		factSheetsNavigation : { semanticObject : "QualityNotification",
								 action : "displayFactSheet" , 
								 paramName : "QualityNotification"},	
		HTTP_Method : {
								 GET 	: "GET",
								 POST	: "POST",
								 PUT	: "PUT",
								 DELETE	: "DELETE",
								 MERGE	: "MERGE"
					  },
		ProcessingModeEnum : {
								 Read : "Read", 
								 Batch : "ReadBatch", 
								 Change : "ChangeBatch"
							 },	
		InteropService	   : {
								name : "UI2/INTEROP",// "INTEROP service - check for cross app navigation availability
								linkCheck : "ResolveLink?linkId='QualityNotification-displayFactSheet'",		
								serviceUrl: URI("/sap/opu/odata/UI2/INTEROP/")
							}, 					 
					 
		filterDialogDefaultFromDate : "1970-01-01T00:00:00.000Z",
		filterDialogDefaultToDate : "9999-12-31T00:00:00.000Z"
					  
	},
	

	/**
	 * @override Getter for the service list to be used as source for the
	 *           Connection Manager
	 * 
	 * @returns {object} the list of ODataModel to instantiate with their
	 *          corresponding url / mock url
	 */
	
	/**
	 * @inherit
	 */
	getServiceList : function() {
		return this.aServiceList;
	},
	
	getParams : function() {
		return this.GlobalParams;
	},
	
	getMasterKeyAttributes : function() {
		return ["Notification", "NotificationID"];
	},
	
	getAppIdentifier : function() {
		return "i2d.qm.qualityissue.confirm";
	},
	
	
});
