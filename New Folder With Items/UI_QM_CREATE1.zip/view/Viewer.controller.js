/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
sap.ca.scfld.md.controller.BaseFullscreenController.extend("i2d.qm.qualityissue.confirm.view.Viewer", {
	onInit: function() {
		this.pictureViewer = this.getView().byId("pictureViewer");
		this.galleryItems = "";
		this.editModel = new sap.ui.model.json.JSONModel({
			"editable": true
		});
		this.getView().setModel(this.editModel, "edit");
		this.resourceBundle = this.oApplicationFacade.getResourceBundle()
	},
	setHeaderFooterOptions: function(o) {},
	onRemove: function(e) {
		var p = e.getParameters().index;
		var m = this.getView().getModel("picture");
		var P = m.getData().Pictures;
		P.splice(p, 1);
		m.setData({
			Pictures: P
		})
	},
	_selectImage: function() {}
});