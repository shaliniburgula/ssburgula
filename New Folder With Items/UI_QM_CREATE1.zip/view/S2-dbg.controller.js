/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
jQuery.sap.require("sap.m.DatePicker");
jQuery.sap.require("sap.ca.scfld.md.app.MasterHeaderFooterHelper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");

sap.ca.scfld.md.controller.ScfldMasterController.extend("i2d.qm.qualityissue.confirm.view.S2", {	
	/**
	 * @override
	 * 
	 * Called by the UI5 runtime to init this controller
	 * 
	 */
	onInit : function() {
		// Execute onInit for the base class
		// BaseMasterController
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		// Settings
		this.oMasterModel = new sap.ui.model.json.JSONModel({
			selectedFilter : "All",
			selectedSorter : "CreatedOn",
			toogleSubmit : false
		});
		this.getView().setModel(this.oMasterModel, "masterModel");
		
		// Retrieve the application bundle
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oSettingsDialog = null;
		// Set list max count displayed
		this.SETTINGS_NAME = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName;
		this.objSettings = localStorage.getObj(this.SETTINGS_NAME);
		
	 	//CSS Fix -remove leading zeros coming from oData
		if (this.objSettings.maxHits){
			this.objSettings.maxHits = parseInt(this.objSettings.maxHits, 10);
			if (isNaN(this.objSettings.maxHits)){
				jQuery.sap.log.error("Error with data, please check consistency of record. Default 30 issues displayed.");
				this.objSettings.maxHits = '30';
			}
		} //end of fix
		
		if ($.isBlank(this.objSettings)) {
			var settingsMapping = [
			                       {output:"maxHits", source:"MaxHits"},
			                       {output:"defPlant", source:"Plant"},
			                       {output:"maxFileSize", source:"MaxFileSize"}
			                       ];
			var batchResult = i2d.qm.qualityissue.confirm.utils.Helper.getCollection([{indexCollection: 3, arConversionRules : settingsMapping}], this);
			this.objSettings = batchResult && batchResult.length >0 && batchResult[0];
			// store the object into local Storage for future usage
			localStorage.setObj(this.SETTINGS_NAME, this.objSettings);
		}
		
		
		this.setMaxHitsToList();
		this._showLoadingText(true);
		var bus = sap.ui.getCore().getEventBus();				   
        
		bus.subscribe(sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier(), "RefreshDetail", this.handleRefresh, this);

		var oList = this.getList();
		oList.attachUpdateFinished(this.handleUpdateFinished, this);
		
		var oTemplate = oList.getItems()[0].clone();
		oList.bindItems("/QMNotificationSelectionSet", oTemplate);
		
		this.aFilterBy = [];
		this.dateFromUTC;
		this.dateToUTC;
		this.DateFromUTCValue;
		this.DateToUTCValue;
		this.previousDateFromUTC;
		this.previousDateToUTC;
		this.closeCustSetDialog = function(){
			this.changedMaxHits 	= undefined;
			this.changedPlant		= undefined;
			this.changedPlantIndex 	= undefined;
			i2d.qm.qualityissue.confirm.utils.FragmentHelper.closeCustSetDialog();
		};
		
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "masterDetail" && oEvent.getParameter("arguments").id === "create" && this.getList().getSelectedItem()) {
				// if creating for a second time (pressing plus button on the list) then the list should be updated  
				// and the selection should be always the first line in list 
				this.handleRefresh();
			}
			}, this);
		
	},
	
	navToEmptyView : function(){
		// work around until release 1.16.6, which will contains fix for this bug
		this.showEmptyView("DETAIL_TITLE", "NO_ITEMS_AVAILABLE"); 
	}, 
	
	/**
	 * Display "Loading..." when the list is loading after search, filter,
	 * sort ... and display usual "No data" after
	 * @param bLoading
	 */
	_showLoadingText:function (bLoading) {
		if (bLoading) {
			this.getList().setNoDataText(this.resourceBundle.getText("QI_LOADING_TEXT"));
		} else {
			this.getList().setNoDataText(this.resourceBundle.getText("QI_NO_DATA_AVAILABLE"));
		}
	},
	handleUpdateFinished : function(oControlEvent) {

		if (!jQuery.device.is.phone && (oControlEvent.getParameters().reason === "Filter"  || oControlEvent.getParameters().reason === "Change" || 
										oControlEvent.getParameters().reason === "Refresh" || oControlEvent.getParameters().reason === "Binding")) {
			
			//this._selectDetail();

			if (this.oRouter._oRouter._prevMatchedRequest === "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {
				this.getList().removeSelections();
			}
			if (this.getList().getItems().length == "0" ){
				this._showLoadingText(false);
			}else {
				this._showLoadingText(true);
			}
		}
	},

	handleRefresh : function() {
		this.setMaxHitsToList();
		this.getList().removeSelections();
		this.getList().getBinding("items")._refresh();
	},

	getHeaderFooterOptions : function() {
		return {
			sI18NMasterTitle : "QI_TITLE_MASTER_VIEW",
			buttonList : [],

			aAdditionalSettingButtons : [ {
				sId : "Settings",
				sI18nBtnTxt : "QI_MV_SETTINGS",
				sIcon : "sap-icon://wrench",
				onBtnPressed : jQuery.proxy(function(oEvent) {
					this.onSettingsPressed();
				}, this)
			} ],

			oFilterOptions : {
				onFilterPressed : $.proxy(this.onFilter, this)
			},
			oSortOptions : {
				onSortPressed : $.proxy(this.onSort, this)
			},
			onAddPress : jQuery.proxy(function(evt) {
				this.onCreate();
				jQuery.sap.log.info("add pressed");
			}, this)
		};
	},

	setMaxHitsToList : function() {
		// Evil hack until the solution is provided
		var oModel = this.getList().getModel();
		oModel.setCountSupported(false);
		oModel.setSizeLimit(this.objSettings.maxHits);
	},

	
	/**
	 * @override
	 * 
	 * @param oItem
	 * @param sFilterPattern
	 * @returns {*}
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {
		if (oItem.isSelectable()) {
			if (sFilterPattern.substring(0, 1) === "#") {
				var sTail = sFilterPattern.substr(1);
				var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
				return sDescr.indexOf(sTail) === 0;
			} else {
				return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem, sFilterPattern);
			}
		}

	},

	/**
	 * @override
	 * 
	 * determines whether search is triggered with each change of the search
	 * field content (or only when the user explicitly starts the search).
	 * 
	 */

	isLiveSearch : function() {
		// CSS: 0000124432 2014 - Reset List's noDataText to 'No Quality Issues Available' before a search
		this.getList().setNoDataText(this.resourceBundle.getText("QI_NO_DATA_AVAILABLE"));
		return false;
	},

	/**
	 * Called by the UI5 runtime to cleanup this controller
	 */

	onExit : function() {
		
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroySortDialog();
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroyFilterDialog();
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroyCustSetDialog();		
		
		if (this.oMasterModel) {
			this.oMasterModel.destroy();
			this.oMasterModel = null;
		}
		
		var oListFooter = sap.ui.getCore().byId( this.getView().sId + "--footer");
		if(oListFooter && oListFooter.destroy) {
		  oListFooter.destroy();
		}
		
	},

	setInfoLabel : function(resourceId, sText, bInfoEnabled, sFilteredBy) {
		if (bInfoEnabled === null)
			bInfoEnabled = true;

		this.oMasterModel.setProperty('/toogleSubmit', bInfoEnabled);
		if (bInfoEnabled === false)
			return;

		var oLabelToolbar = this.getView().byId("labelTB");
		var toReplace = "";
		if (sText)
			toReplace = this.resourceBundle.getText(sText);
		else
			toReplace = sFilteredBy;
		var sText = this.resourceBundle.getText(resourceId, [ toReplace ]);
		oLabelToolbar.setText(sText);
		oLabelToolbar.setTooltip(sText);
	},	
	
	setFilterInfoLabel : function(arFilterBy) {

		if (!$.isArray(arFilterBy) || arFilterBy.length < 1 ){
			this.setInfoLabel('', '', false, '');
			return;
		}
		
		var infoLabelText 	= "", 
			reportOn 		= this.resourceBundle.getText("QI_REPORT_ON"),
			status 			= this.resourceBundle.getText("QI_STATUS_TEXT");
		
		$.each(arFilterBy, function(index, filterBy) {

			if (i2d.qm.qualityissue.confirm.utils.Helper.isValidDate(filterBy.oValue1)){
				
				if (filterBy.oValue1 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate && 
						filterBy.oValue2 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate){
					return false;
				}
				
				filterBy.oValue1 = filterBy.oValue1.substring(0, 10);
				filterBy.oValue2 = filterBy.oValue2.substring(0, 10);
				infoLabelText += reportOn + ": " + filterBy.oValue1 + ", " + filterBy.oValue2;
				
			}else if(filterBy.oValue1){
				if (infoLabelText.indexOf(status) === -1){
					infoLabelText += status + ": " + i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusText(filterBy.oValue1);
				}else {
					infoLabelText += ", " + i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusText(filterBy.oValue1);
				}
			}
			
		});
		
		infoLabelText += ";";
		
		this.setInfoLabel("QI_FILTERED_BY", null, true, infoLabelText);
	},

	onCreate : function() {
		this.oRouter.navTo("fsS4");
	},

	onFilter : function(event){
		this.aFilterBy = [];
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.openFilterDialog(this);
	},
	
	onConfirmFilterDialog : function(oEvent){
		this._showLoadingText(true);
		var parameters = oEvent.getParameters();
		
		if (this.invalidDateTo || this.invalidDateFrom) {
			
			this.setInfoLabel("QI_INVALID_DATES_ERROR", null, true, null);
			this._showLoadingText(false);
			return;
		}
		
		// check if "To Date" entered in filter is equal to or greater than "From Date"
		if ((new Date(this.dateToUTC)).getTime() < (new Date(this.dateFromUTC).getTime())) {
			
			this.setInfoLabel("QI_TO_DATE_AFTER_FROM_DATE_ERROR", null, true, null);
			this._showLoadingText(false);
			return;
		}
			
		$.each(parameters.filterItems, $.proxy(function(index, filterItem){
			if(filterItem.sId === "StatusNew" || filterItem.sId === "StatusInProcess" || filterItem.sId === "StatusCompleted" || filterItem.sId === "StatusPostponed"){
				this.aFilterBy.push(filterItem.getCustomData()[0].getValue().filters);
			}
		}, this));

		if (this.shouldCreateDateFilterObject()){
			this.aFilterBy.push(new sap.ui.model.Filter("CreatedOn", sap.ui.model.FilterOperator.BT, this.dateFromUTC, this.dateToUTC));
		}
		
		//Clear default values of dates if needed
		if (this.dateFromUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate){ 
			this.dateFromUTC = null;
		}
		
		if (this.dateToUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate){ 
			this.dateToUTC = null;
		}

		this.getList().getBinding("items").filter(this.aFilterBy);
		this.setFilterInfoLabel(this.aFilterBy);
		
		this.previousDateFromUTC = this.DateFromUTCValue;
		this.previousDateToUTC = this.DateToUTCValue;
	},
	
	onCancelFilterDialog : function(oEvent){
		//Because the Date filter is constructed via custom controls, the date pickers and the filter counter are manually reset. Previous values are restored
		this.DateFromUTCValue = this.previousDateFromUTC;
		this.DateToUTCValue = this.previousDateToUTC;
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.resetFilterDialogDateFilter(this.previousDateFromUTC, this.previousDateToUTC);
	},
	
	onChangeDateFrom : function(oEvent){
		//Preserve previous value for the case of canceling changes
		this.DateFromUTCValue = oEvent.getSource().mProperties.value;
		this.dateFromUTC = i2d.qm.qualityissue.confirm.utils.Helper.convertToISODateTime(oEvent.getSource().mProperties.dateValue);
		this.invalidDateFrom = oEvent.mParameters.invalidValue && !($.isBlank(oEvent.mParameters.newValue));
		this.setDateFilterCount();
	},
	
	onChangeDateTo : function(oEvent){
		//Preserve previous value for the case of canceling changes
		this.DateToUTCValue = oEvent.getSource().mProperties.value;
		this.dateToUTC = i2d.qm.qualityissue.confirm.utils.Helper.convertToISODateTime(oEvent.getSource().mProperties.dateValue);
		this.invalidDateTo = oEvent.mParameters.invalidValue && !($.isBlank(oEvent.mParameters.newValue));
		this.setDateFilterCount();
	},
	
	onResetFilterDialog : function(oEvent){
		//Because the Date filter is constructed via custom controls, the date pickers and the filter counter are manually reset
		this.DateFromUTCValue = null;
		this.DateToUTCValue = null;
		this.dateFromUTC = null;
		this.dateToUTC = null;
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.resetFilterDialogDateFilter();
	},
	
	shouldCreateDateFilterObject : function(){
		
		//If both dates are blank at the same time, no date filter object should be created 
		if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)){
			return false;
		}
	
		//Check if any of the dates should be set to its default value 
		if ($.isBlank(this.dateFromUTC)){
			this.dateFromUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate;
			return true;
		}
		
		if ($.isBlank(this.dateToUTC)){
			this.dateToUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate;
		}
		
		return true;
	}, 
	
	setDateFilterCount : function(){
		
		if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)){
			i2d.qm.qualityissue.confirm.utils.FragmentHelper.setFilterDialogDateFilterCount(0);
			return;
		}
		
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.setFilterDialogDateFilterCount(1);
	},
	
	onSort : function(oEvent){
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.openSortDialog(this);
	},
	
	onConfirmSortDialog : function(oEvent){

		var parameters = oEvent.getParameters();
		
		//If no no sorted item was selected, return
		if(!parameters.sortItem){
			return;
		}
		
		var sorter = parameters.sortItem.getCustomData()[0].getValue().sorter;
		
		if(!sorter){
			return;
		}
		
		//The event parameter for descending is true/false according to the user selection of Ascending/Descending on the popup
		sorter.bDescending = parameters.sortDescending;
		this.getList().getBinding("items").sort(sorter);
	},
	
	onConfirmCustSettingsDialog : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getAggregation("content")[0];
		
		//Check the value state of IssueNumber input
		if (elementContainer.getId() === "CustomSettingsIssuesNumber" && elementContainer.getContent()[1].getValueState() === sap.ui.core.ValueState.Error){
			return; //The state is error, thus return the focus of the IssueNumber input
		}
		
		var updateLocalStorage = false;
		
		if (this.changedMaxHits > 0 && this.objSettings.maxHits !== this.changedMaxHits){
			this.objSettings.maxHits = this.changedMaxHits;
			this.handleRefresh();
			updateLocalStorage = true;
		}
		
		if (this.changedPlantIndex > -1 && this.objSettings.selectedPlantIndex !== this.changedPlantIndex){
			this.objSettings.defPlant 			= this.changedPlant; 
			this.objSettings.selectedPlantIndex	= this.changedPlantIndex;
			updateLocalStorage 					= true;
		}
		
		if (updateLocalStorage){
			localStorage.setObj(this.SETTINGS_NAME, this.objSettings);
		}
				
		this.closeCustSetDialog();
		
	},
	
	onCancelCustSettingsDialog : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getAggregation("content")[0];
		
		var cancelPlantSelection = function(oController){
			
			i2d.qm.qualityissue.confirm.utils.FragmentHelper.removePlantSelection();
			
			//Check if a plant was selected beforehand to cancel its selection
			if (oController.objSettings.selectedPlantIndex > -1){
				i2d.qm.qualityissue.confirm.utils.FragmentHelper.setDefaultPlantByIndex(oController.objSettings.selectedPlantIndex);
			}
			
		}; 
		
		switch(elementContainer.getId()){
		case "CustomSettingsIssuesNumber": //Cancel pressed from popup view with IssuesNumber input
			
			var issuesNumberInput = elementContainer.getContent()[1];
			issuesNumberInput.setValueState(sap.ui.core.ValueState.None);
			issuesNumberInput.setValueStateText("");
			cancelPlantSelection(this); //In case plant selection was changed beforehand
			break;
			
		case "CustomSettingsPlantsList": //Cancel pressed from popup view with Plants choices
			
			elementContainer.removeSelections(false);
			if (this.objSettings.selectedPlantIndex > -1){
				elementContainer.setSelectedItem(elementContainer.getItems()[this.objSettings.selectedPlantIndex]);
			}
			break;
			
		case "CustomSettingsList": //Cancel pressed from popup view with Settings list
			
			cancelPlantSelection(this);
			break;
			
		}
		
		this.closeCustSetDialog();
		
	},
	
	onCustSetDialogHeaderBack : function(oEvent){
		
		var elementContainer = oEvent.getSource().getParent().getParent().getAggregation("content")[0];
		
		if (elementContainer.getId() === "CustomSettingsIssuesNumber"){ //The Back button was pressed from the popup view with IssuesNumber input
			
			var issuesNumberInput = elementContainer.getContent()[1];
			
			if (issuesNumberInput.getValueState() === sap.ui.core.ValueState.Error ){
				return; //The state of the IssuesNumber input value is error, thus return the focus of the input anew
			}
			
			//Navigate back to the popup list with choices
			i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, issuesNumberInput.getValue());
		
		}else{ //The Back button was pressed from the popup view with plant lists
			
			//If the IssuesNumber was changed before selecting a plant, read it from changedMaxHits variable
			if (this.changedMaxHits){
				i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, this.changedMaxHits); //Navigate back to the popup list with choices
			}else{
				i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits); //Navigate back to the popup list with choices
			}
			
		}
		
	},
	
	onCustomSettingsIssues : function(oEvent){
		var maxHits = oEvent.getSource().getModel("maxHits").getData().maxHits;
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.loadCustSetIssuesNumber(this, maxHits);
	},
	
	onCustomSettingsPlant : function(oEvent){
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.loadCustSetPlantList(this);
	},
	
	onSelectCustomSettingsPlant : function(oEvent){
		var selectedPlant 		= oEvent.getParameter("listItem");
		this.changedPlant 		= selectedPlant.getProperty("title");
		this.changedPlantIndex 	= oEvent.getSource().indexOfItem(selectedPlant);
	},
	
	onLoadCustSettingsPlantList : function(oEvent){
		
		//Make initial plant selection, taken from the previous times, when the application was used and a plant was selected 
		if (this.objSettings.selectedPlantIndex > -1){
			oEvent.getSource().setSelectedItem(oEvent.getSource().getItems()[this.objSettings.selectedPlantIndex]);
			return;
		} 
		
		//The following each statement will be executed only once, when the application is started for first time, in order to select default plant from OData service, if any was received 
		$.each(oEvent.getSource().mAggregations.items, $.proxy(function(index, plant){
			if (plant.getProperty("title") === this.objSettings.defPlant){
				this.objSettings.selectedPlantIndex = index;
				oEvent.getSource().setSelectedItem(plant);
				return false; //Break out of the loop
			};
		}, this));
			
	},
	
	onSettingsPressed : function(oEvent){
		i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits);
	},
	
	onChangeCustSetIssueNumber : function(oEvent){

		//"Not-a-Number" input validation is made on parsing fragment level by the framework. In case of NaN, the value is set to empty string, thus it should be checked only for blank
		// CSS: 0000364969 2014. Framework validation for NaN does not work for Internet Explorer. Hence adding the check locally.
		if (isNaN(oEvent.getSource().getValue()) || $.isBlank(oEvent.getSource().getValue()) || oEvent.getSource().getValue() < 1){
			oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
			oEvent.getSource().setValueStateText(this.resourceBundle.getText("QI_INVALID_ERROR"));
		}else{
			oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			oEvent.getSource().setValueStateText("");
		}
		
		//Remove leading zeros and possible decimal places with radix 10
		this.changedMaxHits = parseInt(oEvent.getSource().getValue(), 10);
		
	}

});