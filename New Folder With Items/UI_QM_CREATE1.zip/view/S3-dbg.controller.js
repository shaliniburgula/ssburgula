/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.type.FileSize");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.InteropServiceHelper");

sap.ca.scfld.md.controller.BaseDetailController
		.extend(
				"i2d.qm.qualityissue.confirm.view.S3",
				{

					/**
					 * @override
					 * 
					 * Called by the UI5 runtime to init this controller
					 * 
					 */
					onInit : function() {
						// Execute onInit for the base class
						// BaseMasterController
       					 sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);

						var view = this.getView();
				        this.oRouter.attachRouteMatched(function(oEvent) {
				        if (oEvent.getParameter("name") === "detail") {
							var context = new sap.ui.model.Context(view.getModel(), '/' + oEvent.getParameter("arguments").contextPath);
							view.setBindingContext(context);
							// Make sure the master is here
							}
						}, this);
						
						// FIXME: this should not be needed but don't work if
						// not here
						this.getView().setModel(
								sap.ui.getCore().getModel("device"), "device");
						
						//init CrossApplicationNavigation object
						var fgetService =  sap.ushell && sap.ushell.Container && sap.ushell.Container.getService; 
						this.oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");
						// register method for the event fired when the refresh button on the list is pressed (or back end search is done)	
					    this.oApplicationFacade.registerOnMasterListRefresh(this.onMasterRefresh, this);
					},
					
					
					onMasterRefresh : function(oEvent){
					// this method is executed when refresh button on the list is pressed (or a back end search is done - currently, we have client search) 
					// it is needed in order to refresh the data in the attachments (if changes are done in the back end)	
						var attItems = this.byId("ATTACHMENTS").getBinding("items");
						// in case the data is loaded 
						if (!attItems.bPendingRequest){
							attItems._refresh();
						}					
					},
					
					
					getHeaderFooterOptions : function() { 
						return {
							bSuppressBookmarkButton : true				  
						};
					},
					
								    				    
					openBusinessCard : function(oEvent) {
						var oEmpData = {};

						// get control that triggeres the BusinessCard
						if (oEvent) {
							var oSource = oEvent.getSource();
							if (oSource) {
								var oContext = oSource.getBindingContext();
								var oModel = this.getView().getModel();
								if (oContext && oModel) {
									oEmpData = {
										name : oModel.getProperty(
												"PartnerName", oContext),
										imgurl : "sap-icon://person-placeholder",
										contactmobile : oModel.getProperty(
												"PartnerMobilePhone", oContext),
									    contactphone : oModel.getProperty(
												"PartnerWorkPhone", oContext),
										contactemail : oModel.getProperty(
												"PartnerEmail", oContext),
										companyname : oModel.getProperty(
												"PartnerCompany", oContext)
									};

									// call 'Business Card' reuse component
									var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(
											oEmpData);
									oEmployeeLaunch.openBy(oSource);
								}
							}
						}
					},
					navBack : function() {
					 window.history.back();
					},
					
					onListItemSelect : function(oEvnt) {
						
						var oSelection = oEvnt.getSource();						
						var oModel = this.getView().getModel();
						var oContext = oSelection.getBindingContext();
						var NotifNumber = oModel.getProperty("NotificationID", oContext);
						var DocNumber = oModel.getProperty("DocumentNumber", oContext);

						if ( NotifNumber && DocNumber )
						{
							i2d.qm.qualityissue.confirm.utils.Helper.getAttStream(NotifNumber, DocNumber);
						}
					},
					
					onNotificationPress : function(oEvnt) {

						var oLink = oEvnt.getSource();
						var NotifId = oLink.getText();
						var sHref = ( this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal(
								{ target : { semanticObject : "QualityNotification",
											 action : "displayFactSheet" }, 
											 params : { "QualityNotification" : NotifId } 
								})); 
						
						if (sHref) {
							//open factsheet in new window
							sap.m.URLHelper.redirect(sHref,true);
						} 
					},
					
					
					

				});