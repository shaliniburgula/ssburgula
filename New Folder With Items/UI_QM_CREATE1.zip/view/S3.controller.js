/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.type.FileSize");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.InteropServiceHelper");
sap.ca.scfld.md.controller.BaseDetailController.extend(
    "i2d.qm.qualityissue.confirm.view.S3", {
        onInit: function() {
            sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit
                .call(this);
            var v = this.getView();
            this.oRouter.attachRouteMatched(function(e) {
                if (e.getParameter("name") === "detail") {
                    var c = new sap.ui.model.Context(v.getModel(),
                        '/' + e.getParameter("arguments").contextPath
                    );
                    v.setBindingContext(c)
                }
            }, this);
            this.getView().setModel(sap.ui.getCore().getModel("device"),
                "device");
            var f = sap.ushell && sap.ushell.Container && sap.ushell.Container
                .getService;
            this.oCrossAppNavigator = f && f(
                "CrossApplicationNavigation");
            this.oApplicationFacade.registerOnMasterListRefresh(this.onMasterRefresh,
                this)
        },
        onMasterRefresh: function(e) {
            var a = this.byId("ATTACHMENTS").getBinding("items");
            if (!a.bPendingRequest) {
                a._refresh()
            }
        },
        getHeaderFooterOptions: function() {
            return {
                bSuppressBookmarkButton: true
            }
        },
        openBusinessCard: function(e) {
            var E = {};
            if (e) {
                var s = e.getSource();
                if (s) {
                    var c = s.getBindingContext();
                    var m = this.getView().getModel();
                    if (c && m) {
                        E = {
                            name: m.getProperty("PartnerName", c),
                            imgurl: "sap-icon://person-placeholder",
                            contactmobile: m.getProperty(
                                "PartnerMobilePhone", c),
                            contactphone: m.getProperty(
                                "PartnerWorkPhone", c),
                            contactemail: m.getProperty(
                                "PartnerEmail", c),
                            companyname: m.getProperty(
                                "PartnerCompany", c)
                        };
                        var o = new sap.ca.ui.quickoverview.EmployeeLaunch(
                            E);
                        o.openBy(s)
                    }
                }
            }
        },
        navBack: function() {
            window.history.back()
        },
        onListItemSelect: function(e) {
            var s = e.getSource();
            var m = this.getView().getModel();
            var c = s.getBindingContext();
            var N = m.getProperty("NotificationID", c);
            var D = m.getProperty("DocumentNumber", c);
            if (N && D) {
                i2d.qm.qualityissue.confirm.utils.Helper.getAttStream(N,
                    D)
            }
        },
        onNotificationPress: function(e) {
            var l = e.getSource();
            var N = l.getText();
            var h = (this.oCrossAppNavigator && this.oCrossAppNavigator
                .hrefForExternal({
                    target: {
                        semanticObject: "QualityNotification",
                        action: "displayFactSheet"
                    },
                    params: {
                        "QualityNotification": N
                    }
                }));
            if (h) {
                sap.m.URLHelper.redirect(h, true)
            }
        },
    });