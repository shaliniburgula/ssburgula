/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.ErrorDialog");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("i2d.qm.qualityissue.confirm.control.AddPicture");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("i2d.qm.qualityissue.confirm.view.S4", {
	/**
	 * Called by the UI5 runtime to init this controller
	 */
	onInit : function() {
		// Execute onInit for the base class
		// BaseMasterController
		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);

		// Retrieve the application bundle
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();

		// Listener for navigation
		this.isRoot = true;
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "fsS4") {
				this.isRoot = false;
			}
		}, this);
		
		this.colon = " : ";
		this.openingBracket = " (";
		this.closingBracket = ")";		

		this.oConnectionManager = sap.ca.scfld.md.app.Application.getImpl().getConnectionManager();

		// subscribe for opening issue form events
		var bus = sap.ui.getCore().getEventBus();
		this.appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
		bus.subscribe(this.appId, "OpenS4", this._openFromMV, this);
		
		bus.subscribe(this.appId, "DataLoaded", function() {
			this.getView().getModel().updateBindings(true);
		}, this);


        this.AddPictureCtrl = this.byId("AddPicturesCtrl");

		// Load the model from server
		var view = this.getView();
		jQuery.each(this.oConnectionManager.modelList, function(name, model) {
			if (name == "undefined") {
				view.setModel(model);
			} else {
				view.setModel(model, name);
			}
		});

		this.creationModel = new sap.ui.model.json.JSONModel({
			"/Attachment" : "",
			"/ShortText" : "",
			"/DefectCodeText" : "",
			"/ReferenceNumber" : "",
			"/NotifCodeText" : "",
			"/LongText" : ""
		});

		this.getView().setModel(this.creationModel, "creationModel");

		// Model for addPicture component
		this.pictureModel = new sap.ui.model.json.JSONModel({Pictures:[]});

		this.getView().setModel(this.pictureModel, "picture");

		this.changeMode = false; // true: CREATE is called by
		// history view

		this.oBusy = null;
		this.bSubmitOK = null; // ?
		this.oSubmitResult = {}; // ?
		this.oSubmitButton = this.byId("QI_SUBMIT");

		this.combineGetRequests();

		// handle data binding validation results
		sap.ui.getCore().attachValidationError(function(evt) {
			var element = evt.getParameter("element");
			if (element.setValueState) {
				element.setValueState(sap.ui.core.ValueState.Error);
			}
		});
		sap.ui.getCore().attachValidationSuccess(function(evt) {
			var element = evt.getParameter("element");
			if (element.setValueState) {
				element.setValueState(sap.ui.core.ValueState.None);
			}
		});
		
	    //the initialize the form vertical alignment 	
        this.bIsFormVAligned = false;
        
        this.oViewerView = new sap.ui.xmlview("viewer-view", "i2d.qm.qualityissue.confirm.view.Viewer");
        this.oViewerView.setHeight("100%");
        this.oViewerView.setModel(this.pictureModel,"picture");
        this.oViewerDialog = new sap.m.Dialog("viewer-dialog", {

            showHeader: false,
            content:[this.oViewerView],
            stretch: true,
            verticalScrolling: false,
            horizontalScrolling: false,
            contentHeight: "100%",
            contentWidth: "100%",
            endButton: new sap.m.Button({text:this.resourceBundle.getText("QI_CONFIRM_BTN"), press: jQuery.proxy(this.onPictureViewerClose, this)})
        });
        
        // bug with Dialog to calculate width & height of container
        // needs to trigger the rendering after the Dialog is actually opened
        var fnTrick = jQuery.proxy(function(){
            this.oViewerView.rerender();
        }, this);
        this.oViewerDialog.attachAfterOpen(fnTrick);

	},
	
	
	/**
     * Handler for close action
     */
    onPictureViewerClose : function () {
        this.oViewerDialog.close();
    },
    
    combineGetRequests : function() {
    	var SETTINGS_NAME = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName;		

		var objSettings = localStorage.getObj(SETTINGS_NAME);
    	// begin of Defect and Category logic
		// initialize variables, retrieve the data from the oData and fill the
		// models
		var itemTemplate = new sap.ui.core.Item({
			key : "{key}" + this.colon + "{catalogType}" + this.colon + "{codeGroup}",
			text : "{title}" + this.openingBracket + "{category}" + this.closingBracket,
			active : true
		});
		// Defect
		this.oDefectDialog = null;
		this.oDefectInput = this.byId("QI_DEFECT_SELECT");
		var arBatchConfig = [];
		var arDefectProperties = [
		    {output:"key", source:"DefectCode"},
			{output:"title", source:"DefectCodeText"},
			{output:"codeGroup", source:"DefectCodeGroup"},
			{output:"category", source:"DefectCodeGroupText"},
			{output:"catalogType", source:"DefectCatalogType"}
		];			
		arBatchConfig.push({indexCollection: 0, arConversionRules : arDefectProperties, itemsPrefix: "items"});
		
		var arNotifProperties = [
		               		    {output:"key", source:"NotifCode"},
		               			{output:"title", source:"NotifCodeText"},
		               			{output:"codeGroup", source:"NotifCodeGroup"},
		               			{output:"category", source:"NotifCodeGroupText"},
		               			{output:"catalogType", source:"NotifCatalogType"}
		               		];
		arBatchConfig.push({indexCollection: 1, arConversionRules : arNotifProperties, itemsPrefix: "items"});
		
		if ($.isBlank(objSettings)) {
			var settingsMapping = [
			                       {output:"maxHits", source:"MaxHits"},
			                       {output:"defPlant", source:"Plant"},
			                       {output:"maxFileSize", source:"MaxFileSize"}
			                       ];
			arBatchConfig.push({indexCollection: 3, arConversionRules : settingsMapping});
		}
		
		var batchResult = i2d.qm.qualityissue.confirm.utils.Helper.getCollection(arBatchConfig, this);
		var listData = batchResult && batchResult.length >0 && batchResult[0];
		var oModelList = new sap.ui.model.json.JSONModel();
		oModelList.setData(listData);
		this.oDefectInput.setModel(oModelList);
		this.oDefectInput.bindAggregation("suggestionItems", "/items", itemTemplate);

		this.selectedDefect = new sap.m.StandardListItem({
			key : "{key}",
			codeGroup : "{codeGroup}",
			category : "{category}",
			title : "{title}",
			catalogType : "{catalogType}",
			active : true
		});
		
		// Category
		this.oCategoryDialog = null;
		this.oCatInput = this.byId("QI_CATEGORY_SELECT");
		
		// listData is already defined
		listData = batchResult && batchResult.length >0 && batchResult[1];
		oModelList = new sap.ui.model.json.JSONModel();
		oModelList.setData(listData);
		this.oCatInput.setModel(oModelList);
		this.oCatInput.bindAggregation("suggestionItems", "/items", itemTemplate);

		this.selectedCategory = new sap.m.StandardListItem({
			key : "{key}",
			codeGroup : "{codeGroup}",
			category : "{category}",
			title : "{title}",
			catalogType : "{catalogType}",
			active : true
		});
		// end of Defect and Category logic
		
		//handle settings values
		
		if ($.isBlank(objSettings)) {
			objSettings = batchResult && batchResult.length >0 && batchResult[2][0];
			// store the object into local Storage for future usage
			localStorage.setObj(SETTINGS_NAME, objSettings);
		}
		
    },
	
	/**
     * Called by the UI5 runtime to cleanup this controller
     */

	onExit : function () {

		// destroy the control if needed
		if (this.oCategoryDialog) {
			try {
				this.oCategoryDialog.destroy();
				this.oCategoryDialog = null;
			}
			catch (e){
				
			}
			
		}
		// destroy the control if needed
		if (this.oDefectDialog) {
			try{
				this.oDefectDialog.destroy();
				this.oDefectDialog = null;
			}
			catch (e){
				
			}
			
		}
		
		if (this.oViewerDialog) {
			try{
				this.oViewerDialog.destroy();
				this.oViewerDialog = null;
			}
			catch (e){
				
			}
			
		}
		if (this.oViewerView) {
			try{
				this.oViewerView.destroy();
				this.oViewerView = null;
			}
			catch (e){
				
			}
			
		}
		
		if (this.creationModel)
	    {
			try{
				this.creationModel.destroy();
				this.creationModel = null;
			}
			catch (e){
				
			}
	    }
		
		if (this.pictureModel)
	    {
			try{
				this.pictureModel.destroy();
				this.pictureModel = null;
		    }
			catch (e){
				
			}
	    }
		
		if (this.selectedDefect)
	    {
			try{
				this.selectedDefect.destroy();
				this.selectedDefect = null;
		    }
			catch (e){
				
			}
	    }
		
		if (this.selectedCategory)
	    {
			try{
				this.selectedCategory.destroy();
				this.selectedCategory = null;
		    }
			catch (e){
				
			}
	    }
		
		if (this.oBusy)
	    {
			try{
				this.oBusy.destroy();
				this.oBusy = null;
		    }
			catch (e){
				
			}
	    }
		
	},

	_openFromMV : function(sChannelId, sEventId, oData) {
		this._context = oData.context;
	},
	/**
	 * @override
	 * 
	 * @param oItem
	 * @param sFilterPattern
	 * @returns {*}
	 */

	applySearchPatternToListItem : function(oItem, sFilterPattern) {

		if (sFilterPattern.substring(0, 1) === "#") {
			var sTail = sFilterPattern.substr(1);
			var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
			return sDescr.indexOf(sTail) === 0;
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem, sFilterPattern);
		}

	},

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 */

	onBack : function(oEvt) {
		// standard back navigation with event bus
		var oBus = sap.ui.getCore().getEventBus();
		oBus.publish("nav", "back");
	},

	onSend : function(evt) {
		if (this.submit(true)) {
			// On submit, disable the submit button for next pass - This is done via resetting the selectedDefect.
			this.selectedDefect = null;
			// reset of the model
			this.cleanModel();
		}
	},
	
	confirmDefectSelectDialog : function(evt) {
		var selectedItem = evt.getParameter("selectedItem");
		var oInput = ("DefectSelectDialog" === evt.getSource().sId) ? this.oDefectInput : this.oCatInput;

		if (selectedItem) {
			oInput.setValue(selectedItem.getTitle());
			// In case there was an error before, clear it
			oInput.setValueState(sap.ui.core.ValueState.None);
			// set the selection in a variable in order to use it in submit
			// TODO: DO NOT use 'undefined'. Should use something like getsPath().
			var position = selectedItem.oBindingContexts.undefined.sPath.split("/");
			var index = position[position.length - 1];
			var selectedValues = selectedItem.oBindingContexts.undefined.oModel.oData.items[index];
			if (oInput === this.oCatInput) {
				this.selectedCategory = selectedValues;
			}else {
				this.selectedDefect = selectedValues;
			}	
			this.onCheckEnableSubmit();
		}
	},
	
	cancelDefectSelectDialog : function(evt) {
		this.onCheckEnableSubmit();
	},
	
	searchDefect : function(oEvent) {
		var sVal = oEvent.getParameter("value");
		if (sVal !== undefined) {
			this.filterDialog(sVal, oEvent.getSource().getBinding("items"));
		}
	},
	
	setInitialFilter : function(filterValueTxt, oSelectDialog) {
		// In case the F4 help is open after value suggestion, use only the title of the defect (the value suggestion is a combination of defect and group)
		filterValueTxt = filterValueTxt.split(this.openingBracket)[0];
		
		// Open the dialog
		oSelectDialog.open(filterValueTxt);
		var itemsDialog = oSelectDialog.getBinding("items");
		if (!$.isBlank(filterValueTxt))
		{
			this.filterDialog(filterValueTxt, itemsDialog);
		}
		//If there was a filter applied but now the value was reset filter on empty value to show all items
		else if (filterValueTxt === "" && itemsDialog.aFilters.length > 0 )
		{
			this.filterDialog(filterValueTxt, itemsDialog);
		}
	},

	onDefectSelect : function(evt) {
		// Create dialog if does not exist
	    if (!this.oDefectDialog) {
	        this.oDefectDialog = i2d.qm.qualityissue.confirm.utils.FragmentHelper.createF4HelpSelectDialog(this, "DefectSelectDialog", this.oDefectInput.getModel()); 
	    }	     
	    
	    this.setInitialFilter(evt.getSource()._lastValue, this.oDefectDialog);

	},

	onCategorySelect : function(evt) {
		// Create dialog if does not exist
	    if (!this.oCategoryDialog) {
	        this.oCategoryDialog = i2d.qm.qualityissue.confirm.utils.FragmentHelper.createF4HelpSelectDialog(this, "CategorySelectDialog", this.oCatInput.getModel());
	    }	     
	    
	    this.setInitialFilter(evt.getSource()._lastValue, this.oCategoryDialog);
	},	

	filterDialog : function(sVal, itemsBinding) {
		var filter = [];
		// create the local filter to apply
		var selectFilter = new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, sVal);
		filter.push(selectFilter);
		// and apply the filter to the bound items, and the Select Dialog
		// will update
		itemsBinding.filter(filter);
	},

	onSuggest : function(oEvent) {
		var sVal = oEvent.getParameter("suggestValue");
		if (sVal !== undefined) {
			this.filterDialog(sVal, oEvent.getSource().getBinding("suggestionItems"));
			// with new search, clear the previous selection
			if (oEvent.getSource() === this.oCatInput) {
				this.selectedCategory = "";
			} else {
				this.selectedDefect = "";
			}
			// In case there was an error before, clear it
			oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
		}
		
	},

	onSuggestionItemSelected : function(oEvent) {
		// set selected value
		var sVal = oEvent.getParameter("selectedItem");
		if (sVal !== undefined) {
			var temp = new sap.m.StandardListItem({
				key : "{key}",
				codeGroup : "{codeGroup}",
				category : "{category}",
				title : "{title}",
				catalogType : "{catalogType}"
			});
			var params = sVal.mProperties.key.split(this.colon);
			temp.key = params[0];
			temp.catalogType = params[1];
			temp.codeGroup = params[2];
			params = sVal.mProperties.text.split(this.openingBracket);
			temp.title = params[0];
			temp.category = params[1].split(this.closingBracket)[0];

			if (oEvent.getSource() === this.oCatInput) {
				this.selectedCategory = temp;
			} else {
				this.selectedDefect = temp;
			}
			// in case the device is phone, there is no live change event
			// not sure for tablet, currently the app is not working there
			if(jQuery.device.is.phone || jQuery.device.is.tablet) {
			    this.onCheckEnableSubmit();
			}			
		}
	},

	onValidation : function() {
		var result = false;
		// mandatory fields check
		result = this.checkMandatoryFields([ "QI_SUBJECT_INPUT", "QI_DEFECT_SELECT" ], this);
		// In case all mandatory fields are filled, check if the input is
		// correct
		if (result)
			result = this.checkValidInput();

		return result;
	},

	checkValidInput : function() {
		var result = true;
		// Check if the defect is not a free text
		if (this.selectedDefect === "" && this.oDefectInput.getValue() !== "") {
			this.oDefectInput.setValueState(sap.ui.core.ValueState.Error);
			this.oDefectInput.setValueStateText(this.resourceBundle.getText("QI_INVALID_ERROR")), 
			result = false;
		} else {
			this.oDefectInput.setValueState(sap.ui.core.ValueState.None);
		}
		// Check if the category is not a free text
		if (this.selectedCategory === "" && this.oCatInput.getValue() !== "") {
			this.oCatInput.setValueState(sap.ui.core.ValueState.Error);
			this.oCatInput.setValueStateText(this.resourceBundle.getText("QI_INVALID_ERROR")),
			result = false;
		} else {
			this.oCatInput.setValueState(sap.ui.core.ValueState.None);
		}
		
		return result;
	},

	submit : function(isSimulation) {
		if (!this.oBusy) {
			this.oBusy = new sap.m.BusyDialog();
		}
		this.oBusy.open();
		
		if (this.onValidation() === false) {
			this.oBusy.close();
			return false;
		}	
			
		var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
		var plant = localStorage.getObj(oAppConfig.getParams().settingsName).defPlant;
		
		// process attachments		
		var Base64Start = ";base64,";
		var AttBase64Body, iPos;
		var arOData = [];
		var arPictures = this.byId("AddPicturesCtrl").getPictures();
		var objOData = null;
		
		for(var i=0;i<arPictures.length;i++) {
			// get the picture Base64 encoded body and remove starting chars
			AttBase64Body = arPictures[i].getSource();
			iPos = AttBase64Body.indexOf(Base64Start);
			if (iPos > -1) {
				AttBase64Body = AttBase64Body.substr(iPos + Base64Start.length);
			}
			objOData = {
					NotificationID 				: "1",
					DocOrigin					: arPictures[i].getName(),
					DocData						: AttBase64Body
					
			};
			arOData.push(objOData);				
		}
		
		var categoryValue = this.oCatInput.getValue();
		objOData = {
				NotificationID 	: "1",
				ShortText		: this.byId("QI_SUBJECT_INPUT").getValue(),
				ReferenceNumber : this.byId("QI_REFERENCE_NUMBER_INPUT").getValue(),
				LongText		: this.byId("QI_DESCRIPTION_INPUT").getValue(),
				NotifCode		: (!$.isBlank(categoryValue) && this.selectedCategory.key) ? this.selectedCategory.key : "",
				NotifCodeGroup	: (!$.isBlank(categoryValue) && this.selectedCategory.codeGroup) ? this.selectedCategory.codeGroup : "",
				NotifCatalogType: (!$.isBlank(categoryValue) && this.selectedCategory.catalogType) ? this.selectedCategory.catalogType : "",
				DefectCode		: (this.selectedDefect.key) ? this.selectedDefect.key : "", 
				DefectCodeGroup : (this.selectedDefect.codeGroup) ? this.selectedDefect.codeGroup : "", 
				DefectCatalogType : (this.selectedDefect.catalogType) ? this.selectedDefect.catalogType : "", 
				Plant			: plant ? plant : ""					
				};
		
		if (arOData.length > 0) {
			// add attachments
			objOData[oAppConfig.getServiceList()[0].QIAttachmentsCreate] = arOData;
		}
		
		
		var result = i2d.qm.qualityissue.confirm.utils.Helper.processChangeOperation(oAppConfig.getServiceList()[0].createCollection, oAppConfig.getParams().HTTP_Method.POST, objOData, this);
		
		var NotifId = result && result.NotificationID;
		var notifSubmitted = true;
		this.oBusy.close();
		if (NotifId) {		
			
			var validationMessage = this.resourceBundle.getText("QI_TXT_VALIDATION");
			sap.m.MessageToast.show(validationMessage);
			//navigate to the list
			this.oRouter.navTo("master", {id: "create"});
		}
		else
		{
			notifSubmitted = false;
		}
		return notifSubmitted;				
	},

	onList : function(oEvnt) {
		// On Cancel, disable the Submit button for next pass. This is done via resetting the selectedDefect.
		this.selectedDefect = null;
		// reset of the model
		this.cleanModel();
		this.oRouter.navTo("master", {id: "list"});
	},

	onPictureClick : function(oEvnt) {
		var selectedImage = oEvnt.mParameters.pictureItem._oImage;
		this.showGallery(selectedImage);
	},

	/**
     * Needed for addpicture component : Creates the model which is passed to the PictureViewer page after navigation
     * @param selectedImage {object} sap.m.Image - the image that should be shown first
     * @private
     */
    showGallery : function (selectedImage) {

        // create model
        var images = [];
        var selectedImageIndex = 0;
        var gallery = this.AddPictureCtrl.getPictures();

        // loop through the pictures, add reference to sap.m.Images, get the index of image
        for (var i=0; i<gallery.length; i++) {
            images.push(gallery[i]._oImage);
            if (gallery[i]._oImage === selectedImage)
                selectedImageIndex = i;
        }

        this.oViewerView.byId("pictureViewer").setSelectedIndex(selectedImageIndex);
        this.oViewerDialog.open();

    },

    onPictureAdded: function(oEvent){
        var oItem = oEvent.getParameters().pictureItem;

        var aPictures = this.pictureModel.getData().Pictures || [];
        aPictures.push({source: oItem.getSource(), name: oItem.getName(), status: oItem.getStatus()});

        this.pictureModel.setData({Pictures: aPictures});

    },
	

	onMaxLimitReached : function(oEvnt) {
		var sMsg = this.resourceBundle.getText("QI_NO_MORE_IMAGES");
		sap.m.MessageToast.show(sMsg);
	},

	cleanModel : function() {
		var formElement = null;
		var arIDs = [ "QI_SUBJECT_INPUT", "QI_REFERENCE_NUMBER_INPUT", "QI_DESCRIPTION_INPUT", "QI_DEFECT_SELECT", "QI_CATEGORY_SELECT" ];
		for ( var i = 0; i < arIDs.length; i++) {
			formElement = this.byId(arIDs[i]);
			if (formElement)
				// clear the values and state (in case there was an error)   
				formElement.setValue("");  
			    formElement.setValueState(sap.ui.core.ValueState.None);
		}

		this.AddPictureCtrl.destroyPictures();
		this.oSubmitButton.setEnabled(false);
		this.pictureModel = new sap.ui.model.json.JSONModel({Pictures:[]});
		this.oViewerView.setModel(this.pictureModel,"picture");
		this.getView().setModel(this.pictureModel, "picture");
	},
	/**
	 * Check if the submit button must be enabled
	 */

	onCheckEnableSubmit : function(oEvent) {
		// if in desktop, disable Submit button when user deletes the defect while on the input field - This is accomplished via resetting the defect category.
		if(!jQuery.device.is.phone && !jQuery.device.is.tablet && this.selectedDefect!= undefined) {
			this.selectedDefect.category = "";
		}
		if (!this.byId("QI_SUBJECT_INPUT").getValue().length == 0 && (!this.byId("QI_DEFECT_SELECT").getValue().length == 0 || (this.selectedDefect!= undefined && this.selectedDefect.category != undefined && this.selectedDefect.category !=null && this.selectedDefect.category !=""))) {
			// Enable the button when all mandatory fields are not empty
			this.oSubmitButton.setEnabled(true);
		} else
			this.oSubmitButton.setEnabled(false);
	},
    /**
	 * sets the form labels in the middle vertical alignement of their
	 * related input field 
	 */
	onAfterRendering : function() {
		var form = this.getView().byId("form");
		if (form) { // !this.bIsFormVAligned && so we update the dom once
			var items = form.getContent();
			var sControlId, oControl, iCalculatedHeight;
			for (var i = 0; i < items.length; i++) {
                if (items[i] instanceof sap.m.Label) {
                    //find related control
                    sControlId = items[i].getLabelFor();
                    if (sControlId) {
                        oControl = this.getView().byId(sControlId);

                        if (oControl && oControl.getVisible && oControl.getVisible()) {
                            //first: inner padding+margin from the div wrapper (parent) and the html control itself (first children)
                            iCalculatedHeight = Math.ceil(oControl.$().children().first().offset().top - oControl.$().parent().offset().top);

                            if (oControl instanceof sap.m.TextArea) {
                                //then either: only text - label alignment
                                iCalculatedHeight += parseInt(oControl.$().children().first().css("padding-top"));
                                items[i].$().css("margin-top", iCalculatedHeight+"px");
                            }
                            else if (oControl instanceof sap.m.Input){
                                //then or: full vertical alignment
                                iCalculatedHeight += 4; //borders
                                iCalculatedHeight += oControl.$().height();

                                items[i].$().parent().css("line-height", iCalculatedHeight + "px"); //vertical alignment
                                items[i].$().css("vertical-align", "middle");
                            }                           
                            
                        }
                    }
                }
            }

			this.bIsFormVAligned = true;
		}

	},	
	
	navBack : function() {
		 window.history.back();
	},
	
	checkMandatoryFields : function(arElIDs, oController) {
		var oFormElement = null;
		var result = true;

		for ( var i = 0; i < arElIDs.length; i++) {
			// find the corr. element
			oFormElement = oController.byId(arElIDs[i]);
			if (oFormElement) {
				// get value for text elements
				if (oFormElement.getValue() === "") {
					// set the state to false
					result = false;
					if (oFormElement.setValueState) {
						oFormElement.setValueState(sap.ui.core.ValueState.Error);
						oFormElement.setValueStateText(this.resourceBundle.getText("QI_DESC_ERROR"));
						result = false;
					}
				} else {
					// set to default ValueState
					if (oFormElement.setValueState) {
						oFormElement.setValueState(sap.ui.core.ValueState.None);
					}
				}
			}
		}
		return result;
	},
	
	/**
     * This function is called when AddPicture control throws an event that indicates that the file being
     * uploaded is not supported. It then warns the user with error message.
     */
	onFileNotSupported :  function(oEvnt) {
		
		var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		var message = oBundle.getText("QI_FILE_TYPE_NOT_SUPPORTED");
		i2d.qm.qualityissue.confirm.utils.ErrorDialog(message);	      
	},

});
