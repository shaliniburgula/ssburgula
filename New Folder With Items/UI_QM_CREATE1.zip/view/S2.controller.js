/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
jQuery.sap.require("sap.m.DatePicker");
jQuery.sap.require("sap.ca.scfld.md.app.MasterHeaderFooterHelper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");
sap.ca.scfld.md.controller.ScfldMasterController.extend(
    "i2d.qm.qualityissue.confirm.view.S2", {
        onInit: function() {
            sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit
                .call(this);
            this.oMasterModel = new sap.ui.model.json.JSONModel({
                selectedFilter: "All",
                selectedSorter: "CreatedOn",
                toogleSubmit: false
            });
            this.getView().setModel(this.oMasterModel, "masterModel");
            this.resourceBundle = this.oApplicationFacade.getResourceBundle();
            this.oSettingsDialog = null;
            this.SETTINGS_NAME = sap.ca.scfld.md.app.Application.getImpl()
                .oConfiguration.getParams().settingsName;
            this.objSettings = localStorage.getObj(this.SETTINGS_NAME);
            if (this.objSettings.maxHits) {
                this.objSettings.maxHits = parseInt(this.objSettings.maxHits,
                    10);
                if (isNaN(this.objSettings.maxHits)) {
                    jQuery.sap.log.error(
                        "Error with data, please check consistency of record. Default 30 issues displayed."
                    );
                    this.objSettings.maxHits = '30'
                }
            }
            if ($.isBlank(this.objSettings)) {
                var s = [{
                    output: "maxHits",
                    source: "MaxHits"
                }, {
                    output: "defPlant",
                    source: "Plant"
                }, {
                    output: "maxFileSize",
                    source: "MaxFileSize"
                }];
                var b = i2d.qm.qualityissue.confirm.utils.Helper.getCollection(
                    [{
                        indexCollection: 3,
                        arConversionRules: s
                    }], this);
                this.objSettings = b && b.length > 0 && b[0];
                localStorage.setObj(this.SETTINGS_NAME, this.objSettings)
            }
            this.setMaxHitsToList();
            this._showLoadingText(true);
            var a = sap.ui.getCore().getEventBus();
            a.subscribe(sap.ca.scfld.md.app.Application.getImpl().oConfiguration
                .getAppIdentifier(), "RefreshDetail", this.handleRefresh,
                this);
            var l = this.getList();
            l.attachUpdateFinished(this.handleUpdateFinished, this);
            var t = l.getItems()[0].clone();
            l.bindItems("/QMNotificationSelectionSet", t);
            this.aFilterBy = [];
            this.dateFromUTC;
            this.dateToUTC;
            this.DateFromUTCValue;
            this.DateToUTCValue;
            this.previousDateFromUTC;
            this.previousDateToUTC;
            this.closeCustSetDialog = function() {
                this.changedMaxHits = undefined;
                this.changedPlant = undefined;
                this.changedPlantIndex = undefined;
                i2d.qm.qualityissue.confirm.utils.FragmentHelper.closeCustSetDialog()
            };
            this.oRouter.attachRouteMatched(function(e) {
                if (e.getParameter("name") === "masterDetail" &&
                    e.getParameter("arguments").id === "create" &&
                    this.getList().getSelectedItem()) {
                    this.handleRefresh()
                }
            }, this)
        },
        navToEmptyView: function() {
            this.showEmptyView("DETAIL_TITLE", "NO_ITEMS_AVAILABLE")
        },
        _showLoadingText: function(l) {
            if (l) {
                this.getList().setNoDataText(this.resourceBundle.getText(
                    "QI_LOADING_TEXT"))
            } else {
                this.getList().setNoDataText(this.resourceBundle.getText(
                    "QI_NO_DATA_AVAILABLE"))
            }
        },
        handleUpdateFinished: function(c) {
            if (!jQuery.device.is.phone && (c.getParameters().reason ===
                "Filter" || c.getParameters().reason === "Change" ||
                c.getParameters().reason === "Refresh" || c.getParameters()
                .reason === "Binding")) {
                if (this.oRouter._oRouter._prevMatchedRequest ===
                    "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {
                    this.getList().removeSelections()
                }
                if (this.getList().getItems().length == "0") {
                    this._showLoadingText(false)
                } else {
                    this._showLoadingText(true)
                }
            }
        },
        handleRefresh: function() {
            this.setMaxHitsToList();
            this.getList().removeSelections();
            this.getList().getBinding("items")._refresh()
        },
        getHeaderFooterOptions: function() {
            return {
                sI18NMasterTitle: "QI_TITLE_MASTER_VIEW",
                buttonList: [],
                aAdditionalSettingButtons: [{
                    sId: "Settings",
                    sI18nBtnTxt: "QI_MV_SETTINGS",
                    sIcon: "sap-icon://wrench",
                    onBtnPressed: jQuery.proxy(function(e) {
                        this.onSettingsPressed()
                    }, this)
                }],
                oFilterOptions: {
                    onFilterPressed: $.proxy(this.onFilter, this)
                },
                oSortOptions: {
                    onSortPressed: $.proxy(this.onSort, this)
                },
                onAddPress: jQuery.proxy(function(e) {
                    this.onCreate();
                    jQuery.sap.log.info("add pressed")
                }, this)
            }
        },
        setMaxHitsToList: function() {
            var m = this.getList().getModel();
            m.setCountSupported(false);
            m.setSizeLimit(this.objSettings.maxHits)
        },
        applySearchPatternToListItem: function(i, f) {
            if (i.isSelectable()) {
                if (f.substring(0, 1) === "#") {
                    var t = f.substr(1);
                    var d = i.getBindingContext().getProperty("Name").toLowerCase();
                    return d.indexOf(t) === 0
                } else {
                    return sap.ca.scfld.md.controller.ScfldMasterController
                        .prototype.applySearchPatternToListItem.call(
                            null, i, f)
                }
            }
        },
        isLiveSearch: function() {
            this.getList().setNoDataText(this.resourceBundle.getText(
                "QI_NO_DATA_AVAILABLE"));
            return false
        },
        onExit: function() {
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroySortDialog();
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroyFilterDialog();
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroyCustSetDialog();
            if (this.oMasterModel) {
                this.oMasterModel.destroy();
                this.oMasterModel = null
            }
            var l = sap.ui.getCore().byId(this.getView().sId +
                "--footer");
            if (l && l.destroy) {
                l.destroy()
            }
        },
        setInfoLabel: function(r, t, i, f) {
            if (i === null) i = true;
            this.oMasterModel.setProperty('/toogleSubmit', i);
            if (i === false) return;
            var l = this.getView().byId("labelTB");
            var a = "";
            if (t) a = this.resourceBundle.getText(t);
            else a = f;
            var t = this.resourceBundle.getText(r, [a]);
            l.setText(t);
            l.setTooltip(t)
        },
        setFilterInfoLabel: function(a) {
            if (!$.isArray(a) || a.length < 1) {
                this.setInfoLabel('', '', false, '');
                return
            }
            var i = "",
                r = this.resourceBundle.getText("QI_REPORT_ON"),
                s = this.resourceBundle.getText("QI_STATUS_TEXT");
            $.each(a, function(b, f) {
                if (i2d.qm.qualityissue.confirm.utils.Helper.isValidDate(
                    f.oValue1)) {
                    if (f.oValue1 === sap.ca.scfld.md.app.Application
                        .getImpl().oConfiguration.getParams().filterDialogDefaultFromDate &&
                        f.oValue2 === sap.ca.scfld.md.app.Application
                        .getImpl().oConfiguration.getParams().filterDialogDefaultToDate
                    ) {
                        return false
                    }
                    f.oValue1 = f.oValue1.substring(0, 10);
                    f.oValue2 = f.oValue2.substring(0, 10);
                    i += r + ": " + f.oValue1 + ", " + f.oValue2
                } else if (f.oValue1) {
                    if (i.indexOf(s) === -1) {
                        i += s + ": " + i2d.qm.qualityissue.confirm
                            .utils.StatusHelper.getStatusText(f
                                .oValue1)
                    } else {
                        i += ", " + i2d.qm.qualityissue.confirm
                            .utils.StatusHelper.getStatusText(f
                                .oValue1)
                    }
                }
            });
            i += ";";
            this.setInfoLabel("QI_FILTERED_BY", null, true, i)
        },
        onCreate: function() {
            this.oRouter.navTo("fsS4")
        },
        onFilter: function(e) {
            this.aFilterBy = [];
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.openFilterDialog(
                this)
        },
        onConfirmFilterDialog: function(e) {
            this._showLoadingText(true);
            var p = e.getParameters();
            if (this.invalidDateTo || this.invalidDateFrom) {
                this.setInfoLabel("QI_INVALID_DATES_ERROR", null, true,
                    null);
                this._showLoadingText(false);
                return
            }
            if ((new Date(this.dateToUTC)).getTime() < (new Date(this.dateFromUTC)
                .getTime())) {
                this.setInfoLabel("QI_TO_DATE_AFTER_FROM_DATE_ERROR",
                    null, true, null);
                this._showLoadingText(false);
                return
            }
            $.each(p.filterItems, $.proxy(function(i, f) {
                if (f.sId === "StatusNew" || f.sId ===
                    "StatusInProcess" || f.sId ===
                    "StatusCompleted" || f.sId ===
                    "StatusPostponed") {
                    this.aFilterBy.push(f.getCustomData()[0]
                        .getValue().filters)
                }
            }, this));
            if (this.shouldCreateDateFilterObject()) {
                this.aFilterBy.push(new sap.ui.model.Filter("CreatedOn",
                    sap.ui.model.FilterOperator.BT, this.dateFromUTC,
                    this.dateToUTC))
            }
            if (this.dateFromUTC === sap.ca.scfld.md.app.Application.getImpl()
                .oConfiguration.getParams().filterDialogDefaultFromDate
            ) {
                this.dateFromUTC = null
            }
            if (this.dateToUTC === sap.ca.scfld.md.app.Application.getImpl()
                .oConfiguration.getParams().filterDialogDefaultToDate) {
                this.dateToUTC = null
            }
            this.getList().getBinding("items").filter(this.aFilterBy);
            this.setFilterInfoLabel(this.aFilterBy);
            this.previousDateFromUTC = this.DateFromUTCValue;
            this.previousDateToUTC = this.DateToUTCValue
        },
        onCancelFilterDialog: function(e) {
            this.DateFromUTCValue = this.previousDateFromUTC;
            this.DateToUTCValue = this.previousDateToUTC;
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.resetFilterDialogDateFilter(
                this.previousDateFromUTC, this.previousDateToUTC)
        },
        onChangeDateFrom: function(e) {
            this.DateFromUTCValue = e.getSource().mProperties.value;
            this.dateFromUTC = i2d.qm.qualityissue.confirm.utils.Helper
                .convertToISODateTime(e.getSource().mProperties.dateValue);
            this.invalidDateFrom = e.mParameters.invalidValue && !($.isBlank(
                e.mParameters.newValue));
            this.setDateFilterCount()
        },
        onChangeDateTo: function(e) {
            this.DateToUTCValue = e.getSource().mProperties.value;
            this.dateToUTC = i2d.qm.qualityissue.confirm.utils.Helper.convertToISODateTime(
                e.getSource().mProperties.dateValue);
            this.invalidDateTo = e.mParameters.invalidValue && !($.isBlank(
                e.mParameters.newValue));
            this.setDateFilterCount()
        },
        onResetFilterDialog: function(e) {
            this.DateFromUTCValue = null;
            this.DateToUTCValue = null;
            this.dateFromUTC = null;
            this.dateToUTC = null;
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.resetFilterDialogDateFilter()
        },
        shouldCreateDateFilterObject: function() {
            if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)) {
                return false
            }
            if ($.isBlank(this.dateFromUTC)) {
                this.dateFromUTC = sap.ca.scfld.md.app.Application.getImpl()
                    .oConfiguration.getParams().filterDialogDefaultFromDate;
                return true
            }
            if ($.isBlank(this.dateToUTC)) {
                this.dateToUTC = sap.ca.scfld.md.app.Application.getImpl()
                    .oConfiguration.getParams().filterDialogDefaultToDate
            }
            return true
        },
        setDateFilterCount: function() {
            if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)) {
                i2d.qm.qualityissue.confirm.utils.FragmentHelper.setFilterDialogDateFilterCount(
                    0);
                return
            }
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.setFilterDialogDateFilterCount(
                1)
        },
        onSort: function(e) {
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.openSortDialog(
                this)
        },
        onConfirmSortDialog: function(e) {
            var p = e.getParameters();
            if (!p.sortItem) {
                return
            }
            var s = p.sortItem.getCustomData()[0].getValue().sorter;
            if (!s) {
                return
            }
            s.bDescending = p.sortDescending;
            this.getList().getBinding("items").sort(s)
        },
        onConfirmCustSettingsDialog: function(e) {
            var a = e.getSource().getParent().getAggregation("content")[
                0];
            if (a.getId() === "CustomSettingsIssuesNumber" && a.getContent()[
                1].getValueState() === sap.ui.core.ValueState.Error) {
                return
            }
            var u = false;
            if (this.changedMaxHits > 0 && this.objSettings.maxHits !==
                this.changedMaxHits) {
                this.objSettings.maxHits = this.changedMaxHits;
                this.handleRefresh();
                u = true
            }
            if (this.changedPlantIndex > -1 && this.objSettings.selectedPlantIndex !==
                this.changedPlantIndex) {
                this.objSettings.defPlant = this.changedPlant;
                this.objSettings.selectedPlantIndex = this.changedPlantIndex;
                u = true
            }
            if (u) {
                localStorage.setObj(this.SETTINGS_NAME, this.objSettings)
            }
            this.closeCustSetDialog()
        },
        onCancelCustSettingsDialog: function(e) {
            var a = e.getSource().getParent().getAggregation("content")[
                0];
            var c = function(C) {
                i2d.qm.qualityissue.confirm.utils.FragmentHelper.removePlantSelection();
                if (C.objSettings.selectedPlantIndex > -1) {
                    i2d.qm.qualityissue.confirm.utils.FragmentHelper
                        .setDefaultPlantByIndex(C.objSettings.selectedPlantIndex)
                }
            };
            switch (a.getId()) {
                case "CustomSettingsIssuesNumber":
                    var i = a.getContent()[1];
                    i.setValueState(sap.ui.core.ValueState.None);
                    i.setValueStateText("");
                    c(this);
                    break;
                case "CustomSettingsPlantsList":
                    a.removeSelections(false);
                    if (this.objSettings.selectedPlantIndex > -1) {
                        a.setSelectedItem(a.getItems()[this.objSettings
                            .selectedPlantIndex])
                    }
                    break;
                case "CustomSettingsList":
                    c(this);
                    break
            }
            this.closeCustSetDialog()
        },
        onCustSetDialogHeaderBack: function(e) {
            var a = e.getSource().getParent().getParent().getAggregation(
                "content")[0];
            if (a.getId() === "CustomSettingsIssuesNumber") {
                var i = a.getContent()[1];
                if (i.getValueState() === sap.ui.core.ValueState.Error) {
                    return
                }
                i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(
                    this, i.getValue())
            } else {
                if (this.changedMaxHits) {
                    i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(
                        this, this.changedMaxHits)
                } else {
                    i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(
                        this, this.objSettings.maxHits)
                }
            }
        },
        onCustomSettingsIssues: function(e) {
            var m = e.getSource().getModel("maxHits").getData().maxHits;
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.loadCustSetIssuesNumber(
                this, m)
        },
        onCustomSettingsPlant: function(e) {
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.loadCustSetPlantList(
                this)
        },
        onSelectCustomSettingsPlant: function(e) {
            var s = e.getParameter("listItem");
            this.changedPlant = s.getProperty("title");
            this.changedPlantIndex = e.getSource().indexOfItem(s)
        },
        onLoadCustSettingsPlantList: function(e) {
            if (this.objSettings.selectedPlantIndex > -1) {
                e.getSource().setSelectedItem(e.getSource().getItems()[
                    this.objSettings.selectedPlantIndex]);
                return
            }
            $.each(e.getSource().mAggregations.items, $.proxy(function(
                i, p) {
                if (p.getProperty("title") === this.objSettings
                    .defPlant) {
                    this.objSettings.selectedPlantIndex = i;
                    e.getSource().setSelectedItem(p);
                    return false
                }
            }, this))
        },
        onSettingsPressed: function(e) {
            i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(
                this, this.objSettings.maxHits)
        },
        onChangeCustSetIssueNumber: function(e) {
            if (isNaN(e.getSource().getValue()) || $.isBlank(e.getSource()
                .getValue()) || e.getSource().getValue() < 1) {
                e.getSource().setValueState(sap.ui.core.ValueState.Error);
                e.getSource().setValueStateText(this.resourceBundle.getText(
                    "QI_INVALID_ERROR"))
            } else {
                e.getSource().setValueState(sap.ui.core.ValueState.None);
                e.getSource().setValueStateText("")
            }
            this.changedMaxHits = parseInt(e.getSource().getValue(), 10)
        }
    });