/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.ErrorDialog");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("i2d.qm.qualityissue.confirm.control.AddPicture");
sap.ca.scfld.md.controller.BaseFullscreenController.extend(
    "i2d.qm.qualityissue.confirm.view.S4", {
        onInit: function() {
            sap.ca.scfld.md.controller.BaseFullscreenController.prototype
                .onInit.call(this);
            this.resourceBundle = this.oApplicationFacade.getResourceBundle();
            this.isRoot = true;
            this.oRouter.attachRouteMatched(function(e) {
                if (e.getParameter("name") === "fsS4") {
                    this.isRoot = false
                }
            }, this);
            this.colon = " : ";
            this.openingBracket = " (";
            this.closingBracket = ")";
            this.oConnectionManager = sap.ca.scfld.md.app.Application.getImpl()
                .getConnectionManager();
            var b = sap.ui.getCore().getEventBus();
            this.appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration
                .getAppIdentifier();
            b.subscribe(this.appId, "OpenS4", this._openFromMV, this);
            b.subscribe(this.appId, "DataLoaded", function() {
                this.getView().getModel().updateBindings(true)
            }, this);
            this.AddPictureCtrl = this.byId("AddPicturesCtrl");
            var v = this.getView();
            jQuery.each(this.oConnectionManager.modelList, function(n,
                m) {
                if (n == "undefined") {
                    v.setModel(m)
                } else {
                    v.setModel(m, n)
                }
            });
            this.creationModel = new sap.ui.model.json.JSONModel({
                "/Attachment": "",
                "/ShortText": "",
                "/DefectCodeText": "",
                "/ReferenceNumber": "",
                "/NotifCodeText": "",
                "/LongText": ""
            });
            this.getView().setModel(this.creationModel, "creationModel");
            this.pictureModel = new sap.ui.model.json.JSONModel({
                Pictures: []
            });
            this.getView().setModel(this.pictureModel, "picture");
            this.changeMode = false;
            this.oBusy = null;
            this.bSubmitOK = null;
            this.oSubmitResult = {};
            this.oSubmitButton = this.byId("QI_SUBMIT");
            this.combineGetRequests();
            sap.ui.getCore().attachValidationError(function(e) {
                var a = e.getParameter("element");
                if (a.setValueState) {
                    a.setValueState(sap.ui.core.ValueState.Error)
                }
            });
            sap.ui.getCore().attachValidationSuccess(function(e) {
                var a = e.getParameter("element");
                if (a.setValueState) {
                    a.setValueState(sap.ui.core.ValueState.None)
                }
            });
            this.bIsFormVAligned = false;
            this.oViewerView = new sap.ui.xmlview("viewer-view",
                "i2d.qm.qualityissue.confirm.view.Viewer");
            this.oViewerView.setHeight("100%");
            this.oViewerView.setModel(this.pictureModel, "picture");
            this.oViewerDialog = new sap.m.Dialog("viewer-dialog", {
                showHeader: false,
                content: [this.oViewerView],
                stretch: true,
                verticalScrolling: false,
                horizontalScrolling: false,
                contentHeight: "100%",
                contentWidth: "100%",
                endButton: new sap.m.Button({
                    text: this.resourceBundle.getText(
                        "QI_CONFIRM_BTN"),
                    press: jQuery.proxy(this.onPictureViewerClose,
                        this)
                })
            });
            var t = jQuery.proxy(function() {
                this.oViewerView.rerender()
            }, this);
            this.oViewerDialog.attachAfterOpen(t)
        },
        onPictureViewerClose: function() {
            this.oViewerDialog.close()
        },
        combineGetRequests: function() {
            var S = sap.ca.scfld.md.app.Application.getImpl().oConfiguration
                .getParams().settingsName;
            var o = localStorage.getObj(S);
            var i = new sap.ui.core.Item({
                key: "{key}" + this.colon + "{catalogType}" +
                    this.colon + "{codeGroup}",
                text: "{title}" + this.openingBracket +
                    "{category}" + this.closingBracket,
                active: true
            });
            this.oDefectDialog = null;
            this.oDefectInput = this.byId("QI_DEFECT_SELECT");
            var a = [];
            var b = [{
                output: "key",
                source: "DefectCode"
            }, {
                output: "title",
                source: "DefectCodeText"
            }, {
                output: "codeGroup",
                source: "DefectCodeGroup"
            }, {
                output: "category",
                source: "DefectCodeGroupText"
            }, {
                output: "catalogType",
                source: "DefectCatalogType"
            }];
            a.push({
                indexCollection: 0,
                arConversionRules: b,
                itemsPrefix: "items"
            });
            var c = [{
                output: "key",
                source: "NotifCode"
            }, {
                output: "title",
                source: "NotifCodeText"
            }, {
                output: "codeGroup",
                source: "NotifCodeGroup"
            }, {
                output: "category",
                source: "NotifCodeGroupText"
            }, {
                output: "catalogType",
                source: "NotifCatalogType"
            }];
            a.push({
                indexCollection: 1,
                arConversionRules: c,
                itemsPrefix: "items"
            });
            if ($.isBlank(o)) {
                var s = [{
                    output: "maxHits",
                    source: "MaxHits"
                }, {
                    output: "defPlant",
                    source: "Plant"
                }, {
                    output: "maxFileSize",
                    source: "MaxFileSize"
                }];
                a.push({
                    indexCollection: 3,
                    arConversionRules: s
                })
            }
            var d = i2d.qm.qualityissue.confirm.utils.Helper.getCollection(
                a, this);
            var l = d && d.length > 0 && d[0];
            var m = new sap.ui.model.json.JSONModel();
            m.setData(l);
            this.oDefectInput.setModel(m);
            this.oDefectInput.bindAggregation("suggestionItems",
                "/items", i);
            this.selectedDefect = new sap.m.StandardListItem({
                key: "{key}",
                codeGroup: "{codeGroup}",
                category: "{category}",
                title: "{title}",
                catalogType: "{catalogType}",
                active: true
            });
            this.oCategoryDialog = null;
            this.oCatInput = this.byId("QI_CATEGORY_SELECT");
            l = d && d.length > 0 && d[1];
            m = new sap.ui.model.json.JSONModel();
            m.setData(l);
            this.oCatInput.setModel(m);
            this.oCatInput.bindAggregation("suggestionItems", "/items",
                i);
            this.selectedCategory = new sap.m.StandardListItem({
                key: "{key}",
                codeGroup: "{codeGroup}",
                category: "{category}",
                title: "{title}",
                catalogType: "{catalogType}",
                active: true
            });
            if ($.isBlank(o)) {
                o = d && d.length > 0 && d[2][0];
                localStorage.setObj(S, o)
            }
        },
        onExit: function() {
            if (this.oCategoryDialog) {
                try {
                    this.oCategoryDialog.destroy();
                    this.oCategoryDialog = null
                } catch (e) {}
            }
            if (this.oDefectDialog) {
                try {
                    this.oDefectDialog.destroy();
                    this.oDefectDialog = null
                } catch (e) {}
            }
            if (this.oViewerDialog) {
                try {
                    this.oViewerDialog.destroy();
                    this.oViewerDialog = null
                } catch (e) {}
            }
            if (this.oViewerView) {
                try {
                    this.oViewerView.destroy();
                    this.oViewerView = null
                } catch (e) {}
            }
            if (this.creationModel) {
                try {
                    this.creationModel.destroy();
                    this.creationModel = null
                } catch (e) {}
            }
            if (this.pictureModel) {
                try {
                    this.pictureModel.destroy();
                    this.pictureModel = null
                } catch (e) {}
            }
            if (this.selectedDefect) {
                try {
                    this.selectedDefect.destroy();
                    this.selectedDefect = null
                } catch (e) {}
            }
            if (this.selectedCategory) {
                try {
                    this.selectedCategory.destroy();
                    this.selectedCategory = null
                } catch (e) {}
            }
            if (this.oBusy) {
                try {
                    this.oBusy.destroy();
                    this.oBusy = null
                } catch (e) {}
            }
        },
        _openFromMV: function(c, e, d) {
            this._context = d.context
        },
        applySearchPatternToListItem: function(i, f) {
            if (f.substring(0, 1) === "#") {
                var t = f.substr(1);
                var d = i.getBindingContext().getProperty("Name").toLowerCase();
                return d.indexOf(t) === 0
            } else {
                return sap.ca.scfld.md.controller.ScfldMasterController
                    .prototype.applySearchPatternToListItem.call(null,
                        i, f)
            }
        },
        onBack: function(e) {
            var b = sap.ui.getCore().getEventBus();
            b.publish("nav", "back")
        },
        onSend: function(e) {
            if (this.submit(true)) {
                this.selectedDefect = null;
                this.cleanModel()
            }
        },
        confirmDefectSelectDialog: function(e) {
            var s = e.getParameter("selectedItem");
            var i = ("DefectSelectDialog" === e.getSource().sId) ? this
                .oDefectInput : this.oCatInput;
            if (s) {
                i.setValue(s.getTitle());
                i.setValueState(sap.ui.core.ValueState.None);
                var p = s.oBindingContexts.undefined.sPath.split("/");
                var a = p[p.length - 1];
                var b = s.oBindingContexts.undefined.oModel.oData.items[
                    a];
                if (i === this.oCatInput) {
                    this.selectedCategory = b
                } else {
                    this.selectedDefect = b
                }
                this.onCheckEnableSubmit()
            }
        },
        cancelDefectSelectDialog: function(e) {
            this.onCheckEnableSubmit()
        },
        searchDefect: function(e) {
            var v = e.getParameter("value");
            if (v !== undefined) {
                this.filterDialog(v, e.getSource().getBinding("items"))
            }
        },
        setInitialFilter: function(f, s) {
            f = f.split(this.openingBracket)[0];
            s.open(f);
            var i = s.getBinding("items");
            if (!$.isBlank(f)) {
                this.filterDialog(f, i)
            } else if (f === "" && i.aFilters.length > 0) {
                this.filterDialog(f, i)
            }
        },
        onDefectSelect: function(e) {
            if (!this.oDefectDialog) {
                this.oDefectDialog = i2d.qm.qualityissue.confirm.utils.FragmentHelper
                    .createF4HelpSelectDialog(this,
                        "DefectSelectDialog", this.oDefectInput.getModel()
                    )
            }
            this.setInitialFilter(e.getSource()._lastValue, this.oDefectDialog)
        },
        onCategorySelect: function(e) {
            if (!this.oCategoryDialog) {
                this.oCategoryDialog = i2d.qm.qualityissue.confirm.utils
                    .FragmentHelper.createF4HelpSelectDialog(this,
                        "CategorySelectDialog", this.oCatInput.getModel()
                    )
            }
            this.setInitialFilter(e.getSource()._lastValue, this.oCategoryDialog)
        },
        filterDialog: function(v, i) {
            var f = [];
            var s = new sap.ui.model.Filter("title", sap.ui.model.FilterOperator
                .Contains, v);
            f.push(s);
            i.filter(f)
        },
        onSuggest: function(e) {
            var v = e.getParameter("suggestValue");
            if (v !== undefined) {
                this.filterDialog(v, e.getSource().getBinding("suggestionItems"));
                if (e.getSource() === this.oCatInput) {
                    this.selectedCategory = ""
                } else {
                    this.selectedDefect = ""
                }
                e.getSource().setValueState(sap.ui.core.ValueState.None)
            }
        },
        onSuggestionItemSelected: function(e) {
            var v = e.getParameter("selectedItem");
            if (v !== undefined) {
                var t = new sap.m.StandardListItem({
                    key: "{key}",
                    codeGroup: "{codeGroup}",
                    category: "{category}",
                    title: "{title}",
                    catalogType: "{catalogType}"
                });
                var p = v.mProperties.key.split(this.colon);
                t.key = p[0];
                t.catalogType = p[1];
                t.codeGroup = p[2];
                p = v.mProperties.text.split(this.openingBracket);
                t.title = p[0];
                t.category = p[1].split(this.closingBracket)[0];
                if (e.getSource() === this.oCatInput) {
                    this.selectedCategory = t
                } else {
                    this.selectedDefect = t
                } if (jQuery.device.is.phone || jQuery.device.is.tablet) {
                    this.onCheckEnableSubmit()
                }
            }
        },
        onValidation: function() {
            var r = false;
            r = this.checkMandatoryFields(["QI_SUBJECT_INPUT",
                "QI_DEFECT_SELECT"
            ], this);
            if (r) r = this.checkValidInput();
            return r
        },
        checkValidInput: function() {
            var r = true;
            if (this.selectedDefect === "" && this.oDefectInput.getValue() !==
                "") {
                this.oDefectInput.setValueState(sap.ui.core.ValueState.Error);
                this.oDefectInput.setValueStateText(this.resourceBundle
                    .getText("QI_INVALID_ERROR")), r = false
            } else {
                this.oDefectInput.setValueState(sap.ui.core.ValueState.None)
            } if (this.selectedCategory === "" && this.oCatInput.getValue() !==
                "") {
                this.oCatInput.setValueState(sap.ui.core.ValueState.Error);
                this.oCatInput.setValueStateText(this.resourceBundle.getText(
                    "QI_INVALID_ERROR")), r = false
            } else {
                this.oCatInput.setValueState(sap.ui.core.ValueState.None)
            }
            return r
        },
        submit: function(a) {
            if (!this.oBusy) {
                this.oBusy = new sap.m.BusyDialog()
            }
            this.oBusy.open();
            if (this.onValidation() === false) {
                this.oBusy.close();
                return false
            }
            var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
            var p = localStorage.getObj(A.getParams().settingsName).defPlant;
            var B = ";base64,";
            var b, P;
            var c = [];
            var d = this.byId("AddPicturesCtrl").getPictures();
            var o = null;
            for (var i = 0; i < d.length; i++) {
                b = d[i].getSource();
                P = b.indexOf(B);
                if (P > -1) {
                    b = b.substr(P + B.length)
                }
                o = {
                    NotificationID: "1",
                    DocOrigin: d[i].getName(),
                    DocData: b
                };
                c.push(o)
            }
            var e = this.oCatInput.getValue();
            o = {
                NotificationID: "1",
                ShortText: this.byId("QI_SUBJECT_INPUT").getValue(),
                ReferenceNumber: this.byId(
                    "QI_REFERENCE_NUMBER_INPUT").getValue(),
                LongText: this.byId("QI_DESCRIPTION_INPUT").getValue(),
                NotifCode: (!$.isBlank(e) && this.selectedCategory.key) ?
                    this.selectedCategory.key : "",
                NotifCodeGroup: (!$.isBlank(e) && this.selectedCategory
                    .codeGroup) ? this.selectedCategory.codeGroup : "",
                NotifCatalogType: (!$.isBlank(e) && this.selectedCategory
                    .catalogType) ? this.selectedCategory.catalogType : "",
                DefectCode: (this.selectedDefect.key) ? this.selectedDefect
                    .key : "",
                DefectCodeGroup: (this.selectedDefect.codeGroup) ?
                    this.selectedDefect.codeGroup : "",
                DefectCatalogType: (this.selectedDefect.catalogType) ?
                    this.selectedDefect.catalogType : "",
                Plant: p ? p : ""
            };
            if (c.length > 0) {
                o[A.getServiceList()[0].QIAttachmentsCreate] = c
            }
            var r = i2d.qm.qualityissue.confirm.utils.Helper.processChangeOperation(
                A.getServiceList()[0].createCollection, A.getParams()
                .HTTP_Method.POST, o, this);
            var N = r && r.NotificationID;
            var n = true;
            this.oBusy.close();
            if (N) {
                var v = this.resourceBundle.getText("QI_TXT_VALIDATION");
                sap.m.MessageToast.show(v);
                this.oRouter.navTo("master", {
                    id: "create"
                })
            } else {
                n = false
            }
            return n
        },
        onList: function(e) {
            this.selectedDefect = null;
            this.cleanModel();
            this.oRouter.navTo("master", {
                id: "list"
            })
        },
        onPictureClick: function(e) {
            var s = e.mParameters.pictureItem._oImage;
            this.showGallery(s)
        },
        showGallery: function(s) {
            var a = [];
            var b = 0;
            var g = this.AddPictureCtrl.getPictures();
            for (var i = 0; i < g.length; i++) {
                a.push(g[i]._oImage);
                if (g[i]._oImage === s) b = i
            }
            this.oViewerView.byId("pictureViewer").setSelectedIndex(b);
            this.oViewerDialog.open()
        },
        onPictureAdded: function(e) {
            var i = e.getParameters().pictureItem;
            var p = this.pictureModel.getData().Pictures || [];
            p.push({
                source: i.getSource(),
                name: i.getName(),
                status: i.getStatus()
            });
            this.pictureModel.setData({
                Pictures: p
            })
        },
        onMaxLimitReached: function(e) {
            var m = this.resourceBundle.getText("QI_NO_MORE_IMAGES");
            sap.m.MessageToast.show(m)
        },
        cleanModel: function() {
            var f = null;
            var a = ["QI_SUBJECT_INPUT", "QI_REFERENCE_NUMBER_INPUT",
                "QI_DESCRIPTION_INPUT", "QI_DEFECT_SELECT",
                "QI_CATEGORY_SELECT"
            ];
            for (var i = 0; i < a.length; i++) {
                f = this.byId(a[i]);
                if (f) f.setValue("");
                f.setValueState(sap.ui.core.ValueState.None)
            }
            this.AddPictureCtrl.destroyPictures();
            this.oSubmitButton.setEnabled(false);
            this.pictureModel = new sap.ui.model.json.JSONModel({
                Pictures: []
            });
            this.oViewerView.setModel(this.pictureModel, "picture");
            this.getView().setModel(this.pictureModel, "picture")
        },
        onCheckEnableSubmit: function(e) {
            if (!jQuery.device.is.phone && !jQuery.device.is.tablet &&
                this.selectedDefect != undefined) {
                this.selectedDefect.category = ""
            }
            if (!this.byId("QI_SUBJECT_INPUT").getValue().length == 0 &&
                (!this.byId("QI_DEFECT_SELECT").getValue().length == 0 ||
                    (this.selectedDefect != undefined && this.selectedDefect
                        .category != undefined && this.selectedDefect.category !=
                        null && this.selectedDefect.category != ""))) {
                this.oSubmitButton.setEnabled(true)
            } else this.oSubmitButton.setEnabled(false)
        },
        onAfterRendering: function() {
            var f = this.getView().byId("form");
            if (f) {
                var a = f.getContent();
                var c, C, b;
                for (var i = 0; i < a.length; i++) {
                    if (a[i] instanceof sap.m.Label) {
                        c = a[i].getLabelFor();
                        if (c) {
                            C = this.getView().byId(c);
                            if (C && C.getVisible && C.getVisible()) {
                                b = Math.ceil(C.$().children().first().offset()
                                    .top - C.$().parent().offset().top
                                );
                                if (C instanceof sap.m.TextArea) {
                                    b += parseInt(C.$().children().first()
                                        .css("padding-top"));
                                    a[i].$().css("margin-top", b + "px")
                                } else if (C instanceof sap.m.Input) {
                                    b += 4;
                                    b += C.$().height();
                                    a[i].$().parent().css("line-height",
                                        b + "px");
                                    a[i].$().css("vertical-align",
                                        "middle")
                                }
                            }
                        }
                    }
                }
                this.bIsFormVAligned = true
            }
        },
        navBack: function() {
            window.history.back()
        },
        checkMandatoryFields: function(a, c) {
            var f = null;
            var r = true;
            for (var i = 0; i < a.length; i++) {
                f = c.byId(a[i]);
                if (f) {
                    if (f.getValue() === "") {
                        r = false;
                        if (f.setValueState) {
                            f.setValueState(sap.ui.core.ValueState.Error);
                            f.setValueStateText(this.resourceBundle.getText(
                                "QI_DESC_ERROR"));
                            r = false
                        }
                    } else {
                        if (f.setValueState) {
                            f.setValueState(sap.ui.core.ValueState.None)
                        }
                    }
                }
            }
            return r
        },
        onFileNotSupported: function(e) {
            var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
            var m = b.getText("QI_FILE_TYPE_NOT_SUPPORTED");
            i2d.qm.qualityissue.confirm.utils.ErrorDialog(m)
        },
    });