/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("i2d.qm.qualityissue.confirm.view.Viewer", {

	/**
     * Initialization of the view
     */
    onInit : function() {

        // get the pictureViewer
        this.pictureViewer = this.getView().byId("pictureViewer");
        this.galleryItems = "";

        this.editModel = new sap.ui.model.json.JSONModel({
            "editable" : true
        });
        this.getView().setModel(this.editModel,"edit");
        
     // Retrieve the application bundle
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();

    },

    /**
     * Override to get rid of Scaffolding
     *
     * @param oOptions
     */
    setHeaderFooterOptions : function(oOptions){


    },



    /**
     * Handler for remove action
     */
    onRemove : function (oEvent) {
  

        // get current index of visible picture
        var pictureIndex = oEvent.getParameters().index;
        //restore the image first
        var oModel = this.getView().getModel("picture");
        var aPictures = oModel.getData().Pictures;
//     	update model
        aPictures.splice(pictureIndex, 1);
        oModel.setData({Pictures: aPictures});
    },


    /**
     * Helper function to create a function for the setTimeout - new set the visible picture
     * @private
     */
    _selectImage : function () {

    }
});