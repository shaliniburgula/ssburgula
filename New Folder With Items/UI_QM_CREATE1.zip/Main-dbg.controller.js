/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("i2d.qm.qualityissue.confirm.Main", {

	onInit : function() {
				
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");
		jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StorageHelper");
		jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.DateTimeConversions");
		
		// extend local Storage object to support objects and array handling		
		Storage.prototype.setObj = function(key, obj) {
			//In private browsing mode Safari and iOS Safari don't support setting localStorage.
			try {
				this.setItem(key, JSON.stringify(obj));
				return true;
			} catch (error) {
				// store it in the local implementation
				i2d.qm.qualityissue.confirm.utils.StorageHelper.setObj(key, obj);
				return false;
			}		    
		};
		Storage.prototype.getObj = function(key) {
			var result = this.getItem(key);
			
			if ($.isBlank(result)) {
				//try to get it from the local implementation
				result = i2d.qm.qualityissue.confirm.utils.StorageHelper.getObj(key);
			} else {
				result = JSON.parse(result);
			}
		    return result;
		};	
		
		//extend jQuery object with isBlank function
		(function($){
			  $.isBlank = function(obj){
			    return(!obj || (typeof(obj) == "string" && $.trim(obj) === "") || (typeof(obj) == "string" && $.trim(obj) === "undefined") || 
			    		($.isPlainObject(obj) && $.isEmptyObject(obj)) ||
			    		($.isArray(obj) && obj.length == 0) 
			    	   );
			  };
			})(jQuery);
		
		sap.ca.scfld.md.Startup.init('i2d.qm.qualityissue.confirm', this);		

	},
    /**
     * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
     *
     * @memberOf MainXML
     */
    onExit : function() {
        if (this.oAppNavigator) {
            // Destroy the navigation again
            this.oAppNavigator.destroy();
        }
	}
	

});