/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("i2d.qm.qualityissue.confirm.Main", {
	onInit: function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");
		jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StorageHelper");
		jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.DateTimeConversions");
		Storage.prototype.setObj = function(k, o) {
			try {
				this.setItem(k, JSON.stringify(o));
				return true
			} catch (e) {
				i2d.qm.qualityissue.confirm.utils.StorageHelper.setObj(k, o);
				return false
			}
		};
		Storage.prototype.getObj = function(k) {
			var r = this.getItem(k);
			if ($.isBlank(r)) {
				r = i2d.qm.qualityissue.confirm.utils.StorageHelper.getObj(k)
			} else {
				r = JSON.parse(r)
			}
			return r
		};
		(function($) {
			$.isBlank = function(o) {
				return (!o || (typeof(o) == "string" && $.trim(o) === "") || (typeof(o) == "string" && $.trim(o) === "undefined") || ($.isPlainObject(
					o) && $.isEmptyObject(o)) || ($.isArray(o) && o.length == 0))
			}
		})(jQuery);
		sap.ca.scfld.md.Startup.init('i2d.qm.qualityissue.confirm', this)
	},
	onExit: function() {
		if (this.oAppNavigator) {
			this.oAppNavigator.destroy()
		}
	}
});