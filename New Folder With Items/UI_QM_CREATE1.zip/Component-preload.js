jQuery.sap.registerPreloadedModules({
	"name": "i2d/qm/qualityissue/confirm/Component-preload",
	"version": "2.0",
	"modules": {
		"i2d/qm/qualityissue/confirm/Component.js": function() {
			/*
			 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
			 */
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.Component");
			jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.Configuration");
			sap.ca.scfld.md.ComponentBase.extend("i2d.qm.qualityissue.confirm.Component", {
				metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
					"name": "Quality Issue Create",
					"version": "1.0.0",
					"library": "i2d.qm.qualityissue.confirm",
					"includes": ["css/qi_style.css"],
					"dependencies": {
						"libs": ["sap.m", "sap.me"],
						"components": []
					},
					"config": {
						"resourceBundle": "i18n/i18n.properties",
						"titleResource": "",
						"icon": "sap-icon://Fiori2/F0316",
						"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/F0316_Report_Quality_Issue.ico",
						"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/F0316_Report_Quality_Issues/57_iPhone_Desktop_Launch.png",
						"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0316_Report_Quality_Issues/114_iPhone-Retina_Web_Clip.png",
						"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/F0316_Report_Quality_Issues/72_iPad_Desktop_Launch.png",
						"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/F0316_Report_Quality_Issues/144_iPad_Retina_Web_Clip.png",
						"startupImage320x460": "./resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png",
						"startupImage640x920": "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png",
						"startupImage640x1096": "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png",
						"startupImage768x1004": "./resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png",
						"startupImage748x1024": "./resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png",
						"startupImage1536x2008": "./resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png",
						"startupImage1496x2048": "./resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png"
					},
					viewPath: "i2d.qm.qualityissue.confirm.view",
					masterPageRoutes: {
						"master": {
							pattern: "master/{id}",
							"view": "S2",
							"viewId": "IssueList"
						}
					},
					detailPageRoutes: {
						"detail": {
							pattern: "detail/{contextPath}",
							"view": "S3",
							"viewId": "IssueListDetail"
						}
					},
					fullScreenPageRoutes: {
						"default": {
							pattern: "",
							"view": "S4",
							"viewId": "ReportForm"
						},
						"fsS4": {
							pattern: "fsS4",
							"view": "S4",
							"viewId": "ReportForm"
						},
						"fsViewer": {
							pattern: "pic",
							view: "Viewer"
						}
					}
				}),
				createContent: function() {
					var v = {
						component: this
					};
					return sap.ui.view({
						viewName: "i2d.qm.qualityissue.confirm.Main",
						type: sap.ui.core.mvc.ViewType.XML,
						viewData: v
					})
				}
			})
		},
		"i2d/qm/qualityissue/confirm/Configuration.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
			jQuery.sap.require("sap.ca.scfld.md.app.Application");
			sap.ca.scfld.md.ConfigurationBase.extend("i2d.qm.qualityissue.confirm.Configuration", {
				aServiceList: [{
					name: "QM_NOTIF_SRV",
					masterCollection: "QMNotificationSelectionSet",
					createCollection: "QMNotificationCreationSet",
					QIAttachmentsCreate: "QMAttachmentCreationSet",
					QIAttachmentsRead: "QMNotificationSelectionSet",
					QIAttachmentGet: "GetAttData",
					QIAttachmentStream: "QMStreamSet",
					SelectionSetCollection: ["QMDefectSelectionSet", "QMCategorySelectionSet", "QMPlantsSet", "QMSettingsSet", "QMStatusSet"],
					serviceUrl: "" + URI("/sap/opu/odata/sap/QM_NOTIF_SRV/"),
					isDefault: true,
					mockedDataSource: "model/metadata.xml",
					useBatch: true
				}],
				GlobalParams: {
					settingsName: "QI_objSettings",
					factSheetsNavigation: {
						semanticObject: "QualityNotification",
						action: "displayFactSheet",
						paramName: "QualityNotification"
					},
					HTTP_Method: {
						GET: "GET",
						POST: "POST",
						PUT: "PUT",
						DELETE: "DELETE",
						MERGE: "MERGE"
					},
					ProcessingModeEnum: {
						Read: "Read",
						Batch: "ReadBatch",
						Change: "ChangeBatch"
					},
					InteropService: {
						name: "UI2/INTEROP",
						linkCheck: "ResolveLink?linkId='QualityNotification-displayFactSheet'",
						serviceUrl: URI("/sap/opu/odata/UI2/INTEROP/")
					},
					filterDialogDefaultFromDate: "1970-01-01T00:00:00.000Z",
					filterDialogDefaultToDate: "9999-12-31T00:00:00.000Z"
				},
				getServiceList: function() {
					return this.aServiceList
				},
				getParams: function() {
					return this.GlobalParams
				},
				getMasterKeyAttributes: function() {
					return ["Notification", "NotificationID"]
				},
				getAppIdentifier: function() {
					return "i2d.qm.qualityissue.confirm"
				},
			})
		},
		"i2d/qm/qualityissue/confirm/Main.controller.js": function() {
			sap.ui.controller("i2d.qm.qualityissue.confirm.Main", {
				onInit: function() {
					jQuery.sap.require("sap.ca.scfld.md.Startup");
					jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");
					jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StorageHelper");
					jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.DateTimeConversions");
					Storage.prototype.setObj = function(k, o) {
						try {
							this.setItem(k, JSON.stringify(o));
							return true
						} catch (e) {
							i2d.qm.qualityissue.confirm.utils.StorageHelper.setObj(k, o);
							return false
						}
					};
					Storage.prototype.getObj = function(k) {
						var r = this.getItem(k);
						if ($.isBlank(r)) {
							r = i2d.qm.qualityissue.confirm.utils.StorageHelper.getObj(k)
						} else {
							r = JSON.parse(r)
						}
						return r
					};
					(function($) {
						$.isBlank = function(o) {
							return (!o || (typeof(o) == "string" && $.trim(o) === "") || (typeof(o) == "string" && $.trim(o) === "undefined") || ($.isPlainObject(
								o) && $.isEmptyObject(o)) || ($.isArray(o) && o.length == 0))
						}
					})(jQuery);
					sap.ca.scfld.md.Startup.init('i2d.qm.qualityissue.confirm', this)
				},
				onExit: function() {
					if (this.oAppNavigator) {
						this.oAppNavigator.destroy()
					}
				}
			})
		},
		"i2d/qm/qualityissue/confirm/Main.view.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n\r\n<core:View xmlns:core="sap.ui.core"\r\n     xmlns="sap.m" controllerName="i2d.qm.qualityissue.confirm.Main" displayBlock="true" height="100%">\r\n    <NavContainer id="fioriContent" showHeader="false">\r\n    </NavContainer>\r\n</core:View>',
		"i2d/qm/qualityissue/confirm/control/AddPicture.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.AddPicture");
			jQuery.sap.require("sap.ca.ui.AddPicture");
			jQuery.sap.require('sap.ca.ui.PictureItem');
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
			sap.ca.ui.AddPicture.extend("i2d.qm.qualityissue.confirm.control.AddPicture", {
				_readFile: function(f) {
					var m = null;
					var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
					if (m === null) {
						var o = localStorage.getObj(sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName);
						m = o.maxFileSize
					}
					if ((m === null) || (m === 0) || f.size <= m) {
						sap.ca.ui.AddPicture.prototype._readFile.call(this, f)
					} else {
						var i = $("#" + this.getId() + "-capture");
						i.wrap('<form>').closest('form').get(0).reset();
						i.unwrap();
						var a = b.getText("QI_MAX_FILE_SIZE", m);
						i2d.qm.qualityissue.confirm.utils.ErrorDialog(a)
					}
				},
			})
		},
		"i2d/qm/qualityissue/confirm/control/AddPictureRenderer.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.AddPictureRenderer");
			jQuery.sap.require("sap.ca.ui.AddPictureRenderer");
			i2d.qm.qualityissue.confirm.control.AddPictureRenderer = {};
			i2d.qm.qualityissue.confirm.control.AddPictureRenderer.render = function(r, c) {
				sap.ca.ui.AddPictureRenderer.render(r, c)
			}
		},
		"i2d/qm/qualityissue/confirm/control/PictureItem.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.PictureItem");
			sap.ca.ui.PictureItem.extend("i2d.qm.qualityissue.confirm.control.PictureItem", {})
		},
		"i2d/qm/qualityissue/confirm/control/PictureItemRenderer.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.PictureItemRenderer");
			jQuery.sap.require("sap.ca.ui.PictureItemRenderer");
			i2d.qm.qualityissue.confirm.control.PictureItemRenderer = {};
			i2d.qm.qualityissue.confirm.control.PictureItemRenderer.render = function(r, c) {
				sap.ca.ui.PictureItemRenderer.render(r, c)
			}
		},
		"i2d/qm/qualityissue/confirm/fragments/CategorySelectDialog.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<SelectDialog\n        xmlns="sap.m"\n        id="CategorySelectDialog"\n        title="{i18n>QI_CATEGORY_DIALOG_TITLE}"\n        noDataText="{i18n>QI_CATEGORY_DIALOG_EMPTY_MSG}"\n        filterPath="title"\n        filterOperator="Contains"\n        search="searchDefect"\n        liveChange="searchDefect"\n        items="{path : \'/items\', \n        \t\t\tsorter : {\n\t\t\t\t\t\tpath : \'category\',\n\t\t\t\t\t\tdescending : false,\n\t\t\t\t\t\tgroup : true\n\t\t\t\t\t}\n\t\t\t\t}"\n        confirm="confirmDefectSelectDialog"\n        cancel="cancelDefectSelectDialog">\n    <StandardListItem\n            key = "{key}"\n\t\t\tcodeGroup = "{codeGroup}"\n\t\t\tcategory = "{category}"\n\t\t\ttitle = "{title}"\n\t\t\tcatalogType = "{catalogType}"/>\n</SelectDialog>',
		"i2d/qm/qualityissue/confirm/fragments/CustomSettingsDialog.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<Dialog xmlns="sap.m" id="CustomSettingsDialog" title="{i18n>QI_MV_SETTINGS}" stretchOnPhone="true">\r\n\t<beginButton>\r\n\t\t<Button text="{i18n>QI_CONFIRM_BTN}" type="Default" press="onConfirmCustSettingsDialog"/>\r\n\t</beginButton>\r\n\t<endButton>\r\n\t\t<Button text="{i18n>QI_CANCEL_BTN}" type="Default" press="onCancelCustSettingsDialog"/>\r\n\t</endButton>\r\n</Dialog>',
		"i2d/qm/qualityissue/confirm/fragments/CustomSettingsDialogHeader.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<Bar xmlns="sap.m" id="CustSetDialogHeader">\r\n\t<contentLeft>\r\n\t\t<Button id="CustSetDialogHeaderBack" icon="sap-icon://nav-back" press="onCustSetDialogHeaderBack"/>\r\n\t</contentLeft>\r\n\t<contentMiddle>\r\n\t\t<Label id="CustSetDialogHeaderTitle" text="{i18n>QI_MV_SETTINGS}"/>\r\n\t</contentMiddle>\r\n</Bar>',
		"i2d/qm/qualityissue/confirm/fragments/CustomSettingsList.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<List xmlns="sap.m" id="CustomSettingsList">\r\n\t<items>\r\n\t\t<StandardListItem id="CustomSettingsIssues"\ttitle="{path:\'maxHits>/maxHits\', formatter:\'i2d.qm.qualityissue.confirm.utils.FragmentHelper.getCustSetMaxHitsTitle\'}" \r\n\t\t\ttype="Navigation" press="onCustomSettingsIssues"/>\r\n\t\t<StandardListItem id="CustomSettingsPlant" title="{i18n>QI_PLANT}" type="Navigation" press="onCustomSettingsPlant"/>\r\n\t</items>\r\n</List>',
		"i2d/qm/qualityissue/confirm/fragments/CustomSettingsNumberOfIssues.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<SimpleForm xmlns="sap.ui.layout.form" id="CustomSettingsIssuesNumber" editable="true" labelMinWidth="30" layout="ResponsiveGridLayout">\r\n\t<content>\r\n\t\t<Label xmlns="sap.m" id="CustSeTIssueNumberLabel" text="{i18n>QI_NUMBER_ISSUES}" labelFor="CustSetIssueNumberInput"/>\r\n\t\t<Input xmlns="sap.m" id="CustSetIssueNumberInput" showValueHelp="false" type="Number" value="{maxHits>/maxHits}" change="onChangeCustSetIssueNumber"></Input>\t\t\r\n\t</content>\r\n</SimpleForm>',
		"i2d/qm/qualityissue/confirm/fragments/CustomSettingsPlantsList.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<List xmlns="sap.m" id="CustomSettingsPlantsList" items="{path: \'/QMPlantsSet\'}" mode="SingleSelectLeft" growing="false" select="onSelectCustomSettingsPlant" updateFinished="onLoadCustSettingsPlantList">\r\n\t<items>\r\n\t\t<StandardListItem title="{Plant}" description="{PostCode} {City} {Name}" type="Active"/>\r\n\t</items>\r\n</List>',
		"i2d/qm/qualityissue/confirm/fragments/DefectSelectDialog.fragment.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<SelectDialog\n        xmlns="sap.m"\n        id="DefectSelectDialog"\n        title="{i18n>QI_DEFECT_DIALOG_TITLE}"\n        noDataText="{i18n>QI_DEFECT_DIALOG_EMPTY_MSG}"\n        filterPath="title"\n        filterOperator="Contains"\n        search="searchDefect"\n        liveChange="searchDefect"\n        items="{path : \'/items\', \n        \t\t\tsorter : {\n\t\t\t\t\t\tpath : \'category\',\n\t\t\t\t\t\tdescending : false,\n\t\t\t\t\t\tgroup : true\n\t\t\t\t\t}\n\t\t\t\t}"\n        confirm="confirmDefectSelectDialog"\n        cancel="cancelDefectSelectDialog">\n    <StandardListItem\n            key = "{key}"\n\t\t\tcodeGroup = "{codeGroup}"\n\t\t\tcategory = "{category}"\n\t\t\ttitle = "{title}"\n\t\t\tcatalogType = "{catalogType}"/>\n</SelectDialog>',
		"i2d/qm/qualityissue/confirm/fragments/ViewSettingsFilterDialog.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<ViewSettingsDialog xmlns="sap.m" id="FilterDialog" confirm="onConfirmFilterDialog" resetFilters="onResetFilterDialog" cancel="onCancelFilterDialog">\r\n\t<filterItems>\r\n\t\t<ViewSettingsFilterItem id="FiltertByStatus" key="1" text="{i18n>QI_STATUS_TEXT}">\r\n\t\t\t<items>\r\n\t\t\t\t<ViewSettingsItem id="StatusNew" key="1a" text="{path:\'/status1\'}">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0068\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t\t<ViewSettingsItem id="StatusInProcess" key="1b" text="{path:\'/status2\'}">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0070\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t\t<ViewSettingsItem id="StatusCompleted" key="1c" text="{path:\'/status3\'}">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0072\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t\t<ViewSettingsItem id="StatusPostponed" key="1d" text="{path:\'/status4\'}">\r\n\t\t\t\t\t<customData>\r\n\t\t\t\t\t\t<CustomData xmlns="sap.ui.core" value="{filters: {path:\'Status\', operator:\'EQ\', value1:\'I0069\'}}"/>\r\n\t\t\t\t\t</customData>\r\n\t\t\t\t</ViewSettingsItem>\r\n\t\t\t</items>\r\n\t\t</ViewSettingsFilterItem>\r\n\t\t<ViewSettingsCustomItem id="FiltertByDate" key="2" text="{i18n>QI_DATE}">\r\n\t\t\t<customControl>\r\n\t\t\t\t<VBox id="DatesContainer" fitContainer="true" direction="Column">\r\n\t\t\t\t\t<items>\r\n\t\t\t\t\t\t<Label id="DateFrom" design="Bold" text="{i18n>QI_FROM}" labelFor="DateFromPicker"/>\r\n\t\t\t\t\t\t<DatePicker xmlns="sap.m" id="DateFromPicker" width="10em" tooltip="{i18n>QI_FROM_TOOLTIP}" change="onChangeDateFrom"/>\r\n\t\t\t\t\t\t<Label id="DateTo" design="Bold" text="{i18n>QI_TO}" labelFor="DateToPicker"/>\r\n\t\t\t\t\t\t<DatePicker xmlns="sap.m" id="DateToPicker" width="10em" tooltip="{i18n>QI_TO_TOOLTIP}" change="onChangeDateTo"/>\r\n\t\t\t\t\t</items>\r\n\t\t\t\t</VBox>\r\n\t\t\t</customControl>\r\n\t\t</ViewSettingsCustomItem>\r\n\t</filterItems>\r\n</ViewSettingsDialog>',
		"i2d/qm/qualityissue/confirm/fragments/ViewSettingsSortDialog.fragment.xml": '<!--\r\n\r\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\r\n\r\n-->\r\n<ViewSettingsDialog xmlns="sap.m" id="SortDialog" confirm="onConfirmSortDialog">\r\n\t<sortItems>\r\n\t\t<ViewSettingsItem id="DateSort" key="1" text="{i18n>QI_DATE}" selected="false">\r\n\t\t\t<customData>\r\n\t\t\t\t<CustomData xmlns="sap.ui.core" value="{sorter: {path:\'CreatedOn\', descending:false}}"/>\r\n\t\t\t</customData>\r\n\t\t</ViewSettingsItem>\r\n\t\t<ViewSettingsItem id="StatusSort" key="2" text="{i18n>QI_STATUS_TEXT}" selected="false">\r\n\t\t\t<customData>\r\n\t\t\t\t<CustomData xmlns="sap.ui.core" value="{sorter: {path:\'Status\', descending:false}}"/>\r\n\t\t\t</customData>\r\n\t\t</ViewSettingsItem>\r\n\t\t<ViewSettingsItem id="DefectSort" key="3" text="{i18n>QI_DEFECT}" selected="false">\r\n\t\t\t<customData>\r\n\t\t\t\t<CustomData xmlns="sap.ui.core" value="{sorter: {path:\'DefectCodeText\', descending:false}}"/>\r\n\t\t\t</customData>\r\n\t\t</ViewSettingsItem>\r\n\t</sortItems>\r\n</ViewSettingsDialog>',
		"i2d/qm/qualityissue/confirm/i18n/i18n.properties": '# Properties file of the Report Quality Issue application. The file comprises all text entities that appear on the application UI.  \n# __ldi.translation.uuid=f5c6ee80-1557-11e3-8ffd-0800200c9a66\n# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=Report Quality Issue\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=Attachments\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=Added on {0} by {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=No file name\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=Description\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=Defect\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=Reference\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Category\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=Detailed Description\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=Submit\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=Cancel\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=Reported On\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=Status\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=Date\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=Quality issue reported\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=Mandatory field\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=Invalid input\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=Image size should be less than {0} bytes\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=You cannot attach more images\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=Are you sure you want to delete this image?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=Delete Image\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=File type not supported\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=Cancel\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=Not all attached images were submitted\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=Choose Category\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=Choose Defect\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=No defects available\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=No categories available\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=New\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=In Process\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=Completed\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=Postponed\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=To\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=From\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP= Enter end date for filtering\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP= Enter start date for filtering\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=Add Image\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=Invalid Date Entered\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=To Date should be equal to or later than From Date\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=My Reported Issues ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=My Reported Issue\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=Priority\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=Assigned To\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=Notification\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=Material\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=Settings\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=Plant\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=Display {0} Issues\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=Display 1 Issue\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=Number of Issues\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=Image Gallery\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=Filtered by {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=Loading...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=No Quality Issues Available\n\n#----------------------Master/Details view properties end------------------------------->',
		"i2d/qm/qualityissue/confirm/i18n/i18n_ar.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=\\u0627\\u0644\\u0625\\u0628\\u0644\\u0627\\u063A \\u0639\\u0646 \\u0645\\u0634\\u0643\\u0644\\u0629 \\u0645\\u062A\\u0639\\u0644\\u0642\\u0629 \\u0628\\u0627\\u0644\\u062C\\u0648\\u062F\\u0629\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=\\u0645\\u0631\\u0641\\u0642\\u0627\\u062A\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=\\u062A\\u0645\\u062A \\u0627\\u0644\\u0625\\u0636\\u0627\\u0641\\u0629 \\u0641\\u064A {0} \\u0628\\u0648\\u0627\\u0633\\u0637\\u0629 {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=\\u0644\\u0627 \\u064A\\u0648\\u062C\\u062F \\u0627\\u0633\\u0645 \\u0645\\u0644\\u0641\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=\\u0627\\u0644\\u0648\\u0635\\u0641\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=\\u0639\\u064A\\u0628\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=\\u0627\\u0644\\u0645\\u0631\\u062C\\u0639\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=\\u0627\\u0644\\u0641\\u0626\\u0629\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=\\u0648\\u0635\\u0641 \\u062A\\u0641\\u0635\\u064A\\u0644\\u064A\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=\\u062A\\u0642\\u062F\\u064A\\u0645\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=\\u0625\\u0644\\u063A\\u0627\\u0621\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=\\u062A\\u0645 \\u0627\\u0644\\u0625\\u0628\\u0644\\u0627\\u063A \\u0641\\u064A\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=\\u0627\\u0644\\u062D\\u0627\\u0644\\u0629\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=\\u0627\\u0644\\u062A\\u0627\\u0631\\u064A\\u062E\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=\\u062A\\u0645 \\u0627\\u0644\\u0625\\u0628\\u0644\\u0627\\u063A \\u0639\\u0646 \\u0645\\u0634\\u0643\\u0644\\u0629 \\u0645\\u062A\\u0639\\u0644\\u0642\\u0629 \\u0628\\u0627\\u0644\\u062C\\u0648\\u062F\\u0629\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=\\u062D\\u0642\\u0644 \\u0625\\u0644\\u0632\\u0627\\u0645\\u064A\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=\\u0625\\u062F\\u062E\\u0627\\u0644 \\u063A\\u064A\\u0631 \\u0635\\u0627\\u0644\\u062D\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=\\u064A\\u062C\\u0628 \\u0623\\u0646 \\u064A\\u0643\\u0648\\u0646 \\u062D\\u062C\\u0645 \\u0627\\u0644\\u0635\\u0648\\u0631\\u0629 \\u0623\\u0642\\u0644 \\u0645\\u0646 {0} \\u0628\\u0627\\u064A\\u062A\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=\\u0644\\u0627 \\u064A\\u0645\\u0643\\u0646\\u0643 \\u0625\\u0631\\u0641\\u0627\\u0642 \\u0645\\u0632\\u064A\\u062F \\u0645\\u0646 \\u0627\\u0644\\u0635\\u0648\\u0631\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u062D\\u0630\\u0641 \\u0647\\u0630\\u0647 \\u0627\\u0644\\u0635\\u0648\\u0631\\u0629 \\u0628\\u0627\\u0644\\u0641\\u0639\\u0644\\u061F\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=\\u062D\\u0630\\u0641 \\u0627\\u0644\\u0635\\u0648\\u0631\\u0629\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=\\u0646\\u0648\\u0639 \\u0627\\u0644\\u0645\\u0644\\u0641 \\u063A\\u064A\\u0631 \\u0645\\u062F\\u0639\\u0648\\u0645\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=\\u0645\\u0648\\u0627\\u0641\\u0642\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=\\u0625\\u0644\\u063A\\u0627\\u0621\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=\\u0644\\u0645 \\u064A\\u062A\\u0645 \\u0625\\u0631\\u0633\\u0627\\u0644 \\u0643\\u0644 \\u0627\\u0644\\u0635\\u0648\\u0631 \\u0627\\u0644\\u0645\\u0631\\u0641\\u0642\\u0629\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=\\u0627\\u062E\\u062A\\u064A\\u0627\\u0631 \\u0641\\u0626\\u0629\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=\\u0627\\u062E\\u062A\\u064A\\u0627\\u0631 \\u0639\\u064A\\u0628\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0639\\u064A\\u0648\\u0628\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0641\\u0626\\u0627\\u062A\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=\\u062C\\u062F\\u064A\\u062F\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=\\u0642\\u064A\\u062F \\u0627\\u0644\\u0645\\u0639\\u0627\\u0644\\u062C\\u0629\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=\\u0645\\u0643\\u062A\\u0645\\u0644\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=\\u0645\\u064F\\u0624\\u062C\\u0651\\u064E\\u0644\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=\\u0625\\u0644\\u0649\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=\\u0645\\u0646\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=\\u0623\\u062F\\u062E\\u0644 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0646\\u062A\\u0647\\u0627\\u0621 \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=\\u0623\\u062F\\u062E\\u0644 \\u062A\\u0627\\u0631\\u064A\\u062E \\u0628\\u062F\\u0627\\u064A\\u0629 \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=\\u0625\\u0636\\u0627\\u0641\\u0629 \\u0635\\u0648\\u0631\\u0629\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=\\u062A\\u0645 \\u0625\\u062F\\u062E\\u0627\\u0644 \\u062A\\u0627\\u0631\\u064A\\u062E \\u063A\\u064A\\u0631 \\u0635\\u0627\\u0644\\u062D\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=\\u064A\\u062C\\u0628 \\u0623\\u0646 \\u062A\\u0643\\u0648\\u0646 \\u0642\\u064A\\u0645\\u0629 "\\u0625\\u0644\\u0649 \\u0627\\u0644\\u062A\\u0627\\u0631\\u064A\\u062E" \\u0645\\u0633\\u0627\\u0648\\u064A\\u0629 \\u0623\\u0648 \\u0644\\u0627\\u062D\\u0642\\u0629 \\u0644\\u0642\\u064A\\u0645\\u0629 "\\u0645\\u0646 \\u0627\\u0644\\u062A\\u0627\\u0631\\u064A\\u062E"\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=\\u0645\\u0634\\u0643\\u0644\\u0627\\u062A\\u064A \\u0627\\u0644\\u0645\\u0628\\u0644\\u0651\\u064E\\u063A \\u0628\\u0647\\u0627 ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=\\u0645\\u0634\\u0643\\u0644\\u062A\\u064A \\u0627\\u0644\\u0645\\u064F\\u0628\\u0644\\u063A \\u0639\\u0646\\u0647\\u0627\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=\\u0627\\u0644\\u0623\\u0641\\u0636\\u0644\\u064A\\u0629\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=\\u062A\\u0645 \\u0627\\u0644\\u062A\\u0639\\u064A\\u064A\\u0646 \\u0625\\u0644\\u0649\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=\\u0627\\u0644\\u0625\\u0634\\u0639\\u0627\\u0631\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=\\u0627\\u0644\\u0645\\u0627\\u062F\\u0629\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=\\u0625\\u0639\\u062F\\u0627\\u062F\\u0627\\u062A\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=\\u0627\\u0644\\u0648\\u062D\\u062F\\u0629\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=\\u0639\\u0631\\u0636 {0} \\u0645\\u0646 \\u0627\\u0644\\u0645\\u0634\\u0643\\u0644\\u0627\\u062A\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=\\u0639\\u0631\\u0636 \\u0645\\u0634\\u0643\\u0644\\u0629 \\u0648\\u0627\\u062D\\u062F\\u0629\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=\\u0639\\u062F\\u062F \\u0627\\u0644\\u0645\\u0634\\u0643\\u0644\\u0627\\u062A\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=\\u0645\\u0639\\u0631\\u0636 \\u0627\\u0644\\u0635\\u0648\\u0631\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=\\u062A\\u0645\\u062A \\u0627\\u0644\\u062A\\u0635\\u0641\\u064A\\u0629 \\u062D\\u0633\\u0628 {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=\\u062C\\u0627\\u0631\\u064D \\u0627\\u0644\\u062A\\u062D\\u0645\\u064A\\u0644...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062C\\u0648\\u062F\\u0629\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_bg.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=\\u0414\\u043E\\u043A\\u043B\\u0430\\u0434\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C \\u0441 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\\u0442\\u043E\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=\\u041F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0435\\u043D \\u043D\\u0430 {0} \\u043E\\u0442 {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=\\u041D\\u044F\\u043C\\u0430 \\u0438\\u043C\\u0435 \\u043D\\u0430 \\u0444\\u0430\\u0439\\u043B\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=\\u0414\\u0435\\u0444\\u0435\\u043A\\u0442\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=\\u0420\\u0435\\u0444\\u0435\\u0440\\u0435\\u043D\\u0446\\u0438\\u044F\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=\\u041A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044F\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E \\u043E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=\\u0418\\u0437\\u043F\\u0440\\u0430\\u0449\\u0430\\u043D\\u0435\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=\\u041E\\u0442\\u043A\\u0430\\u0437\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=\\u0414\\u043E\\u043A\\u0430\\u0434\\u0432\\u0430\\u043D \\u043D\\u0430\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=\\u0414\\u0430\\u0442\\u0430\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=\\u041F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u044A\\u0442 \\u0441 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\\u0442\\u043E \\u0435 \\u0434\\u043E\\u043A\\u043B\\u0430\\u0434\\u0432\\u0430\\u043D\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=\\u0417\\u0430\\u0434\\u044A\\u043B\\u0436\\u0438\\u0442\\u0435\\u043B\\u043D\\u043E \\u043F\\u043E\\u043B\\u0435\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=\\u041D\\u0435\\u0432\\u0430\\u043B\\u0438\\u0434\\u043D\\u043E \\u0432\\u044A\\u0432\\u0435\\u0436\\u0434\\u0430\\u043D\\u0435\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=\\u0420\\u0430\\u0437\\u043C\\u0435\\u0440 \\u043D\\u0430 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435 \\u0442\\u0440\\u044F\\u0431\\u0432\\u0430 \\u0434\\u0430 \\u0435 \\u043F\\u043E-\\u043C\\u0430\\u043B\\u043A\\u043E \\u043E\\u0442 {0} \\u0431\\u0430\\u0439\\u0442\\u0430\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=\\u041D\\u0435 \\u043C\\u043E\\u0436\\u0435\\u0442\\u0435 \\u0434\\u0430 \\u043F\\u0440\\u0438\\u043A\\u0430\\u0447\\u0432\\u0430\\u0442\\u0435 \\u043F\\u043E\\u0432\\u0435\\u0447\\u0435 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u044F\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=\\u041D\\u0430\\u0438\\u0441\\u0442\\u0438\\u043D\\u0430 \\u043B\\u0438 \\u0436\\u0435\\u043B\\u0430\\u0435\\u0442\\u0435 \\u0434\\u0430 \\u0438\\u0437\\u0442\\u0440\\u0438\\u0435\\u0442\\u0435 \\u0442\\u043E\\u0432\\u0430 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=\\u0418\\u0437\\u0442\\u0440\\u0438\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=\\u0412\\u0438\\u0434\\u044A\\u0442 \\u0444\\u0430\\u0439\\u043B \\u043D\\u0435 \\u0441\\u0435 \\u043F\\u043E\\u0434\\u0434\\u044A\\u0440\\u0436\\u0430\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=\\u041E\\u0442\\u043A\\u0430\\u0437\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=\\u041D\\u0435 \\u0432\\u0441\\u0438\\u0447\\u043A\\u0438 \\u043F\\u0440\\u0438\\u043A\\u0430\\u0447\\u0435\\u043D\\u0438 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u044F \\u0441\\u0430 \\u0438\\u0437\\u043F\\u0440\\u0430\\u0442\\u0435\\u043D\\u0438\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=\\u0418\\u0437\\u0431\\u0435\\u0440\\u0435\\u0442\\u0435 \\u043A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044F\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=\\u0418\\u0437\\u0431\\u043E\\u0440 \\u043D\\u0430 \\u0434\\u0435\\u0444\\u0435\\u043A\\u0442\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0434\\u0435\\u0444\\u0435\\u043A\\u0442\\u0438\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u043A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u0438\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=\\u041D\\u043E\\u0432\\u0438\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=\\u0412 \\u043E\\u0431\\u0440\\u0430\\u0431\\u043E\\u0442\\u043A\\u0430\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=\\u0417\\u0430\\u0432\\u044A\\u0440\\u0448\\u0435\\u043D\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=\\u041E\\u0442\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=\\u0414\\u043E\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=\\u041E\\u0442\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u0442\\u0435 \\u043A\\u0440\\u0430\\u0439\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430 \\u0437\\u0430 \\u0444\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D\\u0435\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u0442\\u0435 \\u043D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430 \\u0437\\u0430 \\u0444\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D\\u0435\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=\\u0414\\u043E\\u0431\\u0430\\u0432\\u044F\\u043D\\u0435 \\u043D\\u0430 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=\\u0412\\u044A\\u0432\\u0435\\u0434\\u0435\\u043D\\u0430 \\u0435 \\u043D\\u0435\\u0432\\u0430\\u043B\\u0438\\u0434\\u043D\\u0430 \\u0434\\u0430\\u0442\\u0430\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=\\u041A\\u0440\\u0430\\u0439\\u043D\\u0430\\u0442\\u0430 \\u0434\\u0430\\u0442\\u0430 \\u0442\\u0440\\u044F\\u0431\\u0432\\u0430 \\u0434\\u0430 \\u0441\\u044A\\u0432\\u043F\\u0430\\u0434\\u0430 \\u0438\\u043B\\u0438 \\u0434\\u0430 \\u0435 \\u043F\\u043E-\\u043A\\u044A\\u0441\\u043D\\u0430 \\u043E\\u0442 \\u043D\\u0430\\u0447\\u0430\\u043B\\u043D\\u0430\\u0442\\u0430 \\u0434\\u0430\\u0442\\u0430\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043E\\u0442\\u0447\\u0435\\u0442\\u0435\\u043D\\u0438 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0438 ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=\\u041C\\u043E\\u044F \\u0434\\u043E\\u043A\\u043B\\u0430\\u0434\\u0432\\u0430\\u043D \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=\\u041F\\u0440\\u0438\\u043E\\u0440\\u0438\\u0442\\u0435\\u0442\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D \\u043A\\u044A\\u043C\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=\\u0418\\u0437\\u0432\\u0435\\u0441\\u0442\\u0438\\u0435\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=\\u041C\\u0430\\u0442\\u0435\\u0440\\u0438\\u0430\\u043B\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=\\u041D\\u0430\\u0441\\u0442\\u0440\\u043E\\u0439\\u043A\\u0438\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=\\u0417\\u0430\\u0432\\u043E\\u0434\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0432\\u0430\\u043D\\u0435 {0} \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0438\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=\\u041F\\u043E\\u043A\\u0430\\u0437\\u0432\\u0430\\u043D 1 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=\\u0411\\u0440\\u043E\\u0439 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0438\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=\\u0413\\u0430\\u043B\\u0435\\u0440\\u0438\\u044F \\u0441 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u044F\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=\\u0424\\u0438\\u043B\\u0442\\u0440\\u0438\\u0440\\u0430\\u043D \\u043F\\u043E {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=\\u0417\\u0430\\u0440\\u0435\\u0436\\u0434\\u0430\\u043D\\u0435...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0438 \\u0441 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u043E\\u0442\\u043E\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_cs.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Nahl\\u00E1sit probl\\u00E9m s jakost\\u00ED\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=P\\u0159\\u00EDlohy\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=P\\u0159id\\u00E1no {0}, p\\u0159idal {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=\\u017D\\u00E1dn\\u00FD n\\u00E1zev souboru\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Popis\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Z\\u00E1vada\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Reference\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Kategorie\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Detailn\\u00ED popis\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Odeslat\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Zru\\u0161it\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Nahl\\u00E1\\u0161eno\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Stav\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Datum\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Nahl\\u00E1\\u0161en probl\\u00E9my s kvalitou\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Povinn\\u00E9 pole\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Neplatn\\u00E9 zad\\u00E1n\\u00ED\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Velikost obr\\u00E1zku by m\\u011Bla b\\u00FDt men\\u0161\\u00ED ne\\u017E {0} bajt\\u016F\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Nem\\u016F\\u017Eete p\\u0159ipojit v\\u00EDce obr\\u00E1zk\\u016F\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Chcete tento obr\\u00E1zek opravdu vymazat?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Smazat obr\\u00E1zek\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Typ souboru nen\\u00ED podporov\\u00E1n\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Zru\\u0161it\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=V\\u0161echny p\\u0159ipojen\\u00E9 obr\\u00E1zky nebyly odesl\\u00E1ny\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Vybrat kategorii\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Zvolit z\\u00E1vadu\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 z\\u00E1vady\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 kategorie\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Nov\\u00FD\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=Ve zpracov\\u00E1n\\u00ED\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Dokon\\u010Deno\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Odlo\\u017Eeno\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=Do\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Od\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Zadejte koncov\\u00E9 datum pro filtrov\\u00E1n\\u00ED\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Zadejte po\\u010D\\u00E1te\\u010Dn\\u00ED datum pro filtrov\\u00E1n\\u00ED\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=P\\u0159idat obr\\u00E1zek\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Byla zad\\u00E1na neplatn\\u00E1 data\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Datum by m\\u011Blo b\\u00FDt stejn\\u00E9 nebo pozd\\u011Bj\\u0161\\u00ED ne\\u017E po\\u010D\\u00E1te\\u010Dn\\u00ED datum\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Moje nahl\\u00E1\\u0161en\\u00E9 probl\\u00E9my ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=M\\u016Fj nahl\\u00E1\\u0161en\\u00FD probl\\u00E9m\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priorita\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=P\\u0159i\\u0159azeno k\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Ozn\\u00E1men\\u00ED\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Materi\\u00E1l\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Nastaven\\u00ED\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Z\\u00E1vod\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Zobrazit {0} probl\\u00E9m\\u016F\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Zobrazit 1 probl\\u00E9m\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Po\\u010Det probl\\u00E9m\\u016F\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Galerie obr\\u00E1zk\\u016F\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtrov\\u00E1no podle {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Zav\\u00E1d\\u00ED se...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=\\u017D\\u00E1dn\\u00E9 jakostn\\u00ED probl\\u00E9my nejsou k dispozici\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_de.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Qualit\\u00E4tsproblem melden\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Anlagen\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Hinzugef\\u00FCgt am {0} von {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Kein Dateiname\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Beschreibung\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Fehler\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Referenz\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Kategorisierung\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Detaillierte Beschreibung\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Anlegen\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Abbrechen\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Gemeldet am\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Status\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Datum\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Qualit\\u00E4tsproblem gemeldet\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Mussfeld\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Ung\\u00FCltige Eingabe\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Bildgr\\u00F6\\u00DFe sollte {0} Byte nicht \\u00FCberschreiten\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Sie k\\u00F6nnen keine weiteren Bilder anh\\u00E4ngen\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=M\\u00F6chten Sie dieses Bild l\\u00F6schen?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Bild l\\u00F6schen\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Dateityp wird nicht unterst\\u00FCtzt\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Abbrechen\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Nicht alle angeh\\u00E4ngten Bilder wurden \\u00FCbertragen\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Kategorisierung w\\u00E4hlen\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Fehler w\\u00E4hlen\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Keine Fehler verf\\u00FCgbar\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Keine Kategorisierungen verf\\u00FCgbar\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Neu\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=In Bearbeitung\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Abgeschlossen\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Zur\\u00FCckgestellt\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=Bis\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Von\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Enddatum zum Filtern eingeben\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Startdatum zum Filtern eingeben\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Bild hinzuf\\u00FCgen\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Ung\\u00FCltiges Datum eingegeben\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Bis-Datum soll gleich oder nach Von-Datum sein\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Meine gemeldeten Probleme ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Mein gemeldetes Problem\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priorit\\u00E4t\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Zugeordnet zu\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Meldung\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Material\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Einstellungen\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Werk\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES={0} Probleme anzeigen\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=1 Problem anzeigen\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Anzahl Probleme\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Bildergalerie\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Gefiltert nach {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Ladevorgang l\\u00E4uft...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Keine Qualit\\u00E4tsprobleme verf\\u00FCgbar\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_en.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Report Quality Issue\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Attachments\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Added on {0} by {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=No file name\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Description\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Defect\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Reference\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Category\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Detailed Description\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Submit\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Cancel\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Reported On\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Status\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Date\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Quality issue reported\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Mandatory field\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Invalid input\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Image size should be less than {0} bytes\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=You cannot attach more images\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Are you sure you want to delete this image?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Delete Image\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=File type not supported\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Cancel\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Not all attached images were submitted\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Choose Category\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Choose Defect\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=No defects available\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=No categories available\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=New\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=In Process\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Completed\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Postponed\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=To\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=From\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Enter end date for filtering\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Enter start date for filtering\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Add Image\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Invalid date entered\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=To Date should be equal to or later than From Date\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=My Reported Issues ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=My Reported Issue\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priority\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Assigned To\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Notification\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Material\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Settings\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Plant\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Display {0} Issues\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Display 1 Issue\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Number of Issues\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Image Gallery\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtered by {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Loading...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=No Quality Issues Available\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_en_US_sappsd.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=[[[\\u0158\\u0113\\u03C1\\u014F\\u0157\\u0163 \\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u012C\\u015F\\u015F\\u0171\\u0113]]]\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=[[[\\u0100\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163\\u015F]]]\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=[[[\\u0100\\u018C\\u018C\\u0113\\u018C \\u014F\\u014B {0} \\u0183\\u0177 ]]]{1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=[[[\\u0143\\u014F \\u0192\\u012F\\u013A\\u0113 \\u014B\\u0105\\u0271\\u0113]]]\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=[[[\\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B]]]\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=[[[\\u010E\\u0113\\u0192\\u0113\\u010B\\u0163]]]\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=[[[\\u0158\\u0113\\u0192\\u0113\\u0157\\u0113\\u014B\\u010B\\u0113]]]\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=[[[\\u0108\\u0105\\u0163\\u0113\\u011F\\u014F\\u0157\\u0177]]]\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=[[[\\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u0113\\u018C \\u010E\\u0113\\u015F\\u010B\\u0157\\u012F\\u03C1\\u0163\\u012F\\u014F\\u014B]]]\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=[[[\\u015C\\u0171\\u0183\\u0271\\u012F\\u0163]]]\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A]]]\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=[[[\\u0158\\u0113\\u03C1\\u014F\\u0157\\u0163\\u0113\\u018C \\u014E\\u014B]]]\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=[[[\\u015C\\u0163\\u0105\\u0163\\u0171\\u015F]]]\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=[[[\\u010E\\u0105\\u0163\\u0113]]]\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=[[[\\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u012F\\u015F\\u015F\\u0171\\u0113 \\u0157\\u0113\\u03C1\\u014F\\u0157\\u0163\\u0113\\u018C]]]\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=[[[\\u039C\\u0105\\u014B\\u018C\\u0105\\u0163\\u014F\\u0157\\u0177 \\u0192\\u012F\\u0113\\u013A\\u018C]]]\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=[[[\\u012C\\u014B\\u028B\\u0105\\u013A\\u012F\\u018C \\u012F\\u014B\\u03C1\\u0171\\u0163]]]\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=[[[\\u012C\\u0271\\u0105\\u011F\\u0113 \\u015F\\u012F\\u017E\\u0113 \\u015F\\u0125\\u014F\\u0171\\u013A\\u018C \\u0183\\u0113 \\u013A\\u0113\\u015F\\u015F \\u0163\\u0125\\u0105\\u014B {0} \\u0183\\u0177\\u0163\\u0113\\u015F]]]\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=[[[\\u0176\\u014F\\u0171 \\u010B\\u0105\\u014B\\u014B\\u014F\\u0163 \\u0105\\u0163\\u0163\\u0105\\u010B\\u0125 \\u0271\\u014F\\u0157\\u0113 \\u012F\\u0271\\u0105\\u011F\\u0113\\u015F]]]\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=[[[\\u0100\\u0157\\u0113 \\u0177\\u014F\\u0171 \\u015F\\u0171\\u0157\\u0113 \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u018C\\u0113\\u013A\\u0113\\u0163\\u0113 \\u0163\\u0125\\u012F\\u015F \\u012F\\u0271\\u0105\\u011F\\u0113?]]]\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=[[[\\u010E\\u0113\\u013A\\u0113\\u0163\\u0113 \\u012C\\u0271\\u0105\\u011F\\u0113]]]\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=[[[\\u0191\\u012F\\u013A\\u0113 \\u0163\\u0177\\u03C1\\u0113 \\u014B\\u014F\\u0163 \\u015F\\u0171\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0113\\u018C]]]\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=[[[\\u014E\\u0136]]]\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A]]]\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=[[[\\u0143\\u014F\\u0163 \\u0105\\u013A\\u013A \\u0105\\u0163\\u0163\\u0105\\u010B\\u0125\\u0113\\u018C \\u012F\\u0271\\u0105\\u011F\\u0113\\u015F \\u0175\\u0113\\u0157\\u0113 \\u015F\\u0171\\u0183\\u0271\\u012F\\u0163\\u0163\\u0113\\u018C]]]\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=[[[\\u0108\\u0125\\u014F\\u014F\\u015F\\u0113 \\u0108\\u0105\\u0163\\u0113\\u011F\\u014F\\u0157\\u0177]]]\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=[[[\\u0108\\u0125\\u014F\\u014F\\u015F\\u0113 \\u010E\\u0113\\u0192\\u0113\\u010B\\u0163]]]\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=[[[\\u0143\\u014F \\u018C\\u0113\\u0192\\u0113\\u010B\\u0163\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113]]]\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=[[[\\u0143\\u014F \\u010B\\u0105\\u0163\\u0113\\u011F\\u014F\\u0157\\u012F\\u0113\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=[[[\\u0143\\u0113\\u0175]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=[[[\\u012C\\u014B \\u01A4\\u0157\\u014F\\u010B\\u0113\\u015F\\u015F]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=[[[\\u0108\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113\\u018C]]]\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=[[[\\u01A4\\u014F\\u015F\\u0163\\u03C1\\u014F\\u014B\\u0113\\u018C]]]\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=[[[\\u0162\\u014F]]]\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=[[[\\u0191\\u0157\\u014F\\u0271]]]\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=[[[\\u0114\\u014B\\u0163\\u0113\\u0157 \\u0113\\u014B\\u018C \\u018C\\u0105\\u0163\\u0113 \\u0192\\u014F\\u0157 \\u0192\\u012F\\u013A\\u0163\\u0113\\u0157\\u012F\\u014B\\u011F]]]\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=[[[\\u0114\\u014B\\u0163\\u0113\\u0157 \\u015F\\u0163\\u0105\\u0157\\u0163 \\u018C\\u0105\\u0163\\u0113 \\u0192\\u014F\\u0157 \\u0192\\u012F\\u013A\\u0163\\u0113\\u0157\\u012F\\u014B\\u011F]]]\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=[[[\\u0100\\u018C\\u018C \\u012C\\u0271\\u0105\\u011F\\u0113]]]\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=[[[\\u012C\\u014B\\u028B\\u0105\\u013A\\u012F\\u018C \\u010E\\u0105\\u0163\\u0113 \\u0114\\u014B\\u0163\\u0113\\u0157\\u0113\\u018C]]]\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=[[[\\u0162\\u014F \\u010E\\u0105\\u0163\\u0113 \\u015F\\u0125\\u014F\\u0171\\u013A\\u018C \\u0183\\u0113 \\u0113\\u01A3\\u0171\\u0105\\u013A \\u0163\\u014F \\u014F\\u0157 \\u013A\\u0105\\u0163\\u0113\\u0157 \\u0163\\u0125\\u0105\\u014B \\u0191\\u0157\\u014F\\u0271 \\u010E\\u0105\\u0163\\u0113]]]\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=[[[\\u039C\\u0177 \\u0158\\u0113\\u03C1\\u014F\\u0157\\u0163\\u0113\\u018C \\u012C\\u015F\\u015F\\u0171\\u0113\\u015F ({0})]]]\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=[[[\\u039C\\u0177 \\u0158\\u0113\\u03C1\\u014F\\u0157\\u0163\\u0113\\u018C \\u012C\\u015F\\u015F\\u0171\\u0113]]]\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=[[[\\u01A4\\u0157\\u012F\\u014F\\u0157\\u012F\\u0163\\u0177]]]\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=[[[\\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0113\\u018C \\u0162\\u014F]]]\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=[[[\\u0143\\u014F\\u0163\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B]]]\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=[[[\\u039C\\u0105\\u0163\\u0113\\u0157\\u012F\\u0105\\u013A]]]\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=[[[\\u015C\\u0113\\u0163\\u0163\\u012F\\u014B\\u011F\\u015F]]]\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=[[[\\u01A4\\u013A\\u0105\\u014B\\u0163]]]\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=[[[\\u010E\\u012F\\u015F\\u03C1\\u013A\\u0105\\u0177 {0} \\u012C\\u015F\\u015F\\u0171\\u0113\\u015F]]]\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=[[[\\u010E\\u012F\\u015F\\u03C1\\u013A\\u0105\\u0177 1 \\u012C\\u015F\\u015F\\u0171\\u0113]]]\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=[[[\\u0143\\u0171\\u0271\\u0183\\u0113\\u0157 \\u014F\\u0192 \\u012C\\u015F\\u015F\\u0171\\u0113\\u015F]]]\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=[[[\\u012C\\u0271\\u0105\\u011F\\u0113 \\u0122\\u0105\\u013A\\u013A\\u0113\\u0157\\u0177]]]\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=[[[\\u0191\\u012F\\u013A\\u0163\\u0113\\u0157\\u0113\\u018C \\u0183\\u0177 ]]]{0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=[[[\\u013B\\u014F\\u0105\\u018C\\u012F\\u014B\\u011F...]]]\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=[[[\\u0143\\u014F \\u01EC\\u0171\\u0105\\u013A\\u012F\\u0163\\u0177 \\u012C\\u015F\\u015F\\u0171\\u0113\\u015F \\u0100\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113]]]\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_en_US_saptrc.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=hNmth4TMLj3FIoKkPVIYLQ_Report Quality Issue\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=IMQ4hezZ9KYMFIPscIea5Q_Attachments\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=2Wfo4SUaRQMuyk2zHF2JWA_Added on {0} by {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=R0xOsOIJV/eSjzPH+wQgKg_No file name\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=DtMmozE2peFHEu0PdTg4Eg_Description\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=2CikEcjFOtC2tdvhLWsvew_Defect\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=tBD9AGI4GrDiL+EBpX8oSQ_Reference\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Qshu8/7KUQ6vCRas8JBTnQ_Category\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=RA4rb7K0wyc+k/L2IjediA_Detailed Description\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=KtVAPoeHfLhlGBenTk9C3w_Submit\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=pv1nEObP0HzbHKHkSY1HJA_Cancel\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=4IcFK431pIdHZ0LZSvKh5g_Reported On\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=YV4X+4asyA+0qbcCAlY3Dw_Status\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=X1f3bLHt0a0Tv1kPGZLj0A_Date\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=85RDpqrq/KSMcbsc+etkPw_Quality issue reported\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=fKKi9Ec6riIv0oi3P5JomA_Mandatory field\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=cmYjKNgOL8+EHrliTYW6+g_Invalid input\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=Y4YDn0DrdQS57+k3aHIb9g_Image size should be less than {0} bytes\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=Sdv040mgdIZnoiP/kiLv1w_You cannot attach more images\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=AvshkLPIXCEKfl6PsIZoGA_Are you sure you want to delete this image?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=EM3KhpVDGEOMGEJqd8WlWw_Delete Image\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=SojqSfp3+3Rw/NRaO/8IgA_File type not supported\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=celclp8c/Yfhfw1Q3kpFfg_OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=6xwLFDb1AMElnMa2IMTnJQ_Cancel\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=g1rqp5SMUwhtKM5tKb7D3w_Not all attached images were submitted\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=P6noi974NNiEDND0WoCh5g_Choose Category\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=HbB2VvUmW2wksolG1gNQAA_Choose Defect\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=IdI9NWrvKxIhLSALBBlNzA_No defects available\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=2dpGitQ/YbQ9Ibv6Qa3ADA_No categories available\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=vX73VXweoNYBwqn/+kDh9A_New\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=akdNnu+XRyFBtGj5l51bFQ_In Process\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=JAmMgxT77gutVLqcYD6g7g_Completed\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=7Wc48wKlJM92GJ9HbmWJ9g_Postponed\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=7y5bLkFtaAQuDomAgRdECg_To\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=mextJl0P1yLK6UXwWvs8RA_From\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=7N1I3hSL4lHup7+RnJjxig_Enter end date for filtering\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=y60mUrJ8mtK09m+AOF+ovw_Enter start date for filtering\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=DhF8HrQkaydmOjx5p5LxHg_Add Image\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=jw1viy2ynOYGIle2jbXGHQ_Invalid Date Entered\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Rd60Ug08cU6JuwoMRqPnMw_To Date should be equal to or later than From Date\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=9o28ZStQyJfRuvne96hOFA_My Reported Issues ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=kKUMlEea/GFf1LGWrEp7WQ_My Reported Issue\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=jrrz+XgqqDXsvyCMfbh1Pg_Priority\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=yjmjv7jt7wpdgx2dH9qZPA_Assigned To\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=/NPYiwHNgjhJDH1djqeEOA_Notification\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=sz9mqi6z9kWtokKfoZRrfQ_Material\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=S2blTlz2NIy7wSWezf8CJw_Settings\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=plaPHZQL/HXXpbl1COvzXQ_Plant\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=TWP63FgN8XW8R8HF9bLljA_Display {0} Issues\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=+EOkoCaMfv7YNTU8erTbMw_Display 1 Issue\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=00zsZGeTjeDdeUhyHQPGOg_Number of Issues\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=MhpIzVm7GfDH0qM3j1TcFw_Image Gallery\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=cVYclxX1k+iMNdmEcyC8Iw_Filtered by {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=KEyFERi87pD2DaAc6/9lbw_Loading...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=n4l7ZtRAW/5rnJhofbEuPg_No Quality Issues Available\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_es.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Notificar problema de calidad\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Anexos\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=A\\u00F1adido el {0} por {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Sin nombre de fichero\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Descripci\\u00F3n\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Defecto\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Referencia\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Categor\\u00EDa\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Descripci\\u00F3n detallada\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Enviar\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Cancelar\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Notificado el\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Estado\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Fecha\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Problema de calidad notificado\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Campo obligatorio\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Entrada no v\\u00E1lida\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=El tama\\u00F1o de la imagen debe ser menos de {0} bytes\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=No puede adjuntar m\\u00E1s im\\u00E1genes\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=\\u00BFEst\\u00E1 seguro que desea eliminar esta imagen?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Borrar imagen\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=El tipo de fichero no se admite\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Cancelar\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=No se han enviado todas las im\\u00E1genes adjuntas\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Seleccionar categor\\u00EDa\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Seleccionar defecto\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=No hay defectos disponibles\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=No hay categor\\u00EDas disponibles\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Nuevo\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=En proceso\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Completado\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Pospuesto\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=Hasta\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Desde\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Introduzca la fecha de fin para filtrar\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Introduzca la fecha de inicio para filtrar\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=A\\u00F1adir imagen\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Fecha no v\\u00E1lida indicada\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=La fecha de fin debe ser igual o posterior a la fecha de inicio\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Mis problemas notificados ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Mi problema notificado\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Prioridad\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Asignado a\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Aviso\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Material\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Opciones\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Centro\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Visualizar {0} problemas\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Visualizar 1 problema\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Cantidad de problemas\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Galer\\u00EDa de im\\u00E1genes\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtrado por {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Cargando...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=No hay problemas de calidad disponibles\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_fr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Signalement de probl\\u00E8me de qualit\\u00E9\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Pi\\u00E8ces jointes\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Ajout\\u00E9 le {0} par {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Aucun nom de fichier\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Description\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=D\\u00E9faut\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=R\\u00E9f\\u00E9rence\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Cat\\u00E9gorie\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Description d\\u00E9taill\\u00E9e\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Envoyer\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Interrompre\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Signal\\u00E9 le\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Statut\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Date\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Probl\\u00E8me de qualit\\u00E9 signal\\u00E9\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Zone obligatoire\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Entr\\u00E9e non valide\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=La taille de l\'\'image doit \\u00EAtre inf\\u00E9rieure \\u00E0 {0} octets.\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Vous ne pouvez pas joindre plus d\'images.\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Voulez-vous vraiment supprimer cette image ?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Supprimer image\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Type de fichier non pris en charge\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Interrompre\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Toutes les images jointes n\'ont pas \\u00E9t\\u00E9 envoy\\u00E9es.\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=S\\u00E9lectionner cat\\u00E9gorie\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=S\\u00E9lectionner d\\u00E9faut\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Aucun d\\u00E9faut disponible\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Aucune cat\\u00E9gorie disponible\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Nouv.\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=En cours de traitement\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Term.\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Diff\\u00E9r\\u00E9\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=au\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=du\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Saisir date de fin pour le filtre\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Saisir date de d\\u00E9but pour le filtre\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Ajouter image\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Saisie de date erron\\u00E9e\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=La date de fin doit \\u00EAtre identique ou ult\\u00E9rieure \\u00E0 la date de d\\u00E9but.\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Mes probl\\u00E8mes signal\\u00E9s ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Mon probl\\u00E8me signal\\u00E9\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priorit\\u00E9\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Affect\\u00E9 \\u00E0\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Avis\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Article\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Options\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Division\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Afficher {0} probl\\u00E8mes\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Afficher 1 probl\\u00E8me\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Nombre de probl\\u00E8mes\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Gal\\u00E9rie d\'images\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtr\\u00E9 par {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Chargement...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Aucun probl\\u00E8me de qualit\\u00E9 disponible\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_hr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=Prijava problema kvalitete\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=Prilozi\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=Dodano dana {0} od {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=Nema naziva datoteke\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=Opis\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=Nedostatak\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=Referenca\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Kategorija\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=Detaljni opis\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=Podnesi\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=Otka\\u017Ei\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=Datum prijave\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=Status\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=Datum\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=Problem kvalitete prijavljen\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=Obavezno polje\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=Neva\\u017Ee\\u0107i unos\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=Veli\\u010Dina slike treba biti manje od {0} bajtova\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=Ne mo\\u017Eete prilo\\u017Eiti vi\\u0161e slika\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=\\u017Delite li zaista izbrisati ovu sliku?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=Izbri\\u0161i sliku\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=Tip datoteke nije podr\\u017Ean\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=U redu\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=Otka\\u017Ei\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=Nisu podnesene sve prilo\\u017Eene slike\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=Izaberi kategoriju\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=Izaberi nedostatak\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=Nedostaci nisu raspolo\\u017Eivi\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=Kategorije nisu raspolo\\u017Eive\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=Novo\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=U obradi\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=Dovr\\u0161eno\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=Odgo\\u0111eno\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=Do\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=Od\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=Unesite zavr\\u0161ni datum za filtriranje\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=Unesite po\\u010Detni datum za filtriranje\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=Dodaj sliku\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=Unesen neva\\u017Ee\\u0107i datum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Datum do mora biti jednak datumu od ili prije njega\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=Moj prijavljeni problemi ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=Moj prijavljeni problem\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=Prioritet\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=Dodijeljeno\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=Obavijest\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=Materijal\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=Postave\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=Pogon\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=Prika\\u017Ei {0} problema\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=Prika\\u017Ei 1 problem\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=Broj problema\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=Galerija slika\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=Filtrirano prema {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=U\\u010Ditavanje...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=Problemi kvalitete nisu raspolo\\u017Eivi\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_hu.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Min\\u0151s\\u00E9gprobl\\u00E9ma jelent\\u00E9se\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Mell\\u00E9kletek\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Hozz\\u00E1adta {0} {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Nincs f\\u00E1jln\\u00E9v\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Le\\u00EDr\\u00E1s\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Hiba\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Referencia\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Kateg\\u00F3ria\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=R\\u00E9szletes le\\u00EDr\\u00E1s\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Elk\\u00FCld\\u00E9s\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=M\\u00E9gse\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Jelent\\u00E9s d\\u00E1tuma\\:\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=St\\u00E1tus\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=D\\u00E1tum\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Min\\u0151s\\u00E9gprobl\\u00E9ma jelentve\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=K\\u00F6telez\\u0151 mez\\u0151\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=\\u00C9rv\\u00E9nytelen bevitel\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=A k\\u00E9p m\\u00E9rete legyen kisebb {0} b\\u00E1jtn\\u00E1l\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Nem csatolhat\\u00F3 t\\u00F6bb k\\u00E9p\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Val\\u00F3ban t\\u00F6r\\u00F6lni szeretn\\u00E9 ezt a k\\u00E9pet?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=K\\u00E9p t\\u00F6rl\\u00E9se\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=A f\\u00E1jlt\\u00EDpus nem t\\u00E1mogatott\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=Rendben\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=M\\u00E9gse\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Nem t\\u00F6rt\\u00E9nt meg az \\u00F6sszes csatolt k\\u00E9p \\u00E1tvitele\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Kateg\\u00F3ria v\\u00E1laszt\\u00E1sa\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Hiba v\\u00E1laszt\\u00E1sa\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Nincs el\\u00E9rhet\\u0151 hiba\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Nem \\u00E9rhet\\u0151 el kateg\\u00F3ria\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=\\u00DAj\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=Feldolgoz\\u00E1s alatt\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Befejez\\u0151d\\u00F6tt\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Vissza\\u00E1ll\\u00EDtva\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=A k\\u00F6vetkez\\u0151ig\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Kezd\\u00E9s\\:\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Z\\u00E1r\\u00F3 d\\u00E1tum megad\\u00E1sa sz\\u0171r\\u00E9shez\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Kezd\\u0151 d\\u00E1tum megad\\u00E1sa sz\\u0171r\\u00E9shez\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=K\\u00E9p hozz\\u00E1ad\\u00E1sa\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=A megadott d\\u00E1tum \\u00E9rv\\u00E9nytelen\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=A z\\u00E1r\\u00F3 d\\u00E1tum legfeljebb ugyanakkor, vagy k\\u00E9s\\u0151bb lehet mint a kezd\\u0151 d\\u00E1tum\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Jelentett saj\\u00E1t probl\\u00E9m\\u00E1k ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Saj\\u00E1t jelentett probl\\u00E9m\\u00E1k\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priorit\\u00E1s\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Hozz\\u00E1rendelve a k\\u00F6vetkez\\u0151h\\u00F6z\\:\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Jelent\\u00E9s\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Anyag\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Be\\u00E1ll\\u00EDt\\u00E1sok\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Gy\\u00E1r\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Probl\\u00E9m\\u00E1k {0} megjelen\\u00EDt\\u00E9se\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=1 probl\\u00E9ma megjelen\\u00EDt\\u00E9se\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Probl\\u00E9m\\u00E1k sz\\u00E1ma\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=K\\u00E9pgal\\u00E9ria\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Sz\\u0171r\\u00E9s k\\u00F6vetkez\\u0151 szerint\\: {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Bet\\u00F6lt\\u00E9s...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Nem \\u00E1ll rendelkez\\u00E9sre min\\u0151s\\u00E9gi probl\\u00E9ma\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_it.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Segnala problema di qualit\\u00E0\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Allegati\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Aggiunto il {0} da {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Nessun nome file\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Descrizione\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Difetto\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Riferimento\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Categoria\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Descrizione dettagliata\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Invia\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Annulla\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Data segnalazione\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Stato\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Data\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Problema di qualit\\u00E0 segnalato\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Campo obbligatorio\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Input non valido\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Le dimensioni dell\'\'immagine devono essere inferiori a {0} byte\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Impossibile allegare altre immagini\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Confermare l\'eliminazione di questa immagine?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Elimina immagine\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Tipo di file non supportato\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Annulla\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Non tutte le immagini allegate sono state inviate\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Seleziona una categoria\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Seleziona un difetto\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Nessun difetto disponibile\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Nessuna categoria disponibile\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Nuovo\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=In elaborazione\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Completato\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Posticipato\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=A\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Da\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Inserisci data di fine per filtro\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Inserisci data di inizio per filtro\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Aggiungi immagine\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Data non valida inserita\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=La data di fine dovrebbe essere uguale o successiva alla data di inizio\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=I miei problemi segnalati ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Il mio problema segnalato\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priorit\\u00E0\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Attribuito a\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Avviso\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Materiale\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Impostazioni\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Divisione\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Visualizza {0} problemi\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Visualizza 1 problema\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Numero di problemi\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Galleria immagini\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtrato in base a {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=In caricamento...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Nessun problema di qualit\\u00E0 disponibile\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_iw.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=\\u05D3\\u05D5\\u05D5\\u05D7 \\u05E2\\u05DC \\u05E1\\u05D5\\u05D2\\u05D9\\u05D9\\u05EA \\u05D0\\u05D9\\u05DB\\u05D5\\u05EA\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=\\u05E7\\u05D1\\u05E6\\u05D9\\u05DD \\u05DE\\u05E6\\u05D5\\u05E8\\u05E4\\u05D9\\u05DD\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=\\u05E0\\u05D5\\u05E1\\u05E3 \\u05D1\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA {0} \\u05E2\\u05DC-\\u05D9\\u05D3\\u05D9 {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=\\u05D0\\u05D9\\u05DF \\u05E9\\u05DD \\u05E7\\u05D5\\u05D1\\u05E5\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=\\u05E4\\u05D2\\u05DD\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=\\u05E1\\u05D9\\u05DE\\u05D5\\u05DB\\u05D9\\u05DF\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=\\u05E7\\u05D8\\u05D2\\u05D5\\u05E8\\u05D9\\u05D4\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=\\u05EA\\u05D9\\u05D0\\u05D5\\u05E8 \\u05DE\\u05E4\\u05D5\\u05E8\\u05D8\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=\\u05D4\\u05D2\\u05E9\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=\\u05D1\\u05D8\\u05DC\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=\\u05D3\\u05D5\\u05D5\\u05D7 \\u05D1-\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=\\u05E1\\u05D8\\u05D0\\u05D8\\u05D5\\u05E1\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=\\u05E1\\u05D5\\u05D2\\u05D9\\u05D9\\u05EA \\u05D4\\u05D0\\u05D9\\u05DB\\u05D5\\u05EA \\u05D3\\u05D5\\u05D5\\u05D7\\u05D4\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=\\u05E9\\u05D3\\u05D4 \\u05D7\\u05D5\\u05D1\\u05D4\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=\\u05E7\\u05DC\\u05D8 \\u05DC\\u05D0 \\u05D7\\u05D5\\u05E7\\u05D9\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=\\u05D2\\u05D5\\u05D3\\u05DC \\u05D4\\u05EA\\u05DE\\u05D5\\u05E0\\u05D4 \\u05E6\\u05E8\\u05D9\\u05DA \\u05DC\\u05D4\\u05D9\\u05D5\\u05EA \\u05E0\\u05DE\\u05D5\\u05DA \\u05DE-{0} \\u05D1\\u05D9\\u05D9\\u05D8\\u05D9\\u05DD\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=\\u05D0\\u05D9\\u05DF \\u05D1\\u05D0\\u05E4\\u05E9\\u05E8\\u05D5\\u05EA\\u05DA \\u05DC\\u05E6\\u05E8\\u05E3 \\u05EA\\u05DE\\u05D5\\u05E0\\u05D5\\u05EA \\u05E0\\u05D5\\u05E1\\u05E4\\u05D5\\u05EA\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=\\u05D4\\u05D0\\u05DD \\u05D0\\u05EA\\u05D4 \\u05D1\\u05D8\\u05D5\\u05D7 \\u05E9\\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05DE\\u05D7\\u05D5\\u05E7 \\u05EA\\u05DE\\u05D5\\u05E0\\u05D4 \\u05D6\\u05D5?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=\\u05DE\\u05D7\\u05E7 \\u05EA\\u05DE\\u05D5\\u05E0\\u05D4\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=\\u05E1\\u05D5\\u05D2 \\u05D4\\u05E7\\u05D5\\u05D1\\u05E5 \\u05D0\\u05D9\\u05E0\\u05D5 \\u05E0\\u05EA\\u05DE\\u05DA\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=\\u05D1\\u05D8\\u05DC\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=\\u05DC\\u05D0 \\u05DB\\u05DC \\u05D4\\u05EA\\u05DE\\u05D5\\u05E0\\u05D5\\u05EA \\u05D4\\u05DE\\u05E6\\u05D5\\u05E8\\u05E4\\u05D5\\u05EA \\u05D4\\u05D5\\u05D2\\u05E9\\u05D5\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=\\u05D1\\u05D7\\u05E8 \\u05E7\\u05D8\\u05D2\\u05D5\\u05E8\\u05D9\\u05D4\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=\\u05D1\\u05D7\\u05E8 \\u05E4\\u05D2\\u05DD\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=\\u05D0\\u05D9\\u05DF \\u05E4\\u05D2\\u05DE\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=\\u05D0\\u05D9\\u05DF \\u05E7\\u05D8\\u05D2\\u05D5\\u05E8\\u05D9\\u05D5\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D5\\u05EA\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=\\u05D7\\u05D3\\u05E9\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=\\u05D1\\u05EA\\u05D4\\u05DC\\u05D9\\u05DA\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=\\u05D4\\u05D5\\u05E9\\u05DC\\u05DD\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=\\u05E0\\u05D3\\u05D7\\u05D4\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=\\u05E2\\u05D3\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=\\u05DE-\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=\\u05D4\\u05D6\\u05DF \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05E1\\u05D9\\u05D5\\u05DD \\u05DC\\u05E1\\u05D9\\u05E0\\u05D5\\u05DF\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=\\u05D4\\u05D6\\u05DF \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05D4\\u05EA\\u05D7\\u05DC\\u05D4 \\u05DC\\u05E1\\u05D9\\u05E0\\u05D5\\u05DF\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=\\u05D4\\u05D5\\u05E1\\u05E3 \\u05EA\\u05DE\\u05D5\\u05E0\\u05D4\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=\\u05D4\\u05D5\\u05D6\\u05DF \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05DC\\u05D0 \\u05EA\\u05E7\\u05E3\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=\'\\u05E2\\u05D3 \\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\' \\u05E6\\u05E8\\u05D9\\u05DA \\u05DC\\u05D4\\u05D9\\u05D5\\u05EA \\u05D6\\u05D4\\u05D4 \\u05DC\'\\u05DE\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA\' \\u05D0\\u05D5 \\u05DC\\u05D7\\u05D5\\u05DC \\u05D0\\u05D7\\u05E8\\u05D9\\u05D5\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=\\u05D4\\u05E1\\u05D5\\u05D2\\u05D9\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9 \\u05E9\\u05D3\\u05D5\\u05D5\\u05D7\\u05D5 ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=\\u05D4\\u05E1\\u05D5\\u05D2\\u05D9\\u05D4 \\u05D4\\u05DE\\u05D3\\u05D5\\u05D5\\u05D7\\u05EA \\u05E9\\u05DC\\u05D9\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=\\u05E2\\u05D3\\u05D9\\u05E4\\u05D5\\u05EA\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=\\u05DE\\u05D5\\u05E7\\u05E6\\u05D4 \\u05DC-\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=\\u05D4\\u05D5\\u05D3\\u05E2\\u05D4\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=\\u05D7\\u05D5\\u05DE\\u05E8\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=\\u05D4\\u05D2\\u05D3\\u05E8\\u05D5\\u05EA\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=\\u05D0\\u05EA\\u05E8\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=\\u05D4\\u05E6\\u05D2 {0} \\u05E1\\u05D5\\u05D2\\u05D9\\u05D5\\u05EA\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=\\u05D4\\u05E6\\u05D2 \\u05E1\\u05D5\\u05D2\\u05D9\\u05D4 \\u05D0\\u05D7\\u05EA\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=\\u05DE\\u05E1\\u05E4\\u05E8 \\u05E1\\u05D5\\u05D2\\u05D9\\u05D5\\u05EA\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=\\u05D2\\u05DC\\u05E8\\u05D9\\u05D9\\u05EA \\u05EA\\u05DE\\u05D5\\u05E0\\u05D5\\u05EA\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=\\u05DE\\u05E1\\u05D5\\u05E0\\u05DF \\u05DC\\u05E4\\u05D9 {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=\\u05D8\\u05D5\\u05E2\\u05DF...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=\\u05D0\\u05D9\\u05DF \\u05E1\\u05D5\\u05D2\\u05D9\\u05D5\\u05EA \\u05D0\\u05D9\\u05DB\\u05D5\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D5\\u05EA\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_ja.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=\\u54C1\\u8CEA\\u554F\\u984C\\u306E\\u30EC\\u30DD\\u30FC\\u30C8\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=\\u6DFB\\u4ED8\\u6587\\u66F8\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE={0} \\u306B {1} \\u306B\\u3088\\u3063\\u3066\\u8FFD\\u52A0\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=\\u30D5\\u30A1\\u30A4\\u30EB\\u540D\\u306A\\u3057\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=\\u30C6\\u30AD\\u30B9\\u30C8\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=\\u4E0D\\u826F\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=\\u53C2\\u7167\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=\\u30AB\\u30C6\\u30B4\\u30EA\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=\\u8A73\\u7D30\\u30C6\\u30AD\\u30B9\\u30C8\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=\\u9001\\u4FE1\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=\\u4E2D\\u6B62\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=\\u30EC\\u30DD\\u30FC\\u30C8\\u65E5\\u4ED8\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=\\u30B9\\u30C6\\u30FC\\u30BF\\u30B9\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=\\u65E5\\u4ED8\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=\\u54C1\\u8CEA\\u554F\\u984C\\u304C\\u30EC\\u30DD\\u30FC\\u30C8\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=\\u5165\\u529B\\u5FC5\\u9808\\u9805\\u76EE\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=\\u5165\\u529B\\u304C\\u7121\\u52B9\\u3067\\u3059\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=\\u30A4\\u30E1\\u30FC\\u30B8\\u30B5\\u30A4\\u30BA\\u306F {0} \\u30D0\\u30A4\\u30C8\\u672A\\u6E80\\u3067\\u306A\\u3051\\u308C\\u3070\\u306A\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=\\u3053\\u308C\\u4EE5\\u4E0A\\u30A4\\u30E1\\u30FC\\u30B8\\u3092\\u6DFB\\u4ED8\\u3067\\u304D\\u307E\\u305B\\u3093\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=\\u3053\\u306E\\u30A4\\u30E1\\u30FC\\u30B8\\u3092\\u524A\\u9664\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=\\u30A4\\u30E1\\u30FC\\u30B8\\u524A\\u9664\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=\\u30B5\\u30DD\\u30FC\\u30C8\\u3055\\u308C\\u3066\\u3044\\u306A\\u3044\\u30D5\\u30A1\\u30A4\\u30EB\\u30BF\\u30A4\\u30D7\\u3067\\u3059\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=\\u4E2D\\u6B62\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=\\u6DFB\\u4ED8\\u3057\\u305F\\u30A4\\u30E1\\u30FC\\u30B8\\u306E\\u4E00\\u90E8\\u304C\\u9001\\u4FE1\\u3055\\u308C\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=\\u30AB\\u30C6\\u30B4\\u30EA\\u9078\\u629E\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=\\u4E0D\\u826F\\u9078\\u629E\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=\\u4E0D\\u826F\\u304C\\u3042\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=\\u30AB\\u30C6\\u30B4\\u30EA\\u304C\\u3042\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=\\u65B0\\u898F\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=\\u51E6\\u7406\\u4E2D\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=\\u5B8C\\u4E86\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=\\u5EF6\\u671F\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=\\u7D42\\u4E86\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=\\u958B\\u59CB\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=\\u30D5\\u30A3\\u30EB\\u30BF\\u306B\\u4F7F\\u7528\\u3059\\u308B\\u7D42\\u4E86\\u65E5\\u4ED8\\u3092\\u5165\\u529B\\u3057\\u307E\\u3059\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=\\u30D5\\u30A3\\u30EB\\u30BF\\u306B\\u4F7F\\u7528\\u3059\\u308B\\u958B\\u59CB\\u65E5\\u4ED8\\u3092\\u5165\\u529B\\u3057\\u307E\\u3059\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=\\u30A4\\u30E1\\u30FC\\u30B8\\u8FFD\\u52A0\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=\\u5165\\u529B\\u3055\\u308C\\u305F\\u65E5\\u4ED8\\u306F\\u7121\\u52B9\\u3067\\u3059\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=\\u7D42\\u4E86\\u65E5\\u4ED8\\u306F\\u958B\\u59CB\\u65E5\\u4ED8\\u4EE5\\u964D\\u306E\\u65E5\\u4ED8\\u3067\\u306A\\u3051\\u308C\\u3070\\u306A\\u308A\\u307E\\u305B\\u3093\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=\\u81EA\\u5206\\u304C\\u30EC\\u30DD\\u30FC\\u30C8\\u3057\\u305F\\u554F\\u984C ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=\\u81EA\\u5206\\u304C\\u30EC\\u30DD\\u30FC\\u30C8\\u3057\\u305F\\u554F\\u984C\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=\\u512A\\u5148\\u5EA6\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=\\u5272\\u5F53\\u5148\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=\\u901A\\u77E5\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=\\u54C1\\u76EE\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=\\u8A2D\\u5B9A\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=\\u30D7\\u30E9\\u30F3\\u30C8\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES={0} \\u4EF6\\u306E\\u554F\\u984C\\u3092\\u8868\\u793A\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=1 \\u4EF6\\u306E\\u554F\\u984C\\u3092\\u8868\\u793A\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=\\u554F\\u984C\\u306E\\u6570\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=\\u30A4\\u30E1\\u30FC\\u30B8\\u30AE\\u30E3\\u30E9\\u30EA\\u30FC\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY={0} \\u3067\\u30D5\\u30A3\\u30EB\\u30BF\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=\\u30ED\\u30FC\\u30C9\\u4E2D...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=\\u54C1\\u8CEA\\u554F\\u984C\\u306A\\u3057\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_no.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Rapporter kvalitetsproblem\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Vedlegg\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Tilf\\u00F8yd den {0} av {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Ingen filnavn\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Beskrivelse\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Feil\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Referanse\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Kategori\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Detaljert beskrivelse\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Overf\\u00F8r\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Avbryt\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Rapportert den\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Status\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Dato\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Kvalitetsproblem rapportert\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Obligatorisk felt\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Ugyldige inndata\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Bildest\\u00F8rrelsen m\\u00E5 v\\u00E6re mindre enn {0} byte\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Du kan ikke legge ved flere bilder\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Er du sikker p\\u00E5 at du vil slette dette bildet?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Slett bilde\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Filtype st\\u00F8ttes ikke\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Avbryt\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Ikke alle vedlagte biler er overf\\u00F8rt\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Velg kategori\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Velg feil\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Ingen feil er tilgjengelige\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Ingen kategorier er tilgjengelige\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Ny\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=Under behandling\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Fullf\\u00F8rt\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Utsatt\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=Til\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Fra\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Oppgi sluttdato for filtrering\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Oppgi startdato for filtrering\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Tilf\\u00F8y bilde\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Ugyldig dato oppgitt\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Til-dato m\\u00E5 v\\u00E6re lik eller ligge etter fra-dato\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Mine rapporterte problemer ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Mitt rapporterte problem\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Prioritet\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Tilordnet til\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Melding\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Material\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Innstillinger\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Fabrikk\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Vis {0} problemer\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Vis 1 problem\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Antall problemer\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Bildegalleri\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtrert etter {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Laster ...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Ingen kvalitetsproblemer tilgjengelig\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_pl.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Zg\\u0142o\\u015B problem jako\\u015Bciowy\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Za\\u0142\\u0105czniki\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Dodane dnia {0} przez {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Brak nazwy pliku\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Opis\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Wada\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Referencja\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Kategoria\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Opis szczeg\\u00F3\\u0142owy\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Wy\\u015Blij\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Anuluj\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Zg\\u0142oszone dnia\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Status\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Data\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Zg\\u0142oszono problem jako\\u015Bciowy\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Pole obowi\\u0105zkowe\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Nieprawid\\u0142owe dane wej\\u015Bciowe\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Rozmiar obrazu powinien by\\u0107 mniejszy ni\\u017C nast\\u0119puj\\u0105ca liczba bajt\\u00F3w\\: {0}\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Nie mo\\u017Cna za\\u0142\\u0105czy\\u0107 wi\\u0119cej obraz\\u00F3w\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Na pewno usun\\u0105\\u0107 ten obraz?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Usuwanie obrazu\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Typ pliku nie jest obs\\u0142ugiwany\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Anuluj\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Nie wys\\u0142ano wszystkich za\\u0142\\u0105czono obraz\\u00F3w\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Wybierz kategori\\u0119\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Wybierz wad\\u0119\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Brak dost\\u0119pnych wad\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Brak dost\\u0119pnych kategorii\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Nowy\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=W przetwarzaniu\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Zako\\u0144czono\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Odroczone\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=Do\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Od\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Wpisz dat\\u0119 ko\\u0144cow\\u0105 dla filtrowania\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Wpisz dat\\u0119 pocz\\u0105tkow\\u0105 dla filtrowania\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Dodaj obraz\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Wprowadzono nieprawid\\u0142ow\\u0105 dat\\u0119\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Data Do nie powinna wypada\\u0107 wcze\\u015Bniej ni\\u017C Data Od\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Moje zg\\u0142oszone problemy ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=M\\u00F3j zg\\u0142oszony problem\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Priorytet\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Przypisane do\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Zawiadomienie\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Materia\\u0142\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Ustawienia\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Zak\\u0142ad\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Wy\\u015Bwietl nast\\u0119puj\\u0105c\\u0105 liczb\\u0119 problem\\u00F3w\\: {0}\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Wy\\u015Bwietl 1 problem\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Liczba problem\\u00F3w\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Galeria obraz\\u00F3w\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Przefiltrowane wed\\u0142ug {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=\\u0141adowanie...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Brak problem\\u00F3w jako\\u015Bciowych\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_pt.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Reportar problema de qualidade\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Anexos\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=Adicionado em {0} por {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Arquivo sem nome\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Descri\\u00E7\\u00E3o\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Defeito\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Refer\\u00EAncia\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Categoria\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Descri\\u00E7\\u00E3o detalhada\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=Enviar\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=Anular\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Reportado em\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Status\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Data\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Problema de qualidade reportado\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Campo obrigat\\u00F3rio\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Entrada inv\\u00E1lida\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=O tamanho da imagem deve ser inferior a {0} bytes\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=N\\u00E3o \\u00E9 poss\\u00EDvel anexar mais imagens\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Excluir essa imagem?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Excluir imagem\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Tipo de arquivo n\\u00E3o suportado\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=OK\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=Anular\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Nem todas as imagens anexadas foram enviadas\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Selecionar categoria\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Selecionar defeito\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Nenhum defeito dispon\\u00EDvel\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Nenhuma categoria dispon\\u00EDvel\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Novo\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=Em andamento\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Conclu\\u00EDdo\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Adiado\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=At\\u00E9\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=De\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Inserir data final para filtragem\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Inserir data de in\\u00EDcio para filtragem\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Inserir imagem\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Data inv\\u00E1lida inserida\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=A data do fim deve ser igual ou posterior \\u00E0 data de in\\u00EDcio\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Meus problemas notificados ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Meu problema reportado\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=Prioridade\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=Atribu\\u00EDdo a\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Notifica\\u00E7\\u00E3o\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Material\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Configura\\u00E7\\u00F5es\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=Centro\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=Exibir {0} problemas\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=Exibir 1 problema\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=N\\u00BA de problemas\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Galeria de imagens\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtrado por {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Carregando...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Nenhum problema de qualidade dispon\\u00EDvel\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_ro.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=Raportare problem\\u0103 de calitate\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=Anexe\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=Ad\\u0103ugat de {0} de {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=Niciun nume de fi\\u015Fier\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=Descriere\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=Defect\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=Referin\\u0163\\u0103\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Categorie\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=Descriere detaliat\\u0103\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=Transmitere\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=Anulare\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=Raportat pe\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=Stare\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=Dat\\u0103\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=Problem\\u0103 de calitate raportat\\u0103\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=C\\u00E2mp de intrare obligatorie\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=Intrare nevalabil\\u0103\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=M\\u0103rime imagine nu trebuie s\\u0103 fie mai mic\\u0103 de {0} bytes\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=Nu mai pute\\u0163i anexa alte imagini\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=Sigur dori\\u0163i s\\u0103 \\u015Fterge\\u0163i aceast\\u0103 imagine?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=\\u015Etergere imagine\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=Tip de fi\\u015Fier nesuportat\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=Anulare\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=Nu toate imaginile anexate au fost transmise\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=Alegere categorie\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=Alegere defect\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=F\\u0103r\\u0103 defecte disponibile\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=Nu exist\\u0103 categorii disponibile\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=Nou\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=\\u00CEn prelucrare\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=Terminat\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=Am\\u00E2nat\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=P\\u00E2n\\u0103 la\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=De la\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=Introduce\\u0163i data de sf\\u00E2r\\u015Fit pt.filtrare\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=Introduce\\u0163i data de \\u00EEnceput pt.filtrare\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=Ad\\u0103ugare imagine\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=Dat\\u0103 nevalabil\\u0103 introdus\\u0103\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Data p\\u00E2n\\u0103 la trebuie s\\u0103 fie identic\\u0103 sau dup\\u0103 Data de la\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=Problemele mele raportate ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=Problema mea raportat\\u0103\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=Prioritate\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=Alocat la\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=Notificare\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=Material\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=Set\\u0103ri\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=Unitate logistic\\u0103\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=Afi\\u015Fare {0} probleme\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=Afi\\u015Fare 1 problem\\u0103\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=Num\\u0103r de probleme\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=Galerie de imagini\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=Filtrat dup\\u0103 {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=\\u00CEnc\\u0103rcare ...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=Nu sunt disponibile probleme de calitate\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_ru.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=\\u0421\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u0435 \\u043E \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0435 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0430\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=\\u041F\\u0440\\u0438\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u043B {0} {1}\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=\\u041D\\u0435\\u0442 \\u0438\\u043C\\u0435\\u043D\\u0438 \\u0444\\u0430\\u0439\\u043B\\u0430\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=\\u041E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=\\u0414\\u0435\\u0444\\u0435\\u043A\\u0442\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=\\u0421\\u0441\\u044B\\u043B\\u043A\\u0430\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=\\u041A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0435 \\u043E\\u043F\\u0438\\u0441\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=\\u041E\\u0442\\u043F\\u0440\\u0430\\u0432\\u0438\\u0442\\u044C\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=\\u0414\\u0430\\u0442\\u0430 \\u0441\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=\\u0421\\u0442\\u0430\\u0442\\u0443\\u0441\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=\\u0414\\u0430\\u0442\\u0430\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=\\u0421\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u0435 \\u043E \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0435 \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0430 \\u0441\\u043E\\u0437\\u0434\\u0430\\u043D\\u043E\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=\\u041F\\u043E\\u043B\\u0435 \\u043E\\u0431\\u044F\\u0437\\u0430\\u0442\\u0435\\u043B\\u044C\\u043D\\u043E\\u0433\\u043E \\u0432\\u0432\\u043E\\u0434\\u0430\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=\\u041D\\u0435\\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u044B\\u0439 \\u0432\\u0432\\u043E\\u0434\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=\\u0420\\u0430\\u0437\\u043C\\u0435\\u0440 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u044F \\u0434\\u043E\\u043B\\u0436\\u0435\\u043D \\u0431\\u044B\\u0442\\u044C \\u043C\\u0435\\u043D\\u044C\\u0448\\u0435 {0} \\u0431\\u0430\\u0439\\u0442\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=\\u041D\\u0435\\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u0434\\u043E\\u0431\\u0430\\u0432\\u0438\\u0442\\u044C \\u0431\\u043E\\u043B\\u044C\\u0448\\u0435 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0439\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=\\u0423\\u0434\\u0430\\u043B\\u0438\\u0442\\u044C \\u044D\\u0442\\u043E \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=\\u0423\\u0434\\u0430\\u043B\\u0438\\u0442\\u044C \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=\\u0422\\u0438\\u043F \\u0444\\u0430\\u0439\\u043B\\u0430 \\u043D\\u0435 \\u043F\\u043E\\u0434\\u0434\\u0435\\u0440\\u0436\\u0438\\u0432\\u0430\\u0435\\u0442\\u0441\\u044F\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=\\u041E\\u041A\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=\\u041D\\u0435 \\u0432\\u0441\\u0435 \\u043F\\u0440\\u0438\\u043B\\u0430\\u0433\\u0430\\u0435\\u043C\\u044B\\u0435 \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u044F \\u043E\\u0442\\u043F\\u0440\\u0430\\u0432\\u043B\\u0435\\u043D\\u044B\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=\\u0412\\u044B\\u0431\\u0440\\u0430\\u0442\\u044C \\u043A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044E\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=\\u0412\\u044B\\u0431\\u0440\\u0430\\u0442\\u044C \\u0434\\u0435\\u0444\\u0435\\u043A\\u0442\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0434\\u0435\\u0444\\u0435\\u043A\\u0442\\u043E\\u0432\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u043A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u0439\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=\\u041D\\u043E\\u0432\\u043E\\u0435\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=\\u0412 \\u043E\\u0431\\u0440\\u0430\\u0431\\u043E\\u0442\\u043A\\u0435\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=\\u0412\\u044B\\u043F\\u043E\\u043B\\u043D\\u0435\\u043D\\u043E\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=\\u041E\\u0442\\u043B\\u043E\\u0436\\u0435\\u043D\\u043E\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=\\u041F\\u043E\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=\\u0421\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=\\u0412\\u0432\\u0435\\u0441\\u0442\\u0438 \\u043A\\u043E\\u043D\\u0435\\u0447\\u043D\\u0443\\u044E \\u0434\\u0430\\u0442\\u0443 \\u0434\\u043B\\u044F \\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=\\u0412\\u0432\\u0435\\u0441\\u0442\\u0438 \\u043D\\u0430\\u0447\\u0430\\u043B\\u044C\\u043D\\u0443\\u044E \\u0434\\u0430\\u0442\\u0443 \\u0434\\u043B\\u044F \\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u0442\\u044C \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=\\u0412\\u0432\\u0435\\u0434\\u0435\\u043D\\u0430 \\u043D\\u0435\\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u0430\\u044F \\u0434\\u0430\\u0442\\u0430\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=\\u0414\\u0430\\u0442\\u0430 \\u043E\\u043A\\u043E\\u043D\\u0447\\u0430\\u043D\\u0438\\u044F \\u0434\\u043E\\u043B\\u0436\\u043D\\u0430 \\u0431\\u044B\\u0442\\u044C \\u043D\\u0435 \\u0440\\u0430\\u043D\\u044C\\u0448\\u0435 \\u0434\\u0430\\u0442\\u044B \\u043D\\u0430\\u0447\\u0430\\u043B\\u0430\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=\\u041C\\u043E\\u0438 \\u0441\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u044F \\u043E \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\u0445 ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=\\u041C\\u043E\\u0435 \\u0441\\u043E\\u043E\\u0431\\u0449\\u0435\\u043D\\u0438\\u0435 \\u043E \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0435\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=\\u041F\\u0440\\u0438\\u043E\\u0440\\u0438\\u0442\\u0435\\u0442\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=\\u041F\\u0440\\u0438\\u0441\\u0432\\u043E\\u0435\\u043D\\u043E\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=\\u0423\\u0432\\u0435\\u0434\\u043E\\u043C\\u043B\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=\\u041C\\u0430\\u0442\\u0435\\u0440\\u0438\\u0430\\u043B\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=\\u041D\\u0430\\u0441\\u0442\\u0440\\u043E\\u0439\\u043A\\u0438\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=\\u0417\\u0430\\u0432\\u043E\\u0434\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=\\u041F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C {0} \\u043F\\u0440\\u043E\\u0431\\u043B.\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=\\u041F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C 1 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0443\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=\\u0427\\u0438\\u0441\\u043B\\u043E \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=\\u0413\\u0430\\u043B\\u0435\\u0440\\u0435\\u044F \\u0438\\u0437\\u043E\\u0431\\u0440\\u0430\\u0436\\u0435\\u043D\\u0438\\u0439\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=\\u041E\\u0442\\u0444\\u0438\\u043B\\u044C\\u0442\\u0440\\u043E\\u0432\\u0430\\u043D\\u043E \\u043F\\u043E {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=\\u0417\\u0430\\u0433\\u0440\\u0443\\u0437\\u043A\\u0430...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=\\u041D\\u0435\\u0442 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C \\u043A\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0430\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_sh.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=Prijavi problem kvaliteta\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=Dodaci\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=Dodato {0} od strane {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=Nema naziva fajla\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=Opis\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=Gre\\u0161ka\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=Referenca\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Kategorija\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=Detaljni opis\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=Podnesi\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=Odustani\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=Prijavljeno\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=Status\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=Datum\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=Problem kvaliteta prijavljen\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=Obavezno polje\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=Neva\\u017Ee\\u0107i unos\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=Veli\\u010Dina slike treba da bude manje od {0} bajtova\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=Ne mo\\u017Eete da dodate vi\\u0161e slika\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=Da li sigurno \\u017Eelite da izbri\\u0161ete ovu sliku?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=Izbri\\u0161i sliku\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=Tip fajla nije podr\\u017Ean\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=Odustani\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=Sve dodate slike nisu podnete\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=Izaberi kategoriju\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=Izaberi nedostatak\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=Nema dostupnih nedostataka\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=Kategorije nisu dostupne\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=Novo\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=U obradi\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=Zavr\\u0161eno\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=Odlo\\u017Eeno\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=Do\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=Od\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=Unesi datum zavr\\u0161etka za filtriranje\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=Unesi datum po\\u010Detka za filtriranje\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=Dodaj sliku\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=Unet neva\\u017Ee\\u0107i datum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Datum zavr\\u0161etka treba da bude jednak datumu po\\u010Detka ili kasniji od njega\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=Moji prijavljeni problemi ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=Moj prijavljeni problem\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=Prioritet\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=Dodeljeno\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=Obave\\u0161tenje\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=Materijal\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=Pode\\u0161avanja\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=Pogon\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=Prika\\u017Ei {0} problema\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=Prika\\u017Ei 1 problem\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=Broj problema\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=Galerija slika\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=Filtrirano po {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=U\\u010Ditavanje...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=Nema dostupnih problema kvaliteta\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_sk.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=Hl\\u00E1senie probl\\u00E9mu s kvalitou\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=Pr\\u00EDlohy\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=Pridan\\u00E9 {0}, pridal {1}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=\\u017Diadny n\\u00E1zov s\\u00FAboru\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=Popis\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=Chyba\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=Referencia\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Kateg\\u00F3ria\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=Detailn\\u00FD popis\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=Odosla\\u0165\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=Zru\\u0161i\\u0165\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=Hl\\u00E1sen\\u00E9 d\\u0148a\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=Stav\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=D\\u00E1tum\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=Probl\\u00E9m s kvalitou nahl\\u00E1sen\\u00FD\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=Povinn\\u00E9 pole\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=Neplatn\\u00E9 zadanie\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=Ve\\u013Ekos\\u0165 obr\\u00E1zka mus\\u00ED by\\u0165 men\\u0161ia ako {0} bajtov\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=Nem\\u00F4\\u017Eete pripoji\\u0165 viac obr\\u00E1zkov\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=Naozaj chcete tento obr\\u00E1zok vymaza\\u0165?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=Vymaza\\u0165 obr\\u00E1zok\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=Typ s\\u00FAboru nie je podporovan\\u00FD\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=Zru\\u0161i\\u0165\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=Nie v\\u0161etky pripojen\\u00E9 obr\\u00E1zky boli odoslan\\u00E9\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=Zvoli\\u0165 kateg\\u00F3riu\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=Zvoli\\u0165 chybu\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne chyby\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne kateg\\u00F3rie\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=Nov\\u00E9\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=V spracovan\\u00ED\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=Dokon\\u010Den\\u00E9\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=Odlo\\u017Een\\u00E9\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=Do\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=Od\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=Zadajte koncov\\u00FD d\\u00E1tum pre filtrovanie\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=Zadajte po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum pre filtrovanie\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=Prida\\u0165 obr\\u00E1zok\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=Bol zadan\\u00FD neplatn\\u00FD d\\u00E1tum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Koncov\\u00FD d\\u00E1tum mus\\u00ED by\\u0165 rovnak\\u00FD alebo neskor\\u0161\\u00ED ako po\\u010Diato\\u010Dn\\u00FD d\\u00E1tum\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=Moje nahl\\u00E1sen\\u00E9 probl\\u00E9my ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=M\\u00F4j nahl\\u00E1sen\\u00FD probl\\u00E9m\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=Priorita\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=Priraden\\u00E9 k\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=Hl\\u00E1senie\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=Materi\\u00E1l\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=Nastavenia\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=Z\\u00E1vod\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=Zobrazi\\u0165 {0} probl\\u00E9mov\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=Zobrazi\\u0165 1 probl\\u00E9m\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=Po\\u010Det probl\\u00E9mov\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=Gal\\u00E9ria obr\\u00E1zkov\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=Filtrovan\\u00E9 pod\\u013Ea {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=Na\\u010D\\u00EDtava sa...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne probl\\u00E9my s kvalitou\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_sl.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \n\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: Title of the create quality issue application\nQI_TITLE_CREATE_VIEW=Prijava te\\u017Eave s kakovostjo\n\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\nQI_ATTACHMENT=Priloge\n\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \nQI_ATT_DOC_DATE=Dodal {1} dne {0}\n\n#XFLD: Label indicating that the attached file has no name \nQI_ATT_DOC_NAME=Brez naziva datoteke\n\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\nQI_DESCRIPTION=Opis\n\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\nQI_DEFECT=Napaka\n\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\nQI_REFERENCE=Referenca\n\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\nQI_CATEGORY=Kategorija\n\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\nQI_DETAIL_DESCRIPTION=Detajlni opis\n\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\nQI_SUBMIT=Po\\u0161iljanje\n\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\nQI_LIST=Prekinitev\n\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\nQI_REPORT_ON=Prijavljeno dne\n\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\nQI_STATUS_TEXT=Status\n\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\nQI_DATE=Datum\n\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\nQI_TXT_VALIDATION=Prijavljena te\\u017Eava s kakovostjo\n\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\nQI_DESC_ERROR=Obvezno polje\n\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\nQI_INVALID_ERROR=Neveljaven vnos\n\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\nQI_MAX_FILE_SIZE=Velikost slike mora biti manj\\u0161a od {0} bajtov\n\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\nQI_NO_MORE_IMAGES=Dodajanje ve\\u010D slik ni mogo\\u010De\n\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\nQI_DEL_IMG_QUESTION=Res \\u017Eelite izbrisati to sliko?\n\n#XTIT: Title of the dialog with which you remove an attached image\nQI_CONFIRM_ATT_DIALOG=Brisanje slike\n\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\nQI_FILE_TYPE_NOT_SUPPORTED=Tip datoteke ni podprt\n\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\nQI_CONFIRM_BTN=OK\n\n#XBUT: Label of the cancel button. \nQI_CANCEL_BTN=Prekinitev\n\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\nQI_ATT_SUBMIT_ERROR=Prenesene niso bile vse prilo\\u017Eene slike\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\nQI_CATEGORY_DIALOG_TITLE=Izbira kategorije\n\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\nQI_DEFECT_DIALOG_TITLE=Izbira napake\n\n#XMSG: Message for empty F4 dialog of the "Defect" field\nQI_DEFECT_DIALOG_EMPTY_MSG=Ni razpolo\\u017Eljivih napak\n\n#XMSG: Message for empty F4 dialog of the "Category" field\nQI_CATEGORY_DIALOG_EMPTY_MSG=Ni razpolo\\u017Eljivih kategorij\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_NEW=Novo\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_IN_PROCESS=V obdelavi\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_COMPLETED=Zaklju\\u010Deno\n\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\nQI_STATUS_POSTPONED=Odlo\\u017Eeno\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_TO=Do\n\n#XFLD: Label in the "Filter by Date" dialog.  \nQI_FROM=Od\n\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \nQI_TO_TOOLTIP=Vnos datuma konca za filtriranje\n\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \nQI_FROM_TOOLTIP=Vnos datuma za\\u010Detka za filtriranje\n\n#XBUT: Label for add picture control\nQI_ADD_IMG=Dodajanje slike\n\n#XMSG: Text of the message that indicates date values entered in filter are invalid \nQI_INVALID_DATES_ERROR=Vnesen neveljaven datum\n\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Datum konca mora biti enak ali za Datumom za\\u010Detka\n\n#----------------------Create view properties end--------------------------------------->\n\n#----------------------Master/Details view properties begin----------------------------->\n\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\nQI_TITLE_MASTER_VIEW=Moje sporo\\u010Dene te\\u017Eave ({0})\n\n#XTIT: Title of the section that lists the details of a selected issue\nDETAIL_TITLE=Moja prijavljena te\\u017Eava\n\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\nQI_PRIORITY=Prioriteta\n\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\nQI_DV_ASSIGN_TO=Dodeljeno za\n\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\nQI_DV_NOTIFICATION=Obvestilo\n\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\nQI_DV_MATERIAL=Material\n\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\nQI_MV_SETTINGS=Nastavitve\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_PLANT=Obrat\n\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\nQI_MAX_ISSUES=Prikaz {0} te\\u017Eav\n\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\nQI_MAX_ISSUES_ONE=Prikaz 1 te\\u017Eave\n\n#XFLD: Label of a field in the "Settings" dialog\nQI_NUMBER_ISSUES=\\u0160tevilo te\\u017Eav\n\n#XTIT: This is the title for image gallery\nQI_GALLERY_TITLE=Galerija slik\n\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\nQI_FILTERED_BY=Filtrirano po {0}\n\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \nQI_LOADING_TEXT=Nalaganje poteka ...\n\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\nQI_NO_DATA_AVAILABLE=Ni razpolo\\u017Eljivih te\\u017Eav s kakovostjo\n\n#----------------------Master/Details view properties end------------------------------->\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_tr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=Kalite sorunu bildir\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=Ekler\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE={0} tarihinde {1} taraf\\u0131ndan eklendi\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=Dosya ad\\u0131 yok\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=Tan\\u0131m\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=Hata\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=Referans\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=Kategori\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=Ayr\\u0131nt\\u0131l\\u0131 tan\\u0131m\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=G\\u00F6nder\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=\\u0130ptal\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=Bildirim tarihi\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=Durum\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=Tarih\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=Kalite sorunu bildirildi\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=Zorunlu alan\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=Ge\\u00E7ersiz girdi\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=Resim boyutu {0} bayttan az olmal\\u0131\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=Daha fazla resim ekleyemezsiniz\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=Bu resmi silmek istedi\\u011Finizden emin misiniz?\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=Resmi sil\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=Dosya t\\u00FCr\\u00FC desteklenmiyor\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=Tamam\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=\\u0130ptal\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=Eklenen t\\u00FCm resimler g\\u00F6nderilmedi\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=Kategori se\\u00E7\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=Hata se\\u00E7\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=Hata mevcut de\\u011Fil\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=Kategori mevcut de\\u011Fil\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=Yeni\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=\\u0130\\u015Fleniyor\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=Tamamland\\u0131\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=Ertelendi\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=Biti\\u015F\\:\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=Ba\\u015Flang\\u0131\\u00E7\\:\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=Filtreleme i\\u00E7in biti\\u015F tarihi girin\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=Filtreleme i\\u00E7in ba\\u015Flang\\u0131\\u00E7 tarihi girin\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=Resim ekle\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=Ge\\u00E7ersiz tarih girildi\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=Biti\\u015F tarihi ba\\u015Flang\\u0131\\u00E7 tarihi ile ayn\\u0131 veya sonra olmal\\u0131\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=Bildirilen sorunlar\\u0131m ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=Bildirilen sorunum\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=\\u00D6ncelik\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=\\u015Euna tayin edildi\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=Bildirim\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=Malzeme\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=Ayarlar\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=\\u00DCretim yeri\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES={0} sorunlar\\u0131 g\\u00F6r\\u00FCnt\\u00FCle\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=1 sorun g\\u00F6r\\u00FCnt\\u00FCle\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=Sorunlar\\u0131n say\\u0131s\\u0131\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=Resim galerisi\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=Filtreleme \\u00F6l\\u00E7\\u00FCt\\u00FC {0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=Y\\u00FCkleniyor...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=Kalite sorunlar\\u0131 mevcut de\\u011Fil\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/i18n/i18n_zh_CN.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen \r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: Title of the create quality issue application\r\nQI_TITLE_CREATE_VIEW=\\u62A5\\u544A\\u8D28\\u91CF\\u95EE\\u9898\r\n\r\n#XFLD: Label of the "Attachments" field in the "Report Quality Issue" application. Currently it is not displayed.\r\nQI_ATTACHMENT=\\u9644\\u4EF6\r\n\r\n#XFLD: Label indicating when and who added a file to a quality issue. Example: "Added on 01.01.2013 by Nikolay Kanchev"  \r\nQI_ATT_DOC_DATE=\\u7531 {1} \\u4E8E {0} \\u6DFB\\u52A0\r\n\r\n#XFLD: Label indicating that the attached file has no name \r\nQI_ATT_DOC_NAME=\\u65E0\\u6587\\u4EF6\\u540D\r\n\r\n#XFLD: Label of the "Description" (mandatory) field in the "Report Quality Issue" application. Previously, it was "Subject".\r\nQI_DESCRIPTION=\\u63CF\\u8FF0\r\n\r\n#XFLD: Label of the "Defect" (mandatory) field in the "Report Quality Issue" application\r\nQI_DEFECT=\\u7F3A\\u9677\r\n\r\n#XFLD: Label of the "Reference" field in the "Report Quality Issue" application. Previously, it was "Reference Number".\r\nQI_REFERENCE=\\u53C2\\u8003\r\n\r\n#XFLD: <update> Label of the "Category" field in the "Report Quality Issue" application. Previously, it was "Category".\r\nQI_CATEGORY=\\u7C7B\\u522B\r\n\r\n#XFLD: Label of the "Detailed Description" field in the "Report Quality Issue" application. Previously, it was "Description".\r\nQI_DETAIL_DESCRIPTION=\\u8BE6\\u7EC6\\u63CF\\u8FF0\r\n\r\n#XBUT, 14: Label of the "Submit" pushbutton in the "Report Quality Issue" application. Previously, it was "Send".\r\nQI_SUBMIT=\\u63D0\\u4EA4\r\n\r\n#XBUT, 14: Label of the "List" pushbutton in the "Report Quality Issue" application.\r\nQI_LIST=\\u53D6\\u6D88\r\n\r\n#XFLD: Label of the "Reported On" field in the "My Reported Issue" application.\r\nQI_REPORT_ON=\\u62A5\\u544A\\u65E5\\u671F\r\n\r\n#XFLD: Label of the "Status" field in the "My Reported Issues" list.\r\nQI_STATUS_TEXT=\\u72B6\\u6001\r\n\r\n#XFLD: Label of the "Date" field in the "My Reported Issues" list.\r\nQI_DATE=\\u65E5\\u671F\r\n\r\n#XMSG: Text of the message that indicates successful creation of a quality issue using the "Report Quality Issue" application.\r\nQI_TXT_VALIDATION=\\u5DF2\\u62A5\\u544A\\u8D28\\u91CF\\u95EE\\u9898\r\n\r\n#XMSG: Text of the message that indicates missing user input in a mandatory field. User input of maximum 20 characters is expected.\r\nQI_DESC_ERROR=\\u5FC5\\u586B\\u5B57\\u6BB5\r\n\r\n#XMSG: Text of the message that indicates invalid user input in a text field. User input different than symbols !@#$%^\\&\\*\\(\\)_=\\{\\}\\[\\]\\\\|:;\\u201C\\u2018<>,\\? is expected.\r\nQI_INVALID_ERROR=\\u8F93\\u5165\\u65E0\\u6548\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum file size of attached images.\r\nQI_MAX_FILE_SIZE=\\u56FE\\u50CF\\u5927\\u5C0F\\u5E94\\u5C0F\\u4E8E {0} \\u5B57\\u8282\r\n\r\n#XMSG: Text of the message that indicates reaching the maximum number of attached images. Previously, it was "No more images can be added".\r\nQI_NO_MORE_IMAGES=\\u4E0D\\u80FD\\u9644\\u52A0\\u66F4\\u591A\\u56FE\\u50CF\r\n\r\n#XMSG: Text of the message that validates the removal of an attached image. Previously it was "Are you sure to remove the selected image?".\r\nQI_DEL_IMG_QUESTION=\\u662F\\u5426\\u786E\\u5B9A\\u8981\\u5220\\u9664\\u6B64\\u56FE\\u50CF\\uFF1F\r\n\r\n#XTIT: Title of the dialog with which you remove an attached image\r\nQI_CONFIRM_ATT_DIALOG=\\u5220\\u9664\\u56FE\\u50CF\r\n\r\n#XMSG: Text of the message that indicates the file type being uploaded is not supported.\r\nQI_FILE_TYPE_NOT_SUPPORTED=\\u6587\\u4EF6\\u7C7B\\u578B\\u4E0D\\u53D7\\u652F\\u6301\r\n\r\n#XBUT: Label of the confirmation button of the dialog with which you remove an attached image. Previously it was "Confirm".\r\nQI_CONFIRM_BTN=\\u786E\\u5B9A\r\n\r\n#XBUT: Label of the cancel button. \r\nQI_CANCEL_BTN=\\u53D6\\u6D88\r\n\r\n#XMSG: Text of the message that indicates error during the upload of images into the backend. Previously it was "Some attachments are not submitted to the server.".\r\nQI_ATT_SUBMIT_ERROR=\\u5E76\\u672A\\u63D0\\u4EA4\\u6240\\u6709\\u9644\\u52A0\\u56FE\\u50CF\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Category" pushbutton\r\nQI_CATEGORY_DIALOG_TITLE=\\u9009\\u62E9\\u7C7B\\u522B\r\n\r\n#XTIT: Label of the F4 dialog that opens when you choose the "Defect" pushbutton\r\nQI_DEFECT_DIALOG_TITLE=\\u9009\\u62E9\\u7F3A\\u9677\r\n\r\n#XMSG: Message for empty F4 dialog of the "Defect" field\r\nQI_DEFECT_DIALOG_EMPTY_MSG=\\u65E0\\u53EF\\u7528\\u7F3A\\u9677\r\n\r\n#XMSG: Message for empty F4 dialog of the "Category" field\r\nQI_CATEGORY_DIALOG_EMPTY_MSG=\\u65E0\\u53EF\\u7528\\u7C7B\\u522B\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_NEW=\\u65B0\\u5EFA\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_IN_PROCESS=\\u5904\\u7406\\u4E2D\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_COMPLETED=\\u5DF2\\u5B8C\\u6210\r\n\r\n#XFLD: (XMIT) Label indicating the status of a quality issue. The label also appears as an option of the pushbutton that you use for filtering the list of quality issues.\r\nQI_STATUS_POSTPONED=\\u5DF2\\u63A8\\u8FDF\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_TO=\\u81F3\r\n\r\n#XFLD: Label in the "Filter by Date" dialog.  \r\nQI_FROM=\\u4ECE\r\n\r\n#XFLD: Tooltip of the "To" field in the "Filter by Date" dialog.  \r\nQI_TO_TOOLTIP=\\u8F93\\u5165\\u8FC7\\u6EE4\\u7684\\u7ED3\\u675F\\u65E5\\u671F\r\n\r\n#XFLD: Tooltip of the "From" field in the "Filter by Date" dialog.  \r\nQI_FROM_TOOLTIP=\\u8F93\\u5165\\u8FC7\\u6EE4\\u7684\\u5F00\\u59CB\\u65E5\\u671F\r\n\r\n#XBUT: Label for add picture control\r\nQI_ADD_IMG=\\u6DFB\\u52A0\\u56FE\\u50CF\r\n\r\n#XMSG: Text of the message that indicates date values entered in filter are invalid \r\nQI_INVALID_DATES_ERROR=\\u8F93\\u5165\\u7684\\u65E5\\u671F\\u65E0\\u6548\r\n\r\n#XMSG: Text of the message that indicates "To Date" entered in filter should be equal to or later than "From Date" \r\nQI_TO_DATE_AFTER_FROM_DATE_ERROR=\\u622A\\u6B62\\u65E5\\u671F\\u4E0D\\u5F97\\u65E9\\u4E8E\\u8D77\\u59CB\\u65E5\\u671F\r\n\r\n#----------------------Create view properties end--------------------------------------->\r\n\r\n#----------------------Master/Details view properties begin----------------------------->\r\n\r\n#XTIT: Title of the section that lists all reported issues. The variable in the brackets shows the number of issues.\r\nQI_TITLE_MASTER_VIEW=\\u6211\\u62A5\\u544A\\u7684\\u95EE\\u9898 ({0})\r\n\r\n#XTIT: Title of the section that lists the details of a selected issue\r\nDETAIL_TITLE=\\u6211\\u62A5\\u544A\\u7684\\u95EE\\u9898\r\n\r\n#XFLD: Label of the "Priority" field in the "My Reported Issue" application\r\nQI_PRIORITY=\\u4F18\\u5148\\u7EA7\r\n\r\n#XFLD: Label of the "Assigned To" field in the "My Reported Issue" application\r\nQI_DV_ASSIGN_TO=\\u4F18\\u5148\\u7EA7\r\n\r\n#XFLD: Label of the "Notification" field in the "My Reported Issue" application. It is the same as the created quality issue number.\r\nQI_DV_NOTIFICATION=\\u901A\\u77E5\r\n\r\n#XFLD: Label of the "Material" field in the "My Reported Issue" application\r\nQI_DV_MATERIAL=\\u7269\\u6599\r\n\r\n#XBUT: Label of the "Settings" pushbutton and title of the corresponding dialog\r\nQI_MV_SETTINGS=\\u8BBE\\u7F6E\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_PLANT=\\u5DE5\\u5382\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating how many issues should be displayed in the list.\r\nQI_MAX_ISSUES=\\u663E\\u793A {0} \\u4E2A\\u95EE\\u9898\r\n\r\n#XFLD: Label of a field in the "Settings" dialog indicating 1 issue should be displayed in the list.\r\nQI_MAX_ISSUES_ONE=\\u663E\\u793A 1 \\u4E2A\\u95EE\\u9898\r\n\r\n#XFLD: Label of a field in the "Settings" dialog\r\nQI_NUMBER_ISSUES=\\u95EE\\u9898\\u6570\r\n\r\n#XTIT: This is the title for image gallery\r\nQI_GALLERY_TITLE=\\u56FE\\u50CF\\u5E93\r\n\r\n#XTIT: Title in the list of issues indicating the filter criterion of the entries. Filtered by {status}\r\nQI_FILTERED_BY=\\u8FC7\\u6EE4\\u6761\\u4EF6\\uFF1A{0}\r\n\r\n#XTIT: Title in the list of issues indicating that the list is in process and takes some more than expected \r\nQI_LOADING_TEXT=\\u6B63\\u5728\\u52A0\\u8F7D...\r\n\r\n#XTIT: Title in the list of issues indicating there are no quality issues that match the filter/grouping criteria.\r\nQI_NO_DATA_AVAILABLE=\\u65E0\\u8D28\\u91CF\\u95EE\\u9898\r\n\r\n#----------------------Master/Details view properties end------------------------------->\r\n',
		"i2d/qm/qualityissue/confirm/utils/DateTimeConversions.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.DateTimeConversions");
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
			i2d.qm.qualityissue.confirm.utils.DateTimeConversions = {};
			i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatDaysAgo = function(d) {
				var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
					style: "daysAgo"
				}, null);
				if (d) return f.format(d, true)
			};
			i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate = function(d) {
				var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
					style: "medium"
				}, null);
				if (d) return f.format(d, true)
			};
			i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatLongDate = function(d) {
				var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
					style: "long"
				}, null);
				if (d) return f.format(d)
			};
			i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentDate = function(d, u) {
				if (d) {
					var D = d.substring(6, 8) * 1;
					var M = d.substring(4, 6) * 1 - 1;
					var Y = d.substring(0, 4) * 1;
					var h = d.substring(8, 10) * 1;
					var m = d.substring(10, 12) * 1;
					var s = d.substring(12, 14) * 1;
					var a = new Date(Y, M, D, h, m, s);
					a = i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate(a);
					var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
					return b.getText("QI_ATT_DOC_DATE", [a, u])
				}
			};
			i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentName = function(d) {
				if (!d) {
					var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
					d = b.getText("QI_ATT_DOC_NAME")
				}
				return d
			}
		},
		"i2d/qm/qualityissue/confirm/utils/ErrorDialog.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.ErrorDialog");
			jQuery.sap.require("sap.ca.ui.message.message");
			i2d.qm.qualityissue.confirm.utils.ErrorDialog = function(m) {
				var _ = "";
				var a = "";
				var b = "";
				var s = "";
				if (typeof m === "string") {
					s = {
						message: m,
						type: sap.ca.ui.message.Type.ERROR
					}
				} else if (m instanceof Array) {
					for (var i = 0; i < m.length; i++) {
						_ = "";
						if (typeof m[i] === "string") {
							_ = m[i]
						} else if (typeof m[i] === "object") {
							_ = m[i].value
						}
						if (i === 0) {
							a = _
						} else {
							b = b + _ + "\n"
						}
					}
					if (b === "") {
						s = {
							message: a,
							type: sap.ca.ui.message.Type.ERROR
						}
					} else {
						s = {
							message: a,
							details: b,
							type: sap.ca.ui.message.Type.ERROR
						}
					}
				}
				sap.ca.ui.message.showMessageBox(s)
			}
		},
		"i2d/qm/qualityissue/confirm/utils/FragmentHelper.js": function() {
			jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");
			i2d.qm.qualityissue.confirm.utils.FragmentHelper = function() {
				var c;
				var s = function(C, m) {
					if (!C) {
						return
					}
					var a = C.getModel("maxHits");
					if (a) {
						a.setData({
							maxHits: m
						})
					} else {
						a = new sap.ui.model.json.JSONModel({
							maxHits: m
						});
						C.setModel(a, "maxHits")
					}
				};
				var u = function(C, o) {
					if (!c) {
						return
					}
					c.removeAllContent();
					c.addContent(C);
					var a = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsDialogHeader", o);
					a.setModel(o.oApplicationFacade.getODataModel("i18n"), "i18n");
					c.setCustomHeader(a)
				};
				return {
					openFilterDialog: function(C) {
						if (!C) {
							return
						}
						if (!this.filterDialog) {
							this.filterDialog = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.ViewSettingsFilterDialog", C);
							this.filterDialog.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n");
							this.setFilterDialogModel();
							this.dateVBox = this.filterDialog.getFilterItems()[1].getCustomControl();
							this.dateVBox.addStyleClass("qi_dateFilterMargins");
							this.dateVBox.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
						}
						this.filterDialog.open()
					},
					setFilterDialogDateFilterCount: function(C) {
						if (!this.filterDialog) {
							return
						}
						this.filterDialog.getFilterItems()[1].setFilterCount(C);
						if (C === 0) {
							this.filterDialog.getFilterItems()[1].setSelected(false);
							return
						}
						this.filterDialog.getFilterItems()[1].setSelected(true)
					},
					resetFilterDialogDateFilter: function(p, P) {
						if (!this.filterDialog) {
							return
						}
						this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setDateValue();
						this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setValue(p);
						this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].fireChange(true);
						this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setDateValue();
						this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setValue(P);
						this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].fireChange(true);
						if (!p && !P) {
							this.setFilterDialogDateFilterCount(0)
						} else {
							this.setFilterDialogDateFilterCount(1)
						}
					},
					setFilterDialogModel: function() {
						var a = i2d.qm.qualityissue.confirm.utils.StatusHelper.getArrayColors();
						if (!$.isArray(a) || a.length < 1 || !this.filterDialog) {
							return
						}
						var m = new sap.ui.model.json.JSONModel({
							status1: null
						}, {
							status2: null
						}, {
							status3: null
						}, {
							status4: null
						});
						$.each(a, function(i, b) {
							switch (b.stateStatusCode) {
								case "I0068":
									m.getData().status1 = b.stateStatusText;
									break;
								case "I0070":
									m.getData().status2 = b.stateStatusText;
									break;
								case "I0072":
									m.getData().status3 = b.stateStatusText;
									break;
								case "I0069":
									m.getData().status4 = b.stateStatusText;
									break
							}
						});
						this.filterDialog.getFilterItems()[0].setModel(m)
					},
					destroyFilterDialog: function() {
						if (!this.filterDialog) {
							return
						}
						this.filterDialog.destroy();
						this.filterDialog = null
					},
					openSortDialog: function(C) {
						if (!this.sortDialog) {
							this.sortDialog = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.ViewSettingsSortDialog", C);
							this.sortDialog.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
						}
						this.sortDialog.open()
					},
					destroySortDialog: function() {
						if (!this.sortDialog) {
							return
						}
						this.sortDialog.destroy();
						this.sortDialog = null
					},
					openCustSetDialog: function(C, m) {
						if (!c) {
							c = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsDialog", C);
							c.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
						}
						c.removeAllContent();
						if (!this.customSettingsList) {
							this.customSettingsList = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsList", C);
							this.customSettingsList.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n")
						}
						s(this.customSettingsList.getItems()[0], m);
						c.addContent(this.customSettingsList);
						c.destroyCustomHeader();
						if (c.isOpen() !== true) {
							c.open()
						}
					},
					loadCustSetIssuesNumber: function(C, m) {
						if (!c) {
							return
						}
						if (!this.customSettingsIssueNumber) {
							this.customSettingsIssueNumber = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsNumberOfIssues", C)
						}
						s(this.customSettingsIssueNumber, m);
						u(this.customSettingsIssueNumber, C)
					},
					loadCustSetPlantList: function(C) {
						if (!c) {
							return
						}
						if (!this.customSettingsPlantsList) {
							this.customSettingsPlantsList = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsPlantsList", C);
							this.customSettingsPlantsList.setModel(C.oApplicationFacade.getODataModel())
						}
						u(this.customSettingsPlantsList, C)
					},
					closeCustSetDialog: function() {
						if (c.isOpen() !== false) {
							c.close()
						}
					},
					getCustSetMaxHitsTitle: function(m) {
						var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
						if (m === "1") {
							return b.getText("QI_MAX_ISSUES_ONE")
						} else {
							return b.getText("QI_MAX_ISSUES", m)
						}
					},
					destroyCustSetDialog: function() {
						if (c) {
							c.destroyCustomHeader();
							c.destroy();
							c = null;
							this.customSettingsList.destroy();
							this.customSettingsList = null
						}
						if (this.customSettingsIssueNumber) {
							this.customSettingsIssueNumber.destroy();
							this.customSettingsIssueNumber = null
						}
						if (this.customSettingsPlantsList) {
							this.customSettingsPlantsList.destroy();
							this.customSettingsPlantsList = null
						}
					},
					setDefaultPlantByIndex: function(i) {
						if (!this.customSettingsPlantsList) {
							return
						}
						this.customSettingsPlantsList.setSelectedItem(this.customSettingsPlantsList.getItems()[i])
					},
					removePlantSelection: function() {
						if (!this.customSettingsPlantsList) {
							return
						}
						this.customSettingsPlantsList.removeSelections(false)
					},
					createF4HelpSelectDialog: function(C, f, a) {
						var b = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments." + f, C);
						b.setModel(a);
						b.setModel(C.oApplicationFacade.getODataModel("i18n"), "i18n");
						if (jQuery.device.is.phone) {
							b._dialog.setStretch(true)
						}
						return b
					}
				}
			}()
		},
		"i2d/qm/qualityissue/confirm/utils/Helper.js": function() {
			(function() {
				'use strict';
				jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.Helper");
				i2d.qm.qualityissue.confirm.utils.Helper = {
					processChangeOperation: function(p, h, o, c) {
						this.result = {};
						var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
						var H = a.getParams().HTTP_Method;
						if (h !== H.POST && h !== H.PUT) {
							jQuery.sap.log.error("Invalid HTTP method has been provided: " + h);
							return this.result
						}
						var m = c && c.getView().getModel();
						if (!m) {
							m = new sap.ui.model.odata.ODataModel("" + a.getServiceList()[0].serviceUrl, true)
						}
						m.setRefreshAfterChange(false);
						o = !jQuery.isArray(o) ? [o] : o;
						this.arBatchConfig = [{}];
						this.ProcessingMode = a.getParams().ProcessingModeEnum.Change;
						var C = null;
						for (var i = 0; i < o.length; i++) {
							C = m.createBatchOperation(p, h, o[i]);
							m.addBatchChangeOperations([C])
						}
						try {
							this.modelSubmitBatch(m)
						} catch (e) {
							sap.ca.ui.message.showMessageBox({
								type: sap.ca.ui.message.Type.ERROR,
								message: e.message,
								details: e.details
							})
						}
						return this.result
					},
					modelSubmitBatch: function(m) {
						m.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false)
					},
					modelReadOperation: function(m, p) {
						m.read(p, null, null, false, $.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this))
					},
					setProcessingMode: function(v) {
						this.ProcessingMode = v
					},
					setarBatchConfig: function(v) {
						this.arBatchConfig = v
					},
					setBatchResult: function(v) {
						this.result = v
					},
					getBatchResult: function() {
						return this.result
					},
					getProcessingMode: function() {
						return this.ProcessingMode
					},
					getarBatchConfig: function() {
						return this.arBatchConfig
					},
					convertCollection: function(a, b) {
						var c = [];
						if (!a) {
							return c
						}
						$.each(a, function(d, e) {
							var o = {};
							if (b && $.isArray(b) && b.length > 0) {
								for (var i = 0; i < b.length; i++) {
									o[b[i].output] = e[b[i].source]
								}
							} else {
								o = e
							}
							c.push(o)
						});
						return c
					},
					getCollection: function(a, c) {
						var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
						this.result = [];
						var m = c && c.getView().getModel();
						if (!m) {
							m = new sap.ui.model.odata.ODataModel("" + A.getServiceList()[0].serviceUrl, true)
						}
						this.arBatchConfig = a;
						if (a.length === 1) {
							this.ProcessingMode = A.getParams().ProcessingModeEnum.Read;
							m.setUseBatch(false);
							this.modelReadOperation(m, A.getServiceList()[0].SelectionSetCollection[a[0].indexCollection])
						} else {
							var g = null;
							var b = [];
							this.ProcessingMode = A.getParams().ProcessingModeEnum.Batch;
							for (var i = 0; i < a.length; i++) {
								g = m.createBatchOperation(A.getServiceList()[0].SelectionSetCollection[a[i].indexCollection], A.getParams().HTTP_Method.GET);
								b.push(g)
							}
							m.addBatchReadOperations(b);
							this.modelSubmitBatch(m)
						}
						return this.result
					},
					getInteropServiceData: function(p, f) {
						var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
						this.result = [];
						var m = null;
						if (f) {
							m = f
						} else {
							m = new sap.ui.model.odata.ODataModel("" + a.getParams().InteropService.serviceUrl, true)
						}
						this.arBatchConfig = [{}];
						this.ProcessingMode = a.getParams().ProcessingModeEnum.Read;
						m.setUseBatch(false);
						this.modelReadOperation(m, p);
						return this.result
					},
					fnBatchSuccess: function(d, r, e) {
						var a, o;
						var P = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().ProcessingModeEnum;
						for (var i = 0; i < this.arBatchConfig.length; i++) {
							switch (this.ProcessingMode) {
								case P.Batch:
									a = r.data.__batchResponses.length > 0 && r.data.__batchResponses[i].data && r.data.__batchResponses[i].data.results && r.data.__batchResponses[
										i].data.results.length > 0 && r.data.__batchResponses[i].data.results;
									break;
								case P.Read:
									a = r.data.results;
									break;
								case P.Change:
									a = r.data.__batchResponses[i].__changeResponses && r.data.__batchResponses[i].__changeResponses.length > 0 && r.data.__batchResponses[
										i].__changeResponses[i].data;
									break
							}
							if (this.arBatchConfig[i].arConversionRules) {
								a = i2d.qm.qualityissue.confirm.utils.Helper.convertCollection(a, this.arBatchConfig[i].arConversionRules)
							}
							if (this.arBatchConfig[i].itemsPrefix) {
								o = {};
								o[this.arBatchConfig[i].itemsPrefix] = a;
								this.result.push(o)
							} else if (this.ProcessingMode === P.Batch) {
								this.result.push(a)
							} else {
								this.result = a
							}
						}
						if (e && e.length > 0) {
							var j = e[0].response.body;
							var n = $.parseJSON(j);
							this.result = {};
							this.result.error = n.error.message.value;
							jQuery.sap.log.error("Error occurs during batch processing: " + n.error.message.value);
							throw {
								message: n.error.message.value,
								details: n.error.message.value
							}
						}
					},
					fnBatchError: function(e) {
						this.result.error = e.message;
						jQuery.sap.log.error("Error occurs during batch processing: " + e.message);
						sap.ca.ui.message.showMessageBox({
							type: sap.ca.ui.message.Type.ERROR,
							message: e.message,
							details: e.response.statusText
						})
					},
					getAttStream: function(n, d) {
						var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
						var u = a.getServiceList()[0].serviceUrl + a.getServiceList()[0].QIAttachmentStream + "(Notification='" + n + "',DocumentNumber='" +
							d + "')/$value";
						location.href = u
					},
					formatMaterial: function(m, M) {
						var r = "";
						if (!$.isBlank(m) && !$.isBlank(M)) {
							r = m + " - " + M
						} else if (!$.isBlank(m)) {
							r = m
						} else if (!$.isBlank(M)) {
							r = M
						}
						return r
					},
					convertToISODateTime: function(d) {
						if ($.isBlank(d)) {
							return
						}
						var a = new Date(d),
							t = a.getTimezoneOffset();
						a.setHours(a.getHours() - ~~(t / 60));
						a.setMinutes(a.getMinutes() - (t / 60 - ~~(t / 60)) * 60);
						return a.toISOString()
					},
					isValidDate: function(d) {
						if ($.isBlank(d) || isNaN(Date.parse(d))) {
							return false
						}
						return true
					}
				}
			}())
		},
		"i2d/qm/qualityissue/confirm/utils/InteropServiceHelper.js": function() {
			(function() {
				'use strict';
				jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.InteropServiceHelper");
				jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
				i2d.qm.qualityissue.confirm.utils.InteropServiceHelper = {
					isFactSheetExists: function() {
						if ((this.skipLocalhostCheck === undefined || !this.skipLocalhostCheck) && location.hostname === "localhost") {
							return false
						}
						if (this._bLinkExists === undefined) {
							var d = i2d.qm.qualityissue.confirm.utils.InteropServiceHelper.getServiceData();
							this._bLinkExists = (!$.isBlank(d)) && (d.length > 0)
						}
						return this._bLinkExists
					},
					getServiceData: function() {
						var p = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().InteropService.linkCheck;
						return i2d.qm.qualityissue.confirm.utils.Helper.getInteropServiceData(p)
					},
					resetServiceResult: function() {
						this._bLinkExists = undefined
					},
					setSkipLocalhostCheck: function(v) {
						this.skipLocalhostCheck = v
					}
				}
			}())
		},
		"i2d/qm/qualityissue/confirm/utils/StatusHelper.js": function() {
			(function() {
				'use strict';
				jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.StatusHelper");
				jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
				i2d.qm.qualityissue.confirm.utils.StatusHelper = {
					constructor: function() {
						this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
						this.setArrayColors(this.getStatusColors())
					},
					getStatusState: function(v) {
						var _ = {
							"000000": sap.ui.core.ValueState.None,
							"FFFF00": sap.ui.core.ValueState.Warning,
							"00FF00": sap.ui.core.ValueState.Success,
							"FF0000": sap.ui.core.ValueState.Error
						};
						if (!v) {
							return sap.ui.core.ValueState.None
						}
						var s = i2d.qm.qualityissue.confirm.utils.StatusHelper;
						s.constructor();
						var a = s.getColorByStatus(v);
						return _[a]
					},
					getColorByStatus: function(s) {
						if (this.getArrayColors()) {
							var r = $.grep(this.getArrayColors(), function(i) {
								return i.stateStatusCode === s
							});
							if (r.length > 0) {
								return r[0].stateStatusColor
							} else {
								return "000000"
							}
						}
					},
					getStatusText: function(s) {
						var a = i2d.qm.qualityissue.confirm.utils.StatusHelper;
						a.constructor();
						if (a.getArrayColors()) {
							var r = $.grep(a.getArrayColors(), function(i) {
								return i.stateStatusCode === s
							});
							if (r.length > 0) {
								return r[0].stateStatusText
							} else {
								switch (s) {
									case "I0068":
										return a.oBundle.getText("QI_STATUS_NEW");
									case "I0070":
										return a.oBundle.getText("QI_STATUS_IN_PROCESS");
									case "I0072":
										return a.oBundle.getText("QI_STATUS_COMPLETED");
									case "I0069":
										return a.oBundle.getText("QI_STATUS_POSTPONED");
									default:
										return ""
								}
							}
						}
					},
					getStatusColors: function() {
						if (!this.getArrayColors()) {
							var a = [{
								output: "stateStatusText",
								source: "Text"
							}, {
								output: "stateStatusColor",
								source: "Color"
							}, {
								output: "stateStatusCode",
								source: "Status"
							}];
							var b = i2d.qm.qualityissue.confirm.utils.Helper.getCollection([{
								indexCollection: 4,
								arConversionRules: a
							}]);
							this.setArrayColors(b)
						}
						return this.getArrayColors()
					},
					getArrayColors: function() {
						return this.arStatusColors
					},
					setArrayColors: function(a) {
						this.arStatusColors = a
					}
				}
			}())
		},
		"i2d/qm/qualityissue/confirm/utils/StorageHelper.js": function() {
			(function() {
				'use strict';
				jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.StorageHelper");
				i2d.qm.qualityissue.confirm.utils.StorageHelper = {
					setItem: function(k, v) {
						if (!this._localStorage) {
							this._localStorage = {}
						}
						this._localStorage[k] = v
					},
					getItem: function(k) {
						return this._localStorage && this._localStorage[k]
					},
					removeItem: function(k) {
						if (this._localStorage && this._localStorage[k]) {
							this._localStorage[k] = undefined
						}
					},
					setObj: function(k, o) {
						this.setItem(k, JSON.stringify(o))
					},
					getObj: function(k) {
						var r = this.getItem(k);
						return r && JSON.parse(r)
					}
				}
			}())
		},
		"i2d/qm/qualityissue/confirm/view/S2.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
			jQuery.sap.require("sap.m.DatePicker");
			jQuery.sap.require("sap.ca.scfld.md.app.MasterHeaderFooterHelper");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");
			sap.ca.scfld.md.controller.ScfldMasterController.extend("i2d.qm.qualityissue.confirm.view.S2", {
				onInit: function() {
					sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
					this.oMasterModel = new sap.ui.model.json.JSONModel({
						selectedFilter: "All",
						selectedSorter: "CreatedOn",
						toogleSubmit: false
					});
					this.getView().setModel(this.oMasterModel, "masterModel");
					this.resourceBundle = this.oApplicationFacade.getResourceBundle();
					this.oSettingsDialog = null;
					this.SETTINGS_NAME = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName;
					this.objSettings = localStorage.getObj(this.SETTINGS_NAME);
					if (this.objSettings.maxHits) {
						this.objSettings.maxHits = parseInt(this.objSettings.maxHits, 10);
						if (isNaN(this.objSettings.maxHits)) {
							jQuery.sap.log.error("Error with data, please check consistency of record. Default 30 issues displayed.");
							this.objSettings.maxHits = '30'
						}
					}
					if ($.isBlank(this.objSettings)) {
						var s = [{
							output: "maxHits",
							source: "MaxHits"
						}, {
							output: "defPlant",
							source: "Plant"
						}, {
							output: "maxFileSize",
							source: "MaxFileSize"
						}];
						var b = i2d.qm.qualityissue.confirm.utils.Helper.getCollection([{
							indexCollection: 3,
							arConversionRules: s
						}], this);
						this.objSettings = b && b.length > 0 && b[0];
						localStorage.setObj(this.SETTINGS_NAME, this.objSettings)
					}
					this.setMaxHitsToList();
					this._showLoadingText(true);
					var a = sap.ui.getCore().getEventBus();
					a.subscribe(sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier(), "RefreshDetail", this.handleRefresh, this);
					var l = this.getList();
					l.attachUpdateFinished(this.handleUpdateFinished, this);
					var t = l.getItems()[0].clone();
					l.bindItems("/QMNotificationSelectionSet", t);
					this.aFilterBy = [];
					this.dateFromUTC;
					this.dateToUTC;
					this.DateFromUTCValue;
					this.DateToUTCValue;
					this.previousDateFromUTC;
					this.previousDateToUTC;
					this.closeCustSetDialog = function() {
						this.changedMaxHits = undefined;
						this.changedPlant = undefined;
						this.changedPlantIndex = undefined;
						i2d.qm.qualityissue.confirm.utils.FragmentHelper.closeCustSetDialog()
					};
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "masterDetail" && e.getParameter("arguments").id === "create" && this.getList().getSelectedItem()) {
							this.handleRefresh()
						}
					}, this)
				},
				navToEmptyView: function() {
					this.showEmptyView("DETAIL_TITLE", "NO_ITEMS_AVAILABLE")
				},
				_showLoadingText: function(l) {
					if (l) {
						this.getList().setNoDataText(this.resourceBundle.getText("QI_LOADING_TEXT"))
					} else {
						this.getList().setNoDataText(this.resourceBundle.getText("QI_NO_DATA_AVAILABLE"))
					}
				},
				handleUpdateFinished: function(c) {
					if (!jQuery.device.is.phone && (c.getParameters().reason === "Filter" || c.getParameters().reason === "Change" || c.getParameters().reason ===
						"Refresh" || c.getParameters().reason === "Binding")) {
						if (this.oRouter._oRouter._prevMatchedRequest === "noData/DETAIL_TITLE/NO_ITEMS_AVAILABLE") {
							this.getList().removeSelections()
						}
						if (this.getList().getItems().length == "0") {
							this._showLoadingText(false)
						} else {
							this._showLoadingText(true)
						}
					}
				},
				handleRefresh: function() {
					this.setMaxHitsToList();
					this.getList().removeSelections();
					this.getList().getBinding("items")._refresh()
				},
				getHeaderFooterOptions: function() {
					return {
						sI18NMasterTitle: "QI_TITLE_MASTER_VIEW",
						buttonList: [],
						aAdditionalSettingButtons: [{
							sId: "Settings",
							sI18nBtnTxt: "QI_MV_SETTINGS",
							sIcon: "sap-icon://wrench",
							onBtnPressed: jQuery.proxy(function(e) {
								this.onSettingsPressed()
							}, this)
						}],
						oFilterOptions: {
							onFilterPressed: $.proxy(this.onFilter, this)
						},
						oSortOptions: {
							onSortPressed: $.proxy(this.onSort, this)
						},
						onAddPress: jQuery.proxy(function(e) {
							this.onCreate();
							jQuery.sap.log.info("add pressed")
						}, this)
					}
				},
				setMaxHitsToList: function() {
					var m = this.getList().getModel();
					m.setCountSupported(false);
					m.setSizeLimit(this.objSettings.maxHits)
				},
				applySearchPatternToListItem: function(i, f) {
					if (i.isSelectable()) {
						if (f.substring(0, 1) === "#") {
							var t = f.substr(1);
							var d = i.getBindingContext().getProperty("Name").toLowerCase();
							return d.indexOf(t) === 0
						} else {
							return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
						}
					}
				},
				isLiveSearch: function() {
					this.getList().setNoDataText(this.resourceBundle.getText("QI_NO_DATA_AVAILABLE"));
					return false
				},
				onExit: function() {
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroySortDialog();
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroyFilterDialog();
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.destroyCustSetDialog();
					if (this.oMasterModel) {
						this.oMasterModel.destroy();
						this.oMasterModel = null
					}
					var l = sap.ui.getCore().byId(this.getView().sId + "--footer");
					if (l && l.destroy) {
						l.destroy()
					}
				},
				setInfoLabel: function(r, t, i, f) {
					if (i === null) i = true;
					this.oMasterModel.setProperty('/toogleSubmit', i);
					if (i === false) return;
					var l = this.getView().byId("labelTB");
					var a = "";
					if (t) a = this.resourceBundle.getText(t);
					else a = f;
					var t = this.resourceBundle.getText(r, [a]);
					l.setText(t);
					l.setTooltip(t)
				},
				setFilterInfoLabel: function(a) {
					if (!$.isArray(a) || a.length < 1) {
						this.setInfoLabel('', '', false, '');
						return
					}
					var i = "",
						r = this.resourceBundle.getText("QI_REPORT_ON"),
						s = this.resourceBundle.getText("QI_STATUS_TEXT");
					$.each(a, function(b, f) {
						if (i2d.qm.qualityissue.confirm.utils.Helper.isValidDate(f.oValue1)) {
							if (f.oValue1 === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate && f.oValue2 ===
								sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate) {
								return false
							}
							f.oValue1 = f.oValue1.substring(0, 10);
							f.oValue2 = f.oValue2.substring(0, 10);
							i += r + ": " + f.oValue1 + ", " + f.oValue2
						} else if (f.oValue1) {
							if (i.indexOf(s) === -1) {
								i += s + ": " + i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusText(f.oValue1)
							} else {
								i += ", " + i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusText(f.oValue1)
							}
						}
					});
					i += ";";
					this.setInfoLabel("QI_FILTERED_BY", null, true, i)
				},
				onCreate: function() {
					this.oRouter.navTo("fsS4")
				},
				onFilter: function(e) {
					this.aFilterBy = [];
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.openFilterDialog(this)
				},
				onConfirmFilterDialog: function(e) {
					this._showLoadingText(true);
					var p = e.getParameters();
					if (this.invalidDateTo || this.invalidDateFrom) {
						this.setInfoLabel("QI_INVALID_DATES_ERROR", null, true, null);
						this._showLoadingText(false);
						return
					}
					if ((new Date(this.dateToUTC)).getTime() < (new Date(this.dateFromUTC).getTime())) {
						this.setInfoLabel("QI_TO_DATE_AFTER_FROM_DATE_ERROR", null, true, null);
						this._showLoadingText(false);
						return
					}
					$.each(p.filterItems, $.proxy(function(i, f) {
						if (f.sId === "StatusNew" || f.sId === "StatusInProcess" || f.sId === "StatusCompleted" || f.sId === "StatusPostponed") {
							this.aFilterBy.push(f.getCustomData()[0].getValue().filters)
						}
					}, this));
					if (this.shouldCreateDateFilterObject()) {
						this.aFilterBy.push(new sap.ui.model.Filter("CreatedOn", sap.ui.model.FilterOperator.BT, this.dateFromUTC, this.dateToUTC))
					}
					if (this.dateFromUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate) {
						this.dateFromUTC = null
					}
					if (this.dateToUTC === sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate) {
						this.dateToUTC = null
					}
					this.getList().getBinding("items").filter(this.aFilterBy);
					this.setFilterInfoLabel(this.aFilterBy);
					this.previousDateFromUTC = this.DateFromUTCValue;
					this.previousDateToUTC = this.DateToUTCValue
				},
				onCancelFilterDialog: function(e) {
					this.DateFromUTCValue = this.previousDateFromUTC;
					this.DateToUTCValue = this.previousDateToUTC;
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.resetFilterDialogDateFilter(this.previousDateFromUTC, this.previousDateToUTC)
				},
				onChangeDateFrom: function(e) {
					this.DateFromUTCValue = e.getSource().mProperties.value;
					this.dateFromUTC = i2d.qm.qualityissue.confirm.utils.Helper.convertToISODateTime(e.getSource().mProperties.dateValue);
					this.invalidDateFrom = e.mParameters.invalidValue && !($.isBlank(e.mParameters.newValue));
					this.setDateFilterCount()
				},
				onChangeDateTo: function(e) {
					this.DateToUTCValue = e.getSource().mProperties.value;
					this.dateToUTC = i2d.qm.qualityissue.confirm.utils.Helper.convertToISODateTime(e.getSource().mProperties.dateValue);
					this.invalidDateTo = e.mParameters.invalidValue && !($.isBlank(e.mParameters.newValue));
					this.setDateFilterCount()
				},
				onResetFilterDialog: function(e) {
					this.DateFromUTCValue = null;
					this.DateToUTCValue = null;
					this.dateFromUTC = null;
					this.dateToUTC = null;
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.resetFilterDialogDateFilter()
				},
				shouldCreateDateFilterObject: function() {
					if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)) {
						return false
					}
					if ($.isBlank(this.dateFromUTC)) {
						this.dateFromUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultFromDate;
						return true
					}
					if ($.isBlank(this.dateToUTC)) {
						this.dateToUTC = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().filterDialogDefaultToDate
					}
					return true
				},
				setDateFilterCount: function() {
					if ($.isBlank(this.dateFromUTC) && $.isBlank(this.dateToUTC)) {
						i2d.qm.qualityissue.confirm.utils.FragmentHelper.setFilterDialogDateFilterCount(0);
						return
					}
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.setFilterDialogDateFilterCount(1)
				},
				onSort: function(e) {
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.openSortDialog(this)
				},
				onConfirmSortDialog: function(e) {
					var p = e.getParameters();
					if (!p.sortItem) {
						return
					}
					var s = p.sortItem.getCustomData()[0].getValue().sorter;
					if (!s) {
						return
					}
					s.bDescending = p.sortDescending;
					this.getList().getBinding("items").sort(s)
				},
				onConfirmCustSettingsDialog: function(e) {
					var a = e.getSource().getParent().getAggregation("content")[0];
					if (a.getId() === "CustomSettingsIssuesNumber" && a.getContent()[1].getValueState() === sap.ui.core.ValueState.Error) {
						return
					}
					var u = false;
					if (this.changedMaxHits > 0 && this.objSettings.maxHits !== this.changedMaxHits) {
						this.objSettings.maxHits = this.changedMaxHits;
						this.handleRefresh();
						u = true
					}
					if (this.changedPlantIndex > -1 && this.objSettings.selectedPlantIndex !== this.changedPlantIndex) {
						this.objSettings.defPlant = this.changedPlant;
						this.objSettings.selectedPlantIndex = this.changedPlantIndex;
						u = true
					}
					if (u) {
						localStorage.setObj(this.SETTINGS_NAME, this.objSettings)
					}
					this.closeCustSetDialog()
				},
				onCancelCustSettingsDialog: function(e) {
					var a = e.getSource().getParent().getAggregation("content")[0];
					var c = function(C) {
						i2d.qm.qualityissue.confirm.utils.FragmentHelper.removePlantSelection();
						if (C.objSettings.selectedPlantIndex > -1) {
							i2d.qm.qualityissue.confirm.utils.FragmentHelper.setDefaultPlantByIndex(C.objSettings.selectedPlantIndex)
						}
					};
					switch (a.getId()) {
						case "CustomSettingsIssuesNumber":
							var i = a.getContent()[1];
							i.setValueState(sap.ui.core.ValueState.None);
							i.setValueStateText("");
							c(this);
							break;
						case "CustomSettingsPlantsList":
							a.removeSelections(false);
							if (this.objSettings.selectedPlantIndex > -1) {
								a.setSelectedItem(a.getItems()[this.objSettings.selectedPlantIndex])
							}
							break;
						case "CustomSettingsList":
							c(this);
							break
					}
					this.closeCustSetDialog()
				},
				onCustSetDialogHeaderBack: function(e) {
					var a = e.getSource().getParent().getParent().getAggregation("content")[0];
					if (a.getId() === "CustomSettingsIssuesNumber") {
						var i = a.getContent()[1];
						if (i.getValueState() === sap.ui.core.ValueState.Error) {
							return
						}
						i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, i.getValue())
					} else {
						if (this.changedMaxHits) {
							i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, this.changedMaxHits)
						} else {
							i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits)
						}
					}
				},
				onCustomSettingsIssues: function(e) {
					var m = e.getSource().getModel("maxHits").getData().maxHits;
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.loadCustSetIssuesNumber(this, m)
				},
				onCustomSettingsPlant: function(e) {
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.loadCustSetPlantList(this)
				},
				onSelectCustomSettingsPlant: function(e) {
					var s = e.getParameter("listItem");
					this.changedPlant = s.getProperty("title");
					this.changedPlantIndex = e.getSource().indexOfItem(s)
				},
				onLoadCustSettingsPlantList: function(e) {
					if (this.objSettings.selectedPlantIndex > -1) {
						e.getSource().setSelectedItem(e.getSource().getItems()[this.objSettings.selectedPlantIndex]);
						return
					}
					$.each(e.getSource().mAggregations.items, $.proxy(function(i, p) {
						if (p.getProperty("title") === this.objSettings.defPlant) {
							this.objSettings.selectedPlantIndex = i;
							e.getSource().setSelectedItem(p);
							return false
						}
					}, this))
				},
				onSettingsPressed: function(e) {
					i2d.qm.qualityissue.confirm.utils.FragmentHelper.openCustSetDialog(this, this.objSettings.maxHits)
				},
				onChangeCustSetIssueNumber: function(e) {
					if (isNaN(e.getSource().getValue()) || $.isBlank(e.getSource().getValue()) || e.getSource().getValue() < 1) {
						e.getSource().setValueState(sap.ui.core.ValueState.Error);
						e.getSource().setValueStateText(this.resourceBundle.getText("QI_INVALID_ERROR"))
					} else {
						e.getSource().setValueState(sap.ui.core.ValueState.None);
						e.getSource().setValueStateText("")
					}
					this.changedMaxHits = parseInt(e.getSource().getValue(), 10)
				}
			})
		},
		"i2d/qm/qualityissue/confirm/view/S2.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\tcontrollerName="i2d.qm.qualityissue.confirm.view.S2">\n\t<Page id="page" title="{i18n>QI_TITLE_MASTER_VIEW}" showNavButton="false">\n\t\t<content>\n\t\t\t<!-- visible="{device>/isTouch}" -->\n\n\t\t\t<List id="list" select="_handleSelect" mode="{device>/listMode}">\n\t\t\t\t<infoToolbar>\n\t\t\t\t\t<Toolbar visible="{masterModel>/toogleSubmit}">\n\t\t\t\t\t\t<content>\n\t\t\t\t\t\t\t<Label text="" id="labelTB" />\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</Toolbar>\n\t\t\t\t</infoToolbar>\n\t\t\t\t<ObjectListItem id="MAIN_LIST_ITEM" press="_handleItemPress"\n\t\t\t\t\ttype="{device>/listItemType}" title="{path:\'ShortText\', formatter: \'unescape\'}">\n\t\t\t\t\t<attributes>\n\t\t\t\t\t\t<ObjectAttribute id="DefectCodeText" text="{DefectCodeText}" />\n\t\t\t\t\t\t<ObjectAttribute id="DATE"\n\t\t\t\t\t\t\ttext="{path:\'CreatedOn\', formatter:\'i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatDaysAgo\'}" />\n\t\t\t\t\t</attributes>\n\t\t\t\t\t<firstStatus>\n\t\t\t\t\t\t<ObjectStatus id="StatusText"\n\t\t\t\t\t\t\ttext="{path:\'Status\', formatter: \'i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusText\'}"\n\t\t\t\t\t\t\tstate="{path:\'Status\', formatter: \'i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusState\'}" />\n\t\t\t\t\t</firstStatus>\n\t\t\t\t</ObjectListItem>\n\t\t\t</List>\n\t\t</content>\n\t\t<footer>\n\t\t\t<Bar id="footer">\n\n\t\t\t</Bar>\n\t\t</footer>\n\t</Page>\n</core:View>\n',
		"i2d/qm/qualityissue/confirm/view/S3.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
			jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
			jQuery.sap.require("sap.ushell.services.CrossApplicationNavigation");
			jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
			jQuery.sap.require("sap.ca.ui.model.type.FileSize");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.InteropServiceHelper");
			sap.ca.scfld.md.controller.BaseDetailController.extend("i2d.qm.qualityissue.confirm.view.S3", {
				onInit: function() {
					sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
					var v = this.getView();
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "detail") {
							var c = new sap.ui.model.Context(v.getModel(), '/' + e.getParameter("arguments").contextPath);
							v.setBindingContext(c)
						}
					}, this);
					this.getView().setModel(sap.ui.getCore().getModel("device"), "device");
					var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
					this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
					this.oApplicationFacade.registerOnMasterListRefresh(this.onMasterRefresh, this)
				},
				onMasterRefresh: function(e) {
					var a = this.byId("ATTACHMENTS").getBinding("items");
					if (!a.bPendingRequest) {
						a._refresh()
					}
				},
				getHeaderFooterOptions: function() {
					return {
						bSuppressBookmarkButton: true
					}
				},
				openBusinessCard: function(e) {
					var E = {};
					if (e) {
						var s = e.getSource();
						if (s) {
							var c = s.getBindingContext();
							var m = this.getView().getModel();
							if (c && m) {
								E = {
									name: m.getProperty("PartnerName", c),
									imgurl: "sap-icon://person-placeholder",
									contactmobile: m.getProperty("PartnerMobilePhone", c),
									contactphone: m.getProperty("PartnerWorkPhone", c),
									contactemail: m.getProperty("PartnerEmail", c),
									companyname: m.getProperty("PartnerCompany", c)
								};
								var o = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
								o.openBy(s)
							}
						}
					}
				},
				navBack: function() {
					window.history.back()
				},
				onListItemSelect: function(e) {
					var s = e.getSource();
					var m = this.getView().getModel();
					var c = s.getBindingContext();
					var N = m.getProperty("NotificationID", c);
					var D = m.getProperty("DocumentNumber", c);
					if (N && D) {
						i2d.qm.qualityissue.confirm.utils.Helper.getAttStream(N, D)
					}
				},
				onNotificationPress: function(e) {
					var l = e.getSource();
					var N = l.getText();
					var h = (this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "QualityNotification",
							action: "displayFactSheet"
						},
						params: {
							"QualityNotification": N
						}
					}));
					if (h) {
						sap.m.URLHelper.redirect(h, true)
					}
				},
			})
		},
		"i2d/qm/qualityissue/confirm/view/S3.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:f="sap.ui.layout.form"\n\txmlns:ui="sap.ca.ui" controllerName="i2d.qm.qualityissue.confirm.view.S3">\n\t<Page title="{i18n>DETAIL_TITLE}" showNavButton="{device>/isPhone}"\n\t\tnavButtonPress="navBack">\n\t\t<content>\n\t\t\t<ObjectHeader title="{path:\'ShortText\', formatter: \'unescape\'}">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute text="{DefectCodeText}" />\n\t\t\t\t\t<ObjectAttribute\n\t\t\t\t\t\ttext="{path:\'CreatedOn\',formatter:\'i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatDaysAgo\'}" />\n\t\t\t\t</attributes>\n\n\t\t\t\t<firstStatus>\n\t\t\t\t\t<ObjectStatus id="StatusText"\n\t\t\t\t\t\ttext="{path:\'Status\', formatter: \'i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusText\'}"\n\t\t\t\t\t\tstate="{path:\'Status\', formatter: \'i2d.qm.qualityissue.confirm.utils.StatusHelper.getStatusState\'}" />\n\t\t\t\t</firstStatus>\n\n\t\t\t</ObjectHeader>\n\n\t\t\t<IconTabBar>\n\t\t\t\t<items>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://hint" iconColor="Default"\n\t\t\t\t\t\tkey="key1">\n\t\t\t\t\t\t<core:ExtensionPoint name="extInfoS3">\n\t\t\t\t\t\t\t<f:SimpleForm id="form1">\n\n\t\t\t\t\t\t\t\t<!-- Notification ID -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_NOTIFICATION" text="{i18n>QI_DV_NOTIFICATION}"\n\t\t\t\t\t\t\t\t\tpadding-right="3em" />\n\t\t\t\t\t\t\t\t<Link id="QI_NOTIFICATION" text="{Notification}" width="100%"\n\t\t\t\t\t\t\t\t\tpress="onNotificationPress" enabled="{path:\'Notification\',formatter:\'i2d.qm.qualityissue.confirm.utils.InteropServiceHelper.isFactSheetExists\'}" />\n\n\t\t\t\t\t\t\t\t<!-- Priority -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_PRIORITY" text="{i18n>QI_PRIORITY}"\n\t\t\t\t\t\t\t\t\tpadding-right="3em" />\n\t\t\t\t\t\t\t\t<Text id="QI_PRIORITY" text="{PriorityText}" width="100%" />\n\n\t\t\t\t\t\t\t\t<!--Assigned to : Contact Person -Partner Name -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_ASSIGN_TO" text="{i18n>QI_DV_ASSIGN_TO}"\n\t\t\t\t\t\t\t\t\tpadding-right="3em" />\n\t\t\t\t\t\t\t\t<Link id="QI_ASSIGN_TO" text="{PartnerName}" press="openBusinessCard" />\n\n\t\t\t\t\t\t\t\t<!--Reported On -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_REPORTED_ON" text="{i18n>QI_REPORT_ON}" />\n\t\t\t\t\t\t\t\t<Text id="QI_REPORTED_ON"\n\t\t\t\t\t\t\t\t\ttext="{path:\'CreatedOn\',formatter:\'i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate\'}" />\n\t\t\t\t\t\t\t</f:SimpleForm>\n\n\t\t\t\t\t\t\t<f:SimpleForm id="form2">\n\t\t\t\t\t\t\t\t<!--Detailed Description -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_DETAILED_DESCRIPTION" text="{i18n>QI_DETAIL_DESCRIPTION}"\n\t\t\t\t\t\t\t\t\tpadding-right="10%" />\n\t\t\t\t\t\t\t\t<Text id="QI_DETAILED_DESCRIPTION" text="{path:\'LongText\', formatter: \'unescape\'}" />\n\t\t\t\t\t\t\t</f:SimpleForm>\n\n\t\t\t\t\t\t\t<f:SimpleForm id="form3">\n\t\t\t\t\t\t\t\t<!--Category -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_CATEGORY" text="{i18n>QI_CATEGORY}"\n\t\t\t\t\t\t\t\t\tpadding-right="10%" />\n\t\t\t\t\t\t\t\t<Text id="QI_CATEGORY" text="{NotifCodeText}" />\n\n\t\t\t\t\t\t\t\t<!-- Reference Code -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_REFERENCE_NUMBER" text="{i18n>QI_REFERENCE}"\n\t\t\t\t\t\t\t\t\tpadding-right="10%" />\n\t\t\t\t\t\t\t\t<Text id="QI_REFERENCE_NUMBER" text="{path:\'ReferenceNumber\', formatter: \'unescape\'}" />\n\n\t\t\t\t\t\t\t\t<!--Material -->\n\t\t\t\t\t\t\t\t<Label labelFor="QI_MATERIAL" text="{i18n>QI_DV_MATERIAL}" />\n\t\t\t\t\t\t\t\t<Text id="QI_MATERIAL"\n\t\t\t\t\t\t\t\t\ttext="{parts:[{path:\'MaterialNumber\'},{path:\'MaterialText\'}],\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t  formatter:\'i2d.qm.qualityissue.confirm.utils.Helper.formatMaterial\'}" />\n\t\t\t\t\t\t\t</f:SimpleForm>\n\t\t\t\t\t\t</core:ExtensionPoint>\n\t\t\t\t\t</IconTabFilter>\n\n\t\t\t\t\t<IconTabFilter icon="sap-icon://attachment"\n\t\t\t\t\t\ticonColor="Default" count="{AttCount}" key="ATT_KEY" id="ATT_ICON_TAB">\n\n\t\t\t\t\t\t<List id="ATTACHMENTS" showSeparators="None"\n\t\t\t\t\t\t\titems="{QMAttachmentSelectionSet}">\n\n\t\t\t\t\t\t\t<StandardListItem\n\t\t\t\t\t\t\t\ttitle="{path: \'DocOrigin\', formatter:\'i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentName\'}"\n\t\t\t\t\t\t\t\ticon="sap-icon://attachment-photo" type="Active" press="onListItemSelect"\n\t\t\t\t\t\t\t\tinfo="{path:\'DocFileSize\', type:\'sap.ca.ui.model.type.FileSize\', formatOptions : { style:\'short\'}}"\n\t\t\t\t\t\t\t\tdescription="{parts:[{path:\'CreatedAt\'},{path:\'CreatorName\'}],\n\t\t\t\t\t                                \t\tformatter:\'i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentDate\'}" />\n\t\t\t\t\t\t</List>\n\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t</items>\n\t\t\t</IconTabBar>\n\t\t</content>\n\n\t\t<footer>\n\t\t\t<Bar>\n\t\t\t</Bar>\n\t\t</footer>\n\t</Page>\n</core:View>\n',
		"i2d/qm/qualityissue/confirm/view/S4.controller.js": function() {
			jQuery.sap.require("sap.ui.core.mvc.Controller");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.ErrorDialog");
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("sap.ca.ui.dialog.factory");
			jQuery.sap.require("i2d.qm.qualityissue.confirm.control.AddPicture");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("i2d.qm.qualityissue.confirm.view.S4", {
				onInit: function() {
					sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
					this.resourceBundle = this.oApplicationFacade.getResourceBundle();
					this.isRoot = true;
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "fsS4") {
							this.isRoot = false
						}
					}, this);
					this.colon = " : ";
					this.openingBracket = " (";
					this.closingBracket = ")";
					this.oConnectionManager = sap.ca.scfld.md.app.Application.getImpl().getConnectionManager();
					var b = sap.ui.getCore().getEventBus();
					this.appId = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getAppIdentifier();
					b.subscribe(this.appId, "OpenS4", this._openFromMV, this);
					b.subscribe(this.appId, "DataLoaded", function() {
						this.getView().getModel().updateBindings(true)
					}, this);
					this.AddPictureCtrl = this.byId("AddPicturesCtrl");
					var v = this.getView();
					jQuery.each(this.oConnectionManager.modelList, function(n, m) {
						if (n == "undefined") {
							v.setModel(m)
						} else {
							v.setModel(m, n)
						}
					});
					this.creationModel = new sap.ui.model.json.JSONModel({
						"/Attachment": "",
						"/ShortText": "",
						"/DefectCodeText": "",
						"/ReferenceNumber": "",
						"/NotifCodeText": "",
						"/LongText": ""
					});
					this.getView().setModel(this.creationModel, "creationModel");
					this.pictureModel = new sap.ui.model.json.JSONModel({
						Pictures: []
					});
					this.getView().setModel(this.pictureModel, "picture");
					this.changeMode = false;
					this.oBusy = null;
					this.bSubmitOK = null;
					this.oSubmitResult = {};
					this.oSubmitButton = this.byId("QI_SUBMIT");
					this.combineGetRequests();
					sap.ui.getCore().attachValidationError(function(e) {
						var a = e.getParameter("element");
						if (a.setValueState) {
							a.setValueState(sap.ui.core.ValueState.Error)
						}
					});
					sap.ui.getCore().attachValidationSuccess(function(e) {
						var a = e.getParameter("element");
						if (a.setValueState) {
							a.setValueState(sap.ui.core.ValueState.None)
						}
					});
					this.bIsFormVAligned = false;
					this.oViewerView = new sap.ui.xmlview("viewer-view", "i2d.qm.qualityissue.confirm.view.Viewer");
					this.oViewerView.setHeight("100%");
					this.oViewerView.setModel(this.pictureModel, "picture");
					this.oViewerDialog = new sap.m.Dialog("viewer-dialog", {
						showHeader: false,
						content: [this.oViewerView],
						stretch: true,
						verticalScrolling: false,
						horizontalScrolling: false,
						contentHeight: "100%",
						contentWidth: "100%",
						endButton: new sap.m.Button({
							text: this.resourceBundle.getText("QI_CONFIRM_BTN"),
							press: jQuery.proxy(this.onPictureViewerClose, this)
						})
					});
					var t = jQuery.proxy(function() {
						this.oViewerView.rerender()
					}, this);
					this.oViewerDialog.attachAfterOpen(t)
				},
				onPictureViewerClose: function() {
					this.oViewerDialog.close()
				},
				combineGetRequests: function() {
					var S = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().settingsName;
					var o = localStorage.getObj(S);
					var i = new sap.ui.core.Item({
						key: "{key}" + this.colon + "{catalogType}" + this.colon + "{codeGroup}",
						text: "{title}" + this.openingBracket + "{category}" + this.closingBracket,
						active: true
					});
					this.oDefectDialog = null;
					this.oDefectInput = this.byId("QI_DEFECT_SELECT");
					var a = [];
					var b = [{
						output: "key",
						source: "DefectCode"
					}, {
						output: "title",
						source: "DefectCodeText"
					}, {
						output: "codeGroup",
						source: "DefectCodeGroup"
					}, {
						output: "category",
						source: "DefectCodeGroupText"
					}, {
						output: "catalogType",
						source: "DefectCatalogType"
					}];
					a.push({
						indexCollection: 0,
						arConversionRules: b,
						itemsPrefix: "items"
					});
					var c = [{
						output: "key",
						source: "NotifCode"
					}, {
						output: "title",
						source: "NotifCodeText"
					}, {
						output: "codeGroup",
						source: "NotifCodeGroup"
					}, {
						output: "category",
						source: "NotifCodeGroupText"
					}, {
						output: "catalogType",
						source: "NotifCatalogType"
					}];
					a.push({
						indexCollection: 1,
						arConversionRules: c,
						itemsPrefix: "items"
					});
					if ($.isBlank(o)) {
						var s = [{
							output: "maxHits",
							source: "MaxHits"
						}, {
							output: "defPlant",
							source: "Plant"
						}, {
							output: "maxFileSize",
							source: "MaxFileSize"
						}];
						a.push({
							indexCollection: 3,
							arConversionRules: s
						})
					}
					var d = i2d.qm.qualityissue.confirm.utils.Helper.getCollection(a, this);
					var l = d && d.length > 0 && d[0];
					var m = new sap.ui.model.json.JSONModel();
					m.setData(l);
					this.oDefectInput.setModel(m);
					this.oDefectInput.bindAggregation("suggestionItems", "/items", i);
					this.selectedDefect = new sap.m.StandardListItem({
						key: "{key}",
						codeGroup: "{codeGroup}",
						category: "{category}",
						title: "{title}",
						catalogType: "{catalogType}",
						active: true
					});
					this.oCategoryDialog = null;
					this.oCatInput = this.byId("QI_CATEGORY_SELECT");
					l = d && d.length > 0 && d[1];
					m = new sap.ui.model.json.JSONModel();
					m.setData(l);
					this.oCatInput.setModel(m);
					this.oCatInput.bindAggregation("suggestionItems", "/items", i);
					this.selectedCategory = new sap.m.StandardListItem({
						key: "{key}",
						codeGroup: "{codeGroup}",
						category: "{category}",
						title: "{title}",
						catalogType: "{catalogType}",
						active: true
					});
					if ($.isBlank(o)) {
						o = d && d.length > 0 && d[2][0];
						localStorage.setObj(S, o)
					}
				},
				onExit: function() {
					if (this.oCategoryDialog) {
						try {
							this.oCategoryDialog.destroy();
							this.oCategoryDialog = null
						} catch (e) {}
					}
					if (this.oDefectDialog) {
						try {
							this.oDefectDialog.destroy();
							this.oDefectDialog = null
						} catch (e) {}
					}
					if (this.oViewerDialog) {
						try {
							this.oViewerDialog.destroy();
							this.oViewerDialog = null
						} catch (e) {}
					}
					if (this.oViewerView) {
						try {
							this.oViewerView.destroy();
							this.oViewerView = null
						} catch (e) {}
					}
					if (this.creationModel) {
						try {
							this.creationModel.destroy();
							this.creationModel = null
						} catch (e) {}
					}
					if (this.pictureModel) {
						try {
							this.pictureModel.destroy();
							this.pictureModel = null
						} catch (e) {}
					}
					if (this.selectedDefect) {
						try {
							this.selectedDefect.destroy();
							this.selectedDefect = null
						} catch (e) {}
					}
					if (this.selectedCategory) {
						try {
							this.selectedCategory.destroy();
							this.selectedCategory = null
						} catch (e) {}
					}
					if (this.oBusy) {
						try {
							this.oBusy.destroy();
							this.oBusy = null
						} catch (e) {}
					}
				},
				_openFromMV: function(c, e, d) {
					this._context = d.context
				},
				applySearchPatternToListItem: function(i, f) {
					if (f.substring(0, 1) === "#") {
						var t = f.substr(1);
						var d = i.getBindingContext().getProperty("Name").toLowerCase();
						return d.indexOf(t) === 0
					} else {
						return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
					}
				},
				onBack: function(e) {
					var b = sap.ui.getCore().getEventBus();
					b.publish("nav", "back")
				},
				onSend: function(e) {
					if (this.submit(true)) {
						this.selectedDefect = null;
						this.cleanModel()
					}
				},
				confirmDefectSelectDialog: function(e) {
					var s = e.getParameter("selectedItem");
					var i = ("DefectSelectDialog" === e.getSource().sId) ? this.oDefectInput : this.oCatInput;
					if (s) {
						i.setValue(s.getTitle());
						i.setValueState(sap.ui.core.ValueState.None);
						var p = s.oBindingContexts.undefined.sPath.split("/");
						var a = p[p.length - 1];
						var b = s.oBindingContexts.undefined.oModel.oData.items[a];
						if (i === this.oCatInput) {
							this.selectedCategory = b
						} else {
							this.selectedDefect = b
						}
						this.onCheckEnableSubmit()
					}
				},
				cancelDefectSelectDialog: function(e) {
					this.onCheckEnableSubmit()
				},
				searchDefect: function(e) {
					var v = e.getParameter("value");
					if (v !== undefined) {
						this.filterDialog(v, e.getSource().getBinding("items"))
					}
				},
				setInitialFilter: function(f, s) {
					f = f.split(this.openingBracket)[0];
					s.open(f);
					var i = s.getBinding("items");
					if (!$.isBlank(f)) {
						this.filterDialog(f, i)
					} else if (f === "" && i.aFilters.length > 0) {
						this.filterDialog(f, i)
					}
				},
				onDefectSelect: function(e) {
					if (!this.oDefectDialog) {
						this.oDefectDialog = i2d.qm.qualityissue.confirm.utils.FragmentHelper.createF4HelpSelectDialog(this, "DefectSelectDialog", this.oDefectInput
							.getModel())
					}
					this.setInitialFilter(e.getSource()._lastValue, this.oDefectDialog)
				},
				onCategorySelect: function(e) {
					if (!this.oCategoryDialog) {
						this.oCategoryDialog = i2d.qm.qualityissue.confirm.utils.FragmentHelper.createF4HelpSelectDialog(this, "CategorySelectDialog", this
							.oCatInput.getModel())
					}
					this.setInitialFilter(e.getSource()._lastValue, this.oCategoryDialog)
				},
				filterDialog: function(v, i) {
					var f = [];
					var s = new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, v);
					f.push(s);
					i.filter(f)
				},
				onSuggest: function(e) {
					var v = e.getParameter("suggestValue");
					if (v !== undefined) {
						this.filterDialog(v, e.getSource().getBinding("suggestionItems"));
						if (e.getSource() === this.oCatInput) {
							this.selectedCategory = ""
						} else {
							this.selectedDefect = ""
						}
						e.getSource().setValueState(sap.ui.core.ValueState.None)
					}
				},
				onSuggestionItemSelected: function(e) {
					var v = e.getParameter("selectedItem");
					if (v !== undefined) {
						var t = new sap.m.StandardListItem({
							key: "{key}",
							codeGroup: "{codeGroup}",
							category: "{category}",
							title: "{title}",
							catalogType: "{catalogType}"
						});
						var p = v.mProperties.key.split(this.colon);
						t.key = p[0];
						t.catalogType = p[1];
						t.codeGroup = p[2];
						p = v.mProperties.text.split(this.openingBracket);
						t.title = p[0];
						t.category = p[1].split(this.closingBracket)[0];
						if (e.getSource() === this.oCatInput) {
							this.selectedCategory = t
						} else {
							this.selectedDefect = t
						} if (jQuery.device.is.phone || jQuery.device.is.tablet) {
							this.onCheckEnableSubmit()
						}
					}
				},
				onValidation: function() {
					var r = false;
					r = this.checkMandatoryFields(["QI_SUBJECT_INPUT", "QI_DEFECT_SELECT"], this);
					if (r) r = this.checkValidInput();
					return r
				},
				checkValidInput: function() {
					var r = true;
					if (this.selectedDefect === "" && this.oDefectInput.getValue() !== "") {
						this.oDefectInput.setValueState(sap.ui.core.ValueState.Error);
						this.oDefectInput.setValueStateText(this.resourceBundle.getText("QI_INVALID_ERROR")), r = false
					} else {
						this.oDefectInput.setValueState(sap.ui.core.ValueState.None)
					} if (this.selectedCategory === "" && this.oCatInput.getValue() !== "") {
						this.oCatInput.setValueState(sap.ui.core.ValueState.Error);
						this.oCatInput.setValueStateText(this.resourceBundle.getText("QI_INVALID_ERROR")), r = false
					} else {
						this.oCatInput.setValueState(sap.ui.core.ValueState.None)
					}
					return r
				},
				submit: function(a) {
					if (!this.oBusy) {
						this.oBusy = new sap.m.BusyDialog()
					}
					this.oBusy.open();
					if (this.onValidation() === false) {
						this.oBusy.close();
						return false
					}
					var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
					var p = localStorage.getObj(A.getParams().settingsName).defPlant;
					var B = ";base64,";
					var b, P;
					var c = [];
					var d = this.byId("AddPicturesCtrl").getPictures();
					var o = null;
					for (var i = 0; i < d.length; i++) {
						b = d[i].getSource();
						P = b.indexOf(B);
						if (P > -1) {
							b = b.substr(P + B.length)
						}
						o = {
							NotificationID: "1",
							DocOrigin: d[i].getName(),
							DocData: b
						};
						c.push(o)
					}
					var e = this.oCatInput.getValue();
					o = {
						NotificationID: "1",
						ShortText: this.byId("QI_SUBJECT_INPUT").getValue(),
						ReferenceNumber: this.byId("QI_REFERENCE_NUMBER_INPUT").getValue(),
						LongText: this.byId("QI_DESCRIPTION_INPUT").getValue(),
						NotifCode: (!$.isBlank(e) && this.selectedCategory.key) ? this.selectedCategory.key : "",
						NotifCodeGroup: (!$.isBlank(e) && this.selectedCategory.codeGroup) ? this.selectedCategory.codeGroup : "",
						NotifCatalogType: (!$.isBlank(e) && this.selectedCategory.catalogType) ? this.selectedCategory.catalogType : "",
						DefectCode: (this.selectedDefect.key) ? this.selectedDefect.key : "",
						DefectCodeGroup: (this.selectedDefect.codeGroup) ? this.selectedDefect.codeGroup : "",
						DefectCatalogType: (this.selectedDefect.catalogType) ? this.selectedDefect.catalogType : "",
						Plant: p ? p : ""
					};
					if (c.length > 0) {
						o[A.getServiceList()[0].QIAttachmentsCreate] = c
					}
					var r = i2d.qm.qualityissue.confirm.utils.Helper.processChangeOperation(A.getServiceList()[0].createCollection, A.getParams().HTTP_Method
						.POST, o, this);
					var N = r && r.NotificationID;
					var n = true;
					this.oBusy.close();
					if (N) {
						var v = this.resourceBundle.getText("QI_TXT_VALIDATION");
						sap.m.MessageToast.show(v);
						this.oRouter.navTo("master", {
							id: "create"
						})
					} else {
						n = false
					}
					return n
				},
				onList: function(e) {
					this.selectedDefect = null;
					this.cleanModel();
					this.oRouter.navTo("master", {
						id: "list"
					})
				},
				onPictureClick: function(e) {
					var s = e.mParameters.pictureItem._oImage;
					this.showGallery(s)
				},
				showGallery: function(s) {
					var a = [];
					var b = 0;
					var g = this.AddPictureCtrl.getPictures();
					for (var i = 0; i < g.length; i++) {
						a.push(g[i]._oImage);
						if (g[i]._oImage === s) b = i
					}
					this.oViewerView.byId("pictureViewer").setSelectedIndex(b);
					this.oViewerDialog.open()
				},
				onPictureAdded: function(e) {
					var i = e.getParameters().pictureItem;
					var p = this.pictureModel.getData().Pictures || [];
					p.push({
						source: i.getSource(),
						name: i.getName(),
						status: i.getStatus()
					});
					this.pictureModel.setData({
						Pictures: p
					})
				},
				onMaxLimitReached: function(e) {
					var m = this.resourceBundle.getText("QI_NO_MORE_IMAGES");
					sap.m.MessageToast.show(m)
				},
				cleanModel: function() {
					var f = null;
					var a = ["QI_SUBJECT_INPUT", "QI_REFERENCE_NUMBER_INPUT", "QI_DESCRIPTION_INPUT", "QI_DEFECT_SELECT", "QI_CATEGORY_SELECT"];
					for (var i = 0; i < a.length; i++) {
						f = this.byId(a[i]);
						if (f) f.setValue("");
						f.setValueState(sap.ui.core.ValueState.None)
					}
					this.AddPictureCtrl.destroyPictures();
					this.oSubmitButton.setEnabled(false);
					this.pictureModel = new sap.ui.model.json.JSONModel({
						Pictures: []
					});
					this.oViewerView.setModel(this.pictureModel, "picture");
					this.getView().setModel(this.pictureModel, "picture")
				},
				onCheckEnableSubmit: function(e) {
					if (!jQuery.device.is.phone && !jQuery.device.is.tablet && this.selectedDefect != undefined) {
						this.selectedDefect.category = ""
					}
					if (!this.byId("QI_SUBJECT_INPUT").getValue().length == 0 && (!this.byId("QI_DEFECT_SELECT").getValue().length == 0 || (this.selectedDefect !=
						undefined && this.selectedDefect.category != undefined && this.selectedDefect.category != null && this.selectedDefect.category !=
						""))) {
						this.oSubmitButton.setEnabled(true)
					} else this.oSubmitButton.setEnabled(false)
				},
				onAfterRendering: function() {
					var f = this.getView().byId("form");
					if (f) {
						var a = f.getContent();
						var c, C, b;
						for (var i = 0; i < a.length; i++) {
							if (a[i] instanceof sap.m.Label) {
								c = a[i].getLabelFor();
								if (c) {
									C = this.getView().byId(c);
									if (C && C.getVisible && C.getVisible()) {
										b = Math.ceil(C.$().children().first().offset().top - C.$().parent().offset().top);
										if (C instanceof sap.m.TextArea) {
											b += parseInt(C.$().children().first().css("padding-top"));
											a[i].$().css("margin-top", b + "px")
										} else if (C instanceof sap.m.Input) {
											b += 4;
											b += C.$().height();
											a[i].$().parent().css("line-height", b + "px");
											a[i].$().css("vertical-align", "middle")
										}
									}
								}
							}
						}
						this.bIsFormVAligned = true
					}
				},
				navBack: function() {
					window.history.back()
				},
				checkMandatoryFields: function(a, c) {
					var f = null;
					var r = true;
					for (var i = 0; i < a.length; i++) {
						f = c.byId(a[i]);
						if (f) {
							if (f.getValue() === "") {
								r = false;
								if (f.setValueState) {
									f.setValueState(sap.ui.core.ValueState.Error);
									f.setValueStateText(this.resourceBundle.getText("QI_DESC_ERROR"));
									r = false
								}
							} else {
								if (f.setValueState) {
									f.setValueState(sap.ui.core.ValueState.None)
								}
							}
						}
					}
					return r
				},
				onFileNotSupported: function(e) {
					var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
					var m = b.getText("QI_FILE_TYPE_NOT_SUPPORTED");
					i2d.qm.qualityissue.confirm.utils.ErrorDialog(m)
				},
			})
		},
		"i2d/qm/qualityissue/confirm/view/S4.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View \ncontrollerName="i2d.qm.qualityissue.confirm.view.S4"\n\t \txmlns="sap.m"\n        xmlns:ui="sap.ca.ui"\n        xmlns:layout="sap.ui.layout"\n        xmlns:our="i2d.qm.qualityissue.confirm.control"\n        xmlns:core="sap.ui.core"\n        xmlns:form="sap.ui.layout.form">\n\n\t<Page id="page" title="{i18n>QI_TITLE_CREATE_VIEW}" showNavButton="true" navButtonPress="navBack">\n\n\t\t<content>\n\t\t\t<form:SimpleForm id="form"  maxContainerCols="2" layout="ResponsiveGridLayout">\n                <form:content>\n\n\t\t\t\t\t<!--Attachment -->\n\t\t\t\t\t<Label labelFor="AddPicturesCtrl" text="{i18n>QI_ATTACHMENT}" width="100%" id="lblAddPictures" visible="false" />\n\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t<our:AddPicture id="AddPicturesCtrl" text="{i18n>QI_ADD_IMG}" buttonPosition="End" maxPictureNumber="10"  uploadUrl="/sap/bc/ui2/encode_file" fileNotSupported="onFileNotSupported" \n\t\t\t\t\t\t pictures="{picture>/Pictures}" show="onPictureClick" pictureAdded="onPictureAdded" buttonPageType="Form" width="100%" maxPictureLimitReached="onMaxLimitReached" compression="High">\t\t\t\t\t\t\n\t\t\t\t\t\t<our:pictures>\n                             <our:PictureItem source="{picture>source}" name="{picture>name}"/>\n                        </our:pictures>\t\t\n\t\t\t\t\t</our:AddPicture>\n\n\n\t\t\t<!--Description -->\n\t\t\t\n\t\t\t\t\t<Label labelFor="QI_SUBJECT_INPUT" text="{i18n>QI_DESCRIPTION}"  required="true" width="100%"/>\t\t\n\t\t\t\t\t\t\t\t\n\t\t\t\t\t<Input id="QI_SUBJECT_INPUT" maxLength="40" liveChange="onCheckEnableSubmit">\t\t\t\t \n\t\t\t\t\t</Input>\n\n\t\t\t<!-- Defect -->\n\t\t\t\n\t\t\t\t\t<Label labelFor="QI_DEFECT_SELECT" text="{i18n>QI_DEFECT}" required="true" width="100%"/>\n\n\t\t\t\t\t<Input id="QI_DEFECT_SELECT"  liveChange="onCheckEnableSubmit" filterSuggests="false"\n\t\t\t\t\t\tshowValueHelp="true" valueHelpRequest="onDefectSelect" showSuggestion="true" suggest="onSuggest" suggestionItemSelected="onSuggestionItemSelected">\t\t\t\t\t\t\n\t\t\t\t\t</Input>\n\t\t\t\n\n\t\t\t\n\t\t\t\t\t<!-- Reference -->\n\t\t\t\t\t<Label labelFor="QI_REFERENCE_NUMBER_INPUT" text="{i18n>QI_REFERENCE}" required="false" width="100%"/>\t\t\t\t\t\t\n\t\t\t\t\t\n\t\t\t\t\t<Input id="QI_REFERENCE_NUMBER_INPUT" type="Text" maxLength="20" >\n\t\t\t\t\t</Input>\n\n\t\t\t\t\t<!-- Category -->\n\t\t\t\t\t<Label labelFor="QI_CATEGORY_SELECT" text="{i18n>QI_CATEGORY}" width="100%"/>\n\t\t\t\t\t\n\t\t\t\t\t<Input id="QI_CATEGORY_SELECT" type="Text" showValueHelp="true" filterSuggests="false"\n\t\t\t\t\t\tvalueHelpRequest="onCategorySelect" showSuggestion="true" suggest="onSuggest" suggestionItemSelected="onSuggestionItemSelected">\t\t\t\t\t\t\n\t\t\t\t\t</Input>\n \t\t\t\t\t\n \t\t\t\t\t<!-- Extension point -->\n \t\t\t\t\t<core:ExtensionPoint name="extMoreFields"/>\n\t\t\t\t\t\n\t\t\t\t\t<!-- Details -->\n\t\t\t\t\t<Label labelFor="QI_DESCRIPTION_INPUT" text="{i18n>QI_DETAIL_DESCRIPTION}"  width="100%"/>\n\t\t\t\t\t\n\t\t\t\t\t<TextArea id="QI_DESCRIPTION_INPUT" width="100%" row="2">\n\t\t\t\t\t</TextArea>\n\t\t\t\t</form:content>\n            </form:SimpleForm>\t\t\n\t\t</content>\n\n\t\t<footer>\n\t\t\t<Bar>\n\n\t\t\t\t<contentRight>\n\t\t\t\t\t<Button id="QI_SUBMIT" text="{i18n>QI_SUBMIT}" press="onSend" enabled="false" type="Emphasized"/>\n\n\t\t\t\t\t<Button id="QI_LIST" text="{i18n>QI_LIST}" enabled="true" press="onList"/>\n\t\t\t\t</contentRight>\n\t\t\t</Bar>\n\n\t\t</footer>\n\t</Page>\n</core:View>\n',
		"i2d/qm/qualityissue/confirm/view/Viewer.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("i2d.qm.qualityissue.confirm.view.Viewer", {
				onInit: function() {
					this.pictureViewer = this.getView().byId("pictureViewer");
					this.galleryItems = "";
					this.editModel = new sap.ui.model.json.JSONModel({
						"editable": true
					});
					this.getView().setModel(this.editModel, "edit");
					this.resourceBundle = this.oApplicationFacade.getResourceBundle()
				},
				setHeaderFooterOptions: function(o) {},
				onRemove: function(e) {
					var p = e.getParameters().index;
					var m = this.getView().getModel("picture");
					var P = m.getData().Pictures;
					P.splice(p, 1);
					m.setData({
						Pictures: P
					})
				},
				_selectImage: function() {}
			})
		},
		"i2d/qm/qualityissue/confirm/view/Viewer.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n        controllerName="i2d.qm.qualityissue.confirm.view.Viewer"\n        xmlns="sap.m"\n        xmlns:core="sap.ui.core"\n        xmlns:ui="sap.ca.ui"        \n        >\n\n    <Page id="viewerPage" title="{i18n>QI_GALLERY_TITLE}" showFooter="false" enableScrolling="false">\n\n        <content>\n            <ui:PictureViewer id="pictureViewer" pictureDeleted="onRemove" tiles="{picture>/Pictures}" removable="{edit>/editable}"\n            \t\t\t\tconfirmActive="true" confirmText="{i18n>QI_DEL_IMG_QUESTION}" >\n                <ui:tiles>\n                    <ui:PictureTile>\n                        <ui:content>\n                            <Image src="{picture>source}" />\n                        </ui:content>\n                    </ui:PictureTile>\n\n                </ui:tiles>\n\n            </ui:PictureViewer>\n\n        </content>\n    </Page>\n\n</core:View>'
	}
});