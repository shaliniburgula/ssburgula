/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.PictureItem");sap.ca.ui.PictureItem.extend("i2d.qm.qualityissue.confirm.control.PictureItem",{});
