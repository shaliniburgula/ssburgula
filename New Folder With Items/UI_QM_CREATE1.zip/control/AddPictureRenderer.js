/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.AddPictureRenderer");jQuery.sap.require("sap.ca.ui.AddPictureRenderer");i2d.qm.qualityissue.confirm.control.AddPictureRenderer={};
i2d.qm.qualityissue.confirm.control.AddPictureRenderer.render=function(r,c){sap.ca.ui.AddPictureRenderer.render(r,c)};
