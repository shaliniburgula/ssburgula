/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.PictureItemRenderer");
jQuery.sap.require("sap.ca.ui.PictureItemRenderer");

i2d.qm.qualityissue.confirm.control.PictureItemRenderer = {
};

/**
 * Renders the HTML for the given control, using the provided {@link sap.ui.core.RenderManager}.
 *
 * @param {sap.ui.core.RenderManager} oRm the RenderManager that can be used for writing to the render output buffer
 * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered
 */
i2d.qm.qualityissue.confirm.control.PictureItemRenderer.render = function(oRm, oControl){
	 // call the base control render function
	sap.ca.ui.PictureItemRenderer.render(oRm, oControl);
};
