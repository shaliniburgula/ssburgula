/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.control.PictureItemRenderer");jQuery.sap.require("sap.ca.ui.PictureItemRenderer");i2d.qm.qualityissue.confirm.control.PictureItemRenderer={};
i2d.qm.qualityissue.confirm.control.PictureItemRenderer.render=function(r,c){sap.ca.ui.PictureItemRenderer.render(r,c)};
