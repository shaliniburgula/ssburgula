/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.StorageHelper");
	
	i2d.qm.qualityissue.confirm.utils.StorageHelper = {			
			
			setItem : function (key, value) {
			    if (!this._localStorage) {
			    	this._localStorage = {};
			    }
				this._localStorage[key] = value;
			},

			getItem : function (key) {

				return this._localStorage && this._localStorage[key];
			},

			removeItem : function (key) {
				if (this._localStorage && this._localStorage[key]) {
					this._localStorage[key] = undefined;
			    }
			},
			
			setObj : function (key, obj) {
				this.setItem(key, JSON.stringify(obj));
			},
			
			getObj : function(key) {
				var  result = this.getItem(key);
				return result && JSON.parse(result);
			}
	};
}());
