/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.StatusHelper");
	jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");

	i2d.qm.qualityissue.confirm.utils.StatusHelper = {
		constructor : function() {
			this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			this.setArrayColors(this.getStatusColors());
		},

		getStatusState : function(value) {
			var _statusStateMap = {
				"000000" : sap.ui.core.ValueState.None,
				"FFFF00" : sap.ui.core.ValueState.Warning,
				"00FF00" : sap.ui.core.ValueState.Success,
				"FF0000" : sap.ui.core.ValueState.Error
			};
			if (!value) {
				return sap.ui.core.ValueState.None;
			}
			var self = i2d.qm.qualityissue.confirm.utils.StatusHelper;
			self.constructor();
			var stateColor = self.getColorByStatus(value);
			return _statusStateMap[stateColor];
		},

		getColorByStatus : function(status) {
			// get mapping first
			if (this.getArrayColors()) {
				var result = $.grep(this.getArrayColors(), function(item) {
					return item.stateStatusCode === status;
				});

				if (result.length > 0) {
					return result[0].stateStatusColor;
				} else {
					return "000000";
				}
			}
		},

		getStatusText : function(status) {
			var self = i2d.qm.qualityissue.confirm.utils.StatusHelper;
			self.constructor();

			if (self.getArrayColors()) {
				var result = $.grep(self.getArrayColors(), function(item) {
					return item.stateStatusCode === status;
				});

				if (result.length > 0) {
					return result[0].stateStatusText;
				} else {
					switch (status) {
					case "I0068":
						return self.oBundle.getText("QI_STATUS_NEW");
					case "I0070":
						return self.oBundle.getText("QI_STATUS_IN_PROCESS");
					case "I0072":
						return self.oBundle.getText("QI_STATUS_COMPLETED");
					case "I0069":
						return self.oBundle.getText("QI_STATUS_POSTPONED");
					default:
						return "";
					}
				}
			}
		},

		getStatusColors : function() {
			// start retrieve if needed
			if (!this.getArrayColors()) {
				var arStatusProperties = [ {
					output : "stateStatusText",
					source : "Text"
				}, {
					output : "stateStatusColor",
					source : "Color"
				}, {
					output : "stateStatusCode",
					source : "Status"
				} ];

				var batchResult = i2d.qm.qualityissue.confirm.utils.Helper.getCollection([ {
					indexCollection : 4,
					arConversionRules : arStatusProperties
				} ]);

				this.setArrayColors(batchResult);

			}
			return this.getArrayColors();
		},

		getArrayColors : function() {
			return this.arStatusColors;
		},

		setArrayColors : function(arColors) {
			this.arStatusColors = arColors;
		}

	};
}());
