/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.ErrorDialog");
jQuery.sap.require("sap.ca.ui.message.message");
i2d.qm.qualityissue.confirm.utils.ErrorDialog = function(m) {
	var _ = "";
	var a = "";
	var b = "";
	var s = "";
	if (typeof m === "string") {
		s = {
			message: m,
			type: sap.ca.ui.message.Type.ERROR
		}
	} else if (m instanceof Array) {
		for (var i = 0; i < m.length; i++) {
			_ = "";
			if (typeof m[i] === "string") {
				_ = m[i]
			} else if (typeof m[i] === "object") {
				_ = m[i].value
			}
			if (i === 0) {
				a = _
			} else {
				b = b + _ + "\n"
			}
		}
		if (b === "") {
			s = {
				message: a,
				type: sap.ca.ui.message.Type.ERROR
			}
		} else {
			s = {
				message: a,
				details: b,
				type: sap.ca.ui.message.Type.ERROR
			}
		}
	}
	sap.ca.ui.message.showMessageBox(s)
};