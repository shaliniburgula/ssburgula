/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.StorageHelper");
	i2d.qm.qualityissue.confirm.utils.StorageHelper = {
		setItem: function(k, v) {
			if (!this._localStorage) {
				this._localStorage = {}
			}
			this._localStorage[k] = v
		},
		getItem: function(k) {
			return this._localStorage && this._localStorage[k]
		},
		removeItem: function(k) {
			if (this._localStorage && this._localStorage[k]) {
				this._localStorage[k] = undefined
			}
		},
		setObj: function(k, o) {
			this.setItem(k, JSON.stringify(o))
		},
		getObj: function(k) {
			var r = this.getItem(k);
			return r && JSON.parse(r)
		}
	}
}());