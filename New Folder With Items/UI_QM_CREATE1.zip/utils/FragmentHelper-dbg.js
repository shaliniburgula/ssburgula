/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.FragmentHelper");
jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.StatusHelper");

i2d.qm.qualityissue.confirm.utils.FragmentHelper = function(){
	
	var customSettingsDialog;
	
	var setMaxHitsData = function(oControl, sMaxHits){
		
		if (!oControl){
			return;
		}
		
		//If the max hits has been already set for a control, then it should be overwritten
		var model = oControl.getModel("maxHits"); 
		
		if (model){
			model.setData({maxHits : sMaxHits});
		}else{
			model = new sap.ui.model.json.JSONModel({maxHits : sMaxHits});
			oControl.setModel(model, "maxHits");
		}
		
	};
	
	var updateCustSetDialogContent = function(oContent, oController){
		
		if (!customSettingsDialog){
			return;
		}
		
		customSettingsDialog.removeAllContent();
		customSettingsDialog.addContent(oContent);
		var customSettingsDialogHeader = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsDialogHeader", oController);
		customSettingsDialogHeader.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
		customSettingsDialog.setCustomHeader(customSettingsDialogHeader);
		
	};
	
	return {
		
		openFilterDialog: function(oController) {
			
			if(!oController){
				return;
			}
			
			if (!this.filterDialog) {
	            this.filterDialog = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.ViewSettingsFilterDialog", oController);
	            this.filterDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
	            this.setFilterDialogModel();
	            this.dateVBox = this.filterDialog.getFilterItems()[1].getCustomControl();
	            this.dateVBox.addStyleClass("qi_dateFilterMargins");
	            this.dateVBox.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
	        }

	        this.filterDialog.open();
			
		},
		
		setFilterDialogDateFilterCount: function(iCount){
			
			//iCount could be 0 or 1
			if (!this.filterDialog){
				return;
			}
			
			this.filterDialog.getFilterItems()[1].setFilterCount(iCount);
			
			if (iCount === 0){
				this.filterDialog.getFilterItems()[1].setSelected(false);
				return;
			}

			this.filterDialog.getFilterItems()[1].setSelected(true);
		},
		
		resetFilterDialogDateFilter: function(sPreviousDateFromUTC, sPreviousDateToUTC){
			if (!this.filterDialog){
				return;
			}
			
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setDateValue();
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].setValue(sPreviousDateFromUTC);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[1].fireChange(true);
			
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setDateValue();
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].setValue(sPreviousDateToUTC);
			this.filterDialog.getFilterItems()[1].getCustomControl().getItems()[3].fireChange(true);
			
			if (!sPreviousDateFromUTC && !sPreviousDateToUTC){
				this.setFilterDialogDateFilterCount(0);
			}else{
				this.setFilterDialogDateFilterCount(1);
			}
			
		},
		
		setFilterDialogModel : function(){
			
			var arStatusData = i2d.qm.qualityissue.confirm.utils.StatusHelper.getArrayColors();
			
			if(!$.isArray(arStatusData) || arStatusData.length < 1 || !this.filterDialog){
				return;
			}

			var model = new sap.ui.model.json.JSONModel({status1 : null}, {status2 : null}, {status3 : null}, {status4 : null});
						
			$.each(arStatusData, function(index, statusData){
				
				switch (statusData.stateStatusCode) {
				case "I0068":
					model.getData().status1 = statusData.stateStatusText;  
					break;
				case "I0070":
					model.getData().status2 = statusData.stateStatusText;  
					break;
				case "I0072":
					model.getData().status3 = statusData.stateStatusText;  
					break;
				case "I0069":
					model.getData().status4 = statusData.stateStatusText;  
					break;
				};
				
			});
			
			this.filterDialog.getFilterItems()[0].setModel(model);
		},
		
		destroyFilterDialog : function(){
			
			//Destroy Filter Dialog and all of its related controls
			if (!this.filterDialog){
				return;
			}
			
			this.filterDialog.destroy();
			this.filterDialog = null;
			
		},
		
		openSortDialog: function(oController) {
			
			if (!this.sortDialog){
	            this.sortDialog = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.ViewSettingsSortDialog", oController);
	            this.sortDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			}
			
	        this.sortDialog.open();
	        
		},
		
		destroySortDialog : function(){

			//Destroy Sort Dialog and all of its related controls
			if (!this.sortDialog){
				return;
			}
			
			this.sortDialog.destroy();
			this.sortDialog = null;
			
		},
		
		openCustSetDialog : function(oController, sMaxHits) {
			
			if (!customSettingsDialog){
				customSettingsDialog = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsDialog", oController);
				customSettingsDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			}
			
			//Reset dialog container
			customSettingsDialog.removeAllContent();
			
			//Load default container with Settings List
			if (!this.customSettingsList){
				this.customSettingsList = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsList", oController);
				this.customSettingsList.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			}

			setMaxHitsData(this.customSettingsList.getItems()[0], sMaxHits);
			customSettingsDialog.addContent(this.customSettingsList);
			customSettingsDialog.destroyCustomHeader();
			
			if (customSettingsDialog.isOpen() !== true){
				customSettingsDialog.open();
			}
			
		},
		
		loadCustSetIssuesNumber : function(oController, sMaxHits) {
			
			//In order to load Issues Number form, CustomSettingsDialog has to be loaded preliminary
			if (!customSettingsDialog){
				return;
			}
			
			if (!this.customSettingsIssueNumber){
				this.customSettingsIssueNumber = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsNumberOfIssues", oController);
			}
			
			setMaxHitsData(this.customSettingsIssueNumber, sMaxHits);
			updateCustSetDialogContent(this.customSettingsIssueNumber, oController);
			
		},
		
		loadCustSetPlantList: function(oController) {

			//In order to load Plants list, CustomSettingsDialog has to be loaded preliminary
			if (!customSettingsDialog){
				return;
			}
			
			if (!this.customSettingsPlantsList){
				this.customSettingsPlantsList = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments.CustomSettingsPlantsList", oController);
				this.customSettingsPlantsList.setModel(oController.oApplicationFacade.getODataModel());
			}

			updateCustSetDialogContent(this.customSettingsPlantsList, oController);
			
		},
		
		closeCustSetDialog: function() {
			if (customSettingsDialog.isOpen() !== false){
				customSettingsDialog.close();
			}
		},
		
		getCustSetMaxHitsTitle : function(sMaxHits){

			//Formatter method
			var bundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			
			if (sMaxHits === "1"){
				return bundle.getText("QI_MAX_ISSUES_ONE");
			}else{
				return bundle.getText("QI_MAX_ISSUES", sMaxHits);
			}
		},
		
		destroyCustSetDialog : function(){
			
			if (customSettingsDialog){
				customSettingsDialog.destroyCustomHeader();
				customSettingsDialog.destroy();
				customSettingsDialog = null;
				this.customSettingsList.destroy();
				this.customSettingsList = null;
			}
			
			if (this.customSettingsIssueNumber){
				this.customSettingsIssueNumber.destroy();
				this.customSettingsIssueNumber = null;
			}
			
			if (this.customSettingsPlantsList){
				this.customSettingsPlantsList.destroy();
				this.customSettingsPlantsList = null;
			}
			
		},
		
		setDefaultPlantByIndex : function(iIndex){
			
			if (!this.customSettingsPlantsList){
				return;
			}
			
			this.customSettingsPlantsList.setSelectedItem(this.customSettingsPlantsList.getItems()[iIndex]);
		},
		
		removePlantSelection : function(){
			
			if (!this.customSettingsPlantsList){
				return;
			}
			
			this.customSettingsPlantsList.removeSelections(false);
			
		},
		
		createF4HelpSelectDialog : function(oController, fragmentName, fragmentModel){
			var selectDialog = sap.ui.xmlfragment("i2d.qm.qualityissue.confirm.fragments." + fragmentName, oController);
			selectDialog.setModel(fragmentModel);
			selectDialog.setModel(oController.oApplicationFacade.getODataModel("i18n"),"i18n");
			//set stretch onProne flag
			if(jQuery.device.is.phone) {
				selectDialog._dialog.setStretch(true);
			}
			
			return selectDialog;
		}
		
	};

}();

