/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.Helper");

	i2d.qm.qualityissue.confirm.utils.Helper = {
		
		processChangeOperation : function(sPath, httpMethod, objOData, oController) {

			this.result = {};
			var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			var oHTTPMethod = oAppConfig.getParams().HTTP_Method;
			// allowed methods are PUT & POST now
			if (httpMethod !== oHTTPMethod.POST && httpMethod !== oHTTPMethod.PUT) {
				jQuery.sap.log.error("Invalid HTTP method has been provided: " + httpMethod);
				return this.result;
			}

			var oModel = oController && oController.getView().getModel();
			if (!oModel) {
				// create model
				oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getServiceList()[0].serviceUrl, true);
			}
		    
			oModel.setRefreshAfterChange(false);

			objOData = !jQuery.isArray(objOData) ? [ objOData ] : objOData;
			
			this.arBatchConfig = [{}];
			this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Change;
			
			var oChangeBatch = null;
			for ( var i = 0; i < objOData.length; i++) {
				oChangeBatch = oModel.createBatchOperation(sPath, httpMethod, objOData[i]);
				oModel.addBatchChangeOperations([ oChangeBatch ]);
			}

			try {
				this.modelSubmitBatch(oModel);
			} catch (error) {
				sap.ca.ui.message.showMessageBox({
					type : sap.ca.ui.message.Type.ERROR,
					message : error.message,
					details : error.details
				});
			}
			
			return this.result;
		},
		
		modelSubmitBatch : function(oModel) {
			oModel.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false);
		},
		modelReadOperation : function(oModel, sPath) {
			oModel.read(sPath, null, null, false, $.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this));	
		},
		
		// setters needed by unit tests
		setProcessingMode : function(value){
			this.ProcessingMode = value;
		},
		
		setarBatchConfig : function(value){
			this.arBatchConfig = value;
		},
		
		setBatchResult : function(value){
			this.result = value;
		},
		// getters
		getBatchResult : function(){
			return this.result;
		},
		getProcessingMode : function(){
			return this.ProcessingMode;
		},
		getarBatchConfig : function(){
			return this.arBatchConfig;
		},
		// end setters/getters
		
		convertCollection : function(arODataProperties, arExpected) {
			var arResult = [];
			if (!arODataProperties) {
				return arResult;
			}
			$.each(arODataProperties, function(index, arODataProperty) {
				var obj = {};
				if (arExpected && $.isArray(arExpected) && arExpected.length > 0) {
					for ( var i = 0; i < arExpected.length; i++) {
						obj[arExpected[i].output] = arODataProperty[arExpected[i].source];
					}
				} else {
					obj = arODataProperty;
				}

				arResult.push(obj);
			});
			return arResult;
		},
		
		getCollection : function(arBatchConfig, oController) {
			/*
			 * format of the read batch operation objGetOperation = { indexCollection :
			 * 0 should be a valid index of the collection located in Configuration.js
			 * arConversionRules : array of objects like {output:"key",
			 * source:"DefectCode"} , if is null or empty - no conversion will be made
			 * itemsPrefix : "items" is the default one prefix, could be null like in
			 * settings
			 *  }
			 */

			var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			this.result = [];

			var oModel = oController && oController.getView().getModel();
			if (!oModel) {
				// create model
				oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getServiceList()[0].serviceUrl, true);
			}
			this.arBatchConfig = arBatchConfig;
			if (arBatchConfig.length === 1 ) {
				// single GET requests are processed as READ operation
				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Read;
				oModel.setUseBatch(false);
				this.modelReadOperation(oModel, oAppConfig.getServiceList()[0].SelectionSetCollection[arBatchConfig[0].indexCollection]);				
			} else {
				// start batch processing
				var oGetBatch = null;
				var arGetOperations = [];

				this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Batch;
				for ( var i = 0; i < arBatchConfig.length; i++) {
					oGetBatch = oModel.createBatchOperation(oAppConfig.getServiceList()[0].SelectionSetCollection[arBatchConfig[i].indexCollection], oAppConfig.getParams().HTTP_Method.GET);
					arGetOperations.push(oGetBatch);
				}

				oModel.addBatchReadOperations(arGetOperations);

				this.modelSubmitBatch(oModel);
				// end batch processing		
			}
			
			return this.result;
		},
		
		getInteropServiceData : function(sPath, oFakeODataModel) {
			

			var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			this.result = [];
			
			// create model	
			var oModel = null;
			if (oFakeODataModel) {
				oModel = oFakeODataModel;
			} else {
				oModel = new sap.ui.model.odata.ODataModel("" + oAppConfig.getParams().InteropService.serviceUrl, true);
			}
			
			this.arBatchConfig = [{}];
			this.ProcessingMode = oAppConfig.getParams().ProcessingModeEnum.Read;
			oModel.setUseBatch(false);
				
			this.modelReadOperation(oModel, sPath);
			return this.result;
		},
		
		fnBatchSuccess : function(oData, oResponse, oErrResponse) {
			// handle the response
			var data, obj;
			var ProcessingModeEnum = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().ProcessingModeEnum;
			
			for ( var i = 0; i < this.arBatchConfig.length; i++) {
				switch (this.ProcessingMode) {
					case ProcessingModeEnum.Batch:
						data = oResponse.data.__batchResponses.length > 0 &&
								oResponse.data.__batchResponses[i].data &&
								oResponse.data.__batchResponses[i].data.results &&
								oResponse.data.__batchResponses[i].data.results.length > 0 && 
								oResponse.data.__batchResponses[i].data.results;
						break;
					case ProcessingModeEnum.Read:
						data = oResponse.data.results;
						break;
					case ProcessingModeEnum.Change:
						data = oResponse.data.__batchResponses[i].__changeResponses && oResponse.data.__batchResponses[i].__changeResponses.length > 0 && oResponse.data.__batchResponses[i].__changeResponses[i].data;
						break;
				}		
				
				// data conversion if needed
				if (this.arBatchConfig[i].arConversionRules) {
					data = i2d.qm.qualityissue.confirm.utils.Helper.convertCollection(data, this.arBatchConfig[i].arConversionRules);
				}
				// set prefix if needed
				if (this.arBatchConfig[i].itemsPrefix) {
					obj = {};
					obj[this.arBatchConfig[i].itemsPrefix] = data;
					this.result.push(obj);
				} else if (this.ProcessingMode === ProcessingModeEnum.Batch){
					this.result.push(data);
				} else {
					this.result = data;
				};
			}

			if (oErrResponse && oErrResponse.length > 0) {
				var oJson = oErrResponse[0].response.body;
				var oNewJ = $.parseJSON(oJson);
				this.result = {};
				this.result.error = oNewJ.error.message.value;
				jQuery.sap.log.error("Error occurs during batch processing: " + oNewJ.error.message.value);

				throw {message : oNewJ.error.message.value, details : oNewJ.error.message.value};
			};
		},

		fnBatchError : function(oError) {
			this.result.error = oError.message;
			jQuery.sap.log.error("Error occurs during batch processing: " + oError.message);
			sap.ca.ui.message.showMessageBox({
				type : sap.ca.ui.message.Type.ERROR,
				message : oError.message,
				details : oError.response.statusText
			});

		},
		
		getAttStream : function(sNotificationID, sDocNum) {

			// Complete/FInish QT using jQuery
			var oAppConfig = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			var sUrl = oAppConfig.getServiceList()[0].serviceUrl + oAppConfig.getServiceList()[0].QIAttachmentStream + "(Notification='" + sNotificationID + "',DocumentNumber='" + sDocNum + "')/$value";
			location.href = sUrl;
		},

		formatMaterial : function(sMatNumber, sMatText) {

			var result = "";

			if (!$.isBlank(sMatNumber) && !$.isBlank(sMatText)) {
				result = sMatNumber + " - " + sMatText;
			} else if (!$.isBlank(sMatNumber)) {
				result = sMatNumber;
			} else if (!$.isBlank(sMatText)) {
				result = sMatText;
			}

			return result;
		},

		/**
		 * Formats the provided oDate in UTC, regardless of the user settings. The OData
		 * backend service expects oDates in UTC format and also ignores any user
		 * customizations in SU01
		 * 
		 * @param ooDate
		 *            the oDate to be formatted
		 */
		convertToISODateTime : function(sDate) {

			if ($.isBlank(sDate)) {
				return;
			}

			var date = new Date(sDate), timeZoneOffset = date.getTimezoneOffset();

			date.setHours(date.getHours() - ~~(timeZoneOffset / 60));
			date.setMinutes(date.getMinutes() - (timeZoneOffset / 60 - ~~(timeZoneOffset / 60)) * 60);

			return date.toISOString();
		},

		isValidDate : function(sDate) {
			if ($.isBlank(sDate) || isNaN(Date.parse(sDate))) {
				return false;
			}

			return true;
		}
		
	};
}());

