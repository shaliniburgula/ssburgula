/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.StatusHelper");
	jQuery.sap.require("i2d.qm.qualityissue.confirm.utils.Helper");
	i2d.qm.qualityissue.confirm.utils.StatusHelper = {
		constructor: function() {
			this.oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			this.setArrayColors(this.getStatusColors())
		},
		getStatusState: function(v) {
			var _ = {
				"000000": sap.ui.core.ValueState.None,
				"FFFF00": sap.ui.core.ValueState.Warning,
				"00FF00": sap.ui.core.ValueState.Success,
				"FF0000": sap.ui.core.ValueState.Error
			};
			if (!v) {
				return sap.ui.core.ValueState.None
			}
			var s = i2d.qm.qualityissue.confirm.utils.StatusHelper;
			s.constructor();
			var a = s.getColorByStatus(v);
			return _[a]
		},
		getColorByStatus: function(s) {
			if (this.getArrayColors()) {
				var r = $.grep(this.getArrayColors(), function(i) {
					return i.stateStatusCode === s
				});
				if (r.length > 0) {
					return r[0].stateStatusColor
				} else {
					return "000000"
				}
			}
		},
		getStatusText: function(s) {
			var a = i2d.qm.qualityissue.confirm.utils.StatusHelper;
			a.constructor();
			if (a.getArrayColors()) {
				var r = $.grep(a.getArrayColors(), function(i) {
					return i.stateStatusCode === s
				});
				if (r.length > 0) {
					return r[0].stateStatusText
				} else {
					switch (s) {
						case "I0068":
							return a.oBundle.getText("QI_STATUS_NEW");
						case "I0070":
							return a.oBundle.getText("QI_STATUS_IN_PROCESS");
						case "I0072":
							return a.oBundle.getText("QI_STATUS_COMPLETED");
						case "I0069":
							return a.oBundle.getText("QI_STATUS_POSTPONED");
						default:
							return ""
					}
				}
			}
		},
		getStatusColors: function() {
			if (!this.getArrayColors()) {
				var a = [{
					output: "stateStatusText",
					source: "Text"
				}, {
					output: "stateStatusColor",
					source: "Color"
				}, {
					output: "stateStatusCode",
					source: "Status"
				}];
				var b = i2d.qm.qualityissue.confirm.utils.Helper.getCollection([{
					indexCollection: 4,
					arConversionRules: a
				}]);
				this.setArrayColors(b)
			}
			return this.getArrayColors()
		},
		getArrayColors: function() {
			return this.arStatusColors
		},
		setArrayColors: function(a) {
			this.arStatusColors = a
		}
	}
}());