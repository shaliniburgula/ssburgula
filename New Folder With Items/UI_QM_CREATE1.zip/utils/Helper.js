/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
(function() {
	'use strict';
	jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.Helper");
	i2d.qm.qualityissue.confirm.utils.Helper = {
		processChangeOperation: function(p, h, o, c) {
			this.result = {};
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			var H = a.getParams().HTTP_Method;
			if (h !== H.POST && h !== H.PUT) {
				jQuery.sap.log.error("Invalid HTTP method has been provided: " + h);
				return this.result
			}
			var m = c && c.getView().getModel();
			if (!m) {
				m = new sap.ui.model.odata.ODataModel("" + a.getServiceList()[0].serviceUrl, true)
			}
			m.setRefreshAfterChange(false);
			o = !jQuery.isArray(o) ? [o] : o;
			this.arBatchConfig = [{}];
			this.ProcessingMode = a.getParams().ProcessingModeEnum.Change;
			var C = null;
			for (var i = 0; i < o.length; i++) {
				C = m.createBatchOperation(p, h, o[i]);
				m.addBatchChangeOperations([C])
			}
			try {
				this.modelSubmitBatch(m)
			} catch (e) {
				sap.ca.ui.message.showMessageBox({
					type: sap.ca.ui.message.Type.ERROR,
					message: e.message,
					details: e.details
				})
			}
			return this.result
		},
		modelSubmitBatch: function(m) {
			m.submitBatch($.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this), false)
		},
		modelReadOperation: function(m, p) {
			m.read(p, null, null, false, $.proxy(this.fnBatchSuccess, this), $.proxy(this.fnBatchError, this))
		},
		setProcessingMode: function(v) {
			this.ProcessingMode = v
		},
		setarBatchConfig: function(v) {
			this.arBatchConfig = v
		},
		setBatchResult: function(v) {
			this.result = v
		},
		getBatchResult: function() {
			return this.result
		},
		getProcessingMode: function() {
			return this.ProcessingMode
		},
		getarBatchConfig: function() {
			return this.arBatchConfig
		},
		convertCollection: function(a, b) {
			var c = [];
			if (!a) {
				return c
			}
			$.each(a, function(d, e) {
				var o = {};
				if (b && $.isArray(b) && b.length > 0) {
					for (var i = 0; i < b.length; i++) {
						o[b[i].output] = e[b[i].source]
					}
				} else {
					o = e
				}
				c.push(o)
			});
			return c
		},
		getCollection: function(a, c) {
			var A = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			this.result = [];
			var m = c && c.getView().getModel();
			if (!m) {
				m = new sap.ui.model.odata.ODataModel("" + A.getServiceList()[0].serviceUrl, true)
			}
			this.arBatchConfig = a;
			if (a.length === 1) {
				this.ProcessingMode = A.getParams().ProcessingModeEnum.Read;
				m.setUseBatch(false);
				this.modelReadOperation(m, A.getServiceList()[0].SelectionSetCollection[a[0].indexCollection])
			} else {
				var g = null;
				var b = [];
				this.ProcessingMode = A.getParams().ProcessingModeEnum.Batch;
				for (var i = 0; i < a.length; i++) {
					g = m.createBatchOperation(A.getServiceList()[0].SelectionSetCollection[a[i].indexCollection], A.getParams().HTTP_Method.GET);
					b.push(g)
				}
				m.addBatchReadOperations(b);
				this.modelSubmitBatch(m)
			}
			return this.result
		},
		getInteropServiceData: function(p, f) {
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			this.result = [];
			var m = null;
			if (f) {
				m = f
			} else {
				m = new sap.ui.model.odata.ODataModel("" + a.getParams().InteropService.serviceUrl, true)
			}
			this.arBatchConfig = [{}];
			this.ProcessingMode = a.getParams().ProcessingModeEnum.Read;
			m.setUseBatch(false);
			this.modelReadOperation(m, p);
			return this.result
		},
		fnBatchSuccess: function(d, r, e) {
			var a, o;
			var P = sap.ca.scfld.md.app.Application.getImpl().oConfiguration.getParams().ProcessingModeEnum;
			for (var i = 0; i < this.arBatchConfig.length; i++) {
				switch (this.ProcessingMode) {
					case P.Batch:
						a = r.data.__batchResponses.length > 0 && r.data.__batchResponses[i].data && r.data.__batchResponses[i].data.results && r.data.__batchResponses[
							i].data.results.length > 0 && r.data.__batchResponses[i].data.results;
						break;
					case P.Read:
						a = r.data.results;
						break;
					case P.Change:
						a = r.data.__batchResponses[i].__changeResponses && r.data.__batchResponses[i].__changeResponses.length > 0 && r.data.__batchResponses[
							i].__changeResponses[i].data;
						break
				}
				if (this.arBatchConfig[i].arConversionRules) {
					a = i2d.qm.qualityissue.confirm.utils.Helper.convertCollection(a, this.arBatchConfig[i].arConversionRules)
				}
				if (this.arBatchConfig[i].itemsPrefix) {
					o = {};
					o[this.arBatchConfig[i].itemsPrefix] = a;
					this.result.push(o)
				} else if (this.ProcessingMode === P.Batch) {
					this.result.push(a)
				} else {
					this.result = a
				}
			}
			if (e && e.length > 0) {
				var j = e[0].response.body;
				var n = $.parseJSON(j);
				this.result = {};
				this.result.error = n.error.message.value;
				jQuery.sap.log.error("Error occurs during batch processing: " + n.error.message.value);
				throw {
					message: n.error.message.value,
					details: n.error.message.value
				}
			}
		},
		fnBatchError: function(e) {
			this.result.error = e.message;
			jQuery.sap.log.error("Error occurs during batch processing: " + e.message);
			sap.ca.ui.message.showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: e.message,
				details: e.response.statusText
			})
		},
		getAttStream: function(n, d) {
			var a = sap.ca.scfld.md.app.Application.getImpl().oConfiguration;
			var u = a.getServiceList()[0].serviceUrl + a.getServiceList()[0].QIAttachmentStream + "(Notification='" + n + "',DocumentNumber='" + d +
				"')/$value";
			location.href = u
		},
		formatMaterial: function(m, M) {
			var r = "";
			if (!$.isBlank(m) && !$.isBlank(M)) {
				r = m + " - " + M
			} else if (!$.isBlank(m)) {
				r = m
			} else if (!$.isBlank(M)) {
				r = M
			}
			return r
		},
		convertToISODateTime: function(d) {
			if ($.isBlank(d)) {
				return
			}
			var a = new Date(d),
				t = a.getTimezoneOffset();
			a.setHours(a.getHours() - ~~(t / 60));
			a.setMinutes(a.getMinutes() - (t / 60 - ~~(t / 60)) * 60);
			return a.toISOString()
		},
		isValidDate: function(d) {
			if ($.isBlank(d) || isNaN(Date.parse(d))) {
				return false
			}
			return true
		}
	}
}());