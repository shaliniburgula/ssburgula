/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.DateTimeConversions");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
i2d.qm.qualityissue.confirm.utils.DateTimeConversions = {};
i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatDaysAgo = function(d) {
	var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style: "daysAgo"
	}, null);
	if (d) return f.format(d, true)
};
i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate = function(d) {
	var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style: "medium"
	}, null);
	if (d) return f.format(d, true)
};
i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatLongDate = function(d) {
	var f = sap.ca.ui.model.format.DateFormat.getDateInstance({
		style: "long"
	}, null);
	if (d) return f.format(d)
};
i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentDate = function(d, u) {
	if (d) {
		var D = d.substring(6, 8) * 1;
		var M = d.substring(4, 6) * 1 - 1;
		var Y = d.substring(0, 4) * 1;
		var h = d.substring(8, 10) * 1;
		var m = d.substring(10, 12) * 1;
		var s = d.substring(12, 14) * 1;
		var a = new Date(Y, M, D, h, m, s);
		a = i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate(a);
		var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		return b.getText("QI_ATT_DOC_DATE", [a, u])
	}
};
i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentName = function(d) {
	if (!d) {
		var b = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		d = b.getText("QI_ATT_DOC_NAME")
	}
	return d
};