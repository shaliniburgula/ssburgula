/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("i2d.qm.qualityissue.confirm.utils.DateTimeConversions");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

i2d.qm.qualityissue.confirm.utils.DateTimeConversions = {};

i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatDaysAgo = function(sDate) {
	var formatterdaysAgo = sap.ca.ui.model.format.DateFormat.getDateInstance({style: "daysAgo"},null);
	if (sDate)
		// Use UTC date as stored in the server
		return formatterdaysAgo.format(sDate, true);
};

i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate = function(sDate) {
	var formatterMedium = sap.ca.ui.model.format.DateFormat.getDateInstance({style: "medium"},null);
	if (sDate)
		// Use UTC date as stored in the server
		return formatterMedium.format(sDate, true);
};

i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatLongDate = function(sDate) {
	var formatterLong = sap.ca.ui.model.format.DateFormat.getDateInstance({style: "long"},null);
	if (sDate)
		return formatterLong.format(sDate);
};

i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentDate = function(sDate, sUser) {	
	if (sDate) {
		// format is <d:CreatedAt>20130913154103</d:CreatedAt>
		var Day = sDate.substring(6, 8) * 1;
		var Month = sDate.substring(4, 6) * 1 - 1;// Month value 0-11
		var Year = sDate.substring(0, 4) * 1;
		var hh = sDate.substring(8,10) * 1;
		var mm = sDate.substring(10,12) * 1;
		var ss = sDate.substring(12,14) * 1;

		var DateStr = new Date(Year, Month, Day, hh, mm, ss);
		
		DateStr = i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatMediumDate(DateStr);
		var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
		
		return oBundle.getText("QI_ATT_DOC_DATE", [DateStr, sUser]);
	}
};

i2d.qm.qualityissue.confirm.utils.DateTimeConversions.formatAttachmentName = function(sDocName) {
	// in case the file is uploaded from the back end and has no name, then the other properties are also not displayed
	// set text for missing name in order to solve the problem
		if(!sDocName){
			var oBundle = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle();
			sDocName = oBundle.getText("QI_ATT_DOC_NAME");
		}
		
		return sDocName;
	};
