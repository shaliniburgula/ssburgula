/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("ui.s2p.srm.sc.approve.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.approve.util.ItemList");
jQuery.sap.require("ui.s2p.srm.sc.approve.util.ObjectCache");
jQuery.sap.require("sap.ca.ui.message.message");
sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.approve.view.S3", {
	onInit: function() {
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.busyDialog = new sap.m.BusyDialog();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.oPageCache = ui.s2p.srm.sc.approve.util.ObjectCache.getInstance();
		this.new_oDataModel = this.oApplicationFacade.getODataModel("CARTAPPROVAL_STANDARD");
		this.count = 0;
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "detail") {
				this.description = undefined;
				var d = e.getParameter("arguments").contextPath;
				d = d.split("WorkflowTaskCollection(")[1].split(")")[0];
				var s = d.split(",");
				var w = s[1].split("=")[1].replace(/'/g, "");
				var S = s[0];
				this.oServerName = s[0].split("=")[1];
				this.count++;
				if (this.count == 1) {
					var a = this.oServerName.substring(1, this.oServerName.length - 1);
					this.new_oDataModel.sServiceUrl = this.new_oDataModel.sServiceUrl + a;
				}
				this.busyDialog.open();
				this.readContent(S, w);
				if (this.oPageCache.isEmpty() || this.oPageCache.getId() !== w) {
					this.oPageCache.clear();
					this.oPageCache.setId(w);
				}
			}
		}, this);
		this.setHeaderFooterOptions(this.createHeaderFooterOptions());
	},
	createHeaderFooterOptions: function() {
		var t = this;
		return {
			sI18NDetailTitle: "DETAIL_TITLE",
			oPositiveAction: {
				sId: "approveBtn",
				sI18nBtnTxt: "APPROVE",
				onBtnPressed: function() {
					jQuery.proxy(t.handleApprove(), this);
				}
			},
			oNegativeAction: {
				sId: "rejectBtn",
				sI18nBtnTxt: "REJECT",
				onBtnPressed: function() {
					jQuery.proxy(t.handleReject(), this);
				}
			},
			buttonList: [{
				sId: "inquireBtn",
				sI18nBtnTxt: "INQUIRE",
				onBtnPressed: function(e) {
					jQuery.proxy(t.handleInquire(e), this);
				}
			}, {
				sId: "sendBtn",
				sI18nBtnTxt: "SEND",
				onBtnPressed: function(e) {
					jQuery.proxy(t.handleSend(e), this);
				}
			}, {
				sId: "forwardBtn",
				sI18nBtnTxt: "FORWARD",
				onBtnPressed: function(e) {
					jQuery.proxy(t.handleForward(e), this);
				}
			}],
			oAddBookmarkSettings: {
				title: t.oApplicationFacade.getResourceBundle().getText("DETAIL_TITLE"),
				icon: "sap-icon//cart"
			},
			onBack: jQuery.proxy(function() {
				var d = sap.ui.core.routing.History.getInstance().getDirection(this.oRouter.getURL("master"));
				if (d === "Backwards") {
					window.history.go(-1);
				} else {
					this.oRouter.navTo("master");
				}
			}, this)
		};
	},
	readContent: function(s, w) {
		var o = function(d, r) {
			this.bindView(d);
		};
		this.oDataModel.setHeaders({
			"X-Requested-With": "XMLHttpRequest",
			"Content-Type": "application/atom+xml"
		});
		this.oDataModel.read("WorkflowTaskCollection(" + s + ",WorkitemID='" + w + "')/SCAHeader", null, [
			"$expand=SCAAttachmentHeader,SCANoteHeader,SCAApproverHeader,SCAItem/SCAAttachmentItem,SCAItem/SCANoteItem"], true, jQuery.proxy(o,
			this), jQuery.proxy(this.onRequestFailed, this));
		if (this.extHook2) {
			this.extHook2();
		};
	},
	bindView: function(d) {
		this.description = d;
		this.getView().byId('icontabBar').setSelectedKey("Information");
		this.getView().byId('icontabBar').setExpanded(true);
		this.getView().setModel(new sap.ui.model.json.JSONModel(d), "description");
		ui.s2p.srm.sc.approve.util.ItemList.item.clear();
		for (var i = 0; i < d.SCAItem.results.length; i++) {
			ui.s2p.srm.sc.approve.util.ItemList.item.add(d.SCAItem.results);
		}
		this.showApproveRejectSendButtons(d.ApprovalOnItemlevel, d.isInquireWorkflow);
		if (this.extHookBind) {
			this.extHookBind(d);
		}
		this.updateItemStateFromCache();
		this.busyDialog.close();
	},
	handleUserNameClick: function(c, e) {
		var p = this.formatEmployee(e);
		var o = function(d, r) {
			var E = {
				imgurl: p,
				name: d.results[0].FullName,
				department: "",
				contactmobile: d.results[0].MobilePhone,
				contactphone: d.results[0].WorkPhone,
				companyname: d.results[0].CompanyName,
				contactemail: d.results[0].EMail,
				contactemailsubj: "",
				companyaddress: d.results[0].AddressString
			};
			var a = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
			a.openBy(c);
		};
		this.oDataModel.read("UserDetailsCollection", null, ["$filter=UserID eq '" + e + "' and SAP__Origin eq " + this.oServerName], false,
			jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this));
	},
	onApproverPress: function(e) {
		if (e.getSource().getModel('description')) {
			var i = parseInt(e.getSource().getBindingContextPath().split('/')[3]);
			var a = this.description.SCAApproverHeader.results;
			var s = e.getParameters().id;
			var c = this.getView().byId(s);
			this.handleUserNameClick(c, a[i].ApproverID);
		}
	},
	onCreatorPress: function(e) {
		var c = this.getView().byId("DetailHeader");
		this.handleUserNameClick(c, this.description.CreatedByID);
	},
	onPersonNamePress: function(e) {
		var c = this.getView().byId("ATTR2");
		var i = "";
		if (this.description.ForwardedByID) {
			i = this.description.ForwardedByID;
		} else if (this.description.SubstitutingForID) {
			i = this.description.SubstitutingForID;
		} else {
			i = this.description.OnBehalfOfID;
		}
		this.handleUserNameClick(c, i);
	},
	onNotePersonPress: function(e) {
		if (e.getSource().getModel('description')) {
			var i = parseInt(e.getSource().getBindingContextPath().split('/')[3]);
			var a = this.description.SCANoteHeader.results;
			var c = this.getView().byId("Notes");
			this.handleUserNameClick(c, a[i].CreatedByID);
		}
	},
	handleApprove: function() {
		var d = this.description;
		var b = this.oApplicationFacade.getResourceBundle();
		sap.ca.ui.dialog.confirmation.open({
			question: b.getText("APPROVESC_BY") + " " + d.CreatedByName + b.getText("QUESTION_MARK"),
			showNote: true,
			title: b.getText("APPROVE"),
			confirmButtonLabel: b.getText("OK")
		}, jQuery.proxy(this.onApprove, this));
	},
	handleReject: function() {
		var d = this.description;
		var b = this.oApplicationFacade.getResourceBundle();
		sap.ca.ui.dialog.confirmation.open({
			question: b.getText("REJECTSC_BY") + " " + d.CreatedByName + b.getText("QUESTION_MARK"),
			showNote: true,
			title: b.getText("REJECT"),
			confirmButtonLabel: b.getText("OK")
		}, jQuery.proxy(this.onReject, this));
	},
	handleSend: function(e) {
		var d = this.description;
		var b = this.oApplicationFacade.getResourceBundle();
		var a = this.byId('itemList').getItems();
		var c = 0;
		var r = 0;
		for (var i = 0; i < a.length; i++) {
			if (a[i].getCells()[0].getProperty('state') == true) {
				c++;
			} else {
				r++;
			}
		}
		sap.ca.ui.dialog.confirmation.open({
			question: b.getText("DECISION") + d.CreatedByName + b.getText("QUESTION_MARK") + "\n\n" + b.getText("APPROVED_ITEMS") + " " + c + "\n" +
				b.getText("REJECTED_ITEMS") + " " + r,
			showNote: true,
			title: b.getText("SEND"),
			text: b.getText("APPROVED_ITEMS") + " " + c,
			additionaltext: b.getText("REJECTED_ITEMS") + " " + r,
			confirmButtonLabel: b.getText("SEND")
		}, jQuery.proxy(this.onApproveRejectAtItemLevel, this));
	},
	handleForward: function(c) {
		var s = function(q) {
			var p = this.oDataModel.sServiceUrl;
			this.oDataModel.read("/ForwardingAgentCollection", null, ["$filter=SearchForText eq '" + q + "'and SAP__Origin eq " + this.oServerName],
				true, jQuery.proxy(function(d, r) {
					sap.ca.ui.dialog.forwarding.setFoundAgents(d.results);
				}, this), jQuery.proxy(this.onSearchRequestFailed, this));
		};
		sap.ca.ui.dialog.forwarding.start(jQuery.proxy(s, this), jQuery.proxy(this.ForwardingAgentCollection, this));
	},
	onItemApproveChange: function(e) {
		var i = e.getSource().sId.split('-')[6];
		if (i !== -1) {
			this.oPageCache.setKey(i, e.getSource().getProperty("state"));
		}
	},
	onApprove: function(r) {
		var d = this.description;
		this.sTextKey = "APPROVED";
		if (r.isConfirmed) {
			var e = {};
			e.Comment = (r.sNote) ? r.sNote : "";
			e.WorkitemID = d.WorkitemID;
			e.DecisionKey = "001";
			e.ScNumber = d.ScNumber;
			var s = this.oServerName.replace(/'/g, "");
			this.oDataModel.setRefreshAfterChange(false);
			var p = this.oDataModel.sServiceUrl;
			this.new_oDataModel.create("ApplyDecision?WorkitemID='" + d.WorkitemID + "'&DecisionKey='001'&Comment='" + encodeURI(e.Comment) + "'",
				e, null, jQuery.proxy(this._handleApproveRejectSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		}
	},
	onReject: function(r) {
		var d = this.description;
		this.sTextKey = "REJECTED";
		if (r.isConfirmed) {
			var e = {};
			e.Comment = (r.sNote) ? r.sNote : "";
			e.WorkitemID = d.WorkitemID;
			e.DecisionKey = "002";
			var s = this.oServerName.replace(/'/g, "");
			var p = this.oDataModel.sServiceUrl;
			this.new_oDataModel.create("ApplyDecision?WorkitemID='" + d.WorkitemID + "'&DecisionKey='002'&Comment='" + encodeURI(e.Comment) + "'",
				e, null, jQuery.proxy(this._handleApproveRejectSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		}
	},
	ForwardingAgentCollection: function(r) {
		var d = this.description;
		if (r && r.bConfirmed) {
			var s = r.oAgentToBeForwarded;
			var e = {};
			e.Comment = (r.sNote) ? r.sNote : "";
			e.WorkitemID = d.WorkitemID;
			e.NewApprover = s.UserId;
			var S = this.oServerName.replace(/'/g, "");
			var p = this.oApplicationFacade.getODataModel().sServiceUrl;
			this.new_oDataModel.create("Forward?WorkitemID='" + d.WorkitemID + "'&NewApprover='" + s.UserId + "'&Comment='" + encodeURI(e.Comment) +
				"'", e, null, jQuery.proxy(this._handleForwardSuccess, this, s), jQuery.proxy(this.onRequestFailed, this));
		}
	},
	_handleApproveRejectSuccess: function() {
		var p = this.oDataModel.sServiceUrl;
		this.oDataModel.sServiceUrl = p.split(";")[0] + ";v=2;mo";
		var c = sap.ui.core.Component.getOwnerIdFor(this.oView);
		var C = sap.ui.component(c);
		C.oEventBus.publish("ui.s2p.srm.sc.approve", "approveShoppingCart");
		this.oDataModel.setRefreshAfterChange(true);
		this.oDataModel.refresh(true);
		var m = this.oApplicationFacade.getResourceBundle().getText(this.sTextKey) + "\n";
		sap.m.MessageToast.show(m);
	},
	_handleForwardSuccess: function(s) {
		var c = sap.ui.core.Component.getOwnerIdFor(this.oView);
		var C = sap.ui.component(c);
		C.oEventBus.publish("ui.s2p.srm.sc.approve", "approveShoppingCart");
		this.oDataModel.setRefreshAfterChange(true);
		this.oDataModel.refresh(true);
		var m = this.oApplicationFacade.getResourceBundle().getText("FORWARDED", [s.FullName]) + "\n";
		sap.m.MessageToast.show(m);
	},
	onApproveRejectAtItemLevel: function(r) {
		var d = this.description;
		var a = [];
		this.sTextKey = "APPROVED";
		var b = 0;
		for (var i = 0; i < d.SCAItem.results.length; i++) {
			var o = {};
			if (this.byId('itemList').getItems()[i].getCells()[0].getProperty('state') == true) {
				o.ItemApproved = d.SCAItem.results[i].ApprovalOnItemlevel;
			} else {
				o.ItemApproved = '0';
				b++;
			}
			o.ItemNumber = d.SCAItem.results[i].ItemNumber;
			a.push(o);
		}
		if (b == d.SCAItem.results.length) {
			this.sTextKey = "REJECTED";
		}
		var s = this.oServerName.replace(/'/g, "");
		if (r.isConfirmed) {
			var e = {};
			e.Comment = (r.sNote) ? r.sNote : "";
			e.WorkitemID = d.WorkitemID;
			e.ScNumber = d.ScNumber;
			e.SCAIBAItem = a;
			var p = this.oDataModel.sServiceUrl;
			this.new_oDataModel.create("SCAIBAHeaderCollection", e, null, jQuery.proxy(this._handleApproveRejectSuccess, this), jQuery.proxy(this.onRequestFailed,
				this));
		}
	},
	onRequestFailed: function(e) {
		this.busyDialog.close();
		var b = this.oApplicationFacade.getResourceBundle();
		this.oDataModel.setRefreshAfterChange(true);
		if (this.oDataModel.hasPendingChanges()) {
			this.oDataModel.refresh(true);
		}
		var m = new Array();
		if (e.response) {
			if (e.response.body) {
				if (jQuery.parseJSON(e.response.body).error.innererror.errordetails) {
					for (var i = 0; i < jQuery.parseJSON(e.response.body).error.innererror.errordetails.length; i++) {
						m.push(jQuery.parseJSON(e.response.body).error.innererror.errordetails[i].message);
					}
				}
			}
		}
		var a = '';
		if (m.length > 0) {
			for (var i = 0; i < m.length; i++) {
				a = m[i] + '\n' + '\n' + a;
			}
		}
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: b.getText("ERROR_MESS"),
			details: a
		});
	},
	onSearchRequestFailed: function(e) {
		this.busyDialog.close();
		var b = this.oApplicationFacade.getResourceBundle();
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: b.getText("SEARCH_MESS")
		});
	},
	updateItemStateFromCache: function(e) {
		if (this.description) {
			if (this.description.ApprovalOnItemlevel === "X" && !this.oPageCache.isEmpty()) {
				for (var i = 0; i < this.description.NumberOfItems; i++) {
					var s = this.oPageCache.getValue(i);
					if (s !== undefined) {
						this.byId("itemList").getItems()[i].getCells()[0].setProperty("state", s);
					}
				}
			}
		}
	},
	showApproveRejectSendButtons: function(i, a) {
		if (i === "") {
			this.byId('itemList').getColumns()[0].setVisible(false);
			var b = this.createHeaderFooterOptions();
			b = this.showInquireButton(b, a);
			this.setHeaderFooterOptions(b);
			this.setBtnEnabled("sendBtn", false);
		} else {
			this.getView().byId('itemList').getColumns()[0].setVisible(true);
			var c = this.createHeaderFooterOptions();
			c.oPositiveAction = null;
			c.oNegativeAction = null;
			c = this.showInquireButton(c, a);
			this.setHeaderFooterOptions(c);
			this.setBtnEnabled("sendBtn", true);
		}
		this.isInquireIntentSupported();
	},
	handleInquire: function() {
		var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
		var d = this.description;
		var h = (this.oCrossAppNavigator && this.oCrossAppNavigator.hrefForExternal({
			target: {
				semanticObject: "ShoppingCartItem",
				action: "inquire"
			},
			params: {
				"SAPSRM_BO_NO": d.ScNumber,
				"SAPSRM_WIID": d.WorkitemID
			}
		}));
		if (h) {
			sap.m.URLHelper.redirect(h);
		}
	},
	showInquireButton: function(o, a) {
		if (a === "" || a === undefined || sap.ui.Device.system.tablet === true || sap.ui.Device.system.phone === true) {
			for (var i = 0; i < o.buttonList.length; i++) {
				if (o.buttonList[i].sId === "inquireBtn") {
					o.buttonList.splice(i, 1);
				}
			}
		}
		return o;
	},
	moveToItemDetail: function(e) {
		var w = e.getSource().getModel('description').getData().WorkitemID;
		var i = e.getSource().sId.split('-')[6];
		var a = e.getSource().getModel('description').getData().SCAItem.results[i].ItemNumber;
		var s = e.getSource().getModel('description').getData().ScNumber;
		var b = this.oServerName;
		this.oRouter.navTo("detailItem", {
			workItemId: w,
			itemIndex: i,
			itemNumber: a,
			scNumber: s,
			servername: b
		}, true);
	},
	navToEmpty: function() {
		this.oRouter.navTo("noData");
	},
	formatEmployee: function(e) {
		if (e.getParameters().key === "approver") {
			var v = "";
			var s = this.oServerName.replace(/'/g, "");
			var a = this.description.SCAApproverHeader.results;
			for (var i = 0; i < a.length; i++) {
				var S = function(d, r) {
					if (r.body.length === 0) {
						v = jQuery.sap.getModulePath("ui.s2p.srm.sc.approve") + "/img/" + "person_placeholder.png";
						this.getView().byId("Approval_list").getItems()[i].setIcon(v);
					} else {
						v = r.requestUri;
						this.getView().byId("Approval_list").getItems()[i].setIcon(v);
					}
					this.oDataModel.sServiceUrl = this.oDataModel.sServiceUrl.split(";")[0] + ";v=2;mo";
				};
				var E = function(o) {
					v = jQuery.sap.getModulePath("ui.s2p.srm.sc.approve") + "/img/" + "person_placeholder.png";
					this.getView().byId("Approval_list").getItems()[i].setIcon(v);
					this.oDataModel.sServiceUrl = this.oDataModel.sServiceUrl.split(";")[0] + ";v=2;mo";
				};
				var b = a[i].ApproverID;
				this.new_oDataModel.read("UserDetailsCollection('" + b + "')/$value", null, null, false, jQuery.proxy(S, this), jQuery.proxy(E, this));
			}
		}
	},
	isMainScreen: function() {
		return true;
	},
	isInquireIntentSupported: function() {
		var i = ["#ShoppingCartItem-inquire?SAPSRM_BO_NO=" + this.description.ScNumber + "&SAPSRM_WIID=" + this.description.WorkitemID];
		var f = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
		this.oCrossAppNavigator = f && f("CrossApplicationNavigation");
		var c = this;
		this.oCrossAppNavigator.isIntentSupported(i).done(function(r) {
			if (r[i[0]].supported !== true) {
				c.setBtnEnabled("inquireBtn", false);
			}
		}).fail(function() {
			c.setBtnEnabled("inquireBtn", false);
		});
	}
});