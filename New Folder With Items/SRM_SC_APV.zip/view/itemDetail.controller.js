/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("ui.s2p.srm.sc.approve.util.ItemList");
jQuery.sap.require("ui.s2p.srm.sc.approve.util.ObjectCache");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.approve.view.itemDetail", {
	onInit: function() {
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.busyDialog = new sap.m.BusyDialog();
		this.getView().byId("itemHeader").setShowNavButton(true);
		this.oPageCache = ui.s2p.srm.sc.approve.util.ObjectCache.getInstance();
		this.new_oDataModel = this.oApplicationFacade.getODataModel("CARTAPPROVAL_STANDARD");
		this.count = 0;
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "detailItem") {
				var w = e.getParameter("arguments").workItemId;
				this.itemIndex = parseInt(e.getParameter("arguments").itemIndex);
				var i = e.getParameter("arguments").itemNumber;
				var s = e.getParameter("arguments").scNumber;
				var S = e.getParameter("arguments").servername;
				this.oServer = S;
				this.count++;
				if (this.count == 1) {
					var a = this.oServer.substring(1, this.oServer.length - 1);
					this.new_oDataModel.sServiceUrl = this.new_oDataModel.sServiceUrl + a;
				}
				this.busyDialog.open();
				this.readContent(false, w, S, s, i);
				this.initHeaderFooter(w);
			}
		}, this);
	},
	readContent: function(f, w, s, a, i) {
		var o = function(D, r) {
			this.itemObj = D;
			this.bindView();
		};
		var d = this.oApplicationFacade.getODataModel();
		d.read("SCAItemCollection(SAP__Origin=" + s + ",WorkitemID='" + w + "',ScNumber='" + a + "',ItemNumber='" + i + "')", null, [
			"$expand=SCAAccounting,SCAAttachmentItem,SCANoteItem,SCAApproverItem"], true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,
			this));
	},
	onRequestFailed: function(e) {
		this.busyDialog.close();
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type: sap.ca.ui.message.Type.ERROR,
			message: e.message,
			details: e.response.body
		});
	},
	initHeaderFooter: function(w) {
		var t = this;
		if (ui.s2p.srm.sc.approve.util.ItemList.item.length() == 0) {
			var o = function(D, r) {
				for (var i = 0; i < D.SCAItem.results.length; i++) {
					ui.s2p.srm.sc.approve.util.ItemList.item.add(D.SCAItem.results);
					this.oHeaderFooterOptions.oUpDownOptions.iPosition = ui.s2p.srm.sc.approve.util.ItemList.item.getIndex(t.itemIndex);
					this.oHeaderFooterOptions.oUpDownOptions.iCount = ui.s2p.srm.sc.approve.util.ItemList.item.length();
					this.setHeaderFooterOptions(this.oHeaderFooterOptions);
				}
			};
			var a = function(e) {
				this.busyDialog.close();
				jQuery.sap.require("sap.ca.ui.message.message");
				sap.ca.ui.message.showMessageBox({
					type: sap.ca.ui.message.Type.ERROR,
					message: e.message,
					details: e.response.body
				});
			};
			var s = t.oServer;
			var d = this.oApplicationFacade.getODataModel();
			d.read("WorkflowTaskCollection(SAP__Origin=" + s + ",WorkitemID='" + w + "')/SCAHeader", null, [
				"$expand=SCAAttachmentHeader,SCANoteHeader,SCAApproverHeader,SCAItem/SCAAttachmentItem,SCAItem/SCANoteItem"], true, jQuery.proxy(o,
				this), jQuery.proxy(a, this));
		}
		this.oHeaderFooterOptions = {
			onBack: function(e) {
				var w = t.itemObj.WorkitemID;
				var s = t.oServer;
				t.new_oDataModel.sServiceUrl = "/sap/opu/odata/GBSRM/CARTAPPROVAL;v=2;o=";
				var p = "WorkflowTaskCollection(SAP__Origin=" + s + ",WorkitemID='" + w + "')";
				t.oRouter.navTo("detail", {
					contextPath: p
				}, true);
			},
			oUpDownOptions: {
				sI18NDetailTitle: "ITEM_DETAIL_HEADER",
				iPosition: 0,
				iCount: 0,
				fSetPosition: function(n) {
					if ((n >= 0) && (n < ui.s2p.srm.sc.approve.util.ItemList.item.length())) {
						t.workItemId = ui.s2p.srm.sc.approve.util.ItemList.item.getWorkItemId(n);
						t.scNumber = ui.s2p.srm.sc.approve.util.ItemList.item.getSCNumber(n);
						t.scItemNumber = ui.s2p.srm.sc.approve.util.ItemList.item.getSCItemNumber(n);
						t.oRouter.navTo("detailItem", {
							workItemId: t.workItemId,
							itemIndex: n,
							itemNumber: t.scItemNumber,
							scNumber: t.scNumber,
							servername: t.oServer
						}, true);
					}
				}
			}
		};
		this.oHeaderFooterOptions.oUpDownOptions.iPosition = ui.s2p.srm.sc.approve.util.ItemList.item.getIndex(t.itemIndex);
		this.oHeaderFooterOptions.oUpDownOptions.iCount = ui.s2p.srm.sc.approve.util.ItemList.item.length();
		this.setHeaderFooterOptions(this.oHeaderFooterOptions);
		if (this.extHook3) {
			this.extHook3();
		};
	},
	bindView: function() {
		this.getApproveRejectData();
		var i = this.itemObj;
		var m = new sap.ui.model.json.JSONModel(i);
		this.getView().setModel(m, "itemDetailData");
		if ((m.oData.DeliveryDate == "" || m.oData.DeliveryDate == null) && m.oData.DeliveryPeriodFrom && m.oData.DeliveryPeriodTo) {
			var d = this.oApplicationFacade.getResourceBundle().getText("DELIVERY_REQUIRED");
			this.getView().byId("delivery").setText(d);
		}
		this.initHeaderFooter(this.itemObj.WorkitemID);
		this.busyDialog.close();
	},
	handleUserNameClick: function(c, e) {
		var p = this.formatEmployee(e);
		var o = function(D, r) {
			var E = {
				imgurl: p,
				name: D.results[0].FullName,
				department: "",
				contactmobile: D.results[0].MobilePhone,
				contactphone: D.results[0].WorkPhone,
				companyname: D.results[0].CompanyName,
				contactemail: D.results[0].EMail,
				contactemailsubj: "",
				companyaddress: D.results[0].AddressString
			};
			var a = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
			a.openBy(c);
		};
		var d = this.oApplicationFacade.getODataModel();
		d.read("UserDetailsCollection", null, ["$filter=UserID eq '" + e + "' and SAP__Origin eq " + this.oServer], false, jQuery.proxy(o, this),
			jQuery.proxy(this.onRequestFailed, this));
	},
	formatEmployee: function(A) {
		var v = "";
		var s = this.oServer.replace(/'/g, "");
		var S = function(d, r) {
			if (r.body.length === 0) {
				v = jQuery.sap.getModulePath("ui.s2p.srm.sc.approve") + "/img/" + "person_placeholder.png";
			} else {
				v = r.requestUri;
			}
		};
		var e = function(E) {
			v = jQuery.sap.getModulePath("ui.s2p.srm.sc.approve") + "/img/" + "person_placeholder.png";
		};
		this.new_oDataModel.sServiceUrl = this.new_oDataModel.sServiceUrl.split(";")[0] + ";v=2;o=" + s;
		this.new_oDataModel.read("UserDetailsCollection('" + A + "')/$value", null, null, false, jQuery.proxy(S, this), jQuery.proxy(e, this));
		return v;
	},
	onAttachment: function(e) {
		var i = parseInt(e.getSource().getBindingContextPath().split('/')[3]);
		var U = this.itemObj.SCAAttachmentItem.results[i].__metadata.media_src;
		ui.s2p.srm.sc.approve.util.Formatter.showAttachment(U);
	},
	onApproverPress: function(e) {
		if (e.getSource().getModel('itemDetailData')) {
			var i = parseInt(e.getSource().getBindingContextPath().split('/')[3]);
			var a = this.itemObj.SCAApproverItem.results;
			var s = e.getParameters().id;
			var c = this.getView().byId(s);
			this.handleUserNameClick(c, a[i].ApproverID);
		}
	},
	onNotePersonPress: function(e) {
		if (e.getSource().getModel('itemDetailData')) {
			var i = parseInt(e.getSource().getBindingContextPath().split('/')[3]);
			var a = this.itemObj.SCANoteItem.results;
			var c = this.getView().byId("NotesDetail");
			this.handleUserNameClick(c, a[i].CreatedByID);
		}
	},
	getApproveRejectData: function() {
		var a = true;
		if (this.oPageCache.getValue(this.itemIndex) == false) {
			a = this.oPageCache.getValue(this.itemIndex);
		}
		if (this.itemObj) {
			if (this.itemObj.ApprovalOnItemlevel != "") {
				if (a) {
					this.getView().byId('approveRejectIcon').setIcon("sap-icon://accept").setState("Success");
				} else {
					this.getView().byId('approveRejectIcon').setIcon("sap-icon://decline").setState("Error");
				}
			} else {
				this.getView().byId('approveRejectIcon').setIcon("");
			}
		}
	}
});