sap.ui.controller("SPUI.ext.controller.ListReportExt", {

	//Create Button
	onClickActionZc_allocsales1: function (oEvent) {
		
			if (!this._oCreateAllocDialog) {
			this._oCreateAllocDialog = sap.ui.xmlfragment("SPUI.ext.fragment.createDeep", this);
			this.getView().addDependent(this._oCreateAllocDialog);
		}
		var oModel = new sap.ui.model.json.JSONModel({
			assigmentno: "",
			rdes: "",
			fromdate: "",
			todate: "",
			slstrgt: "",
			cstmrtrgt: "",
			Assgstatus: "",
			statusText: "",
			allctdexpns: "",
			userid: "",
			assignedby: "",
			SalesTargetAch: ""
		});

		this._oCreateAllocDialog.setModel(oModel);
		var worklogNewList = {};
		var worklogObj = [];
		worklogNewList["worklog"] = worklogObj;
		var worklogModel = new sap.ui.model.json.JSONModel();
		worklogModel.setData(worklogNewList);
		sap.ui.getCore().setModel(worklogModel, "worklogModel")
		sap.ui.getCore().byId("idworklogModelTable").setModel(worklogModel);

		var expenseNewList = {};
		var expenseObj = [];
		expenseNewList["expense"] = expenseObj;
		var expenseModel = new sap.ui.model.json.JSONModel();
		expenseModel.setData(expenseNewList);
		sap.ui.getCore().setModel(expenseModel, "expenseModel")
		sap.ui.getCore().byId("idexpenseModelTable").setModel(expenseModel);

		this._oCreateAllocDialog.open();
	
	},
	onCreate: function (oEvent) {
		var oModel = oEvent.getSource().getModel();
		var assStatus = sap.ui.getCore().byId("assStatus").getSelectedKey();
		var statusText = sap.ui.getCore().byId("assStatus").getSelectedItem().getText();
		var oWorklogModel = sap.ui.getCore().byId("idworklogModelTable").getModel().getData();
		var oExpenseModel = sap.ui.getCore().byId("idexpenseModelTable").getModel().getData();
		var payload = {

			"Accept_ac": "",
			"Reject_ac": "",
			"assigmentno": oModel.oData.assigmentno,
			"slstrgt": oModel.oData.slstrgt,
			"curr": "INR",
			"Assgstatus": assStatus,
			"statusText": statusText,
			"SalesTargetAch": oModel.oData.SalesTargetAch,
			"allctdexpns": oModel.oData.allctdexpns,
			"remarks": "",
			"actiontime": oModel.oData.fromdate,
			"userid": oModel.oData.userid,
			"eassgn_timestamp": oModel.oData.fromdate,
			"fromdate": oModel.oData.fromdate,
			"assignedby": oModel.oData.assignedby,
			"regkey": "100",
			"rdes": oModel.oData.rdes,
			"todate": oModel.oData.todate,
			"cstmrtrgt": oModel.oData.cstmrtrgt,
			"worklog": oWorklogModel.worklog,
			"expense": oExpenseModel.expense

		};
		var datavalue = JSON.stringify(payload);
		console.log(datavalue);

		var jurl = "/SCService/xsjs/SPDeepOps.xsjs?cmd=createAlloc";
		var that = this;
		jQuery.ajax({

			url: jurl,
			async: false,
			data: {
				dataobject: datavalue
			},
			method: 'POST',
			dataType: 'text',
			success: function (data) {
				that._oCreateAllocDialog.close();
				new sap.m.MessageBox.confirm(data);
			}
		});

		this.getView().getModel().refresh();
	},
	onCancel: function () {
		this._oCreateAllocDialog.close();
	},
	
	onPressExpense: function () {
		var oTablelength = sap.ui.getCore().byId("idexpenseModelTable").getItems().length;
		var myjsonExpense = new sap.ui.model.json.JSONModel();
		var mydataExpense = {};
		if (oTablelength === 0) {
			objectExpense = [];
		}
		mydataExpense["expense"] = objectExpense;
		myjsonExpense.setData(mydataExpense);
		sap.ui.getCore().setModel("expenseModel", myjsonExpense);
		sap.ui.getCore().byId("idexpenseModelTable").setModel("expenseModel", myjsonExpense);

		sap.ui.getCore().byId("idexpenseModelTable").getModel().getData().expense.push({
			expno: "",
			regkey: "",
			userid: "",
			rdes: "",
			statu: "02",
			StatusDesc: "Submitted",
			remarks: "",
			approvernote: "",
			exp_timestamp: "",
			assigmentno: "",
			expcatid: "",
			CategoryText: "",
			amount: "",
			curr: "INR",
			frmdate: "",
			todate: "",
			lockey: ""

		});
		sap.ui.getCore().byId("idexpenseModelTable").getModel().refresh(true);

	},
	onPressWorklog: function () {

		var oTablelength = sap.ui.getCore().byId("idworklogModelTable").getItems().length;
		var myjsonWorklog = new sap.ui.model.json.JSONModel();
		var mydataWorklog = {};
		if (oTablelength === 0) {
			objectWorklog = [];
		}
		mydataWorklog["worklog"] = objectWorklog;
		myjsonWorklog.setData(mydataWorklog);
		sap.ui.getCore().setModel("worklogModel", myjsonWorklog);
		sap.ui.getCore().byId("idworklogModelTable").setModel("worklogModel", myjsonWorklog);

		sap.ui.getCore().byId("idworklogModelTable").getModel().getData().worklog.push({
			worklogno: "",
			custaddres: "",
			custphno: "",
			amount: "",
			curr: "INR",
			statu: "",
			SalesStatusText: "",
			feedback: "",
			FeedbackDesc: "",
			remarks: "",
			assigmentno: "",
			salesemp: "",
			regkey: "",
			rdes: "",
			prdid: "",
			quantity: "",
			custdetail: "",
			CreatedTime: ""

		});
		sap.ui.getCore().byId("idworklogModelTable").getModel().refresh(true);

	},
	onCategory: function (e) {
		var sId = parseInt(e.getSource().getId().split("idexpenseModelTable-")[1]);
		var tableItems = sap.ui.getCore().byId("idexpenseModelTable").getItems();
		var CategoryText = tableItems[sId].getAggregation("cells")[2].getSelectedItem().getText();
		var expcatid = tableItems[sId].getAggregation("cells")[2].getSelectedKey();

		sap.ui.getCore().getModel("expenseModel").setProperty("/expense/" + sId + "/expcatid", expcatid);
		sap.ui.getCore().getModel("expenseModel").setProperty("/expense/" + sId + "/CategoryText", CategoryText);
		var oModel = this._oCreateAllocDialog.getModel();
		sap.ui.getCore().getModel("expenseModel").setProperty("/expense/" + sId + "/assigmentno", oModel.oData.assigmentno);
		sap.ui.getCore().getModel("expenseModel").setProperty("/expense/" + sId + "/rdes", oModel.oData.rdes);
		sap.ui.getCore().getModel("expenseModel").setProperty("/expense/" + sId + "/userid", oModel.oData.userid);
	},
	onChange: function (e) {
		var sId = parseInt(e.getSource().getId().split("idworklogModelTable-")[1]);
		var tableItems = sap.ui.getCore().byId("idworklogModelTable").getItems();
		var salesStatusText = tableItems[sId].getAggregation("cells")[4].getSelectedItem().getText();
		var salesStatusKey = tableItems[sId].getAggregation("cells")[4].getSelectedKey();

		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/statu", salesStatusKey);
		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/SalesStatusText", salesStatusText);

		var oModel = this._oCreateAllocDialog.getModel();
		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/assigmentno", oModel.oData.assigmentno);
		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/rdes", oModel.oData.rdes);

	},
	onChangeFeedback: function (e) {
		var sId = parseInt(e.getSource().getId().split("idworklogModelTable-")[1]);
		var tableItems = sap.ui.getCore().byId("idworklogModelTable").getItems();
		var FeedbackDesc = tableItems[sId].getAggregation("cells")[5].getSelectedItem().getText();
		var feedback = tableItems[sId].getAggregation("cells")[5].getSelectedKey();

		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/feedback", feedback);
		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/FeedbackDesc", FeedbackDesc);
	},
	onChangeProduct: function (e) {
		var sId = parseInt(e.getSource().getId().split("idworklogModelTable-")[1]);
		var tableItems = sap.ui.getCore().byId("idworklogModelTable").getItems();
		var prdDesc = tableItems[sId].getAggregation("cells")[6].getSelectedItem().getText();
		var prdid = tableItems[sId].getAggregation("cells")[6].getSelectedKey();

		sap.ui.getCore().getModel("worklogModel").setProperty("/worklog/" + sId + "/prdid", prdid);

	},
	//Update Button
	onClickActionZc_allocsales2: function (oEvent) {
		var assignmentNo = oEvent.getSource().getParent().getParent().getTable().getSelectedItem().getBindingContext().getProperty(
			"assigmentno");
		var sPath = oEvent.getSource().getParent().getParent().getTable().getSelectedItem().getBindingContext().getPath();
		if (!this._oUpdateAllocDialog) {
			this._oUpdateAllocDialog = sap.ui.xmlfragment(this.getView().getId(), "SPUI.ext.fragment.updateDeep", this);
			this.getView().addDependent(this._oUpdateAllocDialog);
		}
		this._oUpdateAllocDialog.bindElement(sPath);

		this._oUpdateAllocDialog.open();

	},
	onCancelUpdate: function () {
		this._oUpdateAllocDialog.close();

	},
	//Delete Button
	onClickActionZc_allocsales3: function (oEvent) {
		
		var assignmentNo = oEvent.getSource().getParent().getParent().getTable().getSelectedItem().getBindingContext().getProperty(
			"assigmentno");
		var oModel = oEvent.getSource().getModel();
		var payload = {
			"assigmentno": assignmentNo
		};
		var datavalue = JSON.stringify(payload);

		var jurl = "/SCService/xsjs/SPDeepOps.xsjs?cmd=deleteAlloc";
		var that = this;
		var that = this;
		jQuery.ajax({

			url: jurl,
			async: false,
			TYPE: 'POST',
			data: {
				dataobject: datavalue
			},
			method: 'GET',
			dataType: 'text',
			success: function (data) {
				new sap.m.MessageBox.confirm(data);
			}
		});
		this.getView().getModel().refresh();

	},
		onUpdate: function (oEvent) {
		var assgNo = this.getView().byId("idAssgNo").getValue();
		var region = this.getView().byId("idReg").getValue();
		var slsTgt = this.getView().byId("idSlsTrgt").getValue();
		var assStatus = this.getView().byId("assStatus1").getSelectedKey();
		var statusText = this.getView().byId("assStatus1").getSelectedItem().getText();
		var eTgt = this.getView().byId("idEtrgt").getValue();
		var allcExp = this.getView().byId("idAllcExp").getValue();
		var sTArch = this.getView().byId("idSTarch").getValue();
		var userId = this.getView().byId("idUser").getValue();

		var assgBy = this.getView().byId("idAssgBy").getValue();
		var fD = this.getView().byId("idFD").getValue();
		var eD = this.getView().byId("idED").getValue();

		var aWorklog = [];
		var aWorklogItems = this.getView().byId("idworklogModelTable1").getItems();
		for (var i = 0; i < aWorklogItems.length; i++) {
			var newWorkLogItem = {
				worklogno: aWorklogItems[i].getAggregation("cells")[0].getValue(),
				custaddres: aWorklogItems[i].getAggregation("cells")[1].getValue(),
				custphno: aWorklogItems[i].getAggregation("cells")[2].getValue(),
				amount: aWorklogItems[i].getAggregation("cells")[3].getValue(),
				curr: "INR",
				statu: aWorklogItems[i].getAggregation("cells")[4].getSelectedKey(),
				SalesStatusText: aWorklogItems[i].getAggregation("cells")[4].getSelectedItem().getText(),
				feedback: aWorklogItems[i].getAggregation("cells")[5].getSelectedKey(),
				FeedbackDesc: aWorklogItems[i].getAggregation("cells")[5].getSelectedItem().getText(),
				remarks: "",
				assigmentno: assgNo,
				salesemp: "",
				regkey: "",
				rdes: region,
				prdid: aWorklogItems[i].getAggregation("cells")[6].getSelectedKey(),
				quantity: aWorklogItems[i].getAggregation("cells")[7].getValue(),
				custdetail: aWorklogItems[i].getAggregation("cells")[8].getValue(),
				CreatedTime: aWorklogItems[i].getAggregation("cells")[9].getValue()

			};
			aWorklog.push(newWorkLogItem);
		}
		var aExpense = [];
		var aExpenseItems = this.getView().byId("idexpenseModelTable1").getItems();
		for (var i = 0; i < aExpenseItems.length; i++) {
			var newExpenseItem = {
				expno: aExpenseItems[i].getAggregation("cells")[0].getValue(),
				regkey: "",
				userid: userId,
				rdes: region,
				statu: "02",
				StatusDesc: "Submitted",
				remarks: "",
				approvernote: "",
				exp_timestamp: aExpenseItems[i].getAggregation("cells")[3].getValue(),
				assigmentno: assgNo,
				expcatid: aExpenseItems[i].getAggregation("cells")[2].getSelectedKey(),
				CategoryText: aExpenseItems[i].getAggregation("cells")[2].getSelectedItem().getText(),
				amount: aExpenseItems[i].getAggregation("cells")[3].getValue(),
				curr: "INR",
				frmdate: aExpenseItems[i].getAggregation("cells")[4].getValue(),
				todate: aExpenseItems[i].getAggregation("cells")[5].getValue(),
				lockey: ""

			};
			aExpense.push(newExpenseItem);
		}

		var payload = {

			"Accept_ac": "",
			"Reject_ac": "",
			"assigmentno": assgNo,
			"slstrgt": slsTgt,
			"curr": "INR",
			"Assgstatus": assStatus,
			"statusText": statusText,
			"SalesTargetAch": sTArch,
			"allctdexpns": allcExp,
			"remarks": "",
			"actiontime": fD,
			"userid": userId,
			"eassgn_timestamp": fD,
			"fromdate": fD,
			"assignedby": assgBy,
			"regkey": "",
			"rdes": region,
			"todate": eD,
			"cstmrtrgt": eTgt,
			"worklog": aWorklog,
			"expense": aExpense

		};
		var datavalue = JSON.stringify(payload);
		console.log(datavalue);

		var jurl = "/SCService/xsjs/SPDeepOps.xsjs?cmd=updateAlloc";
		var that = this;
		jQuery.ajax({

			url: jurl,
			async: false,
			data: {
				dataobject: datavalue
			},
			method: 'POST',
			dataType: 'text',
			success: function (data) {
				that._oUpdateAllocDialog.close();
				new sap.m.MessageBox.confirm(data);
			}
		});

		this.getView().getModel().refresh();
	},
	
});