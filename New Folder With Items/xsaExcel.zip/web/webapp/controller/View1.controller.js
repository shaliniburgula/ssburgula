sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("web.web.controller.View1", {
		downloadExcel : function(){
			
			var aUrl = '/xsjs/hdb.xsjs';
		jQuery.ajax({
			url: aUrl,
			method: 'GET',
			dataType: 'json',
			success: this.onSuccessCall,
			error: this.onErrorCall });
		},
		
		onErrorCall: function(jqXHR, textStatus, errorThrown){
		 
	},
	onSuccessCall: function(body){
		console.log(body);
	},
	});
});