sap.ui.define([
	"com/caltex/au/ZSupplier_Hub/test/unit/controller/App.controller"
], function () {
	"use strict";
});