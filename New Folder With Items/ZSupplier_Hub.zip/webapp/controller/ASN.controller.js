var ASNModel,oTable;
var monthVal,month,headerVal;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",
	'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel'
], function (Controller, BaseController, Filter, JSONModel) {
	"use strict";

	return BaseController.extend("com.caltex.au.ZSupplier_Hub.controller.ASN", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.ASN
		 */
		onInit: function () {
				this.getRouter().getRoute("ASN").attachPatternMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched: function (oEvent) {
			monthVal =  oEvent.getParameter("arguments").monthValue;
			headerVal =  oEvent.getParameter("arguments").statusASNVal;
			if(monthVal ==="Six Months"){
				month = "M06";
			}
			else if(monthVal === "Year"){
				month = "M12";
			}
			else
			{
				month = "M03";
			}
			var oModel = new JSONModel();
			oTable = this.getView().byId("idASNTable");
			oModel.loadData("./localService/mockdata/AsnHubSet.json", true);

			oModel.attachRequestCompleted(function (oEvent1) {
				ASNModel = oEvent1.getSource();
				
				sap.ui.getCore().setModel(ASNModel,"ASNModel");
				oTable.setModel(ASNModel,"ASNModel");
				var oBinding = oTable.getBinding("items"),	aFilters = [],oASNValues;
				oASNValues = new Filter([new Filter("DataRange", "EQ", month),new Filter("AsnStatTxt", "EQ", headerVal)], true);
				aFilters.push(new Filter([oASNValues], false));
					oBinding.filter(aFilters);

			});
		},
		handleIconTabBarSelect: function (oEvent) {
				var oBinding = oTable.getBinding("items"),
				sKey = oEvent.getParameter("key"),
				// Array to combine filters
				aFilters = [],
				oASNValues;

			if (sKey === "All") {
				oASNValues = new Filter([new Filter("DataRange", "EQ", month)], true);
			
				aFilters.push(new Filter([oASNValues], false));
			} else if (sKey === "In-Transit") {
				oASNValues = new Filter([new Filter("AsnStatTxt", "EQ", sKey), new Filter("DataRange", "EQ", month)], true);
				aFilters.push(new Filter([oASNValues ], false));
			} else if (sKey === "Pending") {
				oASNValues = new Filter([new Filter("AsnStatTxt", "EQ", sKey), new Filter("DataRange", "EQ", month)], true);
				aFilters.push(new Filter([oASNValues], false));
			}else if (sKey === "Gate Entry") {
				oASNValues = new Filter([new Filter("AsnStatTxt", "EQ", sKey), new Filter("DataRange", "EQ", month)], true);
				aFilters.push(new Filter([oASNValues], false));
			}else if (sKey === "Pending GRN") {
				oASNValues = new Filter([new Filter("AsnStatTxt", "EQ", sKey), new Filter("DataRange", "EQ", month)], true);
				aFilters.push(new Filter([oASNValues], false));
			}
			oBinding.filter(aFilters);
			}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.ASN
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.ASN
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.ASN
		 */
		//	onExit: function() {
		//
		//	}

	});

});