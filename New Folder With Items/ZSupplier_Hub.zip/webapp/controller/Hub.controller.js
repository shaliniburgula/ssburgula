var selectedKey = "Three Months";
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",
	'sap/ui/core/Element',
], function (Controller, BaseController, Element) {
	"use strict";

	return BaseController.extend("com.caltex.au.ZSupplier_Hub.controller.Hub", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.Hub
		 */
		onInit: function () {
			var oModel = new sap.ui.model.json.JSONModel(sap.ui.require.toUrl("localService/tiles.json"));
			this.getView().setModel(oModel);
		},
		pressPOStatus: function (oEvent) {
		  var headerVal = this.getView().byId(oEvent.getParameters().id).getHeader();
			
			this.getRouter().navTo("PO", {
					monthValue :	selectedKey,
					statusVal  :  headerVal
			});
		},
		pressASNStatus : function(oEvent){
			var subheaderVal = this.getView().byId(oEvent.getParameters().id).getSubheader();
			
			this.getRouter().navTo("ASN", {
					monthValue :	selectedKey,
					statusASNVal  :  subheaderVal
			});
		},
		onSelectionChange: function (oEvent) {
			var oSegmentedButton = this.byId('SB1'),
				oSelectedItemId = oSegmentedButton.getSelectedItem(),
				oSelectedItem = Element.registry.get(oSelectedItemId);

			selectedKey = oSelectedItem.getText();

			if (selectedKey === "Six Months") {
				this.byId("idpoNew").setSubheader("3");
				this.byId("idpoConf").setSubheader("2");
				this.byId("idASN1").setHeader("3");
				this.byId("idASN2").setHeader("2");
				this.byId("idASN3").setHeader("4");
				this.byId("idASN4").setHeader("5");

				this.byId("idInv1").setHeader("3");
				this.byId("idInv2").setHeader("2");
				this.byId("idInv3").setHeader("4");
				this.byId("idInv4").setHeader("5");
				this.byId("idInv5").setHeader("3");
				this.byId("idInv6").setHeader("2");
				this.byId("idInv7").setHeader("4");
				this.byId("idInv8").setHeader("5");
			} else if (selectedKey === "Year") {
				this.byId("idpoNew").setSubheader("10");
				this.byId("idpoConf").setSubheader("6");
				this.byId("idASN1").setHeader("6");
				this.byId("idASN2").setHeader("7");
				this.byId("idASN3").setHeader("9");
				this.byId("idASN4").setHeader("6");

				this.byId("idInv1").setHeader("1");
				this.byId("idInv2").setHeader("3");
				this.byId("idInv3").setHeader("5");
				this.byId("idInv4").setHeader("7");
				this.byId("idInv5").setHeader("2");
				this.byId("idInv6").setHeader("4");
				this.byId("idInv7").setHeader("8");
				this.byId("idInv8").setHeader("6");
			} else {
				this.byId("idpoNew").setSubheader("6");
				this.byId("idpoConf").setSubheader("1");
				this.byId("idASN1").setHeader("1");
				this.byId("idASN2").setHeader("2");
				this.byId("idASN3").setHeader("3");
				this.byId("idASN4").setHeader("4");

				this.byId("idInv1").setHeader("1");
				this.byId("idInv2").setHeader("2");
				this.byId("idInv3").setHeader("3");
				this.byId("idInv4").setHeader("4");
				this.byId("idInv5").setHeader("5");
				this.byId("idInv6").setHeader("6");
				this.byId("idInv7").setHeader("7");
				this.byId("idInv8").setHeader("8");
			}

		}
	

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.Hub
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.Hub
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.Hub
		 */
		//	onExit: function() {
		//
		//	}

	});

});