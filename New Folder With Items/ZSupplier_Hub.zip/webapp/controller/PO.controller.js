var POModel,oTable;
var monthVal,month,headerVal;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"./BaseController",

	'sap/ui/model/Filter',
	'sap/ui/model/json/JSONModel'
], function (Controller, BaseController, Filter, JSONModel) {
	"use strict";

	return BaseController.extend("com.caltex.au.ZSupplier_Hub.controller.PO", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.PO
		 */
		onInit: function () {

			this.getRouter().getRoute("PO").attachPatternMatched(this._onObjectMatched, this);

		},
		_onObjectMatched: function (oEvent) {
			monthVal =  oEvent.getParameter("arguments").monthValue;
			headerVal =  oEvent.getParameter("arguments").statusVal;
			if(monthVal ==="Six Months"){
				month = "M06";
			}
			else if(monthVal === "Year"){
				month = "M12";
			}
			else
			{
				month = "M03";
			}
			var oModel = new JSONModel();
			oTable = this.getView().byId("idPOTable");
			oModel.loadData("./localService/mockdata/PoHubSet.json", true);

			oModel.attachRequestCompleted(function (oEvent1) {
				POModel = oEvent1.getSource();
				
				sap.ui.getCore().setModel(POModel);
				oTable.setModel(POModel);
				var oBinding = oTable.getBinding("items"),	aFilters = [],oPOValues;
				oPOValues = new Filter([new Filter("DataRange", "EQ", month),new Filter("PoStatTxt", "EQ", headerVal)], true);
				aFilters.push(new Filter([oPOValues], false));
					oBinding.filter(aFilters);

			});
		},
		handleIconTabBarSelect: function (oEvent) {
				var oBinding = oTable.getBinding("items"),
				sKey = oEvent.getParameter("key"),
				// Array to combine filters
				aFilters = [],
				oPOValues;

			if (sKey === "All") {
				oPOValues = new Filter([new Filter("DataRange", "EQ", month)], true);
			
				aFilters.push(new Filter([oPOValues], false));
			} else if (sKey === "New") {
				oPOValues = new Filter([new Filter("PoStatTxt", "EQ", "New"), new Filter("DataRange", "EQ", month)], true);
				aFilters.push(new Filter([oPOValues ], false));
			} else if (sKey === "Confirmed") {
				oPOValues = new Filter([new Filter("PoStatTxt", "EQ", "Confirmed"), new Filter("DataRange", "EQ", month)], true);
				aFilters.push(new Filter([oPOValues], false));
			}
			oBinding.filter(aFilters);
			}
			/*,
					_loadData : function()
					{
						var dModel = new sap.ui.model.json.JSONModel();
						this.oTable = this.getView().byId("idPOTable").setModel(ModelPO,"POModel");
					}*/

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.PO
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.PO
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.caltex.au.ZSupplier_Hub.view.PO
		 */
		//	onExit: function() {
		//
		//	}

	});

});