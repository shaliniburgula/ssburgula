jQuery.sap.declare("hcm.people.profile.Z_PEP_PROFEXT.Component");
	
(function() {



	jQuery.sap.registerModulePath("sap.hcm.lib.common", "/sap/bc/ui5_ui5/sap/hcm_common/sap/hcm/lib/common/");



}());

// use the load function for getting the optimized preload file if present

sap.ui.component.load({

	name: "hcm.people.profile",

	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository

	url: "/sap/bc/ui5_ui5/sap/HCM_PEP_PROFILE"



	// we use a URL relative to our own component

	// extension application is deployed with customer namespace

});


var batch = new Array();
var reportBatch = new Array();
var parentId ;
this.hcm.people.profile.Component.extend("hcm.people.profile.Z_PEP_PROFEXT.Component", {

	metadata: {

		version: "1.0",

		"includes": ["css/profile_style.css"],



		config: {

			"sap.ca.serviceConfigs": [



				{



					name: "",



					serviceUrl: "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/",



					isDefault: true,

					mockedDataSource: "./model/metadata.xml"

                }



            ]

		},

		customizing: {

			"sap.ui.viewReplacements": {

				"hcm.people.profile.view.Profile": {

					viewName: "hcm.people.profile.Z_PEP_PROFEXT.view.ProfileCustom",

					type: "XML",
					viewId: "idProfileCustom"

				},

				"hcm.people.profile.blocks.PersInfo": {

					viewName: "hcm.people.profile.Z_PEP_PROFEXT.blocks.PersInfoCustom",

					type: "XML"

				},

				"hcm.people.profile.blocks.QualificationsCollapsed": {

					viewName: "hcm.people.profile.Z_PEP_PROFEXT.blocks.QualificationsCollapsedCustom",

					type: "XML"

				},

				"hcm.people.profile.blocks.QualificationsExpanded": {

					viewName: "hcm.people.profile.Z_PEP_PROFEXT.blocks.QualificationsExpandedCustom",

					type: "XML"

				}

			},

			"sap.ui.controllerExtensions": {

				"hcm.people.profile.view.Profile": {

					controllerName: "hcm.people.profile.Z_PEP_PROFEXT.view.ProfileCustom"

				},

				"hcm.people.profile.blocks.PersInfoController": {

					controllerName: "hcm.people.profile.Z_PEP_PROFEXT.blocks.PersInfoControllerCustom"

				},

				"hcm.people.profile.blocks.QualificationsCollapsedController": {

					controllerName: "hcm.people.profile.Z_PEP_PROFEXT.blocks.QualificationsCollapsedControllerCustom"

				},

				"hcm.people.profile.blocks.QualificationsExpandedController": {

					controllerName: "hcm.people.profile.Z_PEP_PROFEXT.blocks.QualificationsExpandedControllerCustom"

				}

			}

		}

	},
	
	init : function () {
	
    
	    
	}

});