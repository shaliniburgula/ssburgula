/*

 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved

 */
var fileCollection = new Array();
var p;
this.approverName = "";
this.approverID = "";
var roleBandTxt = "";
var subArea = "";
var persArea = "";
var hrFACID = "";
jQuery.sap.require("sap.ui.commons.RichTooltip");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");

jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

jQuery.sap.require("hcm.people.profile.util.UIHelper");

jQuery.sap.require("hcm.people.profile.blocks.Notifications");

jQuery.sap.require("hcm.people.profile.blocks.TimeRecording");

jQuery.sap.require("hcm.people.profile.blocks.Vacations");

jQuery.sap.require("hcm.people.profile.blocks.Cources");

jQuery.sap.require("hcm.people.profile.blocks.Qualifications");

jQuery.sap.require("hcm.people.profile.blocks.Performance");

jQuery.sap.require("hcm.people.profile.blocks.Progression");

jQuery.sap.require("hcm.people.profile.blocks.Payslip");

jQuery.sap.require("hcm.people.profile.blocks.Salary");

jQuery.sap.require("hcm.people.profile.blocks.Notes");

jQuery.sap.require("hcm.people.profile.Z_PEP_PROFEXT.blocks.NotetoHR");

jQuery.sap.require("hcm.people.profile.blocks.PersInfo");

jQuery.sap.require("hcm.people.profile.util.ConcurrentEmployment");
jQuery.sap.require("hcm.people.profile.util.UIHelper");

jQuery.sap.require("hcm.people.profile.blocks.TimeBalance");
jQuery.sap.require("sap.m.MessageBox");

sap.ui.controller("hcm.people.profile.Z_PEP_PROFEXT.view.ProfileCustom", {

	onInit: function() {
	    var that = this;
	      $(document).on("click", ".messageGood", function(){
	         
	          that.openQuickView();
         
    }); 
		var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		sap.ui.getCore().setModel(oModel);

		//		this.oDataModel = this.oApplicationFacade.getODataModel();

		//		hcm.people.profile.util.UIHelper.setODataModel(this.oDataModel);

		//		this.notifODataModel = this.oApplicationFacade.getODataModel("NOTIFICATIONSTORE");

		//		hcm.people.profile.util.UIHelper.setNotifODataModel(this.notifODataModel);

		//		hcm.people.profile.util.UIHelper.setControllerInstance(this);

		//		this.resourseBundle = this.oApplicationFacade.getResourceBundle();

		//		hcm.people.profile.util.UIHelper.setResourceBundle(this.resourseBundle);

		//		this.oApplication = this.oApplicationFacade.oApplicationImplementation;

		//		this.ctrlObjectPageLayout = this.byId("ctrlObjectPageLayout");

		//		this.ctrlObjHeaderEmp = this.byId("ctlrObjHeaderEmp");

		//		this.pernr = null;

		//		this.extHookSections = null;

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		
		
		var BGJson = new sap.ui.model.json.JSONModel();

		var bloodGrpSet = "SHBloodGroupSet";

		oDataModel.read(bloodGrpSet, null, null, false, function(r) {

			BGJson.setData(r);

		});

		sap.ui.getCore().setModel(BGJson, "BGModel");

		var RHJson = new sap.ui.model.json.JSONModel();

		var RHfactorSet = "SHRHFactorSet";

		oDataModel.read(RHfactorSet, null, null, false, function(r) {

			RHJson.setData(r);

		});

		sap.ui.getCore().setModel(RHJson, "RHModel");

	},

	//	initializeView: function() {

	//		var t = this;

	//		var c = $.when(this.getEmployeeDataSet(), this.getConfigurationSet());

	//		c.done(function(o, a) {

	//			t.buildHeaderUI(o);

	//			t.(a);

	//		});

	//		c.fail(function(e) {

	//			jQuery.sap.log.getLogger().error("Data fetch failed" + e.toString());

	//		});

	//		var i = this.byId("ctrlHeaderImage").getId();

	//		$("#" + i).css("border-radius", "100%");

	//	},

	//	onBeforeRendering: function() {},

	//	getEmployeeDataSet: function() {

	//		var d = $.Deferred();

	//		this.oDataModel.read("EmployeeDataSet('" + this.oApplication.pernr + "')", null, null, true, function(r) {

	//			d.resolve(r);

	//		}, function(r) {

	//			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());

	//			d.reject("Data fetch failed" + r.toString());

	//		});

	//		return d.promise();

	//	},

	//	getConfigurationSet: function() {

	//		var d = $.Deferred();

	//		this.oDataModel.read("ConfigurationSet('" + this.oApplication.pernr + "')", null, null, true, function(r) {

	//			d.resolve(r);

	//		}, function(r) {

	//			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());

	//			d.reject("Data fetch failed" + r.toString());

	//		});

	//		return d.promise();

	//	},

	buildHeaderUI: function(o) {

            	var modelJson = new sap.ui.model.json.JSONModel();
			var model = {
				results: [
					{
						"Name": "Personal Data",
						"percent": ""
					},
					{
							"Name": "Address Details",
						"percent": ""
					},
					{
							"Name": "Communication",
						"percent": ""
					},
					{
					   	"Name": "Family Members Details",
						"percent": ""
					},
					{
					    	"Name": "Education Details",
						"percent": ""
					},
					
					{
					    	"Name": "Previous Employment Details",
						"percent": ""
					},
					
					{
					    	"Name": "Skills/Competency",
						"percent": ""
					},
					
					{
					    	"Name": "Aadhar ID, Passport No and Photo",
						"percent": ""
					}
                        ]
			};
			modelJson.setData(model);
			sap.ui.getCore().setModel(modelJson, "appModel");

		var t = this;
        var percentCompletion = new Array();
		t.pernr = o.Employeenumber;

		hcm.people.profile.util.UIHelper.setPernr(t.pernr);
		
		var prgBarJson = new sap.ui.model.json.JSONModel();

		var perPrgBarSet = "EmployeeDataSet('" +  t.pernr + "')/PersonalInfoSet";

		this.oDataModel.read(perPrgBarSet, null, null, false, function(r) {

			prgBarJson.setData(r);

		});
		
			var dat = prgBarJson.getData().results;
				var PrevGrpName = "";
				var prevSubGrpName ="";
				var PrevLabelName = "";
				var addressPercent = 0;
				var commPercent = 0;
		for (var i =0; i<dat.length;i++){
		    if(dat[i].Groupname ==="Personal Data" || dat[i].Groupname ==="Personal data"  ){
		    if(dat[i].Groupname !== PrevGrpName){
		        
		            percentCompletion.push(dat[i].PercentCompletion);
		            PrevGrpName = dat[i].Groupname;
		            	modelJson.oData.results[0].percent = dat[i].PercentCompletion;
		    }
		   }
		   else if(dat[i].Groupname ==="Addresses"){
		    if(dat[i].SubGroupname !== prevSubGrpName){
		        
		            percentCompletion.push(dat[i].PercentCompletion);
		            prevSubGrpName = dat[i].SubGroupname;
		            addressPercent = parseInt(addressPercent) + parseInt(dat[i].PercentCompletion);
		            	modelJson.oData.results[1].percent = addressPercent;
		    }
		   }
		   else if(dat[i].Groupname ==="Communication"){
		    if(dat[i].Fieldlabel !== PrevLabelName){
		        
		            percentCompletion.push(dat[i].PercentCompletion);
		            PrevLabelName = dat[i].Fieldlabel;
		              commPercent = parseInt(commPercent) + parseInt(dat[i].PercentCompletion);
		            	modelJson.oData.results[2].percent = commPercent;
		    }
		   }
		    else if(dat[i].Groupname ==="Family Member Details"){
		    if(dat[i].Groupname !== PrevGrpName){
		        
		            percentCompletion.push(dat[i].PercentCompletion);
		            PrevGrpName = dat[i].Groupname;
		            	modelJson.oData.results[3].percent = dat[i].PercentCompletion;
		    }
		   }else if(dat[i].Groupname ==="Education Details"){
		    if(dat[i].Groupname !== PrevGrpName){
		        
		            percentCompletion.push(dat[i].PercentCompletion);
		            PrevGrpName = dat[i].Groupname;
		            	modelJson.oData.results[4].percent = dat[i].PercentCompletion;
		    }
		   }else if(dat[i].Groupname ==="Previous Employment Details"){
		    if(dat[i].Groupname !== PrevGrpName){
		        
		            percentCompletion.push(dat[i].PercentCompletion);
		            PrevGrpName = dat[i].Groupname;
		            	modelJson.oData.results[5].percent = dat[i].PercentCompletion;
		    }
		   }
		}
		//percentCompletion.push(dat[0].PercentCompletion);
		
	    var prgBarQuaJson = new sap.ui.model.json.JSONModel();

		var quaPrgBarSet = "EmployeeDataSet('" +  t.pernr + "')/QualificationSet";

		this.oDataModel.read(quaPrgBarSet, null, null, false, function(r) {

			prgBarQuaJson.setData(r);

		});
		
			var datQua = prgBarQuaJson.getData().results;
		if(prgBarQuaJson.getData().results.length!==0){
		percentCompletion.push(datQua[0].PercentCompletion);
			modelJson.oData.results[6].percent = datQua[0].PercentCompletion;
		}
		else{
		    	modelJson.oData.results[6].percent = 0;
		}
      
        var perData = o.PercentCompletion; 
        percentCompletion.push(perData);
        console.log(percentCompletion);
        	modelJson.oData.results[7].percent = perData;
        var prgValue = 0;
        for(var k = 0 ; k < percentCompletion.length;k++){
            prgValue = prgValue+parseInt(percentCompletion[k]);
        }
        var percentValue = prgValue +"%";
        t.byId("idProgInd").setPercentValue(prgValue);
        t.byId("idProgInd").setDisplayValue(percentValue);
        var sHtml ="";
        	var oBtn = this.byId("idProgInd");
			
			if(modelJson.oData.results[0].percent !== "10"){ //personal data
			sHtml = modelJson.oData.results[0].Name +" - "+ modelJson.oData.results[0].percent +"/10 <br>";
			}
			if(modelJson.oData.results[1].percent !== 15){ //address        
			 sHtml += modelJson.oData.results[1].Name +" - "+ modelJson.oData.results[1].percent +"/15 <br>";
			}
			if(modelJson.oData.results[2].percent !== 20){ //comm
            sHtml += modelJson.oData.results[2].Name +" - "+ modelJson.oData.results[2].percent +"/20 <br>";
			}
			if(modelJson.oData.results[3].percent !== "10"){ //family
            sHtml += modelJson.oData.results[3].Name +" - "+ modelJson.oData.results[3].percent +"/10 <br>";
			}
			if(modelJson.oData.results[4].percent !== "10"){ //edu
            sHtml += modelJson.oData.results[4].Name +" - "+ modelJson.oData.results[4].percent +"/10 <br>";
			}
			if(modelJson.oData.results[5].percent !== "10") //employment
            {
                sHtml += modelJson.oData.results[5].Name +" - "+ modelJson.oData.results[5].percent +"/10 <br>";
            }
            if(modelJson.oData.results[6].percent !== "10"){ //skills
            sHtml += modelJson.oData.results[6].Name +" - "+ modelJson.oData.results[6].percent +"/10 <br>";
            }
            if(modelJson.oData.results[7].percent !== "15"){ //ids & photo
            sHtml += modelJson.oData.results[7].Name +"- "+ modelJson.oData.results[7].percent +"/15 <br>";
            }
			var oRichTooltip = new sap.ui.commons.RichTooltip({
				text: sHtml,
				title: "Pending Profile "
			});
			oRichTooltip.setAtPosition("end top");
			oBtn.setTooltip(oRichTooltip);
			
			
			
		var i = this.oDataModel.sServiceUrl + "/EmployeeDataSet('" + t.pernr + "')/$value";

		var c = t.byId("ctrlHeaderImage");
        parentId = t.byId("ctrlObjectPageLayout").getParent().getParent().sId;
        console.log(parentId);
        
        	if(modelJson.oData.results[0].percent === "10" && modelJson.oData.results[6].percent === "10"){
        	  	    	sap.ui.getCore().byId(parentId+"--msgGood").close();
        	}
        
		t.ctrlObjHeaderEmp.setObjectImageURI(i);

		c.setSrc(i);

		c.addStyleClass("sapHcmObjectHeaderImage");

		if (sap.ui.Device.system.desktop) {

			c.setWidth("10rem");

			c.setHeight("10rem");

		} else if (sap.ui.Device.system.tablet) {

			c.setWidth("8rem");

			c.setHeight("8rem");

		} else if (sap.ui.Device.system.phone) {

			c.setWidth("6rem");

			c.setHeight("6rem");

		} else {

			c.setWidth("10rem");

			c.setHeight("10rem");

		}

		t.ctrlObjHeaderEmp.setObjectTitle(o.Ename);

		t.ctrlObjHeaderEmp.setObjectSubtitle(o.PositionTxt);
        
		if (o.Ename) {

			t.byId("lblName").setTitle(o.Ename);

			t.byId("lblName").addStyleClass("sapHcmHeaderTitle");

		} else {

			t.byId("lblName").setVisible(false);

		} if (o.Employeenumber) {

			t.byId("lblEmpNo").setText(o.Employeenumber);

		} else {

			t.byId("lblEmpNo").setVisible(false);

		} if (o.PositionTxt) {

			var position = "Designation : " + o.PositionTxt;

			t.byId("lblPosition").setText(position);

		} else {

			t.byId("lblPosition").setVisible(false);

		} if (o.OrgunitTxt) {

			var orgUnit = "Department  : " + o.OrgunitTxt;

			t.byId("lblOrgUnit").setText(orgUnit);

		} else {

			t.byId("lblOrgUnit").setVisible(false);

		}
		/*if (o.BldingNo.trim() === "" && o.RoomNo.trim() === "") {

			t.byId("lblLocation").setVisible(false);

		} else {

			var s = null;

			if (o.BldingNo.trim() !== "" && o.RoomNo.trim() !== "") {

				s = ", ";

			} else {

				s = "";

			}

			var roomNo = "Room/BuildingNo : "+ o.RoomNo + s + o.BldingNo;

			t.byId("lblLocation").setText(roomNo);

		} */
		/*if (o.Phone) {

			var a = o.Phone;

			a = o.Phone.replace("/", "-");

			var phone = "Phone : "+a;

			t.byId("lblPhone").setText(phone);

			t.empPhone = o.Phone;

		} else {

			t.byId("lblPhone").setVisible(false);

		} */
		if (o.Email) {

			var email = "Email : " + o.Email;

			t.byId("lblEmail").setText(email);

			t.empEmail = o.Email;

		} else {

			t.byId("lblEmail").setVisible(false);

		}
		/* if (o.City.trim() === "" && o.Country.trim() === "") {

			t.byId("lblCountryLocation").setVisible(false);

		} else {

			var b = null;

			if (o.City.trim() !== "" && o.Country.trim() !== "") {

				b = ", ";

			} else {

				b = "";

			}

			var country = "City/Country : "+o.City + b + o.Country;

			t.byId("lblCountryLocation").setText(country);

		} if (o.Localtime) {

			var d = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({

				pattern: "EEEE, d MMMM, h:mm a",

				style: "medium"

			});

			var time = "Time : "+ o.Localtime;

			t.byId("lblTime").setText(d.format(time));

		} else {

			t.byId("lblTime").setVisible(false);

		}*/

		//extended 

		if (o.EmployeeSubgroupTxt) {
	        roleBandTxt  = o.EmployeeSubgroupTxt;

			var roleBand = "Role Band   : " + o.EmployeeSubgroupTxt;

			t.byId("lblsubGroup").setText(roleBand);

		} else {

			t.byId("lblsubGroup").setVisible(false);

		}

		if (o.PersonnelAreaTxt) {
		    persArea = o.PersonnelAreaTxt;

			var unit = "Unit        : " + o.PersonnelAreaTxt;

			t.byId("lblPerArea").setText(unit);

		} else {

			t.byId("lblPerArea").setVisible(false);

		}

		if (o.PersonnelSubareaTxt) {
            subArea = o.PersonnelSubareaTxt;
			var location = "Location    : " + o.PersonnelSubareaTxt;

			t.byId("lblPerSubArea").setText(location);

		} else {

			t.byId("lblPerSubArea").setVisible(false);

		}

		if (o.BloodGroup) {

			var bloodGrp = "Blood Group : " + o.BloodGroup;

			t.byId("lblBloodGroup").setText(bloodGrp);

		} else {

			var bloodGrp = "Blood Group : No Data";

			t.byId("lblBloodGroup").setText(bloodGrp);

		}

		if (o.PassportID) {

			var passport = "Passport No : " + o.PassportID;

			t.byId("lblPassportID").setText(passport);

		} else {

			var passport = "Passport No : No Data";

			t.byId("lblPassportID").setText(passport);

		}

		if (o.AadharID) {

			var aadhar = "Aadhar ID  : " + o.AadharID;

			t.byId("lblAadharId").setText(aadhar);

		} else {

			var aadhar = "Aadhar ID : No Data";

			t.byId("lblAadharId").setText(aadhar);

		}

		if (o.PANNo) {

			var panNo = "PAN No      : " + o.PANNo;

			t.byId("lblPanCard").setText(panNo);

		} else {

			var panNo = "PAN No      : No Data";
			t.byId("lblPanCard").setText(panNo);

		}

		if (o.L1Name) {

			var l1Name = "L+1 Name     : " + o.L1Name;

			t.byId("lblL1Name").setText(l1Name);

		} else {

			var l1Name = "L+1 Name     :No Data";

			t.byId("lblL1Name").setText(l1Name);

		}

		if (o.L1PositionTxt) {

			var l1Design = "L+1 Designation     : " + o.L1PositionTxt;

			t.byId("lblL1Design").setText(l1Design);

		} else {

			var l1Design = "L+1 Designation     :No Data";

			t.byId("lblL1Design").setText(l1Design);

		}

		if (o.L2Name) {

			var l2Name = "L+2 Name     : " + o.L2Name;

			t.byId("lblL2Name").setText(l2Name);

		} else {

			var l2Name = "L+2 Name     :No Data";

			t.byId("lblL2Name").setText(l2Name);

		}

		if (o.L2PositionTxt) {

			var l2Design = "L+2 Designation     : " + o.L2PositionTxt;

			t.byId("lblL2Design").setText(l2Design);

		} else {

			var l2Design = "L+2 Designation     :No Data";

			t.byId("lblL2Design").setText(l2Design);

		}

		if (o.HRFACName) {

			var hrFac = "HR FAC Name     : " + o.HRFACName;

			t.byId("lblhrfacName").setText(hrFac);

		} else {

			var hrFac = "HR FAC Name     :No Data";

			t.byId("lblhrfacName").setText(hrFac);

		}

		if (o.HRFACID) {
            hrFACID = o.HRFACID;
            console.log(hrFACID);
		}
		/*else {

			t.byId("lblhrfacID").setText(o.HRFACID);
           t.byId("lblhrfacID").setVisible(false);
		}*/
        /*	var oBtn = t.byId("idattach");
			var sHtml = "Add/Update Aadhar ID <br>";
			 sHtml += "Add/Update Passport No <br>";
            sHtml += "Update Permanent Address <br>";
            sHtml += "Add/Update Local/Temporary Address <br>";
            sHtml += "Add Education details ";
			var oRichTooltip = new sap.ui.commons.RichTooltip({
				text: sHtml,
				title: "Documents are required for"
			});
			oRichTooltip.setAtPosition("end top");
			oBtn.setTooltip(oRichTooltip);*/
	},

	//	onEmailClick: function(e) {

	//		sap.m.URLHelper.triggerEmail(this.empEmail);

	//	},

	//	onPhoneClick: function(e) {

	//		sap.m.URLHelper.triggerTel(this.empPhone);

	//	},

	//	onBackPress: function(e) {

	//		window.history.go(-1);

	//	},

	//	onHierarchyPress: function() {

	//		var p = hcm.people.profile.util.UIHelper.getCachedPersData();

	//		p.crossAppNavFlag = true;

	//		this.oPersonalizer.setPersData(p);

	//		hcm.people.profile.util.UIHelper.cachePersData(p);

	//		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({

	//			target: {

	//				shellHash: "#Organization-lookup&/hierarchy/" + this.pernr

	//			}

	//		});

	//	},

	buildByConfiguration: function(c) {

		var t = this;

		hcm.people.profile.util.UIHelper.setConfiguration(c);

		if (c.ShowNotifications === "X" || c.ShowTimerecording === "X" || c.ShowVacation === "X") {

			var s = new sap.uxap.ObjectPageSection({

				title: t.resourseBundle.getText("WHATS_NEW"),

				visible: false

			});

			if (c.ShowNotifications === "X") {

				var S = new sap.uxap.ObjectPageSubSection({

					title: t.resourseBundle.getText("NOTIFICATIONS")

				});

				S.insertBlock(new hcm.people.profile.blocks.Notifications());

				hcm.people.profile.util.UIHelper.setSubSecNotf(S);

				s.addSubSection(S);

			}

			if (c.ShowTimerecording === "X" || c.ShowVacation === "X" || c.ShowTimeBalance === "X") {

				var o = new sap.uxap.ObjectPageSubSection({

					title: t.resourseBundle.getText("TIMESHEET_ABSCENCES")

				});

				if (c.ShowTimerecording === "X") {

					o.insertBlock(new hcm.people.profile.blocks.TimeRecording(), 0);

				}

				if (c.ShowVacation === "X") {

					o.insertBlock(new hcm.people.profile.blocks.Vacations(), 1);

				}

				if (c.ShowTimeBalance === "X") {

					o.insertBlock(new hcm.people.profile.blocks.TimeBalance(), 2);

				}

				s.addSubSection(o);

			}

			t.ctrlObjectPageLayout.addSection(s);

		}

		if (c.ShowSocialMediaInfo === "X") {

			t.oDataModel.read("EmployeeDataSet('" + t.pernr + "')/SocialMediaSet", null, null, true, function(r) {

				var n = t.byId("ctrlSocialMediaHolder");

				r.results.forEach(function(p) {

					n.addContent(new sap.m.Image({

						width: "21px",

						height: "21px",

						src: p.ImageUrl

					}));

				});

			}, function(r) {

				jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());

			});

		}

		if (c.ShowCompensation === "X") {

			var g = new sap.uxap.ObjectPageSection({

				title: t.resourseBundle.getText("COMPENSATION"),

				visible: false

			});

			var h = new sap.uxap.ObjectPageSubSection({

				title: t.resourseBundle.getText("PAYSLIP")

			});

			hcm.people.profile.util.UIHelper.setSubSecPayslip(h);

			h.insertBlock(new hcm.people.profile.blocks.Payslip());

			g.addSubSection(h);

			var i = new sap.uxap.ObjectPageSubSection({

				title: t.resourseBundle.getText("SALARY_BONUS")

			});

			i.insertBlock(new hcm.people.profile.blocks.Salary());

			g.addSubSection(i);

			t.ctrlObjectPageLayout.addSection(g);

		}

		if (c.ShowNotes === "X") {

			var j = new sap.uxap.ObjectPageSection({

				title: t.resourseBundle.getText("NOTES"),
				visible: false
			});

			var k = new sap.uxap.ObjectPageSubSection({

				title: t.resourseBundle.getText("MY_PERSONAL_NOTES")

			});

			k.insertBlock(new hcm.people.profile.blocks.Notes());

			j.addSubSection(k);

			t.ctrlObjectPageLayout.addSection(j);

		}

		if (c.ShowPersonalinfo === "X") {

			var l = new sap.uxap.ObjectPageSection({

				title: "PERSONAL INFORMATION"

			});

			hcm.people.profile.util.UIHelper.setSecPersInfo(l);

			var m = new sap.uxap.ObjectPageSubSection({

				id: "subSecPersInfo",

				title: ""

			});

			hcm.people.profile.util.UIHelper.setSubSecPersInfo(m);

			m.insertBlock(new hcm.people.profile.blocks.PersInfo());

			l.addSubSection(m);

			t.ctrlObjectPageLayout.addSection(l);

		}

		if (c.ShowCourse === "X" || c.ShowQualification === "X" || c.ShowPerformance === "X" || c.ShowProgression === "X") {

			var a = new sap.uxap.ObjectPageSection({

				title: "SKILLS/COMPETENCY"

			});

			/*if (c.ShowCourse === "X") {

				var b = new sap.uxap.ObjectPageSubSection({

					title: t.resourseBundle.getText("UPCOMING_COURSES"),

					mode: "Collapsed",

					showSubSectionMore: true

				});

				hcm.people.profile.util.UIHelper.setSubSecCourses(b);

				b.insertBlock(new hcm.people.profile.blocks.Cources());

				a.addSubSection(b);

			}*/

			if (c.ShowQualification === "X") {

				var d = new sap.uxap.ObjectPageSubSection({

					title: "SKILLS/COMPETENCY",

					mode: "Collapsed"

				});

				hcm.people.profile.util.UIHelper.setSubSecQualif(d);

				d.insertBlock(new hcm.people.profile.blocks.Qualifications());

				a.addSubSection(d);

			}

			/*if (c.ShowPerformance === "X") {

				var e = new sap.uxap.ObjectPageSubSection({

					title: t.resourseBundle.getText("PERFORMANCE")

				});

				e.insertBlock(new hcm.people.profile.blocks.Performance());

				hcm.people.profile.util.UIHelper.setSubSecPerf(e);

				a.addSubSection(e);

			}

			if (c.ShowProgression === "X") {

				var f = new sap.uxap.ObjectPageSubSection({

					title: t.resourseBundle.getText("PROGRESSION")

				});

				f.insertBlock(new hcm.people.profile.blocks.Progression());

				a.addSubSection(f);

			}*/

			t.ctrlObjectPageLayout.addSection(a);

		}

		if (c.ShowCourse === "X" || c.ShowQualification === "X" || c.ShowPerformance === "X" || c.ShowProgression === "X") {

			var a = new sap.uxap.ObjectPageSection({

				title: "NOTE TO HR"

			});

			if (c.ShowQualification === "X") {

				var d = new sap.uxap.ObjectPageSubSection({

					title: "NOTE TO HR",

					mode: "Collapsed"

				});

				hcm.people.profile.util.UIHelper.setSubSecQualif(d);

				d.insertBlock(new hcm.people.profile.Z_PEP_PROFEXT.blocks.NotetoHR());

				a.addSubSection(d);

			}

			t.ctrlObjectPageLayout.addSection(a);

		}

		var editIdsInfo = "X";
/*
		if (editIdsInfo === "X") {

			var page = new sap.uxap.ObjectPageSection({

				title: ""

			});

			var section = new sap.uxap.ObjectPageSubSection({

				title: "",

				blocks: [

					new sap.m.Text({

						text: ""

					})

				]

			});

			page.addSubSection(section);

			t.ctrlObjectPageLayout.addSection(page);

		}
*/
		if (t.extHookSections) {

			t.ctrlObjectPageLayout = this.extHookSections(t.ctrlObjectPageLayout);

		}

	},
	/*,

	onAfterRendering: function() {

		this.createPersonalizationObj();

		this.getPersonalizationData(this.oPersId);

	},

	getPersonalizationData: function(i) {

		this.oPersonalizer.getPersData().done(this.userPersData.bind(this)).fail(function() {

			jQuery.sap.log.error("Reading personalization data failed.");

		});

	},

	userPersData: function(p) {

		if (p === undefined || p.crossAppNavFlag === false) {

			if (!this.oApplication.pernr) {

				hcm.people.profile.util.ConcurrentEmployment.getCEEnablement(this, jQuery.proxy(function() {

					var d = {

						selectedCEPernr: this.oApplication.pernr,

						crossAppNavFlag: false

					};

					this.oPersonalizer.setPersData(d);

					hcm.people.profile.util.UIHelper.cachePersData(d);

					this.initializeView();

				}, this));

			}

		} else {

			try {

				p.crossAppNavFlag = false;

				this.oPersonalizer.setPersData(p);

				hcm.people.profile.util.UIHelper.cachePersData(p);

			} catch (e) {}

			this.oApplication.pernr = p.selectedCEPernr;

			this.initializeView();

		}

	},

	onExit: function() {},

	createPersonalizationObj: function() {

	//	if (sap.ushell !== undefined && sap.ushell.Container !== undefined) {

		//	var p = sap.ushell.Container.getService("Personalization");

		//	var c = p.constants;

		//	console.log(c);

			var C = sap.ui.core.Component.getOwnerComponentFor(this.getView());

			var s = {

				keyCategory: c.keyCategory.FIXED_KEY,

				writeFrequency: c.writeFrequency.LOW,

				clientStorageAllowed: true,

				validity: Infinity

			};

			this.oPersId = {

				container: "hcm.people.profile",

				item: "appPersSettings"

			};

		//	this.oPersonalizer = p.getPersonalizer(this.oPersId, s, C);

			hcm.people.profile.util.UIHelper.setPersonalizerInstance(this.oPersId);

		//}

	//}*/

	editHRFAC: function() {

		var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

		if (dialog === undefined)

		{

			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.editHRFAC", this.getView().getController());

		}

		dialog.open();

		var labelName = this.byId("lblhrfacName").getText();

		var name = labelName.split(":");

		var approverName = name[1];

		if (approverName === "No Data") {

			sap.ui.getCore().byId("idHRFAC").setVisible(false);
			sap.ui.getCore().byId("idNoHRFAC").setVisible(true);

			sap.ui.getCore().byId("idBtn2").setVisible(false);
			sap.ui.getCore().byId("idBtn1").setVisible(true);

		} else

		{

			sap.ui.getCore().byId("idHRFAC").setVisible(true);
			sap.ui.getCore().byId("idNoHRFAC").setVisible(false);

			sap.ui.getCore().byId("idBtn2").setVisible(true);
			sap.ui.getCore().byId("idBtn1").setVisible(false);

			//	sap.ui.getCore().byId("idHRName").setValue(approverName);

		}

	},
	onOKNote: function() {

		var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

		dialog.close();

	},
	onCloseNote: function() {

		sap.ui.getCore().byId("txtHR").setValue("");
		sap.ui.getCore().byId("subjHR").setValue("");

		var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

		dialog.close();

	},

	SubmitNote: function() {

		var note = sap.ui.getCore().byId("txtHR").getValue();

		var subject = sap.ui.getCore().byId("subjHR").getValue();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		var labelName = this.byId("lblhrfacName").getText();
		var approverID = "P" + this.byId("lblhrfacID").getText();

		var name = labelName.split(":");

		var approverName = name[1];

		var errorBody;

		var createPath = "EmployeeNoteSet";

		var obj = {

			ApproverName: approverName,
			Note: note,
			Subject: subject,
			ApproverID: approverID

		};
		var r = true;
		if (subject === "") {
			sap.ui.getCore().byId("subjHR").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("subjHR").setValueStateText("Enter Subject, Mandatory field");
			r = false;
		} else {
			sap.ui.getCore().byId("subjHR").setValueState(sap.ui.core.ValueState.None);
		}

		if (note === "") {
			sap.ui.getCore().byId("txtHR").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("txtHR").setValueStateText("Enter Details, Mandatory field");
			r = false;
		} else {
			sap.ui.getCore().byId("txtHR").setValueState(sap.ui.core.ValueState.None);
		}

		var result = false;
		if (r) {
		    sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			oDataModel.create(createPath, obj, null, function(responseBody, sucRes) {

				result = true;

			}, function(failRes) {

				result = false;

				errorBody = JSON.parse(failRes.response.body);

			});

			if (result === true) {

				sap.m.MessageBox.success("This has been forwarded to HR FAC");

				sap.ui.getCore().byId("txtHR").setValue("");

				var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

				dialog.close();

			} else {
				sap.m.MessageBox.error("\\n Message: " + errorBody.error.message.value);
			}

		}
	},

	onAppNameSelect: function(e) {

		var dialog = sap.ui.getCore().byId("HRFACSelectDialog");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.HRApprover", this);

			//this.addDependent(dialog);

		}

		dialog.open();

		this.setInitialFilter("ApproverName", e.getSource()._lastValue, dialog);

	},

	onSuggest: function(e) {

		var v = e.getParameter("suggestValue");

		if (v !== undefined) {

			if (e.getSource().sId === "idHRName") {

				title = "ApproverName";

			}

			var oFilter = new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v);

			e.getSource().getBinding("suggestionItems").filter([oFilter]);

			this.filterDialog(title, v, e.getSource().getBinding("suggestionItems").filter([oFilter]));

		}

	},

	onSuggestionItemSelected: function(e) {

		var v = e.getParameter("selectedItem");

		if (v !== undefined) {

			var selectedItem = v.mProperties.text;

			if (e.getSource().sId === "idHRName")

			{

				this.selectedState = selectedItem;

			}

		}

	},

	searchDialog: function(e) {

		var dialog = e.getSource().sId;

		var v = e.getParameter("value");

		var title;

		if (v !== undefined) {

			if (dialog === "HRFACSelectDialog")

			{

				title = "ApproverName";

			}

			var oFilter = new sap.ui.model.Filter(new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v), false);

			e.getSource().getBinding("items").filter([oFilter]);

			this.filterDialog(title, v, e.getSource().getBinding("items").filter([oFilter]));

		}

	},

	filterDialog: function(title, v, i) {

		var f = [];

		var s = new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v);

		f.push(s);

		i.filter(f);

	},

	cancelSelectDialog: function(e) {},

	confirmSelectDialog: function(e) {

		var dialog = e.getSource().sId;

		var s = e.getParameter("selectedItem");

		if (s) {

			if (dialog === "HRFACSelectDialog") {

				var path = s.oBindingContexts.HRFACModel.sPath.split("/");

				sap.ui.getCore().byId("idHRName").setValue(s.getTitle());

				this.approverName = sap.ui.getCore().byId("idHRName").getValue();
				this.approverID = s.getDescription();
			}

		}

	},

	setInitialFilter: function(title, f, s) {

		f = f.split(this.openingBracket)[0];

		s.open(f);

		var i = s.getBinding("items");

		this.filterDialog(title, f, i)

	},
	//photo upload code starts from here

	onUploadPhoto: function() {
		var dialog = sap.ui.getCore().byId("idDialogUploadPhoto");

		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.UploadPhoto", this.getView().getController());
			this.getView().addDependent();
		}
		dialog.open();

	},
	onClosePhoto: function() {
		var dialog = sap.ui.getCore().byId("idDialogUploadPhoto");
		dialog.destroy();
	},

	handleUploadComplete: function(oEvent) {

		var sResponse = oEvent.getParameter("response");

		if (sResponse) {

			var sMsg = "";

			var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);

			if (m[1] == "200") {

				sMsg = "Return Code: " + m[1] + "\n" + m[2], "SUCCESS", "Upload Success";

				oEvent.getSource().setValue("");

			} else {

				sMsg = "Return Code: " + m[1] + "\n" + m[2], "ERROR", "Upload Error";

			}

			sap.m.MessageToast.show(sMsg);

		}

	},
	/*	handleUploadPress1: function(evt) {

		var header_xcsrf_token = "";
		OData.request({
				requestUri: "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/EmployeeDataSet('" + p + "')/$value",
				method: "GET",
				headers: {
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				}
			},
			function(data, response) {
				header_xcsrf_token = data.response.headers['x-csrf-token'];
				console.log(header_xcsrf_token);

			},
			function(data, response) {
				header_xcsrf_token = data.response.headers['x-csrf-token'];
				console.log(header_xcsrf_token);
				var oHeaders = {
					"x-csrf-token": header_xcsrf_token,
					"slug": ""
				};
				jQuery.ajax({
					type: 'PUT',
					url: "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/EmployeeDataSet('" + p + "')/$value",
					headers: oHeaders,
					cache: false,
					contentType: "image/jpeg",
					processData: false,
					data: "",
					success: this._handleSuccess,
					error: this._handleError
				});

			});
		console.log(header_xcsrf_token);

	},*/
	handleUploadPress: function(evt) {
		p = hcm.people.profile.util.UIHelper.getPernr();
		var oUploader = sap.ui.getCore().byId("photoUploader");
		var oFileUploader = sap.ui.getCore().byId("photoUploader");
		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {
			sap.m.MessageBox.alert("Please select photo to upload");
		} else {
			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/png") {

							docType = "SIM";

							contentType = ".png";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename,

							StringUpload: ""

						};
						/*
					var header_xcsrf_token = "";
					OData.request({
							requestUri: "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/EmployeeDataSet('" + p + "')/$value",
							method: "GET",
							headers: {
								"X-Requested-With": "XMLHttpRequest",
								"Content-Type": "application/atom+xml",
								"DataServiceVersion": "2.0",
								"X-CSRF-Token": "Fetch"
							}
						},
						function(data, response) {
							header_xcsrf_token = data.response.headers['x-csrf-token'];

						},
						function(data, response) {
						    
							var dialog = sap.ui.getCore().byId("idDialogUploadPhoto");
							sap.ui.getCore().byId("photoUploader").setValue("");
							dialog.close();
							header_xcsrf_token = data.response.headers['x-csrf-token'];
                            var filedata = fileData.FileContent;
							var oHeaders = {
								"x-csrf-token": header_xcsrf_token,
								"slug": fileData.FileName,
								"Content-Type": "image/jpeg",
								"Accept": "application/json"
							};
							jQuery.ajax({
								type: 'PUT',
								url: "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/EmployeeDataSet('" + p + "')/PhotoUrl",
								headers: oHeaders,
								cache: false,
								contentType: "image/jpeg",
								processData: false,
								data: fileData.FileContent,
								success: function(result) {
								    	sap.m.MessageBox.show("Photo uploaded Successfully.", {
						icon: sap.m.MessageBox.Icon.SUCCESS,
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
								location.reload(true);
							}
						}.bind(that)
					});
								    
								},
								error: function(result) {
            	sap.m.MessageBox.alert("Cannot Upload the Photo.. Some has error occured" );}
							});
						}
					);
*/
						var path = "EmployeeDataSet('" + p + "')";
						var that = this;
						var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
						oDataModel.update(path, {
							PhotoUrl: fileData.FileContent,
							ContentType: fileData.FileContentType
						}, {
							success: function() {
								jQuery.sap.require("sap.m.MessageBox");
								sap.m.MessageBox.show("Photo uploaded successfully.", {
									icon: sap.m.MessageBox.Icon.SUCCESS,

									actions: [sap.m.MessageBox.Action.OK],
									onClose: function(oAction) {
										if (oAction === "OK") {
											var dialog = sap.ui.getCore().byId("idDialogUploadPhoto");
											sap.ui.getCore().byId("photoUploader").setValue("");
											dialog.close();
											// location.reload(true);
										}
									}.bind(that)
								});
							},
							error: function() {
								jQuery.sap.require("sap.m.MessageBox");
								sap.m.MessageBox.alert("Couldnot upload photo .. Some error has occured");

							}
						});

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}
		}

	},
	onCancelPhoto: function() {
		var dialog = sap.ui.getCore().byId("idDialogUploadPhoto");
		sap.ui.getCore().byId("photoUploader").setValue("");
		dialog.close();
	},

	editBloodGroup: function() {
		var dialog = sap.ui.getCore().byId("idDialogEditBG");
		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.BloodGroup", this.getView().getController());

		}
            var BGval = this.getView().byId("lblBloodGroup").getText();
			var splitVal = BGval.split(":");
			var BG = splitVal[1].substring(1,2);
			var BGKey,RHKey;
			var RH = splitVal[1].substring(2,3);
			var results = sap.ui.getCore().getModel("BGModel").getData().results;
			for(var i=0;i<results.length;i++){
				if(results[i].GroupName === BG)
				{
					BGKey = results[i].GroupCode;
				}
			}
			
			var resultsRH = sap.ui.getCore().getModel("RHModel").getData().results;
			for(var i=0;i<resultsRH.length;i++){
				if(resultsRH[i].FactorName === RH)
				{
					RHKey = resultsRH[i].FactorCode;
				}
			}
			sap.ui.getCore().byId("idBGVal").setSelectedKey(BGKey);
			sap.ui.getCore().byId("idRHFactor").setSelectedKey(RHKey);
		dialog.open();
	},
	onCloseBG: function() {
		var dialog = sap.ui.getCore().byId("idDialogEditBG");
		dialog.close();
	},

	SubmitBG: function() {
		var bloodGroup = sap.ui.getCore().byId("idBGVal").getSelectedKey();

		var RHFactor = sap.ui.getCore().byId("idRHFactor").getSelectedKey();

		var employeeNo = this.byId("lblEmpNo").getText();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		var errorBody;

		var createPath = "BloodGroupSet";

		var obj = {

			Employeenumber: employeeNo,
			Subtype: "0001",
			ObjectID: "",
			Group: bloodGroup,
			RHFactor: RHFactor

		};

		var result = false;

		/*	oDataModel.create(createPath, obj, null, function(responseBody, sucRes) {

			result = true;

		}, function(failRes) {

			result = false;

			errorBody = JSON.parse(failRes.response.body);

		});*/
         sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
		batch.push(oDataModel.createBatchOperation(createPath, "POST", obj));
		var dialog = sap.ui.getCore().byId("idDialogEditBG");

		dialog.close();
		/*	if (result === true) {
            var that = this;
            	sap.m.MessageBox.show("BloodGroup updated Successfully.", {
						icon: sap.m.MessageBox.Icon.SUCCESS,
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
							//	location.reload(true);
							}
						}.bind(that)
					});
		
			var dialog = sap.ui.getCore().byId("idDialogEditBG");

			dialog.close();
			
		
		} else {

			sap.m.MessageBox.error("\\n Message: " + errorBody.error.message.value);

		}*/
	},
	editIDs: function(e) {
		var sId = e.getSource().sId;
		var id = sId.split("--");
		var editId = id[1];

		var dialog = sap.ui.getCore().byId("idDialogEditIDs");

		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.EditIDs", this.getView().getController());
			this.getView().addDependent(dialog);
		}
		dialog.open();
		sap.ui.getCore().byId("idReq").setVisible(false);
		if (editId === "idBtnAID") {
			sap.ui.getCore().byId("idDialogEditIDs").setTitle("Edit/Add Aadhar ID");
			sap.ui.getCore().byId("idSelect").setSelectedKey("aadharNo");
			sap.ui.getCore().byId("idSelect").setEnabled(false);
			sap.ui.getCore().byId("idValue").setPlaceholder("Please enter 12 digits valid Aadhar ID");
			if (sap.ui.getCore().byId("idFileTableIds").getVisible()) {
				sap.ui.getCore().byId("idFileTableIds").setVisible(false);
			}

			var oBtn = sap.ui.getCore().byId("idHelp");
			var sHtml = "Upload scanned copies of Aadhar card, donot upload e-aadhar card <br>";
			var oRichTooltip = new sap.ui.commons.RichTooltip({
				text: sHtml,
				title: "Quick Help"
			});
			oRichTooltip.setAtPosition("end top");
			oBtn.setTooltip(oRichTooltip);

		} else {
			sap.ui.getCore().byId("idDialogEditIDs").setTitle("Edit/Add Passport No");
			sap.ui.getCore().byId("idValue").setPlaceholder("Please enter 8 digits valid Passport No");
			sap.ui.getCore().byId("idSelect").setSelectedKey("Passport ID");
			sap.ui.getCore().byId("idSelect").setEnabled(false);
			if (sap.ui.getCore().byId("idFileTableIds").getVisible()) {
				sap.ui.getCore().byId("idFileTableIds").setVisible(false);
			}
			oBtn = sap.ui.getCore().byId("idHelp");
			sHtml = "Upload Passport<br>";
			oRichTooltip = new sap.ui.commons.RichTooltip({
				text: sHtml,
				title: "Quick Help"
			});
			oRichTooltip.setAtPosition("end top");
			oBtn.setTooltip(oRichTooltip);
		}
	},
	setValID: function() {
		sap.ui.getCore().byId("idValue").setValue("");
		sap.ui.getCore().byId("idValue").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("fileUploaderIDs").setValueState(sap.ui.core.ValueState.None);
		fileCollection = new Array();
		this.setFileAttachments(fileCollection);
	},
	onCloseID: function() {
		this.setValID();
		var dialog = sap.ui.getCore().byId("idDialogEditIDs");
		dialog.close();
	},
	SubmitID: function() {
		var selectedVal = sap.ui.getCore().byId("idSelect").getSelectedItem().getText();
		var idValue = sap.ui.getCore().byId("idValue").getValue();
		var subtype;
		if (selectedVal === "Aadhar No") {
			subtype = "06";
		} else {
			subtype = "04"
		}

		var nameObj = {
			Employeenumber: p,
			IDNumber: idValue,
			Subtype: subtype,
			ObjectID: ""
		};
		var path = "IdentificationSet";
		var r = true;
		var aaID_regExp = /^[0-9]+$/;
		if (selectedVal === "Aadhar No") {
			var size = idValue.length;
			if ((size !== 12) || (!idValue.match(aaID_regExp))) {
				//sap.m.MessageBox.error("Please provide valid Aadhar ID of Length 12");
				sap.ui.getCore().byId("idReq").setVisible(true);
			//	sap.ui.getCore().byId("idReq").setText("Please enter 12 digits valid Aadhar ID");
				sap.ui.getCore().byId("idValue").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idValue").setValueStateText("Please enter 12 digits valid Aadhar ID ");
				r = false;
			} else { //  sap.ui.getCore().byId("idReq").setVisible(false);
				sap.ui.getCore().byId("idValue").setValueState(sap.ui.core.ValueState.None);

			}
		}
		if (selectedVal === "Passport ID") {
			var psize = idValue.length;
			if (psize !== 8) {
				//sap.m.MessageBox.error("Please provide valid Passport No of Length 8 ");
				sap.ui.getCore().byId("idReq").setVisible(true);
				//sap.ui.getCore().byId("idReq").setText("Please enter 8 digits valid Aadhar ID");
				sap.ui.getCore().byId("idValue").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idValue").setValueStateText("Enter enter 8 digits valid Passport No ");
				r = false;
			} else {
				//sap.ui.getCore().byId("idReq").setVisible(false);
				sap.ui.getCore().byId("idValue").setValueState(sap.ui.core.ValueState.None);

			}
		}
		if (this.getFileAttachments() === undefined || this.getFileAttachments() === null || this.getFileAttachments().length === 0) {
			//sap.m.MessageBox.error("Attachment is Mandatory");
			//	 sap.ui.getCore().byId("idReq").setVisible(true);
			sap.ui.getCore().byId("fileUploaderIDs").setValueState(sap.ui.core.ValueState.Error);
		//	sap.ui.getCore().byId("fileUploaderIDs").setValueStateText("Upload File");
			r = false;
		} else {
			//   sap.ui.getCore().byId("idReq").setVisible(false);
			sap.ui.getCore().byId("fileUploaderIDs").setValueState(sap.ui.core.ValueState.None);
		}

		var resultId = false;
		if (r) {
		     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
			var errorBodyId;
			/*	oDataModel.create(path, nameObj, null, function(responseBody, sucRes) {
				resultId = true;
			}, function(failRes) {
				resultId = false;
				errorBodyId = JSON.parse(failRes.response.body);

			});*/

			batch.push(oDataModel.createBatchOperation(path, "POST", nameObj));

			var attchCreate = "AttachmentCreateSet";
			var oFiles = [];
			var attchObj = {};

			if (this.getFileAttachments() === undefined || this.getFileAttachments() === null) {

			} else {

				var fileData = this.getFileAttachments();

				if (fileData !== null) {

					attchObj = fileData[0];
				}
			}
			batch.push(oDataModel.createBatchOperation(attchCreate, "POST", attchObj));

			/*	oDataModel.create(attchCreate, attchObj, null, function(responseBody, sucRes) {

					resultId = true;

				}, function(failRes) {
					resultId = false;
					errorBodyId = JSON.parse(failRes.response.body);
				});
			*/
			var that = this;
			this.setValID();
			var dialog = sap.ui.getCore().byId("idDialogEditIDs");
			dialog.close();
			/*if (resultId === true) {
				this.setValID();
				var dialog = sap.ui.getCore().byId("idDialogEditIDs");
				dialog.close();
				sap.m.MessageBox.show("ID sent for HR approval.", {
					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						if (oAction == "OK") {
						//	location.reload(true);
						}
					}.bind(that)
				});
			} else {
				sap.m.MessageBox.error("\\n Message: " + errorBodyId.error.message.value);
			}
            */
		} else {
			sap.ui.getCore().byId("idReq").setVisible(true);
		}
	},

	handleUploadPressIds: function(evt) {
		var selectedVal = sap.ui.getCore().byId("idSelect").getSelectedItem().getText();

		var subtype;
		if (selectedVal === "Aadhar No") {
			subtype = "06";
		} else {
			subtype = "04"
		}
		fileCollection = new Array();

		var myjsonEmp = new sap.ui.model.json.JSONModel();

		var mydataEmp = {

			"myFiles": []

		};

		myjsonEmp.setData(mydataEmp);

		sap.ui.getCore().setModel("FileModel", myjsonEmp);

		sap.ui.getCore().byId("idFileTableIds").setModel(myjsonEmp);

		sap.ui.getCore().byId("idFileTableIds").setVisible(true);

		var oTable = sap.ui.getCore().byId("idFileTableIds");

		var colItems = new sap.m.ColumnListItem({

			type: "Active"

		});

		oTable.bindAggregation("items", "/myFiles", colItems);

		var txtNAME = new sap.m.Text({

			text: "{fileName}"

		});

		colItems.addCell(txtNAME);
		var that1 = this;
		var button = new sap.m.Button({

			icon: "sap-icon://delete",

			press: function(e) {

				var selectedRow = parseInt(e.getSource().getId().split("idFileTableIds-")[1]);

				var items = sap.ui.getCore().byId("idFileTableIds").getItems();

				items[selectedRow].getAggregation("cells")[2].setValue("D");

				var assFileListEmp = {};

				var assFileEmp = [];

				assFileListEmp["myFiles"] = assFileEmp;

				var myAssFileModelEmp = new sap.ui.model.json.JSONModel();

				myAssFileModelEmp.setData(assFileListEmp);

				var myNewModelData = myAssFileModelEmp.oData.myFiles;

				items = sap.ui.getCore().byId("idFileTableIds").getItems();

				for (var i = 0; i < items.length; i++) {

					var inputValue = items[i].getAggregation("cells")[0].getText();

					var delFlag = items[i].getAggregation("cells")[2].getValue();

					var taskData = {};

					if (delFlag === "I") {

						taskData.fileName = inputValue;

						taskData.Updkz = delFlag;

						myNewModelData.push(taskData);

					}

				}

				sap.ui.getCore().byId("idFileTableIds").setModel(myAssFileModelEmp);

				var newfileCollection = new Array();

				/*for (var i = 0; i < myNewModelData.length; i++) {

					for (var j = 0; j < fileCollection.length; j++) {

						if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {

							var fileData = {

								Employeenumber: fileCollection[j].Employeenumber,
								Subtype: fileCollection[j].Subtype,
								Infotype: fileCollection[j].Infotype,
								FileContent: fileCollection[j].FileContent,
								FileContentType: fileCollection[j].FileContentType,
								FileLength: fileCollection[j].FileLength,
								FileName: fileCollection[j].FileName,
								StringUpload: fileCollection[j].StringUpload,
								EvFlag: fileCollection[j].EvFlag

							};

							newfileCollection.push(fileData);

						}

					}

				}*/

				fileCollection = newfileCollection;
				sap.ui.getCore().byId("idFileTableIds").setVisible(false);

				that1.setFileAttachments(fileCollection);

			}

		});

		colItems.addCell(button);

		var txtNAME3 = new sap.m.Input({

			value: "{Updkz}",

			visible: false

		});

		colItems.addCell(txtNAME3);

		//end table

		var getFileCollection = this.getFileAttachments();
		if (getFileCollection === null) {
			fileCollection = new Array();
		}

		var oView = this.getView();
		var oUploader = sap.ui.getCore().byId("fileUploaderIDs");
		var oFileUploader = sap.ui.getCore().byId("fileUploaderIDs");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];
		var BASE64_MARKER = 'data:' + file.type + ';base64,';

		var filename = file.name;
		var that = this;

		try {

			var reader = new FileReader();
			// On load set file contents to text view
			reader.onload = (function(theFile) {
				return function(evt) {
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

					var base64 = evt.target.result.substring(base64Index);

					var docType = "";
					var contentType = "";
					if (file.type === "application/msword") {
						docType = "DOC";
						contentType = ".doc";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
						docType = "DOC";
						contentType = ".docx";
					} else if (file.type === "image/jpeg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/jpg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/gif") {
						docType = "SIM";
						contentType = ".gif";
					} else if (file.type === "application/pdf") {
						docType = "PDF";
						contentType = ".pdf";
					} else if (file.type === "text/plain") {
						docType = "TXT";
						contentType = ".txt";
					} else if (file.type === "image/tiff") {
						docType = "TIF";
						contentType = ".tiff";
					} else if (file.type === "application/xml") {
						docType = "XML";
						contentType = ".xml";
					} else if (file.type === "application/vnd.ms-excel" || file.type ===
						"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xls";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xlsx";
					} else if (file.type === "video/mpeg") {
						docType = "MPP";
						contentType = ".m2v";
					} else if (file.type === "video/mp3") {
						docType = "MPP";
						contentType = ".mp3";
					}

					// *****************************
					var fileData = {

						Employeenumber: p,
						Subtype: subtype,
						FileContent: base64,
						FileContentType: contentType,
						FileLength: "",
						FileName: filename,
						StringUpload: p,
						EvFlag: "",
						Infotype: "0185"
					};
					fileCollection.push(fileData);
					that.setFileAttachments(fileCollection);
					sap.ui.getCore().byId("idFileTableIds").getModel().getData().myFiles.push({
						fileName: filename,
						Updkz: "I"
					});

					sap.ui.getCore().byId("idFileTableIds").getModel().refresh(true);
					oFileUploader.setValue("");

				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);

			return;

		} catch (e) {
			sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");
			//do something
			return;
		}
	},
	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},
	onSubmit: function() {
		//location.reload(true);
		var dialog = sap.ui.getCore().byId("idDialogDisclamier");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Disclamier", this.getView().getController());

		}
		dialog.open();
		sap.ui.getCore().byId("idBGDis").setVisible(false);
		sap.ui.getCore().byId("idEmerAdd").setVisible(false);
		sap.ui.getCore().byId("idPerAdd").setVisible(false);
		sap.ui.getCore().byId("idLocAdd").setVisible(false);
		sap.ui.getCore().byId("idAadharID").setVisible(false);
		sap.ui.getCore().byId("idPassNo").setVisible(false);
		sap.ui.getCore().byId("idPersdata").setVisible(false);
		sap.ui.getCore().byId("idEmailId").setVisible(false);
		sap.ui.getCore().byId("idMob").setVisible(false);
		sap.ui.getCore().byId("idIP").setVisible(false);
		sap.ui.getCore().byId("idAltMob").setVisible(false);
		sap.ui.getCore().byId("idFamdis").setVisible(false);
		sap.ui.getCore().byId("idEduDis").setVisible(false);
		sap.ui.getCore().byId("idQuaDis").setVisible(false);
		sap.ui.getCore().byId("idNoteDis").setVisible(false);
        
        var personalID = hcm.people.profile.util.UIHelper.getPernr();
        var empSubGrp = roleBandTxt ;
        var empSubArea = subArea;
        var empArea = persArea;
        var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true);  
	    var reportPath = "HRReportSet"; 
		for (var i = 0; i < batch.length; i++) {
			var URI = batch[i].requestUri;

			if (URI === "AddressesSet" || URI.indexOf("AddressesSet")>=0) {
				if (batch[i].data.Subtype === "4") {
					sap.ui.getCore().byId("idEmerAdd").setVisible(true);
				} else if (batch[i].data.Subtype === "1") {
					sap.ui.getCore().byId("idPerAdd").setVisible(true);
				} else if (batch[i].data.Subtype === "2") {
					sap.ui.getCore().byId("idLocAdd").setVisible(true);
				}
					var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0006"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			}
			if (URI === "IdentificationSet" || URI.indexOf("IdentificationSet")>=0) {
				if (batch[i].data.Subtype === "06") {
					sap.ui.getCore().byId("idAadharID").setVisible(true);
				} else {
					sap.ui.getCore().byId("idPassNo").setVisible(true);
				}
					var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0185"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			} 
			if (URI === "PersDataSet" || URI.indexOf("PersDataSet")>=0) {
				sap.ui.getCore().byId("idPersdata").setVisible(true);
				var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0002"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			}
			if(URI === "BloodGroupSet" || URI.indexOf("BloodGroupSet")>=0){
			    sap.ui.getCore().byId("idBGDis").setVisible(true);
			    var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0028"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			} 
			if (URI === "CommunicationsSet" || URI.indexOf("CommunicationsSet")>=0) {
				if (batch[i].data.Subtype === "0030") {
					sap.ui.getCore().byId("idEmailId").setVisible(true);
				} else if (batch[i].data.Subtype === "MOB") {
					sap.ui.getCore().byId("idMob").setVisible(true);
					}else if (batch[i].data.Subtype === "MOBP") {
					sap.ui.getCore().byId("idAltMob").setVisible(true);
						} else if (batch[i].data.Subtype === "IPP") {
					sap.ui.getCore().byId("idIP").setVisible(true);
					} else if (batch[i].data.Subtype === "RES") {
					sap.ui.getCore().byId("idAltMob").setVisible(true);
					}
					var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0105"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
				
			}
			if (URI === "FamilySet" || URI.indexOf("FamilySet")>=0) {
				sap.ui.getCore().byId("idFamdis").setVisible(true);
				var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0021"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			} 
			if (URI === "EducationSet" || URI.indexOf("EducationSet")>=0) {
				sap.ui.getCore().byId("idEduDis").setVisible(true);
				var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0022"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			} 
			if (URI === "QualificationSet" || URI.indexOf("QualificationSet")>=0) {
				sap.ui.getCore().byId("idQuaDis").setVisible(true);
				var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : "0024"
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			} 
			if (URI === "EmployeeNoteSet" || URI.indexOf("EmployeeNoteSet")>=0) {
				sap.ui.getCore().byId("idNoteDis").setVisible(true);
				var object = {
					    EmployeeID :personalID,
					    EmployeeSubgroupTxt :empSubGrp,
					    PersonnelSubareaTxt : empSubArea,
					    PersonnelAreaTxt : empArea,
					    HRFACID : hrFACID,
					    Infotype : ""
					};
					reportBatch.push(oDataModel.createBatchOperation(reportPath, "POST", object));
			}

		}

		
	},
	SubmitDisclamier : function(){
	        	var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true);   
	        	 var dialog = sap.ui.getCore().byId("idDialogDisclamier");
	                dialog.close();
            	this.getView().setBusy(true);
		jQuery.sap.delayedCall(4000, this, function() {
                dModel.addBatchChangeOperations(batch);
                dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
				this.getView().setBusy(false);
			});

	},
	CancelDisclamier : function(){
	    var dialog = sap.ui.getCore().byId("idDialogDisclamier");
	    dialog.close();
	},
    onRequestReportSuccess : function(e){
		var that = this;

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				sap.m.MessageBox.alert("Error while saving HR Report"+this.result.error);

			} else {
                      sap.m.MessageToast.show("Data saved Successfully");
                	location.reload(true);
			}
		}
    },
	onRequestSuccess: function(e) {

		var that = this;

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				sap.m.MessageBox.alert(this.result.error);

			} else {
                    var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true);   
					var oDialog = sap.ui.getCore().byId("idDialogDisclamier");
					
                    jQuery.sap.delayedCall(400, this, function() {
                    dModel.addBatchChangeOperations(reportBatch);
                    dModel.submitBatch(dModel,jQuery.proxy(this.onRequestReportSuccess, this));
                    oDialog.close();
				    this.getView().setBusy(false);
		    	    });
                    
			/*	sap.m.MessageBox.show("Data saved Successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction == "OK") {

							var oDialog = sap.ui.getCore().byId("idDialogDisclamier");

							oDialog.close();

							location.reload(true);

						}

					}.bind(that)

				});*/

			}

		}

	},

	onRequestFailed: function(e) {

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			var j = e.__batchResponses[0].response.body;

			var n = $.parseJSON(j);

			this.result = {};

			this.result.error = n.error.message.value;

			this.busyDialog.close();

			sap.m.MessageBox.error(this.result.error);

		}

	},
	onAttach : function(){
	    var oBtn = this.getView().byId("idattach");
			var sHtml = "Add/Update Aadhar ID <br>";
			 sHtml += "Add/Update Passport No <br>";
            sHtml += "Update Permanent Address <br>";
            sHtml += "Add/Update Local/Temporary Address <br>";
            sHtml += "Add Education details ";
			var oRichTooltip = new sap.ui.commons.RichTooltip({
				text: sHtml,
				title: "Documents are required for"
			});
			oRichTooltip.setAtPosition("end top");
			oBtn.setTooltip(oRichTooltip);
	},
		openQuickView : function(oEvent){

		if (!this._oQuickView) {
			this._oQuickView = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.QuickView", this.getView().getController());
			this.getView().addDependent(this._oQuickView);
		}
		var oLink =  sap.ui.getCore().byId(parentId+"--idGood");
		this._oQuickView.openBy(oLink);
		
	},
	
	handleOKPress : function(){
	    var dialog = sap.ui.getCore().byId("idPopover");
	    dialog.close();
		sap.ui.getCore().byId(parentId+"--msgGood").close();
	},
	
	onRefreshPage : function(){
	    	location.reload(true);
	}
});