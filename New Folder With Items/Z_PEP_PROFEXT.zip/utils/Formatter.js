jQuery.sap.declare("hcm.people.profile.Z_PEP_PROFEXT.utils.Formatter");

jQuery.sap.require("sap.ui.core.Element");

hcm.people.profile.Z_PEP_PROFEXT.utils.Formatter = {

 namesEditable : function(firstName,secondName)
 { 
     
     if(secondName === "." ){
         return true;
     }
     else
     {
         return false;
     }
 },
 textChange : function(value){
     if(value === "Marr.")
     {
         return "Married";
     }
     return value;
 },
 	ui5ToOdatadataForLocalFiltering: function(data) {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = day+'-'+month+'-'+iDatadt.getFullYear();

			return iDatadt;

}

		



};