var p;

var oDataModel;

var selectedIndex1;
var that = this;
var seqID = 0;
var myTasksModel;
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.Z_PEP_PROFEXT.blocks.QualificationsCollapsedControllerCustom", {

onInit: function() {

		this.buildUIColl();

		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		//Skills

		var skillsJson = new sap.ui.model.json.JSONModel();

		var skillsSet = "SHSkillsSet?$filter=QualifId gt '00009999'";

		oDataModel.read(skillsSet, null, null, false, function(r) {

			skillsJson.setData(r);

		});

		sap.ui.getCore().setModel(skillsJson, "skillsModel");

		//Languages

		var langJson = new sap.ui.model.json.JSONModel();

		var langSet = "SHSkillsSet?$filter=QualifId ge '00000001' and QualifId le '00009999'";

		oDataModel.read(langSet, null, null, false, function(r) {

			langJson.setData(r);

		});

		sap.ui.getCore().setModel(langJson, "langModel");
		//Proficiency set
		
		var profJson = new sap.ui.model.json.JSONModel();

		var profSet = "SHProficiencySet?$filter=Proficiency ge '10' and Proficiency le '13'";

		oDataModel.read(profSet, null, null, false, function(r) {

			profJson.setData(r);

		});

		sap.ui.getCore().setModel(profJson,"ProfModel");
	},

	onExit: function() {},

	buildUI: function() {},

	buildUIColl: function() {
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		
		var t = this;

			var p = hcm.people.profile.util.UIHelper.getPernr();
		var d = hcm.people.profile.util.UIHelper.getODataModel();

		var c = t.byId("ctrlQualificationContainer");

		var q = "EmployeeDataSet('" + p + "')/QualificationSet";

		oDataModel.read(q, null, null, true, function(r) {

			var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "ValidUntil");

			hcm.people.profile.util.UIHelper.setDataQualif(s);
			var data = {
				results: s
			};
			var model = new sap.ui.model.json.JSONModel();

			model.setData(data);
			seqID = data.results.length;
			var b = 0;

			var prevSubGrpName, f;
			this._table;
			var v = new sap.ui.layout.VerticalLayout({

				width: "100%",

				content: [

					 new sap.m.Panel({
						expandable: true,
						expanded: false,
						width: "100%",
						headerText: "Skills Details ",
						content: [
				 this._table = new sap.m.Table({
								inset: false,
								/*includeItemInSelection :true,*/
								
								columns: [
				        new sap.m.Column({
										header: new sap.m.Label({
											text: "Skills Name"
										}),
										minScreenWidth: "Tablet",
										demandPopin: true,
										hAlign: "Left"
									}),
				        new sap.m.Column({
										header: new sap.m.Label({
											text: "Proficiency"
										}),
										minScreenWidth: "Tablet",
										demandPopin: true,
										hAlign: "Left"
									}),
							new sap.m.Column({
										header: new sap.m.Label({
											text: ""
										}),
										minScreenWidth: "Tablet",
										demandPopin: true,
										hAlign: "Left"
									})

				    ]
							})
					]

					}),

						   new sap.m.Button({

						text: "Add",

						width: "150px",

						type: "Emphasized",

						press: function() {

							var dialog = sap.ui.getCore().byId("idDialogSkillDetails");

							if (dialog === undefined) {
								dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.QualificationDetails", t.getView().getController());
							}
							dialog.open();
							var taskList = {};

							var taskObj = [];

							taskList["myTasks"] = taskObj;

							myTasksModel = new sap.ui.model.json.JSONModel();

							myTasksModel.setData(taskList);

							var tsModelData = myTasksModel.oData.myTasks;

							var taskData = {};

							taskData.Updkz = "I";

							tsModelData.push(taskData);
							sap.ui.getCore().setModel(myTasksModel, "myTasksModel");
							sap.ui.getCore().byId("idTaskDetails").setModel("myTasksModel");
                            sap.ui.getCore().byId("idTaskDetails").getModel("myTasksModel").refresh(true);
					        var items = sap.ui.getCore().byId("idTaskDetails").getItems();
							for (var i = 0; i < items.length; i++)

			                {

                				if (items[0].getAggregation("cells")[1].mAggregations.items[1].getVisible()) {
                					items[0].getAggregation("cells")[1].mAggregations.items[1].setValue("");
                				
                				} else {
                					items[0].getAggregation("cells")[1].mAggregations.items[0].setValue("");
                					
                				}
			                }
						}

					})
							         ]

			});
			
			var objSelect = new sap.m.Select({enabled:false});
			var oItemSelectTemplate = new sap.ui.core.Item({
				key: "{ProfModel>Proficiency}",
				text: "{ProfModel>ProficiencyText}"
			});
			
			objSelect.bindAggregation("items", "ProfModel>/results", oItemSelectTemplate);
			objSelect.attachChange(function(oEvent){
				var otable = oEvent.getSource().getParent().getParent().sId;
				var index = oEvent.getSource().sId.split(otable+"-")[1];
				var items = sap.ui.getCore().byId(otable).getItems();
				var oModel = sap.ui.getCore().byId(otable).getModel();
                var tableItems = sap.ui.getCore().byId(otable).getItems();
                var profText = tableItems[index].getAggregation("cells")[1].getSelectedItem().getText();
                		var seqno = oModel.getData().results[index].SequenceNo;
						var empNo = oModel.getData().results[index].Employeenumber;
						var iDatadt = oModel.getData().results[index].StartDate;
						var Rating = oModel.getData().results[index].Rating;
						/*var changeddate = startdate.match(/\d+/g).map(function (s) { return new Date(+s); });
						var iDatadt = new Date(changeddate);*/
						var month = (iDatadt.getMonth() + 1);
						var day = iDatadt.getDate()
						if ((iDatadt.getMonth() + 1).toString().length < 2) {
							month = '0' + (iDatadt.getMonth() + 1);
						}
						if ((iDatadt.getDate()).toString().length < 2) {
							day = '0' + iDatadt.getDate();
						}
						iDatadt = iDatadt.getFullYear() +
						'-' + month +
						'-' + day +
						'T' + "00" +
						':' + "00" +
						':' + "00";
						var obj = {
							    RatingText :profText,
							    Rating:Rating
							}
					
		         var oModelData = oModel.getProperty("/");
			    
			     oModelData.results[index].RatingText = profText;
			     
			     oModel.setProperty("/", oModelData);
						oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
						var editpath = "QualificationSet(Employeenumber='" + empNo + "',ObjectID='',Subtype='',SequenceNo='" + seqno +
							"',StartDate=datetime'" + iDatadt + "')";

					oDataModel.update(editpath,obj, {
        	        success : function(odata) {
        	            jQuery.sap.require("sap.m.MessageToast");
        	            sap.m.MessageToast.show("updated Successfully");
        	        },
        	        error : function() {
        	          jQuery.sap.require("sap.m.MessageToast");
        	            sap.m.MessageToast.show("Fail while Updating the Request");
        	            }
        	    });
                
            
			});
			
			/*objSelect.attachSelectionChange(function(oEvent){
				oEvent.getSource().getBindingContext();
			});*/
			this._table.setModel(model);
			this._table.bindAggregation("items", {
				path: "/results",
				template: new sap.m.ColumnListItem({
					cells: [
						                    new sap.m.Label({
							text: "{Name}",
							wrapText: true
						}),
						//objSelect,
						   new sap.m.Label({
								text: "{RatingText}"
							}),
						new sap.ui.layout.HorizontalLayout({
							content: [
						              new sap.ui.core.Icon({
									src: "sap-icon://edit",
									press: function(oEvent) {
										var otable = oEvent.getSource().getParent().getParent().getParent().sId;
										var index = oEvent.getSource().sId.split(otable+"-")[1];
										var items = sap.ui.getCore().byId(otable).getItems();
										//items[index].getAggregation("cells")[1].setEnabled(true);
										
								
										var model = sap.ui.getCore().byId(otable).getModel();
										var sPath = "/results/" + index;
										var path = model.getProperty(sPath);
										var T = new sap.ui.model.json.JSONModel(path);
										
										
										var dialog = sap.ui.getCore().byId("ItemQualif");

										if (dialog === undefined) {

											dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.ItemQualif", t.getView().getController());

											//this.addDependent(dialog);

										}

										dialog.open();
										dialog.setModel(T, "ItemModel");
										sap.ui.getCore().setModel(T,"ItemModel");
										var profLevel = T.getData().RatingText;
										var ProfKey;
										var resultsProf = sap.ui.getCore().getModel("ProfModel").getData().results;
										for(var i=0;i<resultsProf.length;i++){
											if(resultsProf[i].ProficiencyText === profLevel)
											{
												ProfKey = resultsProf[i].Proficiency;
											}
										}
										sap.ui.getCore().byId("idProf").setSelectedKey(ProfKey);									}
								}),
								new sap.m.Label({
									text: "",
									width: "3rem"
								}),

						              new sap.ui.core.Icon({
									src: "sap-icon://delete",
									press: function(oEvent) {
										var otable = oEvent.getSource().getParent().getParent().getParent().sId;
										var oTableItemID = oEvent.getSource().getParent().getParent().sId;
										var index = oEvent.getSource().sId.split(otable+"-")[1];
									
									//	items[index].getAggregation("cells")[1].setEnabled(true);
										
										var oModel = sap.ui.getCore().byId(otable).getModel();
										var items = sap.ui.getCore().byId(otable).getItems();
										var seqno = oModel.getData().results[index].SequenceNo;
										var empNo = oModel.getData().results[index].Employeenumber;
										var iDatadt = oModel.getData().results[index].StartDate;
										//var changeddate = startdate.match(/\d+/g).map(function (s) { return new Date(+s); });
										//var iDatadt = new Date(changeddate);

											var month = (iDatadt.getMonth() + 1);
										var day = iDatadt.getDate()
										if ((iDatadt.getMonth() + 1).toString().length < 2) {	
											month = '0' + (iDatadt.getMonth() + 1);
										}
										if ((iDatadt.getDate()).toString().length < 2) {
											day = '0' + iDatadt.getDate();
										}
										iDatadt = iDatadt.getFullYear() +
										'-' + month +
										'-' + day +
										'T' + "00" +
										':' + "00" +
										':' + "00";
										sap.ui.getCore().byId(oTableItemID).addStyleClass("table");
										oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
										iDatadt = encodeURIComponent(iDatadt);
										var deletepath = "QualificationSet(Employeenumber='" + empNo + "',ObjectID='',Subtype='',SequenceNo='" + seqno +"',StartDate=datetime'" + iDatadt + "')";
                                    sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
										batch.push(oDataModel.createBatchOperation(deletepath, "DELETE"));
									    items[index].getAggregation("cells")[2].mAggregations.content[0].setVisible(false);
										items[index].getAggregation("cells")[2].mAggregations.content[2].setVisible(false);
										items[index].addStyleClass("highlightStyle");

									}
								})
						]
						})
						/*,
						                    new sap.m.Label({
										text: "{RatingText}"
									})*/
						            ]
				})
			});
			/*var oItemSelectTemplate = new sap.ui.core.Item({
				key: "{Proficiency}",
				text: "{ProficiencyText}"
			});
			var profJson = new sap.ui.model.json.JSONModel(); 
			profJson.setData(sap.ui.getCore().getModel("ProfModel").getData()); 
			var mySelectMenu = sap.ui.getCore().byId("idSelectProf"); 
			mySelectMenu.setModel(profJson);
			mySelectMenu.bindAggregation("items", "/results", oItemSelectTemplate);*/
			c.addContent(v);
		}, function(r) {

			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());

		});

	},

	onBeforeRendering: function() {},

	onAfterRendering: function() {
	/*	var sId  = this.getView().byId("ctrlQualificationContainer").getContent()[0].mAggregations.content[0].mAggregations.content[0].sId;
		
	var modelItems = sap.ui.getCore().byId(sId).getModel();
	var profModel = sap.ui.getCore().getModel("ProfModel");
		var items = sap.ui.getCore().byId(sId).getItems();

		for (var k = 0; k < modelItems.oData.results.length; k++) {

			var ratingTxt = modelItems.oData.results[k].RatingText;
			
			for(var i =0;i<profModel.oData.results.length;i++){
				var text = profModel.oData.results[i].ProficiencyText;
				if(text === ratingTxt){
					var key = profModel.oData.results[i].Proficiency;
				}
			}

			items[k].getAggregation("cells")[1].setSelectedKey(key);

		}*/
	},

	onSkillSelect: function(e) {

		var sId = e.getSource().getParent().sId.split("idTaskDetails-")[1];

		selectedIndex1 = sId; // sap.ui.getCore().byId("idTaskDetails").indexOfItem(e.getSource().getParent());

		var dialog = sap.ui.getCore().byId("skillsSelectDialog");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Skills", this);

			//this.addDependent(dialog);

		}

		dialog.open();

		//	this.setInitialFilter("Name", e.getSource()._lastValue, dialog);
		this.setInitialFilter("Name", "", dialog);

	},

	onLangSelect: function(e) {
		var sId = e.getSource().getParent().sId.split("idTaskDetails-")[1];

		selectedIndex1 = sId;

		//selectedIndex1 = sap.ui.getCore().byId("idTaskDetails").indexOfItem(e.getSource().getParent());

		var dialog = sap.ui.getCore().byId("langsSelectDialog");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Langs", this);

			//this.addDependent(dialog);

		}

		dialog.open();

		this.setInitialFilter("Name", "", dialog);

	},

	setInitialFilter: function(title, f, s) {

		f = f.split(this.openingBracket)[0];

		s.open(f);

		var i = s.getBinding("items");

		this.filterDialog(title, f, i)

	},

	onSuggest: function(e) {

		var v = e.getParameter("suggestValue");

		selectedIndex1 = sap.ui.getCore().byId("idTaskDetails").indexOfItem(e.getSource().getParent());

		var oFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, v);

		e.getSource().getBinding("suggestionItems").filter([oFilter]);

		this.filterDialog("Name", v, e.getSource().getBinding("suggestionItems").filter([oFilter]));

	},

	onSuggestionItemSelected: function(e) {

		var v = e.getParameter("selectedItem");

		if (v !== undefined) {

			var selectedItem = v.mProperties.text;

			if (e.getSource().sId === "idSkills") {

				this.selectedSkills = selectedItem + " [" + v.mProperties.key + "]";

			} else if (e.getSource().sId === "idLangs") {

				this.selectedLangs = selectedItem + " [" + v.mProperties.key + "]";

			}

		}

	},

	searchDialog: function(e) {

		var dialog = e.getSource().sId;

		var v = e.getParameter("value");

		var title;

		if (v !== undefined) {

			if (dialog === "skillsSelectDialog") {

				title = "Name";

			} else if (dialog === "langsSelectDialog") {

				title = "Name";

			}

			var oFilter = new sap.ui.model.Filter(new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v), false);

			e.getSource().getBinding("items").filter([oFilter]);

			this.filterDialog(title, v, e.getSource().getBinding("items").filter([oFilter]));

		}

	},

	filterDialog: function(title, v, i) {

		var f = [];

		var s = new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v);

		f.push(s);

		i.filter(f);

	},

	cancelSelectDialog: function(e) {},

	confirmSelectDialog: function(e) {

		var s = e.getParameter("selectedItem");

		var items = sap.ui.getCore().byId("idTaskDetails").getItems();

		var i;

		var p = s.oBindingContexts.skillsModel.sPath.split("/");

		if ("skillsSelectDialog" === e.getSource().sId) {

			i = items[selectedIndex1].getAggregation("cells")[1].mAggregations.items[0];

		}

		if (s) {

			var p = s.oBindingContexts.skillsModel.sPath.split("/");

			var a = p[p.length - 1];

			var QualifId = s.oBindingContexts.skillsModel.oModel.getData().results[a].QualifId;

			i.setValue(s.getTitle());
			i.setTooltip(QualifId);

			i.setValueState(sap.ui.core.ValueState.None);

		}

	},

	confirmLangDialog: function(e) {

		var s = e.getParameter("selectedItem");

		var items = sap.ui.getCore().byId("idTaskDetails").getItems();

		var i;

		var p = s.oBindingContexts.langModel.sPath.split("/");

		if ("langsSelectDialog" === e.getSource().sId) {

			i = items[selectedIndex1].getAggregation("cells")[1].mAggregations.items[1];

		}

		if (s) {

			var p = s.oBindingContexts.langModel.sPath.split("/");

			var a = p[p.length - 1];

			var QualifId = s.oBindingContexts.langModel.oModel.getData().results[a].QualifId;

			i.setValue(s.getTitle());
			i.setTooltip(QualifId);

			i.setValueState(sap.ui.core.ValueState.None);

		}

	},

	onChangeSkill: function(oEvent)

	{

		var sId = oEvent.getSource().sId;

		var value = sap.ui.getCore().byId("idTaskDetails").indexOfItem(oEvent.getSource().getParent());

		var selectedItem = sap.ui.getCore().byId(sId).getSelectedItem().getText();

		var items = sap.ui.getCore().byId("idTaskDetails").getItems();
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		if (selectedItem === "Languages")

		{

			var langJson = new sap.ui.model.json.JSONModel();

			var langSet = "SHSkillsSet?$filter=QualifId ge '00000001' and QualifId le '00009999'";

			oDataModel.read(langSet, null, null, false, function(r) {

				langJson.setData(r);

			});

			sap.ui.getCore().setModel(langJson, "langModel");

			items[value].getAggregation("cells")[1].mAggregations.items[1].setVisible(true);
			items[value].getAggregation("cells")[1].mAggregations.items[0].setVisible(false);

		} else

		{
			var skillsJson = new sap.ui.model.json.JSONModel();

			var skillsSet = "SHSkillsSet?$filter=QualifId gt '00009999'";

			oDataModel.read(skillsSet, null, null, false, function(r) {

				skillsJson.setData(r);

			});

			sap.ui.getCore().setModel(skillsJson, "skillsModel");
			items[value].getAggregation("cells")[1].mAggregations.items[0].setVisible(true);
			items[value].getAggregation("cells")[1].mAggregations.items[1].setVisible(false);

		}

	},

	SubmitSkill: function()

	{
		sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true);

		var B = new Array();

		var items = sap.ui.getCore().byId("idTaskDetails").getItems();

		var sequencNo = seqID;
		var flag = true;
		for (var i = 0; i < items.length; i++)

		{

			var QualifName, QualifId;

			if (items[i].getAggregation("cells")[1].mAggregations.items[1].getVisible()) {
				QualifName = items[i].getAggregation("cells")[1].mAggregations.items[1].getValue();

			} else {
				QualifName = items[i].getAggregation("cells")[1].mAggregations.items[0].getValue();

			}
			if (QualifName === "") {
				flag = false;
				if (items[i].getAggregation("cells")[1].mAggregations.items[1].getVisible()) {
					items[i].getAggregation("cells")[1].mAggregations.items[1].setValueState(sap.ui.core.ValueState.Error);

				} else {
					items[i].getAggregation("cells")[1].mAggregations.items[0].setValueState(sap.ui.core.ValueState.Error);

				}
			} else {
				if (items[i].getAggregation("cells")[1].mAggregations.items[1].getVisible()) {
					items[i].getAggregation("cells")[1].mAggregations.items[1].setValueState(sap.ui.core.ValueState.None);

				} else {
					items[i].getAggregation("cells")[1].mAggregations.items[0].setValueState(sap.ui.core.ValueState.None);

				}
			}
		}
		if (flag) {
			for (var i = 0; i < items.length; i++)

			{

				if (items[i].getAggregation("cells")[1].mAggregations.items[1].getVisible()) {
					QualifName = items[i].getAggregation("cells")[1].mAggregations.items[1].getValue();
					QualifId = items[i].getAggregation("cells")[1].mAggregations.items[1].getTooltip();
				} else {
					QualifName = items[i].getAggregation("cells")[1].mAggregations.items[0].getValue();
					QualifId = items[i].getAggregation("cells")[1].mAggregations.items[0].getTooltip();
				}
				var QualifObj = {};

				sequencNo = seqID + i + 1;

				/*	var QualifName = name.split("[");

				var finalQualiID = QualifName[1].split("]")[0];*/

				QualifObj.Employeenumber = p;

				QualifObj.Name = QualifName;

				QualifObj.QualifId = QualifId;

				QualifObj.ProficiencyLevel = items[i].getAggregation("cells")[2].getSelectedKey();
				QualifObj.Rating = items[i].getAggregation("cells")[2].getSelectedKey();
				QualifObj.RatingText = items[i].getAggregation("cells")[2].getSelectedItem().getText();

				QualifObj.SequenceNo = "" + sequencNo;

				batch.push(dModel.createBatchOperation("QualificationSet", "POST", QualifObj));
				var dialog = sap.ui.getCore().byId("idDialogSkillDetails");
				dialog.close();
			}

			/*	dModel.addBatchChangeOperations(B);

		dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
*/
		}
	},

	onRequestSuccess: function(e) {

		var that = this;

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				sap.m.MessageBox.alert(this.result.error);

			} else {

				sap.m.MessageBox.show("Data saved Successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction == "OK") {

							var skillDialog = sap.ui.getCore().byId("idDialogSkillDetails");

							skillDialog.close();

							location.reload(true);

						}

					}.bind(that)

				});

			}

		}

	},

	onRequestFailed: function(e) {

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			var j = e.__batchResponses[0].response.body;

			var n = $.parseJSON(j);

			this.result = {};

			this.result.error = n.error.message.value;

			this.busyDialog.close();

			sap.m.MessageBox.error(this.result.error);

		}

	},

	onCloseSkill: function()

	{

		var skillDialog = sap.ui.getCore().byId("idDialogSkillDetails");
		var taskList = {};

		var taskObj = [];

		taskList["myTasks"] = taskObj;

		myTasksModel = new sap.ui.model.json.JSONModel();

		myTasksModel.setData(taskList);

		var tsModelData = myTasksModel.oData.myTasks;

		var taskData = {};

		sap.ui.getCore().setModel(myTasksModel, "myTasksModel")
		sap.ui.getCore().byId("idTaskDetails").setModel(myTasksModel);

		sap.ui.getCore().byId("idTaskDetails").getModel().refresh(true);

		skillDialog.close();

	},

	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()

			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}

			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}

			iDatadt = iDatadt.getFullYear() +

			'-' + month +

			'-' + day +

			'T' + "00" +

			':' + "00" +

			':' + "00";

			return iDatadt;

		}

	},

	onClickAddTask: function(e) {

		var myTasksModel = sap.ui.getCore().byId("idTaskDetails").getModel("myTasksModel");

		var items = sap.ui.getCore().byId("idTaskDetails").getItems();

		var taskArrValue = [];

		var listArrValue = [];

		/*	for (var n = 0; n < items.length; n++) {

			taskArrValue[n] = items[n].getAggregation("cells")[1].getValue();

			listArrValue[n] = items[n].getAggregation("cells")[2].getSelectedKey();

		}*/

		var tsModelData = myTasksModel.oData.myTasks;

		var taskData = {};

		taskData.Updkz = "I";

		tsModelData.push(taskData);

		sap.ui.getCore().byId("idTaskDetails").setModel(myTasksModel);

		sap.ui.getCore().byId("idTaskDetails").getModel().refresh(true);

		items = sap.ui.getCore().byId("idTaskDetails").getItems();

		/*for (var n = 0; n < listArrValue.length; n++) {

			items[n].getAggregation("cells")[1].setValue(taskArrValue[n]);

			items[n].getAggregation("cells")[2].setSelectedKey(listArrValue[n]);

		}*/

		var skillsJson = new sap.ui.model.json.JSONModel();

		var skillsSet = "SHSkillsSet?$filter=QualifId gt '00009999'";

		oDataModel.read(skillsSet, null, null, false, function(r) {

			skillsJson.setData(r);

		});

		sap.ui.getCore().setModel(skillsJson, "skillsModel");

	},
	onDelete: function(oEvent) {
		var id = oEvent.getSource().sId;
		var selectedItem = id.split("idTaskDetails-");

		var selectedList = sap.ui.getCore().byId("idTaskDetails").getItems();

		if (selectedList[selectedItem[1]].getAggregation("cells")[4].getText() !== "") {

			selectedList[selectedItem[1]].getAggregation("cells")[4].setText("D");

		}
		var items = sap.ui.getCore().byId("idTaskDetails").getItems();

		var taskList = {};

		var taskObj = [];

		taskList["myTasks"] = taskObj;

		var myTasksModelNew = new sap.ui.model.json.JSONModel();

		myTasksModelNew.setData(taskList);

		var tsModelDataNew = myTasksModelNew.oData.myTasks;

		var count = 0;

		var typeArrValue = [];

		var skillArrValue = [];
		var langArrValue = [];
		var levelArrValue = [];
		var visSkillValue = [];

		for (var k = 0; k < items.length; k++) {

			if (items[k].getAggregation("cells")[4].getText() === "" || items[k].getAggregation("cells")[4].getText() === "I") {

				var taskData = {};

				typeArrValue[count] = items[k].getAggregation("cells")[0].getSelectedKey();

				if (items[k].getAggregation("cells")[1].mAggregations.items[1].getVisible()) {
					langArrValue[count] = items[k].getAggregation("cells")[1].mAggregations.items[1].getValue();
					visSkillValue[count] = false;
				} else {
					skillArrValue[count] = items[k].getAggregation("cells")[1].mAggregations.items[0].getValue();
					visSkillValue[count] = true;
				}
				levelArrValue[count] = items[k].getAggregation("cells")[2].getSelectedKey();
				taskData.Updkz = items[k].getAggregation("cells")[4].getText();

				tsModelDataNew.push(taskData);

				count++;

			}
		}
		sap.ui.getCore().byId("idTaskDetails").setModel(myTasksModelNew);

		sap.ui.getCore().byId("idTaskDetails").getModel().refresh(true);

		sap.ui.getCore().getModel("myTasksModel").setData(sap.ui.getCore().byId("idTaskDetails").getModel().getData());

		items = sap.ui.getCore().byId("idTaskDetails").getItems();

		for (var n = 0; n < typeArrValue.length; n++) {

			items[n].getAggregation("cells")[0].setSelectedKey(typeArrValue[n]);
			if (visSkillValue[n] === true) {
				items[n].getAggregation("cells")[1].mAggregations.items[0].setVisible(visSkillValue[n]);
				items[n].getAggregation("cells")[1].mAggregations.items[1].setVisible(false);
				items[n].getAggregation("cells")[1].mAggregations.items[0].setValue(skillArrValue[n]);
			} else {
				items[n].getAggregation("cells")[1].mAggregations.items[0].setVisible(false);
				items[n].getAggregation("cells")[1].mAggregations.items[1].setVisible(true);
				items[n].getAggregation("cells")[1].mAggregations.items[1].setValue(langArrValue[n]);

			}

			items[n].getAggregation("cells")[2].setSelectedKey(levelArrValue[n]);
			items[n].getAggregation("cells")[4].setText("I");
		}

	},
	sortArrayByProperty: function(v, w) {
		function x(y) {
			var z = 1;
			if (y[0] === "-") {
				z = -1;
				y = y.substr(1);
			}
			return function(a, b) {
				var A = (a[y] < b[y]) ? -1 : (a[y] > b[y]) ? 1 : 0;
				return A * z;
			};
		}
		return v.sort(x(w));
	},
	setSubSecQualif: function(a) {
		m = a;
	},
	getSubSecQualif: function() {
		return m;
	},
	setDataQualif: function(a) {
		n = a;
	},
	getDataQualif: function() {
		return n;
	},

	
	SubmitProfi: function(oEvent) {
		var oModel = sap.ui.getCore().getModel("ItemModel");
              		var seqno = oModel.getData().SequenceNo;
				var empNo = oModel.getData().Employeenumber;
				var iDatadt = oModel.getData().StartDate;
				var Rating = oModel.getData().Rating;
				var profText = sap.ui.getCore().byId("idProf").getSelectedItem().getText();
				/*var changeddate = startdate.match(/\d+/g).map(function (s) { return new Date(+s); });
				var iDatadt = new Date(changeddate);*/
				var month = (iDatadt.getMonth() + 1);
				var day = iDatadt.getDate()
				if ((iDatadt.getMonth() + 1).toString().length < 2) {
					month = '0' + (iDatadt.getMonth() + 1);
				}
				if ((iDatadt.getDate()).toString().length < 2) {
					day = '0' + iDatadt.getDate();
				}
				iDatadt = iDatadt.getFullYear() +
				'-' + month +
				'-' + day +
				'T' + "00" +
				':' + "00" +
				':' + "00";
				var obj = {
					    RatingText :profText,
					    Rating:Rating
					}
		iDatadt = encodeURIComponent(iDatadt);
		var editpath = "QualificationSet(Employeenumber='" + empNo + "',ObjectID='',Subtype='',SequenceNo='" + seqno +"',StartDate=datetime'" + iDatadt + "')";
 
	    sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
		batch.push(oDataModel.createBatchOperation(editpath, "PUT", obj));
		var dialog = sap.ui.getCore().byId("ItemQualif");

		dialog.close();

	},
	onCloseProfi : function()
	{
		var dialog = sap.ui.getCore().byId("ItemQualif");
		
		dialog.close();
	}

});