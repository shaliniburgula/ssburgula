/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("hcm.people.profile.Z_PEP_PROFEXT.utils.Formatter");
var facName, facID;
var p;
var fileCollection = new Array();
sap.ui.controller("hcm.people.profile.Z_PEP_PROFEXT.blocks.NotetoHRCollapsedController", {
	onInit: function() {
		this.buildUI();
	},
	onExit: function() {},
	onAfterRendering: function(){
	  
	},
	buildUI: function() {

		var t = this;

		p = hcm.people.profile.util.UIHelper.getPernr();

		var d = hcm.people.profile.util.UIHelper.getODataModel();

		var persJson = new sap.ui.model.json.JSONModel();

		var c = t.byId("ctrlNoteContainer");
		var q = "EmployeeDataSet('" + p + "')";

		d.read(q, null, null, false, function(r) {

			persJson.setData(r);

		});

		this.getView().setModel(persJson, "NotePRModel");

		console.log(persJson);

		var noteJson = new sap.ui.model.json.JSONModel();
		var noteSet = "EmployeeNoteSet?$top=20";
		d.read(noteSet, null, null, false, function(r) {
			noteJson.setData(r);
		});
		sap.ui.getCore().setModel(noteJson, "NoteModel");

		facName = this.getView().getModel("NotePRModel").getData().HRFACName;
		facID = this.getView().getModel("NotePRModel").getData().HRFACID;
		
		var textNote;
		var table;
        var oPanel;
        var that = this;
      	var v = new sap.ui.layout.VerticalLayout({

			width: "100%",
			content: [
					/*	   new sap.m.Button({
					text: "Request with HR-FAC",
					width: "150px",
					type: "Emphasized",
					press: function() {
						var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

						if (dialog === undefined)

						{

							dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.editHRFAC", t.getView().getController());

						}

						dialog.open();
                        
						var labelName = sap.ui.getCore().byId("__xmlview2--lblhrfacName").getText();

						sap.ui.getCore().byId("toHR").setText(labelName);

						if (facName === "No Data") {

							sap.ui.getCore().byId("idHRFAC").setVisible(false);
							sap.ui.getCore().byId("idNoHRFAC").setVisible(true);

							sap.ui.getCore().byId("idBtn2").setVisible(false);
							sap.ui.getCore().byId("idBtn1").setVisible(true);

						} else

						{

							sap.ui.getCore().byId("idHRFAC").setVisible(true);
							sap.ui.getCore().byId("idNoHRFAC").setVisible(false);

							sap.ui.getCore().byId("idBtn2").setVisible(true);
							sap.ui.getCore().byId("idBtn1").setVisible(false);

							//	sap.ui.getCore().byId("idHRName").setValue(approverName);

						}

					}
				}),*/
					new sap.ui.layout.HorizontalLayout({
						width: "100%",
						content: [
								textNote = new sap.m.Text("idtextNote",{
					text: "",
					wrapping:true,
					width: "100%"
				}),
				new sap.m.Label({ 
				    text:"",
				   width:"6px" 
				}),
				 new sap.m.Link({
				     text:facName,
				     press:function(){
				         	var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

						if (dialog === undefined)

						{

							dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.editHRFAC", t.getView().getController());

						}

						dialog.open();
                        
						var labelName = sap.ui.getCore().byId(parentId+"--lblhrfacName").getText();

						sap.ui.getCore().byId("toHR").setText(labelName);

				     }
				 })
				
				]
					}),

									oPanel = new sap.m.Panel({
					expandable: true,
					expanded: false,
					width: "100%",
					headerText: "History of requests ",
					content: [
													    table = new sap.m.Table({
							inset: true,
							columns: [
				        new sap.m.Column({
									header: new sap.m.Label({
										text: "Date"
									}),
									minScreenWidth: "Tablet",
									demandPopin: true,
									hAlign: "Left"
								}),
				        new sap.m.Column({
									header: new sap.m.Label({
										text: "Subject"
									}),
									minScreenWidth: "Tablet",
									demandPopin: true,
									hAlign: "Left"
								}),
							 new sap.m.Column({
									header: new sap.m.Label({
										text: "Description"
									}),
									minScreenWidth: "Tablet",
									demandPopin: true,
									hAlign: "Left"
								}),
							 new sap.m.Column({
									header: new sap.m.Label({
										text: "Attachment"
									}),
									minScreenWidth: "Tablet",
									demandPopin: true,
									hAlign: "Left"
								})
				    ]
						})
											]

				})

						         ]
		});
	   
		table.setModel(noteJson);
		table.bindAggregation("items", {
			path: "/results",
			template: new sap.m.ColumnListItem({
				cells: [
						                    new sap.m.Label({
						text: "{parts:[{path:'CreationDate'}],formatter:'hcm.people.profile.Z_PEP_PROFEXT.utils.Formatter.ui5ToOdatadataForLocalFiltering'}",
						wrapping: true
					}),
						                    new sap.m.Label({
						text: "{Subject}",
						wrapping: true
					}),
						                    new sap.m.Label({
						text: "{Note}",
						wrapping: true
					}),
						                    new sap.m.Link({
						text: "{FileName}",
						href :"",
						wrapping: true,
						press:function(e){
						      var id = e.getSource().getId()
 
           //var checked = sap.ui.getCore().byId(id).getSelected();
 
           var selectedIndex = parseInt(e.getSource().getId().split("__table0-")[1]);
           var model = sap.ui.getCore().getModel("NoteModel");
           var sPath = "/results/" + selectedIndex;
           var path = model.getProperty(sPath);
           var T = new sap.ui.model.json.JSONModel(path);
           var data = T.getData();
           var approverID = data.ApproverID;
            var creationDate = data.CreationDate;
            var formattedDate = new Date(creationDate);

	formattedDate = that.ui5ToOdatadataForLocalFiltering(creationDate, 'date');
           
           var creationTime = data.CreationTime;
           var formattedTime = that.formatTime(creationTime);
						    var i = "/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/HRNoteAttachmentDisplaySet(CreationDate=datetime'"+formattedDate+"',CreationTime=time'"+formattedTime+"',ApproverID='"+approverID+"')/$value";
          
                             window.open(i,"_blank");
						}
					})
						/*,
						                    new sap.m.Label({
										text: "{RatingText}"
									})*/
						            ]
			})
		});

		textNote.addStyleClass("noteText");
		c.addContent(v);
      if(facName === ""){  
        sap.ui.getCore().byId("idtextNote").setText("For any data that could not be corrected or updated by you, please raise a request with HR-FAC. As per the records, No HR FAC is assigned .Please contact your local HR");
      }
      else{
       sap.ui.getCore().byId("idtextNote").setText("For any data that could not be corrected or updated by you, please raise a request with HR-FAC");
      }
        
	},
	onBeforeRendering: function() {},
	onAfterRendering: function() {
	     
	},
	onOKNote: function() {

		var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

		dialog.close();

	},
	onCloseNote: function() {

		sap.ui.getCore().byId("txtHR").setValue("");
		sap.ui.getCore().byId("subjHR").setValue("");

		var myjson = new sap.ui.model.json.JSONModel();
		var mydata = {
			"myFiles": [
	                                                                ]
		};
		myjson.setData(mydata);
		if (sap.ui.getCore().byId("idFileTableHR").getVisible()) {
			sap.ui.getCore().byId("idFileTableHR").setModel(myjson);
		}
		var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

		dialog.close();

	},

	SubmitNote: function() {

		var note = sap.ui.getCore().byId("txtHR").getValue();

		var subject = sap.ui.getCore().byId("subjHR").getValue();

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		/*		var labelName = this.byId("lblhrfacName").getText();
        		var approverID = "P"+this.byId("lblhrfacID").getText();

		var name = labelName.split(":");

		var approverName = name[1];*/

		var errorBody;
		var approverId = "P" + facID;
		var createPath = "EmployeeNoteSet";
		if (fileCollection.length > 0) {

			var obj = {

				ApproverName: facName,
				Note: note,
				Subject: subject,
				ApproverID: approverId,
				FileContent: fileCollection[0].FileContent,
				FileContentType: fileCollection[0].FileContentType,
				FileName: fileCollection[0].FileName

			};
		} else {
			obj = {

				ApproverName: facName,
				Note: note,
				Subject: subject,
				ApproverID: approverId,
				FileContent: "",
				FileContentType: "",
				FileName: ""

			};
		}

		console.log(obj);
		var r = true;
		if (subject === "") {
			sap.ui.getCore().byId("subjHR").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("subjHR").setValueStateText("Enter Subject, Mandatory field");
			r = false;
		} else {
			sap.ui.getCore().byId("subjHR").setValueState(sap.ui.core.ValueState.None);
		}

		if (note === "") {
			sap.ui.getCore().byId("txtHR").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("txtHR").setValueStateText("Enter Details, Mandatory field");
			r = false;
		} else {
			sap.ui.getCore().byId("txtHR").setValueState(sap.ui.core.ValueState.None);
		}

		var result = false;
		if (r) {
			/*oDataModel.create(createPath, obj, null, function(responseBody, sucRes) {

				result = true;

			}, function(failRes) {

				result = false;

				errorBody = JSON.parse(failRes.response.body);

			});*/
			 sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
        	batch.push(oDataModel.createBatchOperation(createPath, "POST", obj));
        	sap.ui.getCore().byId("txtHR").setValue("");
				sap.ui.getCore().byId("subjHR").setValue("");
				var myjson = new sap.ui.model.json.JSONModel();
				var mydata = {
					"myFiles": [
	                                                                ]
				};
				myjson.setData(mydata);
				if (sap.ui.getCore().byId("idFileTableHR").getVisible()) {
					sap.ui.getCore().byId("idFileTableHR").setModel(myjson);
				}

				var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

				dialog.close();

			/*if (result === true) {

				sap.m.MessageBox.success("This has been forwarded to HR FAC");

				sap.ui.getCore().byId("txtHR").setValue("");
				sap.ui.getCore().byId("subjHR").setValue("");
				var myjson = new sap.ui.model.json.JSONModel();
				var mydata = {
					"myFiles": [
	                                                                ]
				};
				myjson.setData(mydata);
				if (sap.ui.getCore().byId("idFileTableHR").getVisible()) {
					sap.ui.getCore().byId("idFileTableHR").setModel(myjson);
				}

				var dialog = sap.ui.getCore().byId("idDialogEditHRFAC");

				dialog.close();

			} else {
				sap.m.MessageBox.error("\\n Message: " + errorBody.error.message.value);
			}*/

		}
	},

	handleUploadPressIds: function(evt) {

		fileCollection = new Array();

		var myjsonEmp = new sap.ui.model.json.JSONModel();

		var mydataEmp = {

			"myFiles": []

		};

		myjsonEmp.setData(mydataEmp);

		sap.ui.getCore().setModel("FileModel", myjsonEmp);

		sap.ui.getCore().byId("idFileTableHR").setModel(myjsonEmp);
		sap.ui.getCore().byId("idFileTableHR").setVisible(true);
		var that = this;
		var oTable = sap.ui.getCore().byId("idFileTableHR");

		var colItems = new sap.m.ColumnListItem({

			type: "Active"

		});

		oTable.bindAggregation("items", "/myFiles", colItems);

		var txtNAME = new sap.m.Text({

			text: "{fileName}"

		});

		colItems.addCell(txtNAME);

		var button = new sap.ui.core.Icon({

			src: "sap-icon://delete",

			press: function(e) {

				var selectedRow = parseInt(e.getSource().getId().split("idFileTableHR-")[1]);

				var items = sap.ui.getCore().byId("idFileTableHR").getItems();

				items[selectedRow].getAggregation("cells")[2].setValue("D");

				var assFileListEmp = {};

				var assFileEmp = [];

				assFileListEmp["myFiles"] = assFileEmp;

				var myAssFileModelEmp = new sap.ui.model.json.JSONModel();

				myAssFileModelEmp.setData(assFileListEmp);

				var myNewModelData = myAssFileModelEmp.oData.myFiles;

				items = sap.ui.getCore().byId("idFileTableHR").getItems();

				for (var i = 0; i < items.length; i++) {

					var inputValue = items[i].getAggregation("cells")[0].getText();

					var delFlag = items[i].getAggregation("cells")[2].getValue();

					var taskData = {};

					if (delFlag === "I") {

						taskData.fileName = inputValue;

						taskData.Updkz = delFlag;

						myNewModelData.push(taskData);

					}

				}

				sap.ui.getCore().byId("idFileTableHR").setModel(myAssFileModelEmp);

				var newfileCollection = new Array();

				for (var i = 0; i < myNewModelData.length; i++) {

					for (var j = 0; j < fileCollection.length; j++) {

						if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {

							var fileData = {

								Employeenumber: fileCollection[j].Employeenumber,
								Subtype: fileCollection[j].Subtype,
								Infotype: fileCollection[j].Infotype,
								FileContent: fileCollection[j].FileContent,
								FileContentType: fileCollection[j].FileContentType,
								FileLength: fileCollection[j].FileLength,
								FileName: fileCollection[j].FileName,
								StringUpload: fileCollection[j].StringUpload,
								EvFlag: fileCollection[j].EvFlag

							};

							newfileCollection.push(fileData);

						}

					}

				}

				fileCollection = newfileCollection;
                sap.ui.getCore().byId("idFileTableHR").setVisible(false);
				that.setFileAttachments(fileCollection);

			}

		});

		colItems.addCell(button);

		var txtNAME3 = new sap.m.Input({

			value: "{Updkz}",

			visible: false

		});

		colItems.addCell(txtNAME3);

		//end table

		var getFileCollection = this.getFileAttachments();
		if (getFileCollection === null) {
			fileCollection = new Array();
		}

		var oView = this.getView();
		var oUploader = sap.ui.getCore().byId("fileUploaderHR");
		var oFileUploader = sap.ui.getCore().byId("fileUploaderHR");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];
		var BASE64_MARKER = 'data:' + file.type + ';base64,';

		var filename = file.name;
		var that = this;

		try {

			var reader = new FileReader();
			// On load set file contents to text view
			reader.onload = (function(theFile) {
				return function(evt) {
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

					var base64 = evt.target.result.substring(base64Index);

					var docType = "";
					var contentType = "";
					if (file.type === "application/msword") {
						docType = "DOC";
						contentType = ".doc";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
						docType = "DOC";
						contentType = ".docx";
					} else if (file.type === "image/jpeg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/jpg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/gif") {
						docType = "SIM";
						contentType = ".gif";
					} else if (file.type === "application/pdf") {
						docType = "PDF";
						contentType = ".pdf";
					} else if (file.type === "text/plain") {
						docType = "TXT";
						contentType = ".txt";
					} else if (file.type === "image/png") {
						docType = "PNG";
						contentType = ".png";
					} else if (file.type === "image/tiff") {
						docType = "TIF";
						contentType = ".tiff";
					} else if (file.type === "application/xml") {
						docType = "XML";
						contentType = ".xml";
					} else if (file.type === "application/vnd.ms-excel" || file.type ===
						"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xls";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xlsx";
					} else if (file.type === "video/mpeg") {
						docType = "MPP";
						contentType = ".m2v";
					} else if (file.type === "video/mp3") {
						docType = "MPP";
						contentType = ".mp3";
					}

					// *****************************
					var fileData = {

						Employeenumber: p,
						FileContent: base64,
						FileContentType: contentType,
						FileLength: "",
						FileName: filename
					};
					fileCollection.push(fileData);
					that.setFileAttachments(fileCollection);
					sap.ui.getCore().byId("idFileTableHR").getModel().getData().myFiles.push({
						fileName: filename,
						Updkz: "I"
					});

					sap.ui.getCore().byId("idFileTableHR").getModel().refresh(true);
					oFileUploader.setValue("");

				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);

			return;

		} catch (e) {
			sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");
			//do something
			return;
		}
	},
	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},

  	ui5ToOdatadataForLocalFiltering: function(data, type) {

		if (type === 'date') {

			var iDatadt = data;

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()



			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}



			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}



		iDatadt = iDatadt.getFullYear() +

				'-' + month +

				'-' + day +

				'T' + "00" +

				':' + "00" +

				':' + "00";



			return iDatadt;



		}



	},
	formatTime: function(val) {
  	  var d = new Date(val.ms);
    var s = d.getUTCSeconds();
    var h = d.getUTCHours();
    var m = d.getUTCMinutes();
	var value = "PT"+h+"H"+m+"M"+s+"S";
    return value;
	}
});