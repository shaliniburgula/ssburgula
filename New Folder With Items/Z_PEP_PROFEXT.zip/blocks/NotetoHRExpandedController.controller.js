/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
sap.ui.controller("hcm.people.profile.Z_PEP_PROFEXT.blocks.NotetoHRExpandedController", {
	onInit: function() {
		this.buildUI();
	},
	onExit: function() {},
	buildUI: function() {
	       var t = this;

		var p = hcm.people.profile.util.UIHelper.getPernr();

		var d = hcm.people.profile.util.UIHelper.getODataModel();

		var c = t.byId("ctrlNoteContainer");

			var b = 0;

			var prevSubGrpName,f;

            var v = new sap.ui.layout.VerticalLayout({

							width: "100%",
							content: [
						   new sap.m.Button({
									text: "Add",
									width: "150px",
									type: "Emphasized",
									press: function() {
									    	var dialog = sap.ui.getCore().byId("idDialogSkillDetails");
										if (dialog === undefined) {
											dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.QualificationDetails", t.getView().getController());
											this.addDependent();
										}
										dialog.open();
									
									}
								})
						         ]

						});
					c.addContent(v);
	},
	onBeforeRendering: function() {},
	onAfterRendering: function() {}
});