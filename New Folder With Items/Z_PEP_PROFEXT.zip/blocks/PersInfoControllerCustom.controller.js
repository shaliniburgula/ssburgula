/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
var p;
var a, g, b;
var oDataModel;
var fileCollection = new Array();
var fileCollectionIns = new Array();
var fileCollectionEmp = new Array();
var arrayList = {};
var arrayObj = [];
var result = false;
var resultEmp = false;
var resultIns = false;
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("sap.ui.layout.form.SimpleForm");

jQuery.sap.require("sap.ui.commons.RichTooltip");

jQuery.sap.require("hcm.people.profile.Z_PEP_PROFEXT.utils.Formatter");

sap.ui.controller("hcm.people.profile.Z_PEP_PROFEXT.blocks.PersInfoControllerCustom", {
	onInit: function() {

		var dialog = sap.ui.getCore().byId("idDialogFamilyDetails");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.FamilyDetails", this.getView().getController());

		}
		/*	var oldDateValue = sap.ui.getCore().byId("DP6").getValue();
		var picker = sap.ui.getCore().byId("DP6");
		picker.attachBrowserEvent('keypress', function(oEvent) {
			sap.m.MessageBox.alert("select only through date picker");
			picker.setValue("");
			oEvent.preventDefault();
			picker.setValue(oldDateValue);
		});*/

		var dialogEmp = sap.ui.getCore().byId("idDialogEmployerDetails");
		if (dialogEmp === undefined) {
			dialogEmp = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.EmployerDetails", this.getView().getController());

		}

		/*	var startDateEmpValue = sap.ui.getCore().byId("startDateEmp").getValue();
		var SDEmpPicker = sap.ui.getCore().byId("startDateEmp");
		SDEmpPicker.attachBrowserEvent('keypress', function(oEvent) {
			sap.m.MessageBox.alert("select only through date picker");
			SDEmpPicker.setValue("");
			oEvent.preventDefault();
			SDEmpPicker.setValue(startDateEmpValue);
		});
		var endDateEmpValue = sap.ui.getCore().byId("endDateEmp").getValue();
		var EDEmpPicker = sap.ui.getCore().byId("endDateEmp");
		EDEmpPicker.attachBrowserEvent('keypress', function(oEvent) {
			sap.m.MessageBox.alert("select only through date picker");
			EDEmpPicker.setValue("");
			oEvent.preventDefault();
			EDEmpPicker.setValue(endDateEmpValue);
		});*/

		var dialogIns = sap.ui.getCore().byId("idDialogInstituteDetails");
		if (dialogIns === undefined) {
			dialogIns = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.InstituteDetails", this.getView().getController());
		}

		/*var startDateValue = sap.ui.getCore().byId("startDate").getValue();
		var SDPicker = sap.ui.getCore().byId("startDate");
		SDPicker.attachBrowserEvent('keypress', function(oEvent) {
			sap.m.MessageBox.alert("select only through date picker");
			SDPicker.setValue("");
			oEvent.preventDefault();
			SDPicker.setValue(startDateValue);
		});
		var endDateValue = sap.ui.getCore().byId("endDate").getValue();
		var EDPicker = sap.ui.getCore().byId("endDate");
		EDPicker.attachBrowserEvent('keypress', function(oEvent) {
			sap.m.MessageBox.alert("select only through date picker");
			EDPicker.setValue("");
			oEvent.preventDefault();
			EDPicker.setValue(endDateValue);
		});
*/
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
        
        //District binding for value help of address dialog
		var districtJson = new sap.ui.model.json.JSONModel();
		var districtSet = "SHDistrictSet";
		oDataModel.read(districtSet, null, null, false, function(r) {
			districtJson.setData(r);
		});

		sap.ui.getCore().setModel(districtJson, "DistrictModel");
		console.log(districtJson);
		
		var countryExtJson = new sap.ui.model.json.JSONModel();

		var countryExtCodeJson = {
			countryCode: [
				{
					"countryName": "India - 559",
					"code": "559"
				},
				/*
				{
					"countryName": "India - Banglore - 559",
					"code": "559"
				},
				{
					"countryName": "India - Mumbai - 559",
					"code": "559"
				},
				{
					"countryName": "India - Delhi - 559",
					"code": "559"
				},
				{
					"countryName": "CHINA (CH) - 559",
					"code": "559"
				},
				{
					"countryName": "ROMANIA (RO) - 559",
					"code": "559"
				},
				{
					"countryName": "JAMAICA (JA) - 559",
					"code": "559"
				},
				{
					"countryName": "VENEZUELA (VEN) - 559",
					"code": "559"
				},
				{
					"countryName": "MYANMAR (MY) - 559",
					"code": "559"
				},
				{
					"countryName": "BELARUS (BE) - 559",
					"code": "559"
				},
				{
					"countryName": "VIETNAM (VI) - 559",
					"code": "559"
				},
				{
					"countryName": "UZBEKISTAN (UZB) - 559",
					"code": "559"
				},
				{
					"countryName": "KAZAKHSTAN (KA) - 559",
					"code": "559"
				},
				{
					"countryName": "AUSTRALIA (AS) - 559",
					"code": "559"
				},
				{
					"countryName": "Colombia (Col) - 559",
					"code": "559"
				},
				{
					"countryName": "Brazil (Bzl) - 559",
					"code": "559"
				},*/

				{
					"countryName": "India - Vizag SEZ - 571",
					"code": "571"
				}
				/*,
				{
					"countryName": "Beverly - US - 545",
					"code": "545"
				},
				{
					"countryName": "Mirfield - UK - 543",
					"code": "543"
				},
				{
					"countryName": "Cambridge - UK - 542",
					"code": "542"
				},
				{
					"countryName": "Russia - UK - 557",
					"code": "557"
				},
				{
					"countryName": "South Africa - 562",
					"code": "562"
				},
				{
					"countryName": "Ukraine - 560",
					"code": "560"
				},
				{
					"countryName": "Shreveport - 555",
					"code": "555"
				},
				{
					"countryName": "Princeton - US - 581",
					"code": "581"
				}*/
				              ]
		};
		countryExtJson.setData(countryExtCodeJson);
		sap.ui.getCore().setModel(countryExtJson, "countryExtCodeModel");
       sap.ui.getCore().byId(parentId).setBusy(true);
		jQuery.sap.delayedCall(4000, this, function() {
              
        	var statePerJson = new sap.ui.model.json.JSONModel();
				var statePerSet = "SHStateSet";
			
				oDataModel.read(statePerSet, null, null, false, function(r) {
					statePerJson.setData(r);
				});

				sap.ui.getCore().setModel(statePerJson, "StatePerModel");
				
		var extJson = new sap.ui.model.json.JSONModel();
		var extSet = "SHPhoneCodeSet";
		oDataModel.read(extSet, null, null, false, function(r) {
			extJson.setData(r);
		});
		sap.ui.getCore().setModel(extJson, "phoneCodeModel");

		sap.ui.getCore().getModel("phoneCodeModel").setSizeLimit("1000");

		var stdJson = new sap.ui.model.json.JSONModel();
		var stdSet = "SHSTDCodeSet";
		oDataModel.read(stdSet, null, null, false, function(r) {
			stdJson.setData(r);
		});
		sap.ui.getCore().setModel(stdJson, "stdCodeModel");

		sap.ui.getCore().getModel("stdCodeModel").setSizeLimit("1000");

		//State binding for value help of address dialog

		var stateJson = new sap.ui.model.json.JSONModel();
		var stateSet = "SHStateSet";
		oDataModel.read(stateSet, null, null, false, function(r) {
			stateJson.setData(r);
		});
		sap.ui.getCore().setModel(stateJson, "StateModel");
		//Country binding for value help of address dialog
		var countryJson = new sap.ui.model.json.JSONModel();
		var countrySet = "SHCountrySet";
		oDataModel.read(countrySet, null, null, false, function(r) {
			countryJson.setData(r);
		});

		sap.ui.getCore().setModel(countryJson, "CountryModel");

		//Certificate binding for value help of Institute dialog

		var certiJson = new sap.ui.model.json.JSONModel();
		var certificateSet = "SHCertificateSet";
		oDataModel.read(certificateSet, null, null, false, function(r) {
			certiJson.setData(r);
		});

		sap.ui.getCore().setModel(certiJson, "CertificateModel");

		//Institute binding for value help of Institute dialog
		var instituteJson = new sap.ui.model.json.JSONModel();
		var instituteSet = "SHInstituteSet";
		oDataModel.read(instituteSet, null, null, false, function(r) {
			instituteJson.setData(r);
		});

		sap.ui.getCore().setModel(instituteJson, "InstituteModel");

		//Job binding for value help if Employer dialog
		var jobJson = new sap.ui.model.json.JSONModel();
		var jobSet = "SHJobSet";
		oDataModel.read(jobSet, null, null, false, function(r) {
			jobJson.setData(r);
		});

		sap.ui.getCore().setModel(jobJson, "JobModel");

		//EmployerModel
		var employerJson = new sap.ui.model.json.JSONModel();
		var employerSet = "SHEmployerSet";
		oDataModel.read(employerSet, null, null, false, function(r) {
			employerJson.setData(r);
		});

		sap.ui.getCore().setModel(employerJson, "EmployerModel");

		//IndustryModel
		var industryJson = new sap.ui.model.json.JSONModel();
		var industrySet = "SHIndustrySet";
		oDataModel.read(industrySet, null, null, false, function(r) {
			industryJson.setData(r);
		});

		sap.ui.getCore().setModel(industryJson, "IndustryModel");

		
		
    	sap.ui.getCore().byId(parentId).setBusy(false);
			});
		this.buildUI();
	},

	buildUI: function() {
		var t = this;
		p = hcm.people.profile.util.UIHelper.getPernr();
		var i = false;
		var d = hcm.people.profile.util.UIHelper.getODataModel();
		var q = "EmployeeDataSet('" + p + "')/PersonalInfoSet";

		d.read(q, null, null, true, function(r) {
			a = r.results;
			g = [];
			b = [];
			var s = hcm.people.profile.util.UIHelper.getSecPersInfo();
			if (a.length > 0) {
				a.forEach(function(c) {
					if (b[c.Groupname]) {
						b[c.Groupname].vals.push({
							"Fieldlabel": c.Fieldlabel,
							"Fieldvalue": c.Fieldvalue,
							"SubGroupname": c.SubGroupname,
							"ObjectID": c.ObjectID
						});
					} else {
						g.push(c.Groupname);
						b[c.Groupname] = {
							"groupName": c.Groupname,
							vals: []
						};
						b[c.Groupname].vals.push({
							"Fieldlabel": c.Fieldlabel,
							"Fieldvalue": c.Fieldvalue,
							"SubGroupname": c.SubGroupname,
							"ObjectID": c.ObjectID
						});

					}
				});

				g.forEach(function(c) {

					if (c === "Personal data" || c === "Personal Data") {
						var form;
						arrayList = {};
						arrayObj = [];
						arrayList["results"] = arrayObj;
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%",
							content: [
						   
						form = new sap.ui.layout.form.SimpleForm({
									maxContainerCols: 2,
									editable: false,
									layout: "ResponsiveGridLayout"
								}),
						new sap.m.Button({
									text: "Edit",
									width: "150px",
									type: "Emphasized",
									press: function() {
										var nameModel = new sap.ui.model.json.JSONModel();
										nameModel.setData(arrayList);
										var personalinfoModel = new sap.ui.model.json.JSONModel();
										oDataModel.read("/SHMaritalStatusSet", null, null, false, function(odata) {
											personalinfoModel.setData(odata);
										});
										sap.ui.getCore().setModel(personalinfoModel, "personalinfoModel");
										sap.ui.getCore().setModel(nameModel, "nameModel");

										var dialog = sap.ui.getCore().byId("idDialogPerDetails");
										var fN = sap.ui.getCore().getModel("nameModel").getData().results[0];
										var lN = sap.ui.getCore().getModel("nameModel").getData().results[1];
										var marStatus = sap.ui.getCore().getModel("nameModel").getData().results[5];
										var marDOM = sap.ui.getCore().getModel("nameModel").getData().results[6];
										var countryBirth = sap.ui.getCore().getModel("nameModel").getData().results[4];
										var state = sap.ui.getCore().getModel("nameModel").getData().results[3];
										var birthPlace = sap.ui.getCore().getModel("nameModel").getData().results[2];

										if (dialog === undefined) {
											dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.PerDetails", t.getView().getController());
											this.addDependent();
										}
										dialog.open();
										sap.ui.getCore().byId("idFirstName").setValue(fN);
										sap.ui.getCore().byId("idLastName").setValue(lN);
										if (lN !== ".") {
											sap.ui.getCore().byId("idFirstName").setEnabled(false);
											sap.ui.getCore().byId("idLastName").setEnabled(false);
											sap.ui.getCore().byId("idpersDetails").setTitle("");
										}
										if (marStatus === "Marr.") {
											sap.ui.getCore().byId("idMarStatus").setSelectedKey("1");
											sap.ui.getCore().byId("idDOM").setValue(marDOM)
										}
										if (marStatus === "Single") {
											sap.ui.getCore().byId("idMarStatus").setSelectedKey("0");
											sap.ui.getCore().byId("idDOM").setEditable(false);

										}
										sap.ui.getCore().byId("idCountryPer").setValue(countryBirth);
										sap.ui.getCore().byId("idStatePer").setValue(state);
										sap.ui.getCore().byId("idBirth").setValue(birthPlace);

										//									sap.ui.getCore().byId("idLastName").setValue(lN);
									}
								})
						         ]
						});

						t.buildContent(form, g, c, b);

						b[c].vals.forEach(function(h) {
							if (h.Fieldlabel === "First name") {
								arrayObj.push(h.Fieldvalue);
							}
							if (h.Fieldlabel === "Last name") {
								arrayObj.push(h.Fieldvalue);
							}

							if (h.Fieldlabel === "Date of Marriage") {
								arrayObj.push(h.Fieldvalue);
							}

							if (h.Fieldlabel === "Marital Status") {
								arrayObj.push(h.Fieldvalue);
							}
							if (h.Fieldlabel === "Birthplace") {
								arrayObj.push(h.Fieldvalue);
							}
							if (h.Fieldlabel === "Country of Birth") {
								arrayObj.push(h.Fieldvalue);
							}
							if (h.Fieldlabel === "State") {
								arrayObj.push(h.Fieldvalue);
							}
						});
					}
					if (c === "Addresses") {
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%"
						});

						/*e.addContent(new sap.m.Button({
							text: "Add / Edit",
							width: "150px",
							type: "Emphasized",
							press: function() {
								var dialog = sap.ui.getCore().byId("idDialogAddressDetails");
								if (dialog === undefined) {
									dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.AddressDetails", t.getView().getController());
									this.addDependent();
								}
								
								var oBtn = sap.ui.getCore().byId("fileUploader");
                            var sHtml = "Upload address proofs such as:<br>";
                            sHtml += "<ul>";
                            sHtml += "<li>Aadhar card</li>";
                            sHtml += "<li>Passport</li>";
                            sHtml += "<li>Gas bill</li>";
                            sHtml += "<li>Bank statements</li>";
                            sHtml += "</ul>";
                            var oRichTooltip = new sap.ui.commons.RichTooltip({
                                            text: sHtml,
                                            title: "Quick Help"
                            });
                            oRichTooltip.setAtPosition("end top");
                            oBtn.setTooltip(oRichTooltip);

								var pModel = sap.ui.getCore().getModel("temporaryModel");
								for (var i = 0; i < pModel.item.length; i++) {

									if (pModel.item[i].title === "House No/Street") {
										sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "2nd Address Line") {
										sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "City") {
										sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "District") {
										sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Region") {
										sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Postal Code") {
										sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Country Name") {
										sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Telephone Number") {
										sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
									}
								}

								dialog.open();
							}
						}));*/
						var jsonObj = {};
						jsonObj.item = new Array();
						var label = "";
						var value = "";
						var jsonObjTemp = {};
						jsonObjTemp.item = new Array();
						var labelTemp = "";
						var valueTemp = "";

						var jsonObjEmer = {};
						jsonObjEmer.item = new Array();
						var labelEmer = "";
						var valueEmer = "";
						var addressForm, prevSubGrpName;
						var oPanel;
						var headerTextVal ;
						b[c].vals.forEach(function(h) {

							if (h.SubGroupname !== prevSubGrpName) {
								var that = this;
								if(h.SubGroupname === "Emergency Address" || h.SubGroupname === "Emergency Contact")
								{
								    headerTextVal = h.SubGroupname;
								}
								else
								{
								    headerTextVal = "*"+h.SubGroupname;
								}
								e.addContent(

									oPanel = new sap.m.Panel({
										expandable: true,
										expanded: false,
										width: "100%",
										headerText: h.SubGroupname,
										content: [
											 addressForm = new sap.ui.layout.form.SimpleForm({
												editable: false,
												maxContainerCols: 2,
												layout: "ResponsiveGridLayout"
											})
											],

										headerToolbar: [

								            new sap.m.Toolbar({
												content: [
								                new sap.m.Title({
														text: h.SubGroupname
													}),
								                    new sap.ui.core.Icon({
														src: "sap-icon://edit",
														press: function(oEvent) {

															var dialog = sap.ui.getCore().byId("idDialogAddressDetails");
															if (dialog === undefined) {
																dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.AddressDetails", t.getView().getController());
															this.addDependent();
															}
															var panelText = oEvent.getSource().getParent().getParent().mProperties.headerText;

															if (panelText === "Local/Temporary address" || panelText === "Local/Temporary Address") {
																panelText = "Local address";
																sap.ui.getCore().byId("idDialogAddressDetails").setTitle("Edit Local/Temporary Address Details");
															} else if (panelText === "Permanent residence" || panelText === "Permanent Address") {
																panelText = "Permanent address";
																sap.ui.getCore().byId("idDialogAddressDetails").setTitle("Edit Permanent Address Details");

															} else if (panelText === "Emergency Address" || panelText === "Emergency Contact") {
																panelText = "Emergency Address";
																sap.ui.getCore().byId("idDialogAddressDetails").setTitle("Edit Emergency Address Details");
															}
															t.addressSelect(panelText)

																var oBtn = sap.ui.getCore().byId("idHelpAdd");
															var sHtml = "Upload address proofs such as:<br>";
															sHtml += "<ul>";
															sHtml += "<li>Aadhar card</li>";
															sHtml += "<li>Passport</li>";
															sHtml += "<li>Gas bill</li>";
															sHtml += "<li>Bank statements</li>";
															sHtml += "</ul>";
															var oRichTooltip = new sap.ui.commons.RichTooltip({
																text: sHtml,
																title: "Quick Help"
															});
															oRichTooltip.setAtPosition("end top");
															oBtn.setTooltip(oRichTooltip);

															/*	var pModel = sap.ui.getCore().getModel("temporaryModel");
								for (var i = 0; i < pModel.item.length; i++) {

									if (pModel.item[i].title === "House No/Street") {
										sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "2nd Address Line") {
										sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "City") {
										sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "District") {
										sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Region") {
										sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Postal Code") {
										sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Country Name") {
										sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
									} else if (pModel.item[i].title === "Telephone Number") {
										sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
									}
								}*/
       
															dialog.open();
														/*	var extJson = new sap.ui.model.json.JSONModel();
															var extSet = "SHPhoneCodeSet";
															oDataModel.read(extSet, null, null, false, function(r) {
																extJson.setData(r);
															});
															sap.ui.getCore().setModel(extJson, "phoneCodeModel");

															sap.ui.getCore().getModel("phoneCodeModel").setSizeLimit("1000");
															sap.ui.getCore().byId("idCouExt").setModel(extJson, "phoneCodeModel");

															var stdJson = new sap.ui.model.json.JSONModel();
															var stdSet = "SHSTDCodeSet";
															oDataModel.read(stdSet, null, null, false, function(r) {
																stdJson.setData(r);
															});
															sap.ui.getCore().setModel(stdJson, "stdCodeModel");

															sap.ui.getCore().getModel("stdCodeModel").setSizeLimit("1000");
															sap.ui.getCore().byId("idStd").setModel(stdJson, "stdCodeModel");*/
														}
													})
								                    ]

											})
								    ]

									})
							
							);
								prevSubGrpName = h.SubGroupname;

							}

							addressForm.addContent(new sap.m.Label({
								text: h.Fieldlabel
							}));
							addressForm.addContent(new sap.m.Text({
								text: h.Fieldvalue
							}));

							if (h.SubGroupname === "Permanent residence" || h.SubGroupname === "Permanent Address") {

								label = h.Fieldlabel;
								value = h.Fieldvalue;
								jsonObj.item.push({
									"title": label,
									"value": value

								});
							}

							if (h.SubGroupname === "Local/Temporary Address") {

								labelTemp = h.Fieldlabel;
								valueTemp = h.Fieldvalue;
								jsonObjTemp.item.push({
									"title": labelTemp,
									"value": valueTemp

								});
							}

							if (h.SubGroupname === "Emergency Address") {

								labelEmer = h.Fieldlabel;
								valueEmer = h.Fieldvalue;
								jsonObjEmer.item.push({
									"title": labelEmer,
									"value": valueEmer

								});
							}
						});
						sap.ui.getCore().setModel(jsonObj, "permanentModel");
						sap.ui.getCore().setModel(jsonObjTemp, "temporaryModel");
						sap.ui.getCore().setModel(jsonObjEmer, "emergencyModel");
                        }
					if (c === "Previous Employment Details" || c ==="Previous Employment Details") {
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%"
						});
						e.addContent(
							/*new sap.m.Button({
							text: "Add",
							type: "Emphasized",
							width: "150px",
							press: function() {
								var dialog = sap.ui.getCore().byId("idDialogEmployerDetails");
								if (dialog === undefined) {
									dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.EmployerDetails", t.getView().getController());
									this.addDependent();
								}
								dialog.open();
							}
						})*/
							/*new sap.m.Text({
								text: "For any error in data please write a Note to HR",
								addStyleClass:"noteText"
							})*/
						);
						var employerForm;
						var employer = [],
							design = [],
							startDate = [],
							endDate = [];
						b[c].vals.forEach(function(h) {
							if (h.Fieldlabel === "Company Name") {
								employer.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "Designation") {
								design.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "Start Date") {
								startDate.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "End Date") {
								endDate.push(h.Fieldvalue)
							}

						});
						var j = 0;
						b[c].vals.forEach(function(h) {

							if (h.Fieldlabel === "Company Name") {
								e.addContent(new sap.m.Panel({
									expandable: true,
									expanded: false,
									width: "auto",
									headerText: employer[j] + " - " + design[j] + " - " + startDate[j] + " - " + endDate[j],
									content: [
											 employerForm = new sap.ui.layout.form.SimpleForm({
											editable: false,
											maxContainerCols: 2,
											layout: "ResponsiveGridLayout"
										})
											]
								}));
								j = j + 1;
							}

							employerForm.addContent(new sap.m.Label({
								text: h.Fieldlabel
							}));
							employerForm.addContent(new sap.m.Text({
								text: h.Fieldvalue
							}));
						});
					}
					if (c === "Communication") {
						var communForm;
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%",
							content: [
							    /*new sap.m.Button({
									text: "Edit",
									width: "150px",
									type: "Emphasized",
									press: function() {
										var dialog = sap.ui.getCore().byId("idDialogCommDetails");
										if (dialog === undefined) {
											dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CommunicationDetails", t.getView().getController());
											this.addDependent();
										}
										
										dialog.open();
											var commJson = new sap.ui.model.json.JSONModel();
			var d = new sap.ui.model.odata.ODataModel(
				"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
			var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
			var mobCode = [];
			d.read(q, null, null, false, function(r) {
				mobCode.push(r.results[0].MobileCode);

				commJson.setData(mobCode);
			});
			sap.ui.getCore().setModel(commJson, "extModel");

			var extValue = "+"+sap.ui.getCore().getModel("extModel").getData()[0];
			
			sap.ui.getCore().byId("idPerMobExt").setValue(extValue);
			sap.ui.getCore().byId("idPerMobExt1").setValue(extValue);
			sap.ui.getCore().byId("idReqComm").setVisible(false);
			
										b[c].vals.forEach(function(h) {

											if (h.Fieldlabel === "Personal E-mail") {
												this.emailID = h.Fieldvalue;
												sap.ui.getCore().byId("idPerEmail").setValue(this.emailID);
											}
											else if(h.Fieldlabel === "Alternate Mobile number"){
											    this.altMob = h.Fieldvalue;
											     var mobAltValue = this.Mob.substring(3);
											    sap.ui.getCore().byId("idPerMob1").setValue(mobAltValue);
											}
												else if(h.Fieldlabel === "Mobile number"){
											    this.Mob = h.Fieldvalue;
											    var mobValue = this.Mob.substring(3);
											    sap.ui.getCore().byId("idPerMob").setValue(mobValue);
											}
											else if(h.Fieldlabel === "IP phone number"){
											    this.IP = h.Fieldvalue;
											    var IPValue = this.IP.substring(5);
											    sap.ui.getCore().byId("idIPPhone").setValue(IPValue); 
											}
											

										});
									}
								}),*/
							  communForm = new sap.ui.layout.form.SimpleForm({
								    maxContainerCols: 2,
									editable: true,
									layout: "ResponsiveGridLayout",
									labelSpanL: 3,
									labelSpanM: 3/*,
									emptySpanL: 2,
									emptySpanM: 2*/
								})
							    ]

						}).addStyleClass("sapUiSizeCompact");
						// communForm.addStyleClass("nonApproval");
						t.buildContent(communForm, g, c, b);
					}
					if (c === "Family Member Details") {
						var tableJsondata = {};
						var relateddata = [];
						tableJsondata["results"] = relateddata;
						var tableJsonObj = new sap.ui.model.json.JSONModel();
						tableJsonObj.setData(tableJsondata);
						var prevSubGrpName = "";
						var tmp, relationship, firstName, lastName, dob;
						var relationship = [],
							firstName = [],
							lastName = [],
							dob = [];
						var size = b[c].vals.length;
						b[c].vals.forEach(function(h) {
							if (h.SubGroupname !== prevSubGrpName) {
								relationship.push(h.SubGroupname);
								prevSubGrpName = h.SubGroupname;

							}
							if (prevSubGrpName === "Child") {
								relationship.push(h.SubGroupname);
							}
							if (h.Fieldlabel === "First name") {
								firstName.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "Last name") {
								lastName.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "Date of Birth" || h.Fieldlabel === "Date of birth") {
								dob.push(h.Fieldvalue)
							}

						});

						for (var val = 0; val < size / 3; val++) {
							tmp = {
								'Relationship': relationship[val],
								'firstName': firstName[val],
								'lastName': lastName[val],
								'dob': dob[val]
							};

							relateddata.push(tmp);
						}
						var table;
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%",
							content: [
							 table = new sap.m.Table({
									inset: true,
									columns: [
				        new sap.m.Column({
											header: new sap.m.Label({
												text: "Relationship"
											}),
											minScreenWidth: "Tablet",
											demandPopin: true,
											hAlign: "Left"
										}),
				        new sap.m.Column({
											header: new sap.m.Label({
												text: "First Name"
											}),
											minScreenWidth: "Tablet",
											demandPopin: true,
											hAlign: "Left"
										}),
				        new sap.m.Column({
											header: new sap.m.Label({
												text: "Last Name"
											}),
											minScreenWidth: "Tablet",
											demandPopin: true,
											hAlign: "Left"
										}),
				        new sap.m.Column({
											header: new sap.m.Label({
												text: "Date of Birth"
											}),
											minScreenWidth: "Tablet",
											demandPopin: true,
											hAlign: "Left"
										})
				    ]
								}),
								              new sap.m.Button({
									text: "Add",
									width: "150px",
									type: "Emphasized",
									press: function() {

										var dialog = sap.ui.getCore().byId("idDialogFamilyDetails");
										if (dialog === undefined) {
											dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.FamilyDetails", t.getView().getController());
											this.addDependent();
										}
										sap.ui.getCore().byId("idReqFam").setVisible(false);
										dialog.open();

									}
								})
							         ]
						});

						table.setModel(tableJsonObj);
						table.bindAggregation("items", {
							path: "/results",
							template: new sap.m.ColumnListItem({
								cells: [
						                    new sap.m.Label({
										text: "{Relationship}"
									}),
						                    new sap.m.Label({
										text: "{firstName}"
									}),
						                    new sap.m.Label({
										text: "{lastName}"
									}),
						                    new sap.m.Label({
										text: "{dob}"
									})
						            ]
							})
						});

					}

					if (c === "Education Details") {
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%"
						});
						var degree = [],
							spec = [],
							insti = [],
							endDate = [];
						b[c].vals.forEach(function(h) {
							if (h.Fieldlabel === "Degree") {
								degree.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "Specialisation") {
								spec.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "University/Institute") {
								insti.push(h.Fieldvalue)
							}
							if (h.Fieldlabel === "End Date") {
								endDate.push(h.Fieldvalue)
							}

						});
						
						var k = 0;
						var eduForm;
						b[c].vals.forEach(function(h) {
							if (h.Fieldlabel === "Degree") {
								e.addContent(new sap.m.Panel({
									expandable: true,
									expanded: false,
									width: "auto",
									headerText: degree[k] + " - " + spec[k] + " - " + insti[k] + " - " + endDate[k],
									content: [
											 eduForm = new sap.ui.layout.form.SimpleForm({
											minWidth: 1024,
											maxContainerCols: 2,
											editable: false,
											layout: "ResponsiveGridLayout",
											labelSpanL: 3,
											labelSpanM: 3,
											emptySpanL: 4,
											emptySpanM: 4,
											columnsL: 1,
											columnsM: 1
										})
											]
								}));
								k = k + 1;

							}
							if (h.Fieldlabel !== "Duration of course" && h.Fieldlabel !== "Unit of time/meas.") {
								eduForm.addContent(new sap.m.Label({
									text: h.Fieldlabel
								}));
								eduForm.addContent(new sap.m.Text({
									text: h.Fieldvalue
								}));
							}
						});

						e.addContent(new sap.m.Button({
							text: "Add",
							type: "Emphasized",
							width: "150px",
							press: function() {
								var timeMeasureJson = new sap.ui.model.json.JSONModel();
								var time = "SHTimeMeasureSet";
								var timeArr = [];
								oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

								oDataModel.read(time, null, null, false, function(data) {
									for (var i = 0; i <= data.results.length - 1; i++) {
										if (data.results[i].TimeMeasureUnitTxt === "Years") {
											timeArr.push(data.results[i]);
										}
										if (data.results[i].TimeMeasureUnitTxt === "Semester") {
											timeArr.push(data.results[i]);
										}
										if (data.results[i].TimeMeasureUnitTxt === "Months") {
											timeArr.push(data.results[i]);
										}
										if (data.results[i].TimeMeasureUnitTxt === "Weeks") {
											timeArr.push(data.results[i]);
										}
										if (data.results[i].TimeMeasureUnitTxt === "Days") {
											timeArr.push(data.results[i]);
										}
									}

								});

								var timeList = {
									timeres: timeArr
								};

								timeMeasureJson.setData(timeList);
								var dialog = sap.ui.getCore().byId("idDialogInstituteDetails");
								if (dialog === undefined) {
									dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.InstituteDetails", t.getView().getController());
									this.addDependent();
								}
								dialog.open();
								//sap.ui.getCore().byId("idUnit").setModel(timeMeasureJson, "TimeModel");
								sap.ui.getCore().byId("idReqIns").setVisible(false);
							}
						}));
					}
					/*if (c === "Edit IDs") {
						var idsForm;
						var e = new sap.ui.layout.VerticalLayout({
							width: "100%",
							content: [
							         
							       idsForm = new sap.ui.layout.form.SimpleForm({
									maxContainerCols: 2,
									editable: false,
									layout: "ResponsiveGridLayout"
								})
							           ]
						});

						b[c].vals.forEach(function(h) {

							idsForm.addContent(new sap.m.Label({
								text: h.Fieldlabel
							}));
							idsForm.addContent(new sap.m.Text({
								text: h.Fieldvalue
							}))
						});

					}*/

					if (!i) {
						var f = hcm.people.profile.util.UIHelper.getSubSecPersInfo();
						f.setTitle(c);
						f.insertBlock(e);
						i = true;
					} else {
						var n = new sap.uxap.ObjectPageSubSection({
							title: c
						});
						n.insertBlock(e);
						s.addSubSection(n);
					}
				});
			} else {
				t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERS_NO_DATA"));
				t.byId("dispStatusMsg").setVisible(true);
			}
		}, function(r) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
		});
	},
	onSelectingMaritalStatus: function(oEvent) {
		var key = oEvent.getSource().getSelectedKey();
		if (key === "0") {
			sap.ui.getCore().byId("idDOM").setEditable(false);
		} else {
			sap.ui.getCore().byId("idDOM").setEditable(true);

		}

	},
	editContent: function(e, g, c, b) {
		var prevSubGrpName = "";
		e.removeAllContent();
		if (c === "Communication") {
			b[c].vals.forEach(function(h) {
				if (h.SubGroupname !== prevSubGrpName) {
					e.addContent(new sap.ui.core.Title({
						text: h.SubGroupname
					}));

					prevSubGrpName = h.SubGroupname;
				}

				e.addContent(new sap.m.Label({
					text: h.Fieldlabel,
					textDirection: "LTR"
				}));
				if (h.Fieldlabel === "E-mail") {
					e.addContent(new sap.m.Input({
						value: h.Fieldvalue,
						type: "Email",
						width: "300px"

					}));
				} else if (h.Fieldlabel === "Mobile Phone") {
					e.addContent(new sap.m.Input({
						value: "+91",
						layoutData: [new sap.ui.layout.GridData({
							span: "L1 M1 S2"
						})],
						maxLength: 3

					}));
					e.addContent(new sap.m.Input({
						value: h.Fieldvalue,
						type: "Number",
						width: "300px"
					}));
				} else if (h.Fieldlabel === "IP phone number") {
					e.addContent(new sap.m.Input({
						value: "(559)",
						layoutData: [new sap.ui.layout.GridData({
							span: "L1 M1 S2"
						})],
						maxLength: 5

					}));
					e.addContent(new sap.m.Input({
						value: h.Fieldvalue,
						type: "Number",
						width: "300px"
					}));
				} else {
					e.addContent(new sap.m.Input({
						value: h.Fieldvalue,
						width: "300px"
					}));
				}
			});
		}
	},
	buildContent: function(e, g, c, b) {
		var prevSubGrpName = "";
		var that = this;
		b[c].vals.forEach(function(h) {

			if (h.SubGroupname !== prevSubGrpName) {
				e.addContent(new sap.ui.core.Title({
					text: h.SubGroupname
				}));

				prevSubGrpName = h.SubGroupname;
			}
			e.addContent(new sap.m.Label({
				text: h.Fieldlabel
			}));
			if (h.Fieldlabel === "Mobile number") {
				e.addContent(
					new sap.ui.layout.HorizontalLayout({
						width: "100%",
						content: [
				    new sap.m.Text({
								text: h.Fieldvalue,
								width: "200px"

							}),

			        new sap.ui.core.Icon({
								src: "sap-icon://edit",
								press: function() {
									var dialog = sap.ui.getCore().byId("idDialogCommDetails");
									if (dialog === undefined) {
										dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CommunicationDetails", that.getView().getController());
										//	that.addDependent();
									}

									dialog.open();
									sap.ui.getCore().byId("idDialogCommDetails").setTitle("Edit Mobile number");
									var commJson = new sap.ui.model.json.JSONModel();
									var d = new sap.ui.model.odata.ODataModel(
										"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
									var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
									var mobCode = [];
									d.read(q, null, null, false, function(r) {
										mobCode.push(r.results[0].MobileCode);

										commJson.setData(mobCode);
									});
									sap.ui.getCore().setModel(commJson, "extModel");
									var text = h.Fieldlabel;

									that.CommSelect(text)

									sap.ui.getCore().byId("idComm").setSelectedKey("Mobile Phone");
									var extValue = "+" + sap.ui.getCore().getModel("extModel").getData()[0];

									//sap.ui.getCore().byId("idPerMobExt").setValue(extValue);
									//sap.ui.getCore().byId("idPerMobExt1").setValue(extValue);
									sap.ui.getCore().byId("idReqComm").setVisible(false);
									if(h.Fieldvalue === "No Data"){
									    sap.ui.getCore().byId("idPerMob").setValue("");
									}
									else
									{   var mobValue ;
									    if(h.Fieldvalue.length ===13){
									         mobValue = h.Fieldvalue.substring(3,13);
						                    sap.ui.getCore().byId("idPerMob").setValue(mobValue);
									    }
									    else
									    {
									          mobValue = h.Fieldvalue;
						                    sap.ui.getCore().byId("idPerMob").setValue(mobValue);
									    }
										
									}
								}
							})

                ]
					}).addStyleClass("myCustomCss"));
			} else if (h.Fieldlabel === "Marital Status") {
				var status;
				if (h.Fieldvalue === "Marr.") {
					status = "Married";
				} else {
					status = "Single";
				}
				e.addContent(new sap.m.Text({
					//layoutData:new sap.ui.layout.GridData({span:"L2 M2 S4"}),
					text: status,
					width: "300px"

				}));

			} else if (h.Fieldlabel === "IP phone number") {
				e.addContent(
				  	new sap.ui.layout.HorizontalLayout({
						width: "100%",
						content: [
				    
				    
				    new sap.m.Text({
					text: h.Fieldvalue,
					width: "200px"

				}),

				new sap.ui.core.Icon({
					src: "sap-icon://edit",
					press: function() {
						var dialog = sap.ui.getCore().byId("idDialogCommDetails");
						if (dialog === undefined) {
							dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CommunicationDetails", that.getView().getController());
							//	that.addDependent();
						}

						dialog.open();
						sap.ui.getCore().byId("idDialogCommDetails").setTitle("Edit IP phone number");
						var text = h.Fieldlabel;

						that.CommSelect(text)
						var commJson = new sap.ui.model.json.JSONModel();
						var d = new sap.ui.model.odata.ODataModel(
							"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
						var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
						var mobCode = [];
						d.read(q, null, null, false, function(r) {
							mobCode.push(r.results[0].MobileCode);

							commJson.setData(mobCode);
						});
						sap.ui.getCore().setModel(commJson, "extModel");
						sap.ui.getCore().byId("idComm").setSelectedKey("IP phone number");
						var extValue = "+" + sap.ui.getCore().getModel("extModel").getData()[0];

						//sap.ui.getCore().byId("idPerMobExt").setValue(extValue);
						//sap.ui.getCore().byId("idPerMobExt1").setValue(extValue);
						sap.ui.getCore().byId("idReqComm").setVisible(false);
						if(h.Fieldvalue === "No Data"){
									    sap.ui.getCore().byId("idIPPhone").setValue("");
									}
									else
									{
					     var value = h.Fieldvalue.substring(5,9);
						var code = h.Fieldvalue.substring(1,4);
						sap.ui.getCore().byId("idIPPhExt").setSelectedKey(code);
						sap.ui.getCore().byId("idIPPhone").setValue(value);
									}
					}
				})
                ]
					}));
			
			} else if (h.Fieldlabel === "Personal E-mail") {
				e.addContent(
				  	new sap.ui.layout.HorizontalLayout({
						width: "100%",
						content: [
				    
				    new sap.m.Text({
					text: h.Fieldvalue,
					width: "200px"

				}),

				    new sap.ui.core.Icon({
					src: "sap-icon://edit",
					press: function() {

						var dialog = sap.ui.getCore().byId("idDialogCommDetails");
						if (dialog === undefined) {
							dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CommunicationDetails", that.getView().getController());
							//that.addDependent();
						}

						dialog.open();
						var text = h.Fieldlabel;

						that.CommSelect(text)
						sap.ui.getCore().byId("idDialogCommDetails").setTitle("Edit Personal Email");
						var commJson = new sap.ui.model.json.JSONModel();
						var d = new sap.ui.model.odata.ODataModel(
							"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
						var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
						var mobCode = [];
						d.read(q, null, null, false, function(r) {
							mobCode.push(r.results[0].MobileCode);

							commJson.setData(mobCode);
						});
						sap.ui.getCore().setModel(commJson, "extModel");
						sap.ui.getCore().byId("idComm").setSelectedKey("Personal E-mail");
						var extValue = "+" + sap.ui.getCore().getModel("extModel").getData()[0];

						//sap.ui.getCore().byId("idPerMobExt").setValue(extValue);
						//sap.ui.getCore().byId("idPerMobExt1").setValue(extValue);
						sap.ui.getCore().byId("idReqComm").setVisible(false);
							if(h.Fieldvalue === "No Data"){
									    sap.ui.getCore().byId("idPerEmail").setValue("");
									}
									else
									{
						sap.ui.getCore().byId("idPerEmail").setValue(h.Fieldvalue);
									}
					}
				})
				
                ]
					}));
			
			} else if (h.Fieldlabel === "Alternate Mobile number") {
				e.addContent(
				  	new sap.ui.layout.HorizontalLayout({
						width: "100%",
						content: [
				    
				    new sap.m.Text({
					text: h.Fieldvalue,
					width: "200px"

				}),

				new sap.ui.core.Icon({
					src: "sap-icon://edit",
					press: function() {

						var dialog = sap.ui.getCore().byId("idDialogCommDetails");
						if (dialog === undefined) {
							dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CommunicationDetails", that.getView().getController());
							//	that.addDependent();
						}

						dialog.open();
						var text = h.Fieldlabel;

						that.CommSelect(text)
						sap.ui.getCore().byId("idDialogCommDetails").setTitle("Edit Alternate mobile number");
						var commJson = new sap.ui.model.json.JSONModel();
						var d = new sap.ui.model.odata.ODataModel(
							"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
						var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
						var mobCode = [];
						d.read(q, null, null, false, function(r) {
							mobCode.push(r.results[0].MobileCode);

							commJson.setData(mobCode);
						});
						sap.ui.getCore().setModel(commJson, "extModel");
						sap.ui.getCore().byId("idComm").setSelectedKey("Alternate mobile number");
						var extValue = "+" + sap.ui.getCore().getModel("extModel").getData()[0];

						//sap.ui.getCore().byId("idPerMobExt").setValue(extValue);
						//sap.ui.getCore().byId("idPerMobExt1").setValue(extValue);
						sap.ui.getCore().byId("idReqComm").setVisible(false);
							if(h.Fieldvalue === "No Data"){
									    sap.ui.getCore().byId("idPerMob").setValue("");
									}
									else
									{
									    var mobValue ;
									    if(h.Fieldvalue.length === 13){
									        	mobValue = h.Fieldvalue.substring(3,13);
					                        	sap.ui.getCore().byId("idPerMob").setValue(mobValue);
									    }
									    else
									    {
									        	mobValue = h.Fieldvalue;
					                        	sap.ui.getCore().byId("idPerMob").setValue(mobValue);
									    }
					
									}

					}
				})
                    ]
					}));
			
			} else {

				e.addContent(new sap.m.Text({

					text: h.Fieldvalue

				}));
			}
		});
	},

	onClose: function() {
		this.setValFamily();
		sap.ui.getCore().byId("idFN").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idLN").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("DP6").setValueState(sap.ui.core.ValueState.None);
		var dialog = sap.ui.getCore().byId("idDialogFamilyDetails");
		dialog.close();
	},
	onCloseInstitute: function() {
		this.setValInstitute();

		sap.ui.getCore().byId("idCertificate").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idInstitute").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idEduEst").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idBranch").setValueState(sap.ui.core.ValueState.None);
		//sap.ui.getCore().byId("idDur").setValueState(sap.ui.core.ValueState.None);
		//	sap.ui.getCore().byId("idUnit").setSelectedItem();
		sap.ui.getCore().byId("idCountryIns").setValueState(sap.ui.core.ValueState.None);
		//	sap.ui.getCore().byId("idHighestEdu").setSelectedItem();
		sap.ui.getCore().byId("startDate").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("endDate").setValueState(sap.ui.core.ValueState.None);
		fileCollection = new Array();
		this.setFileAttachments(fileCollection);
		var dialog = sap.ui.getCore().byId("idDialogInstituteDetails");
		dialog.close();
	},

	onCloseEmployer: function() {
		this.setValEmployer();
		sap.ui.getCore().byId("idJob").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idEmployer").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idIndustry").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCityEmp").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("startDateEmp").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("endDateEmp").setValueState(sap.ui.core.ValueState.None);
		fileCollection = new Array();
		this.setFileAttachments(fileCollection);
		var dialog = sap.ui.getCore().byId("idDialogEmployerDetails");
		dialog.close();
	},
	onCloseAddress: function() {
		this.setValAddress();
		sap.ui.getCore().byId("idContactName").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idAddLine").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.None);
		fileCollection = new Array();
		this.setFileAttachments(fileCollection);
		sap.ui.getCore().byId("idSameAddr").setSelected(false);
		sap.ui.getCore().byId("idradio1").setSelected(false);
		sap.ui.getCore().byId("idradio2").setSelected(false);
		sap.ui.getCore().byId("emrBut").setVisible(false);
		sap.ui.getCore().byId("idAddress").setSelectedKey("Local address");
		var dialog = sap.ui.getCore().byId("idDialogAddressDetails");
		dialog.close();
	},
	SubmitAddress: function() {
		var selectedAddressVal = sap.ui.getCore().byId("idAddress").getSelectedKey();
		var houseNoVal = sap.ui.getCore().byId("idHouseNo").getValue();
		var addLineVal = sap.ui.getCore().byId("idAddLine").getValue();
		var cityVal = sap.ui.getCore().byId("idCity").getValue();
		var districtVal = sap.ui.getCore().byId("idDistrict").getValue();
		var postalCodeVal = sap.ui.getCore().byId("idPostalCode").getValue();
		var regionVal = sap.ui.getCore().byId("idRegion").getValue();
		var countryVal = sap.ui.getCore().byId("idCountryAddress").getValue();
		var telephNum = sap.ui.getCore().byId("idTelNum").getValue();
		var contactName = sap.ui.getCore().byId("idContactName").getValue();
		var careOf = sap.ui.getCore().byId("idCareOf").getValue();

		var phone_regExp = /^[0-9]+$/;
		var contactExt= telephNum;
	/*	if (selectedAddressVal === "Emergency Address" || selectedAddressVal === "Emergency contact") {
			if (sap.ui.getCore().byId("idLL").getEnabled()) {
				var stdCode = sap.ui.getCore().byId("idStd").getSelectedItem().getText();

				contactExt = stdCode + telephNum;
			} else {
				var countryCode = sap.ui.getCore().byId("idCouExt").getSelectedItem().getText();
				contactExt = countryCode + telephNum;
			}

		}*/
		var subType;
		var createPath = "AddressesSet";
		var count = 0;
		var updatePath;
		if (selectedAddressVal === "Local address") {
			subType = "2";
		} else if (selectedAddressVal === "Permanent address") {
			subType = "1";
		} else {
			subType = "4";
		}
		b["Addresses"].vals.forEach(function(h) {
			if (h.SubGroupname === selectedAddressVal) {
				if (h.SubGroupname === "Local address") {
					count = 1;
					updatePath = "AddressesSet('" + p + "')";

				}

				if (h.SubGroupname === "Permanent address") {

					count = 1;
					updatePath = "AddressesSet('" + p + "')";

				}

				if (h.SubGroupname === "Emergency Address") {

					count = 1;
					updatePath = "AddressesSet('" + p + "')";

				}

			}
		});
		p = "" + p;
		var addressObj;
		if (selectedAddressVal === "Local address" || selectedAddressVal === "Permanent address") {
			addressObj = {
				Employeenumber: p,
				Subtype: subType,
				ObjectID: "",
				StreetHouseNo: houseNoVal,
				AddressSecondLine: addLineVal,
				City: cityVal,
				District: districtVal,
				PostalCode: postalCodeVal,
				Country: countryVal,
				StateTxt: regionVal,
				TelNo: telephNum,
				ContactName: careOf
			};
		} else {
			addressObj = {
				Employeenumber: p,
				Subtype: subType,
				ObjectID: "",
				StreetHouseNo: houseNoVal,
				AddressSecondLine: addLineVal,
				City: cityVal,
				District: districtVal,
				PostalCode: postalCodeVal,
				Country: countryVal,
				StateTxt: regionVal,
				TelNo: contactExt,
				ContactName: contactName
			};
		}
		var r = true;
		if (houseNoVal === "") {
			sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idHouseNo").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.None);
		}

		if (districtVal === "") {
			sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idDistrict").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.None);
		}

		if (postalCodeVal !== "") {
			if (!postalCodeVal.match(phone_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Postal Code");
				sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idPostalCode").setValueStateText("Enter Value");
				r = false;
			} else {
				sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.None);
			}
		} else {
			sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idPostalCode").setValueStateText("Enter Value");
			r = false;
		}
	

		if (regionVal === "") {
			if (this.stateDialog !== regionVal && this.selectedState !== regionVal) {
				sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idRegion").setValueStateText("Enter Value");
				r = false;
			}
		} else {
			sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.None);
		}

		if (countryVal === "") {
			if (this.countryAddressDialog !== countryVal && this.selectedCountryAdd !== countryVal) {
				sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idCountryAddress").setValueStateText("Enter Value");
				r = false;
			}
		} else {
			sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.None);
		}

		if (telephNum !== "") {
			if (!telephNum.match(phone_regExp) || (telephNum.length > 10)) {
				sap.m.MessageBox.alert("Please provide Correct Phone Number");
				sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idTelNum").setValueStateText("Enter Value");
				r = false;
			} else {
				sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.None);
			}
		} else {
			sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idTelNum").setValueStateText("Enter Value");
			r = false;
		}
		/*	if(selectedAddressVal === "Emergency Address" || selectedAddressVal === "Emergency contact"){
		if (sap.ui.getCore().byId("idCouExt").getSelectedItem().getText() !== "") {
			sap.ui.getCore().byId("idCouExt").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCouExt").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCouExt").setValueState(sap.ui.core.ValueState.None);
		}
		if (sap.ui.getCore().byId("idStd").getValue() !== "") {
			sap.ui.getCore().byId("idStd").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idStd").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idStd").setValueState(sap.ui.core.ValueState.None);
		}
        	}*/
        	
		if (selectedAddressVal === "Permanent address") {
			if (sap.ui.getCore().byId("fileUploader").getVisible()) {
				if (this.getFileAttachments() === undefined || this.getFileAttachments() === null || this.getFileAttachments().length === 0) {
					//sap.m.MessageBox.error("Attachment is Mandatory");
					sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.Error);
					// sap.ui.getCore().byId("fileUploader").setValueStateText("Upload File");
					r = false;
				} else {
					sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
				}
			}
		}
		
			if (selectedAddressVal === "Local address") {
			if (sap.ui.getCore().byId("fileUploader").getVisible()) {
			    if(!sap.ui.getCore().byId("idSameAddr").getSelected()){
				if (this.getFileAttachments() === undefined || this.getFileAttachments() === null || this.getFileAttachments().length === 0) {
					//sap.m.MessageBox.error("Attachment is Mandatory");
					sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.Error);
					// sap.ui.getCore().byId("fileUploader").setValueStateText("Upload File");
					r = false;
				} else {
					sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
				}
			    }
			    else
			    {
			        	sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
			    }
			}
			
		}
		//contact name mandatory

		if (selectedAddressVal === "Emergency Address") {
			if (contactName === "") {
				sap.ui.getCore().byId("idContactName").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idContactName").setValueStateText("Enter Value");
				r = false;
			} else {
				sap.ui.getCore().byId("idContactName").setValueState(sap.ui.core.ValueState.None);
			}
		}

		if (r === false) {
			//	sap.m.MessageBox.error("Please fill all Mandatory Fields");
			sap.ui.getCore().byId("idReqAdd").setVisible(true);
		} else {
			sap.ui.getCore().byId("idReqAdd").setVisible(false);
		}

		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		var errorBodyAdd;
		if (r) {
		     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			var model = sap.ui.getCore().getModel("permanentModel");

			for (var i = 0; i < model.item.length; i++) {
				if (model.item[i].title === "House No/Street") {
					model.item[i].value = houseNoVal;
				} else if (model.item[i].title === "2nd Address Line") {
					model.item[i].value = addLineVal;
				} else if (model.item[i].title === "City") {
					model.item[i].value = cityVal;
				} else if (model.item[i].title === "District") {
					model.item[i].value = districtVal;
				} else if (model.item[i].title === "Region") {
					model.item[i].value = regionVal;
				} else if (model.item[i].title === "Postal Code") {
					model.item[i].value = postalCodeVal;
				} else if (model.item[i].title === "Country Name") {
					model.item[i].value = countryVal;
				} else if (model.item[i].title === "Telephone Number") {
					model.item[i].value = telephNum;
				}

			}

			if (count === 1) {
				batch.push(oDataModel.createBatchOperation(createPath, "POST", addressObj));
				/*oDataModel.create(createPath, addressObj, null, function(responseBody, sucRes) {

					result = true;
				}, function(failRes) {
					result = false;
					errorBodyAdd = JSON.parse(failRes.response.body);

				});*/
			} else {

				/*	oDataModel.create(createPath, addressObj, null, function(responseBody, sucRes) {
					result = true;

				}, function(failRes) {
					result = false;
					errorBodyAdd = JSON.parse(failRes.response.body);

				});*/
				batch.push(oDataModel.createBatchOperation(createPath, "POST", addressObj));
			}
			if (selectedAddressVal === "Local address") {
				var attchCreate = "AttachmentCreateSet";
				var oFiles = [];
				var attchObj = {};

				if (this.getFileAttachments() === undefined || this.getFileAttachments() === null) {

				} else {

					var fileData = this.getFileAttachments();

					if (fileData !== null) {

						attchObj = fileData[0];
					}
				}
				batch.push(oDataModel.createBatchOperation(attchCreate, "POST", attchObj));

				/*oDataModel.create(attchCreate, attchObj, null, function(responseBody, sucRes) {

					result = true;

				}, function(failRes) {
					result = false;
					errorBodyAdd = JSON.parse(failRes.response.body);
				});*/
			}
			/*if (result === true) {
				if (selectedAddressVal === "Local address" || selectedAddressVal === "Permanent address") {
					sap.m.MessageBox.success("This has been forwarded to HR for Approval");
					var addressDialog = sap.ui.getCore().byId("idDialogAddressDetails");

					this.setValAddress();
					addressDialog.close();
				} else {
					sap.m.MessageBox.success("Data saved successfully");
					var addressDialog = sap.ui.getCore().byId("idDialogAddressDetails");

					this.setValAddress();
					addressDialog.close();
					//location.reload(true);
				}

			} else {
				sap.m.MessageBox.error("\\n Message: " + errorBodyAdd.error.message.value);
			}*/
			var addressDialog = sap.ui.getCore().byId("idDialogAddressDetails");

			this.setValAddress();
			addressDialog.close();
		}

	},
	emerTel: function(oEvent) {
		var selectedVal = oEvent.getSource().sId;
		if (selectedVal === "idLL") {
			sap.ui.getCore().byId("idCouExt").setVisible(false);
			sap.ui.getCore().byId("idStd").setVisible(true);
		} else {
			sap.ui.getCore().byId("idStd").setVisible(false);
			sap.ui.getCore().byId("idCouExt").setVisible(true);
		}
	},
	addressSelect: function(panelText) {
		var selectedAddressVal = sap.ui.getCore().byId("idAddress").setSelectedKey(panelText);
		selectedAddressVal = sap.ui.getCore().byId("idAddress").getSelectedKey();
		if (selectedAddressVal === "Emergency contact" || selectedAddressVal === "Emergency Address") {
			sap.ui.getCore().byId("fileUploader").setVisible(true);
			sap.ui.getCore().byId("idFileTable").setVisible(false);
			sap.ui.getCore().byId("idBtnUpload").setVisible(true);
			sap.ui.getCore().byId("idLblName").setVisible(true);
			sap.ui.getCore().byId("idContactName").setVisible(true);
			sap.ui.getCore().byId("idSameAddr").setVisible(false);
			sap.ui.getCore().byId("idSameAddr").setSelected(false);
			sap.ui.getCore().byId("idPanelUpload").setVisible(false);
			sap.ui.getCore().byId("idlblcareOf").setVisible(false);
			sap.ui.getCore().byId("idCareOf").setVisible(false);
			sap.ui.getCore().byId("idradioB").setVisible(true);
			sap.ui.getCore().byId("idReqAdd").setVisible(false);
			sap.ui.getCore().byId("emrBut").setVisible(true);

			/*	sap.ui.getCore().byId("idem1").setVisible(true);
			sap.ui.getCore().byId("idem2").setVisible(true);
		sap.ui.getCore().byId("idradioC").setVisible(true);
			sap.ui.getCore().byId("idCouExt").setVisible(true);
			sap.ui.getCore().byId("idStd").setVisible(false);*/

			sap.ui.getCore().byId("idTelLbl").setText("Emergency Contact");
			sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idContactName").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idAddLine").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.None);
			var pModel = sap.ui.getCore().getModel("emergencyModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {
					if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idContactName").setValue(pModel.item[i].value);
					}

					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
						var stateJson = new sap.ui.model.json.JSONModel();
						var stateSet = "SHStateSet?$filter=Country eq '" + pModel.item[i].value + "' ";
						oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

						oDataModel.read(stateSet, null, null, false, function(r) {
							stateJson.setData(r);
						});

						sap.ui.getCore().setModel(stateJson, "StateModel");
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {
				sap.ui.getCore().byId("idContactName").setValue("");
				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
				sap.ui.getCore().byId("idCareOf").setValue("");
			}

		} else if (selectedAddressVal === "Permanent address") {
			sap.ui.getCore().byId("fileUploader").setVisible(true);
			sap.ui.getCore().byId("idFileTable").setVisible(false);
			sap.ui.getCore().byId("idBtnUpload").setVisible(true);
			sap.ui.getCore().byId("idLblName").setVisible(false);
			sap.ui.getCore().byId("idContactName").setVisible(false);
			sap.ui.getCore().byId("idSameAddr").setVisible(false);
			sap.ui.getCore().byId("idPanelUpload").setVisible(true);
			sap.ui.getCore().byId("idlblcareOf").setVisible(true);
			sap.ui.getCore().byId("idCareOf").setVisible(true);
			sap.ui.getCore().byId("idradioB").setVisible(false);
			sap.ui.getCore().byId("idReqAdd").setVisible(false);
		/*	sap.ui.getCore().byId("idCouExt").setVisible(false);
			sap.ui.getCore().byId("idStd").setVisible(false);
			sap.ui.getCore().byId("idem1").setVisible(false);
			sap.ui.getCore().byId("idem2").setVisible(false);*/
            sap.ui.getCore().byId("emrBut").setVisible(false);
			sap.ui.getCore().byId("idTelLbl").setText("Telephone Number");
			sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idContactName").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idAddLine").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.None);
		//	sap.ui.getCore().byId("idradioC").setVisible(false);
			var pModel = sap.ui.getCore().getModel("permanentModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {
					if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idCareOf").setValue(pModel.item[i].value);
					}

					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
						var stateJson = new sap.ui.model.json.JSONModel();
						var stateSet = "SHStateSet?$filter=Country eq '" + pModel.item[i].value + "' ";
						oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

						oDataModel.read(stateSet, null, null, false, function(r) {
							stateJson.setData(r);
						});

						sap.ui.getCore().setModel(stateJson, "StateModel");
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {
				sap.ui.getCore().byId("idCareOf").setValue("");
				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}

		} else if (selectedAddressVal === "Local address") {
			sap.ui.getCore().byId("fileUploader").setVisible(true);
			sap.ui.getCore().byId("idFileTable").setVisible(false);
			sap.ui.getCore().byId("idBtnUpload").setVisible(true);
			sap.ui.getCore().byId("idLblName").setVisible(false);
			sap.ui.getCore().byId("idContactName").setVisible(false);
			sap.ui.getCore().byId("idSameAddr").setVisible(true);
			sap.ui.getCore().byId("idSameAddr").setSelected(false);
			sap.ui.getCore().byId("idPanelUpload").setVisible(true);
			sap.ui.getCore().byId("idlblcareOf").setVisible(true);
			sap.ui.getCore().byId("idCareOf").setVisible(true);
			sap.ui.getCore().byId("idradioB").setVisible(false);
			sap.ui.getCore().byId("idReqAdd").setVisible(false);
			sap.ui.getCore().byId("emrBut").setVisible(false);
		/*	sap.ui.getCore().byId("idCouExt").setVisible(false);
			sap.ui.getCore().byId("idStd").setVisible(false);
			sap.ui.getCore().byId("idem1").setVisible(false);
			sap.ui.getCore().byId("idem2").setVisible(false);
			sap.ui.getCore().byId("idradioC").setVisible(false);*/
			sap.ui.getCore().byId("idTelLbl").setText("Telephone Number");
			sap.ui.getCore().byId("fileUploader").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCareOf").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idAddLine").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.None);
			var pModel = sap.ui.getCore().getModel("temporaryModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {
					if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idCareOf").setValue(pModel.item[i].value);
					}
					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
						var stateJson = new sap.ui.model.json.JSONModel();
						var stateSet = "SHStateSet?$filter=Country eq '" + pModel.item[i].value + "' ";
						oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

						oDataModel.read(stateSet, null, null, false, function(r) {
							stateJson.setData(r);
						});

						sap.ui.getCore().setModel(stateJson, "StateModel");
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {
				sap.ui.getCore().byId("idCareOf").setValue("");
				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}

		}

		//this.setValAddress();
	},
	populateAddr: function() {
		var checked = sap.ui.getCore().byId("idSameAddr").getSelected();
		if (checked) {
			var pModel = sap.ui.getCore().getModel("permanentModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {
					if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idCareOf").setValue(pModel.item[i].value);
					}
					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {

				sap.ui.getCore().byId("idContactName").setValue("");
				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}
		} else {
			var pModel = sap.ui.getCore().getModel("temporaryModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {
					if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idCareOf").setValue(pModel.item[i].value);
					}
					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {
				sap.ui.getCore().byId("idContactName").setValue("");
				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}
		}

	},
	setValAddress: function() {
		sap.ui.getCore().byId("idHouseNo").setValue();
			sap.ui.getCore().byId("idHouseNo").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idAddLine").setValue();
			sap.ui.getCore().byId("idAddLine").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCity").setValue();
			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idDistrict").setValue();
			sap.ui.getCore().byId("idDistrict").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idPostalCode").setValue();
			sap.ui.getCore().byId("idPostalCode").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idRegion").setValue();
			sap.ui.getCore().byId("idRegion").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCountryAddress").setValue();
			sap.ui.getCore().byId("idCountryAddress").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idTelNum").setValue();
			sap.ui.getCore().byId("idTelNum").setValueState(sap.ui.core.ValueState.None);
		var myjson = new sap.ui.model.json.JSONModel();
		var mydata = {
			"myFiles": [
	                                                                ]
		};
		myjson.setData(mydata);
		if (sap.ui.getCore().byId("idFileTable").getVisible()) {
			sap.ui.getCore().byId("idFileTable").setModel(myjson);
		}
		/*if(sap.ui.getCore().byId("idContactName").getVisible()){
				sap.ui.getCore().byId("idContactName").setValue("");
			}*/
        sap.ui.getCore().byId("idReqAdd").setVisible(false);
	},
	SubmitEmployer: function() {
		var c = "Previous Employment Details";
		var jobVal = sap.ui.getCore().byId("idJob").getValue();
		var EmployerVal = sap.ui.getCore().byId("idEmployer").getValue();
		var industryVal = sap.ui.getCore().byId("idIndustry").getValue();
		var cityEmpVal = sap.ui.getCore().byId("idCityEmp").getValue();
		var countryVal = sap.ui.getCore().byId("idCountry").getValue();
		var startDate = sap.ui.getCore().byId("startDateEmp").getDateValue();
		var endDate = sap.ui.getCore().byId("endDateEmp").getDateValue();

		var r = true;
		if (jobVal === "" || (this.jobDialog !== jobVal && this.selectedJob !== jobVal)) {
			sap.ui.getCore().byId("idJob").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idJob").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idJob").setValueState(sap.ui.core.ValueState.None);
		}

		if (EmployerVal === "") {
			sap.ui.getCore().byId("idEmployer").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idEmployer").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idEmployer").setValueState(sap.ui.core.ValueState.None);
		}

		if (industryVal === "" || (this.industryDialog !== industryVal && this.selectedIndustry !== industryVal)) {
			sap.ui.getCore().byId("idIndustry").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idIndustry").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idIndustry").setValueState(sap.ui.core.ValueState.None);
		}

		if (cityEmpVal === "") {
			sap.ui.getCore().byId("idCityEmp").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCityEmp").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCityEmp").setValueState(sap.ui.core.ValueState.None);
		}

		if (countryVal === "" || (this.countryEmpDialog !== countryVal && this.selectedCountry !== countryVal)) {
			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCountry").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.None);
		}

		if (startDate === "" || startDate === null) {
			sap.ui.getCore().byId("startDateEmp").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("startDateEmp").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("startDateEmp").setValueState(sap.ui.core.ValueState.None);
		}

		if (endDate === "" || endDate === null) {
			sap.ui.getCore().byId("endDateEmp").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("endDateEmp").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("endDateEmp").setValueState(sap.ui.core.ValueState.None);
		}

		var path = "OtherEmployersSet";
		var objectID = " ";
		b[c].vals.forEach(function(h) {
			if (h.SubGroupname === jobVal) {
				objectID = h.ObjectID;
				if (objectID === "NaN" || objectID === "") {
					objectID = "0";
				}
				objectID = parseInt(objectID) + 1;
				objectID = "" + objectID;
			}

		});

		if (sap.ui.getCore().byId("fileUploaderEmp").getVisible()) {
			if (this.getFileAttachmentsEmp() === undefined || this.getFileAttachmentsEmp === null || this.getFileAttachmentsEmp().length === 0) {
				//sap.m.MessageBox.error("Attachment is Mandatory");
				sap.ui.getCore().byId("fileUploaderEmp").setValueState(sap.ui.core.ValueState.Error);
				//  sap.ui.getCore().byId("fileUploaderEmp").setValueStateText("Upload File");
				r = false;
			} else {
				sap.ui.getCore().byId("fileUploaderEmp").setValueState(sap.ui.core.ValueState.None);
			}
		}

		if (r === false) {
			sap.m.MessageBox.error("Please fill all Mandatory Fields");
		}
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		var errorBodyEmp;
		if (r) {
             sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			var formattedStartDate = new Date(startDate);
			formattedStartDate = this.ui5ToOdatadataForLocalFiltering(startDate, 'date');
			var formattedEndDate = new Date(endDate);
			formattedEndDate = this.ui5ToOdatadataForLocalFiltering(endDate, 'date');
			var employerObj = {
				Employeenumber: p,
				ObjectID: objectID,
				FormerJobTxt: jobVal,
				EmployerName: EmployerVal,
				City: cityEmpVal,
				Country: countryVal,
				IndustrykeyTxt: industryVal,
				StartDate: formattedStartDate,
				EndDate: formattedEndDate
			};
			oDataModel.create(path, employerObj, null, function(responseBody, sucRes) {
				resultEmp = true;

			}, function(failRes) {
				resultEmp = false;
				errorBodyEmp = JSON.parse(failRes.response.body);
			});

			var attchCreate = "AttachmentCreateSet";
			var oFiles = [];
			var attchObj = {};

			if (this.getFileAttachments() === undefined || this.getFileAttachments() === null) {

			} else {

				var fileData = this.getFileAttachments();

				if (fileData !== null) {

					attchObj = fileData[0];
				}
			}

			oDataModel.create(attchCreate, attchObj, null, function(responseBody, sucRes) {

				resultEmp = true;

			}, function(failRes) {
				resultEmp = false;
				errorBodyEmp = JSON.parse(failRes.response.body);
			});

			if (resultEmp === true) {
				sap.m.MessageBox.success("This has been forwarded to HR for Approval");
				this.setValEmployer();
				var dialog = sap.ui.getCore().byId("idDialogEmployerDetails");
				dialog.close();
				//location.reload(true);	
			} else {
				sap.m.MessageBox.error("\\n Message: " + errorBodyEmp.error.message.value);
			}

		}
	},
	setValEmployer: function() {
		sap.ui.getCore().byId("idJob").setValue("");
		sap.ui.getCore().byId("idEmployer").setValue("");
		sap.ui.getCore().byId("idIndustry").setValue("");
		sap.ui.getCore().byId("idCityEmp").setValue("");
		sap.ui.getCore().byId("idCountry").setValue("");
		sap.ui.getCore().byId("startDateEmp").setValue("");
		sap.ui.getCore().byId("endDateEmp").setValue("");
		var myjsonEmp = new sap.ui.model.json.JSONModel();
		var mydataEmp = {
			"myFiles": [
	                                                                ]
		};
		myjsonEmp.setData(mydataEmp);
		if (sap.ui.getCore().byId("idFileTableEmp").getVisible()) {
			sap.ui.getCore().byId("idFileTableEmp").setModel(myjsonEmp);
		}
	},
	SubmitInstitute: function() {
		var c = "Education Details";
		var certiVal = sap.ui.getCore().byId("idCertificate").getValue();
		var instituteVal = sap.ui.getCore().byId("idInstitute").getValue();
		var eduEstVal = sap.ui.getCore().byId("idEduEst").getValue();
		var branchVal = sap.ui.getCore().byId("idBranch").getValue();
		/*	var durationVal = sap.ui.getCore().byId("idDur").getValue();
		var unitVal = sap.ui.getCore().byId("idUnit").getSelectedItem().getText();*/
		var countryVal = sap.ui.getCore().byId("idCountryIns").getValue();
		var highestEduVal = sap.ui.getCore().byId("idHighestEdu").getSelectedItem().getText();
		var startDate = sap.ui.getCore().byId("startDate").getDateValue();
		var endDate = sap.ui.getCore().byId("endDate").getDateValue();
		var highEdu;
		if (highestEduVal === "Yes") {
			highEdu = "Y"
		} else {
			highEdu = " "
		}
		var r = true;

		if (certiVal === "" || (this.certificateDialog !== certiVal && this.selectedCertificate !== certiVal)) {
			sap.ui.getCore().byId("idCertificate").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCertificate").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCertificate").setValueState(sap.ui.core.ValueState.None);
		}

		if (instituteVal === "") {
			sap.ui.getCore().byId("idInstitute").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idInstitute").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idInstitute").setValueState(sap.ui.core.ValueState.None);
		}

		if (eduEstVal === "" || ((this.eduEstDialog !== eduEstVal && this.eduEstDialog !== undefined) && this.selectedEduEst !== eduEstVal)) {
			sap.ui.getCore().byId("idEduEst").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idEduEst").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idEduEst").setValueState(sap.ui.core.ValueState.None);
		}

		if (branchVal === "" || (this.branchDialog !== branchVal && this.selectedBranch !== branchVal)) {
			sap.ui.getCore().byId("idBranch").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idBranch").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idBranch").setValueState(sap.ui.core.ValueState.None);
		}

		/*if (durationVal === "") {
			sap.ui.getCore().byId("idDur").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idDur").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idDur").setValueState(sap.ui.core.ValueState.None);
		}*/

		if (countryVal === "" || (this.countryInsDialog !== countryVal && this.selectedCountry !== countryVal)) {
			sap.ui.getCore().byId("idCountryIns").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCountryIns").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCountryIns").setValueState(sap.ui.core.ValueState.None);
		}

		if (startDate === "" || startDate === null) {
			sap.ui.getCore().byId("startDate").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("startDate").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("startDate").setValueState(sap.ui.core.ValueState.None);
		}

		if (endDate === "" || endDate === null) {
			sap.ui.getCore().byId("endDate").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("endDate").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("endDate").setValueState(sap.ui.core.ValueState.None);
		}
		if (sap.ui.getCore().byId("fileUploaderIns").getVisible()) {
			if (this.getFileAttachmentsIns() === undefined || this.getFileAttachmentsIns === null || this.getFileAttachmentsIns().length === 0) {
				sap.ui.getCore().byId("fileUploaderIns").setValueState(sap.ui.core.ValueState.Error);
				// sap.ui.getCore().byId("fileUploaderIns").setValueStateText("Upload File");
				r = false;
			} else {
				sap.ui.getCore().byId("fileUploaderIns").setValueState(sap.ui.core.ValueState.None);
			}
		}

		if (r === false) {
			//sap.m.MessageBox.error("Please fill all Mandatory Fields");
			sap.ui.getCore().byId("idReqIns").setVisible(true);
		} else {
			sap.ui.getCore().byId("idReqIns").setVisible(false);
		}
		if (r) {
		     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			var formattedStartDate = new Date(startDate);
			formattedStartDate = this.ui5ToOdatadataForLocalFiltering(startDate, 'date');

			var formattedEndDate = new Date(endDate);
			formattedEndDate = this.ui5ToOdatadataForLocalFiltering(endDate, 'date');

			if (formattedStartDate < formattedEndDate) {
				var path = "EducationSet";
				var objectID = " ";
				b[c].vals.forEach(function(h) {
					if (h.SubGroupname === certiVal) {
						objectID = h.ObjectID;
						if (objectID === "NaN" || objectID === "") {
							objectID = "0";
						}
						objectID = parseInt(objectID) + 1;
						objectID = "" + objectID;
					}

				});
				var eduObj = {
					Employeenumber: p,
					Institute: instituteVal,
					CertificateTxt: certiVal,
					BranchTxt: branchVal,
					Duration: "",
					TimeTxt: "",
					Country: countryVal,
					ObjectID: objectID,
					EduEstablishTxt: eduEstVal,
					StartDate: formattedStartDate,
					EndDate: formattedEndDate,
					HighestEducation: highEdu
				};

				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
				var errorBodyIns;

				/*oDataModel.create(path, eduObj, null, function(responseBody, sucRes) {
					resultIns = true;

				}, function(failRes) {
					resultIns = false;
					errorBodyIns = JSON.parse(failRes.response.body);

				});
*/
				batch.push(oDataModel.createBatchOperation(path, "POST", eduObj));
				var attchCreate = "AttachmentCreateSet";
				var oFiles = [];
				var attchObj = {};

				if (this.getFileAttachmentsIns() === undefined || this.getFileAttachmentsIns() === null) {

				} else {

					var fileData = this.getFileAttachments();

					if (fileData !== null) {

						attchObj = fileData[0];
					}
				}

				/*oDataModel.create(attchCreate, attchObj, null, function(responseBody, sucRes) {

					resultIns = true;

				}, function(failRes) {
					resultIns = false;
					errorBodyIns = JSON.parse(failRes.response.body);
				});*/
				batch.push(oDataModel.createBatchOperation(attchCreate, "POST", attchObj));
				this.setValInstitute();
				var dialog = sap.ui.getCore().byId("idDialogInstituteDetails");
				dialog.close();
			
				/*				if (resultIns === true) {
					sap.m.MessageBox.success("This has been forwarded to HR for Approval");

					this.setValInstitute();
					var dialog = sap.ui.getCore().byId("idDialogInstituteDetails");
					dialog.close();
					//location.reload(true);

				} else {
					sap.m.MessageBox.error("\\n Message: " + errorBodyIns.error.message.value);
				}*/
			} else {
				sap.m.MessageBox.error("Start date should not be greater than End date");
			}
		}
	},

	setValInstitute: function() {
		sap.ui.getCore().byId("idCertificate").setValue("");
		sap.ui.getCore().byId("idInstitute").setValue("");
		sap.ui.getCore().byId("idEduEst").setValue("");
		sap.ui.getCore().byId("idBranch").setValue("");
		//sap.ui.getCore().byId("idDur").setValue("");
		//sap.ui.getCore().byId("idUnit").setSelectedItem();
		sap.ui.getCore().byId("idCountryIns").setValue("");
		sap.ui.getCore().byId("idHighestEdu").setSelectedItem();
		sap.ui.getCore().byId("startDate").setValue("");
		sap.ui.getCore().byId("endDate").setValue("");
		var myjsonIns = new sap.ui.model.json.JSONModel();
		var mydataIns = {
			"myFiles": [
	                                                                ]
		};
		myjsonIns.setData(mydataIns);
		if (sap.ui.getCore().byId("idFileTableIns").getVisible()) {
			sap.ui.getCore().byId("idFileTableIns").setModel(myjsonIns);
		}
	},
	setValFamily: function() {
		sap.ui.getCore().byId("idMember").setSelectedKey("Father");
		sap.ui.getCore().byId("idFN").setValue("");
		sap.ui.getCore().byId("idLN").setValue("");
		sap.ui.getCore().byId("DP6").setValue("");
	},
	SubmitFamilyDetails: function() {
		c = "Family Member Details";
		var memberValue = sap.ui.getCore().byId("idMember").getSelectedKey();
		var firstName = sap.ui.getCore().byId("idFN").getValue();
		var lastName = sap.ui.getCore().byId("idLN").getValue();
		var dob = sap.ui.getCore().byId("DP6").getDateValue();

		var path = "FamilySet";

		var flag = false;
		var subType;
		var objectID;
		if (memberValue === "Father") {
			subType = "11";
		} else if (memberValue === "Mother") {
			subType = "12";
		} else if (memberValue === "Spouse") {
			subType = "1";
		} else if (memberValue === "Child") {
			subType = "2";
		}
		b[c].vals.forEach(function(h) {
			if (h.SubGroupname === memberValue) {
				if (h.SubGroupname === "Child") {
					flag = false;
					objectID = h.ObjectID;

				} else {
					flag = true;
				}
			}
		});
		if (objectID === "NAN" || objectID === undefined) {
			objectID = "";
		}

		if (objectID === "") {
			objectID = ""
		} else {
			if (objectID === "") {
				objectID = 0;
				objectID = parseInt(objectID) + 1;
			}
		}
		var r = true;
		if (firstName === "") {
			sap.ui.getCore().byId("idFN").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idFN").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idFN").setValueState(sap.ui.core.ValueState.None);
		}

		if (lastName === "") {
			sap.ui.getCore().byId("idLN").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idLN").setValueStateText("Enter Value");
			r = false;
		} else {
			/* var LN_regExp = /^\+[a-zA-Z0-9]+$/;
		
			if (!lastName.match(LN_regExp)) {
			
			sap.ui.getCore().byId("idLN").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idLN").setValueStateText("Enter Value");
			r = false;
			}
			else{*/

			sap.ui.getCore().byId("idLN").setValueState(sap.ui.core.ValueState.None);
			//}
		}

		if (dob === "" || dob === null) {
			sap.ui.getCore().byId("DP6").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("DP6").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("DP6").setValueState(sap.ui.core.ValueState.None);
		}

		if (r === false) {
			//sap.m.MessageBox.error("Please fill all Mandatory Fields");
			sap.ui.getCore().byId("idReqFam").setVisible(true);
		} else {
			sap.ui.getCore().byId("idReqFam").setVisible(false);
		}

		if (r) {
		     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			var formattedDOB = new Date(dob);
			formattedDOB = this.ui5ToOdatadataForLocalFiltering(dob, 'date');
			var currentDate = new Date();
			currentDate =  this.ui5ToOdatadataForLocalFiltering(currentDate, 'date');
			if(formattedDOB < currentDate ){
			oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
			var resultFam = false;
			var errorBodyFam;
			var familyObj = {
				Employeenumber: p,
				Subtype: subType,
				ObjectID: objectID,
				FirstName: firstName,
				LastName: lastName,
				Dateofbirth: formattedDOB

			};
			if (flag === true) {
				sap.m.MessageBox.alert("Cannot add " + memberValue + " details again");
			} else {
				/*	oDataModel.create(path, {
					Employeenumber: p,
					Subtype: subType,
					ObjectID: objectID,
					FirstName: firstName,
					LastName: lastName,
					Dateofbirth: formattedDOB

				}, null, function(responseBody, sucRes) {
					resultFam = true;
				}, function(failRes) {
					resultFam = false;
					errorBodyFam = JSON.parse(failRes.response.body);
				});*/
				batch.push(oDataModel.createBatchOperation(path, "POST", familyObj));
				var that = this;
				that.setValFamily();
				var dialog = sap.ui.getCore().byId("idDialogFamilyDetails");
				dialog.close();
				/*if (resultFam === true) {
					that.setValFamily();
					var dialog = sap.ui.getCore().byId("idDialogFamilyDetails");
					dialog.close();
					sap.m.MessageBox.show("This has been forwarded to HR for Approval", {
						icon: sap.m.MessageBox.Icon.SUCCESS,
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
								//			location.reload(true);
							}
						}.bind(that)
					});
				} else {
					sap.m.MessageBox.error("\\n Message: " + errorBodyFam.error.message.value);
				}*/
			}
		}
		else
		{
		    sap.m.MessageBox.alert("Date of birth cannot be greater than current date");
		}
		}
	},
	ui5ToOdatadataForLocalFiltering: function(data, type) {
		if (type === 'date') {
			var iDatadt = data;
			var month = (iDatadt.getMonth() + 1);
			var day = iDatadt.getDate()

			if ((iDatadt.getMonth() + 1).toString().length < 2) {
				month = '0' + (iDatadt.getMonth() + 1);
			}

			if ((iDatadt.getDate()).toString().length < 2) {
				day = '0' + iDatadt.getDate();
			}

			iDatadt = iDatadt.getFullYear() +
				'-' + month +
				'-' + day +
				'T' + "00" +
				':' + "00" +
				':' + "00";

			return iDatadt;

		}

	},
	familySelect: function() {
		sap.ui.getCore().byId("idFN").setValue("");
		sap.ui.getCore().byId("idLN").setValue("");
		sap.ui.getCore().byId("DP6").setValue("");
	},
	setValComm: function() {
		/*sap.ui.getCore().byId("idComm").setSelectedKey("Personal E-mail");
		var selectedVal = sap.ui.getCore().byId("idComm").getSelectedKey();
		if (selectedVal === "Personal E-mail") {
			sap.ui.getCore().byId("idPerEmail").setVisible(true);
			sap.ui.getCore().byId("idPerMobExt").setVisible(false);
			sap.ui.getCore().byId("idPerMob").setVisible(false);
			sap.ui.getCore().byId("idIPPhExt").setVisible(false);
			sap.ui.getCore().byId("idIPPhone").setVisible(false);
			sap.ui.getCore().byId("idText").setVisible(false);

		}

		if (sap.ui.getCore().byId("idPerEmail").getVisible()) {
			sap.ui.getCore().byId("idPerEmail").setValue("");
		}
		if (sap.ui.getCore().byId("idPerMobExt").getVisible()) {
			sap.ui.getCore().byId("idPerMobExt").setValue("");

		}
		if (sap.ui.getCore().byId("idPerMob").getVisible()) {
			sap.ui.getCore().byId("idPerMob").setValue("");
		}
		if (sap.ui.getCore().byId("idIPPhExt").getVisible()) {
			sap.ui.getCore().byId("idIPPhExt").setSelectedKey();

		}
		if (sap.ui.getCore().byId("idIPPhone").getVisible()) {
			sap.ui.getCore().byId("idIPPhone").setValue("");

		}
		if (sap.ui.getCore().byId("idText").getVisible()) {
			sap.ui.getCore().byId("idText").setVisible(false);
		}*/
		sap.ui.getCore().byId("idPerEmail").setValue("");
		
		sap.ui.getCore().byId("idPerMobExt").setValue("");
		sap.ui.getCore().byId("idPerMob").setValue("");
		sap.ui.getCore().byId("idIPPhone").setValue("");

	},
	onCloseComm: function() {
		this.setValComm();
		var dialog = sap.ui.getCore().byId("idDialogCommDetails");
		dialog.close();
	},
	SubmitComm1: function(evt) {
		var flag = true;
		var path = "CommunicationsSet";
		var emailValue, peremailValue, phoneValue, IPPhoneValue, phoneExtValue, IPphoneExtValue;
		var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", false, "", "");

		var B = new Array();
		var CommObj = {};
		peremailValue = sap.ui.getCore().byId("idPerEmail").getValue();
		var email_regExp =
			/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
		if (!peremailValue.match(email_regExp)) {
			sap.ui.getCore().byId("idPerEmail").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idPerEmail").setValueStateText("Enter value");
			flag = false;
		} else {
			sap.ui.getCore().byId("idPerEmail").setValueState(sap.ui.core.ValueState.None);
			CommObj = {
				Employeenumber: p,
				UserName: "",
				Email: peremailValue,
				Number: "",
				Subtype: "0030",
				ObjectID: ""
			};
			batch.push(dModel.createBatchOperation("CommunicationsSet", "POST", CommObj));
		}

		phoneExtValue = sap.ui.getCore().byId("idPerMobExt").getValue(); //content[0].mAggregations.items[0].mProperties.value;
		phoneValue = sap.ui.getCore().byId("idPerMob").getValue(); //content[0].mAggregations.items[1].mProperties.value
		var phone_regExp = /^[0-9]+$/;
		var ext_regExp = /^\+[0-9]+$/;
		var subtype = "MOB";
		var phoneVal = "" + phoneExtValue + phoneValue;

		if (!phoneExtValue.match(ext_regExp)) {
			sap.ui.getCore().byId("idPerMobExt").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idPerMobExt").setValueStateText("Enter value");
			flag = false;
		} else
		if (!phoneValue.match(phone_regExp)) {
			sap.ui.getCore().byId("idPerMob").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idPerMob").setValueStateText("Enter value");
			flag = false;
		} else {
			sap.ui.getCore().byId("idPerMobExt").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idPerMob").setValueState(sap.ui.core.ValueState.None);
			CommObj = {
				Employeenumber: p,
				UserName: "",
				Email: "",
				Number: phoneVal,
				Subtype: subtype,
				ObjectID: ""
			};
			batch.push(dModel.createBatchOperation("CommunicationsSet", "POST", CommObj));
		}

		IPphoneExtValue = sap.ui.getCore().byId("idIPPhExt").getSelectedKey(); //content[0].mAggregations.items[0].mProperties.value;
		IPPhoneValue = sap.ui.getCore().byId("idIPPhone").getValue(); //content[0].mAggregations.items[1].mProperties.value;
		IPphoneExtValue = "(" + IPphoneExtValue + ")";
		var phone_regExp = /^\([0-9]{3}\)+$/;
		var IPPhone_regExp = /^[0-9]+$/;
		var phoneVal = "" + IPphoneExtValue + IPPhoneValue;
		if (!IPPhoneValue.match(IPPhone_regExp)) {
			sap.ui.getCore().byId("idIPPhone").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idIPPhone").setValueStateText("Enter value");

			flag = false;
		}
		/*else if (!IPphoneExtValue.match(phone_regExp)) {
			sap.ui.getCore().byId("idIPPhExt").setValueState(sap.ui.core.ValueState.Error);
		        sap.ui.getCore().byId("idIPPhExt").setValueStateText("Enter value");
				
				flag = false;
			}*/
		else {
			sap.ui.getCore().byId("idIPPhone").setValueState(sap.ui.core.ValueState.None);

			CommObj = {
				Employeenumber: p,
				UserName: "",
				Email: "",
				Number: phoneVal,
				Subtype: "IPP",
				ObjectID: ""
			};

		}

		phoneExtValue = sap.ui.getCore().byId("idPerMobExt1").getValue(); //content[0].mAggregations.items[0].mProperties.value;
		phoneValue = sap.ui.getCore().byId("idPerMob1").getValue(); //content[0].mAggregations.items[1].mProperties.value
		var phone_regExp = /^[0-9]+$/;
		var ext_regExp = /^\+[0-9]+$/;
		var subtype;
		var phoneVal = "" + phoneExtValue + phoneValue;
		subtype = "MOBP";
		if (!phoneExtValue.match(ext_regExp)) {
			sap.ui.getCore().byId("idPerMobExt1").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idPerMobExt1").setValueStateText("Enter value");

			flag = false;
		} else if (!phoneValue.match(phone_regExp)) {
			sap.ui.getCore().byId("idPerMob1").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idPerMob1").setValueStateText("Enter value");

			flag = false;
		} else {
			sap.ui.getCore().byId("idPerMobExt1").setValueState(sap.ui.core.ValueState.None);
			sap.ui.getCore().byId("idPerMob1").setValueState(sap.ui.core.ValueState.None);
			CommObj = {
				Employeenumber: p,
				UserName: "",
				Email: "",
				Number: phoneVal,
				Subtype: subtype,
				ObjectID: ""
			};
		}
		if (flag === false) {
			sap.ui.getCore().byId("idReqComm").setVisible(true);
		} else {
			sap.ui.getCore().byId("idReqComm").setVisible(false);
		}
		if (flag) {
			dModel.addBatchChangeOperations(B);

			dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		}
	},

	onRequestSuccess: function(e) {

		var that = this;

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				sap.m.MessageBox.alert(this.result.error);

			} else {

				sap.m.MessageBox.show("Data saved Successfully", {

					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],

					onClose: function(oAction) {

						if (oAction == "OK") {

							var oDialog = sap.ui.getCore().byId("idDialogCommDetails");

							oDialog.close();

							//	location.reload(true);

						}

					}.bind(that)

				});

			}

		}

	},

	onRequestFailed: function(e) {

		if (e.__batchResponses && e.__batchResponses.length > 0) {

			var j = e.__batchResponses[0].response.body;

			var n = $.parseJSON(j);

			this.result = {};

			this.result.error = n.error.message.value;

			this.busyDialog.close();

			sap.m.MessageBox.error(this.result.error);

		}

	},
	SubmitComm: function(evt) {
		// var content = sap.ui.getCore().byId("commForm").getItems();
		var flag = true;
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

	//	var selectedVal = sap.ui.getCore().byId("idComm").getSelectedItem().getText();
	var selectedVal = sap.ui.getCore().byId("idComm").getSelectedKey();
		var emailValue, peremailValue, phoneValue, IPPhoneValue, phoneExtValue, IPphoneExtValue;

		var path = "CommunicationsSet";
		if (selectedVal === "Personal E-mail") {
			peremailValue = sap.ui.getCore().byId("idPerEmail").getValue();
			var email_regExp =
				/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
			if (!peremailValue.match(email_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Personal Email Address");
				flag = false;
			}
			oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

			if (flag === true) {
             sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
				var communiperEmailObj = {
					Employeenumber: p,
					UserName: "",
					Email: peremailValue,
					Number: "",
					Subtype: "0030",
					ObjectID: ""
				};
				var resultEmail = false;
				var errorBodyEmail;
				batch.push(oDataModel.createBatchOperation(path, "POST", communiperEmailObj));
				/*oDataModel.create(path, communiperEmailObj, null, function(responseBody, sucRes) {
					resultEmail = true;

				}, function(failRes) {
					resultEmail = false;
					errorBodyEmail = JSON.parse(failRes.response.body);

				});*/
				var that = this;
				that.setValComm();
				var dialog = sap.ui.getCore().byId("idDialogCommDetails");
				dialog.close();
				/*if (resultEmail === true) {
					that.setValComm();
					var dialog = sap.ui.getCore().byId("idDialogCommDetails");
					dialog.close();
					sap.m.MessageBox.show("Personal Email Address Updated Successfully", {
						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
								//	location.reload(true);
							}
						}.bind(that)
					});
				} else {
					sap.m.MessageBox.error("\\n Message: " + errorBodyEmail.error.message.value);
				}*/
			}
		}
		if (selectedVal === "Mobile Phone") {
			phoneExtValue = sap.ui.getCore().byId("idPerMobExt").getValue(); //content[0].mAggregations.items[0].mProperties.value;
			phoneValue = sap.ui.getCore().byId("idPerMob").getValue(); //content[0].mAggregations.items[1].mProperties.value
			var phone_regExp = /^[0-9]+$/;
			var ext_regExp = /^\+[0-9]+$/;
			var subtype;
			var phoneVal = "" + phoneExtValue + phoneValue;

			if (!phoneExtValue.match(ext_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Ext Phone Number");
				flag = false;
			}
			if (!phoneValue.match(phone_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Phone Number");
				flag = false;
			}
			if(phoneValue.length < 10 || phoneValue.length >10){
				sap.m.MessageBox.alert("Please provide Correct Phone Number");
				flag = false;
			}

			subtype = "MOB";
			var resultPh = false;
			var errorBodyPh;
			oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

			if (flag === true) {
			     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
				var communiMobObj = {
					Employeenumber: p,
					UserName: "",
					Email: "",
					Number: phoneVal,
					Subtype: subtype,
					ObjectID: ""
				};
				batch.push(oDataModel.createBatchOperation(path, "POST", communiMobObj));
				/*oDataModel.create(path, communiMobObj, null, function(responseBody, sucRes) {
					resultPh = true;

				}, function(failRes) {
					resultPh = false;
					errorBodyPh = JSON.parse(failRes.response.body);

				});*/
				var that = this;
				that.setValComm();
				var dialog = sap.ui.getCore().byId("idDialogCommDetails");
				dialog.close();
				/*if (resultPh === true) {
				//	that.setValComm();
					var dialog = sap.ui.getCore().byId("idDialogCommDetails");
					dialog.close();
					sap.m.MessageBox.show("Phone Number Updated Successfully", {
						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
								//	location.reload(true);
							}
						}.bind(that)
					});
				} else {
					sap.m.MessageBox.error("\\n Message: " + errorBodyPh.error.message.value);
				}*/
			}
		}
		if (selectedVal === "IP phone number") {
			IPphoneExtValue = sap.ui.getCore().byId("idIPPhExt").getSelectedKey(); //content[0].mAggregations.items[0].mProperties.value;
			IPPhoneValue = sap.ui.getCore().byId("idIPPhone").getValue(); //content[0].mAggregations.items[1].mProperties.value;
			IPphoneExtValue = "(" + IPphoneExtValue + ")";
			var phone_regExp = /^\([0-9]{3}\)+$/;
			var IPPhone_regExp = /^[0-9]+$/;
			var phoneVal = "" + IPphoneExtValue + IPPhoneValue;
			if (!IPPhoneValue.match(IPPhone_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Ext IP Phone Number");
				flag = false;
			}

			if (!IPphoneExtValue.match(phone_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct IP Phone Number");
				flag = false;
			}
			if(IPPhoneValue.length < 4 || IPPhoneValue.length >4){
				sap.m.MessageBox.alert("Please provide Correct IP Phone Number");
				flag = false;
			}
			oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

			if (flag === true) {
			     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
				var communiIPObj = {
					Employeenumber: p,
					UserName: "",
					Email: "",
					Number: phoneVal,
					Subtype: "IPP",
					ObjectID: ""
				};
				var resultIP = false;
				var errorBodyIP;
				batch.push(oDataModel.createBatchOperation(path, "POST", communiIPObj));
				/*oDataModel.create(path, communiIPObj, null, function(responseBody, sucRes) {
					resultIP = true;

				}, function(failRes) {
					resultIP = false;
					errorBodyIP = JSON.parse(failRes.response.body);
				});
*/
				var that = this;
				that.setValComm();
				var dialog = sap.ui.getCore().byId("idDialogCommDetails");
				dialog.close();
				/*				if (resultIP === true) {
					that.setValComm();
					var dialog = sap.ui.getCore().byId("idDialogCommDetails");
					dialog.close();
					sap.m.MessageBox.show("IP Phone Number Updated Successfully", {
						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
								//	location.reload(true);
							}
						}.bind(that)
					});
				} else {
					sap.m.MessageBox.error("\\n Message: " + errorBodyIP.error.message.value);
				}*/

			}

		}
		if (selectedVal === "Alternate mobile number") {
			phoneExtValue = sap.ui.getCore().byId("idPerMobExt").getValue(); //content[0].mAggregations.items[0].mProperties.value;
			phoneValue = sap.ui.getCore().byId("idPerMob").getValue(); //content[0].mAggregations.items[1].mProperties.value
			var phone_regExp = /^[0-9]+$/;
			var ext_regExp = /^\+[0-9]+$/;
			var subtype;
			var phoneVal = "" + phoneExtValue + phoneValue;

			if (!phoneExtValue.match(ext_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Ext Phone Number");
				flag = false;
			}
			if (!phoneValue.match(phone_regExp)) {
				sap.m.MessageBox.alert("Please provide Correct Phone Number");
				flag = false;
			}
            if(phoneValue.length < 10 || phoneValue.length >10){
				sap.m.MessageBox.alert("Please provide Correct Phone Number");
				flag = false;
			}
			subtype = "MOBP";
			var resultPh = false;
			var errorBodyPh;
			oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

			if (flag === true) {
			     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
				var communiMobObj = {
					Employeenumber: p,
					UserName: "",
					Email: "",
					Number: phoneVal,
					Subtype: subtype,
					ObjectID: ""
				};

				batch.push(oDataModel.createBatchOperation(path, "POST", communiMobObj));
				/*oDataModel.create(path, communiMobObj, null, function(responseBody, sucRes) {
					resultPh = true;

				}, function(failRes) {
					resultPh = false;
					errorBodyPh = JSON.parse(failRes.response.body);

				});**/

				var that = this;
				that.setValComm();
				var dialog = sap.ui.getCore().byId("idDialogCommDetails");
				dialog.close();
				/*if (resultPh === true) {
					that.setValComm();
					var dialog = sap.ui.getCore().byId("idDialogCommDetails");
					dialog.close();
					sap.m.MessageBox.show("Alternate Phone Number Updated Successfully", {
						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction == "OK") {
								//	location.reload(true);
							}
						}.bind(that)
					});
				} else {
					sap.m.MessageBox.error("\\n Message: " + errorBodyPh.error.message.value);
				}*/
			}

		}
	},
	CommSelect: function(text) {
		if (text === "Mobile number") {
			text = "Mobile Phone";
		} else if (text === "Alternate Mobile number") {
			text = "Alternate mobile number";
		}
	/*	var selectedVal = sap.ui.getCore().byId("idComm").getSelectedItem().setText(text);
		selectedVal = sap.ui.getCore().byId("idComm").getSelectedItem().getText();*/
		 sap.ui.getCore().byId("idComm").setSelectedKey(text);

		var selectedVal = sap.ui.getCore().byId("idComm").getSelectedKey();
		var commJson = new sap.ui.model.json.JSONModel();
		var d = new sap.ui.model.odata.ODataModel(
			"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
		var mobCode = [];
		d.read(q, null, null, false, function(r) {
			mobCode.push(r.results[0].MobileCode);

			commJson.setData(mobCode);
		});
		sap.ui.getCore().setModel(commJson, "extModel");

		if (selectedVal === "Mobile Phone") {
			var value = sap.ui.getCore().getModel("extModel").getData()[0];
			value = "+" + value;
			sap.ui.getCore().byId("idPerEmail").setVisible(false);
			sap.ui.getCore().byId("idPerMobExt").setVisible(true);
			sap.ui.getCore().byId("idPerMob").setVisible(true);
			sap.ui.getCore().byId("idIPPhExt").setVisible(false);
			sap.ui.getCore().byId("idIPPhone").setVisible(false);
			sap.ui.getCore().byId("idPerMobExt").setValue(value);
			sap.ui.getCore().byId("idText").setVisible(false);
		} else if (selectedVal === "IP phone number") {
			sap.ui.getCore().byId("idPerEmail").setVisible(false);
			sap.ui.getCore().byId("idPerMobExt").setVisible(false);
			sap.ui.getCore().byId("idPerMob").setVisible(false);
			sap.ui.getCore().byId("idIPPhExt").setVisible(true);
			sap.ui.getCore().byId("idIPPhone").setVisible(true);
			sap.ui.getCore().byId("idText").setVisible(true);

		} else if (selectedVal === "Personal E-mail") {
			sap.ui.getCore().byId("idPerEmail").setVisible(true);
			sap.ui.getCore().byId("idPerMobExt").setVisible(false);
			sap.ui.getCore().byId("idPerMob").setVisible(false);
			sap.ui.getCore().byId("idIPPhExt").setVisible(false);
			sap.ui.getCore().byId("idIPPhone").setVisible(false);
			sap.ui.getCore().byId("idText").setVisible(false);

		} else if (selectedVal === "Alternate mobile number") {
			var value = sap.ui.getCore().getModel("extModel").getData()[0];
			value = "+" + value;
			sap.ui.getCore().byId("idPerEmail").setVisible(false);
			sap.ui.getCore().byId("idPerMobExt").setVisible(true);
			sap.ui.getCore().byId("idPerMob").setVisible(true);
			sap.ui.getCore().byId("idIPPhExt").setVisible(false);
			sap.ui.getCore().byId("idIPPhone").setVisible(false);
			sap.ui.getCore().byId("idPerMobExt").setValue(value);
			sap.ui.getCore().byId("idText").setVisible(false);
		}

	},
	CommSelect1: function(text) {
		var emailID = sap.ui.getCore().byId("idPerEmail").getValue();

		if (emailID !== "No Data") {
			var selectedVal = sap.ui.getCore().byId("idComm").getSelectedItem().getText();
			var commJson = new sap.ui.model.json.JSONModel();
			var d = new sap.ui.model.odata.ODataModel(
				"/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
			var q = "SHPhoneCodeSet?$filter=Employeenumber eq '" + p + "'";
			var mobCode = [];
			d.read(q, null, null, false, function(r) {
				mobCode.push(r.results[0].MobileCode);

				commJson.setData(mobCode);
			});
			sap.ui.getCore().setModel(commJson, "extModel");

			if (selectedVal === "Mobile Phone") {
				var value = sap.ui.getCore().getModel("extModel").getData()[0];
				value = "+" + value;
				sap.ui.getCore().byId("idPerEmail").setVisible(false);
				sap.ui.getCore().byId("idPerMobExt").setVisible(true);
				sap.ui.getCore().byId("idPerMob").setVisible(true);
				sap.ui.getCore().byId("idIPPhExt").setVisible(false);
				sap.ui.getCore().byId("idIPPhone").setVisible(false);
				sap.ui.getCore().byId("idPerMobExt").setValue(value);
				sap.ui.getCore().byId("idText").setVisible(false);
			} else if (selectedVal === "IP phone number") {
				sap.ui.getCore().byId("idPerEmail").setVisible(false);
				sap.ui.getCore().byId("idPerMobExt").setVisible(false);
				sap.ui.getCore().byId("idPerMob").setVisible(false);
				sap.ui.getCore().byId("idIPPhExt").setVisible(true);
				sap.ui.getCore().byId("idIPPhone").setVisible(true);
				sap.ui.getCore().byId("idText").setVisible(true);

			} else if (selectedVal === "Personal E-mail") {
				sap.ui.getCore().byId("idPerEmail").setVisible(true);
				sap.ui.getCore().byId("idPerMobExt").setVisible(false);
				sap.ui.getCore().byId("idPerMob").setVisible(false);
				sap.ui.getCore().byId("idIPPhExt").setVisible(false);
				sap.ui.getCore().byId("idIPPhone").setVisible(false);
				sap.ui.getCore().byId("idText").setVisible(false);

			} else if (selectedVal === "Alternate mobile number") {
				var value = sap.ui.getCore().getModel("extModel").getData()[0];
				value = "+" + value;
				sap.ui.getCore().byId("idPerEmail").setVisible(false);
				sap.ui.getCore().byId("idPerMobExt").setVisible(true);
				sap.ui.getCore().byId("idPerMob").setVisible(true);
				sap.ui.getCore().byId("idIPPhExt").setVisible(false);
				sap.ui.getCore().byId("idIPPhone").setVisible(false);
				sap.ui.getCore().byId("idPerMobExt").setValue(value);
				sap.ui.getCore().byId("idText").setVisible(false);
			}
		} else {
			sap.ui.getCore().byId("idComm").setSelectedKey("Personal E-mail")
			sap.ui.getCore().byId("idPerEmail").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idPerEmail").setValueStateText("Personal Email ID is mandatory");
		}
	},

	setValPersonal: function() {
		//sap.ui.getCore().byId("idFirstName").setValue("");
		//sap.ui.getCore().byId("idLastName").setValue("");

		sap.ui.getCore().byId("idMarStatus").setSelectedKey();
		sap.ui.getCore().byId("idDOM").setValue("");
		sap.ui.getCore().byId("idDOM").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idBirth").setValue("");
			sap.ui.getCore().byId("idBirth").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idStatePer").setValue("");
			sap.ui.getCore().byId("idStatePer").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idCountryPer").setValue("");
			sap.ui.getCore().byId("idCountryPer").setValueState(sap.ui.core.ValueState.None);
		sap.ui.getCore().byId("idReqPer").setVisible(false);
		sap.ui.getCore().byId("idReqPerName").setVisible(false);

	},
	onClosePersonal: function() {
		this.setValPersonal();
		var dialog = sap.ui.getCore().byId("idDialogPerDetails");
		dialog.close();
	},
	SubmitPersonal: function() {
		
	    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
	     var perJson = new sap.ui.model.json.JSONModel();
    var perSet = "EmployeeDataSet('"+p+"')/PersonalInfoSet";
     oDataModel.read(perSet, null, null, false, function(r) {
      perJson.setData(r);
    });

    this.getView().setModel(perJson,"perModel");
    
    var oPerModel = this.getView().getModel("perModel").getData().results;
    
    var jsonObjTemp = {};
						jsonObjTemp.item = new Array();
    for(var i=0; i< oPerModel.length ; i++){
        if(oPerModel[i].Groupname === "Personal data" || oPerModel[i].Groupname === "Personal Data" ){
            			jsonObjTemp.item.push({
								"title": oPerModel[i].Fieldlabel,
								"value": oPerModel[i].Fieldvalue

								});

        }
    }
    var FN , LN;
    sap.ui.getCore().setModel(jsonObjTemp, "oldperModel");
    for(var i =0;i<jsonObjTemp.item.length;i++)
    {
        if(jsonObjTemp.item[i].title === "First name")
        {
            FN = jsonObjTemp.item[i].value;
        }
        if(jsonObjTemp.item[i].title === "Last name")
        {
            LN = jsonObjTemp.item[i].value;
        }
    }
    
    var fullName = FN+" "+LN;
    var myString
  if(LN === "."){
        myString = fullName.replace(/.$/, '');
    }else
    {
    	myString = fullName;
    }
		var fName = sap.ui.getCore().byId("idFirstName").getValue();
		var lName = sap.ui.getCore().byId("idLastName").getValue();
		var nameNew = fName+" "+lName;
		var splitName = myString.split(fName);
		var key = sap.ui.getCore().byId("idMarStatus").getSelectedKey();
		var DOM = sap.ui.getCore().byId("idDOM").getDateValue();
		var birthPlace = sap.ui.getCore().byId("idBirth").getValue();
		var cntryBirth = sap.ui.getCore().byId("idCountryPer").getValue();
		var stateBirth = sap.ui.getCore().byId("idStatePer").getValue();
		if (DOM != null) {
			var dom = new Date(DOM);
			dom = this.ui5ToOdatadataForLocalFiltering(DOM, 'date');
		} else {
			dom = "0000-00-00T00:00:00";
		}
		var birthPlace_regExp = /^[A-Za-z]+$/;
		var r = true;
		var resultName = true;
		if (key === "1" && DOM === null) {
			sap.ui.getCore().byId("idDOM").setValueState("Error");
			r = false;

		} else {
			sap.ui.getCore().byId("idDOM").setValueState("None");
		}

		if (fName === "") {
			sap.ui.getCore().byId("idFirstName").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idFirstName").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idFirstName").setValueState(sap.ui.core.ValueState.None);
		}
		if (lName === "" || lName === ".") {
			sap.ui.getCore().byId("idLastName").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idLastName").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idLastName").setValueState(sap.ui.core.ValueState.None);
		}

		if (birthPlace === "") {

			sap.ui.getCore().byId("idBirth").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idBirth").setValueStateText("Enter Value");
			r = false;
		} else {
			if (!birthPlace.match(birthPlace_regExp)) {
				sap.ui.getCore().byId("idBirth").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idBirth").setValueStateText("Only alphabets are allowed");
				r = false;
			} else {
				sap.ui.getCore().byId("idBirth").setValueState(sap.ui.core.ValueState.None);
			}
		}
		if (cntryBirth === "") {
			if (this.countryPerDialog !== cntryBirth && this.selectedCountryPer !== cntryBirth) {
				sap.ui.getCore().byId("idCountryPer").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idCountryPer").setValueStateText("Enter Value");
				r = false;
			}
		} else {
			sap.ui.getCore().byId("idCountryPer").setValueState(sap.ui.core.ValueState.None);
		}

		if (stateBirth === "") {
			if (this.statePerDialog !== stateBirth && this.selectedStatePer !== stateBirth) {
				sap.ui.getCore().byId("idStatePer").setValueState(sap.ui.core.ValueState.Error);
				sap.ui.getCore().byId("idStatePer").setValueStateText("Enter Value");
				r = false;
			}
		} else {
			sap.ui.getCore().byId("idStatePer").setValueState(sap.ui.core.ValueState.None);
		}

		
		if(myString !== nameNew ){
			sap.ui.getCore().byId("idFirstName").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idFirstName").setValueStateText("Enter Value");
					sap.ui.getCore().byId("idLastName").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idLastName").setValueStateText("Enter Value");

			r = false;
            resultName = false;
		}

		if (r === false) {
			//sap.m.MessageBox.error("Please fill all Mandatory Fields");
			if(resultName === false)
			{
			    sap.ui.getCore().byId("idReqPerName").setVisible(true);    
			    sap.ui.getCore().byId("idReqPerName").setText("Your possible last name can be "+splitName[1]);
			}else{
			    sap.ui.getCore().byId("idReqPer").setVisible(true);    
			}
			
		} else {
			sap.ui.getCore().byId("idReqPer").setVisible(false);
			sap.ui.getCore().byId("idReqPerName").setVisible(false);   
		}
		var nameObj = {
			Employeenumber: p,
			MaritalStatusKey: key,
			DateofMarriage: dom,
			Subtype: "",
			ObjectID: "",
			FirstName: fName,
			LastName: lName,
			BirthPlace: birthPlace,
			Country: cntryBirth,
			StateTxt: stateBirth
		};
		var resultPer = false;
		var errorBody;
		var path = "PersDataSet('" + p + "')";
		var lNameRegExp = /^[A-Za-z][A-Za-z]*(?:.[A-Za-z]+)*$/;
		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
		if (r) {
             sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			if (!lName.match(lNameRegExp)) {
				sap.m.MessageBox.error("Last name should start with character and shouldnot end with special character");
			} else {
				var that = this;
				batch.push(oDataModel.createBatchOperation(path, "PUT", nameObj));
				that.setValPersonal();
				var dialog = sap.ui.getCore().byId("idDialogPerDetails");
				dialog.close();

				/*	oDataModel.update(path, nameObj, null, function(responseBody, sucRes) {
					resultPer = true;

				}, function(failRes) {
					resultPer = false;
					errorBody = JSON.parse(failRes.response.body);

				});

				var that = this;
				if (resultPer === true) {
					that.setValPersonal();
					var dialog = sap.ui.getCore().byId("idDialogPerDetails");
					dialog.close();
					sap.m.MessageBox.show("This has been forwarded to HR for Approval", {
						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],
						onClose: function(oAction) {
							if (oAction === "OK") {
								//location.reload(true);

							}
						}.bind(that)
					});
				} else {
					sap.m.MessageBox.error("Message: " + errorBody.error.message.value);
				}*/
			}
		}
	},

	setValID: function() {
		sap.ui.getCore().byId("idValue").setValue("");
	},
	onCloseID: function() {
		this.setValID();
		var dialog = sap.ui.getCore().byId("idDialogEditIDs");
		dialog.close();
	},
	SubmitID: function() {
		var selectedVal = sap.ui.getCore().byId("idSelect").getSelectedItem().getText();
		var idValue = sap.ui.getCore().byId("idValue").getValue();
		var subtype;
		if (selectedVal === "Aadhar No") {
			subtype = "06";
		} else {
			subtype = "04"
		}

		var nameObj = {
			Employeenumber: p,
			IDNumber: idValue,
			Subtype: subtype,
			ObjectID: ""
		};
		var path = "IdentificationSet";
		var r = true;
		if (selectedVal === "Aadhar No") {
			var size = idValue.length;
			if (size !== 12) {
				sap.m.MessageBox.error("Please provide valid Aadhar No of Length 12");
				r = false;
			}
		}
		if (selectedVal === "Passport ID") {
			var psize = idValue.length;
			if (psize !== 8) {
				sap.m.MessageBox.error("Please provide valid Passport ID of Length 8 ");
				r = false;
			}
		}
		var resultId = false;
		if (r) {
			var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
			var errorBodyId;
			oDataModel.create(path, nameObj, null, function(responseBody, sucRes) {
				resultId = true;
			}, function(failRes) {
				resultId = false;
				errorBodyId = JSON.parse(failRes.response.body);

			});
			var that = this;
			if (resultId === true) {
				this.setValID();
				var dialog = sap.ui.getCore().byId("idDialogEditIDs");
				dialog.close();
				sap.m.MessageBox.show("ID Updated Successfully.", {
					icon: sap.m.MessageBox.Icon.SUCCESS,

					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						if (oAction == "OK") {
							//	location.reload(true);
						}
					}.bind(that)
				});
			} else {
				sap.m.MessageBox.error("\\n Message: " + errorBodyId.error.message.value);
			}

		}
	},

	onStatePerSelect: function(e) {
		var dialog = sap.ui.getCore().byId("statePerSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.StatePer", this);
			//this.addDependent(dialog);
		}
		dialog.open();
			this.setInitialFilter("StateTxt", "", dialog);
	},
	
	//Address Dialog binding for State value help

	onStateSelect: function(e) {
		var dialog = sap.ui.getCore().byId("stateSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.State", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("StateTxt", "", dialog);
	},
	//Address Dialog binding for Country value help 

	onCountryAddressSelect: function(e) {
		var dialog = sap.ui.getCore().byId("countryAddressSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CountryAddress", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("Country", "", dialog);

	},
	//District dialog binding
	onDistrictSelect: function(e) {
		var dialog = sap.ui.getCore().byId("districtSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.District", this);
			//this.addDependent(dialog);
		}
		dialog.open();
			this.setInitialFilter("Country", "", dialog);

	},
	//Institute Dialog binding for certificate value help
	onCertificateSelect: function(e) {
		var dialog = sap.ui.getCore().byId("certificateSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Certificate", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("CertificateTxt", "", dialog)
	},

	onEduEstSelect: function(e) {
		var dialog = sap.ui.getCore().byId("EduEstSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.EduEst", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		var certificateVal = sap.ui.getCore().byId("idCertificate").getValue();
		var eduEstJson = new sap.ui.model.json.JSONModel();
		var estSet = "SHEduEstablishSet?$filter=CertificateTxt eq '" + certificateVal + "' ";
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		oDataModel.read(estSet, null, null, false, function(r) {
			eduEstJson.setData(r);
			if (r.results.length == 1) {

			}
		});

		sap.ui.getCore().setModel(eduEstJson, "EduEstModel");

		this.setInitialFilter("EduEstablishTxt", "", dialog);
	},

	onInstituteSelect: function(e) {
		var dialog = sap.ui.getCore().byId("instituteSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Institute", this);
			// this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("Institute", "", dialog);
	},
	onCountrySelect: function(e) {
		var dialog = sap.ui.getCore().byId("countrySelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Country", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("Country", "", dialog);
	},

	onBranchSelect: function(e) {
		var dialog = sap.ui.getCore().byId("branchSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Branch", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		var eduEstVal = sap.ui.getCore().byId("idEduEst").getValue();
		var branchJson = new sap.ui.model.json.JSONModel();
		var branchSet = "SHBranchSet?$filter=EduEstablishTxt eq '" + eduEstVal + "'";
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		oDataModel.read(branchSet, null, null, false, function(r) {

			branchJson.setData(r);
		});
		sap.ui.getCore().setModel(branchJson, "BranchModel");
		this.setInitialFilter("BranchTxt", "", dialog);

	},
	onJobSelect: function(e) {
		var dialog = sap.ui.getCore().byId("JobSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Job", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("FormerJobTxt", "", dialog);

	},

	onEmployerSelect: function(e) {
		var dialog = sap.ui.getCore().byId("EmployerSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Employer", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("EmployerName", "", dialog);
	},

	onIndustrySelect: function(e) {
		var dialog = sap.ui.getCore().byId("industrySelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.Industry", this);
			//this.addDependent(dialog);
		}
		dialog.open();
		this.setInitialFilter("IndustrykeyTxt", "", dialog);

	},
	onCountryEmpSelect: function(e) {
		var dialog = sap.ui.getCore().byId("countryEmpSelectDialog");
		if (dialog === undefined) {
			dialog = sap.ui.xmlfragment("hcm.people.profile.Z_PEP_PROFEXT.fragments.CountryEmp", this);
			//this.addDependent(dialog);
		}
		dialog.open();
			this.setInitialFilter("Country", "", dialog);
	},
	setInitialFilter: function(title, f, s) {

		f = f.split(this.openingBracket)[0];
		s.open(f);
		var i = s.getBinding("items");

		this.filterDialog(title, f, i)

	},
	onSuggest: function(e) {
		var v = e.getParameter("suggestValue");
		var title;
		if (v !== undefined) {
			if (e.getSource().sId === "idRegion") {
				title = "StateTxt";
			} else if (e.getSource().sId === "idStatePer") {
				title = "StateTxt";
			} else if (e.getSource().sId === "idCountryAddress") {
				title = "Country";
			} else if (e.getSource().sId === "idCountryPer") {
				title = "Country";
			} else if (e.getSource().sId === "idCertificate") {
				title = "CertificateTxt";
			} else if (e.getSource().sId === "idEduEst") {
				title = "";
			} else if (e.getSource().sId === "idInstitute") {
				title = "Institute";
			} else if (e.getSource().sId === "idCountryIns") {
				title = "Country";
			} else if (e.getSource().sId === "idBranch") {
				title = "BranchTxt";
			} else if (e.getSource().sId === "idJob") {
				title = "FormerJobTxt";
			} else if (e.getSource().sId === "idEmployer") {
				title = "EmployerName";
			} else if (e.getSource().sId === "idIndustry") {
				title = "IndustrykeyTxt";
			} else if (e.getSource().sId === "idCountry") {
				title = "Country";
			} else if (e.getSource().sId === "idDistrict") {
				title = "District";
			}

			var oFilter = new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v);
			e.getSource().getBinding("suggestionItems").filter([oFilter]);
			this.filterDialog(title, v, e.getSource().getBinding("suggestionItems").filter([oFilter]));
		}
	},
	onSuggestionItemSelected: function(e) {
		var v = e.getParameter("selectedItem");
		if (v !== undefined) {

			var selectedItem = v.mProperties.text;
			if (e.getSource().sId === "idRegion") {
				this.selectedState = selectedItem;
			} else if (e.getSource().sId === "idStatePer") {
				this.selectedStatePer = selectedItem;
				
				var countryJson = new sap.ui.model.json.JSONModel();
				var countrySet = "SHCountrySet?$filter=StateTxt eq '" + this.selectedStatePer + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(countrySet, null, null, false, function(r) {
					countryJson.setData(r);
				});

				sap.ui.getCore().setModel(countryJson, "CountryModel");
					var dat = countryJson.getData().results;
				if (dat.length === 1) {
					sap.ui.getCore().byId("idCountryPer").setValue(dat[0].Country);
				} else {
					sap.ui.getCore().byId("idCountryPer").setValue("");
				}
				
				
			} else if (e.getSource().sId === "idCountryAddress") {
				this.selectedCountryAdd = selectedItem;

				/*	var stateJson = new sap.ui.model.json.JSONModel();
				var stateSet = "SHStateSet?$filter=Country eq '" + this.selectedCountryAdd + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(stateSet, null, null, false, function(r) {
					stateJson.setData(r);
				});

				sap.ui.getCore().setModel(stateJson, "StateModel");
			*/
			} else if (e.getSource().sId === "idCertificate") {
				this.selectedCertificate = selectedItem;
				var eduEstJson = new sap.ui.model.json.JSONModel();
				var estSet = "SHEduEstablishSet?$filter=CertificateTxt eq '" + this.selectedCertificate + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(estSet, null, null, false, function(r) {
					eduEstJson.setData(r);
				});

				sap.ui.getCore().setModel(eduEstJson, "EduEstModel");
				var dat = eduEstJson.getData().results;
				if (dat.length === 1) {
					sap.ui.getCore().byId("idEduEst").setValue(dat[0].EduEstablishTxt);
				} else {
					sap.ui.getCore().byId("idEduEst").setValue("")
				}
					var branchJson = new sap.ui.model.json.JSONModel();
		var branchSet = "SHBranchSet?$filter=EduEstablishTxt eq '" +dat[0].EduEstablishTxt+ "'";
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		oDataModel.read(branchSet, null, null, false, function(r) {

			branchJson.setData(r);
		});
		sap.ui.getCore().setModel(branchJson, "BranchModel");
			} else if (e.getSource().sId === "idEduEst") {
				this.selectedEduEst = selectedItem;
                	var branchJson = new sap.ui.model.json.JSONModel();
		var branchSet = "SHBranchSet?$filter=EduEstablishTxt eq '" + this.selectedEduEst + "'";
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		oDataModel.read(branchSet, null, null, false, function(r) {

			branchJson.setData(r);
		});
		sap.ui.getCore().setModel(branchJson, "BranchModel");
			} else if (e.getSource().sId === "idInstitute") {
				this.selectedInstitute = selectedItem;
			} else if (e.getSource().sId === "idCountryIns") {
				this.selectedCountry = selectedItem;
			} else if (e.getSource().sId === "idBranch") {
				this.selectedBranch = selectedItem;
			} else if (e.getSource().sId === "idJob") {
				this.selectedJob = selectedItem;
			} else if (e.getSource().sId === "idEmployer") {
				this.selectedEmployer = selectedItem;
			} else if (e.getSource().sId === "idIndustry") {
				this.selectedIndustry = selectedItem;
			} else if (e.getSource().sId === "idCountryPer") {
				this.selectedCountryPer = selectedItem;

			/*	var stateJson = new sap.ui.model.json.JSONModel();
				var stateSet = "SHStateSet?$filter=Country eq '" + this.selectedCountryPer + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(stateSet, null, null, false, function(r) {
					stateJson.setData(r);
				});

				sap.ui.getCore().setModel(stateJson, "StatePerModel");
				sap.ui.getCore().byId("idStatePer").setValue("");*/
			} else if (e.getSource().sId === "idDistrict") {
				this.selectedDistrict = selectedItem;

				/*var stateJson = new sap.ui.model.json.JSONModel();
				var stateSet = "SHStateSet?$filter=Country eq '" + this.selectedDistrict + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(stateSet, null, null, false, function(r) {
					stateJson.setData(r);
				});

				sap.ui.getCore().setModel(stateJson, "StatePerModel");
				sap.ui.getCore().byId("idStatePer").setValue("");
			*/
			var selectedValue = selectedItem.split("-");
				sap.ui.getCore().byId("idDistrict").setValue(selectedValue[0]);
				sap.ui.getCore().byId("idRegion").setValue(selectedValue[1]);
				sap.ui.getCore().byId("idCountryAddress").setValue(selectedValue[2]);
			}
		}
	},
	searchDialog: function(e) {
		var dialog = e.getSource().sId;
		var v = e.getParameter("value");
		var title;
		if (v !== undefined) {
			if (dialog === "stateSelectDialog") {
				title = "StateTxt";
			} else if (dialog === "countryAddressSelectDialog") {
				title = "Country";
			} else if (dialog === "certificateSelectDialog") {
				title = "CertificateTxt";
			} else if (dialog === "EduEstSelectDialog") {
				title = "EduEstablishTxt";
			} else if (dialog === "instituteSelectDialog") {
				title = "Institute";
			} else if (dialog === "countrySelectDialog") {
				title = "Country";
			} else if (dialog === "branchSelectDialog") {
				title = "BranchTxt";
			} else if (dialog === "JobSelectDialog") {
				title = "FormerJobTxt";
			} else if (dialog === "EmployerSelectDialog") {
				title = "EmployerName";
			} else if (dialog === "industrySelectDialog") {
				title = "IndustrykeyTxt";
			} else if (dialog === "countryEmpSelectDialog") {
				title = "Country";
			} else if (dialog === "statePerSelectDialog") {
				title = "StateTxt";
			} else if (dialog === "districtSelectDialog") {
				title = "District";
			}
			var oFilter = new sap.ui.model.Filter(new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v), false);

			e.getSource().getBinding("items").filter([oFilter]);

			this.filterDialog(title, v, e.getSource().getBinding("items").filter([oFilter]));
		}

	},
	filterDialog: function(title, v, i) {

		var f = [];

		var s = new sap.ui.model.Filter(title, sap.ui.model.FilterOperator.Contains, v);

		f.push(s);

		i.filter(f);

	},

	cancelSelectDialog: function(e) {},

	confirmSelectDialog: function(e) {
		var dialog = e.getSource().sId;
		var s = e.getParameter("selectedItem");
		var path;
		if (s) {
			if (dialog === "stateSelectDialog") {
				path = s.oBindingContexts.StateModel.sPath.split("/");
				sap.ui.getCore().byId("idRegion").setValue(s.getTitle());
				this.stateDialog = sap.ui.getCore().byId("idRegion").getValue();
				sap.ui.getCore().byId("idDistrict").setValue("");
			} else if (dialog === "countryAddressSelectDialog") {
				path = s.oBindingContexts.CountryModel.sPath.split("/");
				sap.ui.getCore().byId("idCountryAddress").setValue(s.getTitle());
				this.countryAddressDialog = sap.ui.getCore().byId("idCountryAddress").getValue();
				var stateJson = new sap.ui.model.json.JSONModel();
				var stateSet = "SHStateSet?$filter=Country eq '" + this.countryAddressDialog + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(stateSet, null, null, false, function(r) {
					stateJson.setData(r);
				});
                
				sap.ui.getCore().setModel(stateJson, "StateModel");
				sap.ui.getCore().byId("idRegion").setValue("");
                sap.ui.getCore().byId("idDistrict").setValue("");
			} else if (dialog === "certificateSelectDialog") {
				path = s.oBindingContexts.CertificateModel.sPath.split("/");
				sap.ui.getCore().byId("idCertificate").setValue(s.getTitle());
				var estSet = "SHEduEstablishSet?$filter=CertificateTxt eq '" + s.getTitle() + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
				var eduEstJson = new sap.ui.model.json.JSONModel();
				oDataModel.read(estSet, null, null, false, function(r) {
					eduEstJson.setData(r);
				});
				var dat = eduEstJson.getData().results;
				if (dat.length === 1) {
					sap.ui.getCore().byId("idEduEst").setValue(dat[0].EduEstablishTxt);
				} else {
					sap.ui.getCore().byId("idEduEst").setValue("")
				}
                
				this.certificateDialog = sap.ui.getCore().byId("idCertificate").getValue();
				
					var branchJson = new sap.ui.model.json.JSONModel();
		var branchSet = "SHBranchSet?$filter=EduEstablishTxt eq '" + dat[0].EduEstablishTxt + "'";
		oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

		oDataModel.read(branchSet, null, null, false, function(r) {

			branchJson.setData(r);
		});
		sap.ui.getCore().setModel(branchJson, "BranchModel");
			} else if (dialog === "EduEstSelectDialog") {
				path = s.oBindingContexts.EduEstModel.sPath.split("/");
				sap.ui.getCore().byId("idEduEst").setValue(s.getTitle());
				this.eduEstDialog = sap.ui.getCore().byId("idEduEst").getValue();
			} else if (dialog === "instituteSelectDialog") {
				path = s.oBindingContexts.InstituteModel.sPath.split("/");
				sap.ui.getCore().byId("idInstitute").setValue(s.getTitle());
				this.instituteDialog = sap.ui.getCore().byId("idInstitute").getValue();
			} else if (dialog === "countrySelectDialog") {
				path = s.oBindingContexts.CountryModel.sPath.split("/");
				sap.ui.getCore().byId("idCountryIns").setValue(s.getTitle());
				this.countryInsDialog = sap.ui.getCore().byId("idCountryIns").getValue();

			} else if (dialog === "branchSelectDialog") {
				path = s.oBindingContexts.BranchModel.sPath.split("/");
				sap.ui.getCore().byId("idBranch").setValue(s.getTitle());
				this.branchDialog = sap.ui.getCore().byId("idBranch").getValue();
			} else if (dialog === "JobSelectDialog") {
				path = s.oBindingContexts.JobModel.sPath.split("/");
				sap.ui.getCore().byId("idJob").setValue(s.getTitle());
				this.jobDialog = sap.ui.getCore().byId("idJob").getValue();
			} else if (dialog === "EmployerSelectDialog") {
				path = s.oBindingContexts.EmployerModel.sPath.split("/");
				sap.ui.getCore().byId("idEmployer").setValue(s.getTitle());
				this.employerDialog = sap.ui.getCore().byId("idEmployer").getValue();
			} else if (dialog === "industrySelectDialog") {
				path = s.oBindingContexts.IndustryModel.sPath.split("/");
				sap.ui.getCore().byId("idIndustry").setValue(s.getTitle());
				this.industryDialog = sap.ui.getCore().byId("idIndustry").getValue();
			} else if (dialog === "countryEmpSelectDialog") {
				path = s.oBindingContexts.CountryModel.sPath.split("/");
				sap.ui.getCore().byId("idCountryPer").setValue(s.getTitle());
				this.countryPerDialog = sap.ui.getCore().byId("idCountryPer").getValue();
				/*var stateJson = new sap.ui.model.json.JSONModel();
				var stateSet = "SHStateSet?$filter=Country eq '" + this.countryPerDialog + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(stateSet, null, null, false, function(r) {
					stateJson.setData(r);
				});

				sap.ui.getCore().setModel(stateJson, "StatePerModel");
				sap.ui.getCore().byId("idStatePer").setValue("");*/

			} else if (dialog === "statePerSelectDialog") {
				path = s.oBindingContexts.StatePerModel.sPath.split("/");
				sap.ui.getCore().byId("idStatePer").setValue(s.getTitle());
				this.statePerDialog = sap.ui.getCore().byId("idStatePer").getValue();
				
				var countryJson = new sap.ui.model.json.JSONModel();
				var countrySet = "SHCountrySet?$filter=StateTxt eq '" + this.statePerDialog  + "' ";
				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");

				oDataModel.read(countrySet, null, null, false, function(r) {
					countryJson.setData(r);
				});

				sap.ui.getCore().setModel(countryJson, "CountryModel");
					var dat = countryJson.getData().results;
				if (dat.length === 1) {
					sap.ui.getCore().byId("idCountryPer").setValue(dat[0].Country);
				} else {
					sap.ui.getCore().byId("idCountryPer").setValue("");
				}
			
			} else if (dialog === "districtSelectDialog") {
				path = s.oBindingContexts.DistrictModel.sPath.split("/");
				var selectedValue = s.getTitle().split("-");
				sap.ui.getCore().byId("idDistrict").setValue(selectedValue[0]);
				sap.ui.getCore().byId("idRegion").setValue(selectedValue[1]);
				sap.ui.getCore().byId("idCountryAddress").setValue(selectedValue[2]);
				this.districtDialog = sap.ui.getCore().byId("idDistrict").getValue();
			}

		}
	},
	onChangeDistrict : function(){
	    sap.ui.getCore().byId("idRegion").setValue("");
	    sap.ui.getCore().byId("idCountryAddress").setValue("");
	},

	handleTypeMissmatch: function(oEvent) {
		var aFileTypes = oEvent.getSource().getFileType();
		jQuery.each(aFileTypes, function(key, value) {
			aFileTypes[key] = "*." + value
		});
		var sSupportedFileTypes = aFileTypes.join(", ");
		sap.m.MessageBox.error("The file type *." + oEvent.getParameter("fileType") +
			" is not supported. Choose one of the following types: " +
			sSupportedFileTypes);
	},

	handleValueChange: function(oEvent) {

	},

	handleUploadComplete: function(oEvent) {
		var sResponse = oEvent.getParameter("response");
		if (sResponse) {
			var sMsg = "";
			var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
			if (m[1] == "200") {
				sMsg = "Return Code: " + m[1] + "\n" + m[2], "SUCCESS", "Upload Success";
				oEvent.getSource().setValue("");
			} else {
				sMsg = "Return Code: " + m[1] + "\n" + m[2], "ERROR", "Upload Error";
			}

			sap.m.MessageToast.show(sMsg);
		}
	},

	handleUploadPress: function(evt) {
		var myjson = new sap.ui.model.json.JSONModel();
		var mydata = {
			"myFiles": [
	                                                                ]
		};
		myjson.setData(mydata);
		sap.ui.getCore().byId("idFileTable").setModel(myjson);
		fileCollection = new Array();
		var myjson = new sap.ui.model.json.JSONModel();
		var mydata = {
			"myFiles": []
		};

		myjson.setData(mydata);

		sap.ui.getCore().setModel("FileModel", myjson);

		sap.ui.getCore().byId("idFileTable").setModel(myjson);
		sap.ui.getCore().byId("idFileTable").setVisible(true);

		var oTable = sap.ui.getCore().byId("idFileTable");

		var colItems = new sap.m.ColumnListItem({

			type: "Active"

		});

		oTable.bindAggregation("items", "/myFiles", colItems);

		var txtNAME = new sap.m.Text({

			text: "{fileName}"

		});

		colItems.addCell(txtNAME);
		var that = this;
		var button = new sap.ui.core.Icon({

			src: "sap-icon://delete",

			press: function(e) {

				var selectedRow = parseInt(e.getSource().getId().split("idFileTable-")[1]);

				var items = sap.ui.getCore().byId("idFileTable").getItems();

				items[selectedRow].getAggregation("cells")[2].setValue("D");

				var assFileList = {};

				var assFile = [];

				assFileList["myFiles"] = assFile;

				var myAssFileModel = new sap.ui.model.json.JSONModel();

				myAssFileModel.setData(assFileList);

				var myNewModelData = myAssFileModel.oData.myFiles;

				items = sap.ui.getCore().byId("idFileTable").getItems();

				for (var i = 0; i < items.length; i++) {

					var inputValue = items[i].getAggregation("cells")[0].getText();

					var delFlag = items[i].getAggregation("cells")[2].getValue();

					var taskData = {};

					if (delFlag === "I") {

						taskData.fileName = inputValue;

						taskData.Updkz = delFlag;

						myNewModelData.push(taskData);

					}

				}

				sap.ui.getCore().byId("idFileTable").setModel(myAssFileModel);

				var newfileCollection = new Array();

				for (var i = 0; i < myNewModelData.length; i++) {

					for (var j = 0; j < fileCollection.length; j++) {

						if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {

							var fileData = {

								Employeenumber: fileCollection[j].Employeenumber,
								Subtype: fileCollection[j].Subtype,
								Infotype: fileCollection[j].Infotype,
								FileContent: fileCollection[j].FileContent,
								FileContentType: fileCollection[j].FileContentType,
								FileLength: fileCollection[j].FileLength,
								FileName: fileCollection[j].FileName,
								StringUpload: fileCollection[j].StringUpload,
								EvFlag: fileCollection[j].EvFlag
							};

							newfileCollection.push(fileData);

						}

					}

				}

				fileCollection = newfileCollection;
				sap.ui.getCore().byId("idFileTable").setVisible(false);

				that.setFileAttachments(fileCollection);
			}

		});

		colItems.addCell(button);

		var txtNAME3 = new sap.m.Input({

			value: "{Updkz}",

			visible: false

		});

		colItems.addCell(txtNAME3);

		//end table

		var getFileCollection = this.getFileAttachments();
		if (getFileCollection === null) {
			fileCollection = new Array();
		}
		var oUploader = sap.ui.getCore().byId("fileUploader");
		var oFileUploader = sap.ui.getCore().byId("fileUploader");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];
		var BASE64_MARKER = 'data:' + file.type + ';base64,';

		var filename = file.name;
		var that = this;

		try {

			var reader = new FileReader();
			// On load set file contents to text view
			reader.onload = (function(theFile) {
				return function(evt) {
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

					var base64 = evt.target.result.substring(base64Index);

					var docType = "";
					var contentType = "";
					if (file.type === "application/msword") {
						docType = "DOC";
						contentType = ".doc";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
						docType = "DOC";
						contentType = ".docx";
					} else if (file.type === "image/jpeg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/jpg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/gif") {
						docType = "SIM";
						contentType = ".gif";
					} else if (file.type === "application/pdf") {
						docType = "PDF";
						contentType = ".pdf";
					} else if (file.type === "text/plain") {
						docType = "TXT";
						contentType = ".txt";
					} else if (file.type === "image/tiff") {
						docType = "TIF";
						contentType = ".tiff";
					} else if (file.type === "application/xml") {
						docType = "XML";
						contentType = ".xml";
					} else if (file.type === "application/vnd.ms-excel" || file.type ===
						"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xls";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xlsx";
					} else if (file.type === "video/mpeg") {
						docType = "MPP";
						contentType = ".m2v";
					} else if (file.type === "video/mp3") {
						docType = "MPP";
						contentType = ".mp3";
					}

					// *****************************
					var fileData = {

						Employeenumber: p,
						Infotype: "0006",
						Subtype: "2",
						FileContent: base64,
						FileContentType: contentType,
						FileLength: "",
						FileName: filename,
						StringUpload: p,
						EvFlag: ""
					};
					fileCollection.push(fileData);
					that.setFileAttachments(fileCollection);
					sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({
						fileName: filename,
						Updkz: "I"
					});

					sap.ui.getCore().byId("idFileTable").getModel().refresh(true);
					oFileUploader.setValue("");

				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);

			return;

		} catch (e) {
			sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");
			//do something
			return;
		}
	},

	handleUploadPressIns: function(evt) {
		fileCollectionIns = new Array();

		var myjsonIns = new sap.ui.model.json.JSONModel();

		var mydataIns = {

			"myFiles": []

		};

		myjsonIns.setData(mydataIns);

		sap.ui.getCore().setModel("FileModel", myjsonIns);

		sap.ui.getCore().byId("idFileTableIns").setModel(myjsonIns);
		sap.ui.getCore().byId("idFileTableIns").setVisible(true);

		var oTable = sap.ui.getCore().byId("idFileTableIns");

		var colItems = new sap.m.ColumnListItem({

			type: "Active"

		});

		oTable.bindAggregation("items", "/myFiles", colItems);

		var txtNAME = new sap.m.Text({

			text: "{fileName}"

		});

		colItems.addCell(txtNAME);

		var button = new sap.ui.core.Icon({

			src: "sap-icon://delete",

			press: function(e) {

				var selectedRow = parseInt(e.getSource().getId().split("idFileTableIns-")[1]);

				var items = sap.ui.getCore().byId("idFileTableIns").getItems();

				items[selectedRow].getAggregation("cells")[2].setValue("D");

				var assFileListIns = {};

				var assFileIns = [];

				assFileListIns["myFiles"] = assFileIns;

				var myAssFileModelIns = new sap.ui.model.json.JSONModel();

				myAssFileModelIns.setData(assFileListIns);

				var myNewModelDataIns = myAssFileModelIns.oData.myFiles;

				items = sap.ui.getCore().byId("idFileTableIns").getItems();

				for (var i = 0; i < items.length; i++) {

					var inputValue = items[i].getAggregation("cells")[0].getText();

					var delFlag = items[i].getAggregation("cells")[2].getValue();

					var taskData = {};

					if (delFlag === "I") {

						taskData.fileName = inputValue;

						taskData.Updkz = delFlag;

						myNewModelDataIns.push(taskData);

					}

				}

				sap.ui.getCore().byId("idFileTableIns").setModel(myAssFileModelIns);

				var newfileCollection = new Array();

				for (var i = 0; i < myNewModelDataIns.length; i++) {

					for (var j = 0; j < fileCollection.length; j++) {

						if (fileCollectionIns[j].DocOrigin === myNewModelDataIns[i].fileName) {

							var fileData = {

								Employeenumber: fileCollectionIns[j].Employeenumber,
								Subtype: fileCollectionIns[j].Subtype,
								Infotype: fileCollectionIns[j].Infotype,
								FileContent: fileCollectionIns[j].FileContent,
								FileContentType: fileCollectionIns[j].FileContentType,
								FileLength: fileCollectionIns[j].FileLength,
								FileName: fileCollectionIns[j].FileName,
								StringUpload: fileCollectionIns[j].StringUpload,
								EvFlag: fileCollectionIns[j].EvFlag

							};

							newfileCollection.push(fileData);

						}

					}

				}

				fileCollectionIns = newfileCollection;
                	sap.ui.getCore().byId("idFileTableIns").setVisible(false);
				that.setFileAttachmentsIns(fileCollectionIns);

			}

		});

		colItems.addCell(button);

		var txtNAME3 = new sap.m.Input({

			value: "{Updkz}",

			visible: false

		});

		colItems.addCell(txtNAME3);

		//end table

		var getFileCollection = this.getFileAttachmentsIns();
		if (getFileCollection === null) {
			fileCollection = new Array();
		}

		var oUploader = sap.ui.getCore().byId("fileUploaderIns");
		var oFileUploader = sap.ui.getCore().byId("fileUploaderIns");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];
		var BASE64_MARKER = 'data:' + file.type + ';base64,';

		var filename = file.name;
		var that = this;

		try {

			var reader = new FileReader();
			// On load set file contents to text view
			reader.onload = (function(theFile) {
				return function(evt) {
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

					var base64 = evt.target.result.substring(base64Index);

					var docType = "";
					var contentType = "";
					if (file.type === "application/msword") {
						docType = "DOC";
						contentType = ".doc";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
						docType = "DOC";
						contentType = ".docx";
					} else if (file.type === "image/jpeg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/jpg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/gif") {
						docType = "SIM";
						contentType = ".gif";
					} else if (file.type === "application/pdf") {
						docType = "PDF";
						contentType = ".pdf";
					} else if (file.type === "text/plain") {
						docType = "TXT";
						contentType = ".txt";
					} else if (file.type === "image/tiff") {
						docType = "TIF";
						contentType = ".tiff";
					} else if (file.type === "application/xml") {
						docType = "XML";
						contentType = ".xml";
					} else if (file.type === "application/vnd.ms-excel" || file.type ===
						"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xls";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xlsx";
					} else if (file.type === "video/mpeg") {
						docType = "MPP";
						contentType = ".m2v";
					} else if (file.type === "video/mp3") {
						docType = "MPP";
						contentType = ".mp3";
					}
					var eduEstVal = sap.ui.getCore().byId("idEduEst").getValue();
					// *****************************
					var fileData = {

						Employeenumber: p,
						Infotype: "0022",
						Subtype: "",
						FileContent: base64,
						FileContentType: contentType,
						FileLength: "",
						FileName: filename,
						StringUpload: p,
						EvFlag: "",
						EduEstablishTxt: eduEstVal
					};
					fileCollectionIns.push(fileData);
					that.setFileAttachmentsIns(fileCollectionIns);
					sap.ui.getCore().byId("idFileTableIns").getModel().getData().myFiles.push({
						fileName: filename,
						Updkz: "I"
					});

					sap.ui.getCore().byId("idFileTableIns").getModel().refresh(true);
					oFileUploader.setValue("");

				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);

			return;

		} catch (e) {
			sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");
			//do something
			return;
		}
	},

	handleUploadPressEmp: function(evt) {

		fileCollectionEmp = new Array();

		var myjsonEmp = new sap.ui.model.json.JSONModel();

		var mydataEmp = {

			"myFiles": []

		};

		myjsonEmp.setData(mydataEmp);

		sap.ui.getCore().setModel("FileModel", myjsonEmp);

		sap.ui.getCore().byId("idFileTableEmp").setModel(myjsonEmp);

		var oTable = sap.ui.getCore().byId("idFileTableEmp");

		var colItems = new sap.m.ColumnListItem({

			type: "Active"

		});

		oTable.bindAggregation("items", "/myFiles", colItems);

		var txtNAME = new sap.m.Text({

			text: "{fileName}"

		});

		colItems.addCell(txtNAME);

		var button = new sap.ui.core.Icon({

			src: "sap-icon://delete",

			press: function(e) {

				var selectedRow = parseInt(e.getSource().getId().split("idFileTableEmp-")[1]);

				var items = sap.ui.getCore().byId("idFileTableEmp").getItems();

				items[selectedRow].getAggregation("cells")[2].setValue("D");

				var assFileListEmp = {};

				var assFileEmp = [];

				assFileListEmp["myFiles"] = assFileEmp;

				var myAssFileModelEmp = new sap.ui.model.json.JSONModel();

				myAssFileModelEmp.setData(assFileListEmp);

				var myNewModelData = myAssFileModelEmp.oData.myFiles;

				items = sap.ui.getCore().byId("idFileTableEmp").getItems();

				for (var i = 0; i < items.length; i++) {

					var inputValue = items[i].getAggregation("cells")[0].getText();

					var delFlag = items[i].getAggregation("cells")[2].getValue();

					var taskData = {};

					if (delFlag === "I") {

						taskData.fileName = inputValue;

						taskData.Updkz = delFlag;

						myNewModelData.push(taskData);

					}

				}

				sap.ui.getCore().byId("idFileTableEmp").setModel(myAssFileModelEmp);

				var newfileCollection = new Array();

				for (var i = 0; i < myNewModelData.length; i++) {

					for (var j = 0; j < fileCollection.length; j++) {

						if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {

							var fileData = {

								Employeenumber: fileCollectionIns[j].Employeenumber,
								Subtype: fileCollectionIns[j].Subtype,
								Infotype: fileCollectionIns[j].Infotype,
								FileContent: fileCollectionIns[j].FileContent,
								FileContentType: fileCollectionIns[j].FileContentType,
								FileLength: fileCollectionIns[j].FileLength,
								FileName: fileCollectionIns[j].FileName,
								StringUpload: fileCollectionIns[j].StringUpload,
								EvFlag: fileCollectionIns[j].EvFlag

							};

							newfileCollection.push(fileData);

						}

					}

				}

				fileCollectionEmp = newfileCollection;
                sap.ui.getCore().byId("idFileTableEmp").setVisible(false);
				that.setFileAttachmentsEmp(fileCollectionEmp);

			}

		});

		colItems.addCell(button);

		var txtNAME3 = new sap.m.Input({

			value: "{Updkz}",

			visible: false

		});

		colItems.addCell(txtNAME3);

		//end table

		var getFileCollection = this.getFileAttachmentsEmp();
		if (getFileCollection === null) {
			fileCollection = new Array();
		}

		var oView = this.getView();
		var oUploader = sap.ui.getCore().byId("fileUploaderEmp");
		var oFileUploader = sap.ui.getCore().byId("fileUploaderEmp");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];
		var BASE64_MARKER = 'data:' + file.type + ';base64,';

		var filename = file.name;
		var that = this;

		try {

			var reader = new FileReader();
			// On load set file contents to text view
			reader.onload = (function(theFile) {
				return function(evt) {
					var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

					var base64 = evt.target.result.substring(base64Index);

					var docType = "";
					var contentType = "";
					if (file.type === "application/msword") {
						docType = "DOC";
						contentType = ".doc";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
						docType = "DOC";
						contentType = ".docx";
					} else if (file.type === "image/jpeg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/jpg") {
						docType = "SIM";
						contentType = ".jpg";
					} else if (file.type === "image/gif") {
						docType = "SIM";
						contentType = ".gif";
					} else if (file.type === "application/pdf") {
						docType = "PDF";
						contentType = ".pdf";
					} else if (file.type === "text/plain") {
						docType = "TXT";
						contentType = ".txt";
					} else if (file.type === "image/tiff") {
						docType = "TIF";
						contentType = ".tiff";
					} else if (file.type === "application/xml") {
						docType = "XML";
						contentType = ".xml";
					} else if (file.type === "application/vnd.ms-excel" || file.type ===
						"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xls";
					} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
						docType = "XLS";
						contentType = ".xlsx";
					} else if (file.type === "video/mpeg") {
						docType = "MPP";
						contentType = ".m2v";
					} else if (file.type === "video/mp3") {
						docType = "MPP";
						contentType = ".mp3";
					}

					// *****************************
					var fileData = {

						Employeenumber: p,
						Infotype: "0023",
						Subtype: "",
						FileContent: base64,
						FileContentType: contentType,
						FileLength: "",
						FileName: filename,
						StringUpload: p,
						EvFlag: ""
					};
					fileCollectionEmp.push(fileData);
					that.setFileAttachmentsEmp(fileCollectionEmp);
					sap.ui.getCore().byId("idFileTableEmp").getModel().getData().myFiles.push({
						fileName: filename,
						Updkz: "I"
					});

					sap.ui.getCore().byId("idFileTableEmp").getModel().refresh(true);
					oFileUploader.setValue("");

				};
			})(file);
			// Read in the file as text
			reader.readAsDataURL(file);

			return;

		} catch (e) {
			sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");
			//do something
			return;
		}
	},
	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},
	setFileAttachmentsIns: function(files) {

		this.fileAttData = files;

	},

	getFileAttachmentsIns: function() {

		return this.fileAttData;

	},
	setFileAttachmentsEmp: function(files) {

		this.fileAttData = files;

	},

	getFileAttachmentsEmp: function() {

		return this.fileAttData;

	},
	checkCertificate: function(oEvent) {

		var value = oEvent.getSource();
		var certiVal = sap.ui.getCore().byId("idCertificate").getValue();
		if (certiVal === " ") {
			sap.ui.getCore().byId("idEduEst").setValue(" ");
			sap.ui.getCore().byId("idEduEst").setPlaceholder("Mandatory field-type for search for values");
		}
	},
	emerAddress: function(oEvent) {
		var sId = oEvent.getSource().sId;

		if (sId === "idradio1") {
			var pModel = sap.ui.getCore().getModel("permanentModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {

					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idContactName").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {

				sap.ui.getCore().byId("idContactName").setValue("");

				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}
		} else if (sId === "idradio2") {
			var pModel = sap.ui.getCore().getModel("temporaryModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {

					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idContactName").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {

				sap.ui.getCore().byId("idContactName").setValue("");

				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}
		} else if (sId === "idradio3") {
			var pModel = sap.ui.getCore().getModel("emergencyModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {

					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idContactName").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {

				sap.ui.getCore().byId("idContactName").setValue("");

				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}
		}
	},
	addressHelp: function() {

	},
	SubmitAddIns : function(){
	    	var c = "Education Details";
		var certiVal = sap.ui.getCore().byId("idCertificate").getValue();
		var instituteVal = sap.ui.getCore().byId("idInstitute").getValue();
		var eduEstVal = sap.ui.getCore().byId("idEduEst").getValue();
		var branchVal = sap.ui.getCore().byId("idBranch").getValue();
		/*	var durationVal = sap.ui.getCore().byId("idDur").getValue();
		var unitVal = sap.ui.getCore().byId("idUnit").getSelectedItem().getText();*/
		var countryVal = sap.ui.getCore().byId("idCountryIns").getValue();
		var highestEduVal = sap.ui.getCore().byId("idHighestEdu").getSelectedItem().getText();
		var startDate = sap.ui.getCore().byId("startDate").getDateValue();
		var endDate = sap.ui.getCore().byId("endDate").getDateValue();
		var highEdu;
		if (highestEduVal === "Yes") {
			highEdu = "Y"
		} else {
			highEdu = " "
		}
		var r = true;

		if (certiVal === "" || (this.certificateDialog !== certiVal && this.selectedCertificate !== certiVal)) {
			sap.ui.getCore().byId("idCertificate").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCertificate").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCertificate").setValueState(sap.ui.core.ValueState.None);
		}

		if (instituteVal === "") {
			sap.ui.getCore().byId("idInstitute").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idInstitute").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idInstitute").setValueState(sap.ui.core.ValueState.None);
		}

		if (eduEstVal === "" || ((this.eduEstDialog !== eduEstVal && this.eduEstDialog !== undefined) && this.selectedEduEst !== eduEstVal)) {
			sap.ui.getCore().byId("idEduEst").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idEduEst").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idEduEst").setValueState(sap.ui.core.ValueState.None);
		}

		if (branchVal === "" || (this.branchDialog !== branchVal && this.selectedBranch !== branchVal)) {
			sap.ui.getCore().byId("idBranch").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idBranch").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idBranch").setValueState(sap.ui.core.ValueState.None);
		}

		if (countryVal === "" || (this.countryInsDialog !== countryVal && this.selectedCountry !== countryVal)) {
			sap.ui.getCore().byId("idCountryIns").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("idCountryIns").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("idCountryIns").setValueState(sap.ui.core.ValueState.None);
		}

		if (startDate === "" || startDate === null) {
			sap.ui.getCore().byId("startDate").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("startDate").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("startDate").setValueState(sap.ui.core.ValueState.None);
		}

		if (endDate === "" || endDate === null) {
			sap.ui.getCore().byId("endDate").setValueState(sap.ui.core.ValueState.Error);
			sap.ui.getCore().byId("endDate").setValueStateText("Enter Value");
			r = false;
		} else {
			sap.ui.getCore().byId("endDate").setValueState(sap.ui.core.ValueState.None);
		}
		if (sap.ui.getCore().byId("fileUploaderIns").getVisible()) {
			if (this.getFileAttachmentsIns() === undefined || this.getFileAttachmentsIns === null || this.getFileAttachmentsIns().length === 0) {
				sap.ui.getCore().byId("fileUploaderIns").setValueState(sap.ui.core.ValueState.Error);
				// sap.ui.getCore().byId("fileUploaderIns").setValueStateText("Upload File");
				r = false;
			} else {
				sap.ui.getCore().byId("fileUploaderIns").setValueState(sap.ui.core.ValueState.None);
			}
		}

		if (r === false) {
			//sap.m.MessageBox.error("Please fill all Mandatory Fields");
			sap.ui.getCore().byId("idReqIns").setVisible(true);
		} else {
			sap.ui.getCore().byId("idReqIns").setVisible(false);
		}
		if (r) {
		     sap.ui.getCore().byId(parentId+"--idSubmitProfile").setEnabled(true);
			var formattedStartDate = new Date(startDate);
			formattedStartDate = this.ui5ToOdatadataForLocalFiltering(startDate, 'date');

			var formattedEndDate = new Date(endDate);
			formattedEndDate = this.ui5ToOdatadataForLocalFiltering(endDate, 'date');

			if (formattedStartDate < formattedEndDate) {
				var path = "EducationSet";
				var objectID = " ";
				b[c].vals.forEach(function(h) {
					if (h.SubGroupname === certiVal) {
						objectID = h.ObjectID;
						if (objectID === "NaN" || objectID === "") {
							objectID = "0";
						}
						objectID = parseInt(objectID) + 1;
						objectID = "" + objectID;
					}

				});
				var eduObj = {
					Employeenumber: p,
					Institute: instituteVal,
					CertificateTxt: certiVal,
					BranchTxt: branchVal,
					Duration: "",
					TimeTxt: "",
					Country: countryVal,
					ObjectID: objectID,
					EduEstablishTxt: eduEstVal,
					StartDate: formattedStartDate,
					EndDate: formattedEndDate,
					HighestEducation: highEdu
				};

				oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true, "", "");
				var errorBodyIns;
    			batch.push(oDataModel.createBatchOperation(path, "POST", eduObj));
				var attchCreate = "AttachmentCreateSet";
				var oFiles = [];
				var attchObj = {};

				if (this.getFileAttachmentsIns() === undefined || this.getFileAttachmentsIns() === null) {

				} else {
					var fileData = this.getFileAttachments();

					if (fileData !== null) {

						attchObj = fileData[0];
					}
				}

				batch.push(oDataModel.createBatchOperation(attchCreate, "POST", attchObj));
				this.setValInstitute();
				sap.ui.getCore().byId("idFileTableIns").setVisible(false);
			} else {
				sap.m.MessageBox.error("Start date should not be greater than End date");
			}
		}
	
	    
	},
	onResetAddress : function(){
	    	var pModel = sap.ui.getCore().getModel("emergencyModel");
			if (pModel.item.length > 1) {
				for (var i = 0; i < pModel.item.length; i++) {

					if (pModel.item[i].title === "House No/Street") {
						sap.ui.getCore().byId("idHouseNo").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Contact Name") {
						sap.ui.getCore().byId("idContactName").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "2nd Address Line") {
						sap.ui.getCore().byId("idAddLine").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "City") {
						sap.ui.getCore().byId("idCity").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "District") {
						sap.ui.getCore().byId("idDistrict").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Region") {
						sap.ui.getCore().byId("idRegion").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Postal Code") {
						sap.ui.getCore().byId("idPostalCode").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Country Name") {
						sap.ui.getCore().byId("idCountryAddress").setValue(pModel.item[i].value);
					} else if (pModel.item[i].title === "Telephone Number") {
						sap.ui.getCore().byId("idTelNum").setValue(pModel.item[i].value);
					}
				}
			} else {

				sap.ui.getCore().byId("idContactName").setValue("");

				sap.ui.getCore().byId("idHouseNo").setValue("");

				sap.ui.getCore().byId("idAddLine").setValue("");

				sap.ui.getCore().byId("idCity").setValue("");

				sap.ui.getCore().byId("idDistrict").setValue("");

				sap.ui.getCore().byId("idRegion").setValue("");

				sap.ui.getCore().byId("idPostalCode").setValue("");

				sap.ui.getCore().byId("idCountryAddress").setValue("");

				sap.ui.getCore().byId("idTelNum").setValue("");
			}
			
			sap.ui.getCore().byId("idradio1").setSelected(false);
			sap.ui.getCore().byId("idradio2").setSelected(false);
	}

});