/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.ZSRM_SC_ACK.util.Formatter");

sap.ui.controller("ui.s2p.srm.sc.track.ZSRM_SC_ACK.view.S3Custom", {
	onInit: function() {
		this.OBJECT_ID = "";
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		this.busyDialog = new sap.m.BusyDialog({
			customIcon: sap.ca.ui.images.images.Flower
		});
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "detail") {
				var c = e.getParameter("arguments").contextPath;
				var s = c.split("ordertrackCollection('");
				var o = s[0].split("'")[3];
				var a = s[0].split("'")[1];
				this.sapOrigin = a;
				this.busyDialog.open();
				this.getCartInfo(o);
				this.getCartItems(o);
				this.getApprovalDetails(o)
			}
		}, this);
		var h = this.byId("header");
		var i = this.byId("itemList");
		if (i) {
			h.addEventDelegate({
				onAfterRendering: this.updateItemsList
			}, this)
		}
	},
	getHeaderFooterOptions: function() {
		return {
			sI18NDetailTitle: "TITLE_RECENT_CART",
			oAddBookmarkSettings: {
				title: this.oBundle.getText("TITLE_RECENT_CART"),
				icon: "sap-icon://cart"
			},
			oJamOptions: {
				oShareSettings: {
					object: {
						id: this.approvalLink,
						display: this.oDisplay,
						share: this.object_ID
					}
				},
			}
		}
	},
	getCartInfo: function(o) {
		this.getView().byId("icontabBar").setSelectedKey("Information");
		var a = function(D, r) {
			var h = new sap.ui.model.json.JSONModel(D);
			if (D.WIID != '000000000000') {
				this.approvalLink = document.location.origin + document.location.pathname + document.location.search +
					"#ShoppingCartItem-approve&/detail/WorkflowTaskCollection(SAP__Origin=" + jQuery.sap.encodeURL("'") + this.sapOrigin + jQuery.sap.encodeURL(
						"'") + ",WorkitemID=" + jQuery.sap.encodeURL("'") + D.WIID + jQuery.sap.encodeURL("'") + ")"
			} else {
				this.approvalLink = ''
			}
			this.object_ID = o;
			this.objectStatus = new sap.m.ObjectStatus({
				text: D.HEADER_STATUS_DESCR
			});
			this.oDisplay = new sap.m.ObjectListItem({
				title: this.oBundle.getText("CART") + " " + D.OBJECT_ID,
				number: D.TOTAL_GROSS,
				numberUnit: D.CURRENCY,
				firstStatus: this.objectStatus
			});
			var H = this.getHeaderFooterOptions();
			this.setHeaderFooterOptions(H);
			this.getView().byId("header").setModel(h, "ShoppingCartHeader");
			this.getView().byId("info").setModel(h, "ShoppingCartInfo");
			this.parseApprovalNotes()
		};
		var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		d.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + o + "',DOC_MODE='DISPLAY',WIID='000000000000')",
			null, null, true, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));
		if (this.extHook2) {
			this.extHook2()
		}
	},
	updateItemsList: function(e) {
		var s = e.srcControl;
		if (s.getModel('ShoppingCartHeader') !== undefined) {
			setTimeout(jQuery.proxy(function() {
				var i = s.getModel('ShoppingCartHeader').getData().ITEM_COUNT;
				var h = ui.s2p.srm.sc.track.util.Formatter.formatItemCount(i);
				this.getView().byId("itemList").setHeaderText(h)
			}, this), 100)
		}
	},
	getCartItems: function(o) {
		var a = function(D, r) {

			this.getView().byId("itemList").destroyItems();
			this.oItemModel = new sap.ui.model.json.JSONModel(D);
			this.getView().byId("itemList").setModel(this.oItemModel, "ShoppingCartItems");
			//  this.getView().byId("itemList").getModel("ShoppingCartItems").refresh(true);
			// this.getView().byId("itemList").getModel("ShoppingCartItems").setData(D).refresh(true);
			var b = ui.s2p.srm.sc.track.util.Formatter.formatMaxDeliveryDate(D.results);

		//	this.getView().byId("deliv_Date").setText(b);

			ui.s2p.srm.sc.track.util.ItemList.item.clear();

			for (var i = 0; i < D.results.length; i++) {

				ui.s2p.srm.sc.track.util.ItemList.item.add(D.results);

			}

			//this.getView().byId("itemList").setModel("ShoppingCartItems").refresh(true);

		};

		var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);

		d.read("ordertrackCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + o + "')/OrderTrackItemNavigation", null, null, false,

			jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this))

	},
	onDetailListItemPressed: function(e) {
		var l = e.getSource();
		var b = l.getBindingContext("ShoppingCartItems");
		var m = b.getModel();
		var p = b.getPath();
		var i = m.getProperty(p);
		var a = i.PRODUCT_KEY;
		var o = i.OBJECT_ID;
		var c = e.getSource().sId.split('-')[6];
		var d = jQuery.sap.encodeURL(i.PRODUCT_KEY);
		var n = i.NUMBER_INT;
		var s = this.sapOrigin; //b.getModel().getProperty(b.getPath()).SAP__Origin;
		this.oRouter.navTo("itemDetail", {
			objectid: o,
			numberint: n,
			itemIndex: c,
			sapOrigin: s
		}, true)
	},
	getApprovalDetails: function(o) {
		var a = function(D, r) {
			var i;
			for (i = 0; i < D.results.length; i++) {
				if (D.results[i].AGENT_ID == "" && D.results[i].PROCESSOR_NAMES_CONC != "") {
					var b = D.results[i].PROCESSOR_NAMES_CONC.split(";");
					var c = D.results[i].APR_AGENT_ID.slice(1).split(';');
					var j;
					for (j = 0; j < b.length; j++) {
						var e = new Object();
						jQuery.extend(e, D.results[i]);
						e.PROCESSOR_NAMES_CONC = b[j];
						e.AGENT_ID = b[j];
						e.APPROVER_ID = c[j];
						if (j == 0) D.results.splice(i, 1, e);
						else D.results.splice(i, 0, e)
					}
				} else if (D.results[i].AGENT_ID != "") {
					var f = D.results[i].APR_AGENT_ID.slice(1).split(';');
					if (f.length === 1 && f[0] === D.results[i].AGENT_ID) D.results[i].APPROVER_ID = D.results[i].AGENT_ID
				}
			}
			this.oApprovalModel = new sap.ui.model.json.JSONModel(D);
			this.getView().byId("Approval_list").setModel(this.oApprovalModel, "peopleApproverNotes");
			this.getView().byId("approvalTab").setCount(D.results.length);
			this.busyDialog.close()
		};
		var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		d.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + o +
			"',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartApprovalNavigation", null, null, true, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed,
				this))
	},
	parseApprovalNotes: function() {
		var h = this.getView().byId("header").getModel("ShoppingCartHeader");
		var a = h.getData();
		var n = a.APRV_NOTE;
		var p = n.split("________");
		var b = [];
		var c = new sap.ui.model.json.JSONModel();
		for (var i = 0; i < p.length; i++) {
			var d = p[i];
			if (d.trim() === "") {
				continue
			}
			var e = {};
			var u = d.split("(")[1].split(')')[0].split(" ");
			var f = d.slice(0).split("")[0] !== "\n" ? d.slice(0).split("(")[0] : d.slice(1).split("(")[0];
			e.sender = u[0] !== "" ? u[0] : u[1];
			e.timestamp = u.slice(2).join(" ");
			e.noteText = f;
			b.push(e)
		}
		this.getView().byId("Notes").setModel(c, "ApprovalNotes");
		if (n.length === 0) {
			this.getView().byId("peopleNote").setVisible(false)
		} else {
			var g = {
				notes: b
			};
			c.setData(g);
			this.getView().byId("peopleNote").setVisible(true);
			this.getView().byId("peopleNote").setCount(b.length)
		}
	},
	displayContactPicture: function(v) {
		return jQuery.sap.getModulePath("ui.s2p.srm.sc.track") + "/img/" + "person_placeholder.png"
	},
	openBusinessCard: function(e) {
		var v = this.getView();
		var o = function(D, R) {
			var a = D.results[0];
			var f = a.LastName;
			if (a.FirstName) {
				if (f) {
					f = a.FirstName + " " + f
				} else {
					f = a.FirstName
				}
			}
			if (!f) {
				f = ""
			}
			var t = a.TELEPHONE ? a.TELEPHONE : "";
			var b = a.INHOUSE_MAIL;
			var c = a.COMPANY_NAME;
			var E = {
				name: f,
				imgurl: this.displayContactPicture(),
				department: "",
				contactmobile: "",
				contactphone: t,
				companyname: c,
				contactemail: b,
				contactemailsubj: "",
				companyaddress: ""
			};
			Object.keys(E).forEach(function(k) {
				if (E[k]) {
					var C = v.byId("Approval_list");
					var g = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
					g.openBy(C);
					return
				}
			})
		};
		var s = e.getSource().getBinding("sender").getContext().getPath();
		var r = s.split("/");
		var i = r[2];
		var d = this.oApplicationFacade.getODataModel("USERS_LIST");
		d.read("ALL_USERS_LIST", null, ["$filter=UserName eq '" + this.oApprovalModel.oData.results[i].APPROVER_ID + "'"], false, jQuery.proxy(o,
			this), jQuery.proxy(this.onRequestFailed, this))
	},
	onRequestFailed: function(e) {
		if (e.__batchResponses && e.__batchResponses.length > 0) {
			var j = e.__batchResponses[0].response.body;

			var n = $.parseJSON(j);

			this.result = {};

			this.result.error = n.error.message.value;

			this.busyDialog.close();
			jQuery.sap.require("sap.ca.ui.message.message");
			sap.ca.ui.message.showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: n.error.message.value,
				details: n.error.message.value
			})
		}
	},
	onSelection: function(e) {
		var id = e.getSource().getId()

		var checked = sap.ui.getCore().byId(id).getSelected();

		var selectedIndex = parseInt(e.getSource().getId().split("itemList-")[1]);
		var model = this.getView().byId("itemList").getModel("ShoppingCartItems");
		var sPath = "/results/" + selectedIndex;
		var path = model.getProperty(sPath);
		var T = new sap.ui.model.json.JSONModel(path);
		if (checked) {
			var dialog = sap.ui.getCore().byId("idDialogAcknowledge");
			if (dialog === undefined) {
				dialog = sap.ui.xmlfragment("ui.s2p.srm.sc.track.ZSRM_SC_ACK.fragments.Acknowledge", this.getView().getController());
				this.getView().addDependent();

			}
			dialog.open();
			dialog.setModel(T, "ItemModel");
		}
	},
	onCloseAcknowledge: function() {
		var dialog = sap.ui.getCore().byId("idDialogAcknowledge");

		sap.ui.getCore().byId("ackComments").setValue("");
		var model = dialog.getModel("ItemModel");
		console.log(model);

		dialog.close();
	},
	onSubmitAcknowledge: function() {
		var docNamesList = [];
		var docCodeList = [];
		var dialog = sap.ui.getCore().byId("idDialogAcknowledge");
		var model = dialog.getModel("ItemModel");
		this.OBJECT_ID = model.oData.OBJECT_ID;
		docNamesList = model.oData.Docname;
		var docNames = docNamesList.split(",");
		docCodeList = model.oData.Doccode;
		var docCodes = docCodeList.split(",");

		var comments = sap.ui.getCore().byId("ackComments").getValue();
		var B = new Array();
		var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);
		for (var j = 0; j < docNames.length; j++) {
			var h = {};
			h.AcknowledgeFlag = "X";
			h.BookDescription = model.oData.ITEM_DESC;
			h.CreationDate = model.oData.CREATED_AT;
			h.MRComment = comments;
			h.Doccode = docCodes[j];
			h.CartNo = this.OBJECT_ID;
			h.ItemNumber = model.oData.NUMBER_INT;
			h.QUANTITY = model.oData.QUANTITY;
			B.push(d.createBatchOperation("BookDetailsSet(Doccode='" + docCodes[j] + "')", "PUT", h))
		}

		d.addBatchChangeOperations(B);
		d.submitBatch(d, jQuery.proxy(this.onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this))
		this.busyDialog.close();

		//dialog.close();

	},
	onRequestSuccess: function(e) {

		console.log("BC ID");
		console.log(this.OBJECT_ID);

		var that = this;
		var dialog = sap.ui.getCore().byId("idDialogAcknowledge");
		dialog.close();
		sap.ui.getCore().byId("ackComments").setValue("");
		
            if (e.__batchResponses && e.__batchResponses.length > 0) {
			
			if(Object.keys(e.__batchResponses[0]).indexOf("response")=== 1){
				var j = e.__batchResponses[0].response.body;
				var n = $.parseJSON(j);

			this.result = {};

			this.result.error = n.error.message.value;

			jQuery.sap.log.error("Error occurs during batch processing: " + n.error.message.value);

			sap.ca.ui.message.showMessageBox({

				type: sap.ca.ui.message.Type.ERROR,

				message: n.error.message.value,

				details: n.error.message.value

			})

			}
			else {

				//sap.m.MessageBox.alert("Item has been Acknowledged Successfully");
				sap.m.MessageBox.show("Item has been Acknowledged Successfully", {
					icon: sap.m.MessageBox.Icon.SUCCESS,
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						if (oAction == "OK") {
							//	location.reload(true);
							var a = function(D, r) {
								this.oItemModel = new sap.ui.model.json.JSONModel(D);
								this.getView().byId("itemList").setModel(this.oItemModel, "ShoppingCartItems");
								this.getView().byId("itemList").getModel("ShoppingCartItems").refresh(true);
							};
							var d = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_BOOK_APP_SRV/", true);
							d.read("ordertrackCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + this.OBJECT_ID + "')/OrderTrackItemNavigation",
								null, null, false,
								jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this))
						}
					}.bind(that)
				});

			}
			
		}
		
	}

});