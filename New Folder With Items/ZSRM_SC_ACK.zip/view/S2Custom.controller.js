/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require('sap.ca.scfld.md.controller.ScfldMasterController');
jQuery.sap.require('sap.ca.ui.model.format.NumberFormat');
jQuery.sap.require('sap.ca.ui.model.format.DateFormat');
jQuery.sap.require('sap.ca.ui.model.format.QuantityFormat');
jQuery.sap.require('ui.s2p.srm.sc.track.util.Formatter');
jQuery.sap.require('ui.s2p.srm.sc.track.util.ItemList');
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("ui.s2p.srm.sc.track.ZSRM_SC_ACK.util.Formatter");
sap.ui.controller('ui.s2p.srm.sc.track.ZSRM_SC_ACK.view.S2Custom', {
	onInit: function() {
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		var m = this.oApplicationFacade.getODataModel();
		this.getView().setModel(m);
		console.log(m);
		m.setCountSupported(false);
		m.setSizeLimit(10);
		var f = [];
	/*	var F = [
                new sap.ui.model.Filter('ADV_SEARCH_FLAG', sap.ui.model.FilterOperator.EQ, false),
                new sap.ui.model.Filter('STATUS', sap.ui.model.FilterOperator.EQ, 'I1129')
            ];*/
		var F = new sap.ui.model.odata.Filter('ADV_SEARCH_FLAG', [{
			operator: 'EQ',
			value1: 'false'
            }]);
		f.push(F);
		if (this.extHookInit) {
			this.extHookInit(f);
		}
		var l = this.getList();
		var t = l.getItems()[0].clone();
		l.bindItems('/ordertrackCollection', t, null, f);
		this.registerMasterListBind(l);
	},
	setListItem: function(i) {
		var b = i.getBindingContext();
		i.setSelected(true);
		this.getList().setSelectedItem(i, true);
		this.oRouter.navTo('detail', {
			contextPath: b.getPath().substr(1)
		}, true);
		if (this.extHook1) {
			this.extHook1();
		}
	},
	applySearchPatternToListItem: function(i, f) {
		if (f.substring(0, 1) === '#') {
			var t = f.substr(1);
			var d = i.getBindingContext().getProperty('Name').toLowerCase();
			return d.indexOf(t) === 0;
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f);
		}
	},
	getHeaderFooterOptions: function() {
		return {
			sI18NMasterTitle: 'MASTER_TITLE',
			buttonList: []/*,
			oFilterOptions: {
				onFilterPressed: $.proxy(this.onFilter, this)
			}*/
		};
	},
	/*	setFilterInfoLabel: function(a) {
		if (!$.isArray(a) || a.length < 1) {
			this.setInfoLabel('', '', false, '');
			return
		}
		var i = "";
		$.each(a, function(b, f) {
		 if (f.oValue1) {
				if (i.indexOf(s) === -1) {
					i += s + ": " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(f.oValue1)
				} else {
					i += ", " + i2d.qm.task.tracknconfirm.utils.StatusHelper.statusText(f.oValue1)
				}
			}
		});
		i += ";";
		this.setInfoLabel("QT_FILTERED_BY", null, true, i)
	},*/

	onConfirmFilterDialog: function(e) {
		//this._showLoadingText(true);
		var p = e.getParameters();
		this.aTableFilters = [];
		$.each(p.filterItems, $.proxy(function(i, f) {
			if (f.sId === 'StatusSaved' || f.sId === 'StatusOrdered' || f.sId === 'StatusApproved' || f.sId === 'StatusAwaiting') {
				this.aTableFilters.push(f.getCustomData()[0].getValue().filters);
			}
		}, this));
		this.getList().getBinding('items').filter(this.aTableFilters, sap.ui.model.FilterType.Application); //this.setFilterInfoLabel(this.aTableFilters);
	},
	onCancelFilterDialog: function(e) {},
	isBackendSearch: function() {
		return true;
	},
	applyBackendSearchPattern: function(f, b) {
		var F = [];
		if (f) {
			F = [
                new sap.ui.model.Filter('ADV_SEARCH_FLAG', sap.ui.model.FilterOperator.EQ, false),
                new sap.ui.model.Filter('DESCRIPTION', sap.ui.model.FilterOperator.EQ, f)
            ];
		} else {
			F = [new sap.ui.model.Filter('ADV_SEARCH_FLAG', sap.ui.model.FilterOperator.EQ, false)];
		}
		b.filter(F, sap.ui.model.FilterType.Application);
	},
	extHookInit : function(f){
	    var 	F = new sap.ui.model.Filter('STATUS', sap.ui.model.FilterOperator.EQ, 'I1129');
	    f.push(F);
	}
});