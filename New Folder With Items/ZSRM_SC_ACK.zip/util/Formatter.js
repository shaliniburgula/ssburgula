/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.ZSRM_SC_ACK.util.Formatter");
jQuery.sap.require("sap.ui.core.Element");
ui.s2p.srm.sc.track.ZSRM_SC_ACK.util.Formatter = {
	doctorNameFormat: function(a) {
	 var docNames =""; 
	    if(a != "" && a != undefined){
		var docList = a.split(",");
		
		for(var i = 0 ; i <docList.length ; i++){
		    docNames += docList[i]+"\n";
		}
	    }
		return docNames;
	
	    
	},
	checkBoxSelected :  function(value){
	    if(value === "X"){
	        return true;
	    }else{
	        return false;
	    }
	},
	checkBoxEnabled : function(value){
	     if(value === "X"){
	        return false;
	    }else{
	        return true;
	    }
	},
		formatPrice: function(v) {
	    	var n = v;
	    	var i,j;
        var decPlaces = "2";
        var decSeparator =".";
        var thouSeparator =",";
        decPlaces = isNaN(decPlaces = Math.abs(decPlaces)) ? 2 : decPlaces;
        decSeparator = decSeparator === undefined ? "." : decSeparator;
        thouSeparator = thouSeparator === undefined ? "," : thouSeparator;
        i = parseInt(n = Math.abs(+n || 0).toFixed(decPlaces)) + "";
        j = (j = i.length) > 3 ? j % 3 : 0;
    return  (j ? i.substr(0, j) + thouSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thouSeparator) + (decPlaces ? decSeparator + Math.abs(n - i).toFixed(decPlaces).slice(2) : "");
	
	},
		formatDesc : function(v){
	    if(v === 'Saved'){
	        return "Submitted";
	    }
	    else
	    {
	        return v;
	    }
	}
};