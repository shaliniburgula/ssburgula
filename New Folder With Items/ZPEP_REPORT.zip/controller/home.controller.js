jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("com.hcm.ZPEP_REPORT.util.formatter");
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.hcm.ZPEP_REPORT.controller.home", {

		onInit: function() {
		 
		 var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHCM_PEOPLE_PROFILE_SRV/", true);  
	    var reportPath = "HRReportSet"; 
         var oJson = new sap.ui.model.json.JSONModel();
         oDataModel.read(reportPath, null, null, false, function(r) {
			oJson.setData(r);
			oJson.setSizeLimit(100);

		});
		
		sap.ui.getCore().setModel(oJson, "DetailsModel");
		console.log(oJson);
		console.log("testing")
		//console.log(oJson.oData.results[0].CreationTime.ms)
        this.getView().byId("idTable").setModel(oJson, "DetailsModel");
		},
		onFilter: function() {
			var dialog = sap.ui.getCore().byId("idDialogFilterDetails");
			if (dialog === undefined) {
				dialog = sap.ui.xmlfragment("com.hcm.ZPEP_REPORT.fragments.filterSettings", this.getView().getController());

			}
			dialog.open();
		},
		
		onSelection : function(oEvent){
            var sId = oEvent.getSource().sId;
            
            if(sId === "empId"){
                var selectedItem = sap.ui.getCore().byId("empId").getSelectedKey();
                if(selectedItem === "BT"){
                    sap.ui.getCore().byId("idEmpFromValue").setVisible(true);
                    sap.ui.getCore().byId("idEmpToValue").setVisible(true);
                    sap.ui.getCore().byId("idEmpFromValue").setValue("");
                    sap.ui.getCore().byId("idEmpToValue").setValue("");
                    sap.ui.getCore().byId("idEmpValue").setVisible(false);
                }
                else
                {
                    sap.ui.getCore().byId("idEmpFromValue").setVisible(false);
                    sap.ui.getCore().byId("idEmpToValue").setVisible(false);
                    sap.ui.getCore().byId("idEmpValue").setVisible(true);
                     sap.ui.getCore().byId("idEmpValue").setValue("")
                }
            }
            else if(sId === "idEmpGrp"){
                 sap.ui.getCore().byId("idEmpGrpVal").setValue("");
            }
            else if(sId === "idEmpSubgrp"){
                 sap.ui.getCore().byId("idEmpSubgrpVal").setValue("");
            }
            else if(sId === "idPersArea"){
                 sap.ui.getCore().byId("idPersAreaVal").setValue("");
            }
            else if(sId === "idPersSubarea"){
                 sap.ui.getCore().byId("idPerSubareaVal").setValue("");
            }
            
            else if(sId === "idCreationDate"){
                var selectedDateItem = sap.ui.getCore().byId("idCreationDate").getSelectedKey();
                if(selectedDateItem === "BT"){
                    sap.ui.getCore().byId("DP3").setVisible(true);
                    sap.ui.getCore().byId("DP2").setVisible(true);
                    sap.ui.getCore().byId("DP3").setValue("");
                    sap.ui.getCore().byId("DP2").setValue("");
                    sap.ui.getCore().byId("DP1").setVisible(false);
                }
                else
                {
                    sap.ui.getCore().byId("DP2").setVisible(false);
                    sap.ui.getCore().byId("DP3").setVisible(false);
                    sap.ui.getCore().byId("DP1").setVisible(true);
                    sap.ui.getCore().byId("DP1").setValue("");
                }
            }
         /*   else if(sId === "idCreationTime"){
                var selectedTimeItem = sap.ui.getCore().byId("idCreationTime").getSelectedKey();
                if(selectedTimeItem === "BT"){
                    sap.ui.getCore().byId("TP3").setVisible(true);
                    sap.ui.getCore().byId("TP2").setVisible(true);
                    sap.ui.getCore().byId("TP1").setVisible(false);
                }
                else
                {
                    sap.ui.getCore().byId("TP2").setVisible(false);
                    sap.ui.getCore().byId("TP3").setVisible(false);
                    sap.ui.getCore().byId("TP1").setVisible(true);
                }
            }*/
            else if(sId === "idInfotype"){
                var selectedInfoItem = sap.ui.getCore().byId("idInfotype").getSelectedKey();
                if(selectedInfoItem === "BT"){
                    sap.ui.getCore().byId("infoFromVal").setVisible(true);
                    sap.ui.getCore().byId("infoToVal").setVisible(true);
                     sap.ui.getCore().byId("infoFromVal").setValue("");
                    sap.ui.getCore().byId("infoToVal").setValue("");
                    sap.ui.getCore().byId("infoVal").setVisible(false);
                }
                else
                {
                    sap.ui.getCore().byId("infoFromVal").setVisible(false);
                    sap.ui.getCore().byId("infoToVal").setVisible(false);
                    sap.ui.getCore().byId("infoVal").setVisible(true);
                    sap.ui.getCore().byId("infoVal").setValue("");
                }
            }
             else if(sId === "idHRFACID"){
                var selectedInfoItem = sap.ui.getCore().byId("idHRFACID").getSelectedKey();
                if(selectedInfoItem === "BT"){
                    sap.ui.getCore().byId("idHRFACVal1").setVisible(true);
                    sap.ui.getCore().byId("idHRFACVal2").setVisible(true);
                    
                    sap.ui.getCore().byId("idHRFACVal1").setValue("");
                    sap.ui.getCore().byId("idHRFACVal2").setValue("");
                    sap.ui.getCore().byId("idHRFACVal").setVisible(false);
                }
                else
                {
                    sap.ui.getCore().byId("idHRFACVal1").setVisible(false);
                    sap.ui.getCore().byId("idHRFACVal2").setVisible(false);
                    sap.ui.getCore().byId("idHRFACVal").setVisible(true);
                    sap.ui.getCore().byId("idHRFACVal").setValue("");
                }
            }
		},
		
		onCloseFilterDialog : function(){
		    var dialog = sap.ui.getCore().byId("idDialogFilterDetails");
		    dialog.close();
		    this.onRestoreFilter();
		},
		onValidation : function(){
		    var errorMsg ;
		    var result = true;
		    /* Employee ID */
		    	if(sap.ui.getCore().byId("empId").getSelectedKey() !== "select"){
		    	    var selectedKey = sap.ui.getCore().byId("empId").getSelectedKey();
		    	    var empIDValue = sap.ui.getCore().byId("idEmpValue").getValue();
		    	    
		    	   if(selectedKey === "BT"){
		    	        var empIDFromValue = sap.ui.getCore().byId("idEmpFromValue").getValue();
		    	        var empIDToValue = sap.ui.getCore().byId("idEmpToValue").getValue();
		    	        if(empIDFromValue > empIDToValue){
		    	         errorMsg ="Employee ID : From value should not be greater than To value \\n";
		    	         result= false;
		    	        }
		    	    }
		    	}
		    	//Creation Date
		    	 if(sap.ui.getCore().byId("idCreationDate").getSelectedKey() !== "select"){
		    	    var selectedDateKey = sap.ui.getCore().byId("idCreationDate").getSelectedKey();
		    	    var selDate = sap.ui.getCore().byId("DP1").getValue();;
		    	    var formattedDate = new Date(com.hcm.ZPEP_REPORT.util.formatter.formattingDatesForFiltering(selDate));
		    	   if(selectedDateKey === "BT"){
		    	        var selFromDate = sap.ui.getCore().byId("DP2").getValue();
		    	        var formattedFD = new Date(com.hcm.ZPEP_REPORT.util.formatter.formattingDatesForFiltering(selFromDate));
		    	        var selToDate = sap.ui.getCore().byId("DP3").getValue();
		    	        var formattedTD = new Date(com.hcm.ZPEP_REPORT.util.formatter.formattingDatesForFiltering(selToDate));
		    	        if(formattedFD > formattedTD){
		    	            
		    	         errorMsg +="Creation Date : From value should not be greater than To value \\n";
		    	         result= false; 
		    	        }
		    	        
		    	    }
		    	}
		    		//Infotype
		    	 if(sap.ui.getCore().byId("idInfotype").getSelectedKey() !== "select"){
		    	    var selectedInfoKey = sap.ui.getCore().byId("idInfotype").getSelectedKey();
		    	    var selInfotype = sap.ui.getCore().byId("infoVal").getValue();
		    	     if(selectedInfoKey === "BT"){
		    	        var selFromInfotype = sap.ui.getCore().byId("infoFromVal").getValue();
		    	        var selToInfotype = sap.ui.getCore().byId("infoToVal").getValue();
		    	         if(selFromInfotype>selToInfotype){
		    	         errorMsg +="Infotype : From value should not be greater than To value \\n";
		    	         result= false;
		    	         }  
		    	     }
		    	}
		    	//HRFAC ID
		    	 if(sap.ui.getCore().byId("idHRFACID").getSelectedKey() !== "select"){
		    	    var selectedHRKey = sap.ui.getCore().byId("idHRFACID").getSelectedKey();
		    	    var empHRIDValue = sap.ui.getCore().byId("idHRFACVal").getValue();
		    	    
		    	    if(selectedHRKey === "BT"){
		    	        var empHRIDFromValue = sap.ui.getCore().byId("idHRFACVal2").getValue();
		    	        var empHRIDToValue = sap.ui.getCore().byId("idHRFACVal3").getValue();
		    	        if(empHRIDFromValue>empHRIDToValue){
		    	         errorMsg +="HRFAC ID : From value should not be greater than To value \\n";
		    	         result= false;
		    	         }  
		    	    }
		    	}
		    	sap.m.MessageBox.error(errorMsg);
		    	return result;
		},
		onFilterApply : function(){
		    	this.aTableFilters = [];
		    	
		  var result = this.onValidation();
		  if(result){
		    	/* Employee ID */
		    	if(sap.ui.getCore().byId("empId").getSelectedKey() !== "select"){
		    	    var selectedKey = sap.ui.getCore().byId("empId").getSelectedKey();
		    	    var empIDValue = sap.ui.getCore().byId("idEmpValue").getValue();
		    	    
		    	    if(selectedKey === "contains"){
		    	        	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.Contains,empIDValue));
		    	    }else if(selectedKey === "EQ"){
		    	     
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.EQ,empIDValue));
		    	    }else if(selectedKey === "SW"){
		    	      
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.StartsWith,empIDValue));
		    	    }else if(selectedKey === "EW"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.EndsWith,empIDValue));
		    	    }else if(selectedKey === "LT"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.LT,empIDValue));
		    	    }else if(selectedKey === "LE"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.LE,empIDValue));
		    	    }
		    	    else if(selectedKey === "GE"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.GE,empIDValue));
		    	    }
		    	    else if(selectedKey === "GT"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.GT,empIDValue));
		    	    }else if(selectedKey === "NE"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.NE,empIDValue));
		    	    }else if(selectedKey === "BT"){
		    	        var empIDFromValue = sap.ui.getCore().byId("idEmpFromValue").getValue();
		    	        var empIDToValue = sap.ui.getCore().byId("idEmpToValue").getValue();
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeID", sap.ui.model.FilterOperator.BT,empIDFromValue,empIDToValue));
		    	    }
		    	}
		    	//Employee Group
		    	 if(sap.ui.getCore().byId("idEmpGrp").getSelectedKey() !== "select"){
		    	    var selectedGrpKey = sap.ui.getCore().byId("idEmpGrp").getSelectedKey();
		    	    var empGrp = sap.ui.getCore().byId("idEmpGrpVal").getValue();
		    	    
		    	    if(selectedGrpKey === "contains"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeGroupTxt", sap.ui.model.FilterOperator.Contains,empGrp));
		    	    }else if(selectedGrpKey === "EQ"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeGroupTxt", sap.ui.model.FilterOperator.EQ,empGrp));
		    	    }
		    	}
		    	
		    	//Employee Subgroup
		    	 if(sap.ui.getCore().byId("idEmpSubgrp").getSelectedKey() !== "select"){
		    	    var selectedSbGrpKey = sap.ui.getCore().byId("idEmpSubgrp").getSelectedKey();
		    	    var empSubGrp = sap.ui.getCore().byId("idEmpSubgrpVal").getValue();
		    	    
		    	    if(selectedSbGrpKey === "contains"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeSubgroupTxt", sap.ui.model.FilterOperator.Contains,empGrp));
		    	    }else if(selectedSbGrpKey === "EQ"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("EmployeeSubgroupTxt", sap.ui.model.FilterOperator.EQ,empGrp));
		    	    }
		    	}
		    	//Personnel Area
		    	 if(sap.ui.getCore().byId("idPersArea").getSelectedKey() !== "select"){
		    	    var selectedPersAreaKey = sap.ui.getCore().byId("idPersArea").getSelectedKey();
		    	    var  persArea = sap.ui.getCore().byId("idPersAreaVal").getValue();
		    	    
		    	    if(selectedPersAreaKey === "contains"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("PersonnelAreaTxt", sap.ui.model.FilterOperator.Contains,persArea));
		    	    }else if(selectedPersAreaKey === "EQ"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("PersonnelAreaTxt", sap.ui.model.FilterOperator.EQ,persArea));
		    	    }
		    	}
		    	
		    	//Personnel Subarea
		    	 if(sap.ui.getCore().byId("idPersSubarea").getSelectedKey() !== "select"){
		    	    var selectedPerSubareaKey = sap.ui.getCore().byId("idPersSubarea").getSelectedKey();
		    	    var persubArea = sap.ui.getCore().byId("idPerSubareaVal").getValue();
		    	    
		    	    if(selectedPerSubareaKey === "contains"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("PersonnelSubareaTxt", sap.ui.model.FilterOperator.Contains,persubArea));
		    	    }else if(selectedPerSubareaKey === "EQ"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("PersonnelSubareaTxt", sap.ui.model.FilterOperator.EQ,persubArea));
		    	    }
		    	}
		    	
		    	//Creation Date
		    	 if(sap.ui.getCore().byId("idCreationDate").getSelectedKey() !== "select"){
		    	    var selectedDateKey = sap.ui.getCore().byId("idCreationDate").getSelectedKey();
		    	    var selDate = sap.ui.getCore().byId("DP1").getValue();;
		    	    var formattedDate = new Date(com.hcm.ZPEP_REPORT.util.formatter.formattingDatesForFiltering(selDate));
		    	    if(selectedDateKey === "LT"){
		    	         	this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.LT,formattedDate));
		    	    }else if(selectedDateKey === "EQ"){
		    	           	this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.EQ,formattedDate));
		    	    }else if(selectedDateKey === "LE"){
		    	           	this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.LE,formattedDate));
		    	    }else if(selectedDateKey === "GE"){
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.GE,formattedDate));
		    	    }else if(selectedDateKey === "BT"){
		    	        var selFromDate = sap.ui.getCore().byId("DP2").getValue();
		    	        var formattedFD = new Date(com.hcm.ZPEP_REPORT.util.formatter.formattingDatesForFiltering(selFromDate));
		    	        var selToDate = sap.ui.getCore().byId("DP3").getValue();
		    	        var formattedTD = new Date(com.hcm.ZPEP_REPORT.util.formatter.formattingDatesForFiltering(selToDate));
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT,formattedFD,formattedTD));
		    	    }
		    	}
		    	
		    	
		    	//Creation Time
		    	 /*if(sap.ui.getCore().byId("idCreationTime").getSelectedKey() !== "select"){
		    	    var selectedTimeKey = sap.ui.getCore().byId("idCreationTime").getSelectedKey();
		    	    var selTime = sap.ui.getCore().byId("TP1").getValue();
		    	     var formattedTime = com.hcm.ZPEP_REPORT.util.formatter.formatFilterTime(selTime);
		    	    //formattedTime = "PT15H30M54S";
		    	     var object = {
		    	         ms : formattedTime, __edmType: "Edm.Time"
		    	     };
		    	    
		    	    if(selectedTimeKey === "LT"){
		    	             	this.aTableFilters.push(new sap.ui.model.Filter("CreationTime", sap.ui.model.FilterOperator.LT,formattedTime));
		    	    }else if(selectedTimeKey === "EQ"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("CreationTime", sap.ui.model.FilterOperator.EQ,selTime));
		    	    }else if(selectedTimeKey === "LE"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("CreationTime", sap.ui.model.FilterOperator.LE,formattedTime));
		    	    }else if(selectedTimeKey === "GE"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("CreationTime", sap.ui.model.FilterOperator.GE,formattedTime));
		    	    }else if(selectedTimeKey === "BT"){
		    	        var selFromTime = sap.ui.getCore().byId("TP2").getValue();
		    	          var formattedFromTime = com.hcm.ZPEP_REPORT.util.formatter.formatFilterTime(selFromTime);
		    	        var selToTime = sap.ui.getCore().byId("TP3").getValue();
		    	          var formattedToTime = com.hcm.ZPEP_REPORT.util.formatter.formatFilterTime(selToTime);
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("CreationTime", sap.ui.model.FilterOperator.BT,formattedFromTime,formattedToTime));
		    	    }
		    	}*/
		    	
		    	//Infotype
		    	 if(sap.ui.getCore().byId("idInfotype").getSelectedKey() !== "select"){
		    	    var selectedInfoKey = sap.ui.getCore().byId("idInfotype").getSelectedKey();
		    	    var selInfotype = sap.ui.getCore().byId("infoVal").getValue();
		    	    
		    	    if(selectedInfoKey === "LT"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("Infotype", sap.ui.model.FilterOperator.LT,selInfotype));
		    	    }else if(selectedInfoKey === "EQ"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("Infotype", sap.ui.model.FilterOperator.EQ,selInfotype));
		    	    }else if(selectedInfoKey === "LE"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("Infotype", sap.ui.model.FilterOperator.LE,selInfotype));
		    	    }else if(selectedInfoKey === "GE"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("Infotype", sap.ui.model.FilterOperator.GE,selInfotype));
		    	    }else if(selectedInfoKey === "BT"){
		    	        var selFromInfotype = sap.ui.getCore().byId("infoFromVal").getValue();
		    	        var selToInfotype = sap.ui.getCore().byId("infoToVal").getValue();
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("Infotype", sap.ui.model.FilterOperator.BT,selFromInfotype,selToInfotype));
		    	    }
		    	}
		    	//HRFAC ID
		    	 if(sap.ui.getCore().byId("idHRFACID").getSelectedKey() !== "select"){
		    	    var selectedHRKey = sap.ui.getCore().byId("idHRFACID").getSelectedKey();
		    	    var empHRIDValue = sap.ui.getCore().byId("idHRFACVal").getValue();
		    	    
		    	    if(selectedHRKey === "contains"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.Contains,empHRIDValue));
		    	    }else if(selectedHRKey === "EQ"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.EQ,empHRIDValue));
		    	    }else if(selectedHRKey === "SW"){
		    	       
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.StartsWith,empHRIDValue));
		    	    }else if(selectedHRKey === "EW"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.EndsWith,empHRIDValue));
		    	    }else if(selectedHRKey === "LT"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.LT,empHRIDValue));
		    	    }else if(selectedHRKey === "LE"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.LE,empHRIDValue));
		    	    }else if(selectedHRKey === "GE"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.GE,empHRIDValue));
		    	    }else if(selectedHRKey === "GT"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.GT,empHRIDValue));
		    	    }else if(selectedHRKey === "NE"){
		    	        
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.NE,empHRIDValue));
		    	    }else if(selectedHRKey === "BT"){
		    	        var empHRIDFromValue = sap.ui.getCore().byId("idHRFACVal2").getValue();
		    	        var empHRIDToValue = sap.ui.getCore().byId("idHRFACVal3").getValue();
		    	        	this.aTableFilters.push(new sap.ui.model.Filter("HRFACID", sap.ui.model.FilterOperator.BT,empHRIDFromValue,empHRIDToValue));
		    	    }
		    	}
		    	
		   
		    		this.getView().byId("idTable").getBinding("items").filter(this.aTableFilters, sap.ui.model.FilterType.Application);
		    		var dialog = sap.ui.getCore().byId("idDialogFilterDetails");
		            dialog.close();
		  }
		},
		onRestoreFilter : function(){
		    sap.ui.getCore().byId("empId").setSelectedKey("select");
		    if(sap.ui.getCore().byId("idEmpValue").getVisible())
		    {
		        sap.ui.getCore().byId("idEmpValue").setValue("");
		    }
		    else
		    {
		        sap.ui.getCore().byId("idEmpValue").setValue("");
		        sap.ui.getCore().byId("idEmpValue").setVisible(true);
		        sap.ui.getCore().byId("idEmpFromValue").setValue("");
		        sap.ui.getCore().byId("idEmpFromValue").setVisible(false);
		        sap.ui.getCore().byId("idEmpToValue").setValue("");
		        sap.ui.getCore().byId("idEmpToValue").setVisible(false);
		    }
		    
		    sap.ui.getCore().byId("idEmpGrp").setSelectedKey("select");
		    sap.ui.getCore().byId("idEmpGrpVal").setValue("");
		    
		    sap.ui.getCore().byId("idEmpSubgrp").setSelectedKey("select");
		    sap.ui.getCore().byId("idEmpSubgrpVal").setValue("");
		    
		    sap.ui.getCore().byId("idPersArea").setSelectedKey("select");
		    sap.ui.getCore().byId("idPersAreaVal").setValue("");
		    
		    sap.ui.getCore().byId("idPersSubarea").setSelectedKey("select");
		    sap.ui.getCore().byId("idPerSubareaVal").setValue("");
		    
		    sap.ui.getCore().byId("idCreationDate").setSelectedKey("select");
		    if(sap.ui.getCore().byId("DP1").getVisible())
		    {
		        sap.ui.getCore().byId("DP1").setValue("");
		    }
		    else
		    {
		        sap.ui.getCore().byId("DP1").setValue("");
		        sap.ui.getCore().byId("DP1").setVisible(true);
		        sap.ui.getCore().byId("DP2").setValue("");
		        sap.ui.getCore().byId("DP2").setVisible(false);
		        sap.ui.getCore().byId("DP3").setValue("");
		        sap.ui.getCore().byId("DP3").setVisible(false);
		    }
		   /* sap.ui.getCore().byId("idCreationTime").setSelectedKey("select");
		    if(sap.ui.getCore().byId("TP1").getVisible())
		    {
		        sap.ui.getCore().byId("TP1").setValue("");
		    }
		    else
		    {
		        sap.ui.getCore().byId("TP1").setValue("");
		        sap.ui.getCore().byId("TP1").setVisible(true);
		        sap.ui.getCore().byId("TP2").setValue("");
		        sap.ui.getCore().byId("TP2").setVisible(false);
		        sap.ui.getCore().byId("TP3").setValue("");
		        sap.ui.getCore().byId("TP3").setVisible(false);
		    }*/
		    sap.ui.getCore().byId("idInfotype").setSelectedKey("select");
		    if(sap.ui.getCore().byId("infoVal").getVisible())
		    {
		        sap.ui.getCore().byId("infoVal").setValue("");
		    }
		    else
		    {
		        sap.ui.getCore().byId("infoVal").setValue("");
		        sap.ui.getCore().byId("infoVal").setVisible(true);
		        sap.ui.getCore().byId("infoFromVal").setValue("");
		        sap.ui.getCore().byId("infoFromVal").setVisible(false);
		        sap.ui.getCore().byId("infoToVal").setValue("");
		        sap.ui.getCore().byId("infoToVal").setVisible(false);
		    }
		    sap.ui.getCore().byId("idHRFACID").setSelectedKey("select");
		    if(sap.ui.getCore().byId("idHRFACVal").getVisible())
		    {
		        sap.ui.getCore().byId("idHRFACVal").setValue("");
		    }
		    else
		    {
		        sap.ui.getCore().byId("idHRFACVal").setValue("");
		        sap.ui.getCore().byId("idHRFACVal").setVisible(true);
		        sap.ui.getCore().byId("idHRFACVal1").setValue("");
		        sap.ui.getCore().byId("idHRFACVal1").setVisible(false);
		        sap.ui.getCore().byId("idHRFACVal2").setValue("");
		        sap.ui.getCore().byId("idHRFACVal2").setVisible(false);
		    }
		},
		
	onDownloadXLS: function() {

		var data = sap.ui.getCore().getModel("DetailsModel").getData();
		this.JsonToCsvConverter(data, "Employee Profile Report", true);

	},

	JsonToCsvConverter: function(JSONData, ReportTitle, ShowLabel) {
		var arrData = this.getView().byId("idTable").getItems();
		var CSV = "";
		CSV = ReportTitle + "\r\n\n";
		if (ShowLabel) {
			var row = "";
			row = row.slice(0, -1);
			CSV += row + "\r\n";
		}
		var columnRow =
			'Serial No, Employee ID,Personnel Area, Personnel Subarea,Employee Group,Employee Subgroup,Creation Date,Creation Time,Infotype,HRFACID,';
		columnRow = columnRow.slice(0, -1);
		CSV += columnRow + "\r\n";
		for (var i = 0; i < JSONData.results.length; i++) {
		    
		    var creationDate = com.hcm.ZPEP_REPORT.util.formatter.ui5ToOdatadataForLocalFiltering(JSONData.results[i].CreationDate);
		    var creationTime = com.hcm.ZPEP_REPORT.util.formatter.formatTime(JSONData.results[i].CreationTime);
			var row = "";
			row += '"' + JSONData.results[i].SerialNo
			+ '","' + JSONData.results[i].EmployeeID
			+ '","' + JSONData.results[i].PersonnelAreaTxt
			+ '","' + JSONData.results[i].PersonnelSubareaTxt
			+ '","' + JSONData.results[i].EmployeeGroupTxt
			+ '","' + JSONData.results[i].EmployeeSubgroupTxt
			+ '","' + creationDate
			+ '","' + creationTime
			+ '","' + JSONData.results[i].Infotype
			+ '","'+ JSONData.results[i].HRFACID
			+ '",';

			row.slice(0, row.length - 1);
			CSV += row + '\r\n';
		}
		if (CSV == "") {
			alert("Invalid Data");
			return;
		}
				var fileName = "PeopleProfile_";



		var blob = new Blob([CSV], {



			type: "text/csv;charset=utf-8;"



		});



		if (navigator.msSaveBlob) { // IE 10+



			navigator.msSaveBlob(blob, "PeopleProfile_Report.csv")



		} else {

        
		var fileName = "PeopleProfile_Report";
	//	fileName += ReportTitle.replace(/ /g, "_");
		var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
		var link = document.createElement("a");
		link.href = uri;
		link.style = "visibility:hidden";
		link.download = fileName + ".csv";
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);


		}
}

	});
});