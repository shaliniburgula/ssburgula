jQuery.sap.declare("com.hcm.ZPEP_REPORT.util.formatter");

jQuery.sap.require("sap.ui.core.Element");

com.hcm.ZPEP_REPORT.util.formatter = {
	formattingDatesForFiltering: function(data, type) {
            var iDatadt = new Date(data);
			return iDatadt;
	},
	ui5ToOdatadataForLocalFiltering: function(data, type) {

		var iDatadt = data;

		if (data !== null) {

			var month = (iDatadt.getMonth() + 1);

			var day = iDatadt.getDate()

			if ((iDatadt.getMonth() + 1).toString().length < 2) {

				month = '0' + (iDatadt.getMonth() + 1);

			}

			if ((iDatadt.getDate()).toString().length < 2) {

				day = '0' + iDatadt.getDate();

			}

			iDatadt = day + '-' + month + '-' + iDatadt.getFullYear();

			return iDatadt;

		} else {

			return "";

		}

	},

	formatTime: function(val) {

		var d = new Date(val.ms);

		var s = d.getUTCSeconds();

		var h = d.getUTCHours();

		var m = d.getUTCMinutes();

		var value = h + ":" + m + ":" + s;

		return value;

	},
		formatFilterTime: function(val) {

		var formattedTime = val.split(":");

		var s = formattedTime[2];

		var h = formattedTime[0];

		var m = formattedTime[1];

		//var value = "PT"+h + "H" + m + "M" + s+"S"; //PT15H30M54S
          
       var hours = parseInt(h);
        var minutes = parseInt(m);
        var seconds = parseInt(s);
        value = parseInt(3600000 * hours + 60000 * minutes + 1000 * seconds);
		return value;

	},

};