sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("SmartControls.controller.View1", {
			onInit: function() {
		var oModel, oView;
		jQuery.sap.require("sap.ui.core.util.MockServer");
		var oMockServer = new sap.ui.core.util.MockServer({
			rootUri: "mockserver/"
		});
		oMockServer.simulate("SmartControls/mockserver/metadata.xml", 
		                     "SmartControls/mockserver/");
		oMockServer.start();
		oModel = new sap.ui.model.odata.ODataModel("mockserver", true);
		oModel.setDefaultBindingMode("TwoWay"); 
		oView = this.getView();
		oView.setModel(oModel);
		oView.bindElement("/Products('4711')");
	}
	});


});