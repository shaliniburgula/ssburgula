sap.ui.jsview("view.ZHR_LOGIN", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf view.ZHR_LOGIN
	*/ 
	getControllerName : function() {
		return "view.ZHR_LOGIN";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf view.ZHR_LOGIN
	*/ 
	createContent : function(oController) {
		return new sap.m.Page({
			title: "Title",
			content: [
				
			]
		});
	}

});
