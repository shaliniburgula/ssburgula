sap.ui.controller("view.ZHR_LOGIN", {
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* 
*/
onInit: function() {
var oSys = [];
var lv_hash = window.location.hash;
if (lv_hash != '')
{
        if (!window.location.origin) {
          window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
        }
var Servicel = window.location.origin + "/sap/public/bc/icf/logoff";
var rlx_serv = window.location.origin;
  jQuery.ajax({url:Servicel,async:false}).complete(function (){
window.location.assign(rlx_serv);
});
}
else
{
var y = "/sap/bc/ui2/start_up";
    var xmlHttp = null;
    xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
       var oUserData = JSON.parse(xmlHttp.responseText);
       
          oSys = oUserData;
       }
    };
    xmlHttp.open( "GET", y, false );
    xmlHttp.send(null);
if ( oSys.system == "D10")
{
window.location.replace("http://sapnwg75d.mydrreddys.com:8001/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html?sap-client=999&sap-language=EN#Shell-home");
}else if ( oSys.system == "Q11")
{
window.location.replace("http://sapnwg75q.mydrreddys.com:8005/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html?sap-client=999&sap-language=EN#Shell-home");
}else if ( oSys.system == "P10")
{
var Serv_appl = 'sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html?sap-client=999&sap-language=EN#Shell-home';
var Serv_Port = '8067';
var Serv_gw = window.location.protocol + "//" + window.location.hostname + ":" + Serv_Port + Serv_appl;
window.location.replace(Serv_gw);
}
}
  },
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zcredit_login.ZCREDIT_LOGIN
*/
//  onBeforeRendering: function() {
//
//  },
/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zcredit_login.ZCREDIT_LOGIN
*/
//  onAfterRendering: function() {
//
//  },
/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zcredit_login.ZCREDIT_LOGIN
*/
//  onExit: function() {
//
//  }
});