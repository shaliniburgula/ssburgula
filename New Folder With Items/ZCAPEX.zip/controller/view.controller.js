sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("FIZCAPEX.controller.view", {

		onInit: function() {
          	this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
          		this._oRouter.attachRoutePatternMatched(this._handleRouteMatched, this);
	},
		_handleRouteMatched: function(oEvent)

		{

			var oParamaeters = oEvent.getParameter("name");

			if (oParamaeters !== "view")

			{

				return;

			}

		},
	onNavBack: function() {

			this._oRouter.navTo("home");

		},

	});

});