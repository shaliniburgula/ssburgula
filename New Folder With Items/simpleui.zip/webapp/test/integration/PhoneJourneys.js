jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"simple ui/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"simple ui/test/integration/pages/App",
	"simple ui/test/integration/pages/Browser",
	"simple ui/test/integration/pages/Master",
	"simple ui/test/integration/pages/Detail",
	"simple ui/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "simple ui.view."
	});

	sap.ui.require([
		"simple ui/test/integration/NavigationJourneyPhone",
		"simple ui/test/integration/NotFoundJourneyPhone",
		"simple ui/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});