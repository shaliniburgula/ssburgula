jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 Task in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"simple ui/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"simple ui/test/integration/pages/App",
	"simple ui/test/integration/pages/Browser",
	"simple ui/test/integration/pages/Master",
	"simple ui/test/integration/pages/Detail",
	"simple ui/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "simple ui.view."
	});

	sap.ui.require([
		"simple ui/test/integration/MasterJourney",
		"simple ui/test/integration/NavigationJourney",
		"simple ui/test/integration/NotFoundJourney",
		"simple ui/test/integration/BusyJourney",
		"simple ui/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});