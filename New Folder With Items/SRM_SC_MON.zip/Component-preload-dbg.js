jQuery.sap.registerPreloadedModules({
"name":"ui/s2p/srm/sc/track/Component-preload",
"version":"2.0",
"modules":{
	"ui/s2p/srm/sc/track/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.Component");
jQuery.sap.require("ui.s2p.srm.sc.track.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

// new Component
sap.ca.scfld.md.ComponentBase.extend("ui.s2p.srm.sc.track.Component",{
	
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name" : "Master Detail Sample",
		"version" : "1.0.0",
		"library" : "ui.s2p.srm.sc.track",
		"includes" : [],
		"dependencies" : {
			"libs" : [ "sap.m", "sap.me" ],
			"components" : []
		},
		"config": {
			"titleResource": "DISPLAY_NAME_TRACK",
			"resourceBundle": "i18n/i18n.properties",
			"icon": "sap-icon://Fiori2/F0406",
			"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/Track_Shopping_Cart.ico",
			"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/57_iPhone_Desktop_Launch.png",
			"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/114_iPhone-Retina_Web_Clip.png",
			"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/72_iPad_Desktop_Launch.png",
			"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/144_iPad_Retina_Web_Clip.png"			
		},

		// Navigation related properties
		"masterPageRoutes": {
			"master": {
				"pattern": "",
				"view": "ui.s2p.srm.sc.track.view.S2"
			}
		},
		"detailPageRoutes": {
			"detail": {
				"pattern": "detail/{contextPath}",
				"view": "ui.s2p.srm.sc.track.view.S3"
			},
			"itemDetail": {
				"pattern": "itemDetail/{objectid}/{numberint}/{itemIndex}/{sapOrigin}",
				"view": "ui.s2p.srm.sc.track.view.ItemDetail",
			}
		}
	}),

	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
		var oViewData = {
				component : this
		};

		return sap.ui.view({
			viewName : "ui.s2p.srm.sc.track.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	}

});


},
	"ui/s2p/srm/sc/track/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("ui.s2p.srm.sc.track.Configuration",{

	aServiceList : [
		               {
		            	   name : "ORDERTRACK_SERVICE",
		            	   masterCollection : "ordertrackCollection",
		            	   serviceUrl : "/sap/opu/odata/srmnxp/ORDERTRACK_SERVICE;mo/",
		            	   isDefault : true,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
		               },
		               {
		            	   name : "SRMSHOPPING_CART",
		            	   masterCollection : "SRMShoppingCartCollection",
		            	   serviceUrl : "/sap/opu/odata/srmnxp/SRMSHOPPING_CART;mo/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
		               },		               
		               {

		            	   name : "USERS_LIST",
		            	   masterCollection : "SRMShoppingCartCollection",
		            	   serviceUrl : "/sap/opu/odata/SRMNXP/USERS_LIST/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"

		               },
		               {

		            	   name : "UTIL",
		            	   masterCollection : "UOMCollection",
		            	   serviceUrl : "/sap/opu/odata/SRMNXP/UTIL/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"

		               },
		               {

		            	   name : "CARTAPPROVAL",
		            	   masterCollection : "WorkflowTaskCollection",
		            	   serviceUrl : "/sap/opu/odata/GBSRM/CARTAPPROVAL;v=2;mo/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.sc.approve/model/metadata.xml"

		               },
		               {
		            	   name : "ACC_ASSIGN_CATEGORY",
		            	   masterCollection : "ACC_ASSIGN_CATEGORYCollection",
		            	   serviceUrl : "/sap/opu/odata/srmnxp/ACC_ASSIGN_CATEGORY/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
		               }
		               ],

	/**
	 * @inherit
	 */
	getServiceList : function() {
		return this.aServiceList;
	}

});


},
	"ui/s2p/srm/sc/track/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("ui.s2p.srm.sc.track.Main", {

	onInit : function() {
        jQuery.sap.require("sap.ca.scfld.md.Startup");				
		sap.ca.scfld.md.Startup.init('ui.s2p.srm.sc.track', this);
	},
	
	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * 
	 * @memberOf MainXML
	 */
	onExit : function() {
		//exit cleanup code here
	}	
	
});
},
	"ui/s2p/srm/sc/track/Main.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n\txmlns:core="sap.ui.core"\n\txmlns="sap.m"\n\tcontrollerName="ui.s2p.srm.sc.track.Main"\n\tdisplayBlock="true"\n\theight="100%">\n\t<NavContainer\n\t\tid="fioriContent"\n\t\tshowHeader="false">\n\t</NavContainer>\n</core:View>',
	"ui/s2p/srm/sc/track/util/Formatter.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.util.Formatter");

jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("sap.ui.core.Element");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.format.FormattingLibrary");


ui.s2p.srm.sc.track.util.Formatter = {

              showVisibilityAddress1: function(oObject){
                     if(oObject.length!= 0){
                           return true;
                     }
                     else{
                           return false;
                     }
              },

              showVisibilityAddress2: function(city,district,post,country_text){
                     if(city.length != 0 ||  district.length != 0 || post.length != 0 || country_text.length != 0){
                           return true;
                     }
                     else{
                           return false;
                     }
              },

              formatStatus : function(statusText) {
                     var retValue = sap.ui.core.ValueState.None;

                     switch (statusText) {
                     case "I1009": // Saved
                           retValue = sap.ui.core.ValueState.None;
                           break;
                     case "I1016": // Rejected
                           retValue = sap.ui.core.ValueState.Error;
                           break;
                     case "I1129": // Approved
                           retValue = sap.ui.core.ValueState.Success;
                           break;
                     case "I1015": // Pending
                           retValue = sap.ui.core.ValueState.Warning;
                           break;
                     default:
                           retValue = sap.ui.core.ValueState.None;
                           break;
                     }
                     return retValue;
              },

             formatAddress1: function(oObject){
                     if(oObject.length!= 0){
                           return oObject;
                     }
              },

              formatAddress2: function(city,district,post,country_text){
                     var address = "";
                     if (city.length !== 0) {
                           address=city;
                     }
                     if (address.length !== 0) {
                           address += "," + district + " " + post;
                     }
                     if (address.length !== 0) {
                           address += ", " + country_text;                        
                     } 
                     return address;
              },

              formatPreferredItem : function(assortmentInd) {
                     if (assortmentInd === "01") {
                           var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                           var oBundle = oApplication.getResourceBundle();
                           return oBundle.getText("PREFERRED_ITEM");
                     } else {
                           return "";
                     }
              },

              formatCartNumber : function(cartNumberText) {
                     var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                     var oBundle = oApplication.getResourceBundle();
                     return oBundle.getText("CART_NUMBER_EX", [ cartNumberText ]);
              },

              formatItemCount : function(itemCount) {
                     var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                     var oBundle = oApplication.getResourceBundle();
                     return oBundle.getText("ITEMS_QTY_EX", [ itemCount ]);
              },

              formatMaxDeliveryDate : function(itemList) {
                     var currentDeliveryDate = null;
                     for ( var i = 0; i < itemList.length; i++) {
                           if (itemList[i].DELIV_DATE > currentDeliveryDate) {
                                  currentDeliveryDate = itemList[i].DELIV_DATE;
                           }
                     }
                     var dateType = new sap.ui.model.type.Date();
                     dateType.setFormatOptions("medium");
                     return dateType.formatValue(currentDeliveryDate, "string");
              },
              formatDeliveryDate : function(itemDetailData){
        	  		if ( itemDetailData.PRODUCT_TYPE === '02' ){
        	  			        	  			
        	  			var DateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
        	  			var startDate = DateFormatter.format(itemDetailData.VPER_START,true);
        	  			var endDate = DateFormatter.format(itemDetailData.VPER_END,true);
        	  			        	  		
        	  			var delivDateInfo;
        	  			if( itemDetailData.VPER_TYPE  === 'AT' ){        	  				
        	  				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ON", [startDate]);
        	  			}
        	  			else if( itemDetailData.VPER_TYPE  === 'FR' ){
        	  				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("FROM", [startDate]);
        	  			}
        	  			else if ( itemDetailData.VPER_TYPE  === 'BE' ){        	  				
        	  				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("TO", [startDate,endDate]);
        	  			}
        	  			       	  		
        	  		}
        	  		else if(itemDetailData.PRODUCT_TYPE === '01' ){
        	  			var DateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
        	  			var delivDate = DateFormatter.format(itemDetailData.DELIV_DATE,true);        	  			
        	  			return delivDate;
        	  		}
            	  
              },

              formatItemAndCount : function(ItemAndCount, totalItems) {
                     var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                     var oBundle = oApplication.getResourceBundle();
                     return oBundle.getText("ITEM_AND_COUNT_EX",     [ ItemAndCount, totalItems ]);
              },

              formatPrice : function(oValue, sCurrency,priceUnit, unit) {
                     var formatter = sap.ca.ui.model.format.AmountFormat.getInstance({
                           style: "standard",
                           decimals: "2"
                     });
                     return formatter.format(oValue) + ' ' + sCurrency + ' '+ '/' + priceUnit + ' ' + unit;
              },
              
              formatPriceItem : function(oValue) {
      			var formatter = sap.ca.ui.model.format.AmountFormat.getInstance({
    				style: "standard",
    				decimals: "2"
    			});
    			return formatter.format(oValue);
    		},
              //Show an element if required
              showElementOnUi : function(obj){
                     if(obj==''){
                           return false;
                     }
                     else{
                           return true;
                     }
              },
              formatCategory : function(value1, value2){
                     return value1+ ' ' + " ("+value2+")";
              },
              formatDesc : function(value1){
                  return  " ("+value1+")";
           },


              formatACCCategory : function(acc){
                     switch(acc)
                     {
                           case ('CC') : return( 'Cost Center');    
                     }
              },
              
              formatCatName : function(obj) {
                     if (obj == "02") {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_NAME");
                          
                           
                     } else {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_NAME");
                     }
              },

              //Format the item as Product or Sevice Category
              formatCatType : function(obj) {
                     if (obj == "02") {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_CATEGORY");
                     } else {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_CATEGORY");
                     }
              },
              //Check if a value is 0
              valueVisibilityCheck : function(obj){
                     if (obj == 0)
                           return false;
                     else
                           return true;
              },
              
              //Show Notes label if there are notes for an item
              setNoteText : function() {
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('NOTES');

              },
              showSupplierNotes : function(noteType){
                if(noteType == 'ITXT')
                       return true;
                else
                       return false;
              },
              //Show the format of an attachment
              formatAttachmentIcon : function(sMimeType) {
                     var formatterFileIcon = sap.ca.ui.model.format.FormattingLibrary.formatAttachmentIcon(sMimeType);
                     return formatterFileIcon;
              },

              //Show the total size of the attachment
              formatAttachmentSize : function(bytes) {
                 var formatter = sap.ca.ui.model.format.FileSizeFormat.getInstance();
                     var result = formatter.format(bytes);
                     return result;
                     return '12 kb';
              },

              //Open or download the attachment
              showAttachment : function(url) {
                     var sMedia_src = url;
                     sap.m.URLHelper.redirect(sMedia_src, true);
              },
              //Show Attachments label if there are attachments for an item
              setAttachmentText : function() {
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ATTACHMENTS');
              },
              //Check if an array is empty
              arrayVisibilityCheck : function(obj) {                 
                     if (obj.length == 0)
                           return false;
                     else
                           return true;               
              },
              //Set the Account Assignment label 
              setAccountAssignmentText : function(){
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ACCOUNT_ASSIGNMENT');
              },

              formatDistributionPercentage : function(value) {
                     var percent = "%";
                     if (parseFloat(value)) {
                           value = value.split('.').join(',');
                           value += percent;
                     }
                     return value;
              },

              setApproverText : function(){
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('APPR_CHAIN');
              },

              showDeliveryAddress : function(a,b,c,d)
              {
                     return (a + "," + b + " "+ c + " " + d) ;
                     
              },
              //Delivery date for an item in item detail page
              showDeliveryDateHeader : function(oDate, fromDate, toDate){
                     var DateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
                     if(oDate){
                           var mediumDate = DateFormatter.format(oDate,true);
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_ON', [mediumDate]);
                     }
                     else{
                           var mediumFromDate = DateFormatter.format(fromDate,true);
                           var mediumToDate = DateFormatter.format(toDate,true);
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_REQUIRED', [mediumFromDate, mediumToDate]);
                     }

              },

};



},
	"ui/s2p/srm/sc/track/util/ItemList.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.util.ItemList");

ui.s2p.srm.sc.track.util.ItemList = {};

/*
 * We use this Utility object to keep track of the items in the Shopping Cart
 * The items collection can be retrieved in the ItemDetail screen and helps
 * navigating to previous or next items when the Up/Down navigation buttons
 * are clicked. 
 */
ui.s2p.srm.sc.track.util.ItemList.item = (function() {
	var items = [];
	return {
		//Added scnumber, itemnumber for fiori performance improvement
		add : function(itemList) {
			this.clear();
			for(var i = 0; i < itemList.length; i++){
				items.push({
					objectid : itemList[i].OBJECT_ID,
					item : itemList[i].NUMBER_INT,
					index : i
					
				});
			}			
		},
		

		each : function(callback) {
			for ( var i = 0; i < items.length; i++) {
				callback(items[i].item);
			}
		},

		length : function() {
			return items.length;
		},

		clear: function(){
			items = [];
		},
		
		getIndex : function(itemname) {
			for ( var i = 0; i < items.length; i++) {
				if (items[i].item === itemname)
					return i;
			}
			return -1;
		},
		
		getItemAtIndex: function(index){
			return items[index].objectid;
		},
		getSCItemNumber: function(index){
			return items[index].item;
		}
	};
})();

},
	"ui/s2p/srm/sc/track/view/ItemDetail.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

sap.ca.scfld.md.controller.BaseDetailController
              .extend(
                           "ui.s2p.srm.sc.track.view.ItemDetail",
                           {

                                  onInit : function() {
                                         // execute the onInit for the base class
                                         // BaseDetailController
                                         sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit
                                                       .call(this);

                                         // Get instance of the busy dialog
                                         this.busyDialog = new sap.m.BusyDialog({
                                                customIcon : sap.ca.ui.images.images.Flower
                                         });

                                         // Setting the Navigate back visible true for moving
                                         // back to S3
                                         // controller
                                         // this.getView().byId("itemHeader")
                                         // .setShowNavButton(true);

                                         this.oRouter
                                                       .attachRouteMatched(
                                                                     function(oEvent) {
                                                                           if (oEvent.getParameter("name") === "itemDetail") {
                                                                        	   
                                                                                  this.objectid = oEvent.getParameter("arguments").objectid;
                                                                                  this.numberInt = oEvent.getParameter("arguments").numberint;
                                                                                  this.sapOrigin = oEvent.getParameter("arguments").sapOrigin;
                                                                                  this.initHeaderFooter(this.numberInt);
                                                                                  this.readContent(this.objectid,this.numberInt);
                                                                           }
                                                                     }, this);
                                     	//Call the account assignment category service to get the leading acc assign
                                         var onRequestSuccessAccCat = function(oData, oResponse) {                                         	
                                         	this.accCatObj = oData;  
                                         	
                                         };
                                         if(this.accCatObj == undefined){                                        	 
                                        	 var oDataModel_acc = this.oApplicationFacade.getODataModel("ACC_ASSIGN_CATEGORY");
                                        	 oDataModel_acc.read("AccountAssignmentCategoryCollection",
                                                                    null, null, true, jQuery.proxy(onRequestSuccessAccCat, this), jQuery.proxy(this.onRequestFailedAccCat, this));
                                         }
                                         //Call Unit of measure service to get the UOM text
                                         var onRequestSuccessUOM = function(oData, oResponse) {                                            	 
                                          	this.UOMObj = oData;  
                                          	
                                          };
                                         if(this.UOMObj == undefined){
                                        	 var oDataModel_acc = this.oApplicationFacade.getODataModel("UTIL");
                                        	 oDataModel_acc.read("UOMCollection",
                                                                    null, null, true, jQuery.proxy(onRequestSuccessUOM, this), jQuery.proxy(this.onRequestFailedAccCat, this));
                                         
                                         }

                                  },

                                  // Read details of a particular item by calling a service
                                  readContent : function(objectid, numberInt) {
                                         var onRequestSuccess = function(oData) {
                                                this.itemObj = oData;
                                                
                                            
                                          // Call a binding for view
                                             this.bindView();                                                
                                         };

                                         var obj = this.oApplicationFacade.getODataModel().sServiceUrl;

                                         // Since the service uses the backend service name, a
                                         // concatenation of
                                         // its name to service URL done
                                         this.oApplicationFacade.getODataModel().sServiceUrl = obj
                                                       .split(";")[0]
                                                       + ";mo";                                         
                                         this.busyDialog.open();

                                         var NUMBER_INT = numberInt, objectID = objectid;

                                         var OSRMShoppingCartDataModel = this.oApplicationFacade
                                                       .getODataModel("SRMSHOPPING_CART");
                                         var aBatchArray = new Array();
                                         var url = "SRMShoppingCartItemDataCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                                       + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                                       + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                                + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                                + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                  
                                         url = url + "/ItemAccountAssignmentNavigation";
                                         
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         url = "ShippingAddressCollection(SAP__Origin='" + this.sapOrigin + "',ItemNumber='" 
                                                       + NUMBER_INT + "',ShoppingCartID='" + objectID 
                                                       + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));

                                         
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                                + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                                + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         
                                         url = url + '/ItemAttachmentNavigation';
                                         
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='"     + NUMBER_INT  
                                         + "',OBJECT_ID='" + objectID + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         
                                         url = url + '/ItemApproverNavigation';
                                         

                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         //to get SoS data
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                             + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                             + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         url = url + '/SourceofSupplyNavigation';
                               
                               aBatchArray.push(OSRMShoppingCartDataModel
                                             .createBatchOperation(url, "GET"));

                                         
                                         OSRMShoppingCartDataModel
                                                       .addBatchReadOperations(aBatchArray);

                                         
                                         OSRMShoppingCartDataModel.submitBatch(jQuery.proxy(
                                                       onRequestSuccess, this), jQuery.proxy(
                                                       this.onRequestFailed, this));

                                         
                                         var onRequestSuccessNotes = function(oData, oResponse) {
                                                this.bindNotes(oData, oResponse);
                                         };
                                         
                                         
                                         /**
                                          * @ControllerHook Extension hook for saving  
                                          * This hook can be used to save the fields through extensibility
                                          * @callback sap.ca.scfld.md.controller.BaseDetailController~extHook3
                                          * @return {void}  ...
                                         */
                                   	  //var extensionHook3 = this.onDataRecieved3;
                                   	  if(this.extHook3){
                                   			this.extHook3();
                                   	  };
                                         
                                         var oDataModel1 = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
                                         oDataModel1.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectID + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartNotesNavigation?$filter=ITM_NUMBER_INT eq '" + NUMBER_INT + "'",
                                                                    null, null, true, jQuery.proxy(onRequestSuccessNotes, this), jQuery.proxy(this.onRequestFailed, this));

                                  },

                                  bindNotes : function(oData) { 
                                         var itemNotes = oData.results ;
                                         var itemSupplierNote;

                                        
                                        
                                         var oModelDetail = new sap.ui.model.json.JSONModel({
                                                'notesdata' : itemNotes                                       
                                         });
                                         this.getView().setModel(oModelDetail, "notes");

                                  },
                                  
                                  bindView : function() {
                                         // this.getApproveRejectData();                                	
                                         if(this.itemObj.__batchResponses[0].data)
                                         {
                                                var itemDetailData = this.itemObj.__batchResponses[0].data;
                                                if(this.UOMObj){
                                                	var oUOMData = this.UOMObj.results;
                                                	for(var i=0; i<oUOMData.length;i++){
                                                		if(itemDetailData.UNIT == oUOMData[i].COMMERCIAL_UNIT)
                                                			itemDetailData.UNIT_TEXT = oUOMData[i].UOM_TEXT;
                                                	}
                                                }
                                                var deliveryDateValue= ui.s2p.srm.sc.track.util.Formatter.formatDeliveryDate(itemDetailData);
                                    			this.getView().byId("deliveryDate").setText(deliveryDateValue);
                                         }
                                         
                                         
                                         if(this.itemObj.__batchResponses[1].data)
                                                {                                        	
                                        	 var itemAcc = this.itemObj.__batchResponses[1].data.results;
                                             var oAccCatObj = this.accCatObj.results;
                                             for(var i=0;i<itemAcc.length;i++){
                                            	 for(var j=0;j<oAccCatObj.length;j++){
                                            		 if(itemAcc[i].ACC_CAT == oAccCatObj[j].ACC_ASSIGN_CAT_CODE){
                                            			 itemAcc[i].acc_cat_ui = oAccCatObj[j].ACC_ASSIGN_CAT_DESC;
                                            			 itemAcc[i].acc_cat_val_ui = itemAcc[i][oAccCatObj[j].ACC_ASSIGN_FIELD];
                                            			// to get account assignment description
                                                         var desc_cat;
                                                         switch (oAccCatObj[j].ACC_ASSIGN_FIELD) {
                                                         case 'COST_CTR':
                                                           desc_cat = "CC";
                                                           break;
                                                         case 'SD_DOC':
                                                           desc_cat = "SO";                                                           
                                                           break;
                                                         case 'NETWORK':
                                                           desc_cat = "NET";                                                           
                                                           break;
                                                         case 'ORDER_NO':
                                                           desc_cat = "OR";                                                           
                                                           break;
                                                         case 'WBS_ELEM_E':
                                                           desc_cat = "WBS";                                                           
                                                           break;
                                                         case 'ASSET_NO':
                                                           desc_cat = "AS";                                                          
                                                           break;
                                                         case 'G_L_ACCT':
                                                           desc_cat = "GL";                                                           
                                                           break;
                                                         case 'ACTIVITY':
                                                           desc_cat = "ACTIVITY";                                                           
                                                           break;
                                                         case 'FUNC_AREA':
                                                           desc_cat = "FAREA";                                                           
                                                           break;
                                                         case 'FUND':
                                                           desc_cat = "FUND";                                                           
                                                           break;
                                                         case 'GRANT_NBR':
                                                           desc_cat = "GRANT";                                                           
                                                           break;
                                                         default:

                                                           break;
                                                         }

                                                         itemAcc[i].acc_cat_desc_ui = itemAcc[i][desc_cat + "_DESCRIPTION"];
                                            			                                             			
                                            		 }
                                            	 }
                                             }
                                          
		                                        	 
                                        
                                        	 
                                                }
                                         if(this.itemObj.__batchResponses[2].data)
                                                {
                                         var itemShpAdr = this.itemObj.__batchResponses[2].data;
                                                }
                                         if(this.itemObj.__batchResponses[3].data)
                                                {
                                                var itemAtt = this.itemObj.__batchResponses[3].data.results;
                                         itemAtt.splice(0,1);
                                         //itemAtt[0].FileSize = '12 KB';
                                                }
                                         if(this.itemObj.__batchResponses[4].data)
                                         {
                                                var approverData = this.itemObj.__batchResponses[4].data.results;
                                                var i;
                                    			for(i=0;i<approverData.length;i++)
                                    			{
                                    				if(approverData[i].AGENT_ID == "" && approverData[i].PROCESSOR_NAMES_CONC != "")
                                    				{

                                    					var appName = approverData[i].PROCESSOR_NAMES_CONC.split(";");                                    					
                                    					var appId = approverData[i].APR_AGENT_ID.slice(1).split(';');
                                    					var j;
                                    					for(j=0;j<appName.length;j++)
                                    					{
                                    						var appClone = new Object();
                                    						jQuery.extend(appClone, approverData[i]);
                                    						appClone.PROCESSOR_NAMES_CONC = appName[j];
                                    						appClone.AGENT_ID = appName[j];
                                    						appClone.APPROVER_ID = appId[j];
                                    							if(j==0)
                                    								approverData.splice(i,1,appClone);
                                    							else
                                    								approverData.splice(i,0,appClone);
                                    						
                                    					}
                                    				}
                                    				else if(approverData[i].AGENT_ID !== ""){
                                    					var appAgntId = approverData[i].APR_AGENT_ID.slice(1).split(';');
                                    					if(appAgntId.length === 1 && appAgntId[0] === approverData[i].AGENT_ID)
                                    						approverData[i].APPROVER_ID = approverData[i].AGENT_ID;
                                    				}
                                    				
                                    			}
                                         }
                                         if(this.itemObj.__batchResponses[5].data.results)
                                         {                                        	 
                                                var itemSoSData = this.itemObj.__batchResponses[5].data.results;
                                                var itemAssignSupplier;
                                                for ( var i = 0; i < itemSoSData.length; i++) {
                                                	if(itemSoSData[i].Supplierstatus == 'A'){
                                                		itemAssignSupplier = itemSoSData[i];
                                                		break;
                                                	}                                                		
                                                }
                                                
                                         }
                                                
                                         var oModelDetail = new sap.ui.model.json.JSONModel({
                                                'itemDetail' : itemDetailData,
                                                'shipAddr' : itemShpAdr,
                                                'account' : itemAcc,                                          
                                                'attach' : itemAtt,
                                                'approvers': approverData,
                                                'supplier':itemAssignSupplier
                                                
                                         });
                                         this.getView().setModel(oModelDetail, "itemDetailData");

                                         // this.initHeaderFooter(this.itemObj.WorkitemID);
                                         // close the busy dialog first
                                         this.busyDialog.close();

                                  
                                  },
                                  // On click of the attachment
                                  onAttachment : function(oEvent){
                                         var index = parseInt(oEvent.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
                                         var URL = this.itemObj.__batchResponses[3].data.results[index].__metadata.media_src;
                                         ui.s2p.srm.sc.track.util.Formatter.showAttachment(URL);
                                  },
                                
                              	//On click of the approver's name
                              	onApproverPress : function(oEvent) {	                              	
                              		if(oEvent.getSource().getBindingContext('itemDetailData')){
                              			var ind = parseInt(oEvent.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
                              			var arr = this.itemObj.__batchResponses[4].data.results;
                              			var selectedlistid = oEvent.getParameters().id;
                              			var oControl = this.getView().byId(selectedlistid);
                              			//this.handleUserNameClick(oControl, arr[ind].AGENT_ID);
                              			this.handleUserNameClick(oControl, arr[ind].APPROVER_ID);
                              		}
                              	},
                            	//Show Business Card on click of a name.
                            	handleUserNameClick: function(oControl, eId){
                            		//Get the Picture of the employee if exists
                            		var oPicture = this.formatEmployee(eId);
                            		var onRequestSuccess = function(oData, oRespose){                            			
                            			var oEmployee = {
                            					imgurl : oPicture,
                            					name             : oData.results[0].FullName,
                            					department       : "",
                            					contactmobile    : oData.results[0].MobilePhone,
                            					contactphone     : oData.results[0].WorkPhone,
                            					companyname      : oData.results[0].CompanyName,
                            					contactemail     : oData.results[0].EMail,
                            					contactemailsubj : "",
                            					companyaddress   : oData.results[0].AddressString
                            			};

                            			//call 'Business Card' reuse component
                            			var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmployee);
                            			oEmployeeLaunch.openBy(oControl);
                            		};			                            		
                            		var obj=this.oApplicationFacade.getODataModel("CARTAPPROVAL").sServiceUrl;
                            		
                            		var oDataModel = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
                            		//Service read for User Details retrieval
                            		oDataModel.read("UserDetailsCollection", null,
                            				[ "$filter=UserID eq '" + eId + "' and SAP__Origin eq '" +this.sapOrigin + "'"], false,
                            				  
                            				jQuery.proxy(onRequestSuccess, this),
                            				jQuery.proxy(this.onRequestFailed, this));
                            		
                            		
                            		
                            		
                            	},
                            	//Get Employee's Picure 
                            	formatEmployee : function(ApproverID){	                            		
                            	var oVar 		= "";
                        		var oServerName = this.sapOrigin.replace(/'/g, "");
                        		var oModel = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
                        		
                        		var fnSuccess = function(oData,oResponse){
                        			if(oResponse.body.length === 0){
                        				oVar = jQuery.sap.getModulePath("ui.s2p.srm.sc.track")+ "/img/" + "person_placeholder.png";
                        			}
                        			else
                        			{
                        				oVar = oResponse.requestUri;	
                        			}	
                        			oModel.sServiceUrl = oModel.sServiceUrl .split(";")[0]+";v=2;mo";
                        		};
                        		
                        		var fnError = function(oError){
                        			oVar = jQuery.sap.getModulePath("ui.s2p.srm.sc.track")+ "/img/" + "person_placeholder.png";
                        			oModel.sServiceUrl = oModel.sServiceUrl .split(";")[0]+";v=2;mo";
                        		};
                        		
                        		oModel.sServiceUrl = oModel.sServiceUrl.split(";")[0]+";v=2;o="+oServerName;
                        		oModel.read("UserDetailsCollection('" + ApproverID + "')/$value",null,null,false,jQuery.proxy(fnSuccess,this),jQuery.proxy(fnError,this));
                        	
                        		return oVar;
                            		
                            	},
                            	

                            	/**
                            	 * @private [ initHeaderFooter Initialize the back button, item navigation buttons etc.] 
                            	 */
                            	initHeaderFooter: function(objectid){
                            		var that = this;
                            		this.oHeaderFooterOptions = {
                            			onBack : function(oEvent) {
                            				var path = "ordertrackCollection(SAP__Origin='" + that.sapOrigin + "',OBJECT_ID='" + that.objectid + "')";
                                            that.oRouter.navTo("detail", {  
                                                        contextPath : path

                                        },true);
                            			},
                            			oUpDownOptions : {
                            				sI18NDetailTitle: "ITEM_AND_COUNT_EX",
                            				iPosition : 0,
                            				iCount : 0,
                            				fSetPosition : function (iNewPosition) {
                            					if ( (iNewPosition >= 0) && (iNewPosition < ui.s2p.srm.sc.track.util.ItemList.item.length() ) ) {
                            						that.objectid = ui.s2p.srm.sc.track.util.ItemList.item.getItemAtIndex(iNewPosition);
                            						that.numberInt = ui.s2p.srm.sc.track.util.ItemList.item.getSCItemNumber(iNewPosition);
                            						that.oRouter.navTo("itemDetail", {
                            							objectid   : that.objectid,
                            							numberint: that.numberInt,
                            							itemIndex: iNewPosition,
                            							sapOrigin: that.sapOrigin
                            				
                            						}, true);
                            					}
                            				}
                            			}
                            		};
                            		
                            		this.oHeaderFooterOptions.oUpDownOptions.iPosition = ui.s2p.srm.sc.track.util.ItemList.item.getIndex(that.numberInt);
                            		this.oHeaderFooterOptions.oUpDownOptions.iCount    = ui.s2p.srm.sc.track.util.ItemList.item.length();
                            		this.setHeaderFooterOptions(this.oHeaderFooterOptions);
                            	},
                            	


                           });



},
	"ui/s2p/srm/sc/track/view/ItemDetail.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc"\n       xmlns:sap.me="sap.me" xmlns:sap.ui.layout.form="sap.ui.layout.form"\n       xmlns:sap.ui.layout="sap.ui.layout" xmlns:sap.ui.core.mvc="sap.ui.core.mvc"\n       xmlns:sap.ui.core="sap.ui.core" controllerName="ui.s2p.srm.sc.track.view.ItemDetail">\n       <Page id="itemDetailPage" navButtonPress="_navBack" showNavButton="true"\n              class="sapUiFioriObjectPage">\n              <content>\n                     <ObjectHeader id="objectheader1"\n                     title="{itemDetailData>/itemDetail/DESCRIPTION}"\n                          \n                           number = "{path:\'itemDetailData>/itemDetail/PRICE\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}"\n                           numberUnit="{itemDetailData>/itemDetail/CURRENCY}" titleActive="false">\n                           <firstStatus>\n                                  <ObjectStatus id="approveRejectIcon"></ObjectStatus>\n                           </firstStatus>\n                           <attributes>\n                                  <ObjectAttribute\n                                         text="{parts:[{path:\'itemDetailData>/itemDetail/QUANTITY\'},{path:\'itemDetailData>/itemDetail/UNIT_TEXT\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatQuantity\'}"></ObjectAttribute>\n                                  <ObjectAttribute                                         \n                                         text="{parts:[{path:\'itemDetailData>/itemDetail/PRICE\'},{path:\'itemDetailData>/itemDetail/CURRENCY\'},{path:\'itemDetailData>/itemDetail/PRICE_UNIT\'},{path:\'itemDetailData>/itemDetail/UNIT_TEXT\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPrice\'}"                                         \n                                         ></ObjectAttribute>                                 \n                           </attributes>\n                           \n                     </ObjectHeader>\n\n                     <sap.ui.layout.form:SimpleForm id="myForm1"\n                           minWidth="1024" editable="false">\n                            <sap.ui.layout.form:content>\n                                  <sap.ui.core:Title text="{i18n>ITEM_HEADER}"></sap.ui.core:Title>\n\n                                  <Label id="categoryName"\n                                         text="{path:\'itemDetailData>/itemDetail/PRODUCT_TYPE}\', formatter : \'ui.s2p.srm.sc.track.util.Formatter.formatCatName\'}"\n                                         visible="{path:\'itemDetailData>/itemDetail/DESCRIPTION}\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text id="categoryNameText" text="{itemDetailData>/itemDetail/DESCRIPTION}"\n                                         visible="{path:\'itemDetailData>/itemDetail/DESCRIPTION}\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}"\n                                         maxLines="0">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n\n                                  <Label id="categoryType"\n                                         text="{path:\'itemDetailData>/itemDetail/PRODUCT_TYPE\', formatter : \'ui.s2p.srm.sc.track.util.Formatter.formatCatType\'}"\n                                         visible="{path:\'itemDetailData>/itemDetail/CATEGORY_ID\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text id="categoryTypeText"\n                                         visible="{path:\'itemDetailData>/itemDetail/CATEGORY_ID\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}"\n                                         text="{parts:[{path:\'itemDetailData>/itemDetail/CATEGORY_TEXT\'},{path:\'itemDetailData>/itemDetail/CATEGORY_ID\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatCategory\'}"\n                                         maxLines="0">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                          \n\n                                  <Label id="supplier" text="{i18n>SUPPLIER}"\n                                         visible="{path:\'itemDetailData>/supplier/SupplierName\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text id="supplierText" text="{itemDetailData>/supplier/SupplierName}"\n                                         maxLines="0"\n                                         visible="{path:\'itemDetailData>/supplier/SupplierName\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                                  <Label id="deliveryDateLbl" text="{i18n>DELIVERY_DATE}" >                                        \n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>                               \n                                  <Text id="deliveryDate" \n                                  >   \n                                  \n                                                                                                                                               \n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                                  \n                                  <Label text="{i18n>DELIVERY_ADDRESS}" id="address"\n                                         visible="{path:\'itemDetailData>/shipAddr/AdditionalNo\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text\n                                         text="{parts : [{path:\'itemDetailData>/shipAddr/Street\'},{path:\'itemDetailData>/shipAddr/PostalCode1\'},{path:\'itemDetailData>/shipAddr/City\'},{path:\'itemDetailData>/shipAddr/CountryName\'}],\n                                                                     formatter:\'ui.s2p.srm.sc.track.util.Formatter.showDeliveryAddress\'}"\n                                         visible="{path:\'itemDetailData>/shipAddr/AdditionalNo\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}"\n                                         id="addressText" maxLines="0">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                                                                 \n\n                                  <!-- extension point for attributes -->\n\n                                  <core:ExtensionPoint name="extMoreInfo"></core:ExtensionPoint>\n                           </sap.ui.layout.form:content>\n                     </sap.ui.layout.form:SimpleForm>\n\n                \t  <List id="NotesDetail" items="{notes>/notesdata}"\n                           visible="{path:\'itemDetailData>/itemDetail/NUMBER_NOTES\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.valueVisibilityCheck\'}"\n                           headerText="{path:\'itemDetailData>/itemDetail/NUMBER_NOTES\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.setNoteText\'}"\n                           mode="SingleSelectMaster" show-separator="None">\n                           <items>\n                                  <FeedListItem sender="{notes>TEXT_ID_DESC_UI}"\n                                         showIcon="false" senderPress="onNotePersonPress" senderActive="false"\n                                         text="{notes>LONGTEXT}"\n                                         visible="{path:\'notes>TEXT_ID\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showSupplierNotes\'}" >\n\n                                  </FeedListItem>\n                           </items>\n                     </List> \t\t\n                                        \n                             \n                    \n\n                     <List id="AttachmentDetailData" items="{itemDetailData>/attach}"\n                           visible="{path:\'itemDetailData>/itemDetail/NUMBER_ATTACHMENTS\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.valueVisibilityCheck\'}"\n                           headerText="{path:\'itemDetailData>/itemDetail/NUMBER_ATTACHMENTS\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.setAttachmentText\'}"\n                           show-separator="None">\n                           <StandardListItem press="onAttachment" type="Active"\n                                  title="{itemDetailData>PHIO_FNAME}"\n                                  icon="{path:\'itemDetailData>PHIO_MIME\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAttachmentIcon\'}"\n                                  description="{path:\'itemDetailData>PHIO_FSIZE\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAttachmentSize\'}"\n                                  icon-inset="false">\n                           </StandardListItem>\n                     </List>\n\n              \n\n                           \n                     <Table id="tableHeader" items="{itemDetailData>/account}"\n                           visible="{path:\'itemDetailData>/account\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.arrayVisibilityCheck\'}"\n                           headerText="{path:\'itemDetailData>/account\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.setAccountAssignmentText\'}">\n                           <columns>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label text="{i18n>DESCRIPTION}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label text="{i18n>CATEGORY}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label id="GL_ACC" text="{i18n>GL_ACC}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label id="SHARE" text="{i18n>SHARE}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n\n                           </columns>\n                           <items>\n                                  <ColumnListItem type="Active" unread="true" counter="0"\n                                         id="itemListDetail">\n                                         <cells id="itemList">\n                                               <VBox>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<items>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectIdentifier title= "{itemDetailData>acc_cat_desc_ui}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectIdentifier title= "{path: \'itemDetailData>acc_cat_val_ui\' , formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatDesc\'}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t\t\t</VBox>                                                       \n                                                <ObjectIdentifier id="ob2"\n                                                       text="{itemDetailData>acc_cat_ui}"></ObjectIdentifier>\n                                                <VBox>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<items>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Text text= "{itemDetailData>GL_DESCRIPTION}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Text text= "{path: \'itemDetailData>G_L_ACCT\' , formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatDesc\'}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t\t\t</VBox>        \n                                                <ObjectNumber id="ob4"\n                                                       number="{path:\'itemDetailData>DISTR_PERC\', \n                                                              formatter : \'ui.s2p.srm.sc.track.util.Formatter.formatDistributionPercentage\'}">\n                                                </ObjectNumber>\n\n                                         </cells>\n                                  </ColumnListItem>\n                           </items>\n                     </Table>\n                     <List id="Approval_list" items="{itemDetailData>/approvers}"\n                           mode="SingleSelectMaster" show-separator="None"\n                            headerText="{path:\'itemDetailData>/approvers\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.setApproverText\'}"\n                           visible="{path:\'itemDetailData>/approvers\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.arrayVisibilityCheck\'}">\n                           <items>\n                                  <FeedListItem sender="{path:\'itemDetailData>PROCESSOR_NAMES_CONC\'}"\n                                         id="approverDet" icon-active="false" sender-active="true"\n                                         icon="{path : \'itemDetailData>APPROVER_ID\', formatter: \'.formatEmployee\'}"\n                                         iconPress="onApproverPress" senderPress="onApproverPress"\n                                         text="{itemDetailData>DECISION_SET_DESCR}">\n                                  </FeedListItem>\n                           </items>\n                     </List>\n\n\n\n              </content>\n       </Page>\n</core:View>\n\n\n',
	"ui/s2p/srm/sc/track/view/S2.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */

jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");

sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.track.view.S2", {	
	
    onInit : function() {
        //Execute the onInit for the base class BaseDetailController
        sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);

		//Set OData Model for the view, create the filters and bind the list 
		var oModel = this.oApplicationFacade.getODataModel();
		this.getView().setModel(oModel);
        oModel.setCountSupported(false);
        oModel.setSizeLimit(10);
        
        //The ordertrackCollection service requires two filter parameters to be passed
        //for the initial list to be populated. 
        var aFilters = [];
        
        var oFilterSearchFlag = new sap.ui.model.odata.Filter("ADV_SEARCH_FLAG", [ {
			operator : "EQ",
			value1 : 'false'
		} ]);
        aFilters.push(oFilterSearchFlag);
        
       /* var oFilterSCCount = new sap.ui.model.odata.Filter("SC_COUNT", [ {
			operator : "EQ",
			value1 : '10'
		} ]);
        aFilters.push(oFilterSCCount);*/
        
        
        /**
         * @ControllerHook Extension hook for saving  
         * This hook can be used to alter the search filters through extensibility
         * @callback sap.ca.scfld.md.controller.BaseMasterController~extHookInit
         * @param {Array} aFilters ...
         * @return {void}  ...
        */

		 if(this.extHookInit){
		  	this.extHookInit(aFilters);
		  }
        
        
        var oList = this.getList();
        var oTemplate = oList.getItems()[0].clone();
        
        oList.bindItems("/ordertrackCollection", oTemplate, null, aFilters);
        this.registerMasterListBind(oList);
    },
    
    /**
     * @public [ Navigate to the detail screen based on the user item section ]
     */
    setListItem : function(oItem) {
		var bindingContext = oItem.getBindingContext();
		oItem.setSelected(true);
		this.getList().setSelectedItem(oItem, true);
		this.oRouter.navTo("detail", {   
			contextPath : bindingContext.getPath().substr(1),
		}, true);
		
		/**
         * @ControllerHook Extension hook for saving  
         * This hook can be used to save the fields through extensibility
         * @callback sap.ca.scfld.md.controller.BaseMasterController~extHook1
         * @return {void}  ...
        */
  	  //var extensionHook1 = this.onDataRecieved1;
  	  if(this.extHook1){
  			this.extHook1();
  	  };
	},
	
	/**
	 * @public [Front-end search - filter the initial list based on user input]
	 * @param  {[type]} oItem
	 * @param  {[type]} sFilterPattern - search pattern entered in the search field
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {
		if (sFilterPattern.substring(0, 1) === "#") {
			var sTail = sFilterPattern.substr(1);
			var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
			return sDescr.indexOf(sTail) === 0;
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem,
					sFilterPattern);
		}
	},
	
	/**
	 * @public [getHeaderFooterOptions Define header & footer options]
	 */
	getHeaderFooterOptions : function() {
		return {
			sI18NMasterTitle : "MASTER_TITLE",
			buttonList: []
		};
	},
	
    /* 
     * Enables backend search 
     */
     isBackendSearch : function() {
                     return true;
     },
     /*
     * Creates the backend filter pattern
     */
     applyBackendSearchPattern : function(sFilterPattern, oBinding) {

			var aFilters=[];
			
			if(sFilterPattern) {
			 aFilters = [
			             new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false),
			             new sap.ui.model.Filter("DESCRIPTION", sap.ui.model.FilterOperator.EQ, sFilterPattern)
			         ];
			} 
			else {
			 aFilters = [
			             new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false)
			             /*new sap.ui.model.Filter("SC_COUNT", sap.ui.model.FilterOperator.EQ,'200')*/
			         ];
			}
			oBinding.filter(aFilters, sap.ui.model.FilterType.Application);
			}

});
},
	"ui/s2p/srm/sc/track/view/S2.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\tcontrollerName="ui.s2p.srm.sc.track.view.S2">\n\t<Page id="page" title="{i18n>MASTER_TITLE}">\n\t\t<content>\n\t\t\t<List id="list" mode="{device>/listMode}" select="_handleSelect"\n\t\t\t\tupdateFinished="selectFirstItem" growing="true" growingThreshold="10">\n\t\t\t\t<ObjectListItem id="MAIN_LIST_ITEM" type="{device>/listItemType}"\n\t\t\t\t\tpress="_handleItemPress" title="{parts:[{path:\'i18n>CART\'},{path:\'OBJECT_ID\'}]}"\n\t\t\t\t\tnumber="{parts:[{path:\'NET_VALUE\'}],formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}"\n\t\t\t\t\tnumberUnit="{CURRENCY}">\n\t\t\t\t\t<firstStatus>\n\t\t\t\t\t\t<ObjectStatus text="{STATUS_DESC}"\n\t\t\t\t\t\t\tstate="{path: \'STATUS\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatStatus\'}"></ObjectStatus>\n\t\t\t\t\t</firstStatus>\n\t\t\t\t\t<attributes>\n\t\t\t\t\t\t<ObjectAttribute id="ATTR1"\n\t\t\t\t\t\t\ttext="{path:\'CREATED_ON\', type:\'sap.ui.model.type.Date\', formatOptions: {style:\'medium\'}}" />\n\n\t\t\t\t\t\t<!-- extension point for attributes -->\n\t\t\t\t\t\t<core:ExtensionPoint name="extMoreAttr"></core:ExtensionPoint>\n\t\t\t\t\t</attributes>\n\t\t\t\t</ObjectListItem>\n\t\t\t</List>\n\t\t</content>\n\n\t\t<footer>\n\t\t\t<Bar id="footer"></Bar>\n\t\t</footer>\n\n\t</Page>\n</core:View>',
	"ui/s2p/srm/sc/track/view/S3.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
	jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.track.view.S3",
{
		
	onInit : function() {
		// execute the onInit for the base class
		// BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		
		// Get reference of resource bundle		
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		
		// Get instance of the busy dialog
		this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});
	//	  var newObject = jQuery.extend(true, {}, sap.ui.getCore().byId("__xmlview2--list").getItems()[0]);
//		this.oDisplay = new Object();
//		this.oDisplay = sap.ui.getCore().byId("__xmlview2--list").getItems()[0].clone();
//		this.oDisplay.mProperties = sap.ui.getCore().byId("__xmlview2--list").getItems()[0].mProperties;
		
	//	var oSelectedObjectListItem = sap.ui.getCore().byId("__xmlview2--list").getItems()[0];
	//	if(oSelectedObjectListItem)
   //		this.oDisplay = oSelectedObjectListItem.clone();
								
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {	
				//parse the object Id from the context path
				 var contextPath = oEvent.getParameter("arguments").contextPath;
                 var splitArray  = contextPath.split("ordertrackCollection('");
                 var objectId    = splitArray[0].split("'")[3];
                 var sapOrigin  = splitArray[0].split("'")[1];
                 this.sapOrigin  = sapOrigin;

				//start the busy dialog
				this.busyDialog.open();
				
				this.getCartInfo(objectId);
				this.getCartItems(objectId);
				this.getApprovalDetails(objectId);
			}

		}, this);
		
		var oHeader  = this.byId("header");
		
		var oItemList= this.byId("itemList");

        if (oItemList) {
            oHeader.addEventDelegate({
                onAfterRendering: this.updateItemsList
            }, this);
        }
	},
	


	/**
	 * @public [ getHeaderFooterOptions Define Header and Footer for the Detail Screen ]
	 */
	getHeaderFooterOptions: function(){	
		

		return {
			sI18NDetailTitle: "TITLE_RECENT_CART",
			oAddBookmarkSettings : {
				title : this.oBundle.getText("TITLE_RECENT_CART"),
				icon  : "sap-icon://cart"
			},
			
			oJamOptions : {

				oShareSettings : {
					object:{
							id : this.approvalLink,
							display: this.oDisplay,
							share : this.object_ID
							}
								},
							}
				};
		},
	
	/**
	 * @private [ getCartInfo Get Information about the Shopping Cart - Header, Info tab
	 * Since the detail page is populated by different services, we explicitly 
	 * set the model for each section separately. ] 
	 * @param {[type]} objectId - Cart Id
	 */
	getCartInfo : function(objectId) {
		this.getView().byId("icontabBar").setSelectedKey("Information");
		
		var onRequestSuccess = function(oData, oResponse) {
			var oHeaderModel = new sap.ui.model.json.JSONModel(oData);
			
			if(oData.WIID != '000000000000'){
				this.approvalLink = document.location.origin + document.location.pathname + document.location.search + "#ShoppingCartItem-approve&/detail/WorkflowTaskCollection(SAP__Origin=" + jQuery.sap.encodeURL("'") + this.sapOrigin + jQuery.sap.encodeURL("'")+",WorkitemID=" + jQuery.sap.encodeURL("'") + oData.WIID + jQuery.sap.encodeURL("'")+")";

			}
			else
			{
				this.approvalLink = '';
			}
			this.object_ID = objectId;
			this.objectStatus = new sap.m.ObjectStatus({text:oData.HEADER_STATUS_DESCR});
            this.oDisplay=new sap.m.ObjectListItem({
            	title :this.oBundle.getText("CART")+" "+oData.OBJECT_ID,
            	number : oData.TOTAL_GROSS,
            	numberUnit:oData.CURRENCY,
            	firstStatus:this.objectStatus
    });

            
         var oHFOptions = this.getHeaderFooterOptions();
         this.setHeaderFooterOptions(oHFOptions);

			
			//set model for the Object Header
			this.getView().byId("header").setModel(oHeaderModel, "ShoppingCartHeader");

			//set model for the information tab
			this.getView().byId("info").setModel(oHeaderModel, "ShoppingCartInfo");								
			
			this.parseApprovalNotes();
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		oDataModel.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectId + "',DOC_MODE='DISPLAY',WIID='000000000000')",
						null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		/**
         * @ControllerHook Extension hook for saving  
         * This hook can be used to save the fields through extensibility
         * @callback sap.ca.scfld.md.controller.BaseDetailController~extHook2
         * @return {void}  ...
        */
  	  //var extensionHook2 = this.onDataRecieved2;
  	  if(this.extHook2){
  			this.extHook2();
  	  };
	},
	
	/**
	 * @private [ updateItemsList Update the item list entries header ]
	 */
	updateItemsList: function(oEvent){
		var oSrcControl = oEvent.srcControl;
		if(oSrcControl.getModel('ShoppingCartHeader') !== undefined ){
			setTimeout(jQuery.proxy(function() {
				var itemCount   = oSrcControl.getModel('ShoppingCartHeader').getData().ITEM_COUNT;
				var headerText  = ui.s2p.srm.sc.track.util.Formatter.formatItemCount(itemCount);
				this.getView().byId("itemList").setHeaderText(headerText);
			}, this), 100);
		}
	},

	/**
	 * @private [ getCartItems Get a list of cart items ]
	 * @param {[type]} objectId - Cart id
	 */
	getCartItems : function(objectId) {
		
		var onRequestSuccess = function(oData, oResponse) {
			
			this.oItemModel = new sap.ui.model.json.JSONModel(oData);
			this.getView().byId("itemList").setModel(this.oItemModel, "ShoppingCartItems");
			
			var deliveryDateValue= ui.s2p.srm.sc.track.util.Formatter.formatMaxDeliveryDate(oData.results);
			this.getView().byId("deliv_Date").setText(deliveryDateValue);
			
			//we use a global array to keep track of product key for each of the items in a shopping cart
			ui.s2p.srm.sc.track.util.ItemList.item.clear();
			for ( var i = 0; i < oData.results.length; i++) {
				ui.s2p.srm.sc.track.util.ItemList.item.add(oData.results);
			}
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel();
        oDataModel.read("ordertrackCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectId + "')/OrderTrackItemNavigation", null,
                null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));

		
	},

	/**
	 * @private [ onDetailListItemPressed Navigate to the Item Detail Page ]
	 */
	onDetailListItemPressed : function(oEvent) {
		// Delegate event to parent controller
		var listItem = oEvent.getSource();
		var bindingContext = listItem.getBindingContext("ShoppingCartItems");
		
		var oModel   = bindingContext.getModel();
		var path     = bindingContext.getPath();
		var itemdet  = oModel.getProperty(path);
		var prodKey  = itemdet.PRODUCT_KEY;
		var objId    = itemdet.OBJECT_ID;
		var itemIndex   = oEvent.getSource().sId.split('-')[6];
		var productKey = jQuery.sap.encodeURL(itemdet.PRODUCT_KEY);
		var numberInt = itemdet.NUMBER_INT;
		var sapOriginSAP = bindingContext.getModel().getProperty(bindingContext.getPath()).SAP__Origin;

		
		// check if product key is blank
		//if (prodKey.length !== 0) {
			this.oRouter.navTo("itemDetail", {
				objectid: objId,
				numberint: numberInt,
				itemIndex: itemIndex,
				sapOrigin: sapOriginSAP
			}, true);
		//};
	},

	/**
	 * @private [ getApprovalDetails Get Details about the cart approver ]
	 */
	getApprovalDetails : function(objectId) {
		
		var onRequestSuccess = function(oData, oResponse) {
			var i;
			for(i=0;i<oData.results.length;i++)
			{
				if(oData.results[i].AGENT_ID == "" && oData.results[i].PROCESSOR_NAMES_CONC != "")
				{

					var appName = oData.results[i].PROCESSOR_NAMES_CONC.split(";");
					var appId = oData.results[i].APR_AGENT_ID.slice(1).split(';');

					var j;
					for(j=0;j<appName.length;j++)
					{
						var appClone = new Object();
						jQuery.extend(appClone, oData.results[i]);
						appClone.PROCESSOR_NAMES_CONC = appName[j];
						appClone.AGENT_ID = appName[j];
						appClone.APPROVER_ID = appId[j];
							if(j==0)
								oData.results.splice(i,1,appClone);
							else
								oData.results.splice(i,0,appClone);
						
					}
				}
				else if(oData.results[i].AGENT_ID != ""){
					var appAgntId = oData.results[i].APR_AGENT_ID.slice(1).split(';');
					if(appAgntId.length === 1 && appAgntId[0] === oData.results[i].AGENT_ID)
						oData.results[i].APPROVER_ID = oData.results[i].AGENT_ID;
				}				
				
			}			
			this.oApprovalModel = new sap.ui.model.json.JSONModel(oData);
			this.getView().byId("Approval_list").setModel(this.oApprovalModel, "peopleApproverNotes");
			this.getView().byId("approvalTab").setCount(oData.results.length);
			//this.AgentId = this.oApprovalModel.oData.results[0].AGENT_ID;
			
			//all data is fetched, close the busy dialog
			this.busyDialog.close();
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		oDataModel.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectId + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartApprovalNavigation",
						null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},
	
	/**
	 * @private [ parseApprovalNotes Parse the approval notes and bind it to the icon tab ] 
	 */
	parseApprovalNotes : function() {
		
		var headerModel     = this.getView().byId("header").getModel("ShoppingCartHeader");
		var headerModelData = headerModel.getData();
		
		//Approval Note String
		var notesStr = headerModelData.APRV_NOTE;
		var parts = notesStr.split("________");
		var notes = [];
		
		var notesModel = new sap.ui.model.json.JSONModel();
		
		//parse the note String to fetch sender, timestamp and text information
		for ( var i = 0; i < parts.length; i++) {
			var part = parts[i];
			if (part.trim() === "") {
				continue;
			}
			var note = {};
			
			var userTimestampPart    = part.split("(")[1].split(')')[0].split(" ");
			var noteText             = part.slice(0).split("")[0]!=="\n" ? part.slice(0).split("(")[0] : part.slice(1).split("(")[0];
			
			note.sender    = userTimestampPart[0]!=="" ? userTimestampPart[0] : userTimestampPart[1];
			note.timestamp = userTimestampPart.slice(2).join(" ");
			note.noteText  = noteText;
			notes.push(note);
		}
		
		//if there is no notes attached to the cart, we display a message only
		//else we display the note.
		this.getView().byId("Notes").setModel(notesModel,"ApprovalNotes");
		if (notesStr.length === 0) {		
			this.getView().byId("peopleNote").setVisible(false);
		} else {
			var notesData = { notes: notes};
			notesModel.setData(notesData);
			this.getView().byId("peopleNote").setVisible(true);
			this.getView().byId("peopleNote").setCount(notes.length);
		}
	},
	
	/*
	 * FIXME: Currently we display a dummy picture, there is no service attribute 
	 * for the contact image. Once that is received, we can change the below
	 * code accordingly
	 */
	displayContactPicture : function(sValue) {
		return jQuery.sap.getModulePath("ui.s2p.srm.sc.track")+ "/img/" + "person_placeholder.png";
	},

	/**
	 * @private [ openBusinessCart Open Business Card popup on click of a agent id ]
	 */
	openBusinessCard : function(oEvent) {
		var oView = this.getView();
		
		var onRequestSuccess = function(oData, oResponse) {
			var results  = oData.results[0];
			var fullName = results.LastName;
			
			if (results.FirstName) {
				if (fullName) {
					fullName = results.FirstName + " "+ fullName;
				} else {
					fullName = results.FirstName;
				}
			}
			
			if (!fullName) {
				fullName = "";
			}
			
			var telephone = results.TELEPHONE ? results.TELEPHONE: "";
			var emailSubjectString = results.INHOUSE_MAIL;
			var companyName = results.COMPANY_NAME;
			var oEmployee = {
				name             : fullName,
				imgurl           : this.displayContactPicture(),
				department       : "",
				contactmobile    : "",
				contactphone     : telephone,
				companyname      : companyName,
				contactemail 	 : emailSubjectString,
				contactemailsubj : "",
				companyaddress   : ""
			};

			
			Object.keys(oEmployee).forEach(function(key){
					if(oEmployee[key]){
						var oControl = oView.byId("Approval_list");
						// call 'Business Card' reuse component
						var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmployee);
						oEmployeeLaunch.openBy(oControl);
						return ;
					}
				});
		};
		var str = oEvent.getSource().getBinding("sender").getContext().getPath();
		var res = str.split("/");
		var index = res[2];
		var oDataModel = this.oApplicationFacade.getODataModel("USERS_LIST");
		oDataModel.read("ALL_USERS_LIST", null,	[ "$filter=UserName eq '" + this.oApprovalModel.oData.results[index].APPROVER_ID + "'" ], false,
						jQuery.proxy(onRequestSuccess, this),jQuery.proxy(this.onRequestFailed, this));
	},
	
	/**
	 * @private [ onRequestFailed Show error message when service request fails ]
	 */
	onRequestFailed : function(oError) {
		//an error has occurred, close the busy dialog
		this.busyDialog.close();
		
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type : sap.ca.ui.message.Type.ERROR,
			message : oError.message,
			details : oError.response.body
		});
	}




});

//sap.ushell.ui.footerbar.JamShareButton.prototype.setEnabled = function (bEnabled) {
//
//	sap.m.Button.prototype.setEnabled.call(this, bEnabled);
//
//	};


},
	"ui/s2p/srm/sc/track/view/S3.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\txmlns:sap.ui.layout="sap.ui.layout" xmlns:form="sap.ui.layout.form"\n\tcontrollerName="ui.s2p.srm.sc.track.view.S3">\n\t<Page id="detailPage" class="sapUiFioriObjectPage" showNavButton="{device>/showNavButton}" navButtonPress="_navBack">\n\t\t<content>\n\t\t\t<ObjectHeader id="header"\n\t\t\t\ttitle="{parts:[{path:\'i18n>CART\'},{path:\'ShoppingCartHeader>/OBJECT_ID\'}]}"\n\t\t\t\tnumber="{path:\'ShoppingCartHeader>/TOTAL_VALUE\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}" numberUnit="{ShoppingCartHeader>/CURRENCY}"\n\t\t\t\tintroActive="false" titleActive="false" icon="{sscModel>status_icon}"\n\t\t\t\ticonActive="false">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute\n\t\t\t\t\t\ttext="{parts:[{path:\'i18n>CREATED_ON\'},{path:\'ShoppingCartHeader>/CREATED_AT\', type:\'sap.ui.model.type.Date\',formatOptions: {source:{pattern:\'yyyyMMddhhmmss\'}, style:\'medium\'}}]}"\n\t\t\t\t\t\tactive="false"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t\t<firstStatus>\n\t\t\t\t\t<ObjectStatus text="{ShoppingCartHeader>/HEADER_STATUS_DESCR}"\n\t\t\t\t\t\tstate="{path:\'ShoppingCartHeader>/HEADER_STATUS_ID\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatStatus\'}"></ObjectStatus>\n\t\t\t\t</firstStatus>\n\t\t\t</ObjectHeader>\n\t\t\t<IconTabBar id="icontabBar" expandable="false">\n\t\t\t\t<items>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://hint" iconColor="Default"\n\t\t\t\t\t\tkey="Information" id="info" showAll="false">\n\t\t\t\t\t\t<content>\n\t\t\t\t\t\t\t<form:SimpleForm id="myForm1" minWidth="1024"\n\t\t\t\t\t\t\t\teditable="false">\n\t\t\t\t\t\t\t\t<form:content>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>SHOPPING_CART_NO}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text text="{ShoppingCartInfo>/OBJECT_ID}" maxLines="0"\n\t\t\t\t\t\t\t\t\t\tid="cartid">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>COST_ASSIGNMENT}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text text="{ShoppingCartInfo>/ACC_ASS_STR}" maxLines="0"\n\t\t\t\t\t\t\t\t\t\tid="account">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>DELIVERY_ADDRESS}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<VBox direction="Column" id="addressvbox">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t<Text id="SCC_ADDRESS1"\n\t\t\t\t\t\t\t\t\t\t\t\tvisible="{path:\'ShoppingCartInfo>/STREET\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showVisibilityAddress1\'}"\n\t\t\t\t\t\t\t\t\t\t\t\ttext="{path:\'ShoppingCartInfo>/STREET\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAddress1\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t<Text id="SCC_ADDRESS2"\n\t\t\t\t\t\t\t\t\t\t\t\tvisible="{parts : [{path:\'ShoppingCartInfo>/CITY\'},{path:\'ShoppingCartInfo>/DISTRICT\'},{path:\'ShoppingCartInfo>/POSTL_COD1\'},{path:\'ShoppingCartInfo>/COUNTRY_TEXT\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.showVisibilityAddress2\'}"\n\t\t\t\t\t\t\t\t\t\t\t\ttext="{parts : [{path:\'ShoppingCartInfo>/CITY\'},{path:\'ShoppingCartInfo>/DISTRICT\'},{path:\'ShoppingCartInfo>/POSTL_COD1\'},{path:\'ShoppingCartInfo>/COUNTRY_TEXT\'}],formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAddress2\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>REQUESTED_DELIVERY_DATE}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text id="deliv_Date" maxLines="0">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>CURRENT_APPROVER}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text maxLines="0" id="approver" text="{ShoppingCartInfo>/APPR_STR}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\n\t\t\t\t\t\t\t\t\t<!-- Extension point added for more information -->\n\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extMoreInfo"></core:ExtensionPoint>\n\t\t\t\t\t\t\t\t</form:content>\n\t\t\t\t\t\t\t</form:SimpleForm>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://notes" iconColor="Default"\n\t\t\t\t\t\tshowAll="false" id="peopleNote" visible="false">\n\t\t\t\t\t\t<content id="NotesContent">\n\t\t\t\t\t\t\t<List id="Notes" items="{ApprovalNotes>/notes}" mode="SingleSelectMaster"\n\t\t\t\t\t\t\t\tshow-separator="None">\n\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t<FeedListItem id="notelist" sender="{ApprovalNotes>sender}"\n\t\t\t\t\t\t\t\t\t\tsenderActive="false" senderPress="openBusinessCard" timestamp="{ApprovalNotes>timestamp}"\n\t\t\t\t\t\t\t\t\t\ttext="{ApprovalNotes>noteText}">\n\t\t\t\t\t\t\t\t\t</FeedListItem>\n\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t</List>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://group" iconColor="Default"\n\t\t\t\t\t\tshowAll="false" id="approvalTab">\n\t\t\t\t\t\t<content id="Approval">\n\t\t\t\t\t\t\t<List id="Approval_list" items="{peopleApproverNotes>/results}"\n\t\t\t\t\t\t\t\tmode="SingleSelectMaster" show-separator="None">\n\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t<FeedListItem sender="{path:\'peopleApproverNotes>PROCESSOR_NAMES_CONC\'}"\n\t\t\t\t\t\t\t\t\t\ticon="{path:\'peopleApproverNotes>APPROVER_ID\',formatter:\'.displayContactPicture\'}"\n\t\t\t\t\t\t\t\t\t\ticon-active="false" iconPress="openBusinessCard"\n\t\t\t\t\t\t\t\t\t\tsender-active="true" senderPress="openBusinessCard"\n\t\t\t\t\t\t\t\t\t\ttext="{peopleApproverNotes>DECISION_SET_DESCR}">\n\t\t\t\t\t\t\t\t\t</FeedListItem>\n\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t</List>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t</items>\n\t\t\t</IconTabBar>\n\t\t\t<Table id="itemList" items="{ShoppingCartItems>/results}">\n\t\t\t\t<columns>\n\t\t\t\t\t<Column minScreenWidth="tablet" demandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>DESCRIPTION}" textAlign="Left" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column width="20%" hAlign="Right" minScreenWidth="tablet"\n\t\t\t\t\t\tdemandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>QUANTITY_LBL}" textAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column width="20%" hAlign="Right" minScreenWidth="tablet"\n\t\t\t\t\t\tdemandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label id="SCC_SUB_TOTAL" text="{i18n>SUB_TOTAL}"\n\t\t\t\t\t\t\t\ttextAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t</columns>\n\t\t\t\t<items>\n\t\t\t\t\t<ColumnListItem press="onDetailListItemPressed"\n\t\t\t\t\t\ttype="Navigation" unread="true" counter="0" id="itemListDetail">\n\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t<ObjectIdentifier title="{ShoppingCartItems>ITEM_DESC}"></ObjectIdentifier>\n\t\t\t\t\t\t\t<ObjectNumber\n\t\t\t\t\t\t\t\tnumber="{path:\'ShoppingCartItems>QUANTITY\', type:\'sap.ui.model.type.Float\', formatOptions:{maxFractionDigits:0}}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>UNIT}"></ObjectNumber>\n\t\t\t\t\t\t\t<ObjectNumber\n\t\t\t\t\t\t\t\tnumber="{parts:[{path:\'ShoppingCartItems>NET_VALUE\'}, {path:\'ShoppingCartItems>CURRENCY\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>CURRENCY}"></ObjectNumber>\n\t\t\t\t\t\t</cells>\n\t\t\t\t\t</ColumnListItem>\n\t\t\t\t</items>\n\t\t\t</Table>\n\t\t</content>\n\t</Page>\n</core:View>'
}});
