jQuery.sap.registerPreloadedModules({
	"name": "ui/s2p/srm/sc/track/Component-preload",
	"version": "2.0",
	"modules": {
		"ui/s2p/srm/sc/track/Component.js": function() {
			/*
			 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
			 */
			jQuery.sap.declare("ui.s2p.srm.sc.track.Component");
			jQuery.sap.require("ui.s2p.srm.sc.track.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
			sap.ca.scfld.md.ComponentBase.extend("ui.s2p.srm.sc.track.Component", {
				metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
					"name": "Master Detail Sample",
					"version": "1.0.0",
					"library": "ui.s2p.srm.sc.track",
					"includes": [],
					"dependencies": {
						"libs": ["sap.m", "sap.me"],
						"components": []
					},
					"config": {
						"titleResource": "DISPLAY_NAME_TRACK",
						"resourceBundle": "i18n/i18n.properties",
						"icon": "sap-icon://Fiori2/F0406",
						"favIcon": "./resources/sap/ca/ui/themes/base/img/favicon/Track_Shopping_Cart.ico",
						"homeScreenIconPhone": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/57_iPhone_Desktop_Launch.png",
						"homeScreenIconPhone@2": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/114_iPhone-Retina_Web_Clip.png",
						"homeScreenIconTablet": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/72_iPad_Desktop_Launch.png",
						"homeScreenIconTablet@2": "./resources/sap/ca/ui/themes/base/img/launchicon/Track_Shopping_Cart/144_iPad_Retina_Web_Clip.png"
					},
					"masterPageRoutes": {
						"master": {
							"pattern": "",
							"view": "ui.s2p.srm.sc.track.view.S2"
						}
					},
					"detailPageRoutes": {
						"detail": {
							"pattern": "detail/{contextPath}",
							"view": "ui.s2p.srm.sc.track.view.S3"
						},
						"itemDetail": {
							"pattern": "itemDetail/{objectid}/{numberint}/{itemIndex}/{sapOrigin}",
							"view": "ui.s2p.srm.sc.track.view.ItemDetail",
						}
					}
				}),
				createContent: function() {
					var v = {
						component: this
					};
					return sap.ui.view({
						viewName: "ui.s2p.srm.sc.track.Main",
						type: sap.ui.core.mvc.ViewType.XML,
						viewData: v
					})
				}
			})
		},
		"ui/s2p/srm/sc/track/Configuration.js": function() {
			jQuery.sap.declare("ui.s2p.srm.sc.track.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
			jQuery.sap.require("sap.ca.scfld.md.app.Application");
			sap.ca.scfld.md.ConfigurationBase.extend("ui.s2p.srm.sc.track.Configuration", {
				aServiceList: [{
					name: "ORDERTRACK_SERVICE",
					masterCollection: "ordertrackCollection",
					serviceUrl: "/sap/opu/odata/srmnxp/ORDERTRACK_SERVICE;mo/",
					isDefault: true,
					mockedDataSource: "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
				}, {
					name: "SRMSHOPPING_CART",
					masterCollection: "SRMShoppingCartCollection",
					serviceUrl: "/sap/opu/odata/srmnxp/SRMSHOPPING_CART;mo/",
					isDefault: false,
					mockedDataSource: "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
				}, {
					name: "USERS_LIST",
					masterCollection: "SRMShoppingCartCollection",
					serviceUrl: "/sap/opu/odata/SRMNXP/USERS_LIST/",
					isDefault: false,
					mockedDataSource: "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
				}, {
					name: "UTIL",
					masterCollection: "UOMCollection",
					serviceUrl: "/sap/opu/odata/SRMNXP/UTIL/",
					isDefault: false,
					mockedDataSource: "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
				}, {
					name: "CARTAPPROVAL",
					masterCollection: "WorkflowTaskCollection",
					serviceUrl: "/sap/opu/odata/GBSRM/CARTAPPROVAL;v=2;mo/",
					isDefault: false,
					mockedDataSource: "/ui.s2p.srm.sc.approve/model/metadata.xml"
				}, {
					name: "ACC_ASSIGN_CATEGORY",
					masterCollection: "ACC_ASSIGN_CATEGORYCollection",
					serviceUrl: "/sap/opu/odata/srmnxp/ACC_ASSIGN_CATEGORY/",
					isDefault: false,
					mockedDataSource: "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
				}],
				getServiceList: function() {
					return this.aServiceList
				}
			})
		},
		"ui/s2p/srm/sc/track/Main.controller.js": function() {
			sap.ui.controller("ui.s2p.srm.sc.track.Main", {
				onInit: function() {
					jQuery.sap.require("sap.ca.scfld.md.Startup");
					sap.ca.scfld.md.Startup.init('ui.s2p.srm.sc.track', this)
				},
				onExit: function() {}
			})
		},
		"ui/s2p/srm/sc/track/Main.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n\txmlns:core="sap.ui.core"\n\txmlns="sap.m"\n\tcontrollerName="ui.s2p.srm.sc.track.Main"\n\tdisplayBlock="true"\n\theight="100%">\n\t<NavContainer\n\t\tid="fioriContent"\n\t\tshowHeader="false">\n\t</NavContainer>\n</core:View>',
		"ui/s2p/srm/sc/track/util/Formatter.js": function() {
			jQuery.sap.declare("ui.s2p.srm.sc.track.util.Formatter");
			jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
			jQuery.sap.require("sap.ui.core.Element");
			jQuery.sap.require("sap.ui.core.format.NumberFormat");
			jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
			jQuery.sap.require("sap.ca.ui.model.format.FormattingLibrary");
			ui.s2p.srm.sc.track.util.Formatter = {
				showVisibilityAddress1: function(o) {
					if (o.length != 0) {
						return true
					} else {
						return false
					}
				},
				showVisibilityAddress2: function(c, d, p, a) {
					if (c.length != 0 || d.length != 0 || p.length != 0 || a.length != 0) {
						return true
					} else {
						return false
					}
				},
				formatStatus: function(s) {
					var r = sap.ui.core.ValueState.None;
					switch (s) {
						case "I1009":
							r = sap.ui.core.ValueState.None;
							break;
						case "I1016":
							r = sap.ui.core.ValueState.Error;
							break;
						case "I1129":
							r = sap.ui.core.ValueState.Success;
							break;
						case "I1015":
							r = sap.ui.core.ValueState.Warning;
							break;
						default:
							r = sap.ui.core.ValueState.None;
							break
					}
					return r
				},
				formatAddress1: function(o) {
					if (o.length != 0) {
						return o
					}
				},
				formatAddress2: function(c, d, p, a) {
					var b = "";
					if (c.length !== 0) {
						b = c
					}
					if (b.length !== 0) {
						b += "," + d + " " + p
					}
					if (b.length !== 0) {
						b += ", " + a
					}
					return b
				},
				formatPreferredItem: function(a) {
					if (a === "01") {
						var A = sap.ca.scfld.md.app.Application.getImpl();
						var b = A.getResourceBundle();
						return b.getText("PREFERRED_ITEM")
					} else {
						return ""
					}
				},
				formatCartNumber: function(c) {
					var a = sap.ca.scfld.md.app.Application.getImpl();
					var b = a.getResourceBundle();
					return b.getText("CART_NUMBER_EX", [c])
				},
				formatItemCount: function(i) {
					var a = sap.ca.scfld.md.app.Application.getImpl();
					var b = a.getResourceBundle();
					return b.getText("ITEMS_QTY_EX", [i])
				},
				formatMaxDeliveryDate: function(a) {
					var c = null;
					for (var i = 0; i < a.length; i++) {
						if (a[i].DELIV_DATE > c) {
							c = a[i].DELIV_DATE
						}
					}
					var d = new sap.ui.model.type.Date();
					d.setFormatOptions("medium");
					return d.formatValue(c, "string")
				},
				formatDeliveryDate: function(i) {
					if (i.PRODUCT_TYPE === '02') {
						var D = sap.ca.ui.model.format.DateFormat.getDateInstance();
						var s = D.format(i.VPER_START, true);
						var e = D.format(i.VPER_END, true);
						var d;
						if (i.VPER_TYPE === 'AT') {
							return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ON", [s])
						} else if (i.VPER_TYPE === 'FR') {
							return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("FROM", [s])
						} else if (i.VPER_TYPE === 'BE') {
							return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("TO", [s, e])
						}
					} else if (i.PRODUCT_TYPE === '01') {
						var D = sap.ca.ui.model.format.DateFormat.getDateInstance();
						var a = D.format(i.DELIV_DATE, true);
						return a
					}
				},
				formatItemAndCount: function(I, t) {
					var a = sap.ca.scfld.md.app.Application.getImpl();
					var b = a.getResourceBundle();
					return b.getText("ITEM_AND_COUNT_EX", [I, t])
				},
				formatPrice: function(v, c, p, u) {
					var f = sap.ca.ui.model.format.AmountFormat.getInstance({
						style: "standard",
						decimals: "2"
					});
					return f.format(v) + ' ' + c + ' ' + '/' + p + ' ' + u
				},
				formatPriceItem: function(v) {
					var f = sap.ca.ui.model.format.AmountFormat.getInstance({
						style: "standard",
						decimals: "2"
					});
					return f.format(v)
				},
				showElementOnUi: function(o) {
					if (o == '') {
						return false
					} else {
						return true
					}
				},
				formatCategory: function(v, a) {
					return v + ' ' + " (" + a + ")"
				},
				formatDesc: function(v) {
					return " (" + v + ")"
				},
				formatACCCategory: function(a) {
					switch (a) {
						case ('CC'):
							return ('Cost Center')
					}
				},
				formatCatName: function(o) {
					if (o == "02") {
						return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_NAME")
					} else {
						return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_NAME")
					}
				},
				formatCatType: function(o) {
					if (o == "02") {
						return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_CATEGORY")
					} else {
						return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_CATEGORY")
					}
				},
				valueVisibilityCheck: function(o) {
					if (o == 0) return false;
					else return true
				},
				setNoteText: function() {
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('NOTES')
				},
				showSupplierNotes: function(n) {
					if (n == 'ITXT') return true;
					else return false
				},
				formatAttachmentIcon: function(m) {
					var f = sap.ca.ui.model.format.FormattingLibrary.formatAttachmentIcon(m);
					return f
				},
				formatAttachmentSize: function(b) {
					var f = sap.ca.ui.model.format.FileSizeFormat.getInstance();
					var r = f.format(b);
					return r;
					return '12 kb'
				},
				showAttachment: function(u) {
					var m = u;
					sap.m.URLHelper.redirect(m, true)
				},
				setAttachmentText: function() {
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ATTACHMENTS')
				},
				arrayVisibilityCheck: function(o) {
					if (o.length == 0) return false;
					else return true
				},
				setAccountAssignmentText: function() {
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ACCOUNT_ASSIGNMENT')
				},
				formatDistributionPercentage: function(v) {
					var p = "%";
					if (parseFloat(v)) {
						v = v.split('.').join(',');
						v += p
					}
					return v
				},
				setApproverText: function() {
					return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('APPR_CHAIN')
				},
				showDeliveryAddress: function(a, b, c, d) {
					return (a + "," + b + " " + c + " " + d)
				},
				showDeliveryDateHeader: function(d, f, t) {
					var D = sap.ca.ui.model.format.DateFormat.getDateInstance();
					if (d) {
						var m = D.format(d, true);
						return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_ON', [m])
					} else {
						var a = D.format(f, true);
						var b = D.format(t, true);
						return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_REQUIRED', [a, b])
					}
				},
			}
		},
		"ui/s2p/srm/sc/track/util/ItemList.js": function() {
			jQuery.sap.declare("ui.s2p.srm.sc.track.util.ItemList");
			ui.s2p.srm.sc.track.util.ItemList = {};
			ui.s2p.srm.sc.track.util.ItemList.item = (function() {
				var a = [];
				return {
					add: function(b) {
						this.clear();
						for (var i = 0; i < b.length; i++) {
							a.push({
								objectid: b[i].OBJECT_ID,
								item: b[i].NUMBER_INT,
								index: i
							})
						}
					},
					each: function(c) {
						for (var i = 0; i < a.length; i++) {
							c(a[i].item)
						}
					},
					length: function() {
						return a.length
					},
					clear: function() {
						a = []
					},
					getIndex: function(b) {
						for (var i = 0; i < a.length; i++) {
							if (a[i].item === b) return i
						}
						return -1
					},
					getItemAtIndex: function(i) {
						return a[i].objectid
					},
					getSCItemNumber: function(i) {
						return a[i].item
					}
				}
			})()
		},
		"ui/s2p/srm/sc/track/view/ItemDetail.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
			jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
			jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
			jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
			jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
			sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.track.view.ItemDetail", {
				onInit: function() {
					sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
					this.busyDialog = new sap.m.BusyDialog({
						customIcon: sap.ca.ui.images.images.Flower
					});
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "itemDetail") {
							this.objectid = e.getParameter("arguments").objectid;
							this.numberInt = e.getParameter("arguments").numberint;
							this.sapOrigin = e.getParameter("arguments").sapOrigin;
							this.initHeaderFooter(this.numberInt);
							this.readContent(this.objectid, this.numberInt)
						}
					}, this);
					var o = function(D, r) {
						this.accCatObj = D
					};
					if (this.accCatObj == undefined) {
						var d = this.oApplicationFacade.getODataModel("ACC_ASSIGN_CATEGORY");
						d.read("AccountAssignmentCategoryCollection", null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailedAccCat,
							this))
					}
					var a = function(D, r) {
						this.UOMObj = D
					};
					if (this.UOMObj == undefined) {
						var d = this.oApplicationFacade.getODataModel("UTIL");
						d.read("UOMCollection", null, null, true, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailedAccCat, this))
					}
				},
				readContent: function(o, n) {
					var a = function(e) {
						this.itemObj = e;
						this.bindView()
					};
					var b = this.oApplicationFacade.getODataModel().sServiceUrl;
					this.oApplicationFacade.getODataModel().sServiceUrl = b.split(";")[0] + ";mo";
					this.busyDialog.open();
					var N = n,
						c = o;
					var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					var B = new Array();
					var u = "SRMShoppingCartItemDataCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')";
					B.push(O.createBatchOperation(u, "GET"));
					u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')";
					u = u + "/ItemAccountAssignmentNavigation";
					B.push(O.createBatchOperation(u, "GET"));
					u = "ShippingAddressCollection(SAP__Origin='" + this.sapOrigin + "',ItemNumber='" + N + "',ShoppingCartID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')";
					B.push(O.createBatchOperation(u, "GET"));
					u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')";
					u = u + '/ItemAttachmentNavigation';
					B.push(O.createBatchOperation(u, "GET"));
					u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')";
					u = u + '/ItemApproverNavigation';
					B.push(O.createBatchOperation(u, "GET"));
					u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')";
					u = u + '/SourceofSupplyNavigation';
					B.push(O.createBatchOperation(u, "GET"));
					O.addBatchReadOperations(B);
					O.submitBatch(jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));
					var d = function(e, r) {
						this.bindNotes(e, r)
					};
					if (this.extHook3) {
						this.extHook3()
					};
					var D = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					D.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + c +
						"',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartNotesNavigation?$filter=ITM_NUMBER_INT eq '" + N + "'", null, null, true,
						jQuery.proxy(d, this), jQuery.proxy(this.onRequestFailed, this))
				},
				bindNotes: function(d) {
					var i = d.results;
					var a;
					var m = new sap.ui.model.json.JSONModel({
						'notesdata': i
					});
					this.getView().setModel(m, "notes")
				},
				bindView: function() {
					if (this.itemObj.__batchResponses[0].data) {
						var a = this.itemObj.__batchResponses[0].data;
						if (this.UOMObj) {
							var u = this.UOMObj.results;
							for (var i = 0; i < u.length; i++) {
								if (a.UNIT == u[i].COMMERCIAL_UNIT) a.UNIT_TEXT = u[i].UOM_TEXT
							}
						}
						var d = ui.s2p.srm.sc.track.util.Formatter.formatDeliveryDate(a);
						this.getView().byId("deliveryDate").setText(d)
					}
					if (this.itemObj.__batchResponses[1].data) {
						var b = this.itemObj.__batchResponses[1].data.results;
						var A = this.accCatObj.results;
						for (var i = 0; i < b.length; i++) {
							for (var j = 0; j < A.length; j++) {
								if (b[i].ACC_CAT == A[j].ACC_ASSIGN_CAT_CODE) {
									b[i].acc_cat_ui = A[j].ACC_ASSIGN_CAT_DESC;
									b[i].acc_cat_val_ui = b[i][A[j].ACC_ASSIGN_FIELD];
									var c;
									switch (A[j].ACC_ASSIGN_FIELD) {
										case 'COST_CTR':
											c = "CC";
											break;
										case 'SD_DOC':
											c = "SO";
											break;
										case 'NETWORK':
											c = "NET";
											break;
										case 'ORDER_NO':
											c = "OR";
											break;
										case 'WBS_ELEM_E':
											c = "WBS";
											break;
										case 'ASSET_NO':
											c = "AS";
											break;
										case 'G_L_ACCT':
											c = "GL";
											break;
										case 'ACTIVITY':
											c = "ACTIVITY";
											break;
										case 'FUNC_AREA':
											c = "FAREA";
											break;
										case 'FUND':
											c = "FUND";
											break;
										case 'GRANT_NBR':
											c = "GRANT";
											break;
										default:
											break
									}
									b[i].acc_cat_desc_ui = b[i][c + "_DESCRIPTION"]
								}
							}
						}
					}
					if (this.itemObj.__batchResponses[2].data) {
						var e = this.itemObj.__batchResponses[2].data
					}
					if (this.itemObj.__batchResponses[3].data) {
						var f = this.itemObj.__batchResponses[3].data.results;
						f.splice(0, 1)
					}
					if (this.itemObj.__batchResponses[4].data) {
						var g = this.itemObj.__batchResponses[4].data.results;
						var i;
						for (i = 0; i < g.length; i++) {
							if (g[i].AGENT_ID == "" && g[i].PROCESSOR_NAMES_CONC != "") {
								var h = g[i].PROCESSOR_NAMES_CONC.split(";");
								var k = g[i].APR_AGENT_ID.slice(1).split(';');
								var j;
								for (j = 0; j < h.length; j++) {
									var l = new Object();
									jQuery.extend(l, g[i]);
									l.PROCESSOR_NAMES_CONC = h[j];
									l.AGENT_ID = h[j];
									l.APPROVER_ID = k[j];
									if (j == 0) g.splice(i, 1, l);
									else g.splice(i, 0, l)
								}
							} else if (g[i].AGENT_ID !== "") {
								var m = g[i].APR_AGENT_ID.slice(1).split(';');
								if (m.length === 1 && m[0] === g[i].AGENT_ID) g[i].APPROVER_ID = g[i].AGENT_ID
							}
						}
					}
					if (this.itemObj.__batchResponses[5].data.results) {
						var n = this.itemObj.__batchResponses[5].data.results;
						var o;
						for (var i = 0; i < n.length; i++) {
							if (n[i].Supplierstatus == 'A') {
								o = n[i];
								break
							}
						}
					}
					var M = new sap.ui.model.json.JSONModel({
						'itemDetail': a,
						'shipAddr': e,
						'account': b,
						'attach': f,
						'approvers': g,
						'supplier': o
					});
					this.getView().setModel(M, "itemDetailData");
					this.busyDialog.close()
				},
				onAttachment: function(e) {
					var i = parseInt(e.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
					var U = this.itemObj.__batchResponses[3].data.results[i].__metadata.media_src;
					ui.s2p.srm.sc.track.util.Formatter.showAttachment(U)
				},
				onApproverPress: function(e) {
					if (e.getSource().getBindingContext('itemDetailData')) {
						var i = parseInt(e.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
						var a = this.itemObj.__batchResponses[4].data.results;
						var s = e.getParameters().id;
						var c = this.getView().byId(s);
						this.handleUserNameClick(c, a[i].APPROVER_ID)
					}
				},
				handleUserNameClick: function(c, e) {
					var p = this.formatEmployee(e);
					var o = function(D, r) {
						var E = {
							imgurl: p,
							name: D.results[0].FullName,
							department: "",
							contactmobile: D.results[0].MobilePhone,
							contactphone: D.results[0].WorkPhone,
							companyname: D.results[0].CompanyName,
							contactemail: D.results[0].EMail,
							contactemailsubj: "",
							companyaddress: D.results[0].AddressString
						};
						var b = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
						b.openBy(c)
					};
					var a = this.oApplicationFacade.getODataModel("CARTAPPROVAL").sServiceUrl;
					var d = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
					d.read("UserDetailsCollection", null, ["$filter=UserID eq '" + e + "' and SAP__Origin eq '" + this.sapOrigin + "'"], false, jQuery.proxy(
						o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				formatEmployee: function(A) {
					var v = "";
					var s = this.sapOrigin.replace(/'/g, "");
					var m = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
					var S = function(d, r) {
						if (r.body.length === 0) {
							v = jQuery.sap.getModulePath("ui.s2p.srm.sc.track") + "/img/" + "person_placeholder.png"
						} else {
							v = r.requestUri
						}
						m.sServiceUrl = m.sServiceUrl.split(";")[0] + ";v=2;mo"
					};
					var e = function(E) {
						v = jQuery.sap.getModulePath("ui.s2p.srm.sc.track") + "/img/" + "person_placeholder.png";
						m.sServiceUrl = m.sServiceUrl.split(";")[0] + ";v=2;mo"
					};
					m.sServiceUrl = m.sServiceUrl.split(";")[0] + ";v=2;o=" + s;
					m.read("UserDetailsCollection('" + A + "')/$value", null, null, false, jQuery.proxy(S, this), jQuery.proxy(e, this));
					return v
				},
				initHeaderFooter: function(o) {
					var t = this;
					this.oHeaderFooterOptions = {
						onBack: function(e) {
							var p = "ordertrackCollection(SAP__Origin='" + t.sapOrigin + "',OBJECT_ID='" + t.objectid + "')";
							t.oRouter.navTo("detail", {
								contextPath: p
							}, true)
						},
						oUpDownOptions: {
							sI18NDetailTitle: "ITEM_AND_COUNT_EX",
							iPosition: 0,
							iCount: 0,
							fSetPosition: function(n) {
								if ((n >= 0) && (n < ui.s2p.srm.sc.track.util.ItemList.item.length())) {
									t.objectid = ui.s2p.srm.sc.track.util.ItemList.item.getItemAtIndex(n);
									t.numberInt = ui.s2p.srm.sc.track.util.ItemList.item.getSCItemNumber(n);
									t.oRouter.navTo("itemDetail", {
										objectid: t.objectid,
										numberint: t.numberInt,
										itemIndex: n,
										sapOrigin: t.sapOrigin
									}, true)
								}
							}
						}
					};
					this.oHeaderFooterOptions.oUpDownOptions.iPosition = ui.s2p.srm.sc.track.util.ItemList.item.getIndex(t.numberInt);
					this.oHeaderFooterOptions.oUpDownOptions.iCount = ui.s2p.srm.sc.track.util.ItemList.item.length();
					this.setHeaderFooterOptions(this.oHeaderFooterOptions)
				},
			})
		},
		"ui/s2p/srm/sc/track/view/ItemDetail.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m" xmlns:mvc="sap.ui.core.mvc"\n       xmlns:sap.me="sap.me" xmlns:sap.ui.layout.form="sap.ui.layout.form"\n       xmlns:sap.ui.layout="sap.ui.layout" xmlns:sap.ui.core.mvc="sap.ui.core.mvc"\n       xmlns:sap.ui.core="sap.ui.core" controllerName="ui.s2p.srm.sc.track.view.ItemDetail">\n       <Page id="itemDetailPage" navButtonPress="_navBack" showNavButton="true"\n              class="sapUiFioriObjectPage">\n              <content>\n                     <ObjectHeader id="objectheader1"\n                     title="{itemDetailData>/itemDetail/DESCRIPTION}"\n                          \n                           number = "{path:\'itemDetailData>/itemDetail/PRICE\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}"\n                           numberUnit="{itemDetailData>/itemDetail/CURRENCY}" titleActive="false">\n                           <firstStatus>\n                                  <ObjectStatus id="approveRejectIcon"></ObjectStatus>\n                           </firstStatus>\n                           <attributes>\n                                  <ObjectAttribute\n                                         text="{parts:[{path:\'itemDetailData>/itemDetail/QUANTITY\'},{path:\'itemDetailData>/itemDetail/UNIT_TEXT\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatQuantity\'}"></ObjectAttribute>\n                                  <ObjectAttribute                                         \n                                         text="{parts:[{path:\'itemDetailData>/itemDetail/PRICE\'},{path:\'itemDetailData>/itemDetail/CURRENCY\'},{path:\'itemDetailData>/itemDetail/PRICE_UNIT\'},{path:\'itemDetailData>/itemDetail/UNIT_TEXT\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPrice\'}"                                         \n                                         ></ObjectAttribute>                                 \n                           </attributes>\n                           \n                     </ObjectHeader>\n\n                     <sap.ui.layout.form:SimpleForm id="myForm1"\n                           minWidth="1024" editable="false">\n                            <sap.ui.layout.form:content>\n                                  <sap.ui.core:Title text="{i18n>ITEM_HEADER}"></sap.ui.core:Title>\n\n                                  <Label id="categoryName"\n                                         text="{path:\'itemDetailData>/itemDetail/PRODUCT_TYPE}\', formatter : \'ui.s2p.srm.sc.track.util.Formatter.formatCatName\'}"\n                                         visible="{path:\'itemDetailData>/itemDetail/DESCRIPTION}\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text id="categoryNameText" text="{itemDetailData>/itemDetail/DESCRIPTION}"\n                                         visible="{path:\'itemDetailData>/itemDetail/DESCRIPTION}\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}"\n                                         maxLines="0">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n\n                                  <Label id="categoryType"\n                                         text="{path:\'itemDetailData>/itemDetail/PRODUCT_TYPE\', formatter : \'ui.s2p.srm.sc.track.util.Formatter.formatCatType\'}"\n                                         visible="{path:\'itemDetailData>/itemDetail/CATEGORY_ID\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text id="categoryTypeText"\n                                         visible="{path:\'itemDetailData>/itemDetail/CATEGORY_ID\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}"\n                                         text="{parts:[{path:\'itemDetailData>/itemDetail/CATEGORY_TEXT\'},{path:\'itemDetailData>/itemDetail/CATEGORY_ID\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatCategory\'}"\n                                         maxLines="0">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                          \n\n                                  <Label id="supplier" text="{i18n>SUPPLIER}"\n                                         visible="{path:\'itemDetailData>/supplier/SupplierName\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text id="supplierText" text="{itemDetailData>/supplier/SupplierName}"\n                                         maxLines="0"\n                                         visible="{path:\'itemDetailData>/supplier/SupplierName\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                                  <Label id="deliveryDateLbl" text="{i18n>DELIVERY_DATE}" >                                        \n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>                               \n                                  <Text id="deliveryDate" \n                                  >   \n                                  \n                                                                                                                                               \n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                                  \n                                  <Label text="{i18n>DELIVERY_ADDRESS}" id="address"\n                                         visible="{path:\'itemDetailData>/shipAddr/AdditionalNo\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       minWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Label>\n                                  <Text\n                                         text="{parts : [{path:\'itemDetailData>/shipAddr/Street\'},{path:\'itemDetailData>/shipAddr/PostalCode1\'},{path:\'itemDetailData>/shipAddr/City\'},{path:\'itemDetailData>/shipAddr/CountryName\'}],\n                                                                     formatter:\'ui.s2p.srm.sc.track.util.Formatter.showDeliveryAddress\'}"\n                                         visible="{path:\'itemDetailData>/shipAddr/AdditionalNo\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showElementOnUi\'}"\n                                         id="addressText" maxLines="0">\n                                         <layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                       weight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                         </layoutData>\n                                  </Text>\n                                                                 \n\n                                  <!-- extension point for attributes -->\n\n                                  <core:ExtensionPoint name="extMoreInfo"></core:ExtensionPoint>\n                           </sap.ui.layout.form:content>\n                     </sap.ui.layout.form:SimpleForm>\n\n                \t  <List id="NotesDetail" items="{notes>/notesdata}"\n                           visible="{path:\'itemDetailData>/itemDetail/NUMBER_NOTES\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.valueVisibilityCheck\'}"\n                           headerText="{path:\'itemDetailData>/itemDetail/NUMBER_NOTES\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.setNoteText\'}"\n                           mode="SingleSelectMaster" show-separator="None">\n                           <items>\n                                  <FeedListItem sender="{notes>TEXT_ID_DESC_UI}"\n                                         showIcon="false" senderPress="onNotePersonPress" senderActive="false"\n                                         text="{notes>LONGTEXT}"\n                                         visible="{path:\'notes>TEXT_ID\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showSupplierNotes\'}" >\n\n                                  </FeedListItem>\n                           </items>\n                     </List> \t\t\n                                        \n                             \n                    \n\n                     <List id="AttachmentDetailData" items="{itemDetailData>/attach}"\n                           visible="{path:\'itemDetailData>/itemDetail/NUMBER_ATTACHMENTS\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.valueVisibilityCheck\'}"\n                           headerText="{path:\'itemDetailData>/itemDetail/NUMBER_ATTACHMENTS\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.setAttachmentText\'}"\n                           show-separator="None">\n                           <StandardListItem press="onAttachment" type="Active"\n                                  title="{itemDetailData>PHIO_FNAME}"\n                                  icon="{path:\'itemDetailData>PHIO_MIME\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAttachmentIcon\'}"\n                                  description="{path:\'itemDetailData>PHIO_FSIZE\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAttachmentSize\'}"\n                                  icon-inset="false">\n                           </StandardListItem>\n                     </List>\n\n              \n\n                           \n                     <Table id="tableHeader" items="{itemDetailData>/account}"\n                           visible="{path:\'itemDetailData>/account\', formatter :\'ui.s2p.srm.sc.track.util.Formatter.arrayVisibilityCheck\'}"\n                           headerText="{path:\'itemDetailData>/account\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.setAccountAssignmentText\'}">\n                           <columns>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label text="{i18n>DESCRIPTION}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label text="{i18n>CATEGORY}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label id="GL_ACC" text="{i18n>GL_ACC}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n                                  <Column hAlign="Left" minScreenWidth="tablet" demandPopin="true">\n                                         <header>\n                                                <Label id="SHARE" text="{i18n>SHARE}" textAlign="Left"></Label>\n                                         </header>\n                                  </Column>\n\n                           </columns>\n                           <items>\n                                  <ColumnListItem type="Active" unread="true" counter="0"\n                                         id="itemListDetail">\n                                         <cells id="itemList">\n                                               <VBox>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<items>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectIdentifier title= "{itemDetailData>acc_cat_desc_ui}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectIdentifier title= "{path: \'itemDetailData>acc_cat_val_ui\' , formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatDesc\'}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t\t\t</VBox>                                                       \n                                                <ObjectIdentifier id="ob2"\n                                                       text="{itemDetailData>acc_cat_ui}"></ObjectIdentifier>\n                                                <VBox>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<items>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Text text= "{itemDetailData>GL_DESCRIPTION}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Text text= "{path: \'itemDetailData>G_L_ACCT\' , formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatDesc\'}" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t\t\t\t</VBox>        \n                                                <ObjectNumber id="ob4"\n                                                       number="{path:\'itemDetailData>DISTR_PERC\', \n                                                              formatter : \'ui.s2p.srm.sc.track.util.Formatter.formatDistributionPercentage\'}">\n                                                </ObjectNumber>\n\n                                         </cells>\n                                  </ColumnListItem>\n                           </items>\n                     </Table>\n                     <List id="Approval_list" items="{itemDetailData>/approvers}"\n                           mode="SingleSelectMaster" show-separator="None"\n                            headerText="{path:\'itemDetailData>/approvers\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.setApproverText\'}"\n                           visible="{path:\'itemDetailData>/approvers\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.arrayVisibilityCheck\'}">\n                           <items>\n                                  <FeedListItem sender="{path:\'itemDetailData>PROCESSOR_NAMES_CONC\'}"\n                                         id="approverDet" icon-active="false" sender-active="true"\n                                         icon="{path : \'itemDetailData>APPROVER_ID\', formatter: \'.formatEmployee\'}"\n                                         iconPress="onApproverPress" senderPress="onApproverPress"\n                                         text="{itemDetailData>DECISION_SET_DESCR}">\n                                  </FeedListItem>\n                           </items>\n                     </List>\n\n\n\n              </content>\n       </Page>\n</core:View>\n\n\n',
		"ui/s2p/srm/sc/track/view/S2.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
			jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
			jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
			jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
			jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
			sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.track.view.S2", {
				onInit: function() {
					sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
					var m = this.oApplicationFacade.getODataModel();
					this.getView().setModel(m);
					m.setCountSupported(false);
					m.setSizeLimit(10);
					var f = [];
					var F = new sap.ui.model.odata.Filter("ADV_SEARCH_FLAG", [{
						operator: "EQ",
						value1: 'false'
					}]);
					f.push(F);
					if (this.extHookInit) {
						this.extHookInit(f)
					}
					var l = this.getList();
					var t = l.getItems()[0].clone();
					l.bindItems("/ordertrackCollection", t, null, f);
					this.registerMasterListBind(l)
				},
				setListItem: function(i) {
					var b = i.getBindingContext();
					i.setSelected(true);
					this.getList().setSelectedItem(i, true);
					this.oRouter.navTo("detail", {
						contextPath: b.getPath().substr(1),
					}, true);
					if (this.extHook1) {
						this.extHook1()
					}
				},
				applySearchPatternToListItem: function(i, f) {
					if (f.substring(0, 1) === "#") {
						var t = f.substr(1);
						var d = i.getBindingContext().getProperty("Name").toLowerCase();
						return d.indexOf(t) === 0
					} else {
						return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
					}
				},
				getHeaderFooterOptions: function() {
					return {
						sI18NMasterTitle: "MASTER_TITLE",
						buttonList: []
					}
				},
				isBackendSearch: function() {
					return true
				},
				applyBackendSearchPattern: function(f, b) {
					var F = [];
					if (f) {
						F = [new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false), new sap.ui.model.Filter("DESCRIPTION", sap.ui
							.model.FilterOperator.EQ, f)]
					} else {
						F = [new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false)]
					}
					b.filter(F, sap.ui.model.FilterType.Application)
				}
			})
		},
		"ui/s2p/srm/sc/track/view/S2.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\tcontrollerName="ui.s2p.srm.sc.track.view.S2">\n\t<Page id="page" title="{i18n>MASTER_TITLE}">\n\t\t<content>\n\t\t\t<List id="list" mode="{device>/listMode}" select="_handleSelect"\n\t\t\t\tupdateFinished="selectFirstItem" growing="true" growingThreshold="10">\n\t\t\t\t<ObjectListItem id="MAIN_LIST_ITEM" type="{device>/listItemType}"\n\t\t\t\t\tpress="_handleItemPress" title="{parts:[{path:\'i18n>CART\'},{path:\'OBJECT_ID\'}]}"\n\t\t\t\t\tnumber="{parts:[{path:\'NET_VALUE\'}],formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}"\n\t\t\t\t\tnumberUnit="{CURRENCY}">\n\t\t\t\t\t<firstStatus>\n\t\t\t\t\t\t<ObjectStatus text="{STATUS_DESC}"\n\t\t\t\t\t\t\tstate="{path: \'STATUS\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatStatus\'}"></ObjectStatus>\n\t\t\t\t\t</firstStatus>\n\t\t\t\t\t<attributes>\n\t\t\t\t\t\t<ObjectAttribute id="ATTR1"\n\t\t\t\t\t\t\ttext="{path:\'CREATED_ON\', type:\'sap.ui.model.type.Date\', formatOptions: {style:\'medium\'}}" />\n\n\t\t\t\t\t\t<!-- extension point for attributes -->\n\t\t\t\t\t\t<core:ExtensionPoint name="extMoreAttr"></core:ExtensionPoint>\n\t\t\t\t\t</attributes>\n\t\t\t\t</ObjectListItem>\n\t\t\t</List>\n\t\t</content>\n\n\t\t<footer>\n\t\t\t<Bar id="footer"></Bar>\n\t\t</footer>\n\n\t</Page>\n</core:View>',
		"ui/s2p/srm/sc/track/view/S3.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
			jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
			jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
			jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
			jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
			jQuery.sap.require("sap.ca.ui.dialog.factory");
			jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
			jQuery.sap.require("sap.m.MessageBox");
			jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
			sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.track.view.S3", {
				onInit: function() {
					sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
					this.oBundle = this.oApplicationFacade.getResourceBundle();
					this.busyDialog = new sap.m.BusyDialog({
						customIcon: sap.ca.ui.images.images.Flower
					});
					this.oRouter.attachRouteMatched(function(e) {
						if (e.getParameter("name") === "detail") {
							var c = e.getParameter("arguments").contextPath;
							var s = c.split("ordertrackCollection('");
							var o = s[0].split("'")[3];
							var a = s[0].split("'")[1];
							this.sapOrigin = a;
							this.busyDialog.open();
							this.getCartInfo(o);
							this.getCartItems(o);
							this.getApprovalDetails(o)
						}
					}, this);
					var h = this.byId("header");
					var i = this.byId("itemList");
					if (i) {
						h.addEventDelegate({
							onAfterRendering: this.updateItemsList
						}, this)
					}
				},
				getHeaderFooterOptions: function() {
					return {
						sI18NDetailTitle: "TITLE_RECENT_CART",
						oAddBookmarkSettings: {
							title: this.oBundle.getText("TITLE_RECENT_CART"),
							icon: "sap-icon://cart"
						},
						oJamOptions: {
							oShareSettings: {
								object: {
									id: this.approvalLink,
									display: this.oDisplay,
									share: this.object_ID
								}
							},
						}
					}
				},
				getCartInfo: function(o) {
					this.getView().byId("icontabBar").setSelectedKey("Information");
					var a = function(D, r) {
						var h = new sap.ui.model.json.JSONModel(D);
						if (D.WIID != '000000000000') {
							this.approvalLink = document.location.origin + document.location.pathname + document.location.search +
								"#ShoppingCartItem-approve&/detail/WorkflowTaskCollection(SAP__Origin=" + jQuery.sap.encodeURL("'") + this.sapOrigin + jQuery.sap
								.encodeURL("'") + ",WorkitemID=" + jQuery.sap.encodeURL("'") + D.WIID + jQuery.sap.encodeURL("'") + ")"
						} else {
							this.approvalLink = ''
						}
						this.object_ID = o;
						this.objectStatus = new sap.m.ObjectStatus({
							text: D.HEADER_STATUS_DESCR
						});
						this.oDisplay = new sap.m.ObjectListItem({
							title: this.oBundle.getText("CART") + " " + D.OBJECT_ID,
							number: D.TOTAL_GROSS,
							numberUnit: D.CURRENCY,
							firstStatus: this.objectStatus
						});
						var H = this.getHeaderFooterOptions();
						this.setHeaderFooterOptions(H);
						this.getView().byId("header").setModel(h, "ShoppingCartHeader");
						this.getView().byId("info").setModel(h, "ShoppingCartInfo");
						this.parseApprovalNotes()
					};
					var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					d.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + o +
						"',DOC_MODE='DISPLAY',WIID='000000000000')", null, null, true, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));
					if (this.extHook2) {
						this.extHook2()
					}
				},
				updateItemsList: function(e) {
					var s = e.srcControl;
					if (s.getModel('ShoppingCartHeader') !== undefined) {
						setTimeout(jQuery.proxy(function() {
							var i = s.getModel('ShoppingCartHeader').getData().ITEM_COUNT;
							var h = ui.s2p.srm.sc.track.util.Formatter.formatItemCount(i);
							this.getView().byId("itemList").setHeaderText(h)
						}, this), 100)
					}
				},
				getCartItems: function(o) {
					var a = function(D, r) {
						this.oItemModel = new sap.ui.model.json.JSONModel(D);
						this.getView().byId("itemList").setModel(this.oItemModel, "ShoppingCartItems");
						var b = ui.s2p.srm.sc.track.util.Formatter.formatMaxDeliveryDate(D.results);
						this.getView().byId("deliv_Date").setText(b);
						ui.s2p.srm.sc.track.util.ItemList.item.clear();
						for (var i = 0; i < D.results.length; i++) {
							ui.s2p.srm.sc.track.util.ItemList.item.add(D.results)
						}
					};
					var d = this.oApplicationFacade.getODataModel();
					d.read("ordertrackCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + o + "')/OrderTrackItemNavigation", null, null, true,
						jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this))
				},
				onDetailListItemPressed: function(e) {
					var l = e.getSource();
					var b = l.getBindingContext("ShoppingCartItems");
					var m = b.getModel();
					var p = b.getPath();
					var i = m.getProperty(p);
					var a = i.PRODUCT_KEY;
					var o = i.OBJECT_ID;
					var c = e.getSource().sId.split('-')[6];
					var d = jQuery.sap.encodeURL(i.PRODUCT_KEY);
					var n = i.NUMBER_INT;
					var s = b.getModel().getProperty(b.getPath()).SAP__Origin;
					this.oRouter.navTo("itemDetail", {
						objectid: o,
						numberint: n,
						itemIndex: c,
						sapOrigin: s
					}, true)
				},
				getApprovalDetails: function(o) {
					var a = function(D, r) {
						var i;
						for (i = 0; i < D.results.length; i++) {
							if (D.results[i].AGENT_ID == "" && D.results[i].PROCESSOR_NAMES_CONC != "") {
								var b = D.results[i].PROCESSOR_NAMES_CONC.split(";");
								var c = D.results[i].APR_AGENT_ID.slice(1).split(';');
								var j;
								for (j = 0; j < b.length; j++) {
									var e = new Object();
									jQuery.extend(e, D.results[i]);
									e.PROCESSOR_NAMES_CONC = b[j];
									e.AGENT_ID = b[j];
									e.APPROVER_ID = c[j];
									if (j == 0) D.results.splice(i, 1, e);
									else D.results.splice(i, 0, e)
								}
							} else if (D.results[i].AGENT_ID != "") {
								var f = D.results[i].APR_AGENT_ID.slice(1).split(';');
								if (f.length === 1 && f[0] === D.results[i].AGENT_ID) D.results[i].APPROVER_ID = D.results[i].AGENT_ID
							}
						}
						this.oApprovalModel = new sap.ui.model.json.JSONModel(D);
						this.getView().byId("Approval_list").setModel(this.oApprovalModel, "peopleApproverNotes");
						this.getView().byId("approvalTab").setCount(D.results.length);
						this.busyDialog.close()
					};
					var d = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
					d.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + o +
						"',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartApprovalNavigation", null, null, true, jQuery.proxy(a, this), jQuery.proxy(
							this.onRequestFailed, this))
				},
				parseApprovalNotes: function() {
					var h = this.getView().byId("header").getModel("ShoppingCartHeader");
					var a = h.getData();
					var n = a.APRV_NOTE;
					var p = n.split("________");
					var b = [];
					var c = new sap.ui.model.json.JSONModel();
					for (var i = 0; i < p.length; i++) {
						var d = p[i];
						if (d.trim() === "") {
							continue
						}
						var e = {};
						var u = d.split("(")[1].split(')')[0].split(" ");
						var f = d.slice(0).split("")[0] !== "\n" ? d.slice(0).split("(")[0] : d.slice(1).split("(")[0];
						e.sender = u[0] !== "" ? u[0] : u[1];
						e.timestamp = u.slice(2).join(" ");
						e.noteText = f;
						b.push(e)
					}
					this.getView().byId("Notes").setModel(c, "ApprovalNotes");
					if (n.length === 0) {
						this.getView().byId("peopleNote").setVisible(false)
					} else {
						var g = {
							notes: b
						};
						c.setData(g);
						this.getView().byId("peopleNote").setVisible(true);
						this.getView().byId("peopleNote").setCount(b.length)
					}
				},
				displayContactPicture: function(v) {
					return jQuery.sap.getModulePath("ui.s2p.srm.sc.track") + "/img/" + "person_placeholder.png"
				},
				openBusinessCard: function(e) {
					var v = this.getView();
					var o = function(D, R) {
						var a = D.results[0];
						var f = a.LastName;
						if (a.FirstName) {
							if (f) {
								f = a.FirstName + " " + f
							} else {
								f = a.FirstName
							}
						}
						if (!f) {
							f = ""
						}
						var t = a.TELEPHONE ? a.TELEPHONE : "";
						var b = a.INHOUSE_MAIL;
						var c = a.COMPANY_NAME;
						var E = {
							name: f,
							imgurl: this.displayContactPicture(),
							department: "",
							contactmobile: "",
							contactphone: t,
							companyname: c,
							contactemail: b,
							contactemailsubj: "",
							companyaddress: ""
						};
						Object.keys(E).forEach(function(k) {
							if (E[k]) {
								var C = v.byId("Approval_list");
								var g = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
								g.openBy(C);
								return
							}
						})
					};
					var s = e.getSource().getBinding("sender").getContext().getPath();
					var r = s.split("/");
					var i = r[2];
					var d = this.oApplicationFacade.getODataModel("USERS_LIST");
					d.read("ALL_USERS_LIST", null, ["$filter=UserName eq '" + this.oApprovalModel.oData.results[i].APPROVER_ID + "'"], false, jQuery.proxy(
						o, this), jQuery.proxy(this.onRequestFailed, this))
				},
				onRequestFailed: function(e) {
					this.busyDialog.close();
					jQuery.sap.require("sap.ca.ui.message.message");
					sap.ca.ui.message.showMessageBox({
						type: sap.ca.ui.message.Type.ERROR,
						message: e.message,
						details: e.response.body
					})
				}
			})
		},
		"ui/s2p/srm/sc/track/view/S3.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\txmlns:sap.ui.layout="sap.ui.layout" xmlns:form="sap.ui.layout.form"\n\tcontrollerName="ui.s2p.srm.sc.track.view.S3">\n\t<Page id="detailPage" class="sapUiFioriObjectPage" showNavButton="{device>/showNavButton}" navButtonPress="_navBack">\n\t\t<content>\n\t\t\t<ObjectHeader id="header"\n\t\t\t\ttitle="{parts:[{path:\'i18n>CART\'},{path:\'ShoppingCartHeader>/OBJECT_ID\'}]}"\n\t\t\t\tnumber="{path:\'ShoppingCartHeader>/TOTAL_VALUE\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}" numberUnit="{ShoppingCartHeader>/CURRENCY}"\n\t\t\t\tintroActive="false" titleActive="false" icon="{sscModel>status_icon}"\n\t\t\t\ticonActive="false">\n\t\t\t\t<attributes>\n\t\t\t\t\t<ObjectAttribute\n\t\t\t\t\t\ttext="{parts:[{path:\'i18n>CREATED_ON\'},{path:\'ShoppingCartHeader>/CREATED_AT\', type:\'sap.ui.model.type.Date\',formatOptions: {source:{pattern:\'yyyyMMddhhmmss\'}, style:\'medium\'}}]}"\n\t\t\t\t\t\tactive="false"></ObjectAttribute>\n\t\t\t\t</attributes>\n\t\t\t\t<firstStatus>\n\t\t\t\t\t<ObjectStatus text="{ShoppingCartHeader>/HEADER_STATUS_DESCR}"\n\t\t\t\t\t\tstate="{path:\'ShoppingCartHeader>/HEADER_STATUS_ID\',formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatStatus\'}"></ObjectStatus>\n\t\t\t\t</firstStatus>\n\t\t\t</ObjectHeader>\n\t\t\t<IconTabBar id="icontabBar" expandable="false">\n\t\t\t\t<items>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://hint" iconColor="Default"\n\t\t\t\t\t\tkey="Information" id="info" showAll="false">\n\t\t\t\t\t\t<content>\n\t\t\t\t\t\t\t<form:SimpleForm id="myForm1" minWidth="1024"\n\t\t\t\t\t\t\t\teditable="false">\n\t\t\t\t\t\t\t\t<form:content>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>SHOPPING_CART_NO}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text text="{ShoppingCartInfo>/OBJECT_ID}" maxLines="0"\n\t\t\t\t\t\t\t\t\t\tid="cartid">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>COST_ASSIGNMENT}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text text="{ShoppingCartInfo>/ACC_ASS_STR}" maxLines="0"\n\t\t\t\t\t\t\t\t\t\tid="account">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>DELIVERY_ADDRESS}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<VBox direction="Column" id="addressvbox">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t\t\t<Text id="SCC_ADDRESS1"\n\t\t\t\t\t\t\t\t\t\t\t\tvisible="{path:\'ShoppingCartInfo>/STREET\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.showVisibilityAddress1\'}"\n\t\t\t\t\t\t\t\t\t\t\t\ttext="{path:\'ShoppingCartInfo>/STREET\', formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAddress1\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t\t<Text id="SCC_ADDRESS2"\n\t\t\t\t\t\t\t\t\t\t\t\tvisible="{parts : [{path:\'ShoppingCartInfo>/CITY\'},{path:\'ShoppingCartInfo>/DISTRICT\'},{path:\'ShoppingCartInfo>/POSTL_COD1\'},{path:\'ShoppingCartInfo>/COUNTRY_TEXT\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.showVisibilityAddress2\'}"\n\t\t\t\t\t\t\t\t\t\t\t\ttext="{parts : [{path:\'ShoppingCartInfo>/CITY\'},{path:\'ShoppingCartInfo>/DISTRICT\'},{path:\'ShoppingCartInfo>/POSTL_COD1\'},{path:\'ShoppingCartInfo>/COUNTRY_TEXT\'}],formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatAddress2\'}"></Text>\n\t\t\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t\t\t</VBox>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>REQUESTED_DELIVERY_DATE}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text id="deliv_Date" maxLines="0">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\t\t\t\t\t\t\t\t\t<Label text="{i18n>CURRENT_APPROVER}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tminWidth="192" weight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t<Text maxLines="0" id="approver" text="{ShoppingCartInfo>/APPR_STR}">\n\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tweight="5"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t</Text>\n\n\t\t\t\t\t\t\t\t\t<!-- Extension point added for more information -->\n\t\t\t\t\t\t\t\t\t<core:ExtensionPoint name="extMoreInfo"></core:ExtensionPoint>\n\t\t\t\t\t\t\t\t</form:content>\n\t\t\t\t\t\t\t</form:SimpleForm>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://notes" iconColor="Default"\n\t\t\t\t\t\tshowAll="false" id="peopleNote" visible="false">\n\t\t\t\t\t\t<content id="NotesContent">\n\t\t\t\t\t\t\t<List id="Notes" items="{ApprovalNotes>/notes}" mode="SingleSelectMaster"\n\t\t\t\t\t\t\t\tshow-separator="None">\n\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t<FeedListItem id="notelist" sender="{ApprovalNotes>sender}"\n\t\t\t\t\t\t\t\t\t\tsenderActive="false" senderPress="openBusinessCard" timestamp="{ApprovalNotes>timestamp}"\n\t\t\t\t\t\t\t\t\t\ttext="{ApprovalNotes>noteText}">\n\t\t\t\t\t\t\t\t\t</FeedListItem>\n\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t</List>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t\t<IconTabFilter icon="sap-icon://group" iconColor="Default"\n\t\t\t\t\t\tshowAll="false" id="approvalTab">\n\t\t\t\t\t\t<content id="Approval">\n\t\t\t\t\t\t\t<List id="Approval_list" items="{peopleApproverNotes>/results}"\n\t\t\t\t\t\t\t\tmode="SingleSelectMaster" show-separator="None">\n\t\t\t\t\t\t\t\t<items>\n\t\t\t\t\t\t\t\t\t<FeedListItem sender="{path:\'peopleApproverNotes>PROCESSOR_NAMES_CONC\'}"\n\t\t\t\t\t\t\t\t\t\ticon="{path:\'peopleApproverNotes>APPROVER_ID\',formatter:\'.displayContactPicture\'}"\n\t\t\t\t\t\t\t\t\t\ticon-active="false" iconPress="openBusinessCard"\n\t\t\t\t\t\t\t\t\t\tsender-active="true" senderPress="openBusinessCard"\n\t\t\t\t\t\t\t\t\t\ttext="{peopleApproverNotes>DECISION_SET_DESCR}">\n\t\t\t\t\t\t\t\t\t</FeedListItem>\n\t\t\t\t\t\t\t\t</items>\n\t\t\t\t\t\t\t</List>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t</items>\n\t\t\t</IconTabBar>\n\t\t\t<Table id="itemList" items="{ShoppingCartItems>/results}">\n\t\t\t\t<columns>\n\t\t\t\t\t<Column minScreenWidth="tablet" demandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>DESCRIPTION}" textAlign="Left" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column width="20%" hAlign="Right" minScreenWidth="tablet"\n\t\t\t\t\t\tdemandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label text="{i18n>QUANTITY_LBL}" textAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t\t<Column width="20%" hAlign="Right" minScreenWidth="tablet"\n\t\t\t\t\t\tdemandPopin="true">\n\t\t\t\t\t\t<header>\n\t\t\t\t\t\t\t<Label id="SCC_SUB_TOTAL" text="{i18n>SUB_TOTAL}"\n\t\t\t\t\t\t\t\ttextAlign="Right" width="100%"></Label>\n\t\t\t\t\t\t</header>\n\t\t\t\t\t</Column>\n\t\t\t\t</columns>\n\t\t\t\t<items>\n\t\t\t\t\t<ColumnListItem press="onDetailListItemPressed"\n\t\t\t\t\t\ttype="Navigation" unread="true" counter="0" id="itemListDetail">\n\t\t\t\t\t\t<cells>\n\t\t\t\t\t\t\t<ObjectIdentifier title="{ShoppingCartItems>ITEM_DESC}"></ObjectIdentifier>\n\t\t\t\t\t\t\t<ObjectNumber\n\t\t\t\t\t\t\t\tnumber="{path:\'ShoppingCartItems>QUANTITY\', type:\'sap.ui.model.type.Float\', formatOptions:{maxFractionDigits:0}}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>UNIT}"></ObjectNumber>\n\t\t\t\t\t\t\t<ObjectNumber\n\t\t\t\t\t\t\t\tnumber="{parts:[{path:\'ShoppingCartItems>NET_VALUE\'}, {path:\'ShoppingCartItems>CURRENCY\'}], formatter:\'ui.s2p.srm.sc.track.util.Formatter.formatPriceItem\'}"\n\t\t\t\t\t\t\t\tnumberUnit="{ShoppingCartItems>CURRENCY}"></ObjectNumber>\n\t\t\t\t\t\t</cells>\n\t\t\t\t\t</ColumnListItem>\n\t\t\t\t</items>\n\t\t\t</Table>\n\t\t</content>\n\t</Page>\n</core:View>'
	}
});