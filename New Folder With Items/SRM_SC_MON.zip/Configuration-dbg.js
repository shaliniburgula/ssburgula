/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("ui.s2p.srm.sc.track.Configuration",{

	aServiceList : [
		               {
		            	   name : "ORDERTRACK_SERVICE",
		            	   masterCollection : "ordertrackCollection",
		            	   serviceUrl : "/sap/opu/odata/srmnxp/ORDERTRACK_SERVICE;mo/",
		            	   isDefault : true,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
		               },
		               {
		            	   name : "SRMSHOPPING_CART",
		            	   masterCollection : "SRMShoppingCartCollection",
		            	   serviceUrl : "/sap/opu/odata/srmnxp/SRMSHOPPING_CART;mo/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
		               },		               
		               {

		            	   name : "USERS_LIST",
		            	   masterCollection : "SRMShoppingCartCollection",
		            	   serviceUrl : "/sap/opu/odata/SRMNXP/USERS_LIST/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"

		               },
		               {

		            	   name : "UTIL",
		            	   masterCollection : "UOMCollection",
		            	   serviceUrl : "/sap/opu/odata/SRMNXP/UTIL/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"

		               },
		               {

		            	   name : "CARTAPPROVAL",
		            	   masterCollection : "WorkflowTaskCollection",
		            	   serviceUrl : "/sap/opu/odata/GBSRM/CARTAPPROVAL;v=2;mo/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.sc.approve/model/metadata.xml"

		               },
		               {
		            	   name : "ACC_ASSIGN_CATEGORY",
		            	   masterCollection : "ACC_ASSIGN_CATEGORYCollection",
		            	   serviceUrl : "/sap/opu/odata/srmnxp/ACC_ASSIGN_CATEGORY/",
		            	   isDefault : false,
		            	   mockedDataSource : "/ui.s2p.srm.shoppingcartcreate/model/metadata.xml"
		               }
		               ],

	/**
	 * @inherit
	 */
	getServiceList : function() {
		return this.aServiceList;
	}

});

