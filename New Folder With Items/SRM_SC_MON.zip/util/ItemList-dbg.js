/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.util.ItemList");

ui.s2p.srm.sc.track.util.ItemList = {};

/*
 * We use this Utility object to keep track of the items in the Shopping Cart
 * The items collection can be retrieved in the ItemDetail screen and helps
 * navigating to previous or next items when the Up/Down navigation buttons
 * are clicked. 
 */
ui.s2p.srm.sc.track.util.ItemList.item = (function() {
	var items = [];
	return {
		//Added scnumber, itemnumber for fiori performance improvement
		add : function(itemList) {
			this.clear();
			for(var i = 0; i < itemList.length; i++){
				items.push({
					objectid : itemList[i].OBJECT_ID,
					item : itemList[i].NUMBER_INT,
					index : i
					
				});
			}			
		},
		

		each : function(callback) {
			for ( var i = 0; i < items.length; i++) {
				callback(items[i].item);
			}
		},

		length : function() {
			return items.length;
		},

		clear: function(){
			items = [];
		},
		
		getIndex : function(itemname) {
			for ( var i = 0; i < items.length; i++) {
				if (items[i].item === itemname)
					return i;
			}
			return -1;
		},
		
		getItemAtIndex: function(index){
			return items[index].objectid;
		},
		getSCItemNumber: function(index){
			return items[index].item;
		}
	};
})();
