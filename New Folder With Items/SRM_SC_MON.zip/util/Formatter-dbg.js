/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.util.Formatter");

jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("sap.ui.core.Element");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.format.FormattingLibrary");


ui.s2p.srm.sc.track.util.Formatter = {

              showVisibilityAddress1: function(oObject){
                     if(oObject.length!= 0){
                           return true;
                     }
                     else{
                           return false;
                     }
              },

              showVisibilityAddress2: function(city,district,post,country_text){
                     if(city.length != 0 ||  district.length != 0 || post.length != 0 || country_text.length != 0){
                           return true;
                     }
                     else{
                           return false;
                     }
              },

              formatStatus : function(statusText) {
                     var retValue = sap.ui.core.ValueState.None;

                     switch (statusText) {
                     case "I1009": // Saved
                           retValue = sap.ui.core.ValueState.None;
                           break;
                     case "I1016": // Rejected
                           retValue = sap.ui.core.ValueState.Error;
                           break;
                     case "I1129": // Approved
                           retValue = sap.ui.core.ValueState.Success;
                           break;
                     case "I1015": // Pending
                           retValue = sap.ui.core.ValueState.Warning;
                           break;
                     default:
                           retValue = sap.ui.core.ValueState.None;
                           break;
                     }
                     return retValue;
              },

             formatAddress1: function(oObject){
                     if(oObject.length!= 0){
                           return oObject;
                     }
              },

              formatAddress2: function(city,district,post,country_text){
                     var address = "";
                     if (city.length !== 0) {
                           address=city;
                     }
                     if (address.length !== 0) {
                           address += "," + district + " " + post;
                     }
                     if (address.length !== 0) {
                           address += ", " + country_text;                        
                     } 
                     return address;
              },

              formatPreferredItem : function(assortmentInd) {
                     if (assortmentInd === "01") {
                           var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                           var oBundle = oApplication.getResourceBundle();
                           return oBundle.getText("PREFERRED_ITEM");
                     } else {
                           return "";
                     }
              },

              formatCartNumber : function(cartNumberText) {
                     var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                     var oBundle = oApplication.getResourceBundle();
                     return oBundle.getText("CART_NUMBER_EX", [ cartNumberText ]);
              },

              formatItemCount : function(itemCount) {
                     var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                     var oBundle = oApplication.getResourceBundle();
                     return oBundle.getText("ITEMS_QTY_EX", [ itemCount ]);
              },

              formatMaxDeliveryDate : function(itemList) {
                     var currentDeliveryDate = null;
                     for ( var i = 0; i < itemList.length; i++) {
                           if (itemList[i].DELIV_DATE > currentDeliveryDate) {
                                  currentDeliveryDate = itemList[i].DELIV_DATE;
                           }
                     }
                     var dateType = new sap.ui.model.type.Date();
                     dateType.setFormatOptions("medium");
                     return dateType.formatValue(currentDeliveryDate, "string");
              },
              formatDeliveryDate : function(itemDetailData){
        	  		if ( itemDetailData.PRODUCT_TYPE === '02' ){
        	  			        	  			
        	  			var DateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
        	  			var startDate = DateFormatter.format(itemDetailData.VPER_START,true);
        	  			var endDate = DateFormatter.format(itemDetailData.VPER_END,true);
        	  			        	  		
        	  			var delivDateInfo;
        	  			if( itemDetailData.VPER_TYPE  === 'AT' ){        	  				
        	  				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ON", [startDate]);
        	  			}
        	  			else if( itemDetailData.VPER_TYPE  === 'FR' ){
        	  				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("FROM", [startDate]);
        	  			}
        	  			else if ( itemDetailData.VPER_TYPE  === 'BE' ){        	  				
        	  				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("TO", [startDate,endDate]);
        	  			}
        	  			       	  		
        	  		}
        	  		else if(itemDetailData.PRODUCT_TYPE === '01' ){
        	  			var DateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
        	  			var delivDate = DateFormatter.format(itemDetailData.DELIV_DATE,true);        	  			
        	  			return delivDate;
        	  		}
            	  
              },

              formatItemAndCount : function(ItemAndCount, totalItems) {
                     var oApplication = sap.ca.scfld.md.app.Application.getImpl();
                     var oBundle = oApplication.getResourceBundle();
                     return oBundle.getText("ITEM_AND_COUNT_EX",     [ ItemAndCount, totalItems ]);
              },

              formatPrice : function(oValue, sCurrency,priceUnit, unit) {
                     var formatter = sap.ca.ui.model.format.AmountFormat.getInstance({
                           style: "standard",
                           decimals: "2"
                     });
                     return formatter.format(oValue) + ' ' + sCurrency + ' '+ '/' + priceUnit + ' ' + unit;
              },
              
              formatPriceItem : function(oValue) {
      			var formatter = sap.ca.ui.model.format.AmountFormat.getInstance({
    				style: "standard",
    				decimals: "2"
    			});
    			return formatter.format(oValue);
    		},
              //Show an element if required
              showElementOnUi : function(obj){
                     if(obj==''){
                           return false;
                     }
                     else{
                           return true;
                     }
              },
              formatCategory : function(value1, value2){
                     return value1+ ' ' + " ("+value2+")";
              },
              formatDesc : function(value1){
                  return  " ("+value1+")";
           },


              formatACCCategory : function(acc){
                     switch(acc)
                     {
                           case ('CC') : return( 'Cost Center');    
                     }
              },
              
              formatCatName : function(obj) {
                     if (obj == "02") {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_NAME");
                          
                           
                     } else {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_NAME");
                     }
              },

              //Format the item as Product or Sevice Category
              formatCatType : function(obj) {
                     if (obj == "02") {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_CATEGORY");
                     } else {
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_CATEGORY");
                     }
              },
              //Check if a value is 0
              valueVisibilityCheck : function(obj){
                     if (obj == 0)
                           return false;
                     else
                           return true;
              },
              
              //Show Notes label if there are notes for an item
              setNoteText : function() {
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('NOTES');

              },
              showSupplierNotes : function(noteType){
                if(noteType == 'ITXT')
                       return true;
                else
                       return false;
              },
              //Show the format of an attachment
              formatAttachmentIcon : function(sMimeType) {
                     var formatterFileIcon = sap.ca.ui.model.format.FormattingLibrary.formatAttachmentIcon(sMimeType);
                     return formatterFileIcon;
              },

              //Show the total size of the attachment
              formatAttachmentSize : function(bytes) {
                 var formatter = sap.ca.ui.model.format.FileSizeFormat.getInstance();
                     var result = formatter.format(bytes);
                     return result;
                     return '12 kb';
              },

              //Open or download the attachment
              showAttachment : function(url) {
                     var sMedia_src = url;
                     sap.m.URLHelper.redirect(sMedia_src, true);
              },
              //Show Attachments label if there are attachments for an item
              setAttachmentText : function() {
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ATTACHMENTS');
              },
              //Check if an array is empty
              arrayVisibilityCheck : function(obj) {                 
                     if (obj.length == 0)
                           return false;
                     else
                           return true;               
              },
              //Set the Account Assignment label 
              setAccountAssignmentText : function(){
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ACCOUNT_ASSIGNMENT');
              },

              formatDistributionPercentage : function(value) {
                     var percent = "%";
                     if (parseFloat(value)) {
                           value = value.split('.').join(',');
                           value += percent;
                     }
                     return value;
              },

              setApproverText : function(){
                     return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('APPR_CHAIN');
              },

              showDeliveryAddress : function(a,b,c,d)
              {
                     return (a + "," + b + " "+ c + " " + d) ;
                     
              },
              //Delivery date for an item in item detail page
              showDeliveryDateHeader : function(oDate, fromDate, toDate){
                     var DateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
                     if(oDate){
                           var mediumDate = DateFormatter.format(oDate,true);
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_ON', [mediumDate]);
                     }
                     else{
                           var mediumFromDate = DateFormatter.format(fromDate,true);
                           var mediumToDate = DateFormatter.format(toDate,true);
                           return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_REQUIRED', [mediumFromDate, mediumToDate]);
                     }

              },

};


