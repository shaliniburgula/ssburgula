/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.util.ItemList");
ui.s2p.srm.sc.track.util.ItemList = {};
ui.s2p.srm.sc.track.util.ItemList.item = (function() {
	var a = [];
	return {
		add: function(b) {
			this.clear();
			for (var i = 0; i < b.length; i++) {
				a.push({
					objectid: b[i].OBJECT_ID,
					item: b[i].NUMBER_INT,
					index: i
				})
			}
		},
		each: function(c) {
			for (var i = 0; i < a.length; i++) {
				c(a[i].item)
			}
		},
		length: function() {
			return a.length
		},
		clear: function() {
			a = []
		},
		getIndex: function(b) {
			for (var i = 0; i < a.length; i++) {
				if (a[i].item === b) return i
			}
			return -1
		},
		getItemAtIndex: function(i) {
			return a[i].objectid
		},
		getSCItemNumber: function(i) {
			return a[i].item
		}
	}
})();