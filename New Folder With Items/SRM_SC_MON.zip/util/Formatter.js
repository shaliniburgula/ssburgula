/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("sap.ui.core.Element");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.model.format.FormattingLibrary");
ui.s2p.srm.sc.track.util.Formatter = {
	showVisibilityAddress1: function(o) {
		if (o.length != 0) {
			return true
		} else {
			return false
		}
	},
	showVisibilityAddress2: function(c, d, p, a) {
		if (c.length != 0 || d.length != 0 || p.length != 0 || a.length != 0) {
			return true
		} else {
			return false
		}
	},
	formatStatus: function(s) {
		var r = sap.ui.core.ValueState.None;
		switch (s) {
			case "I1009":
				r = sap.ui.core.ValueState.None;
				break;
			case "I1016":
				r = sap.ui.core.ValueState.Error;
				break;
			case "I1129":
				r = sap.ui.core.ValueState.Success;
				break;
			case "I1015":
				r = sap.ui.core.ValueState.Warning;
				break;
			default:
				r = sap.ui.core.ValueState.None;
				break
		}
		return r
	},
	formatAddress1: function(o) {
		if (o.length != 0) {
			return o
		}
	},
	formatAddress2: function(c, d, p, a) {
		var b = "";
		if (c.length !== 0) {
			b = c
		}
		if (b.length !== 0) {
			b += "," + d + " " + p
		}
		if (b.length !== 0) {
			b += ", " + a
		}
		return b
	},
	formatPreferredItem: function(a) {
		if (a === "01") {
			var A = sap.ca.scfld.md.app.Application.getImpl();
			var b = A.getResourceBundle();
			return b.getText("PREFERRED_ITEM")
		} else {
			return ""
		}
	},
	formatCartNumber: function(c) {
		var a = sap.ca.scfld.md.app.Application.getImpl();
		var b = a.getResourceBundle();
		return b.getText("CART_NUMBER_EX", [c])
	},
	formatItemCount: function(i) {
		var a = sap.ca.scfld.md.app.Application.getImpl();
		var b = a.getResourceBundle();
		return b.getText("ITEMS_QTY_EX", [i])
	},
	formatMaxDeliveryDate: function(a) {
		var c = null;
		for (var i = 0; i < a.length; i++) {
			if (a[i].DELIV_DATE > c) {
				c = a[i].DELIV_DATE
			}
		}
		var d = new sap.ui.model.type.Date();
		d.setFormatOptions("medium");
		return d.formatValue(c, "string")
	},
	formatDeliveryDate: function(i) {
		if (i.PRODUCT_TYPE === '02') {
			var D = sap.ca.ui.model.format.DateFormat.getDateInstance();
			var s = D.format(i.VPER_START, true);
			var e = D.format(i.VPER_END, true);
			var d;
			if (i.VPER_TYPE === 'AT') {
				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ON", [s])
			} else if (i.VPER_TYPE === 'FR') {
				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("FROM", [s])
			} else if (i.VPER_TYPE === 'BE') {
				return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("TO", [s, e])
			}
		} else if (i.PRODUCT_TYPE === '01') {
			var D = sap.ca.ui.model.format.DateFormat.getDateInstance();
			var a = D.format(i.DELIV_DATE, true);
			return a
		}
	},
	formatItemAndCount: function(I, t) {
		var a = sap.ca.scfld.md.app.Application.getImpl();
		var b = a.getResourceBundle();
		return b.getText("ITEM_AND_COUNT_EX", [I, t])
	},
	formatPrice: function(v, c, p, u) {
		var f = sap.ca.ui.model.format.AmountFormat.getInstance({
			style: "standard",
			decimals: "2"
		});
		return f.format(v) + ' ' + c + ' ' + '/' + p + ' ' + u
	},
	formatPriceItem: function(v) {
		var f = sap.ca.ui.model.format.AmountFormat.getInstance({
			style: "standard",
			decimals: "2"
		});
		return f.format(v)
	},
	showElementOnUi: function(o) {
		if (o == '') {
			return false
		} else {
			return true
		}
	},
	formatCategory: function(v, a) {
		return v + ' ' + " (" + a + ")"
	},
	formatDesc: function(v) {
		return " (" + v + ")"
	},
	formatACCCategory: function(a) {
		switch (a) {
			case ('CC'):
				return ('Cost Center')
		}
	},
	formatCatName: function(o) {
		if (o == "02") {
			return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_NAME")
		} else {
			return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_NAME")
		}
	},
	formatCatType: function(o) {
		if (o == "02") {
			return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_PRODUCT_CATEGORY")
		} else {
			return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText("ITM_SERVICE_CATEGORY")
		}
	},
	valueVisibilityCheck: function(o) {
		if (o == 0) return false;
		else return true
	},
	setNoteText: function() {
		return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('NOTES')
	},
	showSupplierNotes: function(n) {
		if (n == 'ITXT') return true;
		else return false
	},
	formatAttachmentIcon: function(m) {
		var f = sap.ca.ui.model.format.FormattingLibrary.formatAttachmentIcon(m);
		return f
	},
	formatAttachmentSize: function(b) {
		var f = sap.ca.ui.model.format.FileSizeFormat.getInstance();
		var r = f.format(b);
		return r;
		return '12 kb'
	},
	showAttachment: function(u) {
		var m = u;
		sap.m.URLHelper.redirect(m, true)
	},
	setAttachmentText: function() {
		return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ATTACHMENTS')
	},
	arrayVisibilityCheck: function(o) {
		if (o.length == 0) return false;
		else return true
	},
	setAccountAssignmentText: function() {
		return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('ACCOUNT_ASSIGNMENT')
	},
	formatDistributionPercentage: function(v) {
		var p = "%";
		if (parseFloat(v)) {
			v = v.split('.').join(',');
			v += p
		}
		return v
	},
	setApproverText: function() {
		return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('APPR_CHAIN')
	},
	showDeliveryAddress: function(a, b, c, d) {
		return (a + "," + b + " " + c + " " + d)
	},
	showDeliveryDateHeader: function(d, f, t) {
		var D = sap.ca.ui.model.format.DateFormat.getDateInstance();
		if (d) {
			var m = D.format(d, true);
			return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_ON', [m])
		} else {
			var a = D.format(f, true);
			var b = D.format(t, true);
			return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('DELIVERY_REQUIRED', [a, b])
		}
	},
};