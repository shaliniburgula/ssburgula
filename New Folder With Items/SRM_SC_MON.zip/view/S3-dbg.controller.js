/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
	jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.track.view.S3",
{
		
	onInit : function() {
		// execute the onInit for the base class
		// BaseDetailController
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		
		// Get reference of resource bundle		
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		
		// Get instance of the busy dialog
		this.busyDialog = new sap.m.BusyDialog({customIcon: sap.ca.ui.images.images.Flower});
	//	  var newObject = jQuery.extend(true, {}, sap.ui.getCore().byId("__xmlview2--list").getItems()[0]);
//		this.oDisplay = new Object();
//		this.oDisplay = sap.ui.getCore().byId("__xmlview2--list").getItems()[0].clone();
//		this.oDisplay.mProperties = sap.ui.getCore().byId("__xmlview2--list").getItems()[0].mProperties;
		
	//	var oSelectedObjectListItem = sap.ui.getCore().byId("__xmlview2--list").getItems()[0];
	//	if(oSelectedObjectListItem)
   //		this.oDisplay = oSelectedObjectListItem.clone();
								
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {	
				//parse the object Id from the context path
				 var contextPath = oEvent.getParameter("arguments").contextPath;
                 var splitArray  = contextPath.split("ordertrackCollection('");
                 var objectId    = splitArray[0].split("'")[3];
                 var sapOrigin  = splitArray[0].split("'")[1];
                 this.sapOrigin  = sapOrigin;

				//start the busy dialog
				this.busyDialog.open();
				
				this.getCartInfo(objectId);
				this.getCartItems(objectId);
				this.getApprovalDetails(objectId);
			}

		}, this);
		
		var oHeader  = this.byId("header");
		
		var oItemList= this.byId("itemList");

        if (oItemList) {
            oHeader.addEventDelegate({
                onAfterRendering: this.updateItemsList
            }, this);
        }
	},
	


	/**
	 * @public [ getHeaderFooterOptions Define Header and Footer for the Detail Screen ]
	 */
	getHeaderFooterOptions: function(){	
		

		return {
			sI18NDetailTitle: "TITLE_RECENT_CART",
			oAddBookmarkSettings : {
				title : this.oBundle.getText("TITLE_RECENT_CART"),
				icon  : "sap-icon://cart"
			},
			
			oJamOptions : {

				oShareSettings : {
					object:{
							id : this.approvalLink,
							display: this.oDisplay,
							share : this.object_ID
							}
								},
							}
				};
		},
	
	/**
	 * @private [ getCartInfo Get Information about the Shopping Cart - Header, Info tab
	 * Since the detail page is populated by different services, we explicitly 
	 * set the model for each section separately. ] 
	 * @param {[type]} objectId - Cart Id
	 */
	getCartInfo : function(objectId) {
		this.getView().byId("icontabBar").setSelectedKey("Information");
		
		var onRequestSuccess = function(oData, oResponse) {
			var oHeaderModel = new sap.ui.model.json.JSONModel(oData);
			
			if(oData.WIID != '000000000000'){
				this.approvalLink = document.location.origin + document.location.pathname + document.location.search + "#ShoppingCartItem-approve&/detail/WorkflowTaskCollection(SAP__Origin=" + jQuery.sap.encodeURL("'") + this.sapOrigin + jQuery.sap.encodeURL("'")+",WorkitemID=" + jQuery.sap.encodeURL("'") + oData.WIID + jQuery.sap.encodeURL("'")+")";

			}
			else
			{
				this.approvalLink = '';
			}
			this.object_ID = objectId;
			this.objectStatus = new sap.m.ObjectStatus({text:oData.HEADER_STATUS_DESCR});
            this.oDisplay=new sap.m.ObjectListItem({
            	title :this.oBundle.getText("CART")+" "+oData.OBJECT_ID,
            	number : oData.TOTAL_GROSS,
            	numberUnit:oData.CURRENCY,
            	firstStatus:this.objectStatus
    });

            
         var oHFOptions = this.getHeaderFooterOptions();
         this.setHeaderFooterOptions(oHFOptions);

			
			//set model for the Object Header
			this.getView().byId("header").setModel(oHeaderModel, "ShoppingCartHeader");

			//set model for the information tab
			this.getView().byId("info").setModel(oHeaderModel, "ShoppingCartInfo");								
			
			this.parseApprovalNotes();
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		oDataModel.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectId + "',DOC_MODE='DISPLAY',WIID='000000000000')",
						null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
		/**
         * @ControllerHook Extension hook for saving  
         * This hook can be used to save the fields through extensibility
         * @callback sap.ca.scfld.md.controller.BaseDetailController~extHook2
         * @return {void}  ...
        */
  	  //var extensionHook2 = this.onDataRecieved2;
  	  if(this.extHook2){
  			this.extHook2();
  	  };
	},
	
	/**
	 * @private [ updateItemsList Update the item list entries header ]
	 */
	updateItemsList: function(oEvent){
		var oSrcControl = oEvent.srcControl;
		if(oSrcControl.getModel('ShoppingCartHeader') !== undefined ){
			setTimeout(jQuery.proxy(function() {
				var itemCount   = oSrcControl.getModel('ShoppingCartHeader').getData().ITEM_COUNT;
				var headerText  = ui.s2p.srm.sc.track.util.Formatter.formatItemCount(itemCount);
				this.getView().byId("itemList").setHeaderText(headerText);
			}, this), 100);
		}
	},

	/**
	 * @private [ getCartItems Get a list of cart items ]
	 * @param {[type]} objectId - Cart id
	 */
	getCartItems : function(objectId) {
		
		var onRequestSuccess = function(oData, oResponse) {
			
			this.oItemModel = new sap.ui.model.json.JSONModel(oData);
			this.getView().byId("itemList").setModel(this.oItemModel, "ShoppingCartItems");
			
			var deliveryDateValue= ui.s2p.srm.sc.track.util.Formatter.formatMaxDeliveryDate(oData.results);
			this.getView().byId("deliv_Date").setText(deliveryDateValue);
			
			//we use a global array to keep track of product key for each of the items in a shopping cart
			ui.s2p.srm.sc.track.util.ItemList.item.clear();
			for ( var i = 0; i < oData.results.length; i++) {
				ui.s2p.srm.sc.track.util.ItemList.item.add(oData.results);
			}
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel();
        oDataModel.read("ordertrackCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectId + "')/OrderTrackItemNavigation", null,
                null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));

		
	},

	/**
	 * @private [ onDetailListItemPressed Navigate to the Item Detail Page ]
	 */
	onDetailListItemPressed : function(oEvent) {
		// Delegate event to parent controller
		var listItem = oEvent.getSource();
		var bindingContext = listItem.getBindingContext("ShoppingCartItems");
		
		var oModel   = bindingContext.getModel();
		var path     = bindingContext.getPath();
		var itemdet  = oModel.getProperty(path);
		var prodKey  = itemdet.PRODUCT_KEY;
		var objId    = itemdet.OBJECT_ID;
		var itemIndex   = oEvent.getSource().sId.split('-')[6];
		var productKey = jQuery.sap.encodeURL(itemdet.PRODUCT_KEY);
		var numberInt = itemdet.NUMBER_INT;
		var sapOriginSAP = bindingContext.getModel().getProperty(bindingContext.getPath()).SAP__Origin;

		
		// check if product key is blank
		//if (prodKey.length !== 0) {
			this.oRouter.navTo("itemDetail", {
				objectid: objId,
				numberint: numberInt,
				itemIndex: itemIndex,
				sapOrigin: sapOriginSAP
			}, true);
		//};
	},

	/**
	 * @private [ getApprovalDetails Get Details about the cart approver ]
	 */
	getApprovalDetails : function(objectId) {
		
		var onRequestSuccess = function(oData, oResponse) {
			var i;
			for(i=0;i<oData.results.length;i++)
			{
				if(oData.results[i].AGENT_ID == "" && oData.results[i].PROCESSOR_NAMES_CONC != "")
				{

					var appName = oData.results[i].PROCESSOR_NAMES_CONC.split(";");
					var appId = oData.results[i].APR_AGENT_ID.slice(1).split(';');

					var j;
					for(j=0;j<appName.length;j++)
					{
						var appClone = new Object();
						jQuery.extend(appClone, oData.results[i]);
						appClone.PROCESSOR_NAMES_CONC = appName[j];
						appClone.AGENT_ID = appName[j];
						appClone.APPROVER_ID = appId[j];
							if(j==0)
								oData.results.splice(i,1,appClone);
							else
								oData.results.splice(i,0,appClone);
						
					}
				}
				else if(oData.results[i].AGENT_ID != ""){
					var appAgntId = oData.results[i].APR_AGENT_ID.slice(1).split(';');
					if(appAgntId.length === 1 && appAgntId[0] === oData.results[i].AGENT_ID)
						oData.results[i].APPROVER_ID = oData.results[i].AGENT_ID;
				}				
				
			}			
			this.oApprovalModel = new sap.ui.model.json.JSONModel(oData);
			this.getView().byId("Approval_list").setModel(this.oApprovalModel, "peopleApproverNotes");
			this.getView().byId("approvalTab").setCount(oData.results.length);
			//this.AgentId = this.oApprovalModel.oData.results[0].AGENT_ID;
			
			//all data is fetched, close the busy dialog
			this.busyDialog.close();
		};
		
		var oDataModel = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		oDataModel.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectId + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartApprovalNavigation",
						null, null, true, jQuery.proxy(onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));
	},
	
	/**
	 * @private [ parseApprovalNotes Parse the approval notes and bind it to the icon tab ] 
	 */
	parseApprovalNotes : function() {
		
		var headerModel     = this.getView().byId("header").getModel("ShoppingCartHeader");
		var headerModelData = headerModel.getData();
		
		//Approval Note String
		var notesStr = headerModelData.APRV_NOTE;
		var parts = notesStr.split("________");
		var notes = [];
		
		var notesModel = new sap.ui.model.json.JSONModel();
		
		//parse the note String to fetch sender, timestamp and text information
		for ( var i = 0; i < parts.length; i++) {
			var part = parts[i];
			if (part.trim() === "") {
				continue;
			}
			var note = {};
			
			var userTimestampPart    = part.split("(")[1].split(')')[0].split(" ");
			var noteText             = part.slice(0).split("")[0]!=="\n" ? part.slice(0).split("(")[0] : part.slice(1).split("(")[0];
			
			note.sender    = userTimestampPart[0]!=="" ? userTimestampPart[0] : userTimestampPart[1];
			note.timestamp = userTimestampPart.slice(2).join(" ");
			note.noteText  = noteText;
			notes.push(note);
		}
		
		//if there is no notes attached to the cart, we display a message only
		//else we display the note.
		this.getView().byId("Notes").setModel(notesModel,"ApprovalNotes");
		if (notesStr.length === 0) {		
			this.getView().byId("peopleNote").setVisible(false);
		} else {
			var notesData = { notes: notes};
			notesModel.setData(notesData);
			this.getView().byId("peopleNote").setVisible(true);
			this.getView().byId("peopleNote").setCount(notes.length);
		}
	},
	
	/*
	 * FIXME: Currently we display a dummy picture, there is no service attribute 
	 * for the contact image. Once that is received, we can change the below
	 * code accordingly
	 */
	displayContactPicture : function(sValue) {
		return jQuery.sap.getModulePath("ui.s2p.srm.sc.track")+ "/img/" + "person_placeholder.png";
	},

	/**
	 * @private [ openBusinessCart Open Business Card popup on click of a agent id ]
	 */
	openBusinessCard : function(oEvent) {
		var oView = this.getView();
		
		var onRequestSuccess = function(oData, oResponse) {
			var results  = oData.results[0];
			var fullName = results.LastName;
			
			if (results.FirstName) {
				if (fullName) {
					fullName = results.FirstName + " "+ fullName;
				} else {
					fullName = results.FirstName;
				}
			}
			
			if (!fullName) {
				fullName = "";
			}
			
			var telephone = results.TELEPHONE ? results.TELEPHONE: "";
			var emailSubjectString = results.INHOUSE_MAIL;
			var companyName = results.COMPANY_NAME;
			var oEmployee = {
				name             : fullName,
				imgurl           : this.displayContactPicture(),
				department       : "",
				contactmobile    : "",
				contactphone     : telephone,
				companyname      : companyName,
				contactemail 	 : emailSubjectString,
				contactemailsubj : "",
				companyaddress   : ""
			};

			
			Object.keys(oEmployee).forEach(function(key){
					if(oEmployee[key]){
						var oControl = oView.byId("Approval_list");
						// call 'Business Card' reuse component
						var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmployee);
						oEmployeeLaunch.openBy(oControl);
						return ;
					}
				});
		};
		var str = oEvent.getSource().getBinding("sender").getContext().getPath();
		var res = str.split("/");
		var index = res[2];
		var oDataModel = this.oApplicationFacade.getODataModel("USERS_LIST");
		oDataModel.read("ALL_USERS_LIST", null,	[ "$filter=UserName eq '" + this.oApprovalModel.oData.results[index].APPROVER_ID + "'" ], false,
						jQuery.proxy(onRequestSuccess, this),jQuery.proxy(this.onRequestFailed, this));
	},
	
	/**
	 * @private [ onRequestFailed Show error message when service request fails ]
	 */
	onRequestFailed : function(oError) {
		//an error has occurred, close the busy dialog
		this.busyDialog.close();
		
		jQuery.sap.require("sap.ca.ui.message.message");
		sap.ca.ui.message.showMessageBox({
			type : sap.ca.ui.message.Type.ERROR,
			message : oError.message,
			details : oError.response.body
		});
	}




});

//sap.ushell.ui.footerbar.JamShareButton.prototype.setEnabled = function (bEnabled) {
//
//	sap.m.Button.prototype.setEnabled.call(this, bEnabled);
//
//	};

