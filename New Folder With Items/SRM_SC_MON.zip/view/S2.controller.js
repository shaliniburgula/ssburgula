/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.track.view.S2", {
	onInit: function() {
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		var m = this.oApplicationFacade.getODataModel();
		this.getView().setModel(m);
		m.setCountSupported(false);
		m.setSizeLimit(10);
		var f = [];
		var F = new sap.ui.model.odata.Filter("ADV_SEARCH_FLAG", [{
			operator: "EQ",
			value1: 'false'
		}]);
		f.push(F);
		if (this.extHookInit) {
			this.extHookInit(f)
		}
		var l = this.getList();
		var t = l.getItems()[0].clone();
		l.bindItems("/ordertrackCollection", t, null, f);
		this.registerMasterListBind(l)
	},
	setListItem: function(i) {
		var b = i.getBindingContext();
		i.setSelected(true);
		this.getList().setSelectedItem(i, true);
		this.oRouter.navTo("detail", {
			contextPath: b.getPath().substr(1),
		}, true);
		if (this.extHook1) {
			this.extHook1()
		}
	},
	applySearchPatternToListItem: function(i, f) {
		if (f.substring(0, 1) === "#") {
			var t = f.substr(1);
			var d = i.getBindingContext().getProperty("Name").toLowerCase();
			return d.indexOf(t) === 0
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f)
		}
	},
	getHeaderFooterOptions: function() {
		return {
			sI18NMasterTitle: "MASTER_TITLE",
			buttonList: []
		}
	},
	isBackendSearch: function() {
		return true
	},
	applyBackendSearchPattern: function(f, b) {
		var F = [];
		if (f) {
			F = [new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false), new sap.ui.model.Filter("DESCRIPTION", sap.ui.model
				.FilterOperator.EQ, f)]
		} else {
			F = [new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false)]
		}
		b.filter(F, sap.ui.model.FilterType.Application)
	}
});