/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");

sap.ca.scfld.md.controller.BaseDetailController
              .extend(
                           "ui.s2p.srm.sc.track.view.ItemDetail",
                           {

                                  onInit : function() {
                                         // execute the onInit for the base class
                                         // BaseDetailController
                                         sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit
                                                       .call(this);

                                         // Get instance of the busy dialog
                                         this.busyDialog = new sap.m.BusyDialog({
                                                customIcon : sap.ca.ui.images.images.Flower
                                         });

                                         // Setting the Navigate back visible true for moving
                                         // back to S3
                                         // controller
                                         // this.getView().byId("itemHeader")
                                         // .setShowNavButton(true);

                                         this.oRouter
                                                       .attachRouteMatched(
                                                                     function(oEvent) {
                                                                           if (oEvent.getParameter("name") === "itemDetail") {
                                                                        	   
                                                                                  this.objectid = oEvent.getParameter("arguments").objectid;
                                                                                  this.numberInt = oEvent.getParameter("arguments").numberint;
                                                                                  this.sapOrigin = oEvent.getParameter("arguments").sapOrigin;
                                                                                  this.initHeaderFooter(this.numberInt);
                                                                                  this.readContent(this.objectid,this.numberInt);
                                                                           }
                                                                     }, this);
                                     	//Call the account assignment category service to get the leading acc assign
                                         var onRequestSuccessAccCat = function(oData, oResponse) {                                         	
                                         	this.accCatObj = oData;  
                                         	
                                         };
                                         if(this.accCatObj == undefined){                                        	 
                                        	 var oDataModel_acc = this.oApplicationFacade.getODataModel("ACC_ASSIGN_CATEGORY");
                                        	 oDataModel_acc.read("AccountAssignmentCategoryCollection",
                                                                    null, null, true, jQuery.proxy(onRequestSuccessAccCat, this), jQuery.proxy(this.onRequestFailedAccCat, this));
                                         }
                                         //Call Unit of measure service to get the UOM text
                                         var onRequestSuccessUOM = function(oData, oResponse) {                                            	 
                                          	this.UOMObj = oData;  
                                          	
                                          };
                                         if(this.UOMObj == undefined){
                                        	 var oDataModel_acc = this.oApplicationFacade.getODataModel("UTIL");
                                        	 oDataModel_acc.read("UOMCollection",
                                                                    null, null, true, jQuery.proxy(onRequestSuccessUOM, this), jQuery.proxy(this.onRequestFailedAccCat, this));
                                         
                                         }

                                  },

                                  // Read details of a particular item by calling a service
                                  readContent : function(objectid, numberInt) {
                                         var onRequestSuccess = function(oData) {
                                                this.itemObj = oData;
                                                
                                            
                                          // Call a binding for view
                                             this.bindView();                                                
                                         };

                                         var obj = this.oApplicationFacade.getODataModel().sServiceUrl;

                                         // Since the service uses the backend service name, a
                                         // concatenation of
                                         // its name to service URL done
                                         this.oApplicationFacade.getODataModel().sServiceUrl = obj
                                                       .split(";")[0]
                                                       + ";mo";                                         
                                         this.busyDialog.open();

                                         var NUMBER_INT = numberInt, objectID = objectid;

                                         var OSRMShoppingCartDataModel = this.oApplicationFacade
                                                       .getODataModel("SRMSHOPPING_CART");
                                         var aBatchArray = new Array();
                                         var url = "SRMShoppingCartItemDataCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                                       + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                                       + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                                + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                                + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                  
                                         url = url + "/ItemAccountAssignmentNavigation";
                                         
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         url = "ShippingAddressCollection(SAP__Origin='" + this.sapOrigin + "',ItemNumber='" 
                                                       + NUMBER_INT + "',ShoppingCartID='" + objectID 
                                                       + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));

                                         
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                                + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                                + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         
                                         url = url + '/ItemAttachmentNavigation';
                                         
                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='"     + NUMBER_INT  
                                         + "',OBJECT_ID='" + objectID + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         
                                         url = url + '/ItemApproverNavigation';
                                         

                                         aBatchArray.push(OSRMShoppingCartDataModel
                                                       .createBatchOperation(url, "GET"));
                                         //to get SoS data
                                         url = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" 
                                             + NUMBER_INT + "',OBJECT_ID='" + objectID 
                                             + "',DOC_MODE='DISPLAY',WIID='000000000000')";
                                         url = url + '/SourceofSupplyNavigation';
                               
                               aBatchArray.push(OSRMShoppingCartDataModel
                                             .createBatchOperation(url, "GET"));

                                         
                                         OSRMShoppingCartDataModel
                                                       .addBatchReadOperations(aBatchArray);

                                         
                                         OSRMShoppingCartDataModel.submitBatch(jQuery.proxy(
                                                       onRequestSuccess, this), jQuery.proxy(
                                                       this.onRequestFailed, this));

                                         
                                         var onRequestSuccessNotes = function(oData, oResponse) {
                                                this.bindNotes(oData, oResponse);
                                         };
                                         
                                         
                                         /**
                                          * @ControllerHook Extension hook for saving  
                                          * This hook can be used to save the fields through extensibility
                                          * @callback sap.ca.scfld.md.controller.BaseDetailController~extHook3
                                          * @return {void}  ...
                                         */
                                   	  //var extensionHook3 = this.onDataRecieved3;
                                   	  if(this.extHook3){
                                   			this.extHook3();
                                   	  };
                                         
                                         var oDataModel1 = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
                                         oDataModel1.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + objectID + "',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartNotesNavigation?$filter=ITM_NUMBER_INT eq '" + NUMBER_INT + "'",
                                                                    null, null, true, jQuery.proxy(onRequestSuccessNotes, this), jQuery.proxy(this.onRequestFailed, this));

                                  },

                                  bindNotes : function(oData) { 
                                         var itemNotes = oData.results ;
                                         var itemSupplierNote;

                                        
                                        
                                         var oModelDetail = new sap.ui.model.json.JSONModel({
                                                'notesdata' : itemNotes                                       
                                         });
                                         this.getView().setModel(oModelDetail, "notes");

                                  },
                                  
                                  bindView : function() {
                                         // this.getApproveRejectData();                                	
                                         if(this.itemObj.__batchResponses[0].data)
                                         {
                                                var itemDetailData = this.itemObj.__batchResponses[0].data;
                                                if(this.UOMObj){
                                                	var oUOMData = this.UOMObj.results;
                                                	for(var i=0; i<oUOMData.length;i++){
                                                		if(itemDetailData.UNIT == oUOMData[i].COMMERCIAL_UNIT)
                                                			itemDetailData.UNIT_TEXT = oUOMData[i].UOM_TEXT;
                                                	}
                                                }
                                                var deliveryDateValue= ui.s2p.srm.sc.track.util.Formatter.formatDeliveryDate(itemDetailData);
                                    			this.getView().byId("deliveryDate").setText(deliveryDateValue);
                                         }
                                         
                                         
                                         if(this.itemObj.__batchResponses[1].data)
                                                {                                        	
                                        	 var itemAcc = this.itemObj.__batchResponses[1].data.results;
                                             var oAccCatObj = this.accCatObj.results;
                                             for(var i=0;i<itemAcc.length;i++){
                                            	 for(var j=0;j<oAccCatObj.length;j++){
                                            		 if(itemAcc[i].ACC_CAT == oAccCatObj[j].ACC_ASSIGN_CAT_CODE){
                                            			 itemAcc[i].acc_cat_ui = oAccCatObj[j].ACC_ASSIGN_CAT_DESC;
                                            			 itemAcc[i].acc_cat_val_ui = itemAcc[i][oAccCatObj[j].ACC_ASSIGN_FIELD];
                                            			// to get account assignment description
                                                         var desc_cat;
                                                         switch (oAccCatObj[j].ACC_ASSIGN_FIELD) {
                                                         case 'COST_CTR':
                                                           desc_cat = "CC";
                                                           break;
                                                         case 'SD_DOC':
                                                           desc_cat = "SO";                                                           
                                                           break;
                                                         case 'NETWORK':
                                                           desc_cat = "NET";                                                           
                                                           break;
                                                         case 'ORDER_NO':
                                                           desc_cat = "OR";                                                           
                                                           break;
                                                         case 'WBS_ELEM_E':
                                                           desc_cat = "WBS";                                                           
                                                           break;
                                                         case 'ASSET_NO':
                                                           desc_cat = "AS";                                                          
                                                           break;
                                                         case 'G_L_ACCT':
                                                           desc_cat = "GL";                                                           
                                                           break;
                                                         case 'ACTIVITY':
                                                           desc_cat = "ACTIVITY";                                                           
                                                           break;
                                                         case 'FUNC_AREA':
                                                           desc_cat = "FAREA";                                                           
                                                           break;
                                                         case 'FUND':
                                                           desc_cat = "FUND";                                                           
                                                           break;
                                                         case 'GRANT_NBR':
                                                           desc_cat = "GRANT";                                                           
                                                           break;
                                                         default:

                                                           break;
                                                         }

                                                         itemAcc[i].acc_cat_desc_ui = itemAcc[i][desc_cat + "_DESCRIPTION"];
                                            			                                             			
                                            		 }
                                            	 }
                                             }
                                          
		                                        	 
                                        
                                        	 
                                                }
                                         if(this.itemObj.__batchResponses[2].data)
                                                {
                                         var itemShpAdr = this.itemObj.__batchResponses[2].data;
                                                }
                                         if(this.itemObj.__batchResponses[3].data)
                                                {
                                                var itemAtt = this.itemObj.__batchResponses[3].data.results;
                                         itemAtt.splice(0,1);
                                         //itemAtt[0].FileSize = '12 KB';
                                                }
                                         if(this.itemObj.__batchResponses[4].data)
                                         {
                                                var approverData = this.itemObj.__batchResponses[4].data.results;
                                                var i;
                                    			for(i=0;i<approverData.length;i++)
                                    			{
                                    				if(approverData[i].AGENT_ID == "" && approverData[i].PROCESSOR_NAMES_CONC != "")
                                    				{

                                    					var appName = approverData[i].PROCESSOR_NAMES_CONC.split(";");                                    					
                                    					var appId = approverData[i].APR_AGENT_ID.slice(1).split(';');
                                    					var j;
                                    					for(j=0;j<appName.length;j++)
                                    					{
                                    						var appClone = new Object();
                                    						jQuery.extend(appClone, approverData[i]);
                                    						appClone.PROCESSOR_NAMES_CONC = appName[j];
                                    						appClone.AGENT_ID = appName[j];
                                    						appClone.APPROVER_ID = appId[j];
                                    							if(j==0)
                                    								approverData.splice(i,1,appClone);
                                    							else
                                    								approverData.splice(i,0,appClone);
                                    						
                                    					}
                                    				}
                                    				else if(approverData[i].AGENT_ID !== ""){
                                    					var appAgntId = approverData[i].APR_AGENT_ID.slice(1).split(';');
                                    					if(appAgntId.length === 1 && appAgntId[0] === approverData[i].AGENT_ID)
                                    						approverData[i].APPROVER_ID = approverData[i].AGENT_ID;
                                    				}
                                    				
                                    			}
                                         }
                                         if(this.itemObj.__batchResponses[5].data.results)
                                         {                                        	 
                                                var itemSoSData = this.itemObj.__batchResponses[5].data.results;
                                                var itemAssignSupplier;
                                                for ( var i = 0; i < itemSoSData.length; i++) {
                                                	if(itemSoSData[i].Supplierstatus == 'A'){
                                                		itemAssignSupplier = itemSoSData[i];
                                                		break;
                                                	}                                                		
                                                }
                                                
                                         }
                                                
                                         var oModelDetail = new sap.ui.model.json.JSONModel({
                                                'itemDetail' : itemDetailData,
                                                'shipAddr' : itemShpAdr,
                                                'account' : itemAcc,                                          
                                                'attach' : itemAtt,
                                                'approvers': approverData,
                                                'supplier':itemAssignSupplier
                                                
                                         });
                                         this.getView().setModel(oModelDetail, "itemDetailData");

                                         // this.initHeaderFooter(this.itemObj.WorkitemID);
                                         // close the busy dialog first
                                         this.busyDialog.close();

                                  
                                  },
                                  // On click of the attachment
                                  onAttachment : function(oEvent){
                                         var index = parseInt(oEvent.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
                                         var URL = this.itemObj.__batchResponses[3].data.results[index].__metadata.media_src;
                                         ui.s2p.srm.sc.track.util.Formatter.showAttachment(URL);
                                  },
                                
                              	//On click of the approver's name
                              	onApproverPress : function(oEvent) {	                              	
                              		if(oEvent.getSource().getBindingContext('itemDetailData')){
                              			var ind = parseInt(oEvent.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
                              			var arr = this.itemObj.__batchResponses[4].data.results;
                              			var selectedlistid = oEvent.getParameters().id;
                              			var oControl = this.getView().byId(selectedlistid);
                              			//this.handleUserNameClick(oControl, arr[ind].AGENT_ID);
                              			this.handleUserNameClick(oControl, arr[ind].APPROVER_ID);
                              		}
                              	},
                            	//Show Business Card on click of a name.
                            	handleUserNameClick: function(oControl, eId){
                            		//Get the Picture of the employee if exists
                            		var oPicture = this.formatEmployee(eId);
                            		var onRequestSuccess = function(oData, oRespose){                            			
                            			var oEmployee = {
                            					imgurl : oPicture,
                            					name             : oData.results[0].FullName,
                            					department       : "",
                            					contactmobile    : oData.results[0].MobilePhone,
                            					contactphone     : oData.results[0].WorkPhone,
                            					companyname      : oData.results[0].CompanyName,
                            					contactemail     : oData.results[0].EMail,
                            					contactemailsubj : "",
                            					companyaddress   : oData.results[0].AddressString
                            			};

                            			//call 'Business Card' reuse component
                            			var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmployee);
                            			oEmployeeLaunch.openBy(oControl);
                            		};			                            		
                            		var obj=this.oApplicationFacade.getODataModel("CARTAPPROVAL").sServiceUrl;
                            		
                            		var oDataModel = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
                            		//Service read for User Details retrieval
                            		oDataModel.read("UserDetailsCollection", null,
                            				[ "$filter=UserID eq '" + eId + "' and SAP__Origin eq '" +this.sapOrigin + "'"], false,
                            				  
                            				jQuery.proxy(onRequestSuccess, this),
                            				jQuery.proxy(this.onRequestFailed, this));
                            		
                            		
                            		
                            		
                            	},
                            	//Get Employee's Picure 
                            	formatEmployee : function(ApproverID){	                            		
                            	var oVar 		= "";
                        		var oServerName = this.sapOrigin.replace(/'/g, "");
                        		var oModel = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
                        		
                        		var fnSuccess = function(oData,oResponse){
                        			if(oResponse.body.length === 0){
                        				oVar = jQuery.sap.getModulePath("ui.s2p.srm.sc.track")+ "/img/" + "person_placeholder.png";
                        			}
                        			else
                        			{
                        				oVar = oResponse.requestUri;	
                        			}	
                        			oModel.sServiceUrl = oModel.sServiceUrl .split(";")[0]+";v=2;mo";
                        		};
                        		
                        		var fnError = function(oError){
                        			oVar = jQuery.sap.getModulePath("ui.s2p.srm.sc.track")+ "/img/" + "person_placeholder.png";
                        			oModel.sServiceUrl = oModel.sServiceUrl .split(";")[0]+";v=2;mo";
                        		};
                        		
                        		oModel.sServiceUrl = oModel.sServiceUrl.split(";")[0]+";v=2;o="+oServerName;
                        		oModel.read("UserDetailsCollection('" + ApproverID + "')/$value",null,null,false,jQuery.proxy(fnSuccess,this),jQuery.proxy(fnError,this));
                        	
                        		return oVar;
                            		
                            	},
                            	

                            	/**
                            	 * @private [ initHeaderFooter Initialize the back button, item navigation buttons etc.] 
                            	 */
                            	initHeaderFooter: function(objectid){
                            		var that = this;
                            		this.oHeaderFooterOptions = {
                            			onBack : function(oEvent) {
                            				var path = "ordertrackCollection(SAP__Origin='" + that.sapOrigin + "',OBJECT_ID='" + that.objectid + "')";
                                            that.oRouter.navTo("detail", {  
                                                        contextPath : path

                                        },true);
                            			},
                            			oUpDownOptions : {
                            				sI18NDetailTitle: "ITEM_AND_COUNT_EX",
                            				iPosition : 0,
                            				iCount : 0,
                            				fSetPosition : function (iNewPosition) {
                            					if ( (iNewPosition >= 0) && (iNewPosition < ui.s2p.srm.sc.track.util.ItemList.item.length() ) ) {
                            						that.objectid = ui.s2p.srm.sc.track.util.ItemList.item.getItemAtIndex(iNewPosition);
                            						that.numberInt = ui.s2p.srm.sc.track.util.ItemList.item.getSCItemNumber(iNewPosition);
                            						that.oRouter.navTo("itemDetail", {
                            							objectid   : that.objectid,
                            							numberint: that.numberInt,
                            							itemIndex: iNewPosition,
                            							sapOrigin: that.sapOrigin
                            				
                            						}, true);
                            					}
                            				}
                            			}
                            		};
                            		
                            		this.oHeaderFooterOptions.oUpDownOptions.iPosition = ui.s2p.srm.sc.track.util.ItemList.item.getIndex(that.numberInt);
                            		this.oHeaderFooterOptions.oUpDownOptions.iCount    = ui.s2p.srm.sc.track.util.ItemList.item.length();
                            		this.setHeaderFooterOptions(this.oHeaderFooterOptions);
                            	},
                            	


                           });


