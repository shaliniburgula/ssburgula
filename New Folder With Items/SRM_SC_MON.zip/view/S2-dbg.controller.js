/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */

jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("sap.ca.ui.model.format.QuantityFormat");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");

sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.track.view.S2", {	
	
    onInit : function() {
        //Execute the onInit for the base class BaseDetailController
        sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);

		//Set OData Model for the view, create the filters and bind the list 
		var oModel = this.oApplicationFacade.getODataModel();
		this.getView().setModel(oModel);
        oModel.setCountSupported(false);
        oModel.setSizeLimit(10);
        
        //The ordertrackCollection service requires two filter parameters to be passed
        //for the initial list to be populated. 
        var aFilters = [];
        
        var oFilterSearchFlag = new sap.ui.model.odata.Filter("ADV_SEARCH_FLAG", [ {
			operator : "EQ",
			value1 : 'false'
		} ]);
        aFilters.push(oFilterSearchFlag);
        
       /* var oFilterSCCount = new sap.ui.model.odata.Filter("SC_COUNT", [ {
			operator : "EQ",
			value1 : '10'
		} ]);
        aFilters.push(oFilterSCCount);*/
        
        
        /**
         * @ControllerHook Extension hook for saving  
         * This hook can be used to alter the search filters through extensibility
         * @callback sap.ca.scfld.md.controller.BaseMasterController~extHookInit
         * @param {Array} aFilters ...
         * @return {void}  ...
        */

		 if(this.extHookInit){
		  	this.extHookInit(aFilters);
		  }
        
        
        var oList = this.getList();
        var oTemplate = oList.getItems()[0].clone();
        
        oList.bindItems("/ordertrackCollection", oTemplate, null, aFilters);
        this.registerMasterListBind(oList);
    },
    
    /**
     * @public [ Navigate to the detail screen based on the user item section ]
     */
    setListItem : function(oItem) {
		var bindingContext = oItem.getBindingContext();
		oItem.setSelected(true);
		this.getList().setSelectedItem(oItem, true);
		this.oRouter.navTo("detail", {   
			contextPath : bindingContext.getPath().substr(1),
		}, true);
		
		/**
         * @ControllerHook Extension hook for saving  
         * This hook can be used to save the fields through extensibility
         * @callback sap.ca.scfld.md.controller.BaseMasterController~extHook1
         * @return {void}  ...
        */
  	  //var extensionHook1 = this.onDataRecieved1;
  	  if(this.extHook1){
  			this.extHook1();
  	  };
	},
	
	/**
	 * @public [Front-end search - filter the initial list based on user input]
	 * @param  {[type]} oItem
	 * @param  {[type]} sFilterPattern - search pattern entered in the search field
	 */
	applySearchPatternToListItem : function(oItem, sFilterPattern) {
		if (sFilterPattern.substring(0, 1) === "#") {
			var sTail = sFilterPattern.substr(1);
			var sDescr = oItem.getBindingContext().getProperty("Name").toLowerCase();
			return sDescr.indexOf(sTail) === 0;
		} else {
			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, oItem,
					sFilterPattern);
		}
	},
	
	/**
	 * @public [getHeaderFooterOptions Define header & footer options]
	 */
	getHeaderFooterOptions : function() {
		return {
			sI18NMasterTitle : "MASTER_TITLE",
			buttonList: []
		};
	},
	
    /* 
     * Enables backend search 
     */
     isBackendSearch : function() {
                     return true;
     },
     /*
     * Creates the backend filter pattern
     */
     applyBackendSearchPattern : function(sFilterPattern, oBinding) {

			var aFilters=[];
			
			if(sFilterPattern) {
			 aFilters = [
			             new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false),
			             new sap.ui.model.Filter("DESCRIPTION", sap.ui.model.FilterOperator.EQ, sFilterPattern)
			         ];
			} 
			else {
			 aFilters = [
			             new sap.ui.model.Filter("ADV_SEARCH_FLAG", sap.ui.model.FilterOperator.EQ, false)
			             /*new sap.ui.model.Filter("SC_COUNT", sap.ui.model.FilterOperator.EQ,'200')*/
			         ];
			}
			oBinding.filter(aFilters, sap.ui.model.FilterType.Application);
			}

});