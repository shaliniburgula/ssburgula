/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("ui.s2p.srm.sc.track.util.Formatter");
jQuery.sap.require("ui.s2p.srm.sc.track.util.ItemList");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
sap.ca.scfld.md.controller.BaseDetailController.extend("ui.s2p.srm.sc.track.view.ItemDetail", {
	onInit: function() {
		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.busyDialog = new sap.m.BusyDialog({
			customIcon: sap.ca.ui.images.images.Flower
		});
		this.oRouter.attachRouteMatched(function(e) {
			if (e.getParameter("name") === "itemDetail") {
				this.objectid = e.getParameter("arguments").objectid;
				this.numberInt = e.getParameter("arguments").numberint;
				this.sapOrigin = e.getParameter("arguments").sapOrigin;
				this.initHeaderFooter(this.numberInt);
				this.readContent(this.objectid, this.numberInt)
			}
		}, this);
		var o = function(D, r) {
			this.accCatObj = D
		};
		if (this.accCatObj == undefined) {
			var d = this.oApplicationFacade.getODataModel("ACC_ASSIGN_CATEGORY");
			d.read("AccountAssignmentCategoryCollection", null, null, true, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailedAccCat, this))
		}
		var a = function(D, r) {
			this.UOMObj = D
		};
		if (this.UOMObj == undefined) {
			var d = this.oApplicationFacade.getODataModel("UTIL");
			d.read("UOMCollection", null, null, true, jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailedAccCat, this))
		}
	},
	readContent: function(o, n) {
		var a = function(e) {
			this.itemObj = e;
			this.bindView()
		};
		var b = this.oApplicationFacade.getODataModel().sServiceUrl;
		this.oApplicationFacade.getODataModel().sServiceUrl = b.split(";")[0] + ";mo";
		this.busyDialog.open();
		var N = n,
			c = o;
		var O = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		var B = new Array();
		var u = "SRMShoppingCartItemDataCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')";
		B.push(O.createBatchOperation(u, "GET"));
		u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')";
		u = u + "/ItemAccountAssignmentNavigation";
		B.push(O.createBatchOperation(u, "GET"));
		u = "ShippingAddressCollection(SAP__Origin='" + this.sapOrigin + "',ItemNumber='" + N + "',ShoppingCartID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')";
		B.push(O.createBatchOperation(u, "GET"));
		u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')";
		u = u + '/ItemAttachmentNavigation';
		B.push(O.createBatchOperation(u, "GET"));
		u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')";
		u = u + '/ItemApproverNavigation';
		B.push(O.createBatchOperation(u, "GET"));
		u = "SRMShoppingCartItemCollection(SAP__Origin='" + this.sapOrigin + "',NUMBER_INT='" + N + "',OBJECT_ID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')";
		u = u + '/SourceofSupplyNavigation';
		B.push(O.createBatchOperation(u, "GET"));
		O.addBatchReadOperations(B);
		O.submitBatch(jQuery.proxy(a, this), jQuery.proxy(this.onRequestFailed, this));
		var d = function(e, r) {
			this.bindNotes(e, r)
		};
		if (this.extHook3) {
			this.extHook3()
		};
		var D = this.oApplicationFacade.getODataModel("SRMSHOPPING_CART");
		D.read("SRMShoppingCartCollection(SAP__Origin='" + this.sapOrigin + "',OBJECT_ID='" + c +
			"',DOC_MODE='DISPLAY',WIID='000000000000')/ShoppingCartNotesNavigation?$filter=ITM_NUMBER_INT eq '" + N + "'", null, null, true, jQuery
			.proxy(d, this), jQuery.proxy(this.onRequestFailed, this))
	},
	bindNotes: function(d) {
		var i = d.results;
		var a;
		var m = new sap.ui.model.json.JSONModel({
			'notesdata': i
		});
		this.getView().setModel(m, "notes")
	},
	bindView: function() {
		if (this.itemObj.__batchResponses[0].data) {
			var a = this.itemObj.__batchResponses[0].data;
			if (this.UOMObj) {
				var u = this.UOMObj.results;
				for (var i = 0; i < u.length; i++) {
					if (a.UNIT == u[i].COMMERCIAL_UNIT) a.UNIT_TEXT = u[i].UOM_TEXT
				}
			}
			var d = ui.s2p.srm.sc.track.util.Formatter.formatDeliveryDate(a);
			this.getView().byId("deliveryDate").setText(d)
		}
		if (this.itemObj.__batchResponses[1].data) {
			var b = this.itemObj.__batchResponses[1].data.results;
			var A = this.accCatObj.results;
			for (var i = 0; i < b.length; i++) {
				for (var j = 0; j < A.length; j++) {
					if (b[i].ACC_CAT == A[j].ACC_ASSIGN_CAT_CODE) {
						b[i].acc_cat_ui = A[j].ACC_ASSIGN_CAT_DESC;
						b[i].acc_cat_val_ui = b[i][A[j].ACC_ASSIGN_FIELD];
						var c;
						switch (A[j].ACC_ASSIGN_FIELD) {
							case 'COST_CTR':
								c = "CC";
								break;
							case 'SD_DOC':
								c = "SO";
								break;
							case 'NETWORK':
								c = "NET";
								break;
							case 'ORDER_NO':
								c = "OR";
								break;
							case 'WBS_ELEM_E':
								c = "WBS";
								break;
							case 'ASSET_NO':
								c = "AS";
								break;
							case 'G_L_ACCT':
								c = "GL";
								break;
							case 'ACTIVITY':
								c = "ACTIVITY";
								break;
							case 'FUNC_AREA':
								c = "FAREA";
								break;
							case 'FUND':
								c = "FUND";
								break;
							case 'GRANT_NBR':
								c = "GRANT";
								break;
							default:
								break
						}
						b[i].acc_cat_desc_ui = b[i][c + "_DESCRIPTION"]
					}
				}
			}
		}
		if (this.itemObj.__batchResponses[2].data) {
			var e = this.itemObj.__batchResponses[2].data
		}
		if (this.itemObj.__batchResponses[3].data) {
			var f = this.itemObj.__batchResponses[3].data.results;
			f.splice(0, 1)
		}
		if (this.itemObj.__batchResponses[4].data) {
			var g = this.itemObj.__batchResponses[4].data.results;
			var i;
			for (i = 0; i < g.length; i++) {
				if (g[i].AGENT_ID == "" && g[i].PROCESSOR_NAMES_CONC != "") {
					var h = g[i].PROCESSOR_NAMES_CONC.split(";");
					var k = g[i].APR_AGENT_ID.slice(1).split(';');
					var j;
					for (j = 0; j < h.length; j++) {
						var l = new Object();
						jQuery.extend(l, g[i]);
						l.PROCESSOR_NAMES_CONC = h[j];
						l.AGENT_ID = h[j];
						l.APPROVER_ID = k[j];
						if (j == 0) g.splice(i, 1, l);
						else g.splice(i, 0, l)
					}
				} else if (g[i].AGENT_ID !== "") {
					var m = g[i].APR_AGENT_ID.slice(1).split(';');
					if (m.length === 1 && m[0] === g[i].AGENT_ID) g[i].APPROVER_ID = g[i].AGENT_ID
				}
			}
		}
		if (this.itemObj.__batchResponses[5].data.results) {
			var n = this.itemObj.__batchResponses[5].data.results;
			var o;
			for (var i = 0; i < n.length; i++) {
				if (n[i].Supplierstatus == 'A') {
					o = n[i];
					break
				}
			}
		}
		var M = new sap.ui.model.json.JSONModel({
			'itemDetail': a,
			'shipAddr': e,
			'account': b,
			'attach': f,
			'approvers': g,
			'supplier': o
		});
		this.getView().setModel(M, "itemDetailData");
		this.busyDialog.close()
	},
	onAttachment: function(e) {
		var i = parseInt(e.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
		var U = this.itemObj.__batchResponses[3].data.results[i].__metadata.media_src;
		ui.s2p.srm.sc.track.util.Formatter.showAttachment(U)
	},
	onApproverPress: function(e) {
		if (e.getSource().getBindingContext('itemDetailData')) {
			var i = parseInt(e.getSource().getBindingContext('itemDetailData').sPath.split('/')[2]);
			var a = this.itemObj.__batchResponses[4].data.results;
			var s = e.getParameters().id;
			var c = this.getView().byId(s);
			this.handleUserNameClick(c, a[i].APPROVER_ID)
		}
	},
	handleUserNameClick: function(c, e) {
		var p = this.formatEmployee(e);
		var o = function(D, r) {
			var E = {
				imgurl: p,
				name: D.results[0].FullName,
				department: "",
				contactmobile: D.results[0].MobilePhone,
				contactphone: D.results[0].WorkPhone,
				companyname: D.results[0].CompanyName,
				contactemail: D.results[0].EMail,
				contactemailsubj: "",
				companyaddress: D.results[0].AddressString
			};
			var b = new sap.ca.ui.quickoverview.EmployeeLaunch(E);
			b.openBy(c)
		};
		var a = this.oApplicationFacade.getODataModel("CARTAPPROVAL").sServiceUrl;
		var d = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
		d.read("UserDetailsCollection", null, ["$filter=UserID eq '" + e + "' and SAP__Origin eq '" + this.sapOrigin + "'"], false, jQuery.proxy(
			o, this), jQuery.proxy(this.onRequestFailed, this))
	},
	formatEmployee: function(A) {
		var v = "";
		var s = this.sapOrigin.replace(/'/g, "");
		var m = this.oApplicationFacade.getODataModel("CARTAPPROVAL");
		var S = function(d, r) {
			if (r.body.length === 0) {
				v = jQuery.sap.getModulePath("ui.s2p.srm.sc.track") + "/img/" + "person_placeholder.png"
			} else {
				v = r.requestUri
			}
			m.sServiceUrl = m.sServiceUrl.split(";")[0] + ";v=2;mo"
		};
		var e = function(E) {
			v = jQuery.sap.getModulePath("ui.s2p.srm.sc.track") + "/img/" + "person_placeholder.png";
			m.sServiceUrl = m.sServiceUrl.split(";")[0] + ";v=2;mo"
		};
		m.sServiceUrl = m.sServiceUrl.split(";")[0] + ";v=2;o=" + s;
		m.read("UserDetailsCollection('" + A + "')/$value", null, null, false, jQuery.proxy(S, this), jQuery.proxy(e, this));
		return v
	},
	initHeaderFooter: function(o) {
		var t = this;
		this.oHeaderFooterOptions = {
			onBack: function(e) {
				var p = "ordertrackCollection(SAP__Origin='" + t.sapOrigin + "',OBJECT_ID='" + t.objectid + "')";
				t.oRouter.navTo("detail", {
					contextPath: p
				}, true)
			},
			oUpDownOptions: {
				sI18NDetailTitle: "ITEM_AND_COUNT_EX",
				iPosition: 0,
				iCount: 0,
				fSetPosition: function(n) {
					if ((n >= 0) && (n < ui.s2p.srm.sc.track.util.ItemList.item.length())) {
						t.objectid = ui.s2p.srm.sc.track.util.ItemList.item.getItemAtIndex(n);
						t.numberInt = ui.s2p.srm.sc.track.util.ItemList.item.getSCItemNumber(n);
						t.oRouter.navTo("itemDetail", {
							objectid: t.objectid,
							numberint: t.numberInt,
							itemIndex: n,
							sapOrigin: t.sapOrigin
						}, true)
					}
				}
			}
		};
		this.oHeaderFooterOptions.oUpDownOptions.iPosition = ui.s2p.srm.sc.track.util.ItemList.item.getIndex(t.numberInt);
		this.oHeaderFooterOptions.oUpDownOptions.iCount = ui.s2p.srm.sc.track.util.ItemList.item.length();
		this.setHeaderFooterOptions(this.oHeaderFooterOptions)
	},
});