var fileCollectionMat = new Array();

var selectedIndex = "";

var start = 0;

var i = 0;

var rowCount = 5;

jQuery.sap.require("GST.utils.Formatter");

sap.ui.controller("GST.Blocks.Material.MaterialBlockController", {

	onInit: function() {

		fileCollectionMat = new Array();

		selectedIndex = "";

		this.buildUI();

	},

	onExit: function() {},

	buildUI: function() {

		/*this.getView().byId("idMaterialTable").setModel(modelMatJson,"materialModel");*/
//uncomment
		var oUser = sap.ushell.Container.getUser();

		var user = oUser.getId();

		this.userId = user.split('V');

		//  this.userId = "500961";

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_IMP_SRV/", true, "", "");

		var goodsData = new sap.ui.model.json.JSONModel();
        //uncomment
		var path = "GoodsSupplierDetailsSet?$filter=VendorCode eq '" + this.userId[1] +	"' and (PurchasingOrg eq '1001' or PurchasingOrg eq '1002' or PurchasingOrg eq '1004' or PurchasingOrg eq '1005' or PurchasingOrg eq '1006')";
        //comment
		//var path =  "GoodsSupplierDetailsSet?$filter=VendorCode eq '505866' and (PurchasingOrg eq '1001' or PurchasingOrg eq '1002' or PurchasingOrg eq '1004' or PurchasingOrg eq '1005' or PurchasingOrg eq '1006')";

		oDataModel.read(path, null, null, false, function(r) {

			goodsData.setData(r);

		});

		this.getView().setModel(goodsData, "goodsModel");

		//this.getView().byId("idGoodsTable").setModel(goodsData,"goodsModel")

		var materialsData = new sap.ui.model.json.JSONModel();
        //uncomment
		var pathmat = "MaterialDetailsSet?$filter=VendorCode eq '" + this.userId[1] + "'";
        //comment
		 // var pathmat = "MaterialDetailsSet?$filter=VendorCode eq '505866'";

		oDataModel.read(pathmat, null, null, false, function(r) {

			materialsData.setData(r);

		});

		this.getView().setModel(materialsData, "materialModel");

		this.getView().byId("idMaterialTable").setModel(materialsData, "materialModel");

		console.log(materialsData);

		var statusJson = new sap.ui.model.json.JSONModel();

		var statusmodel = {

			results: [

				{

					"key": "0",

					"Desc": " "

          },

				{

					"key": "DTA",

					"Desc": "DTA"

          },


				{

					"key": "SEZ",

					"Desc": "SEZ"

          },

				{

					"key": "EOU",

					"Desc": "EOU"

          },

				{

					"key": "Tax Exempted",

					"Desc": "Tax Exempted"

          }, {

					"key": "Trader",

					"Desc": "Trader"

          },
          {

					"key": "Not Applicable",

					"Desc": "Not Applicable"

          }

                        ]

		};

		statusJson.setData(statusmodel);

		this.getView().setModel(statusJson, "statusmodel");

		sap.ui.getCore().setModel(statusJson, "statusmodel");

		this.populateData(0, 5);

	},

	onBeforeRendering: function() {},

	onAfterRendering: function() {

		//this.getView().byId("idGoodsTable").setModel("goodsModel")

	},

	onAttachment: function(e) {

		var id = e.getSource().getId()

		selectedIndex = parseInt(e.getSource().getId().split("idGoodsTable-")[1]);

		var model = this.getView().byId("idGoodsTable").getModel("goodsModel");

		var sPath = "/results/" + selectedIndex;

		var path = model.getProperty(sPath);

		var T = new sap.ui.model.json.JSONModel(path);

		var dialog = sap.ui.getCore().byId("idDialogUpload");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("GST.fragments.UploadDocs", this.getView().getController());

			this.getView().addDependent();

		}

		dialog.open();

		dialog.setModel(T, "ItemModel");

		if (T.oData.FileName === "") {

			var myjsonMat = new sap.ui.model.json.JSONModel();

			var mydataMat = {

				"myFiles": []

			};

			myjsonMat.setData(mydataMat);

			sap.ui.getCore().setModel("FileModel", myjsonMat);

			sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

			sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

		} else {

			myjsonMat = new sap.ui.model.json.JSONModel();

			mydataMat = {

				"myFiles": []

			};

			myjsonMat.setData(mydataMat);

			sap.ui.getCore().setModel("FileModel", myjsonMat);

			sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

			sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({

				fileName: T.oData.FileName,

				Updkz: "I"

			});

			sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

		}

	},

	onClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogUpload");

		dialog.close();

	},

	handleUploadPress: function(evt) {

		fileCollectionMat = new Array();

		var myjsonMat = new sap.ui.model.json.JSONModel();

		var mydataMat = {

			"myFiles": []

		};

		myjsonMat.setData(mydataMat);

		sap.ui.getCore().setModel("FileModel", myjsonMat);

		sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionMat = new Array();

		}

		var oView = this.getView();

		var oUploader = sap.ui.getCore().byId("fileUploaderMat");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderMat");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

						};

						fileCollectionMat.push(fileData);

						that.setFileAttachments(fileCollectionMat);

						sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

						oFileUploader.setValue("");

						var dialog = sap.ui.getCore().byId("idDialogUpload");

						//var model = sap.ui.getCore().byId("idDialogUpload").getModel("ItemModel");

						var model = that.getView().getModel("goodsModel");

						var sPath = "/results/" + selectedIndex;

						var path = model.getProperty(sPath);

						var dataModel = new sap.ui.model.json.JSONModel(path);

						var data = dataModel.getData();

						data.FileContent = base64;

						data.FileContentType = contentType;

						data.FileLength = "";

						data.FileName = filename;

						data.attachmentSet = fileCollectionMat;

						model.setProperty(sPath, data);

						//console.log(model);

						//dialog.close();

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},

	onDeleteFile: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTable-")[1]);

		var items = sap.ui.getCore().byId("idFileTable").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListMat = {};

		var assFileMat = [];

		assFileListMat["myFiles"] = assFileMat;

		var myAssFileModelMat = new sap.ui.model.json.JSONModel();

		myAssFileModelMat.setData(assFileListMat);

		var myNewModelData = myAssFileModelMat.oData.myFiles;

		items = sap.ui.getCore().byId("idFileTable").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var matData = {};

			if (delFlag === "I") {

				matData.fileName = inputValue;

				matData.Updkz = delFlag;

				myNewModelData.push(matData);

			}

		}

		sap.ui.getCore().byId("idFileTable").setModel(myAssFileModelMat);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionMat.length; j++) {

				if (fileCollectionMat[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionMat[j].FileContent,

						FileContentType: fileCollectionMat[j].FileContentType,

						FileLength: fileCollectionMat[j].FileLength,

						FileName: fileCollectionMat[j].FileName,

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionMat = newfileCollection;

		this.setFileAttachments(fileCollectionMat);

		//to remove file from model

		var model = this.getView().getModel("goodsModel");

		var sPath = "/results/" + selectedIndex;

		var path = model.getProperty(sPath);

		var dataModel = new sap.ui.model.json.JSONModel(path);

		var data = dataModel.getData();

		data.FileContent = " ";

		data.FileContentType = "";

		data.FileLength = "";

		data.FileName = "";

		data.attachmentSet = fileCollectionMat;

		model.setProperty(sPath, data);

	},

	populateData: function(start, rowCount) {

		this.getView().byId("Previous").setEnabled(true);

		this.getView().byId("Next").setEnabled(true);

		var items = this.getView().getModel("materialModel").getData();

		if (items.results.length > 0) {

			this.getView().byId("idMaterialTable").destroyItems();

			var that = this;

			for (var i = start; i < start + rowCount; i++) {

				var oJson = new sap.ui.model.json.JSONModel();

				var model = {

					codes: [















						{

							"MaterialCode": this.getView().getModel("materialModel").getProperty("/results/" + i + "/MaterialCode"),

							"MaterialText": this.getView().getModel("materialModel").getProperty("/results/" + i + "/MaterialText"),

							"ChapterID": this.getView().getModel("materialModel").getProperty("/results/" + i + "/ChapterID"),

							"HSNNumber": this.getView().getModel("materialModel").getProperty("/results/" + i + "/HSNNumber")

        }















        ]

				};

				oJson.setData(model, "materCode");

				this.getView().setModel(model, "materCode");

				sap.ui.getCore().setModel(model, "materCode");

				var valueMat = GST.utils.Formatter.leadingZeros(model.codes[0].MaterialCode);

				var oTableRow = new sap.m.ColumnListItem({

					type: "Active",

					visible: true,

					selected: true,

					cells: [































                                        new sap.m.ObjectIdentifier({

							title: valueMat

							//title:this.getView().getModel("materialModel").getProperty("/results/" + i + "/MaterialCode")

						}),







                                        new sap.m.Text({

							text: this.getView().getModel("materialModel").getProperty("/results/" + i + "/MaterialText")

						}),







                          new sap.m.Text({
							text: this.getView().getModel("materialModel").getProperty("/results/" + i + "/ChapterID")

						}),







                          new sap.m.Input({

							value: this.getView().getModel("materialModel").getProperty("/results/" + i + "/HSNNumber"),

							liveChange: function(oEvent) {

								var id = that.getView().byId("idMaterialTable").indexOfItem(oEvent.getSource().getParent()) + start;

								var hsnNumber = oEvent.mParameters.newValue;

								that.getView().getModel("materialModel").setProperty("/results/" + id + "/HSNNumber", hsnNumber);

							}

						})







]
				});

				this.getView().byId("idMaterialTable").addItem(oTableRow);

				if (i == this.getView().getModel("materialModel").getProperty("/results/length") - 1) {

					this.getView().byId("Next").setEnabled(false);

					break;

				}

			}

			if (start == 0) {

				this.getView().byId("Previous").setEnabled(false);

			}

		} else {

			this.getView().byId("Previous").setEnabled(false);

			this.getView().byId("Next").setEnabled(false);

		}

	},

	onPrevious: function() {

		start = start - rowCount;

		var tableItems = this.getView().byId("idMaterialTable").getItems();

		this.populateData(start, rowCount);

	},

	onNext: function() {

		var j;

		var tableItems = this.getView().byId("idMaterialTable").getItems();

		for (var i = 0; i < tableItems.length; i++) {

			j = start + i;

			var hsnNumber = tableItems[i].getAggregation("cells")[3].getValue();

			this.getView().getModel("materialModel").setProperty("/results/" + j + "/HSNNumber", hsnNumber);

		}

		start = start + rowCount;

		this.populateData(start, rowCount);

	},

	onChange: function(e) {

		var sId = parseInt(e.getSource().getId().split("idGoodsTable-")[1]);

		var tableItems = this.getView().byId("idGoodsTable").getItems();

		var plantStatus = tableItems[sId].getAggregation("cells")[3].getSelectedItem().getText();
		if(sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--classifVendor").getSelectedItem().getText()=="Not Applicable" && plantStatus =="Not Applicable" ){
		    tableItems[sId].getAggregation("cells")[3].setSelectedItem("0");
		    sap.m.MessageBox.alert("Please provide NA option at one place only");
		}else{
		this.getView().getModel("goodsModel").setProperty("/results/" + sId + "/PlantStatus", plantStatus);
		}
	},

	onChangeStatusDialog: function(e) {
	    var plant = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();
    	if(sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--classifVendor").getSelectedItem().getText()=="Not Applicable" && plant =="Not Applicable" ){
		    sap.ui.getCore().byId("idStatusPlant").setSelectedKey("0");
		    sap.m.MessageBox.alert("Please provide NA option at one place only");
		}
	},

	onClickAddMaterial: function(e) {

		var dialog = sap.ui.getCore().byId("idDialogGoodsSupDetails");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("GST.fragments.GoodsSupplierDetails", this.getView().getController());

			this.getView().addDependent(dialog);

		}

		dialog.open();

		dialog.setModel("statusmodel");

	},

	onGoodsDialogClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogGoodsSupDetails");

		dialog.destroy();

	},

	UploadGoodsAttch: function() {

		fileCollectionMat = new Array();

		var myjsonMat = new sap.ui.model.json.JSONModel();

		var mydataMat = {

			"myFilesGoods": []

		};

		myjsonMat.setData(mydataMat);

		sap.ui.getCore().setModel("FileModelGoods", myjsonMat);

		sap.ui.getCore().byId("idFileTableDiaGoods").setModel(myjsonMat);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionMat = new Array();
		}

		var oView = this.getView();

		var oUploader = sap.ui.getCore().byId("fileUploaderGoods");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderGoods");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

						};

						fileCollectionMat.push(fileData);

						that.setFileAttachments(fileCollectionMat);

						sap.ui.getCore().byId("idFileTableDiaGoods").getModel().getData().myFilesGoods.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTableDiaGoods").getModel().refresh(true);

						oFileUploader.setValue("");

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	onDeleteFileGoods: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTableDiaGoods-")[1]);

		var items = sap.ui.getCore().byId("idFileTableDiaGoods").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListMat = {};

		var assFileMat = [];

		assFileListMat["myFilesGoods"] = assFileMat;

		var myAssFileModelMat = new sap.ui.model.json.JSONModel();

		myAssFileModelMat.setData(assFileListMat);

		var myNewModelData = myAssFileModelMat.oData.myFilesGoods;

		items = sap.ui.getCore().byId("idFileTableDiaGoods").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var matData = {};

			if (delFlag === "I") {

				matData.fileName = inputValue;

				matData.Updkz = delFlag;

				myNewModelData.push(matData);

			}

		}

		sap.ui.getCore().byId("idFileTableDiaGoods").setModel(myAssFileModelMat);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionMat.length; j++) {

				if (fileCollectionMat[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionMat[j].FileContent,

						FileContentType: fileCollectionMat[j].FileContentType,

						FileLength: fileCollectionMat[j].FileLength,

						FileName: fileCollectionMat[j].FileName,

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionMat = newfileCollection;

		this.setFileAttachments(fileCollectionMat);

	},

	onValidation: function() {

		var r = false;

		this.errorList = [];

		this.error = 0;

		r = this.checkMandatoryFields(["idVenDesc", "idGoodsSuplCode", "idGSTNo", "idCompanyCode", "idAccGrp", "idPurOrg", "idAddNo",
    "idSt1", "idSt2", "idSt3", "idPIN", "idCity", "idCountry", "idState", "idEmailId"], this);

		if (r) {

			this.errorList = [];

			this.error = 0;

			r = this.checkValidInput();

		}

		return r;

	},

	checkMandatoryFields: function(a, c) {

		var f = null;

		var r = true;

		for (var i = 0; i < a.length; i++) {

			f = sap.ui.getCore().byId(a[i]);
           var plant = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();
			if (f) {

				if (f.getValue() === "" && plant !=="Not Applicable") {

					r = false;

					this.errorList[this.error] = a[i];

					this.error++;

					if (f.setValueState) {

						f.setValueState(sap.ui.core.ValueState.Error);

						f.setValueStateText("Mandatory field");

						r = false

					}

				} else {

					if (f.setValueState) {

						f.setValueState(sap.ui.core.ValueState.None)

					}

				}

			}

		}

		return r;

	},

	checkValidInput: function() {

		var r = true;

		if (sap.ui.getCore().byId("idVenDesc").getValue() === "") {

			sap.ui.getCore().byId("idVenDesc").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idVenDesc").setValueStateText("Invalid input");

			this.errorList[this.error] = "idVenDesc";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idVenDesc").setValueState(sap.ui.core.ValueState.None);

		}

		/*if (sap.ui.getCore().byId("idGoodsSuplCode").getValue() === "") {































      sap.ui.getCore().byId("idGoodsSuplCode").setValueState(sap.ui.core.ValueState.Error);































      sap.ui.getCore().byId("idGoodsSuplCode").setValueStateText("Invalid input");































      this.errorList[this.error] = "idGoodsSuplCode";































      this.error++;































      r = false;































    } else {































      sap.ui.getCore().byId("idGoodsSuplCode").setValueState(sap.ui.core.ValueState.None);































    }*/

		var gstNo = sap.ui.getCore().byId("idGSTNo").getValue();

		var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;
 var plant = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();
		if (!gstNo.match(gst_regExp) && plant !=="Not Applicable") {

			sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.Error);

			this.errorList[this.error] = "idGSTNo";

			this.error++;

			r = false;

		} else if (sap.ui.getCore().byId("idGSTNo").getValue() === "" && plant !=="Not Applicable") {

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idGSTNo").setValueStateText("Invalid input");

			this.errorList[this.error] = "idGSTNo";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.None);

		}

		/*  if (sap.ui.getCore().byId("idCompanyCode").getValue() === "") {































      sap.ui.getCore().byId("idCompanyCode").setValueState(sap.ui.core.ValueState.Error);































      sap.ui.getCore().byId("idCompanyCode").setValueStateText("Invalid input");































      this.errorList[this.error] = "idCompanyCode";































      this.error++;































      r = false;































    } else {































      sap.ui.getCore().byId("idCompanyCode").setValueState(sap.ui.core.ValueState.None);































    }































































    if (sap.ui.getCore().byId("idAccGrp").getValue() === "") {































      sap.ui.getCore().byId("idAccGrp").setValueState(sap.ui.core.ValueState.Error);































      sap.ui.getCore().byId("idAccGrp").setValueStateText("Invalid input");































      this.errorList[this.error] = "idAccGrp";































      this.error++;































      r = false;































    } else {































      sap.ui.getCore().byId("idAccGrp").setValueState(sap.ui.core.ValueState.None);































    }































































    if (sap.ui.getCore().byId("idPurOrg").getValue() === "") {































      sap.ui.getCore().byId("idPurOrg").setValueState(sap.ui.core.ValueState.Error);































      sap.ui.getCore().byId("idPurOrg").setValueStateText("Invalid input");































      this.errorList[this.error] = "idPurOrg";































      this.error++;































      r = false;































    } else {































      sap.ui.getCore().byId("idPurOrg").setValueState(sap.ui.core.ValueState.None);































    }*/

		if (sap.ui.getCore().byId("idAddNo").getValue() === "") {

			sap.ui.getCore().byId("idAddNo").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idAddNo").setValueStateText("Invalid input");

			this.errorList[this.error] = "idAddNo";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idAddNo").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt1").getValue() === "") {

			sap.ui.getCore().byId("idSt1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt2").getValue() === "") {

			sap.ui.getCore().byId("idSt2").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt2").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt2";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt2").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt3").getValue() === "") {

			sap.ui.getCore().byId("idSt3").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt3").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt3";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt3").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idPIN").getValue() === "") {

			sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idPIN").setValueStateText("Invalid input");

			this.errorList[this.error] = "idPIN";

			this.error++;

			r = false;

		} else {

			var pincode = sap.ui.getCore().byId("idPIN").getValue(); //content[0].mAggregations.items[1].mProperties.value

			var pin_regExp = /^[0-9]+$/;

			if (!pincode.match(pin_regExp)) {

				sap.m.MessageBox.alert("Please provide correct Postal Code");

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN";

				this.error++;

				r = false;

			} else if (pincode.length > 6) {

				sap.m.MessageBox.alert("Please enter valid Postal Code");

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.None);

			}

		}

		if (sap.ui.getCore().byId("idCity").getValue() === "") {

			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCity").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCity";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idCountry").getValue() === "") {

			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCountry").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCountry";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idState").getValue() === "") {

			sap.ui.getCore().byId("idState").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idState").setValueStateText("Invalid input");

			this.errorList[this.error] = "idState";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idState").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idEmailId").getValue() === "") {

			sap.ui.getCore().byId("idEmailId").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idEmailId").setValueStateText("Invalid input");

			this.errorList[this.error] = "idEmailId";

			this.error++;

			r = false;

		} else {

			var emailValue = sap.ui.getCore().byId("idEmailId").getValue();

			var email_regExp =
				/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5+})?$/i;

			if (!emailValue.match(email_regExp)) {

				sap.m.MessageBox.alert("Please provide Correct Email Address");

				sap.ui.getCore().byId("idEmailId").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idEmailId";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idEmailId").setValueState(sap.ui.core.ValueState.None);

			}

		}

		return r;

	},

	onFileValidation: function() {

		var attchModel = sap.ui.getCore().byId("idFileTableDiaGoods").getModel();
         var plant = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();
		if (attchModel === undefined || attchModel === "statusmodel") {
           if( plant !=="Not Applicable"){
			sap.m.MessageBox.alert("Please Upload attachments");

			return false;
		  }

		}

		return true;

	},

	onCheckStatus: function() {

		var statusSelected = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();

		if (statusSelected === " ") {

			sap.m.MessageBox.alert("Please select the Status of the Goods Supplying plant");

			return false;

		}

		return true;

	},

	onAddTable: function() {

		var result = this.onValidation();

		if (result) {

			var selectedStatus = this.onCheckStatus();

		}

		if (selectedStatus) {

			var fileCheck = this.onFileValidation();

		}

		if (fileCheck) {

		//	var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel(

		//		"goodsModel");

		var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel("goodsModel"); 

			var length = goodsModelItems.oData.results.length + 1;

			var venDes = sap.ui.getCore().byId("idVenDesc").getValue();

			var goodsCode = "" + length;

			var GSTNo = sap.ui.getCore().byId("idGSTNo").getValue();

			//var companyCode = sap.ui.getCore().byId("idCompanyCode").getValue();

			//var accGrp = sap.ui.getCore().byId("idAccGrp").getValue();

			//var purGrp = sap.ui.getCore().byId("idPurOrg").getValue();

			var plantStatus = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();

			var addressNo = sap.ui.getCore().byId("idAddNo").getValue();

			var street1 = sap.ui.getCore().byId("idSt1").getValue();

			var street2 = sap.ui.getCore().byId("idSt2").getValue();

			var street3 = sap.ui.getCore().byId("idSt3").getValue();

			var pinCode = sap.ui.getCore().byId("idPIN").getValue();

			var city = sap.ui.getCore().byId("idCity").getValue();

			var country = sap.ui.getCore().byId("idCountry").getValue();

			var state = sap.ui.getCore().byId("idState").getValue();

			var emailId = sap.ui.getCore().byId("idEmailId").getValue();
			 var plant = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();
            if (plant !=="Not Applicable") {
			var fileContent = fileCollectionMat[0].FileContent;

			var fileContentType = fileCollectionMat[0].FileContentType;

			var fileLength = fileCollectionMat[0].FileLength;

			var fileName = fileCollectionMat[0].FileName;
            }
			this.getView().byId("idGoodsTable").getModel("goodsModel").getData().results.push({
                //uncomment
				VendorCode: this.userId[1],
                //comment
                //VendorCode: "",
				GoodsSupplierCode: goodsCode,

				GSTNumber: GSTNo,

				CompanyCode: "",

				VendorAccGrp: "",

				PurchasingOrg: "",

				VendorDesc: venDes,

				AddressNo: addressNo,

				Street1: street1,

				Street2: street2,

				Street3: street3,

				PostalCode: pinCode,

				City: city,

				CountryKey: "",

				CountryTxt: country,

				StateCode: "",

				StateTxt: state,

				Email: emailId,

				FileContent: fileContent,

				FileContentType: fileContentType,

				FileLength: fileLength,

				FileName: fileName,

				PlantStatus: plantStatus

			});

			this.getView().byId("idGoodsTable").getModel("goodsModel").refresh(true);

			//var items = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();
            var items = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();
			for (var k = 0; k < goodsModelItems.oData.results.length; k++) {

				var key = goodsModelItems.oData.results[k].PlantStatus;

				items[k].getAggregation("cells")[3].setSelectedKey(key);

			}

			var dialog = sap.ui.getCore().byId("idDialogGoodsSupDetails");

			dialog.destroy();

		}

	},

	GSTNumberValid: function(oEvent)

	{

		var value = oEvent.mParameters.newValue;

		var selectedRow = parseInt(oEvent.getSource().getId().split("idGoodsTable-")[1]);

		if (value.length > 2)

		{

			var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

			if (!value.match(gst_regExp)) {

				sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

				var goodsTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

				//var goodsTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

				goodsTableItems[selectedRow].getAggregation("cells")[4].setValueState(sap.ui.core.ValueState.Error);

				goodsTableItems[selectedRow].getAggregation("cells")[4].setValueStateText("Mandatory Field");

			}

		}

	}

});