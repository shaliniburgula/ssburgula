var fileCollectionServ = new Array();

var fileCollectionServ1 = new Array();

var selectedIndex = "";

var objectServ;

sap.ui.controller("GST.Blocks.Service.ServiceBlockController", {

	onInit: function() {

		fileCollectionServ = new Array();

		fileCollectionServ1 = new Array();

		selectedIndex = "";

		this.buildUI();

	},

	onExit: function() {},

	buildUI: function() {

		/*this.getView().byId("idMaterialTable").setModel(modelMatJson,"materialModel");*/
        //uncomment
		var oUser = sap.ushell.Container.getUser();

		var user = oUser.getId();

		this.userId = user.split('V');

		var servNewList = {};

		var servObj = [];

		servNewList["myServ"] = servObj;

		var serviceDescModel = new sap.ui.model.json.JSONModel();

		serviceDescModel.setData(servNewList);

		sap.ui.getCore().setModel(serviceDescModel, "serviceDescModel")

		this.getView().byId("idServDescTable").setModel(serviceDescModel);

		//	this.userId = "500961";

		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_IMP_SRV/", true, "", "");

		var serviceData = new sap.ui.model.json.JSONModel();
        //uncomment
		var path = "GoodsSupplierDetailsSet?$filter=VendorCode eq '" + this.userId[1] + "' and PurchasingOrg eq '1003'";
        //commment
	//	var path ="GoodsSupplierDetailsSet?$filter=VendorCode eq '505866' and (PurchasingOrg eq '1001' or PurchasingOrg eq '1002' or PurchasingOrg eq '1004' or PurchasingOrg eq '1005' or PurchasingOrg eq '1006')";

		//	var path = "GoodsSupplierDetailsSet?$filter=VendorCode eq '13' and PurchasingOrg eq '1003'";

		oDataModel.read(path, null, null, false, function(r) {

			serviceData.setData(r);

		});

		this.getView().setModel(serviceData, "serviceModel");

		var modelJson = new sap.ui.model.json.JSONModel();

		var pathSer = "ServiceDetailsSet";

		oDataModel.read(pathSer, null, null, false, function(r) {

			modelJson.setData(r);

		});

		this.getView().setModel(modelJson, "sacModel");

	},

	onBeforeRendering: function() {},

	onAfterRendering: function() {},

	onAttachment: function(e) {

		var id = e.getSource().getId()

		selectedIndex = parseInt(e.getSource().getId().split("idServiceTable-")[1]);

		var model = this.getView().byId("idServiceTable").getModel("serviceModel");

		var sPath = "/results/" + selectedIndex;

		var path = model.getProperty(sPath);

		var T = new sap.ui.model.json.JSONModel(path);

		var dialog = sap.ui.getCore().byId("idDialogService");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("GST.fragments.ServiceDocs", this.getView().getController());

			this.getView().addDependent();

		}

		dialog.open();

		dialog.setModel(T, "ItemServiceModel");

		if (T.oData.FileName === "") {

			var myjsonServ = new sap.ui.model.json.JSONModel();

			var mydataServ = {

				"myFilesServ": []

			};

			myjsonServ.setData(mydataServ);

			sap.ui.getCore().setModel("FileModelServ", myjsonServ);

			sap.ui.getCore().byId("idFileTableServ").setModel(myjsonServ);

			sap.ui.getCore().byId("idFileTableServ").getModel().refresh(true);

		} else {

			myjsonServ = new sap.ui.model.json.JSONModel();

			mydataServ = {

				"myFilesServ": []

			};

			myjsonServ.setData(mydataServ);

			sap.ui.getCore().setModel("FileModelServ", myjsonServ);

			sap.ui.getCore().byId("idFileTableServ").setModel(myjsonServ);

			sap.ui.getCore().byId("idFileTableServ").getModel().getData().myFilesServ.push({

				fileName: T.oData.FileName,

				Updkz: "I"

			});

			sap.ui.getCore().byId("idFileTableServ").getModel().refresh(true);

		}

	},

	onClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogService");

		dialog.close();

	},

	handleUploadPress: function(evt) {

		fileCollectionServ = new Array();

		var myjsonServ = new sap.ui.model.json.JSONModel();

		var mydataServ = {

			"myFilesServ": []

		};

		myjsonServ.setData(mydataServ);

		sap.ui.getCore().setModel("FileModel", myjsonServ);

		sap.ui.getCore().byId("idFileTableServ").setModel(myjsonServ);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionServ = new Array();

		}

		var oUploader = sap.ui.getCore().byId("fileUploaderService");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderService");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							VendorCode: "",

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

							/*	StringUpload: "",*/

						};

						fileCollectionServ.push(fileData);

						that.setFileAttachments(fileCollectionServ);

						sap.ui.getCore().byId("idFileTableServ").getModel().getData().myFilesServ.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTableServ").getModel().refresh(true);

						oFileUploader.setValue("");

						var model = that.getView().getModel("serviceModel");

						var sPath = "/results/" + selectedIndex;

						var path = model.getProperty(sPath);

						var dataModel = new sap.ui.model.json.JSONModel(path);

						var data = dataModel.getData();

						data.FileContent = base64;

						data.FileContentType = contentType;

						data.FileLength = "";

						data.FileName = filename;

						data.attachmentSet = fileCollectionServ;

						model.setProperty(sPath, data);

						//console.log(model);

						//dialog.close();

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},

	onDeleteFile: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTableServ-")[1]);

		var items = sap.ui.getCore().byId("idFileTableServ").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListServ = {};

		var assFileServ = [];

		assFileListServ["myFilesServ"] = assFileServ;

		var myAssFileModelServ = new sap.ui.model.json.JSONModel();

		myAssFileModelServ.setData(assFileListServ);

		var myNewModelData = myAssFileModelServ.oData.myFilesServ;

		items = sap.ui.getCore().byId("idFileTableServ").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var taskData = {};

			if (delFlag === "I") {

				taskData.fileName = inputValue;

				taskData.Updkz = delFlag;

				myNewModelData.push(taskData);

			}

		}

		sap.ui.getCore().byId("idFileTableServ").setModel(myAssFileModelServ);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionServ.length; j++) {

				if (fileCollectionServ[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionServ[j].FileContent,

						FileContentType: fileCollectionServ[j].FileContentType,

						FileLength: fileCollectionServ[j].FileLength,

						FileName: fileCollectionServ[j].FileName

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionServ = newfileCollection;

		this.setFileAttachments(fileCollectionServ);

		//to remove file from model

		var model = this.getView().getModel("serviceModel");

		var sPath = "/results/" + selectedIndex;

		var path = model.getProperty(sPath);

		var dataModel = new sap.ui.model.json.JSONModel(path);

		var data = dataModel.getData();

		data.FileContent = "";

		data.FileContentType = ""

		data.FileLength = "";

		data.FileName = "";

		data.attachmentSet = fileCollectionServ;

		model.setProperty(sPath, data);

	},

	onClickAddService: function() {

		var selectedItems = this.getView().byId("idComboBox").getSelectedItems();

		var key = "",

			value = "";

		var servicesCollection = new Array();

		var oTablelength = this.getView().byId("idServDescTable").getItems().length;

		var myjsonServ = new sap.ui.model.json.JSONModel();

		var mydataServ = {};

		if (oTablelength === 0) {

			objectServ = [];

		}

		mydataServ["myServ"] = objectServ;

		myjsonServ.setData(mydataServ);

		sap.ui.getCore().setModel("serviceDescModel", myjsonServ);

		this.getView().byId("idServDescTable").setModel(myjsonServ);

		var checkDup = this.checkDuplicateServ();

		if (checkDup.length === 0) {

			for (var i = 0; i < selectedItems.length; i++) {

				key = selectedItems[i].getKey();

				value = selectedItems[i].getText();

				var sacData = {

					sacCode: key,

					serviceDescription: value,

					Updkz: "I"

				};

				servicesCollection.push(sacData);

				this.getView().byId("idServDescTable").getModel().getData().myServ.push({

					sacCode: key,

					serviceDescription: value,

					Updkz: "I"

				});

				this.getView().byId("idServDescTable").getModel().refresh(true);

			}

			this.getView().byId("idComboBox").setSelectedItems("");

		} else

		{

			sap.m.MessageBox.alert(checkDup);

		}

	},

	onClickRemoveService: function() {

		var selectedList = this.getView().byId("idServDescTable").getSelectedItems();

		for (var i = 0; i < selectedList.length; i++) {

			if (selectedList[i].getAggregation("cells")[2].getText() !== "")

				selectedList[i].getAggregation("cells")[2].setText("D");

		}

		if (selectedList.length > 0) {

			var items = this.getView().byId("idServDescTable").getItems();

			var servNewList = {};

			var servObj = [];

			servNewList["myServ"] = servObj;

			var oModelNew = new sap.ui.model.json.JSONModel();

			oModelNew.setData(servNewList);

			var oModelDataNew = oModelNew.oData.myServ;

			var count = 0;

			for (var k = 0; k < items.length; k++) {

				if (items[k].getAggregation("cells")[2].getText() === "" || items[k].getAggregation("cells")[2].getText() === "I") {

					var servData = {};

					servData.sacCode = items[k].getAggregation("cells")[0].getTitle();

					servData.serviceDescription = items[k].getAggregation("cells")[1].getText();

					servData.Updkz = items[k].getAggregation("cells")[2].getText();

					oModelDataNew.push(servData);

					count++;

				}

			}

			this.getView().byId("idServDescTable").setModel(oModelNew);

			this.getView().byId("idServDescTable").getModel().refresh(true);

			sap.ui.getCore().getModel("serviceDescModel").setData(this.getView().byId("idServDescTable").getModel().getData());

		}

		this.getView().byId("idComboBox").setSelectedItems("");

	},

	checkDuplicateServ: function()

	{

		var selectedItems = this.getView().byId("idComboBox").getSelectedItems();

		var sacCode = new Array();

		var result = "";

		for (var i = 0; i < selectedItems.length; i++)

		{

			sacCode.push(selectedItems[i].getKey());

		}

		var items = this.getView().byId("idServDescTable").getItems();

		for (var k = 0; k < items.length; k++) {

			for (var j = 0; j < sacCode.length; j++) {

				if (items[k].getAggregation("cells")[0].getTitle() === sacCode[j])

				{

					result += "The Service " + items[k].getAggregation("cells")[1].getText() + " is already added. Please remove\n";

				}

			}

		}

		return result;

	},

	onClickAddNewService: function() {

		var dialog = sap.ui.getCore().byId("idDialogServiceDetails");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("GST.fragments.ServiceDetails", this.getView().getController());

			this.getView().addDependent(dialog);

		}

		dialog.open();

	},

	onServDialogClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogServiceDetails");

		dialog.destroy();

	},

	UploadServAttch: function() {

		fileCollectionServ1 = new Array();

		var myjsonServ = new sap.ui.model.json.JSONModel();

		var mydataServ = {

			"myFilesServs": []

		};

		myjsonServ.setData(mydataServ);

		sap.ui.getCore().setModel("FileModelServs", myjsonServ);

		sap.ui.getCore().byId("idFileTableDiaServ").setModel(myjsonServ);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionServ1 = new Array();

		}

		var oView = this.getView();

		var oUploader = sap.ui.getCore().byId("fileUploaderServ");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderServ");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

						};

						fileCollectionServ1.push(fileData);

						that.setFileAttachments(fileCollectionServ1);

						sap.ui.getCore().byId("idFileTableDiaServ").getModel().getData().myFilesServs.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTableDiaServ").getModel().refresh(true);

						oFileUploader.setValue("");

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	onDeleteFileGoods: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTableDiaServ-")[1]);

		var items = sap.ui.getCore().byId("idFileTableDiaServ").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListMat = {};

		var assFileMat = [];

		assFileListMat["myFilesServs"] = assFileMat;

		var myAssFileModelMat = new sap.ui.model.json.JSONModel();

		myAssFileModelMat.setData(assFileListMat);

		var myNewModelData = myAssFileModelMat.oData.myFilesGoods;

		items = sap.ui.getCore().byId("idFileTableDiaServ").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var matData = {};

			if (delFlag === "I") {

				matData.fileName = inputValue;

				matData.Updkz = delFlag;

				myNewModelData.push(matData);

			}

		}

		sap.ui.getCore().byId("idFileTableDiaServ").setModel(myAssFileModelMat);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionServ1.length; j++) {

				if (fileCollectionServ1[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionServ1[j].FileContent,

						FileContentType: fileCollectionServ1[j].FileContentType,

						FileLength: fileCollectionServ1[j].FileLength,

						FileName: fileCollectionServ1[j].FileName,

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionServ1 = newfileCollection;

		this.setFileAttachments(fileCollectionServ1);

	},

	onValidation: function() {

		var r = false;

		this.errorList = [];

		this.error = 0;

		r = this.checkMandatoryFields(["idVenDesc1", "idGSTNo1", "idCompanyCode1", "idAccGrp1", "idPurOrg1", "idAddNo1",































    "idSte1", "idSte2", "idSte3", "idPIN1", "idCity1", "idCountry1", "idState1", "idEmailId1"], this);

		if (r) {

			this.errorList = [];

			this.error = 0;

			r = this.checkValidInput();

		}

		return r;

	},

	checkMandatoryFields: function(a, c) {

		var f = null;

		var r = true;

		for (var i = 0; i < a.length; i++) {

			f = sap.ui.getCore().byId(a[i]);

			if (f) {

				if (f.getValue() === "") {

					r = false;

					this.errorList[this.error] = a[i];

					this.error++;

					if (f.setValueState) {

						f.setValueState(sap.ui.core.ValueState.Error);

						f.setValueStateText("Mandatory field");

						r = false

					}

				} else {

					if (f.setValueState) {

						f.setValueState(sap.ui.core.ValueState.None)

					}

				}

			}

		}

		return r;

	},

	checkValidInput: function() {

		var r = true;

		if (sap.ui.getCore().byId("idVenDesc1").getValue() === "")

		{

			sap.ui.getCore().byId("idVenDesc1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idVenDesc1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idVenDesc1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idVenDesc1").setValueState(sap.ui.core.ValueState.None);

		}

		/*	if (sap.ui.getCore().byId("idGoodsSuplCode1").getValue() === "")















		{















			sap.ui.getCore().byId("idGoodsSuplCode1").setValueState(sap.ui.core.ValueState.Error);















			sap.ui.getCore().byId("idGoodsSuplCode1").setValueStateText("Invalid input");















			this.errorList[this.error] = "idGoodsSuplCode1";















			this.error++;















			r = false;















		} else {















			sap.ui.getCore().byId("idGoodsSuplCode1").setValueState(sap.ui.core.ValueState.None);















		}







*/

		var gstNo = sap.ui.getCore().byId("idGSTNo1").getValue();

		var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

		if (!gstNo.match(gst_regExp)) {

			sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

			sap.ui.getCore().byId("idGSTNo1").setValueState(sap.ui.core.ValueState.Error);

			this.errorList[this.error] = "idGSTNo1";

			this.error++;

			r = false;

		} else if (sap.ui.getCore().byId("idGSTNo1").getValue() === "")

		{

			sap.ui.getCore().byId("idGSTNo1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idGSTNo1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idGSTNo1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idGSTNo1").setValueState(sap.ui.core.ValueState.None);

		}

		/*		if (sap.ui.getCore().byId("idCompanyCode1").getValue() === "")















		{















			sap.ui.getCore().byId("idCompanyCode1").setValueState(sap.ui.core.ValueState.Error);















			sap.ui.getCore().byId("idCompanyCode1").setValueStateText("Invalid input");















			this.errorList[this.error] = "idCompanyCode1";















			this.error++;















			r = false;















		} else {















			sap.ui.getCore().byId("idCompanyCode1").setValueState(sap.ui.core.ValueState.None);















		}















		if (sap.ui.getCore().byId("idAccGrp1").getValue() === "")















		{















			sap.ui.getCore().byId("idAccGrp1").setValueState(sap.ui.core.ValueState.Error);















			sap.ui.getCore().byId("idAccGrp1").setValueStateText("Invalid input");















			this.errorList[this.error] = "idAccGrp1";















			this.error++;















			r = false;















		} else {















			sap.ui.getCore().byId("idAccGrp1").setValueState(sap.ui.core.ValueState.None);















		}















		if (sap.ui.getCore().byId("idPurOrg1").getValue() === "")















		{















			sap.ui.getCore().byId("idPurOrg1").setValueState(sap.ui.core.ValueState.Error);















			sap.ui.getCore().byId("idPurOrg1").setValueStateText("Invalid input");















			this.errorList[this.error] = "idPurOrg1";















			this.error++;















			r = false;















		} else {















			sap.ui.getCore().byId("idPurOrg1").setValueState(sap.ui.core.ValueState.None);















		}







*/

		if (sap.ui.getCore().byId("idAddNo1").getValue() === "")

		{

			sap.ui.getCore().byId("idAddNo1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idAddNo1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idAddNo1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idAddNo1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSte1").getValue() === "")

		{

			sap.ui.getCore().byId("idSte1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSte1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSte1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSte1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSte2").getValue() === "")

		{

			sap.ui.getCore().byId("idSte2").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSte2").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSte2";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSte2").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSte3").getValue() === "")

		{

			sap.ui.getCore().byId("idSte3").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSte3").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSte3";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSte3").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idPIN1").getValue() === "") {

			sap.ui.getCore().byId("idPIN1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idPIN1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idPIN1";

			this.error++;

			r = false;

		} else {

			var pincode = sap.ui.getCore().byId("idPIN1").getValue(); //content[0].mAggregations.items[1].mProperties.value

			var pin_regExp = /^[0-9]+$/;

			if (!pincode.match(pin_regExp)) {

				sap.m.MessageBox.alert("Please provide correct Postal Code");

				sap.ui.getCore().byId("idPIN1").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN1";

				this.error++;

				r = false;

			} else if (pincode.length > 6) {

				sap.m.MessageBox.alert("Please enter valid Postal Code");

				sap.ui.getCore().byId("idPIN1").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN1";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idPIN1").setValueState(sap.ui.core.ValueState.None);

			}

		}

		if (sap.ui.getCore().byId("idCity1").getValue() === "")

		{

			sap.ui.getCore().byId("idCity1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCity1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCity1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCity1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idCountry1").getValue() === "")

		{

			sap.ui.getCore().byId("idCountry1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCountry1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCountry1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCountry1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idState1").getValue() === "")

		{

			sap.ui.getCore().byId("idState1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idState1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idState1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idState1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idEmailId1").getValue() === "")

		{

			sap.ui.getCore().byId("idEmailId1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idEmailId1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idEmailId1";

			this.error++;

			r = false;

		} else {

			var emailValue = sap.ui.getCore().byId("idEmailId1").getValue();

			var email_regExp =

				/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;

			if (!emailValue.match(email_regExp)) {

				sap.m.MessageBox.alert("Please provide Correct Email Address");

				sap.ui.getCore().byId("idEmailId1").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idEmailId1";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idEmailId1").setValueState(sap.ui.core.ValueState.None);

			}

		}

		return r;

	},

	onFileValidation: function() {

		var attchModel = sap.ui.getCore().byId("idFileTableDiaServ").getModel();

		if (attchModel === undefined) {

			sap.m.MessageBox.alert("Please Upload attachments");

			return false;

		}

		return true;

	},

	onAddServTable: function() {

		var result = this.onValidation();

		if (result) {

			var fileCheck = this.onFileValidation();

		}

		if (fileCheck) {

			var servModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getModel(

				"serviceModel");

			var length = servModelItems.oData.results.length + 1;

			var venDes = sap.ui.getCore().byId("idVenDesc1").getValue();

			var goodsCode = "" + length;

			var GSTNo = sap.ui.getCore().byId("idGSTNo1").getValue();

			//var  companyCode = sap.ui.getCore().byId("idCompanyCode1").getValue();

			//var  accGrp = sap.ui.getCore().byId("idAccGrp1").getValue();

			// var  purGrp = sap.ui.getCore().byId("idPurOrg1").getValue();

			var addressNo = sap.ui.getCore().byId("idAddNo1").getValue();

			var street1 = sap.ui.getCore().byId("idSte1").getValue();

			var street2 = sap.ui.getCore().byId("idSte2").getValue();

			var street3 = sap.ui.getCore().byId("idSte3").getValue();

			var pinCode = sap.ui.getCore().byId("idPIN1").getValue();

			var city = sap.ui.getCore().byId("idCity1").getValue();

			var country = sap.ui.getCore().byId("idCountry1").getValue();

			var state = sap.ui.getCore().byId("idState1").getValue();

			var emailId = sap.ui.getCore().byId("idEmailId1").getValue();

			var fileContent = fileCollectionServ1[0].FileContent;

			var fileContentType = fileCollectionServ1[0].FileContentType;

			var fileLength = fileCollectionServ1[0].FileLength;

			var fileName = fileCollectionServ1[0].FileName;

			this.getView().byId("idServiceTable").getModel("serviceModel").getData().results.push({
                //uncommment
				VendorCode: this.userId[1],
                //comment
                //VendorCode: "505866",
				GoodsSupplierCode: goodsCode,

				GSTNumber: GSTNo,

				CompanyCode: "",

				VendorAccGrp: "",

				PurchasingOrg: "",

				VendorDesc: venDes,

				AddressNo: addressNo,

				Street1: street1,

				Street2: street2,

				Street3: street3,

				PostalCode: pinCode,

				City: city,

				CountryKey: "",

				CountryTxt: country,

				StateCode: "",

				StateTxt: state,

				Email: emailId,

				FileContent: fileContent,

				FileContentType: fileContentType,

				FileLength: fileLength,

				FileName: fileName

			});

			this.getView().byId("idServiceTable").getModel("serviceModel").refresh(true);

			var dialog = sap.ui.getCore().byId("idDialogServiceDetails");

			dialog.destroy();

		}

	},

	GSTNumberValid: function(oEvent)

	{

		var value = oEvent.mParameters.newValue;

		var selectedRow = parseInt(oEvent.getSource().getId().split("idServiceTable-")[1]);

		if (value.length > 2)

		{

			var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

			if (!value.match(gst_regExp)) {

				sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

				var servTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getItems();

				servTableItems[selectedRow].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

				servTableItems[selectedRow].getAggregation("cells")[2].setValueStateText("Mandatory Field");

			}

		}

	}

});