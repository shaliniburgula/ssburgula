sap.ui.define([

	"sap/ui/core/UIComponent",

	"sap/ui/Device",

	"GST/model/models"

], function(UIComponent, Device, models) {

	"use strict";

	return UIComponent.extend("GST.Component", {

		metadata: {

			manifest: "json",

			includes: ["css/style.css"]

		},

	
		init: function() {

			// call the base component's init function

			UIComponent.prototype.init.apply(this, arguments);

			// set the device model

			this.setModel(models.createDeviceModel(), "device");

			this.getRouter().initialize();

		}

	});

});