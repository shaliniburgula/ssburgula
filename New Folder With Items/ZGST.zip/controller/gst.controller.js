var fileCollection = new Array();

sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "GST/utils/Formatter",
    "sap/ca/scfld/md/controller/BaseDetailController",
    "sap/m/MessageBox"
], function(Controller) {

	"use strict";

	return Controller.extend("GST.controller.gst", {

		onInit: function() {

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			this._oRouter.attachRoutePatternMatched(this._handleRouteMatched, this);

			var fileCollection = new Array();

			//uncomment while deploy
			var oUser = sap.ushell.Container.getUser();

			var user = oUser.getId();

			this.userId = user.split('V');

			this.busyDialog = new sap.m.BusyDialog();

			var classifJson = new sap.ui.model.json.JSONModel();

			var classifmodel = {

				results: [







					{

						"classifi": "",

						"Desc": "Registered"

          },







					{

						"classifi": "1",

						"Desc": "Not Registered"

          },































					{

						"classifi": "2",

						"Desc": "Compounding Scheme"

          },































					{

						"classifi": "3",

						"Desc": "PSU/Government Organization"

          },
					{

						"classifi": "4",

						"Desc": "Not Applicable"

          }







                        ]

			};

			classifJson.setData(classifmodel);

			this.getView().setModel(classifJson, "classifModel");

			var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_IMP_SRV/", true, "", "");

			var persData = new sap.ui.model.json.JSONModel();
			//comment while deploy
			// var persSet = "VendorDetailsSet('505866')";
			//uncomment while deploying
			var persSet = "VendorDetailsSet('" + this.userId[1] + "')";

			oDataModel.read(persSet, null, null, false, function(r) {

				persData.setData(r);

			});

			sap.ui.getCore().setModel(persData, "persModel");

			this.getView().setModel(persData, "persModel");

			var T = this.getView().getModel("persModel");

			var materialFlag = T.oData.MaterialFlag;

			var serviceFlag = T.oData.ServiceFlag;

			if (materialFlag === "X") {

				this.getView().byId("MatVenID").setVisible(true);

			} else {

				this.getView().byId("MatVenID").setVisible(false);

			}

			if (serviceFlag === "X") {

				this.getView().byId("ServiceID").setVisible(true);

				//this.getView().byId("MatVenID").setVisible(true);

			} else {

				//this.getView().byId("MatVenID").setVisible(true);

				this.getView().byId("ServiceID").setVisible(false);

			}

		},

		onNavBack: function() {

			this._oRouter.navTo("home");

		},

		_handleRouteMatched: function(oEvent)

		{

			var oParamaeters = oEvent.getParameter("name");

			if (oParamaeters != "gstHome")

			{

				return;

			}

		},

		onAttachment: function() {

			var T = new sap.ui.model.json.JSONModel();

			var dialog = sap.ui.getCore().byId("idDialogVendor");

			if (dialog === undefined) {

				dialog = sap.ui.xmlfragment("GST.fragments.VendorDocs", this.getView().getController());

				this.getView().addDependent();

			}

			var myjsonVen = new sap.ui.model.json.JSONModel();

			T = sap.ui.getCore().getModel("persModel").getData();

			var mydataVen = {

				"myFiles": []

			};

			myjsonVen.setData(mydataVen);

			if (T.FileName === "") {

				/*  sap.ui.getCore().setModel("FileModel", myjsonVen);































        sap.ui.getCore().byId("idFileTableVendor").setModel(myjsonVen);































        sap.ui.getCore().byId("idFileTableVendor").getModel().refresh(true);*/

			} else {

				sap.ui.getCore().setModel("FileModel", myjsonVen);

				sap.ui.getCore().byId("idFileTableVendor").setModel(myjsonVen);

				sap.ui.getCore().byId("idFileTableVendor").getModel().getData().myFiles.push({

					fileName: T.FileName,

					Updkz: "I"

				});

				sap.ui.getCore().byId("idFileTableVendor").getModel().refresh(true);

			}

			dialog.open();

			dialog.setModel("persModel");

		},

		handleTypeMissmatch: function(oEvent) {

			var aFileTypes = oEvent.getSource().getFileType();

			jQuery.each(aFileTypes, function(key, value) {

				aFileTypes[key] = "*." + value

			});

			var sSupportedFileTypes = aFileTypes.join(", ");

			sap.m.MessageBox.error("The file type *." + oEvent.getParameter("fileType") +

				" is not supported. Choose one of the following types: " +

				sSupportedFileTypes);

		},

		handleValueChange: function(oEvent) {

		},

		setFileAttachments: function(files) {

			this.fileAttData = files;

		},

		getFileAttachments: function() {

			return this.fileAttData;

		},

		handleUploadComplete: function(oEvent) {

			var sResponse = oEvent.getParameter("response");

			if (sResponse) {

				var sMsg = "";

				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);

				if (m[1] == "200") {

					sMsg = "Return Code: " + m[1] + "\n" + m[2], "SUCCESS", "Upload Success";

					oEvent.getSource().setValue("");

				} else {

					sMsg = "Return Code: " + m[1] + "\n" + m[2], "ERROR", "Upload Error";

				}

				sap.m.MessageToast.show(sMsg);

			}

		},

		handleUploadPress: function(evt) {

			fileCollection = new Array();

			var myjson = new sap.ui.model.json.JSONModel();

			var mydata = {

				"myFiles": []

			};

			myjson.setData(mydata);

			//sap.ui.getCore().setModel("FileModel", myjson);

			sap.ui.getCore().byId("idFileTableVendor").setModel(myjson);

			/*var oTable = sap.ui.getCore().byId("idFileTableVendor");































































      var colItems = new sap.m.ColumnListItem({































































        type: "Active"































































      });































































      oTable.bindAggregation("items", "/myFiles", colItems);































































      var txtNAME = new sap.m.Text({































































        text: "{fileName}"































































      });































































      colItems.addCell(txtNAME);































































      var button = new sap.m.Button({































































        icon: "sap-icon://delete",































































        press: function(e) {































































          var selectedRow = parseInt(e.getSource().getId().split("idFileTableVendor-")[1]);































































          var items = sap.ui.getCore().byId("idFileTableVendor").getItems();































































          items[selectedRow].getAggregation("cells")[2].setValue("D");































































          var assFileList = {};































































          var assFile = [];































































          assFileList["myFiles"] = assFile;































































          var myAssFileModel = new sap.ui.model.json.JSONModel();































































          myAssFileModel.setData(assFileList);































































          var myNewModelData = myAssFileModel.oData.myFiles;































































          items = sap.ui.getCore().byId("idFileTableVendor").getItems();































































          for (var i = 0; i < items.length; i++) {































































            var inputValue = items[i].getAggregation("cells")[0].getText();































































            var delFlag = items[i].getAggregation("cells")[2].getValue();































































            var taskData = {};































































            if (delFlag === "I") {































































              taskData.fileName = inputValue;































































              taskData.Updkz = delFlag;































































              myNewModelData.push(taskData);































































            }































































          }































































          sap.ui.getCore().byId("idFileTableVendor").setModel(myAssFileModel);































































          var newfileCollection = new Array();































































          for (var i = 0; i < myNewModelData.length; i++) {































































            for (var j = 0; j < fileCollection.length; j++) {































































              if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {































































                var fileData = {































































                  VendorCode: fileCollection[j].VendorCode,































































                  FileContent: fileCollection[j].FileContent,































































                  FileContentType: fileCollection[j].FileContentType,































































                  FileLength: fileCollection[j].FileLength,































































                  FileName: fileCollection[j].FileName,































































                  StringUpload: fileCollection[j].StringUpload































































                };































































                newfileCollection.push(fileData);































































              }































































            }































































          }































































          fileCollection = newfileCollection;































































          this.setFileAttachments(fileCollection);































































        }































































      });































































      colItems.addCell(button);































































      var txtNAME3 = new sap.m.Input({































































        value: "{Updkz}",































































        visible: false































































      });































































      colItems.addCell(txtNAME3);































































      //end table































*/

			var getFileCollection = this.getFileAttachments();

			if (getFileCollection === null) {

				fileCollection = new Array();

			}

			var oView = this.getView();

			var oUploader = sap.ui.getCore().byId("vendorUploader");

			var oFileUploader = sap.ui.getCore().byId("vendorUploader");

			var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							// VendorCode: this.userId[1],

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename,

							StringUpload: ""

						};

						fileCollection.push(fileData);

						that.setFileAttachments(fileCollection);

						sap.ui.getCore().byId("idFileTableVendor").getModel().getData().myFiles.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTableVendor").getModel().refresh(true);

						oFileUploader.setValue("");

						var model = that.getView().getModel("persModel");

						var dataModel = new sap.ui.model.json.JSONModel();

						var data = model.getData();

						data.FileContent = base64;

						data.FileContentType = contentType;

						data.FileLength = "";

						data.FileName = filename;

						//data.attachmentSet = fileCollectionMat;

						model.setProperty(data);

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		},

		onDeleteFile: function(e) {

			var selectedRow = parseInt(e.getSource().getId().split("idFileTableVendor-")[1]);

			var items = sap.ui.getCore().byId("idFileTableVendor").getItems();

			items[selectedRow].getAggregation("cells")[2].setValue("D");

			var assFileListMat = {};

			var assFileMat = [];

			assFileListMat["myFiles"] = assFileMat;

			var myAssFileModelMat = new sap.ui.model.json.JSONModel();

			myAssFileModelMat.setData(assFileListMat);

			var myNewModelData = myAssFileModelMat.oData.myFiles;

			items = sap.ui.getCore().byId("idFileTableVendor").getItems();

			for (var i = 0; i < items.length; i++) {

				var inputValue = items[i].getAggregation("cells")[0].getText();

				var delFlag = items[i].getAggregation("cells")[2].getValue();

				var taskData = {};

				if (delFlag === "I") {

					taskData.fileName = inputValue;

					taskData.Updkz = delFlag;

					myNewModelData.push(taskData);

				}

			}

			sap.ui.getCore().byId("idFileTableVendor").setModel(myAssFileModelMat);

			var newfileCollection = new Array();

			for (var i = 0; i < myNewModelData.length; i++) {

				for (var j = 0; j < fileCollection.length; j++) {

					if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {

						var fileData = {

							FileContent: fileCollection[j].FileContent,

							FileContentType: fileCollection[j].FileContentType,

							FileLength: fileCollection[j].FileLength,

							FileName: fileCollection[j].FileName

						};

						newfileCollection.push(fileData);

					}

				}

			}

			fileCollection = newfileCollection;

			this.setFileAttachments(fileCollection);

			//to remove file from model

			var model = this.getView().getModel("persModel");

			var dataModel = new sap.ui.model.json.JSONModel();

			var data = dataModel.getData();

			model.oData.FileContent = " ";

			model.oData.FileContentType = "";

			model.oData.FileLength = "";

			model.oData.FileName = "";

			model.oData.attachmentSet = fileCollection;

			//model.setProperty(data);

		},

		onClose: function() {

			var dialog = sap.ui.getCore().byId("idDialogVendor");

			dialog.close();

		},

		onUploadVendorDocs: function() {

			var dialog = sap.ui.getCore().byId("idDialogVendor");

			dialog.close();

		},

		onAfterRendering: function() {
			//uncomment
			if (this.getView().byId("MatVenID").getVisible()) {

				var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel(

					"goodsModel");

				var items = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

				for (var k = 0; k < goodsModelItems.oData.results.length; k++) {

					var key = goodsModelItems.oData.results[k].PlantStatus;

					items[k].getAggregation("cells")[3].setSelectedKey(key);

				}

			}

		},

		checkMandatoryFields: function() {

			var result = true;

			var vendorModel = this.getView().getModel("persModel");
			if (this.getView().byId("classifVendor").getSelectedKey() !== "1" && this.getView().byId("classifVendor").getSelectedKey() !== "4") {
				if (vendorModel.oData.FileName === "")

				{

					result = false;

				}
			}

			if (this.getView().byId("MatVenID").getVisible()) {

				var goodsTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

				//var goodsTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

				if (goodsTableItems.length > 0) {

					for (var i = 0; i < goodsTableItems.length; i++) {

						if (goodsTableItems[i].getAggregation("cells")[4].getValue() === "" && goodsTableItems[i].getAggregation("cells")[3].getSelectedItem()
							.getText() !== "Not Applicable")

						{

							goodsTableItems[i].getAggregation("cells")[4].setValueState(sap.ui.core.ValueState.Error);

							goodsTableItems[i].getAggregation("cells")[4].setValueStateText("Mandatory Field");

							result = false;

						} else if (goodsTableItems[i].getAggregation("cells")[4].getValue() !== "" && goodsTableItems[i].getAggregation("cells")[3].getSelectedItem()
							.getText() !== "Not Applicable")

						{

							var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

							if (!goodsTableItems[i].getAggregation("cells")[4].getValue().match(gst_regExp)) {

								goodsTableItems[i].getAggregation("cells")[4].setValueState(sap.ui.core.ValueState.Error);

								goodsTableItems[i].getAggregation("cells")[4].setValueStateText("GST Number should have 1st two digits has numeric");

								result = false;

							} else

							{

								goodsTableItems[i].getAggregation("cells")[4].setValueState(sap.ui.core.ValueState.None);

							}

						} else if (goodsTableItems[i].getAggregation("cells")[3].getSelectedItem().getText() === "" && goodsTableItems[i].getAggregation(
							"cells")[3].getSelectedItem().getText() !== "Not Applicable") {

							result = false;

						}

					}

				}

				//var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel(
				var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel(

					"goodsModel");

				if (goodsModelItems.oData.results.length > 0) {

					for (var i = 0; i < goodsModelItems.oData.results; i++) {

						if (goodsModelItems.oData.results[i].FileName === "")

						{

							result = false;

						}

					}

				}

				/*







        var matModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idMaterialTable").getModel(







          "materialModel");















        if (matModelItems.oData.results.length > 0) {















          for (var i = 0; i < matModelItems.oData.results.length; i++) {















            if (matModelItems.oData.results[i].HSNNumber === "")















            {















              result = false;















            }















          }















        }







            */

			}

			if (this.getView().byId("ServiceID").getVisible()) {

				//var servTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getItems();
				var servTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getItems();

				if (servTableItems.length > 0) {

					for (var i = 0; i < servTableItems.length; i++) {

						if (servTableItems[i].getAggregation("cells")[2].getValue() === "")

						{

							servTableItems[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

							servTableItems[i].getAggregation("cells")[2].setValueStateText("Mandatory Field");

							result = false;

						} else if (servTableItems[i].getAggregation("cells")[2].getValue() !== "")

						{

							var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

							if (!servTableItems[i].getAggregation("cells")[2].getValue().match(gst_regExp)) {

								servTableItems[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);

								servTableItems[i].getAggregation("cells")[2].setValueStateText("GST Number should have 1st two digits has numeric");

								result = false;

							} else

							{

								servTableItems[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.None);

							}

						}

					}

				}

				//var servModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getModel(
				var servModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getModel(

					"serviceModel");

				if (servModelItems.oData.results.length > 0) {

					for (var i = 0; i < servModelItems.oData.results.length; i++) {

						if (servModelItems.oData.results[i].FileName === "")

						{

							result = false;

						}

					}

				}

			}

			return result;

		},

		onSubmit: function() {

			var gstValid = this.GSTValidation();

			var result;

			if (gstValid) {

				result = this.checkMandatoryFields();

				if (result) {

					this.getView().setBusy(true);

					jQuery.sap.delayedCall(40000, this, function() {

						var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_IMP_SRV/", true);

						var B = new Array();

						var o = function(D, r) {

							var T = new sap.ui.model.json.JSONModel(D);

							var h = {};

							if (fileCollection.length > 0) {

								h.FileContent = fileCollection[0].FileContent;

								h.FileContentType = fileCollection[0].FileContentType;

								h.FileLength = fileCollection[0].FileLength;

								h.FileName = fileCollection[0].FileName;

							} else {

								h.FileContent = T.oData.FileContent;

								h.FileContentType = T.oData.FileContentType;

								h.FileLength = T.oData.FileLength;

								h.FileName = T.oData.FileName;

							}

							h.GSTNumber = this.getView().byId("GSTNInput").getValue();

							h.VendorCode = T.oData.VendorCode;

							h.CompanyCode = T.oData.CompanyCode;

							h.VendorAccGrp = T.oData.VendorAccGrp;

							h.VendorDesc = T.oData.VendorDesc;

							h.PurchasingOrg = T.oData.PurchasingOrg;

							h.AddressNo = T.oData.AddressNo;

							h.Street1 = T.oData.Street1;

							h.Street2 = T.oData.Street2;

							h.Street3 = T.oData.Street3;

							h.PostalCode = T.oData.PostalCode;

							h.City = T.oData.City;

							h.CountryKey = T.oData.CountryKey;

							h.CountryTxt = T.oData.CountryTxt;

							h.StateCode = T.oData.StateCode;

							h.StateTxt = T.oData.StateTxt;

							h.Email = T.oData.Email;

							h.VendorClass = this.getView().byId("classifVendor").getSelectedKey();

							h.VendorClassTxt = this.getView().byId("classifVendor").getSelectedItem().getText();
							//uncomment while deploy
							B.push(dModel.createBatchOperation("VendorDetailsSet('" + this.userId[1] + "')", "PUT", h));
							//comment while deploy
							// B.push(dModel.createBatchOperation("VendorDetailsSet('505866')", "PUT", h));

							if (this.getView().byId("MatVenID").getVisible()) {

								var goodsModelItems = sap.ui.getCore().byId(

									"application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel("goodsModel");

								var goodsTableItems = sap.ui.getCore().byId(

									"application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

								for (var i = 0; i < goodsModelItems.oData.results.length; i++) {

									var goodsObj = {};

									goodsObj.VendorCode = goodsModelItems.oData.results[i].VendorCode;

									goodsObj.GoodsSupplierCode = goodsModelItems.oData.results[i].GoodsSupplierCode;

									goodsObj.CompanyCode = goodsModelItems.oData.results[i].CompanyCode;

									goodsObj.VendorAccGrp = goodsModelItems.oData.results[i].VendorAccGrp;

									goodsObj.VendorDesc = goodsModelItems.oData.results[i].VendorDesc;

									goodsObj.PurchasingOrg = goodsModelItems.oData.results[i].PurchasingOrg;

									goodsObj.AddressNo = goodsModelItems.oData.results[i].AddressNo;

									goodsObj.Street1 = goodsModelItems.oData.results[i].Street1;

									goodsObj.Street2 = goodsModelItems.oData.results[i].Street2;

									goodsObj.Street3 = goodsModelItems.oData.results[i].Street3;

									goodsObj.PostalCode = goodsModelItems.oData.results[i].PostalCode;

									goodsObj.City = goodsModelItems.oData.results[i].City;

									goodsObj.CountryKey = goodsModelItems.oData.results[i].CountryKey;

									goodsObj.CountryTxt = goodsModelItems.oData.results[i].CountryTxt;

									goodsObj.StateCode = goodsModelItems.oData.results[i].StateCode;

									goodsObj.StateTxt = goodsModelItems.oData.results[i].StateTxt;

									goodsObj.Email = goodsModelItems.oData.results[i].Email;

									goodsObj.FileContent = goodsModelItems.oData.results[i].FileContent;

									goodsObj.FileContentType = goodsModelItems.oData.results[i].FileContentType;

									goodsObj.FileLength = goodsModelItems.oData.results[i].FileLength;

									goodsObj.FileName = goodsModelItems.oData.results[i].FileName;

									goodsObj.GSTNumber = goodsTableItems[i].getAggregation("cells")[4].getValue();

									goodsObj.PlantStatus = goodsTableItems[i].getAggregation("cells")[3].getSelectedItem().getText();
									//uncomment 
									B.push(dModel.createBatchOperation("GoodsSupplierDetailsSet(VendorCode='" + this.userId[1] + "',GoodsSupplierCode='" +
										goodsObj.GoodsSupplierCode + "')", "PUT", goodsObj));
									//comment
									// B.push(dModel.createBatchOperation("GoodsSupplierDetailsSet(VendorCode='13',GoodsSupplierCode='" + goodsObj.GoodsSupplierCode +"')", "PUT", goodsObj));

								}

								var matModelItems = sap.ui.getCore().byId(

									"application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idMaterialTable").getModel("materialModel");

								for (var i = 0; i < matModelItems.oData.results.length; i++) {

									var matObj = {};

									matObj.VendorCode = matModelItems.oData.results[i].VendorCode;

									matObj.MaterialCode = matModelItems.oData.results[i].MaterialCode;

									matObj.MaterialText = matModelItems.oData.results[i].MaterialText;

									matObj.ChapterID = matModelItems.oData.results[i].ChapterID;

									matObj.HSNNumber = matModelItems.oData.results[i].HSNNumber;
									//uncomment while deploy
									B.push(dModel.createBatchOperation("MaterialDetailsSet(VendorCode='" + this.userId[1] + "',MaterialCode='" + matObj.MaterialCode +
										"')", "PUT", matObj));
									//comment while deploy
									//B.push(dModel.createBatchOperation("MaterialDetailsSet(VendorCode='505866',MaterialCode='" + matObj.MaterialCode + "')", "PUT",matObj));

								}

							}

							if (this.getView().byId("ServiceID").getVisible()) {

								var servModelItems = sap.ui.getCore().byId(

									"application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getModel("serviceModel");

								var servTableItems = sap.ui.getCore().byId(

									"application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServiceTable").getItems();

								for (var i = 0; i < servModelItems.oData.results.length; i++) {

									var servObj = {};

									servObj.VendorCode = servModelItems.oData.results[i].VendorCode;

									servObj.GoodsSupplierCode = servModelItems.oData.results[i].GoodsSupplierCode;

									servObj.CompanyCode = servModelItems.oData.results[i].CompanyCode;

									servObj.VendorAccGrp = servModelItems.oData.results[i].VendorAccGrp;

									servObj.VendorDesc = servModelItems.oData.results[i].VendorDesc;

									servObj.PurchasingOrg = servModelItems.oData.results[i].PurchasingOrg;

									servObj.AddressNo = servModelItems.oData.results[i].AddressNo;

									servObj.Street1 = servModelItems.oData.results[i].Street1;

									servObj.Street2 = servModelItems.oData.results[i].Street2;

									servObj.Street3 = servModelItems.oData.results[i].Street3;

									servObj.PostalCode = servModelItems.oData.results[i].PostalCode;

									servObj.City = servModelItems.oData.results[i].City;

									servObj.CountryKey = servModelItems.oData.results[i].CountryKey;

									servObj.CountryTxt = servModelItems.oData.results[i].CountryTxt;

									servObj.StateCode = servModelItems.oData.results[i].StateCode;

									servObj.StateTxt = servModelItems.oData.results[i].StateTxt;

									servObj.Email = servModelItems.oData.results[i].Email;

									servObj.FileContent = servModelItems.oData.results[i].FileContent;

									servObj.FileContentType = servModelItems.oData.results[i].FileContentType;

									servObj.FileLength = servModelItems.oData.results[i].FileLength;

									servObj.FileName = servModelItems.oData.results[i].FileName;

									servObj.GSTNumber = servTableItems[i].getAggregation("cells")[2].getValue();
									//uncomment
									B.push(dModel.createBatchOperation("GoodsSupplierDetailsSet(VendorCode='" + this.userId[1] + "',GoodsSupplierCode='" +
										servObj.GoodsSupplierCode + "')", "PUT", servObj));
									//comment
									//B.push(dModel.createBatchOperation("GoodsSupplierDetailsSet(VendorCode='505866',GoodsSupplierCode='" + servObj.GoodsSupplierCode +"')", "PUT", servObj));

								}

								var serviceCodeItems = sap.ui.getCore().byId(

									"application-ZGST_IMPL-change-component---gst--Serviceblock-Collapsed--idServDescTable").getModel();

								for (var j = 0; j < serviceCodeItems.oData.myServ.length; j++) {

									var serviceCodes = {};

									serviceCodes.VendorCode = T.oData.VendorCode;

									serviceCodes.SACCode = serviceCodeItems.oData.myServ[j].sacCode;

									serviceCodes.ServiceDesc = serviceCodeItems.oData.myServ[j].serviceDescription;

									B.push(dModel.createBatchOperation("ServiceDetailsSet", "POST", serviceCodes));

								}

							}

							dModel.addBatchChangeOperations(B);

							dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));

							this.busyDialog.close()

						};
						//uncomment
						dModel.read("VendorDetailsSet('" + this.userId[1] + "')", null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,
							this));
						//comment
						//dModel.read("VendorDetailsSet('505866')", null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this));

						this.getView().setBusy(false);

					});

				} else {

					sap.m.MessageBox.alert("Please enter all the mandatory fields (Attachments and Input fields) ")

				}

			}

		},

		onRequestFailed: function(e) {

			if (e.__batchResponses && e.__batchResponses.length > 0) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				this.busyDialog.close();

				sap.m.MessageBox.error(this.result.error);

			}

		},

		onRequestSuccess: function(e) {

			var that = this;

			if (e.__batchResponses && e.__batchResponses.length > 0) {

				if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

					var j = e.__batchResponses[0].response.body;

					var n = $.parseJSON(j);

					this.result = {};

					this.result.error = n.error.message.value;

					this.busyDialog.close();

					sap.m.MessageBox.error(this.result.error);

				} else {

					sap.m.MessageBox.show("Data saved Successfully", {

						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],

						onClose: function(oAction) {

							if (oAction == "OK") {

								location.reload(true);

							}

						}.bind(that)

					});

				}

			}

		},
		/*onChange: function()
		{
		  if(this.getView().byId("classifVendor").getSelectedKey() == "4")
		  {
		      this.getView().byId("application-ZGST_IMPL-change-component---gst--GSTN").setVisible(false);
		      this.getView().byId("application-ZGST_IMPL-change-component---gst--GSTNInput").setVisible(false);
		      this.getView().byId("application-ZGST_IMPL-change-component---gst--idAttachment").setVisible(false);
		  }
		},*/
		GSTValidation: function()

		{

			var result = true;

			if (this.getView().byId("GSTNInput").getValue() === "")

			{

				if (this.getView().byId("classifVendor").getSelectedKey() !== "1" && this.getView().byId("classifVendor").getSelectedKey() !== "4") {

					this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.Error);

					this.getView().byId("GSTNInput").setValueStateText("Mandatory Field");

					result = false;

				}

			} else {

				var gstNo = this.getView().byId("GSTNInput").getValue();

				var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

				if (!gstNo.match(gst_regExp)) {

					sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

					this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.Error);

					this.getView().byId("GSTNInput").setValueStateText("Mandatory Field");

					result = false;

				} else {

					this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.None);

				}

			}

			return result;

		}

	});

});