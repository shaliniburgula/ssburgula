var fileCollection = new Array();
 
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "GST/utils/Formatter",
"sap/ca/scfld/md/controller/BaseDetailController",
"sap/m/MessageBox"
], function(Controller) {
 
     "use strict";
 
     return Controller.extend("GST.controller.Home", {
 
           onInit: function() {
 
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
 
                var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_IMP_SRV/", true, "", "");
 
                var masterJson = new sap.ui.model.json.JSONModel();
 
                var masterSet = "PlantDetailsSet";
 
                oDataModel.read(masterSet, null, null, false, function(r) {
 
                     masterJson.setData(r);
 
                });
 
                sap.ui.getCore().setModel(masterJson, "masterModel");
 
                this.getView().setModel(masterJson, "masterModel");
 
           },
 
           onClickLink: function() {
 
                this.getView().setBusy(true);
 
                jQuery.sap.delayedCall(40000, this, function() {
 
                     this._oRouter.navTo("gstHome");
 
                     this.getView().setBusy(false);
 
                });
 
           },
          
           onDocClick : function(e){
               var id = e.getSource().getId()
 
           //var checked = sap.ui.getCore().byId(id).getSelected();
 
           var selectedIndex = parseInt(e.getSource().getId().split("homeTable-")[1]);
           var model = sap.ui.getCore().getModel("masterModel");
           var sPath = "/results/" + selectedIndex;
           var path = model.getProperty(sPath);
           var T = new sap.ui.model.json.JSONModel(path);
           var data = T.getData();
           var state = data.State;
          
           var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_CUST_SRV/", true);
          
           var i = "/sap/opu/odata/sap/ZGST_CUST_SRV/PlantDetailsSet('"+state+"')/$value";
          
           window.open(i,"_blank");
 
           /*   oModel.read("/PlantDetailsSet('"+state+"')/$value", null, null, function(responseBody, sucRes) {
               
 
                }, function(failRes) {
               
                     var errorBody = JSON.parse(failRes.response.body);
               
                     sap.m.MessageBox.error(errorBody.error.message.value);
 
                });*/
          
           }
 
     });
 
});