/*



 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved



 */



jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");



jQuery.sap.require("ui.s2p.srm.sc.approve.util.Formatter");



jQuery.sap.require("ui.s2p.srm.sc.approve.ZSRM_SC_APV.util.Formatter");







sap.ca.scfld.md.controller.ScfldMasterController.extend("ui.s2p.srm.sc.approve.ZSRM_SC_APV.view.S2Custom", {



	onInit: function() {



		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);



		this.registerMasterListBind(this.getList());



		var c = sap.ui.core.Component.getOwnerIdFor(this.getView());



		var C = sap.ui.component(c);



		C.oEventBus.subscribe("ui.s2p.srm.sc.approve", "approveShoppingCart", this._handleApproveCallBack, this);



		this.oRouter.attachRoutePatternMatched(function(e) {



			if (e.getParameter("name") === "detail") {



				var b = this.getBindingContextPathFor(e.getParameter("arguments"));



				var i = this.findItemByContextPath(b);



				var l = this.getList();



				var I = l.indexOfItem(i);



				var n = l.getItems()[I + 1];



				this._sNextDetailPath = n && n.getBindingContext(this.sModelName).getPath();



			}



		}, this);



	},



	_handleApproveCallBack: function(c, e, d) {



		if (!sap.ui.Device.system.phone) {



			var m = 0;



			var a = this.getList().getItems();



			for (var i = 0; i < a.length; i++) {



				if (a[i].getVisible() == true) {



					m++;



				}



			}



			if (m == 1) {



				this.showEmptyView('DETAIL_TITLE', 'VIEW_MESSGE');



			} else {



				var I = this.findItemByContextPath(this._sNextDetailPath);



				if (I) {



					this.setListItem(I);



				} else {



					if (this.getList().getItems().length > 1) {



						this.selectFirstItem();



					} else {



						this.showEmptyView();



					}



				}



			}



		} else {



			this.oRouter.navTo("master", {}, true);



		}



	},



	applySearchPatternToListItem: function(i, f) {



		if (f.substring(0, 1) === "#") {



			var t = f.substr(1);



			var d = i.getBindingContext().getProperty("Name").toLowerCase();



			return d.indexOf(t) === 0;



		} else {



			return sap.ca.scfld.md.controller.ScfldMasterController.prototype.applySearchPatternToListItem.call(null, i, f);



		} if (this.extHook4) {



			this.extHook4();



		};



	},



	getHeaderFooterOptions: function() {



		return {



			sI18NMasterTitle: "MASTER_TITLE",



			buttonList: []



		};



	}



});