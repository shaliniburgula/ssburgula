sap.ui.define([

	"sap/ui/core/mvc/Controller",

	'sap/m/MessageToast'

], function(Controller,MessageToast) {

	"use strict";



	return Controller.extend("hr.controller.Login", {



		/**

		 * Called when a controller is instantiated and its View controls (if available) are already created.

		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

		 * @memberOf hr.view.Login

		 */

			onInit: function() {

				 

			},



		/**

		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

		 * (NOT before the first rendering! onInit() is used for that one!).

		 * @memberOf hr.view.Login

		 */

		//	onBeforeRendering: function() {

		//

		//	},



		/**

		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

		 * This hook is the same one that SAPUI5 controls get after being rendered.

		 * @memberOf hr.view.Login

		 */

		//	onAfterRendering: function() {

		//

		//	},



		/**

		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.

		 * @memberOf hr.view.Login

		 */

		//	onExit: function() {

		//

		//	}

		showBusyIndicator : function (iDuration, iDelay) {

			sap.ui.core.BusyIndicator.show(iDelay);

 

			if (iDuration && iDuration > 0) {

				if (this._sTimeoutId) {

					jQuery.sap.clearDelayedCall(this._sTimeoutId);

					this._sTimeoutId = null;

				}

				

 

				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {

					this.hideBusyIndicator();

				});

			}



		},

	getUserName: function() {

    var model = this.getView().getModel();

    var sUser = model.oMetadata.sUser;

    // Display user logic here.

	},

		hideBusyIndicator : function() {

			sap.ui.core.BusyIndicator.hide();

		},

		onlogin:function(){

			var model = this.getView().getModel();

    var sUser = model.oMetadata.sUser;

			this.getUserName();

			sap.ui.getCore().username = this.getView().byId("inpLogUser").getValue();

			sap.ui.getCore().password = this.getView().byId("inpLogPass").getValue();

			

// 			var serviceUrl = "http://smgpcsaxs.mydrreddys.com:8009/sap/opu/odata/sap/ZHAP_APPRAISAL_SRV/";

//   var odatamodel = new sap.ui.model.odata.ODataModel(serviceUrl, {

// //       user: sap.ui.getCore().username,

// //       password: sap.ui.getCore().password,

//       headers: {

//         "Content-Type": "application/xml",

//         "Authorization": "Basic "+btoa(sap.ui.getCore().username + ":" + sap.ui.getCore().password) 

//       }

//       });

//       odatamodel.read("/ApprisaleheaderSet(EmpId='"+sap.ui.getCore().username+"',FiscalYear='2017-18')?$format=json", null, null, false, function(oResponse) {

// 				sap.ui.getCore().USERDATA = oResponse;

// 				alert("succ");

// 			});

			

			this.showBusyIndicator(20000, 0);

			var that=this;

			var Item = this.getView().byId("slctLogPhase");

			var item = Item._getSelectedItemText();

			

			

			this.servicecall();

			

				if(sap.ui.getCore().password=== "test" && item === "My Perfect"){

			sap.ui.core.UIComponent.getRouterFor(that).navTo("_Goalset",{});

			sap.ui.core.BusyIndicator.hide();

			

			}

		else if(sap.ui.getCore().password=== "manager" && item === "Team Appraisel"){

				sap.ui.core.UIComponent.getRouterFor(this).navTo("_Approver",{});

				sap.ui.core.BusyIndicator.hide();

			}

			else if(sap.ui.getCore().username === "half" && sap.ui.getCore().password=== "half"){

				sap.ui.core.UIComponent.getRouterFor(this).navTo("_half_year_EMP",{});

			}

			else{

				MessageToast.show("Please enter valid username or password");

				sap.ui.core.BusyIndicator.hide();

			}

		},

		servicecall: function(){

			var odatamodel = this.getView().getModel();

			odatamodel.read("/ApprisaleheaderSet(EmpId='"+sap.ui.getCore().username+"',FiscalYear='2017-18')?$format=json", null, null, false, function(oResponse) {

				sap.ui.getCore().USERDATA = oResponse;

			});

			odatamodel.read("/AppraisalGoalsSet?$filter=EmpId%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%272017-18%27", null, null, false, function(oResponse) {

				sap.ui.getCore().GOALS = oResponse;

			});

			odatamodel.read("/ReporteesListSet?$filter=EmpIdM%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%272017-18%27", null, null, false, function(oResponse) {

				sap.ui.getCore().ReporteesList = oResponse;

			});

			odatamodel.read("/ScoreCardTreeSet", null, null, false, function(oResponse) {

		    sap.ui.getCore().ScoreCardTree = oResponse;

		   });

		   odatamodel.read("/ScoreCardGoalSet", null, null, false, function(oResponse) {

		    sap.ui.getCore().ScoreCardGoalSet = oResponse;

		   });

		}



	});



});