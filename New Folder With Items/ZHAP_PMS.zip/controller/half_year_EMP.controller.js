sap.ui.define([

	"sap/ui/core/mvc/Controller"

], function(Controller) {

	"use strict";



	return Controller.extend("com.drl.pms.controller.half_year_EMP", {



		/**

		 * Called when a controller is instantiated and its View controls (if available) are already created.

		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

		 * @memberOf hr.view.half_year_EMP

		 */

			onInit: function() {

		this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

				this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

			},

					_handleRouteMatched: function() {

			this.getView().byId("Appr_reject_cmnt").setVisible(false);

			

			var tbl_func = this.getView().byId("Func_list_Apr");

			var data = [{

					wtg: "10",

					kra:"kra",

					kpi:"kpi",

					targetDt:"01-04-2017",

					startDt:"02-05-2017"



				},{

					wtg: "30",

					kra:"kra2",

					kpi:"kpi2",

					targetDt:"01-04-2017",

					startDt:"02-05-2017"



				}];

				

				var oModel5 = new sap.ui.model.json.JSONModel();

				oModel5.setData({

					modelData: data

					

				});

			

				tbl_func.setModel(oModel5);

				var objlist = this.getView().byId("func_ObjList_Apr");

				tbl_func.bindItems("/modelData", objlist);

				

				//project goal table binding

				

				var tbl_prj = this.getView().byId("Proj_list_Apr");

			var data = [{

					wtg: "20",

					kra:"kra",

					kpi:"kpi",

					targetDt:"01-04-2017",

					startDt:"02-05-2017"



				},{

					wtg: "40",

					kra:"kra2",

					kpi:"kpi2",

					targetDt:"01-04-2017",

					startDt:"02-05-2017"



				}];

				

				var oModel5 = new sap.ui.model.json.JSONModel();

				oModel5.setData({

					modelData: data

					

				});

			

				tbl_prj.setModel(oModel5);

				var objlist = this.getView().byId("proj_ObjList_Apr");

				tbl_prj.bindItems("/modelData", objlist);

		},

		mngr_submit:function(){

			var cont = this.getView().byId("cust_cont");

			var link = new sap.m.Link({text:"comment"});

			cont.setCustomContent(link);

		}





		/**

		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

		 * (NOT before the first rendering! onInit() is used for that one!).

		 * @memberOf hr.view.half_year_EMP

		 */

		//	onBeforeRendering: function() {

		//

		//	},



		/**

		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

		 * This hook is the same one that SAPUI5 controls get after being rendered.

		 * @memberOf hr.view.half_year_EMP

		 */

		//	onAfterRendering: function() {

		//

		//	},



		/**

		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.

		 * @memberOf hr.view.half_year_EMP

		 */

		//	onExit: function() {

		//

		//	}



	});



});