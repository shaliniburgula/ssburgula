sap.ui.define([

	"sap/ui/core/mvc/Controller"

], function(Controller) {

	"use strict";

	return Controller.extend("com.drl.pms.controller.AfterSubmit", {

		/**

		 * Called when a controller is instantiated and its View controls (if available) are already created.

		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.

		 * @memberOf com.drl.pms.view.AfterSubmit

		 */

		onInit: function() {

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

		},

		_handleRouteMatched: function(oEvent) {

			this.getView().byId("__text0").setText(sap.ui.getCore().Aftersubmit1);

			this.getView().byId("__text1").setText(sap.ui.getCore().Aftersubmit2);
            var language =  oEvent.getParameter("arguments").contextPath;
			var oRootPath = jQuery.sap.getModulePath("com.drl.pms");
			var oBundle;
			if(language === "RU"){
			    oBundle = new sap.ui.model.resource.ResourceModel({
				bundleUrl: oRootPath + "/i18n/i18n_ru.properties"
			});
			oBundle = oBundle._oResourceBundle;
			
			var sMsg1 = oBundle.getText("DocSubmit");

				this.getView().byId("__text0").setText(sMsg1);
				
				var sMsg2 = oBundle.getText("closeWindow");

				this.getView().byId("__text1").setText(sMsg2);

			}
			else
			{   
			    oBundle = new sap.ui.model.resource.ResourceModel({
				bundleUrl: oRootPath + "/i18n/i18n_en.properties"
			});
			oBundle = oBundle._oResourceBundle;
			var sMsg1 = oBundle.getText("DocSubmit");

				this.getView().byId("__text0").setText(sMsg1);
				
				var sMsg2 = oBundle.getText("closeWindow");

				this.getView().byId("__text1").setText(sMsg2);

			    
			}
		}

		/**

		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered

		 * (NOT before the first rendering! onInit() is used for that one!).

		 * @memberOf com.drl.pms.view.AfterSubmit

		 */

		//	onBeforeRendering: function() {

		//

		//	},

		/**

		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.

		 * This hook is the same one that SAPUI5 controls get after being rendered.

		 * @memberOf com.drl.pms.view.AfterSubmit

		 */

		//	onAfterRendering: function() {

		//

		//	},

		/**

		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.

		 * @memberOf com.drl.pms.view.AfterSubmit

		 */

		//	onExit: function() {

		//

		//	}

	});

});