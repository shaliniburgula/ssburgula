sap.ui.define([
	'jquery.sap.global',"sap/ui/core/mvc/Controller",'sap/ui/model/json/JSONModel'
], function(JQuery,Controller,JSONModel) {
	"use strict";

	return Controller.extend("StandardTile.controller.View1", {
	onInit : function () {
			// set mock model
			var sPath = jQuery.sap.getModulePath("StandardTile.model", "/data.json");
			var oModel = new JSONModel(sPath);
			this.getView().setModel(oModel);
			console.log(oModel);
		}
	});

});