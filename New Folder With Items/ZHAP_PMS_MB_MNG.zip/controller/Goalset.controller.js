sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/Dialog',
	'sap/m/Button',
	'sap/m/MessageToast'
], function(Controller, Dialog, Button, MessageToast) {
	

	return Controller.extend("com.drl.pmsManagermobile.controller.Goalset", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.drl.pmsManagermobile.view.Goalset
		 */
		onInit: function() {
			window.onbeforeunload = function(evt) {
			    var message = 'Kindly logout before closing the browser';
			    if (typeof evt == 'undefined') {
			        evt = window.event;
			    }
			    if (evt) {
			        evt.returnValue = message;
			    }

			    return message;
			};
			window.beforeunload = function(evt) {
			    var message = 'Kindly Logout before Closing the Web Browser';
			    if (typeof evt == 'undefined') {
			        evt = window.event;
			    }
			    if (evt) {
			        evt.returnValue = message;
			    }

			    return message;
			} ;
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

			var state = [{
				state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
				value: 10
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Negative,
				value: 20
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
				value: 30
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Planned,
				value: 40
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Critical,
				value: 50
			}];

			var oDataProcessFlowLanesOnly = {
				lanes: [{
					id: "0",
					icon: "sap-icon://customize",
					label: "Goal Setting",
					position: 0,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
						value: 10
					}]
				}, {
					id: "1",
					icon: "sap-icon://com.drl.pmsManagermobile-approval",
					label: "Goal Approval",
					position: 1
				}, {
					id: "2",
					icon: "sap-icon://survey",
					label: "Half Yearly",
					position: 2
				},
				//, {
				// 	id: "3",
				// 	icon: "sap-icon://activity-assigned-to-goal",
				// 	label: "Goal Revisit",
				// 	position: 3
				// }, {
				// 	id: "4",
				// 	icon: "sap-icon://com.drl.pmsManagermobile-approval",
				// 	label: "Goal Approval",
				// 	position: 4
				// }, 
				{
					id: "6",
					icon: "sap-icon://approvals",
					label: "Annual Review",
					position: 3
				}, {
					id: "7",
					icon: "sap-icon://monitor-payments",
					label: "ARC",
					position: 4
				}, {
					id: "8",
					icon: "sap-icon://signature",
					label: "Final Sign Off",
					position: 5
				}]
			};

			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");

			viewPf2.byId("processflow2").updateModel();

		},
		showBusyIndicator : function (iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);
 
			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}
				
 
				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {
					this.hideBusyIndicator();
				});
			}

		},
		hideBusyIndicator : function() {
			sap.ui.core.BusyIndicator.hide();
		},
		onprint:function(){
			var table = "<!DOCTYPE html>"
+"<html xmlns='http://www.w3.org/1999/xhtml'>"
+"<head>"
+"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
+"<title>Dr. Reddy's</title>"


+"</head>"

+"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>"
+"<div style='border:1px solid #666; padding:0 30px;'>"
+"<div style='padding:10px;'>"
+"<img src='image/phot.png' alt='Dr. Reddy's' title='Dr. Reddy's' />"
+"</div>"
+"<div style='margin-bottom:10px;'>"
+"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>Performance Management 2017-18</h1>"
+"<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Introduction</h2>"
+"<p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; line-height:20px;'>Performance Review Form! </p>"
+"<p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; line-height:20px;'>Performance management helps the organization achieve desired business results. It helps employees understand how they are</p>"
+"<p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; line-height:20px;'>contributing to the organization’s goals, what’s expected of them, how they are doing, and how they can continue to grow, </p>"
+"<p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; line-height:20px;'>develop, and add value to the business. </p>"
+"<p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; line-height:20px;'>Performance management brings all the employees under a single strategic umbrella. Most importantly, it gives managers and </p>"
+"<p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; line-height:20px;'>team members an equal opportunity to express themselves. </p>"
+"</div>"
+"<div style='margin-bottom:10px;'>"
+"<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Employee Information</h2>"
+"<table width='100%' border='0' style='margin:0 0 10px 0;'>";
var EmpData = sap.ui.getCore().USERDATA ;

var Fname = EmpData.EmpName;
var EmpCode = EmpData.EmpId;
var Desig = EmpData.DesignText;
var Unit = EmpData.UnitTex;
var Depart = EmpData.DepartText;
var band = EmpData.BandText;
var L_1 = EmpData.ApprName;
var L_2 = EmpData.OtherName;
var Mmngr = EmpData.PartApprName;

table+= "<tr>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>First Name:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>"+Fname+"</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>Last Name:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>&nbsp;</p></td>"
+  "</tr>"
+  "<tr>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>Employee Number:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>"+EmpCode+"</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>Designation:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>"+Desig+"</p></td>"
+  "</tr>"
+  "<tr>"
+     "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>Date of Joining:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>&nbsp;</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>Department:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>"+Depart+"</p></td>"
+  "</tr>"
 + "<tr>"
  +   "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>"
   + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>"+L_1+"</p></td>"
    +"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1 Designation:</strong></p></td>"
    +"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'></p></td>"
  +"</tr>"
 + "<tr>"
 +    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>"
 +   "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>"+L_2+"</p></td>"
 +   "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2 Designation:</strong></p></td>"
 +   "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>&nbsp;</p></td>"
 + "</tr>"
+"</table>"
+"</div>"
+"<div style='margin-bottom:10px;'>"
+"<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>Goals</h2>"
+"<table width='100%' border='0' style='margin:0 0 10px 0;'>";
 
   
  var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list");
  var data= func_goal.getModel().getData().modelData;
  for(var i=0;i<data.length;i++){
  	
	table+= "<tr>"
    +"<td colspan='2'><h4 style='font-size:15px; padding:0 10px; margin:0;'>"+data[i].KraText+"</h4></td>"
  +"</tr>"
   +"<tr>"
    +"<td colspan='2'><p style='font-size:12px; text-align:justify; margin-bottom:5px; margin-top: 0px; padding:0 10px;'></p></td>"
  +"</tr>"
+"</table>"
+"<com.drl.pmsManagermobile/>"
+"<h3 style='font-size:20px; padding:5px 10px; margin: 0;'>Goal Details</h3>"
+"<table width='100%' border='0' style='margin:0 0 10px 0;'>"
+  "<tr>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Start Date:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>&nbsp;</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Target Date:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>"+data[i].GoalDate+"</p></td>"
+  "</tr>"
+  "<tr>"
+     "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Weight:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>"+data[i].Weightage+"</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Measure/KPI:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>"+data[i].KpiText+"</p></td>"
+  "</tr>"

+"</table>"
+"<com.drl.pmsManagermobile/>";
}
  var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list");
  var data= func_goal.getModel().getData().modelData;
  for(var i=0;i<data.length;i++){
  	
	table+= "<tr>"
    +"<td colspan='2'><h4 style='font-size:15px; padding:0 10px; margin:0;'>"+data[i].KraText+"</h4></td>"
  +"</tr>"
   +"<tr>"
    +"<td colspan='2'><p style='font-size:12px; text-align:justify; margin-bottom:5px; margin-top: 0px; padding:0 10px;'></p></td>"
  +"</tr>"
+"</table>"
+"<com.drl.pmsManagermobile/>"
+"<h3 style='font-size:20px; padding:5px 10px; margin: 0;'>Goal Details</h3>"
+"<table width='100%' border='0' style='margin:0 0 10px 0;'>"
+  "<tr>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Start Date:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>&nbsp;</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Target Date:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>"+data[i].GoalDate+"</p></td>"
+  "</tr>"
+  "<tr>"
+     "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Weight:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>"+data[i].Weightage+"</p></td>"
+    "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>Measure/KPI:</strong></p></td>"
+    "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>"+data[i].KpiText+"</p></td>"
+  "</tr>"

+"</table>"
+"<com.drl.pmsManagermobile/>";
}
table+="</div>"
+"</div>"
+"</body>"
+"</html>";
var ua = window.navigator.userAgent;
									    var msie = ua.indexOf("MSIE ");
										
										if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))  // If Internet Explorer, return version number
									    {
											var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
										    var printDocument = printPreview.document;
										    printDocument.open();
										    printDocument.write(table);
										    printDocument.close();
									    }
									    else if(ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0)
									    	{
									    	var wind=window.open("","PrintWindow","width=900px,height=900px");
											wind.document.write(table);
											wind.print();
											wind.close();
									    	}

		},
		handlePressOpenMenu: function(oEvent) {
			var oButton = oEvent.getSource();

			// create menu only once
			if (!this._menu) {
				this._menu = sap.ui.xmlfragment(
					"com.drl.pmsManagermobile.view.Menu",
					this
				);
				this.getView().addDependent(this._menu);
				if(sap.ui.getCore().USERDATA.BandText==="R4"||sap.ui.getCore().USERDATA.BandText==="R5"||sap.ui.getCore().USERDATA.BandText==="R6"||sap.ui.getCore().USERDATA.BandText==="R7A"||sap.ui.getCore().USERDATA.BandText==="R7B"||sap.ui.getCore().USERDATA.BandText==="R8"||sap.ui.getCore().USERDATA.BandText==="CEO"||sap.ui.getCore().USERDATA.BandText==="COO"||sap.ui.getCore().USERDATA.BandText==="Chairman"){
				     sap.ui.getCore().byId("mnuscore").setVisible(true);
				    }
				    else{
				     sap.ui.getCore().byId("mnuscore").setVisible(false);
				    }
			}

			var eDock = sap.ui.core.Popup.Dock;
			this._menu.open(this._bKeyboard, oButton, eDock.BeginTop, eDock.BeginBottom, oButton);
		},
		handle_fun_own: function(oEvent) {
			var oView = sap.ui.getCore().ODThis.getView();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "dd-MMM-yyyy"
									});
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Owngoal", this);
				var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("fungoal_progInd");
				var value = progressBR.getPercentValue();
				fungoal_progInd.setDisplayValue("Overall Weightage "+value+" %");
				fungoal_progInd.setPercentValue(value);
				if(0<=value && value<=40){
							fungoal_progInd.setState("Error");
						}
						else if(41<=value && value<=80){
							fungoal_progInd.setState("Warning");
						}
						else if(81<=value && value<=100){
							fungoal_progInd.setState("Success");
						}
				
				var start_date = oView.byId("DP2_start");
				var year = new Date().getFullYear();
				var statDt = new Date(year+"-04-01");
				start_date.setValue(oDateFormat.format(statDt));
				//31-03-2018
				var end_date = oView.byId("DP2");
				var year = new Date().getFullYear()+1;
				var endDt = new Date(year+"-03-31");
				end_date.setValue(oDateFormat.format(endDt));
				
				// start_date.setMinDate(new Date("2017-04-01 11:12"));
				// start_date.setMaxDate(new Date("2018-03-31 11:12"));
				
				// end_date.setMaxDate(endDt);
				// end_date.setMinDate(statDt);
				
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			oDialog.open();
		},
		handleChange:function(){
			var oView = sap.ui.getCore().ODThis.getView();
				var start_date = oView.byId("DP2_start");
				var end_date = oView.byId("DP2");
				var year = new Date().getFullYear();
				var statDt = new Date(year+"-04-01 00:00:00");
				var year2 = new Date().getFullYear()+1;
				var endDt = new Date(year2+"-03-31 00:00:00");
				var Sel_date = new Date(start_date.getValue());
				var Sel_date_tr = new Date(end_date.getValue());
				if(Sel_date < statDt || Sel_date > endDt){
					this.getView().byId("DP2_start").setValueState("Error");
					this.getView().byId("DP2_start").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
				}
				else{
					this.getView().byId("DP2_start").setValueState("None");
				}
				if(Sel_date_tr < statDt || Sel_date_tr > endDt){
					this.getView().byId("DP2").setValueState("Error");
					this.getView().byId("DP2").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
				}
				else{
					this.getView().byId("DP2").setValueState("None");
				}
				
			
		},
		handleChange_proj:function(){
			var oView = sap.ui.getCore().ODThis.getView();
				var start_date = oView.byId("DP2_start_proj");
				var end_date = oView.byId("DP2_proj");
				var year = new Date().getFullYear();
				var statDt = new Date(year+"-04-01 00:00:00");
				var year2 = new Date().getFullYear()+1;
				var endDt = new Date(year2+"-03-31 00:00:00");
				var Sel_date = new Date(start_date.getValue());
				var Sel_Enddate = new Date(end_date.getValue());
				if(Sel_date < statDt || Sel_date > endDt){
					this.getView().byId("DP2_start_proj").setValueState("Error");
					this.getView().byId("DP2_start_proj").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
				}
				else{
					this.getView().byId("DP2_proj").setValueState("None");
				}
				if(Sel_Enddate < statDt || Sel_Enddate > endDt){
					this.getView().byId("DP2_proj").setValueState("Error");
					this.getView().byId("DP2_proj").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
				}else{
					this.getView().byId("DP2_proj").setValueState("None");
				}
				
			
		},

		handle_proj_own: function(oEvent) {
			var oView = sap.ui.getCore().ODThis.getView();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "dd-MMM-yyyy"
									});
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Owngoal_proj", this);
				
				var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("projgoal_progInd");
				var value = progressBR.getPercentValue();
						fungoal_progInd.setDisplayValue("Overall Weightage "+value+" %");
						fungoal_progInd.setPercentValue(value);
						if(0<=value && value<=40){
							fungoal_progInd.setState("Error");
						}
						else if(41<=value && value<=80){
							fungoal_progInd.setState("Warning");
						}
						else if(81<=value && value<=100){
							fungoal_progInd.setState("Success");
						}
						
				// var start_date = oView.byId("DP2_start_proj");
				// start_date.setValue(oDateFormat.format(new Date()));
				
				var start_date = oView.byId("DP2_start_proj");
				var year = new Date().getFullYear();
				var statDt = new Date(year+"Apr-01");
				start_date.setValue(oDateFormat.format(statDt));
				
				//31-03-2018
				var end_date = oView.byId("DP2_proj");
				var year = new Date().getFullYear()+1;
				var endDt = new Date(year+"Mar-31");
				end_date.setValue(oDateFormat.format(endDt));
				
				// start_date.setMaxDate(endDt);
				// start_date.setMinDate(statDt);
				// end_date.setMaxDate(endDt);
				// end_date.setMinDate(statDt);
						
				// connect dialog to view (models, lifecycle)
				//	this.getView().byId("IntVal").setValue("Add Project Name , Project Manager Name");
				oView.addDependent(oDialog);
			}

			oDialog.open();
		},
		_handleRouteMatched: function() {
			
		try{
    		 //sap.ui.getCore().username = sap.ushell.Container.getUser().getId();
			 sap.ui.getCore().username = 'P00003061';
    		 this.servicecall();
    		 if(sap.ui.getCore().USERDATA.ApStatusSub =="3"){
				    var a = this.getView().byId("func_ObjList");
				    var b = this.getView().byId("proj_ObjList");
				    var a1 = this.getView().byId("Func_list");
				    var b1 = this.getView().byId("Proj_list");
				    a.setType("Inactive");
				    b.setType("Inactive");
				    a1.setMode("None");
				    b1.setMode("None");
				    //save and submit button disabl code
				    this.getView().byId("btn_save_goalSet").setEnabled(false);
    				this.getView().byId("btn_submit_GoalSet").setEnabled(false);
    				
    				this.getView().byId("openMenu").setEnabled(false);
    				this.getView().byId("GOAL_LIB").setEnabled(false);
    				
				   }
				   else{
				    var a = this.getView().byId("func_ObjList");
				    var b = this.getView().byId("proj_ObjList");
				     var a1 = this.getView().byId("Func_list");
				    var b1 = this.getView().byId("Proj_list");
				    a.setType("Active");
				    b.setType("Active");
				    a1.setMode("Delete");
				    b1.setMode("Delete");
				    //save and submit button disabl code
				    this.getView().byId("btn_save_goalSet").setEnabled(true);
    				this.getView().byId("btn_submit_GoalSet").setEnabled(true);
				    
				    this.getView().byId("openMenu").setEnabled(true);
    				this.getView().byId("GOAL_LIB").setEnabled(true);
				    
				   }
			
			var view = this.getView();
			sap.ui.getCore().ODThis = this;
			view.getController().aData = [];
			view.getController().aData_proj = [];
			sap.ui.getCore().cntwtg = 0;
			
			var progressBR = this.getView().byId("Proc_indicator");
				
			this.getView().getController().setHeaderDet();
			this.getView().getController().goalsGET();
			
			//Overall Weightage calculation 
				var goals= sap.ui.getCore().GOALS.results;
				
				if(goals !== undefined){
						
						var wtg_calc = 0;
						for (var i = 0; i < goals.length; i++) {
							wtg_calc = wtg_calc + parseInt(goals[i].Weightage);
						}
						progressBR.setDisplayValue("Overall Weightage "+wtg_calc+" %");
						progressBR.setPercentValue(wtg_calc);
						
						//color logic for progres bar
						if(0<=wtg_calc && wtg_calc<=40){
							progressBR.setState("Error");
						}
						else if(41<=wtg_calc && wtg_calc<=80){
							progressBR.setState("Warning");
						}
						else if(81<=wtg_calc && wtg_calc<=100){
							progressBR.setState("Success");
						}
						
						
				}
				var userInfo = sap.ui.getCore().USERDATA;
				if(userInfo.ApStatus === "2" && userInfo.ApStatusSub === "3"){
						var oDataProcessFlowLanesOnly = {
				lanes: [{
					id: "0",
					icon: "sap-icon://accept",
					label: "Goal Setting",
					position: 0,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
						value: 10
					}]
				}, {
					id: "1",
					icon: "sap-icon://com.drl.pmsManagermobile-approval",
					label: "Goal Approval",
					position: 1,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
						value: 10
					}]
				}, {
					id: "2",
					icon: "sap-icon://survey",
					label: "Half Yearly",
					position: 2
				},
				//, {
				// 	id: "3",
				// 	icon: "sap-icon://activity-assigned-to-goal",
				// 	label: "Goal Revisit",
				// 	position: 3
				// }, {
				// 	id: "4",
				// 	icon: "sap-icon://com.drl.pmsManagermobile-approval",
				// 	label: "Goal Approval",
				// 	position: 4
				// }, 
				{
					id: "6",
					icon: "sap-icon://approvals",
					label: "Annual Review",
					position: 3
				}, {
					id: "7",
					icon: "sap-icon://monitor-payments",
					label: "ARC",
					position: 4
				}, {
					id: "8",
					icon: "sap-icon://signature",
					label: "Final Sign Off",
					position: 5
				}]
			};

			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");

			viewPf2.byId("processflow2").updateModel();
				}
}catch(e){console.log(e);}
		},
		goalsGET: function(){
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
			var goals= sap.ui.getCore().GOALS.results;
			var functionalGoals = [];
			var projectGoals = [];
			for(var i=0;i<goals.length;i++){
				if(goals[i].GoalId ==='0001'){
					functionalGoals.push(goals[i]);
				}
				else if(goals[i].GoalId ==='0002'){
					projectGoals.push(goals[i]);
				}
			}
			//functional goal set
						var dat = sap.ui.getCore().ODThis.getView().getController().aData;
						dat = dat.concat(functionalGoals);
						sap.ui.getCore().ODThis.getView().getController().aData = dat;
						var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var oModel = new sap.ui.model.json.JSONModel();
						var dt = [];
						
						for(var ii=0;ii<dat.length;ii++){
							var wtg = parseInt(dat[ii].Weightage);
							dt.push({
								"EmpId": dat[ii].EmpId,
								"GoalId":dat[ii]. GoalId,
								"GoalItemId":dat[ii].GoalItemId,
								"GoalName": dat[ii].GoalName,
								"Weightage": wtg + "%",
								"KraText": dat[ii].KraText,
								"KpiText": dat[ii].KpiText,
								"GoalDate":oDateFormat.format(dat[ii].GoalDate),
								"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
							});
						}
						oModel.setData({
							modelData: dt
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
						list.bindItems("/modelData", objlist);
				
			
			//project goal set
						dat = sap.ui.getCore().ODThis.getView().getController().aData_proj;
						dat = dat.concat(projectGoals);
						sap.ui.getCore().ODThis.getView().getController().aData_proj = dat;
						list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
						oModel = new sap.ui.model.json.JSONModel();
						dt = [];
						
						for(ii=0;ii<dat.length;ii++){
							wtg = parseInt(dat[ii].Weightage);
							dt.push({
								"EmpId": dat[ii].EmpId,
								"GoalId":dat[ii]. GoalId,
								"GoalItemId":dat[ii].GoalItemId,
								"GoalName": dat[ii].GoalName,
								"Weightage": wtg + "%",
								"KraText": dat[ii].KraText,
								"KpiText": dat[ii].KpiText,
								"GoalDate": oDateFormat.format(dat[ii].GoalDate),
								"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
							});
						}
						oModel.setData({
							modelData: dt
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList");
						list.bindItems("/modelData", objlist);
						
				// 			var userInfo = sap.ui.getCore().USERDATA;
				// if(userInfo.ApStatus === "2" && userInfo.ApStatusSub === "3"){
				// 	this.getView().byId("func_ObjList").setType("Inactive");
				// 	this.getView().byId("proj_ObjList").setType("Inactive");
				// }
				// else{
				// 	this.getView().byId("func_ObjList").setType("Active");
				// 	this.getView().byId("proj_ObjList").setType("Active");
				// }
		},
		
		setHeaderDet: function(){
			var HDR_INFO = sap.ui.getCore().USERDATA;
			this.byId("HD").setObjectTitle(HDR_INFO.EmpName+" |");
			this.byId("HD").setObjectSubtitle(HDR_INFO.DesignText);
			this.byId("HD").setObjectImageURI(sap.ui.getCore().USERDATA.EmpImage);
			this.byId("HD_empcode").setText(" : "+HDR_INFO.EmpId);
			this.byId("HD_roleB").setText(" : "+HDR_INFO.BandText);
			this.byId("HD_dept").setText(" : "+HDR_INFO.DepartText);
			this.byId("HD_unit").setText(" : "+HDR_INFO.UnitText);
			this.byId("HD_mngNM").setText(" : "+HDR_INFO.ApprName);
			this.byId("HD_revNM").setText(" : "+HDR_INFO.OtherName);
			this.byId("HD_mmngr").setText(" : "+HDR_INFO.PartApprName);
			
		},

			onBeforeRendering: function() {},
			servicecall: function(){
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
			var odatamodel = this.getView().getModel();
			odatamodel.read("/ApprisaleheaderSet(EmpId='"+sap.ui.getCore().username+"',FiscalYear='2017-18')?$format=json", null, null, false, function(oResponse) {
				sap.ui.getCore().USERDATA = oResponse;
			});
			odatamodel.read("/AppraisalGoalsSet?$filter=EmpId%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%272017-18%27", null, null, false, function(oResponse) {
				sap.ui.getCore().GOALS = oResponse;
				sap.ui.getCore().GOALS.results.filter(function(item) {

							if (("" + item.GoalDate + "").indexOf("GMT") === -1) {
								var a = item.GoalDate;
								var b = a.substring(6, a.length - 1);
								var c = b.substring(0, b.length - 1);
								var d = new Date(parseInt(c));
								item.GoalDate = d;
								return item;
							} else {
								item.GoalDate = oDateFormat.format(item.GoalDate);
								return item;
							}
						});
						sap.ui.getCore().GOALS.results.filter(function(item) {

							if (("" + item.GoalSdate + "").indexOf("GMT") === -1) {
								var a = item.GoalSdate;
								var b = a.substring(6, a.length - 1);
								var c = b.substring(0, b.length - 1);
								var d = new Date(parseInt(c));
								item.GoalSdate = d;
								return item;
							} else {
								item.GoalSdate = oDateFormat.format(item.GoalSdate);
								return item;
							}
						});
			});
			odatamodel.read("/ReporteesListSet?$filter=EmpIdM%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%272017-18%27", null, null, false, function(oResponse) {
				sap.ui.getCore().ReporteesList = oResponse;
			});
			odatamodel.read("/ScoreCardTreeSet", null, null, false, function(oResponse) {
		    sap.ui.getCore().ScoreCardTree = oResponse;
		   });
		   odatamodel.read("/ScoreCardGoalSet", null, null, false, function(oResponse) {
		    sap.ui.getCore().ScoreCardGoalSet = oResponse;
		   });
		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.drl.pmsManagermobile.view.Goalset
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.drl.pmsManagermobile.view.Goalset
		 */
		//	onExit: function() {
		//
		//	}

		onADD_Func: function(oEvent) {
			var view = this.getView();
			sap.ui.getCore().flag = 0;
			var dialog = new Dialog({
				title: 'Functional Goal',
				contentWidth: "550px",
				contentHeight: "300px",
				resizable: true,
				content: [
					new sap.m.Label({
						text: "Theme/Strategic Intent"
					}),
					new sap.m.Input("IntVal", {

					}),
					new sap.m.Label({
						text: "Weightage"
					}),
					new sap.m.Input("wtgVal", {
						type: "Number"
					}),
					new sap.m.Label({
						text: "KRA/Goals",
						width: "100%"
					}),
					new sap.m.TextArea("KRAVal", {
						rows: 5,
						cols: 50
					}),
					new sap.m.Label({
						text: "KPI/Measurment",
						width: "100%"
					}),
					new sap.m.TextArea("KPIVal", {
						rows: 5,
						cols: 50
					})
				],
				beginButton: new Button({
					text: 'Ok',
					press: function() {

						view.getController().addDataToTable(view);
						if (sap.ui.getCore().flag === 0) {
							dialog.close();
						}
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			//to get access to the global model
			this.getView().addDependent(dialog);
			dialog.open();
		},
		owngoal_Add: function(view) {
			//	view.getController().aData = [];
			try {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
				
				var dialog = this.getView().byId("OwnGoal");
			//	var intent = this.getView().byId("IntVal").getValue();
				var wtg = this.getView().byId("wtgVal").getValue();
				if(wtg !== ""){
				wtg= parseInt(wtg);
				}
				var kra = this.getView().byId("KRAVal").getValue();
				var kpi = this.getView().byId("KPIVal").getValue();
				var startDt = this.getView().byId("DP2_start").getValue();
				startDt = oDateFormat.format(new Date(startDt));
					var year = new Date().getFullYear();
				var statDt = new Date(year+"-04-01 00:00:00");
				var year2 = new Date().getFullYear()+1;
				var endDt = new Date(year2+"-03-31 00:00:00");
				if(new Date(startDt) < statDt || new Date(startDt) > endDt){
					startDt = "In";
				}
				var targetDt = this.getView().byId("DP2").getValue();
				targetDt = oDateFormat.format(new Date(targetDt));
					if(new Date(targetDt) < statDt || new Date(targetDt) > endDt){
					targetDt = "In";
				}
				
				//validation for wtg should not blank
				if(wtg !== "" && kra !== "" && kpi !== "" && targetDt !== "" && startDt !== "" && targetDt !== "In" && startDt !== "In"){
					
				if (sap.ui.getCore().index !== undefined ) {
					var modeldata = this.getView().byId("Func_list").getModel().getData().modelData[sap.ui.getCore().index];
					var edit_wtg = modeldata.Weightage;
					var cntwtg = 0;
					var progressBR = this.getView().byId("Proc_indicator");
					var last_wtg = progressBR.getPercentValue();
				    cntwtg = (parseInt(last_wtg) - parseInt(edit_wtg)) + parseInt(wtg);
					if(cntwtg <= 100 ){
					//modeldata.intent = intent;
					modeldata.KpiText = kpi;
					modeldata.KraText = kra;
					modeldata.Weightage = wtg +"%";
					modeldata.GoalSdate = startDt;
					modeldata.GoalDate = targetDt;

					var dat = this.getView().byId("Func_list").getModel().getData().modelData;
					var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData({
						modelData: dat
					});
					list.setModel(oModel);
					var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
					list.bindItems("/modelData", objlist);

						//Overall Weightage calculation 
						var list_calc = list.getModel().getData().modelData;
						var wtg_calc = 0;
						for (var i = 0; i < list_calc.length; i++) {
							wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
						}
						var list_proj = sap.ui.getCore().ODThis.getView().byId("Proj_list");
						var list_proj_calc = list_proj.getModel().getData();
						if (list_proj_calc !== null) {
							list_proj_calc = list_proj.getModel().getData().modelData;
							for (i = 0; i < list_proj_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
							}
						}
						var progressBR = this.getView().byId("Proc_indicator");
						progressBR.setDisplayValue("Overall Weightage "+wtg_calc+"%");
						progressBR.setPercentValue(wtg_calc);
						if(0<=wtg_calc && wtg_calc<=40){
							progressBR.setState("Error");
						}
						else if(41<=wtg_calc && wtg_calc<=80){
							progressBR.setState("Warning");
						}
						else if(81<=wtg_calc && wtg_calc<=100){
							progressBR.setState("Success");
						}
						
					
					sap.ui.getCore().index = undefined;
					dialog.destroy();
					dialog.close();
					}else{
						MessageToast.show("you can not add weightage more than 100");
					}
					
				} else {
					var cntwtg = 0;
					var progressBR = this.getView().byId("Proc_indicator");
					var last_wtg = progressBR.getPercentValue();
				    cntwtg = parseInt(last_wtg) + parseInt(wtg);
					//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
					//view.getController().checkwtg();
					if (cntwtg <= 100) {
						sap.ui.getCore().flag = 0;
						var subaData = [{
							//intent: intent,
							Weightage: wtg + "%",
							KraText: kra,
							KpiText: kpi,
							GoalSdate: startDt,
							GoalDate: targetDt
						}];

						var dat = this.getView().byId("Func_list").getModel().getData().modelData;
						dat.push(subaData[0]);
						var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData({
							modelData: dat
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
						list.bindItems("/modelData", objlist);
						//view.byId("scenariolB").addRow(row);

						//Overall Weightage calculation 
						var list_calc = list.getModel().getData().modelData;
						var wtg_calc = 0;
						for (var i = 0; i < list_calc.length; i++) {
							wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
						}
						var list_proj = sap.ui.getCore().ODThis.getView().byId("Proj_list");
						var list_proj_calc = list_proj.getModel().getData();
						if (list_proj_calc !== null) {
							list_proj_calc = list_proj.getModel().getData().modelData;
							for (i = 0; i < list_proj_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
							}
						}
						var progressBR = this.getView().byId("Proc_indicator");
						progressBR.setDisplayValue("Overall Weightage "+wtg_calc+"%");
						progressBR.setPercentValue(wtg_calc);
						if(0<=wtg_calc && wtg_calc<=40){
							progressBR.setState("Error");
						}
						else if(41<=wtg_calc && wtg_calc<=80){
							progressBR.setState("Warning");
						}
						else if(81<=wtg_calc && wtg_calc<=100){
							progressBR.setState("Success");
						}
						MessageToast.show('Added!');
						dialog.destroy();
						dialog.close();
					} else {
						//sap.ui.getCore().flag = 1;
						//sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
						MessageToast.show("you can not add weightage more than 100");

					}
				}
				}else{
					var year = new Date().getFullYear();
					var year2 = new Date().getFullYear()+1;
					if(wtg === ""){
							this.getView().byId("wtgVal").setValueState("Error");
							this.getView().byId("wtgVal").setValueStateText("Should not blank");
						}else{
							this.getView().byId("wtgVal").setValueState("None");
						}
						if(kra === ""){
							this.getView().byId("KRAVal").setValueState("Error");
							this.getView().byId("KRAVal").setValueStateText("Should not blank");
						}else{
							this.getView().byId("KRAVal").setValueState("None");
						}
						if(kpi === ""){
							this.getView().byId("KPIVal").setValueState("Error");
							this.getView().byId("KPIVal").setValueStateText("Should not blank");
						}else{
							this.getView().byId("KPIVal").setValueState("None");
						}
							if(targetDt === ""){
							this.getView().byId("DP2").setValueState("Error");
							this.getView().byId("DP2").setValueStateText("Should not blank");
						}else{
							this.getView().byId("DP2").setValueState("None");
						}
							if(startDt === ""){
							this.getView().byId("DP2_start").setValueState("Error");
							this.getView().byId("DP2_start").setValueStateText("Should not blank");
						}else{
							this.getView().byId("DP2_start").setValueState("None");
						}
						if(startDt === "In"){
							this.getView().byId("DP2_start").setValueState("Error");
							this.getView().byId("DP2_start").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
						}else{
							this.getView().byId("DP2_start").setValueState("None");
						}
						if(startDt === "In"){
							this.getView().byId("DP2").setValueState("Error");
							this.getView().byId("DP2").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
						}else{
							this.getView().byId("DP2").setValueState("None");
						}
				}
				
			} catch (e) {
				console.log(e);
			}

		},
		owngoal_Add_proj: function(view) {
			//	view.getController().aData = [];
			try {

				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
				var dialog = this.getView().byId("OwnGoal_proj");
				//var intent = this.getView().byId("IntVal_proj").getValue();
				var wtg = this.getView().byId("wtgVal_proj").getValue();
				if(wtg !== ""){
				wtg= parseInt(wtg);
				}
				var kra = this.getView().byId("KRAVal_proj").getValue();
				var kpi = this.getView().byId("KPIVal_proj").getValue();
				var startDt = this.getView().byId("DP2_start_proj").getValue();
				startDt = oDateFormat.format(new Date(startDt));
				var year = new Date().getFullYear();
				var statDt = new Date(year+"-04-01 00:00:00");
				var year2 = new Date().getFullYear()+1;
				var endDt = new Date(year2+"-03-31 00:00:00");
				if(new Date(startDt) < statDt || new Date(startDt) > endDt){
					startDt = "In";
				}
				var targetDt = this.getView().byId("DP2_proj").getValue();
				targetDt = oDateFormat.format(new Date(targetDt));
				if(new Date(targetDt) < statDt || new Date(targetDt) > endDt){
					targetDt = "In";
				}
				
				//validation for wtg shoud not blank
					if(wtg !== "" && kra !== "" && kpi !== "" && targetDt !== "" && startDt !== "" && targetDt !== "In" && startDt !== "In"){
				
				if (sap.ui.getCore().index_proj !== undefined) {
					var modeldata = this.getView().byId("Proj_list").getModel().getData().modelData[sap.ui.getCore().index_proj];
					var edit_wtg = modeldata.Weightage;
					var cntwtg = 0;
					var progressBR = this.getView().byId("Proc_indicator");
					var last_wtg = progressBR.getPercentValue();
				    cntwtg = (parseInt(last_wtg) - parseInt(edit_wtg)) + parseInt(wtg);
					if(cntwtg <= 100 ){
					//modeldata.intent = intent;
					modeldata.KpiText = kpi;
					modeldata.KraText = kra;
					modeldata.Weightage = wtg+ "%";
					modeldata.GoalSdate = startDt;
					modeldata.GoalDate = targetDt;

					var dat = this.getView().byId("Proj_list").getModel().getData().modelData;
					var list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData({
						modelData: dat
					});
					list.setModel(oModel);
					var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList");
					list.bindItems("/modelData", objlist);

						//Overall Weightage calculation 
						var list_func = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var list_calc = list_func.getModel().getData();
						var wtg_calc = 0;
						if(list_calc !== null){
						
						list_calc = list_func.getModel().getData().modelData;
						for (var i = 0; i < list_calc.length; i++) {
							wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
						}
						}
						var list_proj_calc = list.getModel().getData().modelData;
						if (list_proj_calc !== null) {
							for (i = 0; i < list_proj_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
							}
						}
						var progressBR = this.getView().byId("Proc_indicator");
						progressBR.setDisplayValue("Overall Weightage "+wtg_calc+"%");
						progressBR.setPercentValue(wtg_calc);
						if(0<=wtg_calc && wtg_calc<=40){
							progressBR.setState("Error");
						}
						else if(41<=wtg_calc && wtg_calc<=80){
							progressBR.setState("Warning");
						}
						else if(81<=wtg_calc && wtg_calc<=100){
							progressBR.setState("Success");
						}

					sap.ui.getCore().index_proj = undefined;
					dialog.destroy();
					dialog.close();
					}else{
						MessageToast.show("you can not add weightage more than 100");
					}
				} else {
					var cntwtg = 0;
					var progressBR = this.getView().byId("Proc_indicator");
					var last_wtg = progressBR.getPercentValue();
				    cntwtg = parseInt(last_wtg) + parseInt(wtg);
					//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
					//view.getController().checkwtg();
					if (cntwtg <= 100) {
						sap.ui.getCore().flag = 0;
						var subaData = [{
						//	intent: intent,
							Weightage: wtg + "%",
							KraText: kra,
							KpiText: kpi,
							GoalSdate:startDt, 
							GoalDate: targetDt
						}];

						var dat = this.getView().byId("Proj_list").getModel().getData().modelData;
						dat.push(subaData[0]);
						var list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
						var oModel = new sap.ui.model.json.JSONModel();
						oModel.setData({
							modelData: dat
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList");
						list.bindItems("/modelData", objlist);
						//view.byId("scenariolB").addRow(row);
						
						
						//Overall Weightage calculation 
						var list_func = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var list_calc = list_func.getModel().getData();
						var wtg_calc = 0;
						if(list_calc !== null){
						
						list_calc = list_func.getModel().getData().modelData;
						for (var i = 0; i < list_calc.length; i++) {
							wtg_calc = wtg_calc + parseInt(list_calc[i].Weightage);
						}
						}
						var list_proj_calc = list.getModel().getData().modelData;
						if (list_proj_calc !== null) {
							for (i = 0; i < list_proj_calc.length; i++) {
								wtg_calc = wtg_calc + parseInt(list_proj_calc[i].Weightage);
							}
						}
						var progressBR = this.getView().byId("Proc_indicator");
						progressBR.setDisplayValue("Overall Weightage "+wtg_calc+"%");
						progressBR.setPercentValue(wtg_calc);
						if(0<=wtg_calc && wtg_calc<=40){
							progressBR.setState("Error");
						}
						else if(41<=wtg_calc && wtg_calc<=80){
							progressBR.setState("Warning");
						}
						else if(81<=wtg_calc && wtg_calc<=100){
							progressBR.setState("Success");
						}
						
						
						MessageToast.show('Added!');
						dialog.destroy();
						dialog.close();
					} else {
						//sap.ui.getCore().flag = 1;
					//	sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
						MessageToast.show("you can not add weightage more than 100");

					}
				}
					}else{
				if(wtg === ""){
							this.getView().byId("wtgVal_proj").setValueState("Error");
							this.getView().byId("wtgVal_proj").setValueStateText("Should not blank");
						}else{
							this.getView().byId("wtgVal_proj").setValueState("None");
						}
						if(kra === ""){
							this.getView().byId("KRAVal_proj").setValueState("Error");
							this.getView().byId("KRAVal_proj").setValueStateText("Should not blank");
						}else{
							this.getView().byId("KRAVal_proj").setValueState("None");
						}
						if(kpi === ""){
							this.getView().byId("KPIVal_proj").setValueState("Error");
							this.getView().byId("KPIVal_proj").setValueStateText("Should not blank");
						}else{
							this.getView().byId("KPIVal_proj").setValueState("None");
						}
							if(targetDt === ""){
							this.getView().byId("DP2_proj").setValueState("Error");
							this.getView().byId("DP2_proj").setValueStateText("Should not blank");
						}else{
							this.getView().byId("DP2_proj").setValueState("None");
						}
						if(startDt === ""){
							this.getView().byId("DP2_start_proj").setValueState("Error");
							this.getView().byId("DP2_start_proj").setValueStateText("Should not blank");
						}else{
							this.getView().byId("DP2_start_proj").setValueState("None");
						}
						if(startDt === "In"){
							this.getView().byId("DP2_start_proj").setValueState("Error");
							this.getView().byId("DP2_start_proj").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
						}else{
							this.getView().byId("DP2_start_proj").setValueState("None");
						}
						if(startDt === "In"){
							this.getView().byId("DP2_proj").setValueState("Error");
							this.getView().byId("DP2_proj").setValueStateText("Please select date from 01/04/"+year+" to 31/03/"+year2);
						}else{
							this.getView().byId("DP2_proj").setValueState("None");
						}
				}
			
			} catch (e) {
				console.log(e);
			}

		},
		onCloseDialog: function() {
			var dialog = this.getView().byId("OwnGoal");
			dialog.destroy();
			dialog.close();
		},
		onCloseDialog_proj: function() {
			var dialog = this.getView().byId("OwnGoal_proj");
			dialog.destroy();
			dialog.close();
		},
		onfunc_list: function(evt) {
			var data = evt.getSource().getBindingContext().getObject();
			var oView = sap.ui.getCore().ODThis.getView();
			var oDialog = oView.byId("OwnGoal");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Owngoal", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			
			//update wtg meter inside goal popup
			var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("fungoal_progInd");
				var value = progressBR.getPercentValue();
						fungoal_progInd.setDisplayValue("Overall Weightage "+value+" %");
						fungoal_progInd.setPercentValue(value);
						if(0<=value && value<=40){
							fungoal_progInd.setState("Error");
						}
						else if(41<=value && value<=80){
							fungoal_progInd.setState("Warning");
						}
						else if(81<=value && value<=100){
							fungoal_progInd.setState("Success");
						}
			//this.getView().byId("IntVal").setValue(data.intent);
			//change popup header for edit goal
			this.getView().byId("OwnGoal").setTitle("Edit Functional Goal");
			
			//set other property 
			this.getView().byId("KRAVal").setValue(data.KraText);
			var wtg = data.Weightage;
			wtg= parseInt(wtg);
			this.getView().byId("wtgVal").setValue(wtg);
			this.getView().byId("DP2_start").setValue(data.GoalSdate);
			this.getView().byId("DP2").setValue(data.GoalDate);
			this.getView().byId("KPIVal").setValue(data.KpiText);

			var path = evt.getSource().getBindingContext().getPath();
			sap.ui.getCore().index = parseInt(path.substring(path.lastIndexOf('/') + 1));

			oDialog.open();

		},
		onproj_list: function(evt) {
			var data = evt.getSource().getBindingContext().getObject();
			var oView = sap.ui.getCore().ODThis.getView();
			var oDialog = oView.byId("OwnGoal_proj");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Owngoal_proj", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			var progressBR = this.getView().byId("Proc_indicator");
				var fungoal_progInd = this.getView().byId("projgoal_progInd");
				var value = progressBR.getPercentValue();
						fungoal_progInd.setDisplayValue("Overall Weightage "+value+" %");
						fungoal_progInd.setPercentValue(value);
							if(0<=value && value<=40){
							fungoal_progInd.setState("Error");
						}
						else if(41<=value && value<=80){
							fungoal_progInd.setState("Warning");
						}
						else if(81<=value && value<=100){
							fungoal_progInd.setState("Success");
						}
			//this.getView().byId("IntVal_proj").setValue(data.intent);
			
			//change popup header for edit goal
			this.getView().byId("OwnGoal_proj").setTitle("Edit Project Goal");
			
			
			this.getView().byId("KRAVal_proj").setValue(data.KraText);
			var wtg = data.Weightage;
			wtg= parseInt(wtg);
			this.getView().byId("wtgVal_proj").setValue(wtg);
			this.getView().byId("DP2_start_proj").setValue(data.GoalSdate);
			this.getView().byId("DP2_proj").setValue(data.GoalDate);
			this.getView().byId("KPIVal_proj").setValue(data.KpiText);

			var path = evt.getSource().getBindingContext().getPath();
			sap.ui.getCore().index_proj = parseInt(path.substring(path.lastIndexOf('/') + 1));

			oDialog.open();

		},
		removeFuncGol: function(evt) {
			try {
				var event1 = evt.getSource();
				var item = evt.getParameter('listItem');
				var dialog = new Dialog({
					title: 'Confirm',
					type: 'Message',
					contentWidth: "400px",
					content: [new sap.m.Label({
						width: "100%",
						text: "Are you sure you want to delete this goal?",
						placeholder: ""
					})],
					beginButton: new Button({
						text: 'Ok',
						press: function() {
							//row deletioin code 
							var oList = event1;

							var m = oList.getModel();
							var d = m.getData();
							var modeldata = d.modelData;
							var path = item.getBindingContext().getPath();
							var index = parseInt(path.substring(path.lastIndexOf('/') + 1));
							//update progress bar 
							var wtgDel = modeldata[index].Weightage;
							var progressBR = sap.ui.getCore().ODThis.getView().byId("Proc_indicator");
							var last_wtg = progressBR.getPercentValue();
							var updated_wtg = parseInt(last_wtg) - parseInt(wtgDel);
							
							progressBR.setDisplayValue("Overall Weightage "+updated_wtg+" %");
							progressBR.setPercentValue(updated_wtg);
								if(0<=updated_wtg && updated_wtg<=40){
							progressBR.setState("Error");
						}
						else if(41<=updated_wtg && updated_wtg<=80){
							progressBR.setState("Warning");
						}
						else if(81<=updated_wtg && updated_wtg<=100){
							progressBR.setState("Success");
						}
							modeldata.splice(index, 1);
							m.setData(d);

							MessageToast.show('Removed!');

							dialog.close();
						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				dialog.open();

			} catch (e) {
				console.log(e);
			}
		},
		removeProjGol: function(evt) {
			try {
				var event1 = evt.getSource();
				var item = evt.getParameter('listItem');
				var dialog = new Dialog({
					title: 'Confirm',
					type: 'Message',
					contentWidth: "400px",
					content: [new sap.m.Label({
						width: "100%",
						text: "Are you sure you want to delete this goal?",
						placeholder: ""
					})],
					beginButton: new Button({
						text: 'Ok',
						press: function() {
							//row deletioin code 
							var oList = event1;

							var m = oList.getModel();
							var d = m.getData();
							var modeldata = d.modelData;
							var path = item.getBindingContext().getPath();
							var index = parseInt(path.substring(path.lastIndexOf('/') + 1));
							//update progress bar 
							var wtgDel = modeldata[index].Weightage;
							var progressBR = sap.ui.getCore().ODThis.getView().byId("Proc_indicator");
							var last_wtg = progressBR.getPercentValue();
							var updated_wtg = parseInt(last_wtg) - parseInt(wtgDel);
							
							progressBR.setDisplayValue("Overall Weightage "+updated_wtg+" %");
							progressBR.setPercentValue(updated_wtg);
							if(0<=updated_wtg && updated_wtg<=40){
							progressBR.setState("Error");
						}
						else if(41<=updated_wtg && updated_wtg<=80){
							progressBR.setState("Warning");
						}
						else if(81<=updated_wtg && updated_wtg<=100){
							progressBR.setState("Success");
						}
							modeldata.splice(index, 1);
							m.setData(d);

							MessageToast.show('Removed!');

							dialog.close();
						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				dialog.open();
			} catch (e) {
				console.log(e);
			}
		},

		handleLineItemPress_func: function(evt) {
			var data = evt.getSource().getBindingContext().getObject();

			var view = sap.ui.getCore().ODThis.getView();
			sap.ui.getCore().flag = 0;
			var dialog = new Dialog({
				title: 'Functional Goal',
				contentWidth: "550px",
				contentHeight: "300px",
				resizable: true,
				content: [
					new sap.m.Label({
						text: "Theme/Strategic Intent"
					}),
					new sap.m.Input({
						value: data.intent
					}),
					new sap.m.Label({
						text: "Weightage"
					}),
					new sap.m.Input({
						value: data.wtg
					}),
					new sap.m.Label({
						text: "KRA/Goals",
						width: "100%"
					}),
					new sap.m.TextArea({
						rows: 5,
						cols: 50,
						value: data.kra
					}),
					new sap.m.Label({
						text: "KPI/Measurment",
						width: "100%"
					}),
					new sap.m.TextArea({
						rows: 5,
						cols: 50,
						value: data.kpi
					})
				],
				beginButton: new Button({
					text: 'Edit',
					press: function() {

						view.getController().addDataToTable(view);
						if (sap.ui.getCore().flag === 0) {
							dialog.close();
						}
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			//to get access to the global model
			view.addDependent(dialog);
			dialog.open();

		},

		//check weightage count for meter
		checkwtg: function() {
			if (sap.ui.getCore().cntwtg > 100) {
				alert("you cant add weightage more than 100");
				return;
			}

		},

		onADD_Proj: function(oEvent) {
			var view = this.getView();
			sap.ui.getCore().flag = 0;
			try {
				var dialog = new Dialog({
					title: 'Project Goal',
					contentWidth: "550px",
					contentHeight: "300px",
					resizable: true,
					content: [
						new sap.m.Label({
							text: "Theme/Strategic Intent"
						}),
						new sap.m.Input("IntVal_proj", {

						}),
						new sap.m.Label({
							text: "Weightage"
						}),
						new sap.m.Input("wtgVal_proj", {
							type: "Number"
						}),
						new sap.m.Label({
							text: "KRA/Goals",
							width: "100%"
						}),
						new sap.m.TextArea("KRAVal_proj", {
							rows: 5,
							cols: 50
						}),
						new sap.m.Label({
							text: "KPI/Measurment",
							width: "100%"
						}),
						new sap.m.TextArea("KPIVal_proj", {
							rows: 5,
							cols: 50
						})
					],
					beginButton: new Button({
						text: 'Ok',
						press: function() {

							view.getController().addDataToTable_proj(view);
							if (sap.ui.getCore().flag === 0) {
								dialog.close();
							}
						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function() {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});

				//to get access to the global model
				this.getView().addDependent(dialog);
				dialog.open();
			} catch (e) {
				console.log(e);
			}
		},
		addDataToTable_proj: function(view) {

			//	view.getController().aData = [];
			var intent = sap.ui.getCore().byId("IntVal_proj").getValue();
			var wtg = sap.ui.getCore().byId("wtgVal_proj").getValue();
			var kra = sap.ui.getCore().byId("KRAVal_proj").getValue();
			var kpi = sap.ui.getCore().byId("KPIVal_proj").getValue();
			sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) + parseInt(wtg);
			//var wtg = sap.ui.getCore().byId("wtgVal").getValue();
			//view.getController().checkwtg();
			if (sap.ui.getCore().cntwtg <= 100) {
				sap.ui.getCore().flag = 0;
				var subaData = [{
					intent: intent,
					wtg: wtg,
					kra: kra,
					kpi: kpi

				}];

				var dat = view.getController().aData_proj;
				dat.push(subaData[0]);
				var oTable = view.byId("PrjGLTbl");
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: dat
				});
				oTable.setModel(oModel);
				var template = new sap.m.ColumnListItem({
					type: "Navigation",

					cells: [
						new sap.m.Label({
							text: "{intent}"
						}),
						new sap.m.Label({
							text: "{wtg}"
						}),
						new sap.m.TextArea({
							value: "{kra}"
						}),
						new sap.m.TextArea({
							value: "{kpi}"
						}),
						new sap.m.Button({
							icon: "sap-icon://delete",
							text: "",
							press: view.getController().removeprojGol

						})
					]
				});
				oTable.bindItems("/modelData", template);
				//view.byId("scenariolB").addRow(row);
				var progressBR = this.getView().byId("Proc_indicator");
				progressBR.setDisplayValue("Overall Weightage "+sap.ui.getCore().cntwtg+" %");
				progressBR.setPercentValue(sap.ui.getCore().cntwtg);
				if(0<=sap.ui.getCore().cntwtg && sap.ui.getCore().cntwtg<=40){
							progressBR.setState("Error");
						}
						else if(41<=sap.ui.getCore().cntwtg && sap.ui.getCore().cntwtg<=80){
							progressBR.setState("Warning");
						}
						else if(81<=sap.ui.getCore().cntwtg && sap.ui.getCore().cntwtg<=100){
							progressBR.setState("Success");
						}
				MessageToast.show('Added!');
			} else {
				sap.ui.getCore().flag = 1;
				sap.ui.getCore().cntwtg = parseInt(sap.ui.getCore().cntwtg) - parseInt(wtg);
				MessageToast.show("you can not add weightage more than 100");

			}

		},
		submitforAPR: function() {
				var progressBR = this.getView().byId("Proc_indicator");
				var wtg = progressBR.getPercentValue();
				if(wtg !== 100){
					MessageToast.show("Please ensure overall weightage is 100%");
				}
		},
		onNavBack: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("_Login");

		},
		onsavetemp:function(){
			var oModel = this.getView().getModel();
			sap.ui.getCore().BatchOprAll = new Array();
			var _POSTCONTEXT = "AppraisalGoalsSet";
				var POSTENTRY = {
			      		EmpId : "P00003061",
			      		GoalId : "0001",
			      		GoalItemId : "0007",
			      		GoalName : "P00003061",
			      		Weightage: "10",
			      		KraText: "kra",
			      		KpiText: "kpi",
			      		GoalDate: null,
			      		StatusField: ""
			      		
			      	};
			      	var POSTENTRY1 = {
			      		EmpId : "P00003061",
			      		GoalId : "0001",
			      		GoalItemId : "0008",
			      		GoalName : "P00003061",
			      		Weightage: "10",
			      		KraText: "kra",
			      		KpiText: "kpi",
			      		GoalDate: null,
			      		StatusField: ""
			      		
			      	};
			      		sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY)); 
			      		sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY1));
			      		
			      		console.log(sap.ui.getCore().BatchOprAll);
					oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
					//oModel.addBatchReadOperations("PARAM_DET");

					oModel.submitBatch(function(data) {
						//oModel.refresh();
						sap.ui.core.BusyIndicator.hide();
                 	sap.m.MessageToast.show("Saved Successfully");
						if (data.__batchResponses[0].__changeResponses) {
							sap.m.MessageToast.show("Saved Successfully");
							jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
						} else {
							jQuery.sap.log.info(data.__batchResponses[0].message);
						}

					}, function(err) {
						sap.ui.core.BusyIndicator.hide();
		            		sap.m.MessageToast.show("A connection with the server could not be established");
		            		jQuery.sap.log.info("Error occurred", err);
					});
		},
		onsave:function(){
			this.showBusyIndicator(20000, 0);
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd"
			});
		
			var func_list = sap.ui.getCore().ODThis.getView().byId("Func_list");
			var data = func_list.getModel().getData().modelData;
			
			var proj_list = sap.ui.getCore().ODThis.getView().byId("Proj_list");
			var data_proj = proj_list.getModel().getData().modelData;
			
			sap.ui.getCore().BatchOprAll = new Array();
			var oModel = this.getView().getModel();
			var _POSTCONTEXT = "AppraisalGoalsSet";
			
			var odatamodel = this.getView().getModel();
			odatamodel.read("/AppraisalGoalsSet?$filter=EmpId%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%272017-18%27", null, null, false, function(oResponse) {
				sap.ui.getCore().GOALS = oResponse;
			});
			
			var user_Data = sap.ui.getCore().USERDATA;
			
			var flag=0;
	   									
	   			    var j=0;
	   			    var k=0;
	   			    var odata = new Array();
	   			    var odata_proj = new Array();
	   			    var goal_data = sap.ui.getCore().GOALS.results;
	   			    var idcnt=0;
	   			    
	   			    	for(var i=0;i<goal_data.length;i++){			    		
	   			    		if(goal_data[i].GoalId === '0001'){
	   			    			odata[j]= goal_data[i];
	   			    			j++;
	   			    		}	   			    					    		
	   			    	}
	   			    	for(i=0;i<goal_data.length;i++){			    		
	   			    		if(goal_data[i].GoalId === '0002'){
	   			    			odata_proj[k]= goal_data[i];
	   			    			k++;
	   			    		}	   			    					    		
	   			    	}
	   			    	
	   			    
	   			 var Alcount = odata.length;
	   			 var cnt=odata.length;
	   			 for (i = 0; i < data.length; i++) {
	   			 	var kra = data[i].KraText;
	   			 	var kpi = data[i].KpiText;
	   			 	var wtg = data[i].Weightage;
	   			 	wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
	   			 	var GoalDate = data[i].GoalDate;
	   			 	var temp = GoalDate.split("-");
	   			 	var mnth;
				if(temp[1] === "Jan"){
					mnth = "01";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Mar"){
					mnth = "03";}
				else if(temp[1] === "Apr"){
					mnth = "04";}
				else if(temp[1] === "May"){
					mnth = "05";}
				else if(temp[1] === "Jun"){
					mnth = "06";}
				else if(temp[1] === "Jul"){
					mnth = "07";}
				else if(temp[1] === "Aug"){
					mnth = "08";}
				else if(temp[1] === "Sep"){
					mnth = "09";}
				else if(temp[1] === "Oct"){
					mnth = "10";}
				else if(temp[1] === "Nov"){
					mnth = "11";}
				else if(temp[1] === "Dec"){
					mnth = "12";}
					GoalDate = temp[2]+"-"+mnth+"-"+temp[0];
	   			 	if(GoalDate !== null && GoalDate !== ""){
	   			 	GoalDate = new Date(GoalDate);
	   			 	}
	   			 	var GoalSdate = data[i].GoalSdate;
	   			 	var temp = GoalSdate.split("-");
	   			 	var mnth;
				if(temp[1] === "Jan"){
					mnth = "01";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Mar"){
					mnth = "03";}
				else if(temp[1] === "Apr"){
					mnth = "04";}
				else if(temp[1] === "May"){
					mnth = "05";}
				else if(temp[1] === "Jun"){
					mnth = "06";}
				else if(temp[1] === "Jul"){
					mnth = "07";}
				else if(temp[1] === "Aug"){
					mnth = "08";}
				else if(temp[1] === "Sep"){
					mnth = "09";}
				else if(temp[1] === "Oct"){
					mnth = "10";}
				else if(temp[1] === "Nov"){
					mnth = "11";}
				else if(temp[1] === "Dec"){
					mnth = "12";}
					GoalSdate = temp[2]+"-"+mnth+"-"+temp[0];
	   			 	if(GoalSdate !== null && GoalSdate !== ""){
	   			 	GoalSdate = new Date(GoalSdate);
	   			 	}
	   			 	//GoalDate = oDateFormat.format(GoalDate);
	   			 if(Alcount>=1){
			                    flag=1;
			                    Alcount--;
			                   }
			                   else{
			                    flag=0;
			                    cnt++;
			                   }
			      if(flag===0){
			      
			      	var POSTENTRY = {
			      		EmpId : sap.ui.getCore().username,
			      		GoalId : "0001",
			      		FiscalYear : "2017-18",
			      		EmpCode : user_Data.EmpCode,
			      		GoalItemId : ""+cnt,
			      		GoalName : "Own Goal",
			      		Weightage: wtg,
			      		KraText: kra,
			      		KpiText: kpi,
			      		GoalDate: GoalDate,
			      		GoalSdate: GoalSdate
			      		
			      	};
			      		//sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY)); 
			      		oModel.create(_POSTCONTEXT, POSTENTRY, null, function() {
			      			sap.m.MessageToast.show("Saved successfully");
			      		}, function(error) {
											
											console.log(error.message);
											//sap.ui.getCore().ordersThis.showAlert(error.message);

											//	alert("Update Failed");
										});
			      }else{
			      	
			      	var GoalItemId = odata[idcnt].GoalItemId;
			      
			      	
			      	var POSTENTRY = {
			      		EmpId : sap.ui.getCore().username,
			      		GoalId : "0001",
			      		GoalItemId : GoalItemId,
			      		FiscalYear : "2017-18",
			      		EmpCode : user_Data.EmpCode,
			      		GoalName : "Own Goal",
			      		Weightage: wtg,
			      		KraText: kra,
			      		KpiText: kpi,
			      		GoalDate: GoalDate,
			      		GoalSdate: GoalSdate
			      		
			      	};
			      		//sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT+"(EmpId='"+sap.ui.getCore().username+"',GoalId='0001',GoalItemId='"+GoalItemId+"')", "PUT", POSTENTRY));
			      oModel.update(_POSTCONTEXT+"(FiscalYear='2017-18',EmpId='"+sap.ui.getCore().username+"',GoalId='0001',GoalItemId='"+GoalItemId+"')", POSTENTRY, null,
						function() {
							sap.m.MessageToast.show("Saved successfully");
						}, function(error) {
							/*if (sap.ui.getCore().checkConnection) {
								sap.OData.removeHttpClient();
							}*/
							console.log("RecAssign Update Error : Go Online");
						});
			      	idcnt++;
			      }
			                   
	   			 }
	   			 
	   			 
	   			 //project goals save logic
	   			 var idcnt = 0;
	   			 var Alcount_proj = odata_proj.length;
	   			 var cnt_proj= odata_proj.length ;
	   			 for (i = 0; i < data_proj.length; i++) {
	   			 	kra = data_proj[i].KraText;
	   			 	kpi = data_proj[i].KpiText;
	   			    wtg = data_proj[i].Weightage;
	   			 	wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
	   			 	GoalDate = data_proj[i].GoalDate;
	   			 	var temp = GoalDate.split("-");
	   			 	var mnth;
				if(temp[1] === "Jan"){
					mnth = "01";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Mar"){
					mnth = "03";}
				else if(temp[1] === "Apr"){
					mnth = "04";}
				else if(temp[1] === "May"){
					mnth = "05";}
				else if(temp[1] === "Jun"){
					mnth = "06";}
				else if(temp[1] === "Jul"){
					mnth = "07";}
				else if(temp[1] === "Aug"){
					mnth = "08";}
				else if(temp[1] === "Sep"){
					mnth = "09";}
				else if(temp[1] === "Oct"){
					mnth = "10";}
				else if(temp[1] === "Nov"){
					mnth = "11";}
				else if(temp[1] === "Dec"){
					mnth = "12";}
					GoalDate = temp[2]+"-"+mnth+"-"+temp[0];
	   			 	
	   			 	if(GoalDate !== null && GoalDate !== ""){
	   			 	GoalDate = new Date(GoalDate);
	   			 	}
	   			 	var GoalSdate = data_proj[i].GoalSdate;
	   			 	var temp = GoalSdate.split("-");
	   			 	var mnth;
				if(temp[1] === "Jan"){
					mnth = "01";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Feb"){
					mnth = "02";}
				else if(temp[1] === "Mar"){
					mnth = "03";}
				else if(temp[1] === "Apr"){
					mnth = "04";}
				else if(temp[1] === "May"){
					mnth = "05";}
				else if(temp[1] === "Jun"){
					mnth = "06";}
				else if(temp[1] === "Jul"){
					mnth = "07";}
				else if(temp[1] === "Aug"){
					mnth = "08";}
				else if(temp[1] === "Sep"){
					mnth = "09";}
				else if(temp[1] === "Oct"){
					mnth = "10";}
				else if(temp[1] === "Nov"){
					mnth = "11";}
				else if(temp[1] === "Dec"){
					mnth = "12";}
					GoalSdate = temp[2]+"-"+mnth+"-"+temp[0];
	   			 	if(GoalSdate !== null && GoalSdate !== ""){
	   			 	GoalSdate = new Date(GoalSdate);
	   			 	}
	   			 	//GoalDate = oDateFormat.format(GoalDate);
	   			 if(Alcount_proj>=1){
			                    flag=1;
			                    Alcount_proj--;
			                   }
			                   else{
			                    flag=0;
			                    cnt_proj++;
			                   }
			      if(flag===0){
			      
			      	var POSTENTRY = {
			      		EmpId : sap.ui.getCore().username,
			      		GoalId : "0002",
			      		GoalItemId : ""+cnt_proj,
			      		FiscalYear : "2017-18",
			      		EmpCode : user_Data.EmpCode,
			      		GoalName : "Own Goal",
			      		Weightage: wtg,
			      		KraText: kra,
			      		KpiText: kpi,
			      		GoalDate: GoalDate,
			      		GoalSdate: GoalSdate
			      		
			      	};
			      		//sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT, "POST", POSTENTRY));
			      		oModel.create(_POSTCONTEXT, POSTENTRY, null, function() {
			      			sap.m.MessageToast.show("Saved successfully");
			      		}, function(error) {
											
											console.log(error.message);
											//sap.ui.getCore().ordersThis.showAlert(error.message);

											//	alert("Update Failed");
										});
			      }else{
			      	
			      	var GoalItemId = odata_proj[idcnt].GoalItemId;
			      	var POSTENTRY = {
			      		EmpId : sap.ui.getCore().username,
			      		GoalId : "0002",
			      		GoalItemId : GoalItemId,
			      		FiscalYear : "2017-18",
			      		EmpCode : user_Data.EmpCode,
			      		GoalName : "Own Goal",
			      		Weightage: wtg,
			      		KraText: kra,
			      		KpiText: kpi,
			      		GoalDate: GoalDate,
			      		GoalSdate: GoalSdate
			      		
			      	};
			      		oModel.update(_POSTCONTEXT+"(FiscalYear='2017-18',EmpId='"+sap.ui.getCore().username+"',GoalId='0002',GoalItemId='"+GoalItemId+"')", POSTENTRY, null,
						function() {
							sap.m.MessageToast.show("Saved successfully");
						}, function(error) {
							console.log("RecAssign Update Error : Go Online");
						});
			      		idcnt++;
			      }
			                   
	   			 }
	   			 
			sap.ui.core.BusyIndicator.hide();
		},
		onsubmit:function(){
			var that = this;
			this.onsave();
			var UserData = sap.ui.getCore().USERDATA;
			var oModel = this.getView().getModel();
			var _UPDATESTATUS = "EmployeeStatusSet";
			
			var POSTENTRY = {
			      		"EmpCode": UserData.EmpCode,
						 "FiscalYear":UserData.FiscalYear,
						 "ActionFlag":"A", 
						 "EmpId":UserData.EmpId,
						 "ActionComments":""
			      		
			      	};
			oModel.update(_UPDATESTATUS+"(FiscalYear='"+UserData.FiscalYear+"',EmpId='"+sap.ui.getCore().username+"')", POSTENTRY, null,
						function() {
							sap.m.MessageToast.show("Submit Sucessfully for approval");
							var a = that.getView().byId("func_ObjList");
						    var b = that.getView().byId("proj_ObjList");
						    var a1 = this.getView().byId("Func_list");
				    		var b1 = this.getView().byId("Proj_list");
						    a.setType("Inactive");
						    b.setType("Inactive");
						    a1.setMode("None");
						    b1.setMode("None");
						    
						    //disable save and submit button
						    that.getView().byId("btn_save_goalSet").setEnabled(false);
							that.getView().byId("btn_submit_GoalSet").setEnabled(false);
							that.getView().byId("openMenu").setEnabled(false);
    						that.getView().byId("GOAL_LIB").setEnabled(false);
							
						}, function(error) {
							/*if (sap.ui.getCore().checkConnection) {
								sap.OData.removeHttpClient();
							}*/
							console.log("RecAssign Update Error : Go Online");
						});
			
		},
		handle_fun_score: function(oEvent) {
			var oView = sap.ui.getCore().ODThis.getView();
			
			var oDialog = oView.byId("ScoreCard");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Score_Card", this);
				var oTable = this.getView().byId("treeTable");
				 
				var oModel = new sap.ui.model.json.JSONModel({useBatch : true});
				sap.ui.getCore().ScoreCardTree.results[0].PARENT_NODE_ID = null;
				var res = this.group(sap.ui.getCore().ScoreCardTree.results);
				sap.ui.getCore().ScoreCardTreeset = res;
					oModel.setData({
						items:res
					});
				oTable.setModel(oModel);
				
				oView.addDependent(oDialog);
			}
						var oTable1 = this.getView().byId("tblRespScore");
						var oControl1 = new sap.m.Text({text:"{KPA_TEXT}", textAlign:"Left"}).addStyleClass("txttbl");
						var oColumn1 = new sap.ui.table.Column({multiLabels: [
						                                                      new sap.m.Label({text: "KRA/Goals"})
						                                                      ],width:"50%", template: oControl1,hAlign: "Center", resizable:false ,autoResizable: false});
						oTable1.addColumn(oColumn1, {resizable:false ,autoResizable: false});
						var oControl1 = new sap.m.Text({text:"{KPI_TEXT}", textAlign:"Left"}).addStyleClass("txttbl");
						var oColumn1 = new sap.ui.table.Column({multiLabels: [
						                                                      new sap.m.Label({text: "KPI/Measurement"})
						                                                      ],width:"30%", template: oControl1,hAlign: "Center", resizable:false ,autoResizable: false});
						oTable1.addColumn(oColumn1, {resizable:false ,autoResizable: false});
						var oControl1 = new sap.m.Text({text:"{WEIGHTAGE}", textAlign:"Center"});
						var oColumn1 = new sap.ui.table.Column({multiLabels: [
						                                                      new sap.m.Label({text: "Weightage(%)"})
						                                                      ],width:"10%", template: oControl1,hAlign: "Center", resizable:false ,autoResizable: false});
						oTable1.addColumn(oColumn1, {resizable:false ,autoResizable: false});
						
			oDialog.open();
		},
				group:function (arr) {
		    var t={};
		     for(var i = 0;i<arr.length;i++){
		    	if (!arr[i].NODE_ID) { //'object found without id!'
		       sap.m.MessageToast.show ("object found without id!");
		        }
		        t[arr[i].NODE_ID]=arr[i];
		    }
		    var result=[];
		    for(var i = 0;i<arr.length;i++){
		    	if (!arr[i].PARENT_NODE_ID) {
		            result.push(arr[i]);
		        } else {
		            var parent=t[arr[i].PARENT_NODE_ID];
		            if (!parent){ sap.m.MessageToast.show("parent with id "+arr[i].PARENT_NODE_ID+" not found!");}
		            var items=parent.items;
		            if (!items) {
		                items=[];
		                parent.items=items;
		            }
		            items.push(arr[i]);
		        }
		    }
		     return result;
		},
		onrowchange: function(oEvent){
			var a = oEvent.getSource();
			var b = a.getRows()[oEvent.getParameters().rowIndex];
			var c = b.getCells()[0].getText();
			var nodeid;
			for(var i = 0;i<sap.ui.getCore().ScoreCardTree.results.length;i++){
				if(sap.ui.getCore().ScoreCardTree.results[i].NODE_TEXT===c){
					nodeid=sap.ui.getCore().ScoreCardTree.results[i].NODE_ID;
				}
			}
			var item = sap.ui.getCore().ScoreCardGoalSet.results.filter(function(item) {
							if(item.PARENT_NODE_ID==nodeid)
								{
									return item;
								}
						});
			
					var oTable1 = this.getView().byId("tblRespScore");
						
					var oModel100 = new sap.ui.model.json.JSONModel();				
					oModel100.setData({
						modelData100: item
					});

					oTable1.setModel(oModel100);
					var len = oTable1.getModel().getData().modelData100.length;
					oTable1.setVisibleRowCount(len);
		},
		GoalLib_Add_proj : function(){
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "dd-MMM-yyyy"
									});
				var otable = this.getView().byId("tblGoalLib");
				var arr = otable.getSelectedIndices();
				sap.ui.getCore().gollibScore = [];
				for(var i =0; i<arr.length;i++){
					sap.ui.getCore().gollibScore.push(otable.getModel().getData().items[arr[i]]);
				}
			
						var dat = this.getView().byId("Func_list").getModel().getData().modelData;
						sap.ui.getCore().ODThis.getView().getController().aData = dat;
						var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var oModel = new sap.ui.model.json.JSONModel();
						var dt = sap.ui.getCore().ODThis.getView().getController().aData;
						var year = new Date().getFullYear();
						var statDt = new Date(year+"-04-01");
						var year2 = new Date().getFullYear()+1;
						var endDt = new Date(year2+"-03-31");
						
						for(var ii=0;ii<sap.ui.getCore().gollibScore.length;ii++){
							var wtg = sap.ui.getCore().gollibScore[ii].Weightage;
							dt.push({
								"EmpId": "",
								"GoalId":"",
								"GoalItemId":"",
								"GoalName": "",
								"Weightage": wtg + "%",
								"KraText": sap.ui.getCore().gollibScore[ii].KraText,
								"KpiText": sap.ui.getCore().gollibScore[ii].KpiText,
								"GoalDate":oDateFormat.format(statDt),
								"GoalSdate": oDateFormat.format(endDt)
							});
						}
						oModel.setData({
							modelData: dt
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
						list.bindItems("/modelData", objlist);
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
		},
		ScoreCard_Add_proj : function(){
			
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "dd-MMM-yyyy"
									});
				var otable = this.getView().byId("tblRespScore");
				var arr = otable.getSelectedIndices();
				sap.ui.getCore().FinScore = [];
				for(var i =0; i<arr.length;i++){
					sap.ui.getCore().FinScore.push(otable.getModel().getData().modelData100[arr[i]]);
				}
			
						var dat = this.getView().byId("Func_list").getModel().getData().modelData;
						sap.ui.getCore().ODThis.getView().getController().aData = dat;
						var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
						var oModel = new sap.ui.model.json.JSONModel();
						var dt = sap.ui.getCore().ODThis.getView().getController().aData;
						var year = new Date().getFullYear();
						var statDt = new Date(year+"-04-01");
						var year2 = new Date().getFullYear()+1;
						var endDt = new Date(year2+"-03-31");
						var tempwtg = 0;
						for(var ii=0;ii<sap.ui.getCore().FinScore.length;ii++){
							var wtg = sap.ui.getCore().FinScore[ii].WEIGHTAGE;
							 tempwtg = tempwtg + wtg;
							dt.push({
								"EmpId": "",
								"GoalId":"",
								"GoalItemId":"",
								"GoalName": "",
								"Weightage": wtg + "%",
								"KraText": sap.ui.getCore().FinScore[ii].KPA_TEXT,
								"KpiText": sap.ui.getCore().FinScore[ii].KPI_TEXT,
								"GoalDate":oDateFormat.format(statDt),
								"GoalSdate": oDateFormat.format(endDt)
							});
						}
						
						//weightage meter logic
						var cntwtg = 0;
					var edit_wtg = tempwtg;
					var progressBR = this.getView().byId("Proc_indicator");
					var last_wtg = progressBR.getPercentValue();
					
					cntwtg = parseInt(tempwtg) + parseInt(last_wtg);
					if(cntwtg <= 100 ){
						
						oModel.setData({
							modelData: dt
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
						list.bindItems("/modelData", objlist);
						
						//update wtg meter 
						var progressBR = this.getView().byId("Proc_indicator");
						progressBR.setDisplayValue("Overall Weightage "+cntwtg+"%");
						progressBR.setPercentValue(cntwtg);
						if(0<=cntwtg && cntwtg<=40){
							progressBR.setState("Error");
						}
						else if(41<=cntwtg && cntwtg<=80){
							progressBR.setState("Warning");
						}
						else if(81<=cntwtg && cntwtg<=100){
							progressBR.setState("Success");
						}
						
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
					}else{
							MessageToast.show("you can not add weightage more than 100");
					}
		},
		handle_goal_lib: function(){
			var odatamodel = this.getView().getModel();	
			odatamodel.read("GoalLibararySet?$filter=EmpId%20eq%20%27"+sap.ui.getCore().username+"%27", null, null, false, function(oResponse) {
				sap.ui.getCore().GoalLibarary = oResponse;
			});
			var oView = sap.ui.getCore().ODThis.getView();
			
			var oDialog = oView.byId("GoalLib");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Goal_Lib", this);
				var oTable1 = this.getView().byId("tblGoalLib");
				 
						var oControl1 = new sap.m.Text({text:"{KpiText}", textAlign:"Left"}).addStyleClass("txttbl");
						var oColumn1 = new sap.ui.table.Column({multiLabels: [
						                                                      new sap.m.Label({text: "KPI"})
						                                                      ],width:"40%", template: oControl1,hAlign: "Center", resizable:false ,autoResizable: false});
						oTable1.addColumn(oColumn1, {resizable:false ,autoResizable: false});
						var oControl1 = new sap.m.Text({text:"{KraText}", textAlign:"Left"}).addStyleClass("txttbl");
						var oColumn1 = new sap.ui.table.Column({multiLabels: [
						                                                      new sap.m.Label({text: "KRA"})
						                                                      ],width:"40%", template: oControl1,hAlign: "Center", resizable:false ,autoResizable: false});
						oTable1.addColumn(oColumn1, {resizable:false ,autoResizable: false});
						var oControl1 = new sap.m.Text({text:"{Weightage}", textAlign:"Center"});
						var oColumn1 = new sap.ui.table.Column({multiLabels: [
						                                                      new sap.m.Label({text: "Weightage(%)"})
						                                                      ],width:"20%", template: oControl1,hAlign: "Center", resizable:false ,autoResizable: false});
						oTable1.addColumn(oColumn1, {resizable:false ,autoResizable: false});
				var oModel = new sap.ui.model.json.JSONModel();
				//sap.ui.getCore().ScoreCardTree.results[0].PARENT_NODE_ID = null;
				var res = sap.ui.getCore().GoalLibarary.results;
				//sap.ui.getCore().ScoreCardTreeset = res;
					oModel.setData({
						items:res
					});
				oTable1.setModel(oModel);
				oTable1.setVisibleRowCount(res.length);
				
				oView.addDependent(oDialog);
			}
			oDialog.open();
		},
onCloseScoreCard: function() {
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
		},
		onCloseGoalLib: function() {
			var dialog = this.getView().byId("GoalLib");
			dialog.destroy();
			dialog.close();
		}


	});

});