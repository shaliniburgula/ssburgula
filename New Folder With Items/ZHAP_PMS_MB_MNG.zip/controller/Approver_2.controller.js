sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.drl.pmsManagermobile.controller.Approver_2", {

		onnav: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("_Approver");
		},

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.drl.pmsManagermobile.view.Approver_2
		 */
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

			var oDataProcessFlowLanesOnly = {
				lanes: [{
					id: "0",
					icon: "sap-icon://accept",
					label: "Goal Setting",
					position: 0,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
						value: 10
					}]
				}, {
					id: "1",
					icon: "sap-icon://com.drl.pmsManagermobile-approval",
					label: "Goal Approval",
					position: 1,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
						value: 10
					}]
				}, {
					id: "2",
					icon: "sap-icon://survey",
					label: "Half Yearly Review",
					position: 2
				}, {
					id: "3",
					icon: "sap-icon://activity-assigned-to-goal",
					label: "Goal Revisit",
					position: 3
				}, {
					id: "4",
					icon: "sap-icon://com.drl.pmsManagermobile-approval",
					label: "Goal Approval",
					position: 4
				}, {
					id: "5",
					icon: "sap-icon://approvals",
					label: "Anuual Review",
					position: 5
				}, {
					id: "6",
					icon: "sap-icon://monitor-payments",
					label: "ARC",
					position: 6
				}, {
					id: "7",
					icon: "sap-icon://signature",
					label: "Final Sign Off",
					position: 7
				}]
			};

			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");

			viewPf2.byId("processflow2").updateModel();
		},
		_handleRouteMatched: function() {

			try {
				sap.ui.getCore().ODThis = this;
				//	this.getView().byId("Appr_reject_cmnt").setVisible(false);

				var Logo =
					"data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=";
				this.getView().byId("goal_pic_id_Apr").setSrc(Logo);

				this.servicecall();
				this.getView().getController().perf_path_update();
				////////////// form language as per manager language //////////////
				////// set paramter according to language //////
				var view = this.getView();
				view.byId("HD_empcode0").setText(sap.ui.getCore().ru_empcode);
				view.byId("HD_roleB0").setText(sap.ui.getCore().ru_rleband);
				view.byId("HD_dept0").setText(sap.ui.getCore().ru_deprt);
				view.byId("HD_unit0").setText(sap.ui.getCore().ru_unit);
				view.byId("HD_mngNM0").setText(sap.ui.getCore().ru_mngrL1);
				view.byId("HD_revNM0").setText(sap.ui.getCore().ru_mngrL2);
				view.byId("HD_mmngr0").setText(sap.ui.getCore().ru_mmngr);
				view.byId("PerformancePathID").setTitle(sap.ui.getCore().Perf_path_text);
				view.byId("GoalID").setTitle(sap.ui.getCore().Goal_header);
				//view.byId("goalAPr_hdr").setTitle(sap.ui.getCore().Goal_approver);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-0").setText(sap.ui.getCore().Perf_GoalSetting);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-1").setText(sap.ui.getCore().Perf_goalApproval);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-2").setText(sap.ui.getCore().Perf_halfyearly);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-3").setText(sap.ui.getCore().Perf_revisit);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-4").setText(sap.ui.getCore().Perf_approval);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-5").setText(sap.ui.getCore().Perf_annualReview);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-6").setText(sap.ui.getCore().Perf_ARC);
				// sap.ui.getCore().byId("__header0-Approver_2--processflow2-7").setText(sap.ui.getCore().Perf_Finalsignoff);
				var processF = this.getView().byId("processflow2");
				processF.mAggregations.lanes[0].setText(sap.ui.getCore().Perf_GoalSetting);
				processF.mAggregations.lanes[1].setText(sap.ui.getCore().Perf_goalApproval);
				processF.mAggregations.lanes[2].setText(sap.ui.getCore().L_halfyear);
				processF.mAggregations.lanes[3].setText(sap.ui.getCore().L_revisit);
				processF.mAggregations.lanes[4].setText(sap.ui.getCore().L_goalapprover);
				processF.mAggregations.lanes[5].setText(sap.ui.getCore().Perf_annualReview);
				processF.mAggregations.lanes[6].setText(sap.ui.getCore().Perf_ARC);
				processF.mAggregations.lanes[7].setText(sap.ui.getCore().Perf_Finalsignoff);

				sap.ui.getCore().byId("Approver_2--GoalID").setTitle(sap.ui.getCore().Goal_header);
				view.byId("pml_funcgoal_hdr").setHeaderText(sap.ui.getCore().ru_FunctionalGoals);
				view.byId("ProjectGoalsID").setHeaderText(sap.ui.getCore().ru_ProjectGoals);
				// view.byId("__button0").setText(sap.ui.getCore().ru_Approve);
				// view.byId("__button1").setText(sap.ui.getCore().ru_returnemp);
				//	view.byId("Appr_reject_cmnt").setHeaderText(sap.ui.getCore().ru_cmnt);
				//	view.byId("Apr_Respnc").setText(sap.ui.getCore().submit);
				sap.ui.getCore().mnu_func = "Functional Goal";
				sap.ui.getCore().mnu_proj = "Project Goal";

				view.byId("PNL_OverAllAsset").setHeaderText(sap.ui.getCore().overall);
				view.byId("PNL_HalfYearReview").setHeaderText(sap.ui.getCore().over_Half);
				//	view.byId("PNL_overall_Annual").setHeaderText(sap.ui.getCore().over_Annu);

				// var goals = sap.ui.getCore().GOALS_E.results;
				// var functionalGoals = [];
				// var projectGoals = [];
				// for (var i = 0; i < goals.length; i++) {
				// 	if (goals[i].GoalId === '0001') {
				// 		functionalGoals.push(goals[i]);
				// 	} else if (goals[i].GoalId === '0002') {
				// 		projectGoals.push(goals[i]);
				// 	}
				// }
				// for (var i = 0; i < functionalGoals.length; i++) {
				// 	//set timeline text area text
				// 	sap.ui.getCore().byId("Approver_2--PNL_halfyrcmnt-Approver_2--Func_list_Apr-" + i).setHeaderText(sap.ui.getCore().halfy);
				// 	sap.ui.getCore().byId("Approver_2--PNL_annualRevw-Approver_2--Func_list_Apr-" + i).setHeaderText(sap.ui.getCore().AnnY);

				// }
				// for (var i = 0; i < projectGoals.length; i++) {
				// 	//set timeline text area text
				// 	sap.ui.getCore().byId("Approver_2--PNL_halfyrcmnt_proj-Approver_2--Proj_list_Apr-" + i).setHeaderText(sap.ui.getCore().halfy);
				// 	sap.ui.getCore().byId("Approver_2--PNL_annualRevw_proj-Approver_2--Proj_list_Apr-" + i).setHeaderText(sap.ui.getCore().AnnY);
				// }

				//handle view according to status 
				this.view_handle();

				this.getView().getController().setHeaderDet();
				this.getView().getController().goalsGET();

				this.onAfterRendering1();

				//this.getView().getController().onAfterRendering();
			} catch (e) {
				console.log(e);
			}

		},

		goalsGET: function() {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd-MMM-yyyy"
			});
			var goals = sap.ui.getCore().GOALS_E.results;
			var functionalGoals = [];
			var projectGoals = [];
			for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0001') {
					functionalGoals.push(goals[i]);
				} else if (goals[i].GoalId === '0002') {
					projectGoals.push(goals[i]);
				}
			}
			//functional goal set
			var dat = functionalGoals;
			var list = sap.ui.getCore().ODThis.getView().byId("Func_list_Apr");
			var oModel = new sap.ui.model.json.JSONModel();
			var dt = [];

			for (var ii = 0; ii < dat.length; ii++) {
				var wtg = parseInt(dat[ii].Weightage);
				dt.push({
					"EmpId": dat[ii].EmpId,
					"GoalId": dat[ii].GoalId,
					"GoalItemId": dat[ii].GoalItemId,
					"GoalName": dat[ii].GoalName,
					"Weightage": wtg + "%",
					"KraText": dat[ii].KraText,
					"KpiText": dat[ii].KpiText,
					"GoalDate": oDateFormat.format(dat[ii].GoalDate),
					"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
				});
			}
			oModel.setData({
				modelData: dt
			});
			list.setModel(oModel);
			var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList_Apr");
			list.bindItems("/modelData", objlist);

			//project goal set
			dat = projectGoals;
			list = sap.ui.getCore().ODThis.getView().byId("Proj_list_Apr");
			oModel = new sap.ui.model.json.JSONModel();
			dt = [];

			for (ii = 0; ii < dat.length; ii++) {
				wtg = parseInt(dat[ii].Weightage);
				dt.push({
					"EmpId": dat[ii].EmpId,
					"GoalId": dat[ii].GoalId,
					"GoalItemId": dat[ii].GoalItemId,
					"GoalName": dat[ii].GoalName,
					"Weightage": wtg + "%",
					"KraText": dat[ii].KraText,
					"KpiText": dat[ii].KpiText,
					"GoalDate": oDateFormat.format(dat[ii].GoalDate),
					"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
				});
			}
			oModel.setData({
				modelData: dt
			});
			list.setModel(oModel);
			var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList_Apr");
			list.bindItems("/modelData", objlist);
		},
		setHeaderDet: function() {
			var HDR_INFO = sap.ui.getCore().USERDATA_E;
			this.byId("HD_appr").setObjectTitle(HDR_INFO.EmpName + " |");
			this.byId("HD_appr").setObjectSubtitle(HDR_INFO.DesignText);
			this.byId("HD_appr").setObjectImageURI(sap.ui.getCore().USERDATA_E.EmpImage);
			this.byId("HD_empcode_appr").setText(" : " + HDR_INFO.EmpId);
			this.byId("HD_roleB_appr").setText(" : " + HDR_INFO.BandText);
			this.byId("HD_dept_appr").setText(" : " + HDR_INFO.DepartText);
			this.byId("HD_unit_appr").setText(" : " + HDR_INFO.UnitText);
			this.byId("HD_mngNM_appr").setText(" : " + HDR_INFO.ApprName);
			this.byId("HD_revNM_appr").setText(" : " + HDR_INFO.OtherName);
			this.byId("HD_mmngr_appr").setText(" : " + HDR_INFO.PartApprName);

		},
		servicecall: function() {
			var odatamodel = this.getView().getModel();
			odatamodel.read("/ApprisalHeaderNewSet(EmpId='" + sap.ui.getCore().EMPid + "',FiscalYear='" + sap.ui.getCore().Year_Sel +
				"')?$format=json", null, null, false,
				function(oResponse) {
					sap.ui.getCore().USERDATA_E = oResponse;
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);

					alert("Error " + aa.error.message.value);
					//sap.ui.getCore().servicecallflag = 0;
				});
			odatamodel.read("/ApprisalGoalsNewSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().EMPid +
				"%27%20and%20FiscalYear%20eq%20%27" + sap.ui.getCore().Year_Sel + "%27", null, null, false,
				function(oResponse) {
					sap.ui.getCore().GOALS_E = oResponse;
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);

					alert("Error " + aa.error.message.value);
					//sap.ui.getCore().servicecallflag = 0;
				});
			var data = sap.ui.getCore().USERDATA_E;
			// if (data.ApStatus === "4" && data.ApStatusSub === "3"){
			// 	odatamodel.read("/ApprisalHeaderNewSet(EmpId='P" + sap.ui.getCore().USERDATA_E.ApprId + "',FiscalYear='"+sap.ui.getCore().Year_Sel+"')?$format=json", null, null, false,
			// 	function(oResponse) {
			// 		sap.ui.getCore().USERDATA = oResponse;
			// 	},
			// 	function(oError) {
			// 		var aa = JSON.parse(oError.response.body);

			// 		alert("Error "+aa.error.message.value);
			// 		//sap.ui.getCore().servicecallflag = 0;
			// 	});
			// }
			if (data.ApStatus === "4" && data.ApStatusSub === "4") {
				odatamodel.read("/ApprisalHeaderNewSet(EmpId='P" + sap.ui.getCore().USERDATA_E.OtherId + "',FiscalYear='" + sap.ui.getCore().Year_Sel +
					"')?$format=json", null, null, false,
					function(oResponse) {
						sap.ui.getCore().USERDATA_LP2 = oResponse;
					},
					function(oError) {
						var aa = JSON.parse(oError.response.body);

						alert("Error " + aa.error.message.value);
						//sap.ui.getCore().servicecallflag = 0;
					});
			}
		},
		view_handle: function() {
			//submit button logic
			var data = sap.ui.getCore().USERDATA_E;

			if (data.ApStatus === "2" && data.ApStatusSub === "3") {

				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");

				//hide half year comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//hide overall panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(false);

				//hide save button
				//	this.getView().byId("BTN_save").setVisible(false);

				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(true);

			} else if (data.ApStatus === "3" && data.ApStatusSub === "3") {
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				//	panel.setVisible(false);

				//save button visiblity code
				//	this.getView().byId("BTN_save").setVisible(true);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
			
				}
					Hy_OVRASS_Date =	oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				//	this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				//	this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				//	this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
			//	this.getView().byId("_overallAsserTL").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				//set text to over all assetmanet 
				//	sap.ui.getCore().byId("Approver_2--_overAllCMNT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(false);

			} else if (data.ApStatus === "3" && data.ApStatusSub === "5") {
				
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(false);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(false);

				//save button visiblity code
				//	this.getView().byId("BTN_save").setVisible(false);
				//approver radio button viciblity code
				//		this.getView().byId("__group0").setVisible(true);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
			
				}
					Hy_OVRASS_Date	= oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				//	this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				//	this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				//		this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
			//	this.getView().byId("_overallAsserTL").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				//set value to halfyear assetment
				//	var Hyr_FBK = this.getView().byId("_overallAsserTL");
				//	Hyr_FBK.destroyEmbeddedControl();
				//	Hyr_FBK.setText(sap.ui.getCore().USERDATA.HyrFbkTxt);
				//
			} else if (data.ApStatus === "4" && data.ApStatusSub === "2") {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");

				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save button visiblity code
				//	this.getView().byId("BTN_save").setVisible(true);
				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
			
				}
					Hy_OVRASS_Date =	oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				// this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				// this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
			//	this.getView().byId("_overallAsserTL").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.OVR_ACH_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.OVR_ACH_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_SLF_Date =	oDateFormat.format(An_SLF_Date);
				//set image EMP to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				// this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				// this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_IMG").setSrc(sap.ui.getCore().USERDATA_E.EmpImage);
				this.getView().byId("ANN_EMP_NAME").setText(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_DAT").setText(An_SLF_Date);
				this.getView().byId("ANN_EMP_CMNT").setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);
				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_L1_Date =	oDateFormat.format(An_L1_Date);
				//set image manager to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_mngr").setText(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_Date").setText(An_L1_Date);
				this.getView().byId("ANN_L1_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_L1_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_DAT").setText(An_L1_Date);
				this.getView().byId("Annual_overAllCMNT_mngr").setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				this.getView().byId("ANUL_L1_RAT").setText(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				this.getView().byId("ANUL_L1_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp1Val)
				//get HF  data
				// var HY_L1 = this.getView().byId("_overallAsserTL");
				// HY_L1.destroyEmbeddedControl();
				// HY_L1.setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				// var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				// ANN_EMP.destroyEmbeddedControl();
				// ANN_EMP.setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);

				//annual L+1 comment get
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				// Ann_l1_txt.setValue(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);

				this.getView().byId("Annual_overAllCMNT_mngr_stack").setText(sap.ui.getCore().USERDATA_E.SthFbkTxt);

			} else if (data.ApStatus === "4" && data.ApStatusSub === "3") {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");

				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//panel.setExpanded(false);
				//panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save button visiblity code
				//	this.getView().byId("BTN_save").setVisible(true);
				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
			
				}
					Hy_OVRASS_Date =	oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				// this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				// this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				//this.getView().byId("_overallAsserTL").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_SLF_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_SLF_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_SLF_Date =	oDateFormat.format(An_SLF_Date);
				//set image EMP to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				// this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				// this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_IMG").setSrc(sap.ui.getCore().USERDATA_E.EmpImage);
				this.getView().byId("ANN_EMP_NAME").setText(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_DAT").setText(An_SLF_Date);
				this.getView().byId("ANN_EMP_CMNT").setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);

	
				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_L1_Date =	oDateFormat.format(An_L1_Date);
				//Timeline data set to Annual L+1 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_mngr").setText(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_Date").setText(An_L1_Date);
				this.getView().byId("ANN_L1_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_L1_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_DAT").setText(An_L1_Date);
				this.getView().byId("Annual_overAllCMNT_mngr").setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				this.getView().byId("ANUL_L1_RAT").setText(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				this.getView().byId("ANUL_L1_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp1Val)
				//set date time of Annual L+2
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_L2_Date =	oDateFormat.format(An_L2_Date);
				//Timeline data set to Annual L+2
				// this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA_E.OtherImage);
				// this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				// this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_IMG").setSrc(sap.ui.getCore().USERDATA_E.OtherImage);
				this.getView().byId("ANN_L2_NAME").setText(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_DAT").setText(An_L2_Date);
				this.getView().byId("Annual_overAllCMNT_L2").setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				this.getView().byId("ANN_L2_RAT").setText(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("ANUL_L2_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp2Val)
				//get HF  data
				// var HY_L1 = this.getView().byId("_overallAsserTL");
				// HY_L1.destroyEmbeddedControl();
				// HY_L1.setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				// var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				// ANN_EMP.destroyEmbeddedControl();
				// ANN_EMP.setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);

				//annual L+1 comment get
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				//	Ann_l1_txt.setEditable(false);
				//Annual L+1 stack holder comment
				this.getView().byId("Annual_overAllCMNT_mngr_stack").setText(sap.ui.getCore().USERDATA_E.SthFbkTxt);
				//	this.getView().byId("Annual_overAllCMNT_mngr_stack").setEditable(false);

			} else if (data.ApStatus === "4" && data.ApStatusSub === "4") {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");

				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save & submit button visiblity code
				//	this.getView().byId("BTN_save").setVisible(true);
				//	this.getView().byId("Apr_Respnc").setVisible(true);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save button visiblity code
				//	this.getView().byId("BTN_save").setVisible(true);
				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					Hy_OVRASS_Date = oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				// this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				// this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
			this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_SLF_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_SLF_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_SLF_Date = oDateFormat.format(An_SLF_Date);
				//set image EMP to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				// this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				// this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_IMG").setSrc(sap.ui.getCore().USERDATA_E.EmpImage);
				this.getView().byId("ANN_EMP_NAME").setText(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_DAT").setText(An_SLF_Date);
				this.getView().byId("ANN_EMP_CMNT").setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);
				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_L1_Date = oDateFormat.format(An_L1_Date);
				//Timeline data set to Annual L+1 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_L1_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_DAT").setText(An_L1_Date);
				this.getView().byId("Annual_overAllCMNT_mngr").setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				this.getView().byId("ANUL_L1_RAT").setText(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				this.getView().byId("ANUL_L1_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp1Val);
				//set date time of Annual L+2
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_L2_Date = oDateFormat.format(An_L2_Date);
				//Timeline data set to Annual L+2
				// this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA_E.OtherImage);
				// this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				// this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_IMG").setSrc(sap.ui.getCore().USERDATA_E.OtherImage);
				this.getView().byId("ANN_L2_NAME").setText(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_DAT").setText(An_L2_Date);
				this.getView().byId("Annual_overAllCMNT_L2").setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				this.getView().byId("ANN_L2_RAT").setText(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("ANUL_L2_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp2Val);
				//ARC timeline
				//set date time of Annual ARC
				var An_ARC_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ARC_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ARC_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_ARC_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_ARC_Date = oDateFormat.format(An_ARC_Date);
				//Timeline data set to Annual ARC
				// this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_ARC").setDateTime(An_ARC_Date);
				// this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_ARC_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_ARC_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_ARC_DAT").setText(An_ARC_Date);
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA_E.FinAppTxt);
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA_E.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA_E.PntFctVal);		
				//get HF  data
				// var HY_L1 = this.getView().byId("_overallAsserTL");
				// HY_L1.destroyEmbeddedControl();
				// HY_L1.setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				// var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				// ANN_EMP.destroyEmbeddedControl();
				// ANN_EMP.setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);

				//annual L+1 comment get
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				//	Ann_l1_txt.setEditable(false);
				//Annual L+1 stack holder comment
				this.getView().byId("Annual_overAllCMNT_mngr_stack").setText(sap.ui.getCore().USERDATA_E.SthFbkTxt);
				//	this.getView().byId("Annual_overAllCMNT_mngr_stack").setEditable(false);

			} 	else if (data.ApStatus === "5" && data.ApStatusSub === "") {
				
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
			//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
			//	panel.setExpanded(false);
				//panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
			//	panel.setExpanded(false);
				//panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
			//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
		//		panel.setExpanded(false);

				//save & submit button visiblity code
			//	this.getView().byId("BTN_save").setVisible(false);
			//	this.getView().byId("Apr_Respnc").setVisible(false);
				
				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
			//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(true);
		//		panel.setExpanded(false);

				//save button visiblity code
			//	sap.ui.getCore().byId("Approver_2--BTN_save").setVisible(true);
				//approver radio button viciblity code
			//	this.getView().byId("__group0").setVisible(false);
				
				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if(sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== ""){
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 Hy_OVRASS_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
			
				}
					Hy_OVRASS_Date = oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				
				
				//set date time of timeline
				var An_SLF_Date = new Date();
				if(sap.ui.getCore().USERDATA_E.ANN_SLF_DAT !== ""){
					var datetime = sap.ui.getCore().USERDATA_E.ANN_SLF_DAT;
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 An_SLF_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				 	
				}
				An_SLF_Date = oDateFormat.format(An_SLF_Date);
				this.getView().byId("ANN_EMP_IMG").setSrc(sap.ui.getCore().USERDATA_E.EmpImage);
				this.getView().byId("ANN_EMP_NAME").setText(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_DAT").setText(An_SLF_Date);
				this.getView().byId("ANN_EMP_CMNT").setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);
				//set image EMP to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				// this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				// this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA_E.EmpName);
				
				
				//set date time of timeline
				var An_L1_Date = new Date();
				if(sap.ui.getCore().USERDATA_E.ANN_LP1_DAT !== ""){
					var datetime = sap.ui.getCore().USERDATA_E.ANN_LP1_DAT;
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 An_L1_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);

				}
			  	An_L1_Date = oDateFormat.format(An_L1_Date);
				this.getView().byId("ANN_L1_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_L1_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_DAT").setText(An_L1_Date);
				this.getView().byId("Annual_overAllCMNT_mngr").setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				this.getView().byId("ANUL_L1_RAT").setText(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				this.getView().byId("ANUL_L1_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp1Val);
				//Timeline data set to Annual L+1 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_mngr").setText(sap.ui.getCore().USERDATA_E.ApprName);
				// 	this.getView().byId("Annual_overallAsset_Date").setText(An_L1_Date);
				//set date time of Annual L+2
				var An_L2_Date = new Date();
				if(sap.ui.getCore().USERDATA_E.RVW_REV_DAT !== ""){
					var datetime = sap.ui.getCore().USERDATA_E.RVW_REV_DAT;
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 An_L2_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				}
				 An_L2_Date = oDateFormat.format(An_L2_Date);
				//Timeline data set to Annual L+2
				this.getView().byId("ANN_L2_IMG").setSrc(sap.ui.getCore().USERDATA_E.OtherImage);
				this.getView().byId("ANN_L2_NAME").setText(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_DAT").setText(An_L2_Date);
				this.getView().byId("Annual_overAllCMNT_L2").setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				this.getView().byId("ANN_L2_RAT").setText(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("ANUL_L2_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp2Val);
				// this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA_E.OtherImage);
				// this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				// this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA_E.OtherName);
				
				//ARC timeline
				//set date time of Annual ARC
				var An_ARC_Date = new Date();
				if(sap.ui.getCore().USERDATA_E.ARC_FBK_DAT !== ""){
					var datetime = sap.ui.getCore().USERDATA_E.ARC_FBK_DAT;
				var	y=datetime.substring(0,3);
				var	y=datetime.substring(0,4);
				var	m = datetime.substring(4,6);
				var	d=datetime.substring(6,8);
				var	H=datetime.substring(8,10);
				var	Min=datetime.substring(10,12);
				var	sec=datetime.substring(12,14);
				 An_ARC_Date = new Date(y+"/"+m+"/"+d+" "+H+":"+Min+":"+sec);
				 
				}
				An_ARC_Date = oDateFormat.format(An_ARC_Date);
				//Timeline data set to Annual ARC
					this.getView().byId("ANN_ARC_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_ARC_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_ARC_DAT").setText(An_ARC_Date);
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA_E.FinAppTxt);
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA_E.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA_E.PntFctVal);
				// this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_ARC").setDateTime(An_ARC_Date);
				// this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				
				
				//get HF  data
				// var HY_L1 = this.getView().byId("_overallAsserTL");
				// HY_L1.destroyEmbeddedControl();
				// HY_L1.setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				
				// var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				// ANN_EMP.destroyEmbeddedControl();
				// ANN_EMP.setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);
				
				//this.getView().byId("Annual_overallAsset_mngr").setText("iusdbfisud");
				
				//annual L+1 comment get
			// 	var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
			// 	Ann_l1_txt.setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
			// //	Ann_l1_txt.setEditable(false);
			// 	//Annual L+1 stack holder comment
			// 	this.getView().byId("Annual_overAllCMNT_mngr_stack").setText(sap.ui.getCore().USERDATA_E.SthFbkTxt);
			//	this.getView().byId("Annual_overAllCMNT_mngr_stack").setEditable(false);
				
			
			} else if (data.ApStatus === "7" && data.ApStatusSub === "") {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");

				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save & submit button visiblity code
				//	this.getView().byId("BTN_save").setVisible(false);
				//	this.getView().byId("Apr_Respnc").setVisible(false);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save button visiblity code
				//	sap.ui.getCore().byId("Approver_2--BTN_save").setVisible(true);
				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
			
				}
					Hy_OVRASS_Date =	oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				// this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				// this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
			this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_SLF_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_SLF_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_SLF_Date = oDateFormat.format(An_SLF_Date);
				//set image EMP to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				// this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				// this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_IMG").setSrc(sap.ui.getCore().USERDATA_E.EmpImage);
				this.getView().byId("ANN_EMP_NAME").setText(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_DAT").setText(An_SLF_Date);
				this.getView().byId("ANN_EMP_CMNT").setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);
				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_L1_Date = oDateFormat.format(An_L1_Date);
				//Timeline data set to Annual L+1 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_mngr").setText(sap.ui.getCore().USERDATA_E.ApprName);
				// this.getView().byId("Annual_overallAsset_Date").setText(An_L1_Date);
				this.getView().byId("ANN_L1_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_L1_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_DAT").setText(An_L1_Date);
				this.getView().byId("Annual_overAllCMNT_mngr").setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				this.getView().byId("ANUL_L1_RAT").setText(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				this.getView().byId("ANUL_L1_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp1Val);
				//set date time of Annual L+2
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_L2_Date = oDateFormat.format(An_L2_Date);
				//Timeline data set to Annual L+2
				// this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA_E.OtherImage);
				// this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				// this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_IMG").setSrc(sap.ui.getCore().USERDATA_E.OtherImage);
				this.getView().byId("ANN_L2_NAME").setText(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_DAT").setText(An_L2_Date);
				this.getView().byId("Annual_overAllCMNT_L2").setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				this.getView().byId("ANN_L2_RAT").setText(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("ANUL_L2_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp2Val);
				//ARC timeline
				//set date time of Annual ARC
				var An_ARC_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ARC_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ARC_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_ARC_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_ARC_Date = oDateFormat.format(An_ARC_Date);
				//Timeline data set to Annual ARC
				// this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_ARC").setDateTime(An_ARC_Date);
				// this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_ARC_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_ARC_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_ARC_DAT").setText(An_ARC_Date);
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA_E.FinAppTxt);
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA_E.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA_E.PntFctVal);
				//get HF  data
				// var HY_L1 = this.getView().byId("_overallAsserTL");
				// HY_L1.destroyEmbeddedControl();
				// HY_L1.setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				// var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				// ANN_EMP.destroyEmbeddedControl();
				// ANN_EMP.setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);

				//annual L+1 comment get
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				//	Ann_l1_txt.setEditable(false);
				//Annual L+1 stack holder comment
				this.getView().byId("Annual_overAllCMNT_mngr_stack").setText(sap.ui.getCore().USERDATA_E.SthFbkTxt);
				//	this.getView().byId("Annual_overAllCMNT_mngr_stack").setEditable(false);

			} else if (data.ApStatus === "9" && data.ApStatusSub === "") {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var a1 = this.getView().byId("Func_list_Apr");
				var b1 = this.getView().byId("Proj_list_Apr");
				//	this.getView().byId("Apr_Respnc").setEnabled(true);
				a1.setMode("None");
				b1.setMode("None");

				//goals comment panel
				var panel = this.getView().byId("PNL_halfyrcmnt");
				panel.setVisible(true);
				//panel.setExpanded(false);
				//panel.setExpanded(false);
				var panel = this.getView().byId("PNL_halfyrcmnt_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				//panel.setExpanded(false);
				//Annual comment panel
				var panel = this.getView().byId("PNL_annualRevw");
				panel.setVisible(true);
				var panel = this.getView().byId("PNL_annualRevw_proj");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save & submit button visiblity code

				//	this.getView().byId("BTN_save").setVisible(false);
				//	this.getView().byId("Apr_Respnc").setVisible(false);

				//overall assesment panel
				var panel = this.getView().byId("PNL_OverAllAsset");
				panel.setVisible(true);
				//	panel.setExpanded(false);
				var panel = this.getView().byId("PNL_overall_Annual");
				panel.setVisible(true);
				//	panel.setExpanded(false);

				//save button visiblity code
				//	sap.ui.getCore().byId("Approver_2--BTN_save").setVisible(true);
				//approver radio button viciblity code
				//	this.getView().byId("__group0").setVisible(false);

				//set date time of timeline
				var Hy_OVRASS_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.HYR_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.HYR_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_OVRASS_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					Hy_OVRASS_Date = oDateFormat.format(Hy_OVRASS_Date);
				//set image to over all assetment 
				// this.getView().byId("_overallAsserTL").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("_overallAsserTL").setDateTime(Hy_OVRASS_Date);
				// this.getView().byId("_overallAsserTL").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_ICON").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("HY_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("HY_DATE").setText(Hy_OVRASS_Date);
				this.getView().byId("HY_CMT").setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);
				

				//set date time of timeline
				var An_SLF_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_SLF_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_SLF_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_SLF_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				
				}
					An_SLF_Date = oDateFormat.format(An_SLF_Date);
				//set image EMP to annual review over all assetment 
				// this.getView().byId("Annual_overallAsset_EMP").setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				// this.getView().byId("Annual_overallAsset_EMP").setDateTime(An_SLF_Date);
				// this.getView().byId("Annual_overallAsset_EMP").setUserName(sap.ui.getCore().USERDATA_E.EmpName);
			this.getView().byId("ANN_EMP_IMG").setSrc(sap.ui.getCore().USERDATA_E.EmpImage);
				this.getView().byId("ANN_EMP_NAME").setText(sap.ui.getCore().USERDATA_E.EmpName);
				this.getView().byId("ANN_EMP_DAT").setText(An_SLF_Date);
				this.getView().byId("ANN_EMP_CMNT").setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);
				//set date time of timeline
				var An_L1_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ANN_LP1_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ANN_LP1_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_L1_Date = oDateFormat.format(An_L1_Date);
				//Timeline data set to Annual L+1 
				// this.getView().byId("Annual_overallAsset_mngr").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_overallAsset_mngr").setDateTime(An_L1_Date);
				// this.getView().byId("Annual_overallAsset_mngr").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_L1_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_L1_DAT").setText(An_L1_Date);
				this.getView().byId("Annual_overAllCMNT_mngr").setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				this.getView().byId("ANUL_L1_RAT").setText(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				this.getView().byId("ANUL_L1_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp1Val);
				//set date time of Annual L+2
				var An_L2_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.RVW_REV_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.RVW_REV_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_L2_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_L2_Date = oDateFormat.format(An_L2_Date);
				//Timeline data set to Annual L+2
				// this.getView().byId("Annual_overallAsset_Lp2").setUserPicture(sap.ui.getCore().USERDATA_E.OtherImage);
				// this.getView().byId("Annual_overallAsset_Lp2").setDateTime(An_L2_Date);
				// this.getView().byId("Annual_overallAsset_Lp2").setUserName(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_IMG").setSrc(sap.ui.getCore().USERDATA_E.OtherImage);
				this.getView().byId("ANN_L2_NAME").setText(sap.ui.getCore().USERDATA_E.OtherName);
				this.getView().byId("ANN_L2_DAT").setText(An_L2_Date);
				this.getView().byId("Annual_overAllCMNT_L2").setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				this.getView().byId("ANN_L2_RAT").setText(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("ANUL_L2_POINTFA").setText(sap.ui.getCore().USERDATA_E.PftLp2Val);
				//ARC timeline
				//set date time of Annual ARC
				var An_ARC_Date = new Date();
				if (sap.ui.getCore().USERDATA_E.ARC_FBK_DAT !== "") {
					var datetime = sap.ui.getCore().USERDATA_E.ARC_FBK_DAT;
					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					An_ARC_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					
				}
					An_ARC_Date = oDateFormat.format(An_ARC_Date);
				//Timeline data set to Annual ARC
				// this.getView().byId("Annual_ARC").setUserPicture(sap.ui.getCore().USERDATA_E.ApproverImage);
				// this.getView().byId("Annual_ARC").setDateTime(An_ARC_Date);
				// this.getView().byId("Annual_ARC").setUserName(sap.ui.getCore().USERDATA_E.ApprName);
					this.getView().byId("ANN_ARC_IMG").setSrc(sap.ui.getCore().USERDATA_E.ApproverImage);
				this.getView().byId("ANN_ARC_NAME").setText(sap.ui.getCore().USERDATA_E.ApprName);
				this.getView().byId("ANN_ARC_DAT").setText(An_ARC_Date);
				this.getView().byId("Annual_overAllCMNT_ARC").setText(sap.ui.getCore().USERDATA_E.FinAppTxt);
				this.getView().byId("Ann_ARC_Rat").setText(sap.ui.getCore().USERDATA_E.FinAppVal);
				this.getView().byId("Ann_ARC_Poifact").setText(sap.ui.getCore().USERDATA_E.PntFctVal);
				//get HF  data
				// var HY_L1 = this.getView().byId("_overallAsserTL");
				// HY_L1.destroyEmbeddedControl();
				// HY_L1.setText(sap.ui.getCore().USERDATA_E.HyrFbkTxt);

				// var ANN_EMP = this.getView().byId("Annual_overallAsset_EMP");
				// ANN_EMP.destroyEmbeddedControl();
				// ANN_EMP.setText(sap.ui.getCore().USERDATA_E.OvrAchTxt);

				//annual L+1 comment get
				var Ann_l1_txt = this.getView().byId("Annual_overAllCMNT_mngr");
				Ann_l1_txt.setText(sap.ui.getCore().USERDATA_E.AnnLp1Txt);
				//	Ann_l1_txt.setEditable(false);
				//Annual L+1 stack holder comment
				this.getView().byId("Annual_overAllCMNT_mngr_stack").setText(sap.ui.getCore().USERDATA_E.SthFbkTxt);
				//	this.getView().byId("Annual_overAllCMNT_mngr_stack").setEditable(false);

			} else {
				//	this.getView().byId("Apr_Respnc").setEnabled(false);
			}
		},

		// radio_select: function() {
		// 	var selectedkey = sap.ui.getCore().byId("Approver_2--__group0").getSelectedIndex();
		// 	if (selectedkey === 1) {
		// 		this.getView().byId("Appr_reject_cmnt").setVisible(true);
		// 	} else {
		// 		this.getView().byId("Appr_reject_cmnt").setVisible(false);
		// 	}
		// },
		perf_path_update: function() {

			if (sap.ui.getCore().USERDATA_E.ApStatus === "3" && sap.ui.getCore().USERDATA_E.ApStatusSub === "3") {

				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly Manager",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "3" && sap.ui.getCore().USERDATA_E.ApStatusSub === "5") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "4" && sap.ui.getCore().USERDATA_E.ApStatusSub === "2") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review L+1",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "4" && sap.ui.getCore().USERDATA_E.ApStatusSub === "3") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval L+2",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "4" && sap.ui.getCore().USERDATA_E.ApStatusSub === "4") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7

					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "5" && sap.ui.getCore().USERDATA_E.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
				//viewPf2.byId("processflow2").setZoomLevel("Four");
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "9" && sap.ui.getCore().USERDATA_E.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "7" && sap.ui.getCore().USERDATA_E.ApStatusSub === "") {
				var oDataProcessFlowLanesOnly = {
					lanes: [{
						id: "0",
						icon: "sap-icon://accept",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://accept",
						label: "Goal Approval",
						position: 1,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "3",
						icon: "sap-icon://activity-assigned-to-goal",
						label: "Goal Revisit",
						position: 3,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "4",
						icon: "sap-icon://hr-approval",
						label: "Goal Approval",
						position: 4,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "5",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 5,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "6",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 6,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "7",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 7,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
							value: 10
						}]
					}]
				};

				var oModelPf2 = new sap.ui.model.json.JSONModel();
				var viewPf2 = this.getView();
				oModelPf2.setData(oDataProcessFlowLanesOnly);
				viewPf2.setModel(oModelPf2, "pf2");

				viewPf2.byId("processflow2").updateModel();
			}

		},
		Perfor_path_goalSet: function() {
			var oDataProcessFlowLanesOnly = {
				lanes: [{
						id: "0",
						icon: "sap-icon://customize",
						label: "Goal Setting",
						position: 0,
						state: [{
							state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
							value: 10
						}]
					}, {
						id: "1",
						icon: "sap-icon://com.drl.pmsManagermobile-approval",
						label: "Goal Approval",
						position: 1
					}, {
						id: "2",
						icon: "sap-icon://survey",
						label: "Half Yearly",
						position: 2
					},
					//, {
					// 	id: "3",
					// 	icon: "sap-icon://activity-assigned-to-goal",
					// 	label: "Goal Revisit",
					// 	position: 3
					// }, {
					// 	id: "4",
					// 	icon: "sap-icon://com.drl.pmsManagermobile-approval",
					// 	label: "Goal Approval",
					// 	position: 4
					// }, 
					{
						id: "6",
						icon: "sap-icon://approvals",
						label: "Annual Review",
						position: 3
					}, {
						id: "7",
						icon: "sap-icon://monitor-payments",
						label: "ARC",
						position: 4
					}, {
						id: "8",
						icon: "sap-icon://signature",
						label: "Final Sign Off",
						position: 5
					}
				]
			};

			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");

			viewPf2.byId("processflow2").updateModel();

		},
		showBusyIndicator: function(iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);

			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}

				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function() {
					this.hideBusyIndicator();
				});
			}

		},
		hideBusyIndicator: function() {
			sap.ui.core.BusyIndicator.hide();
		},
		mngr_save: function() {
			var data = sap.ui.getCore().USERDATA_E;

			if (data.ApStatus === "3" && data.ApStatusSub === "3") {
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});

				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();

				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA_E;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS_E.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}

				for (i = 0; i < odata.length; i++) {
					var kra = odata[i].KraText;
					var kpi = odata[i].KpiText;
					var wtg = odata[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = odata[i].GoalDate;
					var GoalName = odata[i].GoalName;
					var GoalSdate = odata[i].GoalSdate;

					var HyrEmpTxt = odata[i].HyrEmpTxt;
					var HyrFbkTxt_fun = sap.ui.getCore().byId("Approver_2--_timelineText_mngr-Approver_2--Func_list_Apr-" + i).getValue();

					var GoalItemId = odata[i].GoalItemId;
					// var Hy_mngr_date = odata[i].HYR_FBK_DAT;
					// if(Hy_mngr_date === ""){
					var Hy_mngr_date = oDateformat_half.format(new Date());
					//}

					var POSTENTRY = {
						HyrFbkTxt: HyrFbkTxt_fun,
						HYR_FBK_DAT: Hy_mngr_date

					};
					sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + user_Data.EmpId +
						"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));
				}

				//project goals save logic
				for (i = 0; i < odata_proj.length; i++) {
					kra = odata_proj[i].KraText;
					kpi = odata_proj[i].KpiText;
					wtg = odata_proj[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = odata_proj[i].GoalName;
					GoalDate = odata_proj[i].GoalDate;
					var HyrEmpTxt_proj = odata_proj[i].HyrEmpTxt;
					var HyrFbkTxt_proj = sap.ui.getCore().byId("Approver_2--_timelineText_mngr_proj-Approver_2--Proj_list_Apr-" + i).getValue();

					var GoalSdate = odata_proj[i].GoalSdate;

					var GoalItemId = odata_proj[i].GoalItemId;
					// var Hy_mngr_date = odata_proj[i].HYR_FBK_DAT;
					// if(Hy_mngr_date === ""){
					var Hy_mngr_date = oDateformat_half.format(new Date());
					//}

					var POSTENTRY = {
						HyrFbkTxt: HyrFbkTxt_proj,
						HYR_FBK_DAT: Hy_mngr_date
					};
					sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + user_Data.EmpId +
						"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}

				//over all assetment comment saving
				var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";
				var OVRL_half_mngr = sap.ui.getCore().byId("Approver_2--_overAllCMNT").getValue();

				var Hy_mngr_date = oDateformat_half.format(new Date());

				var POSTENTRY = {
					HyrFbkTxt: OVRL_half_mngr,
					HYR_FBK_DAT: Hy_mngr_date
				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));

				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established");
					jQuery.sap.log.info("Error occurred", err);
				});
			} else if (data.ApStatus === "4" && data.ApStatusSub === "2") {

				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});

				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var _POSTCONTEXT = "ApprisalGoalsNewSet";

				var odatamodel = this.getView().getModel();

				this.showBusyIndicator(20000, 0);
				var user_Data = sap.ui.getCore().USERDATA_E;

				var flag = 0;

				var j = 0;
				var k = 0;
				var odata = new Array();
				var odata_proj = new Array();
				var goal_data = sap.ui.getCore().GOALS_E.results;
				var idcnt = 0;

				for (var i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0001') {
						odata[j] = goal_data[i];
						j++;
					}
				}
				for (i = 0; i < goal_data.length; i++) {
					if (goal_data[i].GoalId === '0002') {
						odata_proj[k] = goal_data[i];
						k++;
					}
				}
				var GoDate_Ann = oDateformat_half.format(new Date());
				for (i = 0; i < odata.length; i++) {
					var kra = odata[i].KraText;
					var kpi = odata[i].KpiText;
					var wtg = odata[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalDate = odata[i].GoalDate;
					var GoalName = odata[i].GoalName;
					//	var AnnL1Txt = sap.ui.getCore().byId("Approver_2--Annual_timelineText_mngrcmnt-Approver_2--Func_list_Apr-" + i).getText();
					var GoalSdate = odata[i].GoalSdate;

					var GoalItemId = odata[i].GoalItemId;

					var POSTENTRY = {
						//		AnnLp1Txt : AnnL1Txt,
						ANN_LP1_DAT: GoDate_Ann
					};
					sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + user_Data.EmpId +
						"',GoalId='0001',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}

				//project goals save logic
				var idcnt = 0;
				for (i = 0; i < odata_proj.length; i++) {
					kra = odata_proj[i].KraText;
					kpi = odata_proj[i].KpiText;
					wtg = odata_proj[i].Weightage;
					//wtg = wtg.replace(/[^a-zA-Z0-9]/g, "");
					var GoalName = odata_proj[i].GoalName;
					GoalDate = odata_proj[i].GoalDate;
					//	var AnnL1Txt_proj = sap.ui.getCore().byId("Approver_2--Annual_timelineText_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).getText();
					var GoalSdate = odata_proj[i].GoalSdate;

					var GoalItemId = odata_proj[i].GoalItemId;
					var POSTENTRY = {
						//			AnnLp1Txt : AnnL1Txt_proj,
						ANN_LP1_DAT: GoDate_Ann
					};
					sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT + "(EmpId='" + user_Data.EmpId +
						"',GoalId='0002',FiscalYear='" + sap.ui.getCore().Year_Sel + "',GoalItemId='" + GoalItemId + "')", "PUT", POSTENTRY));

				}

				//over all assetment comment saving
				var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";
				var OVRL_Ann_L1 = sap.ui.getCore().byId("Approver_2--Annual_overAllCMNT_mngr").getText();
				//	 var OVRL_Ann_L1_rt = sap.ui.getCore().byId("Approver_2--Ann_L1_rating").getSelectedKey();
				var OVRL_Ann_poiFact = sap.ui.getCore().byId("Approver_2--Ann_L1_Poifact")._getSelectedItemText();
				var OVRL_Ann_L1_STACK = sap.ui.getCore().byId("Approver_2--Annual_overAllCMNT_mngr_stack").getText();

				var Ann_L1_date = oDateformat_half.format(new Date());

				var POSTENTRY = {
					AnnLp1Txt: OVRL_Ann_L1,
					ANN_LP1_DAT: Ann_L1_date,
					AnnLp1Val: OVRL_Ann_L1_rt,
					PftLp1Val: OVRL_Ann_poiFact,
					SthFbkTxt: OVRL_Ann_L1_STACK,
					RvwRevTxt: "#"
				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));

				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
					jQuery.sap.log.info("Error occurred", err);
				});

			} else if (data.ApStatus === "4" && data.ApStatusSub === "3") {
				this.showBusyIndicator(20000, 0);
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});

				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var user_Data = sap.ui.getCore().USERDATA_E;

				//over all assetment comment saving
				var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";
				var OVRL_Ann_L2 = sap.ui.getCore().byId("Approver_2--Annual_overAllCMNT_L2").getText();
				var OVRL_Ann_L2_rt = sap.ui.getCore().byId("Approver_2--Ann_L2_rating").getSelectedKey();
				var OVRL_Ann_L2_poiFact = sap.ui.getCore().byId("Approver_2--Ann_L2_Poifact")._getSelectedItemText();

				var Ann_L2_date = oDateformat_half.format(new Date());

				var POSTENTRY = {
					RvwRevTxt: OVRL_Ann_L2,
					RVW_REV_DAT: Ann_L2_date,
					RvwRevVal: OVRL_Ann_L2_rt,
					PftLp2Val: OVRL_Ann_L2_poiFact,
					ArcFbkTxt: "#"

				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));

				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
					jQuery.sap.log.info("Error occurred", err);
				});

			} else if (data.ApStatus === "4" && data.ApStatusSub === "4") {
				this.showBusyIndicator(20000, 0);
				var that = this;
				sap.ui.getCore().SAVEFLAG = 0;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyy-MM-dd"
				});
				var oDateformat_half = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHMMss"
				});

				sap.ui.getCore().BatchOprAll = new Array();
				var oModel = this.getView().getModel();
				var user_Data = sap.ui.getCore().USERDATA_E;

				//over all assetment comment saving
				var _POSTCONTEXT_HDR = "ApprisalHeaderNewSet";

				var OVRL_Ann_ARC = sap.ui.getCore().byId("Approver_2--Annual_overAllCMNT_ARC").getText();
				var Ann_ARC_date = oDateformat_half.format(new Date());

				var POSTENTRY = {
					RvwRevTxt: OVRL_Ann_ARC,
					ARC_FBK_DAT: Ann_ARC_date

				};
				sap.ui.getCore().BatchOprAll.push(oModel.createBatchOperation(_POSTCONTEXT_HDR + "(EmpId='" + user_Data.EmpId +
					"',FiscalYear='" + sap.ui.getCore().Year_Sel + "')", "PUT", POSTENTRY));

				console.log(sap.ui.getCore().BatchOprAll);
				oModel.addBatchChangeOperations(sap.ui.getCore().BatchOprAll);
				//oModel.addBatchReadOperations("PARAM_DET");
				oModel.setUseBatch(true);
				oModel.submitBatch(function(data) {
					oModel.refresh();

					//sap.m.MessageToast.show("Saved Successfully");
					if (data.__batchResponses[0].__changeResponses) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("Saved Successfully");

						//jQuery.sap.log.info("Inserted " + data.__batchResponses[0].__changeResponses.length + " Employee(s)");
					} else {
						//sap.m.MessageToast.show("Please check network connection");
						jQuery.sap.log.info(data.__batchResponses[0].message);
						sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
						sap.ui.core.BusyIndicator.hide();
					}
				}, function(err) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("A connection with the server could not be established" + err.message);
					jQuery.sap.log.info("Error occurred", err);
				});

			}
		},
		mngr_submit: function() {
			var data = sap.ui.getCore().USERDATA_E;

			if (data.ApStatus === "2" && data.ApStatusSub === "3") {
				//sap.ui.getCore().EMPid = "";
				var that = this;
				var selectedkey = sap.ui.getCore().byId("Approver_2--__group0").getSelectedIndex();
				if (selectedkey === 0) {
					//user status update
					var UserData = sap.ui.getCore().USERDATA_E;
					var oModel = this.getView().getModel();
					var _UPDATESTATUS = "EmployeeStatusSet";

					var POSTENTRY = {
						"EmpCode": UserData.EmpCode,
						"FiscalYear": UserData.FiscalYear,
						"ActionFlag": "A",
						"EmpId": UserData.EmpId,
						"ActionComments": ""

					};
					oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
						null,
						function() {
							//that.getView().byId("Apr_Respnc").setEnabled(false);
							sap.m.MessageToast.show("Approved successfully");
							that.getView().getController().perf_path_update();
							sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
						},
						function(error) {
							/*if (sap.ui.getCore().checkConnection) {
								sap.OData.removeHttpClient();
							}*/
							console.log("Approve Error");
						});
				} else {

					var rejectCmnt = this.getView().byId("Reject_cmnt").getValue();
					//user status update
					var UserData = sap.ui.getCore().USERDATA_E;
					var oModel = this.getView().getModel();
					var _UPDATESTATUS = "EmployeeStatusSet";

					var POSTENTRY = {
						"EmpCode": UserData.EmpCode,
						"FiscalYear": UserData.FiscalYear,
						"ActionFlag": "R",
						"EmpId": UserData.EmpId,
						"ActionComments": rejectCmnt

					};
					oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
						null,
						function() {
							//	that.getView().byId("Apr_Respnc").setEnabled(false);
							sap.m.MessageToast.show("Form return to employee");
							that.getView().getController().Perfor_path_goalSet();
							sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
						},
						function(error) {
							/*if (sap.ui.getCore().checkConnection) {
								sap.OData.removeHttpClient();
							}*/
							console.log("Return to employee error");
						});

				}
			} else if (data.ApStatus === "3" && data.ApStatusSub === "3") {
				//user status update
				var that = this;
				var UserData = sap.ui.getCore().USERDATA_E;
				var oModel = this.getView().getModel();
				var _UPDATESTATUS = "EmployeeStatusSet";

				var POSTENTRY = {
					"EmpCode": UserData.EmpCode,
					"FiscalYear": UserData.FiscalYear,
					"ActionFlag": "A",
					"EmpId": UserData.EmpId,
					"ActionComments": ""

				};
				oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
					null,
					function() {
						//	that.getView().byId("Apr_Respnc").setEnabled(false);
						sap.m.MessageToast.show("Approved successfully");
						sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
					},
					function(oError) {
						/*if (sap.ui.getCore().checkConnection) {
							sap.OData.removeHttpClient();
						}*/
						var aa = JSON.parse(oError.response.body);

						alert("Error " + aa.error.message.value);
						console.log("half year Approve Error");
					});
				this.mngr_save();
			} else if (data.ApStatus === "3" && data.ApStatusSub === "5") {
				var that = this;
				//sap.ui.getCore().EMPid = "";
				var that = this;
				var selectedkey = sap.ui.getCore().byId("Approver_2--__group0").getSelectedIndex();
				if (selectedkey === 0) {
					//user status update
					var UserData = sap.ui.getCore().USERDATA_E;
					var oModel = this.getView().getModel();
					var _UPDATESTATUS = "EmployeeStatusSet";

					var POSTENTRY = {
						"EmpCode": UserData.EmpCode,
						"FiscalYear": UserData.FiscalYear,
						"ActionFlag": "A",
						"EmpId": UserData.EmpId,
						"ActionComments": ""

					};
					oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
						null,
						function() {
							//	that.getView().byId("Apr_Respnc").setEnabled(false);
							sap.m.MessageToast.show("Approved successfully");
							sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
						},
						function(oError) {
							var aa = JSON.parse(oError.response.body);

							alert("Error " + aa.error.message.value);
							console.log("Approve Error");
						});
				} else {

					var rejectCmnt = this.getView().byId("Reject_cmnt").getValue();
					//user status update
					var UserData = sap.ui.getCore().USERDATA_E;
					var oModel = this.getView().getModel();
					var _UPDATESTATUS = "EmployeeStatusSet";

					var POSTENTRY = {
						"EmpCode": UserData.EmpCode,
						"FiscalYear": UserData.FiscalYear,
						"ActionFlag": "R",
						"EmpId": UserData.EmpId,
						"ActionComments": rejectCmnt

					};
					oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
						null,
						function() {
							//	that.getView().byId("Apr_Respnc").setEnabled(false);
							sap.m.MessageToast.show("Form return to employee");
							that.getView().getController().Perfor_path_goalSet();
							sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
						},
						function(oError) {
							var aa = JSON.parse(oError.response.body);

							alert("Error " + aa.error.message.value);
							console.log("Return to employee error");
						});

				}

			} else if (data.ApStatus === "4" && data.ApStatusSub === "2") {

				//user status update
				var that = this;
				var UserData = sap.ui.getCore().USERDATA_E;
				var oModel = this.getView().getModel();
				var _UPDATESTATUS = "EmployeeStatusSet";

				var POSTENTRY = {
					"EmpCode": UserData.EmpCode,
					"FiscalYear": UserData.FiscalYear,
					"ActionFlag": "A",
					"EmpId": UserData.EmpId,
					"ActionComments": ""

				};
				oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
					null,
					function() {
						//	that.getView().byId("Apr_Respnc").setEnabled(false);
						sap.m.MessageToast.show("Approved successfully");
						sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
					},
					function(oError) {
						/*if (sap.ui.getCore().checkConnection) {
							sap.OData.removeHttpClient();
						}*/
						var aa = JSON.parse(oError.response.body);

						alert("Error " + aa.error.message.value);
						console.log("half year Approve Error");
					});
				this.mngr_save();

			} else if (data.ApStatus === "4" && data.ApStatusSub === "3") {

				//user status update
				var that = this;
				var UserData = sap.ui.getCore().USERDATA_E;
				var oModel = this.getView().getModel();
				var _UPDATESTATUS = "EmployeeStatusSet";

				var POSTENTRY = {
					"EmpCode": UserData.EmpCode,
					"FiscalYear": UserData.FiscalYear,
					"ActionFlag": "A",
					"EmpId": UserData.EmpId,
					"ActionComments": ""

				};
				oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
					null,
					function() {
						//	that.getView().byId("Apr_Respnc").setEnabled(false);
						sap.m.MessageToast.show("Approved successfully");
						sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
					},
					function(oError) {
						/*if (sap.ui.getCore().checkConnection) {
							sap.OData.removeHttpClient();
						}*/
						var aa = JSON.parse(oError.response.body);

						alert("Error " + aa.error.message.value);
						console.log("half year Approve Error");
					});
				this.mngr_save();

			} else if (data.ApStatus === "4" && data.ApStatusSub === "4") {

				//user status update
				var that = this;
				var UserData = sap.ui.getCore().USERDATA_E;
				var oModel = this.getView().getModel();
				var _UPDATESTATUS = "EmployeeStatusSet";

				var POSTENTRY = {
					"EmpCode": UserData.EmpCode,
					"FiscalYear": UserData.FiscalYear,
					"ActionFlag": "A",
					"EmpId": UserData.EmpId,
					"ActionComments": ""

				};
				oModel.update(_UPDATESTATUS + "(FiscalYear='" + UserData.FiscalYear + "',EmpId='" + UserData.EmpId + "')", POSTENTRY,
					null,
					function() {
						//	that.getView().byId("Apr_Respnc").setEnabled(false);
						sap.m.MessageToast.show("Approved successfully");
						sap.ui.core.UIComponent.getRouterFor(that).navTo("_Approver", {});
					},
					function(oError) {
						/*if (sap.ui.getCore().checkConnection) {
							sap.OData.removeHttpClient();
						}*/
						var aa = JSON.parse(oError.response.body);

						alert("Error " + aa.error.message.value);
						console.log("half year Approve Error");
					});
				this.mngr_save();

			}
		},
		onprint: function() {

			var year = sap.ui.getCore().USERDATA_E.FiscalYear;
			var table = "<!DOCTYPE html>" + "<html xmlns='http://www.w3.org/1999/xhtml'>" + "<head>" +
				"<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />" + "<title>Dr. Reddy's</title>" + "</head>" +
				"<body style='margin:0 auto; width:1000px; font-family:Verdana, Geneva, sans-serif;'>" +
				"<div style='border:1px solid #666; padding:0 30px;'>" + "<div style='padding:10px;'>" + "<table width='100%'>" + "<tr>" +
				"<td style='height:auto; width:90%;'>" + "<td style='height:auto; width:200px;'>" +
				"<img style='display:block; width:180px;height:50px;' src='data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=' height:auto; width:150px;/>" +
				"</td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>" +
				"<h1 style='font-size:25px; padding:5px 10px; margin-bottom:10px;'>" + sap.ui.getCore().P_title + " " + year + "</h1>" + "</div>" +
				"<div style='margin-bottom:10px;'>" + "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" +
				sap.ui.getCore().P_empinfo + "</h2>" + "<table width='100%' border='0' style='margin:0 0 0px 0;'>";
			var EmpData = sap.ui.getCore().USERDATA_E;

			var Fname = EmpData.EmpName;
			var EmpCode = EmpData.EmpId;
			var Desig = EmpData.DesignText;
			var Unit = EmpData.UnitTex;
			var Depart = EmpData.DepartText;
			var band = EmpData.BandText;
			var L_1 = EmpData.ApprName;
			var L_2 = EmpData.OtherName;
			var Mmngr = EmpData.PartApprName;
			var L_1desgn = EmpData.ApprDesignation;
			var L_2desgn = EmpData.OtherDesignation;
			table += "<tr>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
				sap.ui.getCore().P_Fname + "</strong></p></td>" +
				"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Fname + "</p></td>" +
				"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_empNO +
				"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
				EmpCode + "</p></td>" + "</tr>" + "<tr>" +
				"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_desg +
				"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
				Desig + "</p></td>" + "<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" +
				sap.ui.getCore().P_deprt + "</strong></p></td>" +
				"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + Depart + "</p></td>" +
				"</tr>" + "<tr>" +
				"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+1:</strong></p></td>" +
				"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_1 + "</p></td>" +
				"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_1_desg +
				"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
				L_1desgn + "</p></td>" + "</tr>" + "<tr>" +
				"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>L+2:</strong></p></td>" +
				"<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" + L_2 + "</p></td>" +
				"<td width='20%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'><strong>" + sap.ui.getCore().P_L_2_desg +
				"</strong></p></td>" + "<td width='30%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px;'>" +
				L_2desgn + "</p></td>" + "</tr>" + "</table>" + "</div>" + "<div style='margin-bottom:10px;'>";
			var temp = sap.ui.getCore().ODThis.getView().byId("Func_list_Apr").getModel().getData().modelData.length;
			if (temp !== 0) {

				table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_func +
					"</h2>"
				var func_goal = sap.ui.getCore().ODThis.getView().byId("Func_list_Apr");
				var data = func_goal.getModel().getData().modelData;
				for (var i = 0; i < data.length; i++) {

					table += "<table width='100%' border='0' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
						"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
						"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
						"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
						data[i].GoalSdate + "</p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
						data[i].GoalDate + "</p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
						data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
						"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
						"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
					var match = /\r|\n/.exec(data[i].KraText);
					if (match) {
						var arr100 = data[i].KraText.split(match);
						var finstr = "";
						for (var j = 0; j < arr100.length; j++) {
							finstr = finstr + arr100[j] + "<br>"
						}
					} else {
						finstr = data[i].KraText;
					}

					table += finstr + "</p></td>" + "</tr>" + "<tr>" +
						"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
						"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
					var match = /\r|\n/.exec(data[i].KpiText);
					if (match) {
						var arr100 = data[i].KpiText.split(match);
						var finstr = "";
						for (var j = 0; j < arr100.length; j++) {
							finstr = finstr + arr100[j] + "<br>"
						}
					} else {
						finstr = data[i].KpiText;
					}
					table += finstr + "</p></td>" + "</tr>"

					+ "</table>";
				}
			}
			var func_goal = sap.ui.getCore().ODThis.getView().byId("Proj_list_Apr");
			var func_goallen = sap.ui.getCore().ODThis.getView().byId("Proj_list_Apr").getModel().getData().modelData.length;
			if (func_goallen !== 0) {
				table += "<h2 style='background-color:#CCC; margin-bottom:10px; font-size:20px; padding:5px 10px;'>" + sap.ui.getCore().mnu_proj +
					"</h2>"
				var data = func_goal.getModel().getData().modelData;
				for (var i = 0; i < data.length; i++) {

					table += "<table width='100%' style='margin:0 0 10px 0; border: 1px solid #bfbfbf;'>" + "<tr>" +
						"<td colspan='15'><h4 style='font-size:15px; padding:0 10px; margin:0;'>" + data[i].GoalName + "</h4></td>" + "</tr>" + "<tr>" +
						"<td colspan='1' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_startDt + ":</strong></p></td>" +
						"<td colspan='2' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
						data[i].GoalSdate + "</p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_complDt + ":</strong></p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
						data[i].GoalDate + "</p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_Weight + ":</strong></p></td>" +
						"<td colspan='3' width='15%'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>" +
						data[i].Weightage + "</p></td>" + "</tr>" + "<tr>" +
						"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_KRA + ":</strong></p></td>" +
						"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
					var match = /\r|\n/.exec(data[i].KraText);
					if (match) {
						var arr100 = data[i].KraText.split(match);
						var finstr = "";
						for (var j = 0; j < arr100.length; j++) {
							finstr = finstr + arr100[j] + "<br>"
						}
					} else {
						finstr = data[i].KraText;
					}

					table += finstr + "</p></td>" + "</tr>" + "<tr>" +
						"<td width='10%' colspan='1'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'><strong>" +
						sap.ui.getCore().fun_owngoal_KPI + ":</strong></p></td>" +
						"<td width='90%' colspan='14'><p style='font-size:12px; text-align:justify; margin-bottom:5px; padding:0 10px; margin-top: 0px;'>";
					var match = /\r|\n/.exec(data[i].KpiText);
					if (match) {
						var arr100 = data[i].KpiText.split(match);
						var finstr = "";
						for (var j = 0; j < arr100.length; j++) {
							finstr = finstr + arr100[j] + "<br>"
						}
					} else {
						finstr = data[i].KpiText;
					}
					table += finstr + "</p></td>" + "</tr>" + "</table>";
				}
			}
			table += "</div>" + "</div>" + "</body>" + "</html>";
			var ua = window.navigator.userAgent;
			var msie = ua.indexOf("MSIE ");

			if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) // If Internet Explorer, return version number
			{
				var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
				var printDocument = printPreview.document;
				printDocument.open();
				printDocument.write(table);
				printDocument.close();
			} else if (ua.indexOf("Chrome") > 0 || ua.indexOf("Mozilla") == 0) {
				var wind = window.open("", "PrintWindow", "width=900px,height=900px");
				wind.document.write(table);
				wind.print();
				wind.close();
			}

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.drl.pmsManagermobile.view.Approver_2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.drl.pmsManagermobile.view.Approver_2
		 */
		onAfterRendering1: function() {

			if (sap.ui.getCore().USERDATA_E.ApStatus === "3" && sap.ui.getCore().USERDATA_E.ApStatusSub === "3") {

				//goals comment enable/disabe logic
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

				}
				this.getView().getController().timeline_dataset();
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "3" && sap.ui.getCore().USERDATA_E.ApStatusSub === "5") {
				this.getView().getController().timeline_dataset();
				//this.getView().getController().perf_path_update();
				//goals comment enable/disabe logic
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);
				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);
				}

			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "4" && sap.ui.getCore().USERDATA_E.ApStatusSub === "2") {
				//annual data set	
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);

					//ANN comment set
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnSlfTxt);
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (functionalGoals[i].HYR_FBK_DAT !== "") {
						var datetime = functionalGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Hy_mngr_Date =	oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

					//set date time of timeline
					var Hy_Emp_Date = new Date();
					if (functionalGoals[i].HYR_EMP_DAT !== "") {
						var datetime = functionalGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
								Hy_Emp_Date =	oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
					id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					id.setDateTime(Hy_Emp_Date);
					id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (functionalGoals[i].ANN_SLF_DAT !== "") {
						var datetime = functionalGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date =	oDateFormat.format(Ann_EMP_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (functionalGoals[i].ANN_LP1_DAT !== "") {
						var datetime = functionalGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Ann_L1_Date =	oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set L+1 photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					//	sap.ui.getCore().byId("Approver_2--Annual_timelineText_mngrcmnt-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnLp1Txt);

				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

					//ANN comment editable false
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnSlfTxt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (projectGoals[i].HYR_FBK_DAT !== "") {
						var datetime = projectGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_mngr_Date =	oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					var Hy_Emp_Date = new Date();
					if (projectGoals[i].HYR_EMP_DAT !== "") {
						//set date time of timeline
						var datetime = projectGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date =	oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
					IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					IDP.setDateTime(Hy_Emp_Date);
					IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//annual data set
					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (projectGoals[i].ANN_SLF_DAT !== "") {
						var datetime = projectGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date =	oDateFormat.format(Ann_EMP_Date);
					}
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (projectGoals[i].ANN_LP1_DAT !== "") {
						var datetime = projectGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Ann_L1_Date =	oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
						.USERDATA_E.ApprName);
					//	sap.ui.getCore().byId("Approver_2--Annual_timelineText_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnLp1Txt);

				}
				//	this.onAnn_L1_RAT();
				//this.onAnn_L2_RAT();

				var sel_list = this.getView().byId("Ann_L1_Poifact");
				//var item_sel = this.getView().byId("Ann_L1_rating");
				var SEL_ITEM = sap.ui.getCore().USERDATA_E.AnnLp1Val;
				var data = [];
				if (SEL_ITEM === " ") {

				} else if (SEL_ITEM === "1.000") {
					data = [];
					data.push({
						key: "0",
						value: "0.00"
					});

				} else if (SEL_ITEM === "2.000") {
					data = [];
					data.push({
						key: "0.600",
						value: "0.60"
					}, {
						key: "0.650",
						value: "0.65"
					}, {
						key: "0.700",
						value: "0.70"
					}, {
						key: "0.750",
						value: "0.75"
					}, {
						key: "0.800",
						value: "0.80"
					}, {
						key: "0.850",
						value: "0.85"
					}, {
						key: "0.900",
						value: "0.90"
					}, {
						key: "0.950",
						value: "0.95"
					}, {
						key: "1.000",
						value: "1.00"
					}, {
						key: "1.050",
						value: "1.05"
					}, {
						key: "1.100",
						value: "1.10"
					}, {
						key: "1.150",
						value: "1.15"
					}, {
						key: "1.200",
						value: "1.20"
					});

				} else if (SEL_ITEM === "3.000") {
					data = [];
					data.push({
						key: "1.250",
						value: "1.25"
					}, {
						key: "1.300",
						value: "1.30"
					}, {
						key: "1.350",
						value: "1.35"
					}, {
						key: "1.400",
						value: "1.40"
					}, {
						key: "1.450",
						value: "1.45"
					}, {
						key: "1.500",
						value: "1.50"
					});

				}
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: data
				});

				sel_list.setModel(oModel);
				sel_list.bindItems("/modelData",
					new sap.ui.core.Item({
						key: "{key}",
						text: "{value}"
					})
				);

				var L1_Rat = parseInt(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				//	this.getView().byId("Ann_L1_rating").setSelectedKey(L1_Rat);
				var L1_PoiFct = sap.ui.getCore().USERDATA_E.PftLp1Val;
				this.getView().byId("Ann_L1_Poifact").setSelectedKey(L1_PoiFct);

				this.getView().byId("Annual_overallAsset_Lp2").setVisible(false);
				this.getView().byId("Annual_ARC").setVisible(false);

			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "4" && sap.ui.getCore().USERDATA_E.ApStatusSub === "3") {
				//annual data set
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);

					//ANN comment set employee self
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (functionalGoals[i].HYR_FBK_DAT !== "") {
						var datetime = functionalGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

					//set date time of timeline
					var Hy_Emp_Date = new Date();
					if (functionalGoals[i].HYR_EMP_DAT !== "") {
						var datetime = functionalGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
					id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					id.setDateTime(Hy_Emp_Date);
					id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (functionalGoals[i].ANN_SLF_DAT !== "") {
						var datetime = functionalGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
								Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (functionalGoals[i].ANN_LP1_DAT !== "") {
						var datetime = functionalGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
								Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set L+1 photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

					//ANN comment editable false employee self appraisal
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (projectGoals[i].HYR_FBK_DAT !== "") {
						var datetime = projectGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					var Hy_Emp_Date = new Date();
					if (projectGoals[i].HYR_EMP_DAT !== "") {
						//set date time of timeline
						var datetime = projectGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
					IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					IDP.setDateTime(Hy_Emp_Date);
					IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//annual data set
					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (projectGoals[i].ANN_SLF_DAT !== "") {
						var datetime = projectGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (projectGoals[i].ANN_LP1_DAT !== "") {
						var datetime = projectGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
						.USERDATA_E.ApprName);

				}
				//	this.onAnn_L1_RAT();
				//	this.onAnn_L2_RAT();
				var sel_list = this.getView().byId("Ann_L1_Poifact");
				//var item_sel = this.getView().byId("Ann_L1_rating");
				var SEL_ITEM = sap.ui.getCore().USERDATA_E.AnnLp1Val;
				var data = [];
				if (SEL_ITEM === " ") {

				} else if (SEL_ITEM === "1.000") {
					data = [];
					data.push({
						key: "0",
						value: "0.00"
					});

				} else if (SEL_ITEM === "2.000") {
					data = [];
					data.push({
						key: "0.600",
						value: "0.60"
					}, {
						key: "0.650",
						value: "0.65"
					}, {
						key: "0.700",
						value: "0.70"
					}, {
						key: "0.750",
						value: "0.75"
					}, {
						key: "0.800",
						value: "0.80"
					}, {
						key: "0.850",
						value: "0.85"
					}, {
						key: "0.900",
						value: "0.90"
					}, {
						key: "0.950",
						value: "0.95"
					}, {
						key: "1.000",
						value: "1.00"
					}, {
						key: "1.050",
						value: "1.05"
					}, {
						key: "1.100",
						value: "1.10"
					}, {
						key: "1.150",
						value: "1.15"
					}, {
						key: "1.200",
						value: "1.20"
					});

				} else if (SEL_ITEM === "3.000") {
					data = [];
					data.push({
						key: "1.250",
						value: "1.25"
					}, {
						key: "1.300",
						value: "1.30"
					}, {
						key: "1.350",
						value: "1.35"
					}, {
						key: "1.400",
						value: "1.40"
					}, {
						key: "1.450",
						value: "1.45"
					}, {
						key: "1.500",
						value: "1.50"
					});

				}
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: data
				});

				sel_list.setModel(oModel);
				sel_list.bindItems("/modelData",
					new sap.ui.core.Item({
						key: "{key}",
						text: "{value}"
					})
				);
				//select box get L1
				var L1_Rat = parseInt(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				// this.getView().byId("Ann_L1_rating").setSelectedKey(L1_Rat);
				// this.getView().byId("Ann_L1_rating").setEnabled(false);
				var L1_PoiFct = sap.ui.getCore().USERDATA_E.PftLp1Val;
				this.getView().byId("Ann_L1_Poifact").setSelectedKey(L1_PoiFct);
				this.getView().byId("Ann_L1_Poifact").setEnabled(false);

				//L+2 pointfactor logic
				var sel_list = this.getView().byId("Ann_L2_Poifact");
				//var item_sel = this.getView().byId("Ann_L1_rating");
				var SEL_ITEM = sap.ui.getCore().USERDATA_E.RvwRevVal;
				var data = [];
				if (SEL_ITEM === " ") {

				} else if (SEL_ITEM === "1.000") {
					data = [];
					data.push({
						key: "0",
						value: "0.00"
					});

				} else if (SEL_ITEM === "2.000") {
					data = [];
					data.push({
						key: "0.600",
						value: "0.60"
					}, {
						key: "0.650",
						value: "0.65"
					}, {
						key: "0.700",
						value: "0.70"
					}, {
						key: "0.750",
						value: "0.75"
					}, {
						key: "0.800",
						value: "0.80"
					}, {
						key: "0.850",
						value: "0.85"
					}, {
						key: "0.900",
						value: "0.90"
					}, {
						key: "0.950",
						value: "0.95"
					}, {
						key: "1.000",
						value: "1.00"
					}, {
						key: "1.050",
						value: "1.05"
					}, {
						key: "1.100",
						value: "1.10"
					}, {
						key: "1.150",
						value: "1.15"
					}, {
						key: "1.200",
						value: "1.20"
					});

				} else if (SEL_ITEM === "3.000") {
					data = [];
					data.push({
						key: "1.250",
						value: "1.25"
					}, {
						key: "1.300",
						value: "1.30"
					}, {
						key: "1.350",
						value: "1.35"
					}, {
						key: "1.400",
						value: "1.40"
					}, {
						key: "1.450",
						value: "1.45"
					}, {
						key: "1.500",
						value: "1.50"
					});

				}
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: data
				});

				sel_list.setModel(oModel);
				sel_list.bindItems("/modelData",
					new sap.ui.core.Item({
						key: "{key}",
						text: "{value}"
					})
				);
				//Annual L+2 comment get
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				//select box get L2
				var L1_Rat = parseInt(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("Ann_L2_rating").setSelectedKey(L1_Rat);
				var L1_PoiFct = sap.ui.getCore().USERDATA_E.PftLp2Val;
				this.getView().byId("Ann_L2_Poifact").setSelectedKey(L1_PoiFct);

				this.getView().byId("Annual_overallAsset_Lp2").setVisible(true);
				this.getView().byId("Annual_ARC").setVisible(false);

			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "4" && sap.ui.getCore().USERDATA_E.ApStatusSub === "4") {
				//annual data set	
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);

					//ANN comment set employee self
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (functionalGoals[i].HYR_FBK_DAT !== "") {
						var datetime = functionalGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

					//set date time of timeline
					var Hy_Emp_Date = new Date();
					if (functionalGoals[i].HYR_EMP_DAT !== "") {
						var datetime = functionalGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
					id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					id.setDateTime(Hy_Emp_Date);
					id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (functionalGoals[i].ANN_SLF_DAT !== "") {
						var datetime = functionalGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (functionalGoals[i].ANN_LP1_DAT !== "") {
						var datetime = functionalGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set L+1 photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

					//ANN comment editable false employee self appraisal
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (projectGoals[i].HYR_FBK_DAT !== "") {
						var datetime = projectGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					var Hy_Emp_Date = new Date();
					if (projectGoals[i].HYR_EMP_DAT !== "") {
						//set date time of timeline
						var datetime = projectGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
					IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					IDP.setDateTime(Hy_Emp_Date);
					IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//annual data set
					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (projectGoals[i].ANN_SLF_DAT !== "") {
						var datetime = projectGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (projectGoals[i].ANN_LP1_DAT !== "") {
						var datetime = projectGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
						.USERDATA_E.ApprName);

				}
				// this.onAnn_L1_RAT();
				// this.onAnn_L2_RAT();

				var sel_list = this.getView().byId("Ann_L1_Poifact");
				//var item_sel = this.getView().byId("Ann_L1_rating");
				var SEL_ITEM = sap.ui.getCore().USERDATA_E.AnnLp1Val;
				var data = [];
				if (SEL_ITEM === " ") {

				} else if (SEL_ITEM === "1.000") {
					data = [];
					data.push({
						key: "0",
						value: "0.00"
					});

				} else if (SEL_ITEM === "2.000") {
					data = [];
					data.push({
						key: "0.600",
						value: "0.60"
					}, {
						key: "0.650",
						value: "0.65"
					}, {
						key: "0.700",
						value: "0.70"
					}, {
						key: "0.750",
						value: "0.75"
					}, {
						key: "0.800",
						value: "0.80"
					}, {
						key: "0.850",
						value: "0.85"
					}, {
						key: "0.900",
						value: "0.90"
					}, {
						key: "0.950",
						value: "0.95"
					}, {
						key: "1.000",
						value: "1.00"
					}, {
						key: "1.050",
						value: "1.05"
					}, {
						key: "1.100",
						value: "1.10"
					}, {
						key: "1.150",
						value: "1.15"
					}, {
						key: "1.200",
						value: "1.20"
					});

				} else if (SEL_ITEM === "3.000") {
					data = [];
					data.push({
						key: "1.250",
						value: "1.25"
					}, {
						key: "1.300",
						value: "1.30"
					}, {
						key: "1.350",
						value: "1.35"
					}, {
						key: "1.400",
						value: "1.40"
					}, {
						key: "1.450",
						value: "1.45"
					}, {
						key: "1.500",
						value: "1.50"
					});

				}
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: data
				});

				sel_list.setModel(oModel);
				sel_list.bindItems("/modelData",
					new sap.ui.core.Item({
						key: "{key}",
						text: "{value}"
					})
				);

				//select box get L1
				var L1_Rat = parseInt(sap.ui.getCore().USERDATA_E.AnnLp1Val);
				// this.getView().byId("Ann_L1_rating").setSelectedKey(L1_Rat);
				// this.getView().byId("Ann_L1_rating").setEnabled(false);
				//var L1_PoiFct = parseInt(sap.ui.getCore().USERDATA_E.PftLp1Val);
				this.getView().byId("Ann_L1_Poifact").setSelectedKey(sap.ui.getCore().USERDATA_E.PftLp1Val);
				this.getView().byId("Ann_L1_Poifact").setEnabled(false);

				//Annual L+2 comment get
				var sel_list = this.getView().byId("Ann_L2_Poifact");
				//var item_sel = this.getView().byId("Ann_L1_rating");
				var SEL_ITEM = sap.ui.getCore().USERDATA_E.RvwRevVal;
				var data = [];
				if (SEL_ITEM === " ") {

				} else if (SEL_ITEM === "1.000") {
					data = [];
					data.push({
						key: "0",
						value: "0.00"
					});

				} else if (SEL_ITEM === "2.000") {
					data = [];
					data.push({
						key: "0.600",
						value: "0.60"
					}, {
						key: "0.650",
						value: "0.65"
					}, {
						key: "0.700",
						value: "0.70"
					}, {
						key: "0.750",
						value: "0.75"
					}, {
						key: "0.800",
						value: "0.80"
					}, {
						key: "0.850",
						value: "0.85"
					}, {
						key: "0.900",
						value: "0.90"
					}, {
						key: "0.950",
						value: "0.95"
					}, {
						key: "1.000",
						value: "1.00"
					}, {
						key: "1.050",
						value: "1.05"
					}, {
						key: "1.100",
						value: "1.10"
					}, {
						key: "1.150",
						value: "1.15"
					}, {
						key: "1.200",
						value: "1.20"
					});

				} else if (SEL_ITEM === "3.000") {
					data = [];
					data.push({
						key: "1.250",
						value: "1.25"
					}, {
						key: "1.300",
						value: "1.30"
					}, {
						key: "1.350",
						value: "1.35"
					}, {
						key: "1.400",
						value: "1.40"
					}, {
						key: "1.450",
						value: "1.45"
					}, {
						key: "1.500",
						value: "1.50"
					});

				}
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					modelData: data
				});

				sel_list.setModel(oModel);
				sel_list.bindItems("/modelData",
					new sap.ui.core.Item({
						key: "{key}",
						text: "{value}"
					})
				);
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_L2");
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA_E.RvwRevTxt);
				//Ann_l2_txt.setEnabled(false);
				//select box get L2
				var L1_Rat = parseInt(sap.ui.getCore().USERDATA_E.RvwRevVal);
				this.getView().byId("Ann_L2_rating").setSelectedKey(L1_Rat);
				this.getView().byId("Ann_L2_rating").setEnabled(false);
				//var L1_PoiFct = parseInt(sap.ui.getCore().USERDATA_E.PftLp2Val);
				this.getView().byId("Ann_L2_Poifact").setSelectedKey(sap.ui.getCore().USERDATA_E.PftLp2Val);
				this.getView().byId("Ann_L2_Poifact").setEnabled(false);

				//Annual ARC comment get
				var Ann_l2_txt = this.getView().byId("Annual_overAllCMNT_ARC");
				Ann_l2_txt.setText(sap.ui.getCore().USERDATA_E.ArcFbkTxt);
				//select box get ARC
				var arcrat = sap.ui.getCore().USERDATA_E.FinAppVal;
				var arctx;
				if (arcrat === "1.000") {
					arctx = "Z";
				} else if (arcrat === "2.000") {
					arctx = "A";
				} else if (arcrat === "3.000") {
					arctx = "A+";
				}
				//var L1_Rat = sap.ui.getCore().USERDATA_E.FinAppVal;
				this.getView().byId("Ann_ARC_Rat").setText(arctx);
				//this.getView().byId("Ann_ARC_Rat").setEditable(false);
				var L1_PoiFct = sap.ui.getCore().USERDATA_E.PntFctVal;
				var ARCpont = L1_PoiFct.substring(0, 4);
				this.getView().byId("Ann_ARC_Poifact").setText(ARCpont);
				//this.getView().byId("Ann_ARC_Poifact").setEditable(false);
			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "5" && sap.ui.getCore().USERDATA_E.ApStatusSub === "") {
				//annual data set	
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);

					//ANN comment set employee self
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (functionalGoals[i].HYR_FBK_DAT !== "") {
						var datetime = functionalGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

					//set date time of timeline
					var Hy_Emp_Date = new Date();
					if (functionalGoals[i].HYR_EMP_DAT !== "") {
						var datetime = functionalGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
					id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					id.setDateTime(Hy_Emp_Date);
					id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (functionalGoals[i].ANN_SLF_DAT !== "") {
						var datetime = functionalGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (functionalGoals[i].ANN_LP1_DAT !== "") {
						var datetime = functionalGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
								Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set L+1 photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

					//ANN comment editable false employee self appraisal
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (projectGoals[i].HYR_FBK_DAT !== "") {
						var datetime = projectGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					var Hy_Emp_Date = new Date();
					if (projectGoals[i].HYR_EMP_DAT !== "") {
						//set date time of timeline
						var datetime = projectGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
					IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					IDP.setDateTime(Hy_Emp_Date);
					IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//annual data set
					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (projectGoals[i].ANN_SLF_DAT !== "") {
						var datetime = projectGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (projectGoals[i].ANN_LP1_DAT !== "") {
						var datetime = projectGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
						.USERDATA_E.ApprName);

				}
				// this.onAnn_L1_RAT();
				// this.onAnn_L2_RAT();

			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "7" && sap.ui.getCore().USERDATA_E.ApStatusSub === "") {

				//annual data set	
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);

					//ANN comment set employee self
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (functionalGoals[i].HYR_FBK_DAT !== "") {
						var datetime = functionalGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Hy_mngr_Date =	oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

					//set date time of timeline
					var Hy_Emp_Date = new Date();
					if (functionalGoals[i].HYR_EMP_DAT !== "") {
						var datetime = functionalGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date =	oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
					id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					id.setDateTime(Hy_Emp_Date);
					id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (functionalGoals[i].ANN_SLF_DAT !== "") {
						var datetime = functionalGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date =	oDateFormat.format(Ann_EMP_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (functionalGoals[i].ANN_LP1_DAT !== "") {
						var datetime = functionalGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date =	oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set L+1 photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

					//ANN comment editable false employee self appraisal
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).destroyEmbeddedControl();
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (projectGoals[i].HYR_FBK_DAT !== "") {
						var datetime = projectGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Hy_mngr_Date =	oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					var Hy_Emp_Date = new Date();
					if (projectGoals[i].HYR_EMP_DAT !== "") {
						//set date time of timeline
						var datetime = projectGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date =	oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
					IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					IDP.setDateTime(Hy_Emp_Date);
					IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//annual data set
					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (projectGoals[i].ANN_SLF_DAT !== "") {
						var datetime = projectGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Ann_EMP_Date =	oDateFormat.format(Ann_EMP_Date);
					}
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (projectGoals[i].ANN_LP1_DAT !== "") {
						var datetime = projectGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date =	oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
						.USERDATA_E.ApprName);

				}
				// this.onAnn_L1_RAT();
				// this.onAnn_L2_RAT();

				//select box get L1
			

			} else if (sap.ui.getCore().USERDATA_E.ApStatus === "9" && sap.ui.getCore().USERDATA_E.ApStatusSub === "") {

				//annual data set	
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
				var goals = sap.ui.getCore().GOALS_E.results;
				var functionalGoals = [];
				var projectGoals = [];
				for (var i = 0; i < goals.length; i++) {
					if (goals[i].GoalId === '0001') {
						functionalGoals.push(goals[i]);
					} else if (goals[i].GoalId === '0002') {
						projectGoals.push(goals[i]);
					}
				}
				for (var i = 0; i < functionalGoals.length; i++) {
					//get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrEmpTxt);
					//mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].HyrFbkTxt);

					//ANN comment set employee self
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setText(functionalGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (functionalGoals[i].HYR_FBK_DAT !== "") {
						var datetime = functionalGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

					//set date time of timeline
					var Hy_Emp_Date = new Date();
					if (functionalGoals[i].HYR_EMP_DAT !== "") {
						var datetime = functionalGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
					id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					id.setDateTime(Hy_Emp_Date);
					id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (functionalGoals[i].ANN_SLF_DAT !== "") {
						var datetime = functionalGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
								Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (functionalGoals[i].ANN_LP1_DAT !== "") {
						var datetime = functionalGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set L+1 photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

				}
				for (var i = 0; i < projectGoals.length; i++) {
					//HY get timeline text area text
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrEmpTxt);
					//HY mngr comment editable false
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].HyrFbkTxt);

					//ANN comment editable false employee self appraisal
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnSlfTxt);

					//Ann L+1
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setText(projectGoals[i].AnnLp1Txt);

					//half year data set
					//set date time of timeline
					var Hy_mngr_Date = new Date();
					if (projectGoals[i].HYR_FBK_DAT !== "") {
						var datetime = projectGoals[i].HYR_FBK_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
						Hy_mngr_Date = oDateFormat.format(Hy_mngr_Date);
					}
					// mngr comment timeline set 
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
						.ApproverImage);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_mngr_Date);
					sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.ApprName);

					var Hy_Emp_Date = new Date();
					if (projectGoals[i].HYR_EMP_DAT !== "") {
						//set date time of timeline
						var datetime = projectGoals[i].HYR_EMP_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Hy_Emp_Date = oDateFormat.format(Hy_Emp_Date);
					}
					//emp commment timeline set
					var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
					IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
					IDP.setDateTime(Hy_Emp_Date);
					IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

					//annual data set
					//set date time of timeline
					var Ann_EMP_Date = new Date();
					if (projectGoals[i].ANN_SLF_DAT !== "") {
						var datetime = projectGoals[i].ANN_SLF_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_EMP_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_EMP_Date = oDateFormat.format(Ann_EMP_Date);
					}
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.EmpImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_EMP_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
						.EmpName);
					//hide annual manager timeline
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setVisible(true);

					//ANN L+1 comment
					var Ann_L1_Date = new Date();
					if (projectGoals[i].ANN_LP1_DAT !== "") {
						var datetime = projectGoals[i].ANN_LP1_DAT;

						var y = datetime.substring(0, 3);
						var y = datetime.substring(0, 4);
						var m = datetime.substring(4, 6);
						var d = datetime.substring(6, 8);
						var H = datetime.substring(8, 10);
						var Min = datetime.substring(10, 12);
						var sec = datetime.substring(12, 14);
						Ann_L1_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
							Ann_L1_Date = oDateFormat.format(Ann_L1_Date);
					}
					//Annual data set
					//set EMP photo and datetime
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
						.USERDATA_E.ApproverImage);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(Ann_L1_Date);
					sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
						.USERDATA_E.ApprName);

				}
				// this.onAnn_L1_RAT();
				// this.onAnn_L2_RAT();

			

			}

		},

		timeline_dataset: function() {

			var goals = sap.ui.getCore().GOALS_E.results;
			var functionalGoals = [];
			var projectGoals = [];
			for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0001') {
					functionalGoals.push(goals[i]);
				} else if (goals[i].GoalId === '0002') {
					projectGoals.push(goals[i]);
				}
			}
			for (var i = 0; i < functionalGoals.length; i++) {
				//set date time of timeline
				var Hy_Emp_Date = new Date();
				if (functionalGoals[i].HYR_EMP_DAT !== "") {
					var datetime = functionalGoals[i].HYR_EMP_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}
				//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if (functionalGoals[i].HYR_FBK_DAT !== "") {
					//set date time of timeline
					var datetime = functionalGoals[i].HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_Mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				}

				// mngr comment timeline set 
				sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
					.ApproverImage);
				sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setDateTime(Hy_Mngr_Date);
				sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E.ApprName);

				//emp commment timeline set
				var id = sap.ui.getCore().byId("Approver_2--_idTimelineItem-Approver_2--Func_list_Apr-" + i);
				id.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				id.setDateTime(Hy_Emp_Date);
				id.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

			}
			for (var i = 0; i < projectGoals.length; i++) {
				//mngr timeline date code
				var Hy_Mngr_Date = new Date();
				if (projectGoals[i].HYR_FBK_DAT !== "") {
						var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "dd/MM/YYYY HH:MM"
				});
					//set date time of timeline
					var datetime = projectGoals[i].HYR_FBK_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_Mngr_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
				Hy_Mngr_Date =	oDateFormat.format(Hy_Mngr_Date);
				}
				//employee timeline datetime
				var Hy_Emp_Date = new Date();
				if (projectGoals[i].HYR_EMP_DAT !== "") {
					//set date time of timeline
					var datetime = projectGoals[i].HYR_EMP_DAT;

					var y = datetime.substring(0, 3);
					var y = datetime.substring(0, 4);
					var m = datetime.substring(4, 6);
					var d = datetime.substring(6, 8);
					var H = datetime.substring(8, 10);
					var Min = datetime.substring(10, 12);
					var sec = datetime.substring(12, 14);
					Hy_Emp_Date = new Date(y + "/" + m + "/" + d + " " + H + ":" + Min + ":" + sec);
					Hy_Emp_Date =	oDateFormat.format(Hy_Emp_Date);
				}
				// mngr comment timeline set 
				sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
					.ApproverImage);
				sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setDateTime(Hy_Mngr_Date);
				sap.ui.getCore().byId("Approver_2--_idTimelineItem_mngr_proj-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
					.ApprName);

				//emp commment timeline set
				var IDP = sap.ui.getCore().byId("Approver_2--_idTimelineItem_proj-Approver_2--Proj_list_Apr-" + i);
				IDP.setUserPicture(sap.ui.getCore().USERDATA_E.EmpImage);
				IDP.setDateTime(Hy_Emp_Date);
				IDP.setUserName(sap.ui.getCore().USERDATA_E.EmpName);

			}

		},
		Annual_timeline_dataset: function() {
			var goals = sap.ui.getCore().GOALS_E.results;
			var functionalGoals = [];
			var projectGoals = [];
			for (var i = 0; i < goals.length; i++) {
				if (goals[i].GoalId === '0001') {
					functionalGoals.push(goals[i]);
				} else if (goals[i].GoalId === '0002') {
					projectGoals.push(goals[i]);
				}
			}
			for (var i = 0; i < functionalGoals.length; i++) {
				//set EMP photo and datetime
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore().USERDATA_E
					.EmpImage);
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setDateTime(new Date());
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_EMP-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
					.EmpName);
				//set manager photo and datetime
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserPicture(sap.ui.getCore()
					.USERDATA_E.ApproverImage);
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setDateTime(new Date());
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_mngrcmnt-Approver_2--Func_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
					.ApprName);
			}
			for (var i = 0; i < projectGoals.length; i++) {
				//set EMP photo and datetime
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
					.USERDATA_E.EmpImage);
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setDateTime(new Date());
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_EMP-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore().USERDATA_E
					.EmpName);
				//set manager photo and datetime
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserPicture(sap.ui.getCore()
					.USERDATA.EmpImage);
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setDateTime(new Date());
				sap.ui.getCore().byId("Approver_2--Annual_idTimelineItem_proj_mngrcmnt-Approver_2--Proj_list_Apr-" + i).setUserName(sap.ui.getCore()
					.USERDATA.EmpName);
			}
		},
		//Annual Rating and point factor binding
		onAnn_L1_RAT: function(evt) {
			var sel_list = this.getView().byId("Ann_L1_Poifact");
			//var item_sel = this.getView().byId("Ann_L1_rating");
			//	var SEL_ITEM = this.getView().byId("Ann_L1_rating").getSelectedItem().getText();
			var data = [];
			if (SEL_ITEM === " ") {

			} else if (SEL_ITEM === "Z") {
				data = [];
				data.push({
					key: "0",
					value: "0.00"
				});

			} else if (SEL_ITEM === "A") {
				data = [];
				data.push({
					key: "0.600",
					value: "0.60"
				}, {
					key: "0.650",
					value: "0.65"
				}, {
					key: "0.700",
					value: "0.70"
				}, {
					key: "0.750",
					value: "0.75"
				}, {
					key: "0.800",
					value: "0.80"
				}, {
					key: "0.850",
					value: "0.85"
				}, {
					key: "0.900",
					value: "0.90"
				}, {
					key: "0.950",
					value: "0.95"
				}, {
					key: "1.000",
					value: "1.00"
				}, {
					key: "1.050",
					value: "1.05"
				}, {
					key: "1.100",
					value: "1.10"
				}, {
					key: "1.150",
					value: "1.15"
				}, {
					key: "1.200",
					value: "1.20"
				});

			} else if (SEL_ITEM === "A+") {
				data = [];
				data.push({
					key: "1.250",
					value: "1.25"
				}, {
					key: "1.300",
					value: "1.30"
				}, {
					key: "1.350",
					value: "1.35"
				}, {
					key: "1.400",
					value: "1.40"
				}, {
					key: "1.450",
					value: "1.45"
				}, {
					key: "1.500",
					value: "1.50"
				});

			}
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: data
			});

			sel_list.setModel(oModel);
			sel_list.bindItems("/modelData",
				new sap.ui.core.Item({
					key: "{key}",
					text: "{value}"
				})
			);
		},
		//Annual Rating and point factor binding
		onAnn_L2_RAT: function(evt) {
			var sel_list = this.getView().byId("Ann_L2_Poifact");
			//var item_sel = this.getView().byId("Ann_L2_rating");
			var SEL_ITEM = this.getView().byId("Ann_L2_rating").getSelectedItem().getText();
			var data = [];
			if (SEL_ITEM === " ") {

			} else if (SEL_ITEM === "Z") {
				data = [];
				data.push({
					key: "0",
					value: "0.00"
				});

			} else if (SEL_ITEM === "A") {
				data = [];
				data.push({
					key: "0.600",
					value: "0.60"
				}, {
					key: "0.650",
					value: "0.65"
				}, {
					key: "0.700",
					value: "0.70"
				}, {
					key: "0.750",
					value: "0.75"
				}, {
					key: "0.800",
					value: "0.80"
				}, {
					key: "0.850",
					value: "0.85"
				}, {
					key: "0.900",
					value: "0.90"
				}, {
					key: "0.950",
					value: "0.95"
				}, {
					key: "1.000",
					value: "1.00"
				}, {
					key: "1.050",
					value: "1.05"
				}, {
					key: "1.100",
					value: "1.10"
				}, {
					key: "1.150",
					value: "1.15"
				}, {
					key: "1.200",
					value: "1.20"
				});

			} else if (SEL_ITEM === "A+") {
				data = [];
				data.push({
					key: "1.250",
					value: "1.25"
				}, {
					key: "1.300",
					value: "1.30"
				}, {
					key: "1.350",
					value: "1.35"
				}, {
					key: "1.400",
					value: "1.40"
				}, {
					key: "1.450",
					value: "1.45"
				}, {
					key: "1.500",
					value: "1.50"
				});

			}
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({
				modelData: data
			});

			sel_list.setModel(oModel);
			sel_list.bindItems("/modelData",
				new sap.ui.core.Item({
					key: "{key}",
					text: "{value}"
				})
			);
		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.drl.pmsManagermobile.view.Approver_2
		 */
		//	onExit: function() {
		//
		//	}

	});

});