sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.drl.pmsManagermobile.controller.Approver", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.drl.pmsManagermobile.view.Approver
		 */
		onInit: function() {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this._handleRouteMatched, this);

			// change language according to ser info ///////////
			////// global variable for language////////
			sap.ui.getCore().Perf_path_text = "Performance Path";
			sap.ui.getCore().ru_empcode = "EMP code";
			sap.ui.getCore().ru_rleband = "Role Band";
			sap.ui.getCore().ru_deprt = "Department";
			sap.ui.getCore().ru_unit = "Unit/BU";
			sap.ui.getCore().ru_mngrL1 = "Manager(L+1)";
			sap.ui.getCore().ru_mngrL2 = "Reviewer(L+2)";
			sap.ui.getCore().ru_mmngr = "Matrix manager";
			sap.ui.getCore().Goal_header = "Goals";
			sap.ui.getCore().Goal_approver = "Goal Approval";
			sap.ui.getCore().Perf_GoalSetting = "Goal Setting";
			sap.ui.getCore().Perf_goalApproval = "Goal Approval";
			sap.ui.getCore().Perf_halfyearly = "Half Yearly";
			sap.ui.getCore().Perf_annualReview = "Annual Review";
			sap.ui.getCore().Perf_Finalsignoff = "Final sign off";
			sap.ui.getCore().Perf_ARC = "ARC";
			sap.ui.getCore().ru_FunctionalGoals = "Functional Goal";
			sap.ui.getCore().ru_ProjectGoals = "Project Goal";
			sap.ui.getCore().ru_Approve = "Approve";
			sap.ui.getCore().ru_returnemp = "Return to employee";
			sap.ui.getCore().ru_cmnt = "Comment";
			sap.ui.getCore().Goal_header = "Goals";
			sap.ui.getCore().submit = "Submit";

			//PDF print global variable 
			sap.ui.getCore().P_title = "Performance Management";
			sap.ui.getCore().P_empinfo = "Employee Information";
			sap.ui.getCore().P_Fname = "First Name:";
			sap.ui.getCore().P_empNO = "Employee Number:";
			sap.ui.getCore().P_desg = "Designation:";
			sap.ui.getCore().P_deprt = "Department:";
			sap.ui.getCore().P_L_1 = "L+1:";
			sap.ui.getCore().P_L_1_desg = "L+1 Designation:";
			sap.ui.getCore().P_L_2 = "L+2:";
			sap.ui.getCore().P_L_2_desg = "L+2 Designation:";
			sap.ui.getCore().fun_owngoal_KRA = "KRA/Goals";
			sap.ui.getCore().fun_owngoal_KPI = "KPI/Measurement";
			sap.ui.getCore().fun_owngoal_Weight = "Weight";
			sap.ui.getCore().fun_owngoal_startDt = "Start Date:";
			sap.ui.getCore().fun_owngoal_complDt = "Completion Date";
			sap.ui.getCore().TeamApp = " Team Appraisal";
			sap.ui.getCore().L_empid = "Emp ID";
			sap.ui.getCore().L_name = "Name";
			sap.ui.getCore().L_worklevel = "Work Level";
			sap.ui.getCore().L_status = "Status";
			sap.ui.getCore().L_goalsetting = "Goal Setting";
			sap.ui.getCore().L_goalapprover = "Goal Approval";
			sap.ui.getCore().L_halfyear = "Half Yearly Review";
			sap.ui.getCore().L_revisit = "Goal Revisit";
			sap.ui.getCore().L_annRev = "Annual Review";
			sap.ui.getCore().L_arc = "ARC";
			sap.ui.getCore().L_finSign = "Final Signoff"
			sap.ui.getCore().overall = "Overall Assessment";
			sap.ui.getCore().over_Half = "Half Year Review";
			sap.ui.getCore().over_Annu = "Annual Review";
			sap.ui.getCore().dialog = new sap.m.BusyDialog({
				text: 'Please wait...'
			});

		},

		_handleRouteMatched: function() {
			try {
				sap.ui.getCore().ODThis = this;
				sap.ui.getCore().username = sap.ushell.Container.getUser().getId();
				//sap.ui.getCore().username = 'P00049966';

				sap.ui.getCore().ordersThis = this;
				this.servicecall();

				if (sap.ui.getCore().USERDATA.UnitText === "GG EM - Russia Rep office" || sap.ui.getCore().USERDATA.UnitText ===
					"GG EM - Russia WOS") {
					sap.ui.getCore().ODThis.getView().getController().Russian_language();
				}

				//new code 16_06
				var oTable = this.getView().byId("treeTable");

				var oModel = new sap.ui.model.json.JSONModel({
					useBatch: true
				});
				sap.ui.getCore().HireListSet.results[0].ParentNodeId = null;
				var res = this.group(sap.ui.getCore().HireListSet.results);
				//sap.ui.getCore().HireListSet = res;
				oModel.setData({
					items: res
				});
				oTable.setModel(oModel);

				////****************88///////////////

				var Logo =
					"data:image/false;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAAAvCAYAAACffjT/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAAB3RJTUUH4QMXCScKrmMXhQAAE1FJREFUeNrtnXmcVNWVx7/dzSaboMgawbiAjihGcYsKYwqNNQYnok4YMzhjMkQzSzLRcWKMOiYM0Zm4TEzUOOUWjUsSRomQEAdRE1TEILK5EVRQdhqaRmh6r/njdy916tWrqldLN6ZTv8+nPtBVr859796zn3NvVVFBBX9CiMcS/r99gfOAKcDx7u/twO+BXwAvAk3zFkwvapyq/f2gFVRg4Ri/CugPjAIOB4YDB7r3dwHrgdXAWqABIIoAGKE6BrgJ+AskUEFsBx4FbgE2RaVvURGsCj4WcEzfHVmPzwMx4ChgANAtcHkrYv7Xgf8Ffglsg+wCYITqOOB+4OQIt/U0cCWwqSJYFfxRIWBFvgZcBBxSAIlW4FVgJvAM0BYmBG6cAcBPgfMLoH8ncDXQWohwVQSrgv0Gx+zdgEuA7yALVSx2AN8D7gIarRAY4f0i8ADQowC624ELgJeDgmXo1gBJoB1kNSuCVcF+gXH9/gn4dxRDlYq9wHeBWzEWxoz1OLKIheI/gBtAQmME6pNIKZwINAG/BZ4C6iqCVUGnwyQorgT+i/AEQrGoB64AfgZpgjAYeA44tgiac5FANpv3xgEJ0mO1VpRRvKpbdNoVVFA6jLb/DLJU5RQqkOX7Noq73jfv9wH6FUnzIOQ+esHqDdxIZgKkG/BXwPrqDpi7CirIh4OB64AhHUT/OOAySBPkZtItTiHYi6yRx5HAWVmurQEurghWBZ0Gw+R/CUzo4OEuAoaZv+tQ3asYvAM0mr/7AwfkuH5QRbAq6Gz0BaaSWZsqN0YDJ5m/G4Bni6DTCMyHtBrZViSo2bC2IlgVdDaOJp3hOwo9Q8b5ObCqQDoLUNLD4j1gTpbrG4BERbAq6Gx8CiUDOgOHk16rfR8lTLZF/P5qVF/b5d9wVqsVuBl4AsVfHjtQG9T9FcGqoFNg4qujO3HYfjiX07hxs4F/BP6Q43vtwGLg71FTblir1HrgKyiW+ybwDdTRcQvQUEm3V9CZqKawdqVSkVandTWtdlRrWgX8LXAO8AnkOjYA76Lew8eBDZ5OPJYYCAwFeqFi8GZkoebNWzB9XnDgimBV0NnYrzxnujHeAr4FfB+l/Xsjl28T8JH5ytEodX8ucCgSwCZkseYDj8RjiTeBpLVqFcHqIJjuAjvHrQQWoLNpRRinBhVZWxGDlXOMJOkxSafCuKPd3XM2A9vnLZi+PeS6alTsnYHqVkEMRq1Ml6C47Yl4LLGvjaoqHkucRnbz3IikeIt77YXC96aUMAlVSGOMQIuSDUlgJ/ABaposK8MVee8AX0ITD9AG/BiYW8i9GVpfBi42tO4BfgXlWQ83zkHANWgD4B7gf4DHKLCzO89zzACuL/mGo2E2Eo4W9/chwBdQ10c/YA3KFC70z2ju81LU2X5whHF2Av8C/AS0Ht1Q2jBbA2QbkuodqEj2DDA7HkuspXOYty/wQ1TlbstzbSMqAD4NPBiPJdb5h9xPqAY+i5jUYxXqOysUNSG0VuAEq1QYZroSBeI+NhkDrEPNpSXBMO1baC1rynHvBeATwN0oweCTdpOQ4N0I3OPiL4CxqJk3ilCBtqPcBCwHlsVjCaqBQcg0hr16oSrzYWhhbwPmoaxKX7MgHYVu7qZ7oEp3rtdAlMq9EZgFfBrSmKarodwN1D1RN4SlOwg4tczjrCB6urtcqAauAiaTEiqPgxDPnO7+rgIuB44ocIzDkIdS5QcsBFVIi90G3AEMiscSHzfmrQLGo305o6HLCleydBJpaMFtQzdoQyFAObEGWNJRkxKCdhRKTM5xzWDUZuX/f26RY03CtVGFCdY2ZK7fRm7ALjIXsQfy+WegbEpnYi3y+x91ryeB18gMik8AvkplM2deOHe5HcWAy0mt90qKawPKhUbkUbSWSigikkhY8rl1I92/hyK3sRiM8HTCBOsh5BKcDUxEfv31SNgsvMm8FDrVKixC9YfL3OsLSMP8M+rhsvicmbAK8mMx8A+k5vEnpGo5JcPEu79G2zo6C7vJn4303RUDkFtcDHqi0Ck03b4bqDX5/nWImX+OqspTSFmBnmgH6DzKuAAR0A60e00bjyV2oC3Xo4F/M9eNQNu91wUJGEVQ7Z6nDfZrsuPjgmORhl+OCqnBXbNeGe/bhl4EtqGM2wl0vMdTjbLFS9AW+zA0Ac+7/+8lf6IsG1odrfx1LDOpa4Cvo5SlbfkfiyzGg4GTdvq7z+tRwJpEW5mPQWZ5FbCkHIzs7jEJvOIezj9XT0wpwTDHAJTcOAsdsVWDupVXxmOJhcCb5EgxB+ichmK6wYjZNqAz6V6Pcu+G1kCUKDjZ3bOltSwHiYPiscRYUgqiyc3trhxnNIxEfXS472wF3nD3MM2995Abn3gscSDyXiaSKn1sARbHY4nnURdCJCEz/PRL4BG027cjUYWE5TbEl4cFPk8io+GztRuQ4BezAXM7KhxHKxCbydgA3I4YyWuaGiRYjyCmPgxti/Z+6gdosT7n/h2OhO9uyhTEGoY5gPSYKunuydbFJqIdpmeQuafGM8zjwK3xWGKjf/7AWNWoFeabSLCCdOqQG5XzHAdD61xH69QctPpnIXMkYowBpA40uRu4Nh5LhJ1YNNyt1anu+hpUE/u6+2yve/6fuevHoROQYihLbNEKLEVZtWfisUQhwtWIzpIYA/x53i+Vjt+h0OEaxL+90FrPQiUd322xASnoTxYxxqvAh1BAVtBM2EKk3SzGkupY9n5mT/cahJIc1yLr0N1dV2wDcLZsWF9k6m19ZLd/UIeLUMJjEuEb1apQP9g3UHF0hP3QCOc0xJxnZ6EzEJUksu0ytbQuAx5GzFUMrZXAS26ueyGF90W0izY4HqiOc4a5vpGUtn4bufpfQhnCI9C5DueTKVQgxXyKu+aswDhRsB4dLfZWIV8qAQvRXrCzkaKIoa6JrYa/W5Ai21kg7V3Iyjf7iSkUdci1s/v9D0ECtJVMxh/gHqBcnfS9kWZtN67noYgZLgxc+wYqbINcv9vddz12oyxjk3t/iLnP85EVuSoeS9gM1gS0ZSDYreKthXfJfC0wA4b5JpZKC1mYB1GdsY97bxhK6iwLWJF+qCBqlc9C4GWAeQumtwF7zP1dQfo6b0SaP4mE02bSrkYeSKSWJeMFLUVdC/dTfDYu0ngODaR4Its9LUAZ0muIVshuR4p434bIYgQrSWaiojfZXZUqUu5ZE67lCMVexWAS6Z0ANUirB8dvBO5DiuAAtPCHms+XIm21GLk0w1BGbDqpc+emogMefQarDyo02i3f7WhrwSyUJBmBLOOnya1M+rp7Ghqg9aqj9UEBtF5wL3sQ5RRkSd4z751GesG32T3fnhCaB7u59qhH5Ys5aD1PQZb2KHffw5DgRu4FNIz8f24u7kIKulCsRus5EimC7vm+YNzwvog/GpCi9eHDLciqX0HuBMtexGczgWYvwAUJlpmIpsBH1RFoLQL+GwX1re5BikFf8geWLSjOeML9PR5ZTY8t6NTVl8xz1aFu51EoHgRZkvNICdZJZMYDT6PMqFU2j7tnnZrjHseTee7DbFQ22Big9UNSPYdh2I2s1mdIuZNHoaOabzfNtZeQflLR62RuO/foR3rtpwEJadK9XkEHwox3dF4HaikQhqdmuTFvRV5OVLyKyj5vIgU7EymAUBiBOgm59KegWLgO8ehPUbKo3j3f75FwnYj4rso9/26UOb0XHXO9t+ju9kAGy6KZ3ILyJioov+Uns4PQihb/buRaeO15BumJhHdQsHo0akS233+DlGDhJrQ7EtYzSLeMm1EAvsE+VzyW2II03gTSXU+LMFozcUJlGG4LchfPJN1SBjEfZRDPcX9XAX+NGGUrKkV81lyfREKbTRj2oDjDu3tDkUWZhUKB91Bmb1ap62n2ST2ErMP3iJ6VewzxF0g4HkAKLcijtnv/y6i3Lzifp6NG5287uo1ujn6N8ghjkNDXIyu50s1RBk8X4wr2wLUKGXxE7sM1fkH5hKoeJSR6oMyNNfsvu0l7l/RYb0yAxsmooTgMwQTCMLTY9SF0luMWNeS53nafhwlWVQitZUFagcbV5eQWLB88TyTlyo5DFvdhlNixxfLVSDCyrUktqu0cb+55AkpSNCBFsBx4Mh5LzHHjF72+7ln9DoDuaEt8FOEK8nANId02RnlegJTewCz0RqLU/BZS1rweeTcvRX2eYhIKh6PCnsU6smu+VlwdpkyW6lmU1ZmE4gqLI5FlskJVQ+YCHYA0cNjrwJBr/f6d4GebyB5TNJG9z65bCK2NpB+xZdGYg5ad13nIRfPojjKEh6OYy+JJshwH5uglkYVaFPi4CsWaRziaDyB3aAQlwo3bglzfmwiP/YKYhty6bmj9riS7KzkQJUoG5qE52F3XhyIRWbCMbzqNzDahRaTvurRoofhERRia0DaWD1FwbplxOPKHrRZLkllJ34q07Yo8rzcQo+5xdFoCdHqTPWtUTfaz58Jo9SH7etSQ+xw7jzpktSzt05BrM9a8txHVvvIpuz+gcsCPkbsb1pHQA7le1wPdS21tM8J1J7Ja+YRrHFISs5FimZbj2uPQDogoOIVMzywyIrmCpuZyMZmV8p3k3hfkg90gPVBtZKCbvKiuhDXzz6AMoY0dLkR1CG+2fQeDxXMoSZAk021IIk3f7L7bTMoqBemMQQF+sEcRlN3KdnBKawit0Y7WtgJp4efNzesclNn02yD6I+Gwaz0PxQc56QHEY4k1KDlzB0pUnITiznGka/4pyHIto0S4Z2kBfoDW50ZyW4+RROsJHUX02O1AlEWO1EETRFaL5beDxGOJajfAt4AfkdklPBelrCPBCNV4VKx9AQnmVKCmQI23Cy2mdccGIeG3P9XyGuna9mRk7rejvsha5MrWosm/ExWJTySdIYN0jkGZt33PZe7/Qvd5NgRpHYvbuhBCa0oeWha1KKaytO0z1Lt5z9oP59c9HksMRUmWy918PobS4uejRujN5msHU9rP8KTBCXYzyq7OoPgsskUbhW23KbZnMFSwzgT+FTWz3oDSuPPRjspgIfMddBhHE4VhKGLeKUhTn4n86olFPMOzZMZak0nvVHgRBeseR6C07lig2ljkY4D/RGnp65HSuCRAZ435uwfSptOBwfFYohcS2K+gGlmu32FaiJIsltZN6MgtT2sIUhI3EKE2Ezjia1mWy17AxWF5vIPxwG+QdUug8oR/ngZ3/7arJcMzKRVGuO5w8/xRSQQ137siXruDkObtqAhzBc8hlbLNhQ+R9lrhJ6EAa3Oie1kMQr8J+1yBVusjZLUmkHIXBiCGfBlZsw9QkH0LqZgoDvwZciXXIyaeSPrBIfWku0xrkTWYQUopjUBK4WtIgw9ByiLf1oP3Ha3vBmj9CPXtbUYK6KgItILYjFquPkW68mxC6fcoRVy/QdDXvS5FAvWUozOZ9J/E2U668ioLHF81I0XciuKuYn9Ly8fM50W49rekK9GCUExWMImKZpdTxsNMioEZ91lSbf8e56Hsocd9qCZhteooFH9ch9L0VqiakY+/JDDWvbg0tUFPZP0moQC5J+FJE0JoPZ2D1tgctKry0J5DpsZdgjsuOcKaLcclOBz6IOXxKxTbXkt6R8IcVGIoO0xC4y43bl2RpHYjT2VTnuveR+1vjcXydjXRzXczkvgbkQu3wDx0oVhKZlBYiwpx+WiG3a8/UWi3ea8fqsB7K7YTWdh7yZ9pqkdFyjtJ7fvy2I4syqPkdoGX+jnKgVrErI/lofUameeHh65bYGuITS60u3F25Lkny8gzUUHYC7VPtfcnpZSTSLHdjGnpKTfM0c4J1FZW0LkZ5r6eQ8mYsH7BJPLAvkoBeYMwdEMZtGy/U9SGtMN7iFGWIGnPdULTVuQu+CzNdjI152aUlbsOaeUtqFsieBrQHmQdahFjVKG+Mn+ajnVB5yNG8G1CVW7svsAed91WlJT4Dan6hz9Mp8Ut1mIUVz4PtNjnNGN9iOolc1Gz6zhS9bNat3g/QNarnVT8sSgLrSuQxp+KCrKW1gIk4MeTCr59S1Gudf0b0us5b7sxClGGG1G8+Dv3nKNJtfU0unV9CjH7xqhEi4UpIj/sxr+d3EXzsO8nUXp+JerDPB0pijoUQ++r75WiJKrisUQNuV3CNiLuFg382LHVaK32+4F0+wDku2ek203tzNaKQg+qzHKoZa6xe6K613CkhXcj5tiIa/3P9bwBOkNQViyJFMsWN2+RDtkM0BqKtuAEaRUyDycg62+Z7jsoOVIQw5h764+U5SHumXag2LWWTj7H0az1ZKR0RmW5dDbp5wr6Pj8Lv3OgxV9XjmepHLTShWCE4GYUi3isR8maVV3l6AHzrJNQwmdMyGWzUVY3iVqZLkDtYfcBOzpyLiq/NtL1ENa+NJdUo2qXQCBxdTnZywvtqG55D/B3SOlMh449AKkiWF0Ehkk+T3qhtg4lLdq7irXyMM/jT+56MeSyJFI2vgZbjcoEHeqtVQSra2Ew2ipimWYB7jeeuiKMcK1AFmkuqTjKJ7yWkKpH1qHkVbkPPE1DRbC6FsaiorfHDtSU21gUtT8SGOF6F+0Cn4sSEa8g4VqNhO5qlA2eFfhe2fH/W4b9/T3Nl6sAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTctMDMtMjNUMDk6Mzk6MTAtMDQ6MDA28fDkAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE3LTAzLTIzVDA5OjM5OjEwLTA0OjAwR6xIWAAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII=";
				this.getView().byId("goal_pic_id").setSrc(Logo);

				var view = this.getView();
				sap.ui.getCore().ODThis = this;
				//this.onrowchange_handlerou():
				this.getView().getController().setHeaderDet();
			} catch (e) {
				console.log(e);
			}
		},
		AsMMngr: function() {
			var oView = sap.ui.getCore().ODThis.getView();

			var odatamodel = this.getView().getModel();
			odatamodel.read("/ReporteeslistNewMMSet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username + "%27%20and%20FiscalYear%20eq%20%27" +
				sap.ui.getCore().Year_Sel + "%27", null, null, false,
				function(oResponse) {
					sap.ui.getCore().MatrixManager = oResponse;
				});
			var oDialog = oView.byId("Dialog_MatMngr");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.MatrixMngr_form", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			//binding of matrix manager table
			var reporteesData = sap.ui.getCore().MatrixManager.results;
			var userInfo = sap.ui.getCore().USERDATA;
			var EmpList = [];
			var data = [];
			for (var i = 0; i < reporteesData.length; i++) {
				EmpList.push(reporteesData[i].EmpIdE);
				if (reporteesData[i].ApStatus === "2" && reporteesData[i].ApStatusSub === "3") {
					var status = "Goal Approval";
				} else if ((reporteesData[i].ApStatus === "0" || reporteesData[i].ApStatus === "2") && reporteesData[i].ApStatusSub === "") {
					var status = "Goal Setting";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "") {
					var status = "Half Yearly Review";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "3") {
					var status = "Half Yearly Review(L+1)";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "4") {
					var status = "Goal Revisit by Employee";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "5") {
					var status = "Goal Approval of Revisit";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "6") {
					var status = "Self Appraisal";
				} else if (reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "2") {
					var status = "Annual Review(L+1)";
				} else if (reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "3") {
					var status = "Annual Review(L+2)";
				} else if (reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "4") {
					var status = "ARC";
				} else if (reporteesData[i].ApStatus === "5" && reporteesData[i].ApStatusSub === "") {
					var status = "Final Sign off";
				} else if (reporteesData[i].ApStatus === "7" && reporteesData[i].ApStatusSub === "") {
					var status = "Agree Completed";
				} else if (reporteesData[i].ApStatus === "9" && reporteesData[i].ApStatusSub === "") {
					var status = "Disagree Completed";
				}

				// 		var USERHEader = "";
				// 		var roleband = "";
				// 		if(reporteesData[i].EmpIdE !== ""){
				// 		var odatamodel = this.getView().getModel();
				// odatamodel.read("/ApprisalHeaderNewSet(EmpId='"+reporteesData[i].EmpIdE+"',FiscalYear='2017-18')?$format=json", null, null, false, function(oResponse) {
				// 	 USERHEader = oResponse;
				// });
				// 		}
				// 		if(USERHEader !== ""){
				// 			roleband = USERHEader.BandText;
				// 		}

				var temp_data = {
					Name: reporteesData[i].EmpLnameE + " " + reporteesData[i].EmpFnameE,
					WorkLevel: reporteesData[i].WorkLevel,
					perfECTStatus: status,
					GoalSetting: "",
					GoalSetting2: "",
					GoalSetting3: "",
					GoalSetting4: "",
					GoalSetting5: "",
					GoalSetting6: "",
					GoalSetting7: "",
					EmpId: reporteesData[i].EmpIdE

				};
				data.push(temp_data);

			}
			var apr_tbl = sap.ui.getCore().byId("Approver--TBL_MMngr_status");

			//var data = [{Name:"Anil Reddy",WorkLevel:"R 1A",perfECTStatus : "Goal Setting",GoalSetting:"",GoalSetting2:"",GoalSetting3:"",GoalSetting4:"",GoalSetting5:"",GoalSetting6:"",GoalSetting7:""}];

			var oModel5 = new sap.ui.model.json.JSONModel();
			oModel5.setData({
				modelData: data

			});

			apr_tbl.setModel(oModel5);

			//new table for status change
			apr_tbl.bindAggregation("items", "/modelData", function(sId, oContext) {
				var value = oContext.getProperty("perfECTStatus");
				switch (value) {
					case "Annual Review(L+2)":
						return new sap.m.ColumnListItem({
							cells: [
								new sap.m.Label({
									text: "{Name}"
								}),
								new sap.m.Label({
									text: "{WorkLevel}"
								}),
								new sap.m.Button({
									id: "idbtnStatus10",
									text: "{perfECTStatus}",
									press: function(e) {
										sap.ui.getCore().dialog.open();
										var model = this.getModel();
										var path = e.getSource().getBindingContext().getPath();
										var obj = model.getProperty(path);
										//console.log(obj);
										sap.ui.getCore().EMPid = obj.EmpId;

										sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
										sap.ui.getCore().dialog.close();
									}
								}).addStyleClass("btnCls")

							]
						});
				}
			});

			oDialog.open();
		},

		onCloseDialog: function() {
			var dialog = this.getView().byId("Dialog_MatMngr");
			dialog.destroy();
			dialog.close();
		},
		servicecall: function() {
			var odatamodel = this.getView().getModel();
			// 	odatamodel.read("/ReporteesListSet?$filter=EmpIdM%20eq%20%27"+sap.ui.getCore().username+"%27%20and%20FiscalYear%20eq%20%27"+sap.ui.getCore().Year_Sel+"%27", null, null, false, function(oResponse) {
			// 	sap.ui.getCore().ReporteesList = oResponse;
			// 	},
			// function(oError) {
			// 	var aa = JSON.parse(oError.response.body);

			// 	alert("Error "+aa.error.message.value);
			// 	sap.ui.getCore().servicecallflag = 0;
			// 	sap.ui.core.UIComponent.getRouterFor(that).navTo("_noDocFoud", {});
			// });
			odatamodel.read("/ApprisalHeaderNewSet(EmpId='" + sap.ui.getCore().username + "',FiscalYear='" + sap.ui.getCore().Year_Sel +
				"')?$format=json", null, null, false,
				function(oResponse) {
					sap.ui.getCore().USERDATA = oResponse;
					sap.ui.getCore().USERDATA_LP2 = oResponse;
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);

					alert("Error " + aa.error.message.value);
					sap.ui.getCore().servicecallflag = 0;
					sap.ui.core.UIComponent.getRouterFor(that).navTo("_noDocFoud", {});
				});
			odatamodel.read("/HireTreeSet?$filter=IEmpId%20eq%20%27" + sap.ui.getCore().username + "%27%20and%20IFiscalYear%20eq%20%27" + sap.ui
				.getCore().Year_Sel + "%27", null, null, false,
				function(oResponse) {
					sap.ui.getCore().HireTreeSet = oResponse;
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);

					alert("Error " + aa.error.message.value);
					sap.ui.getCore().servicecallflag = 0;
					sap.ui.core.UIComponent.getRouterFor(that).navTo("_noDocFoud", {});
				});
			odatamodel.read("/HireListSet?$filter=IEmpId%20eq%20%27" + sap.ui.getCore().username + "%27%20and%20IFiscalYear%20eq%20%27" + sap.ui
				.getCore().Year_Sel + "%27", null, null, false,
				function(oResponse) {
					sap.ui.getCore().HireListSet = oResponse;
				},
				function(oError) {
					var aa = JSON.parse(oError.response.body);

					alert("Error " + aa.error.message.value);
					sap.ui.getCore().servicecallflag = 0;
					sap.ui.core.UIComponent.getRouterFor(that).navTo("_noDocFoud", {});
				});
		},
		handleLinkPress: function() {
			alert("h");
		},
		setHeaderDet: function() {
			var HDR_INFO = sap.ui.getCore().USERDATA;
			this.byId("HD_apr").setObjectTitle(HDR_INFO.EmpName + " |");
			this.byId("HD_apr").setObjectSubtitle(HDR_INFO.DesignText);
			this.byId("HD_apr").setObjectImageURI(sap.ui.getCore().USERDATA.EmpImage);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.drl.pmsManagermobile.view.Approver
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.drl.pmsManagermobile.view.Approver
		 */
		onAfterRendering: function() {
			var view = this.getView();
			sap.ui.core.BusyIndicator.hide();

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.drl.pmsManagermobile.view.Approver
		 */
		//	onExit: function() {
		//
		//	}
		onNavBack: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("_Login");

		},
		group: function(arr) {
			var t = {};
			for (var i = 0; i < arr.length; i++) {
				if (!arr[i].NodeId) { //'object found without id!'
					sap.m.MessageToast.show("object found without id!");
				}
				t[arr[i].NodeId] = arr[i];
			}
			var result = [];
			for (var i = 0; i < arr.length; i++) {
				if (!arr[i].ParentNodeId) {
					result.push(arr[i]);
				} else {
					var parent = t[arr[i].ParentNodeId];
					if (!parent) {
						sap.m.MessageToast.show("parent with id " + arr[i].ParentNodeId + " not found!");
					}
					var items = parent.items;
					if (!items) {
						items = [];
						parent.items = items;
					}
					items.push(arr[i]);
				}
			}
			return result;
			//return items;
		},
		handle_goal_lib: function() {
			var odatamodel = this.getView().getModel();
			odatamodel.read("GoalLibararySet?$filter=EmpId%20eq%20%27" + sap.ui.getCore().username + "%27", null, null, false, function(
				oResponse) {
				sap.ui.getCore().GoalLibarary = oResponse;
			});
			var oView = sap.ui.getCore().ODThis.getView();

			var oDialog = oView.byId("GoalLib");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "com.drl.pmsManagermobile.view.Goal_Lib", this);
				var oTable1 = this.getView().byId("tblGoalLib");

				var oControl1 = new sap.m.Text({
					text: "{KpiText}",
					textAlign: "Left"
				});
				var oColumn1 = new sap.ui.table.Column({
					multiLabels: [
						new sap.m.Label({
							text: "KPI"
						}),
						new sap.m.Label({
							text: ""
						})
					],
					width: "50%",
					template: oControl1,
					hAlign: "Center",
					resizable: false,
					autoResizable: false
				});
				oTable1.addColumn(oColumn1, {
					resizable: false,
					autoResizable: false
				});
				var oControl1 = new sap.m.Text({
					text: "{KraText}",
					textAlign: "Left"
				});
				var oColumn1 = new sap.ui.table.Column({
					multiLabels: [
						new sap.m.Label({
							text: "KRA"
						}),
						new sap.m.Label({
							text: ""
						})
					],
					width: "30%",
					template: oControl1,
					hAlign: "Center",
					resizable: false,
					autoResizable: false
				});
				oTable1.addColumn(oColumn1, {
					resizable: false,
					autoResizable: false
				});
				var oControl1 = new sap.m.Text({
					text: "{Weightage}",
					textAlign: "Center"
				});
				var oColumn1 = new sap.ui.table.Column({
					multiLabels: [
						new sap.m.Label({
							text: "Weightage(%)"
						}),
						new sap.m.Label({
							text: ""
						})
					],
					width: "10%",
					template: oControl1,
					hAlign: "Center",
					resizable: false,
					autoResizable: false
				});
				oTable1.addColumn(oColumn1, {
					resizable: false,
					autoResizable: false
				});
				var oModel = new sap.ui.model.json.JSONModel();
				//sap.ui.getCore().ScoreCardTree.results[0].ParentNodeId = null;
				var res = sap.ui.getCore().GoalLibarary.results;
				//sap.ui.getCore().ScoreCardTreeset = res;
				oModel.setData({
					items: res
				});
				oTable1.setModel(oModel);

				oView.addDependent(oDialog);
			}
			oDialog.open();
		},
		GoalLib_Add_proj: function() {
			var otable = this.getView().byId("tblGoalLib");
			var arr = otable.getSelectedIndices();
			sap.ui.getCore().gollibScore = [];
			for (var i = 0; i < arr.length; i++) {
				sap.ui.getCore().gollibScore.push(otable.getModel().getData().modelData100[arr[i]]);
			}

			var dat = sap.ui.getCore().ODThis.getView().getController().aData;
			sap.ui.getCore().ODThis.getView().getController().aData = dat;
			var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
			var oModel = new sap.ui.model.json.JSONModel();
			var dt = sap.ui.getCore().ODThis.getView().getController().aData;

			for (var ii = 0; ii < sap.ui.getCore().gollibScore.length; ii++) {
				var wtg = sap.ui.getCore().gollibScore[ii].Weightage;
				dt.push({
					"EmpId": "",
					"GoalId": "",
					"GoalItemId": "",
					"GoalName": "",
					"Weightage": wtg + "%",
					"KraText": sap.ui.getCore().gollibScore[ii].KraText,
					"KpiText": sap.ui.getCore().gollibScore[ii].KpiText,
					"GoalDate": "",
					"GoalSdate": ""
				});
			}
			oModel.setData({
				modelData: dt
			});
			list.setModel(oModel);
			var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
			list.bindItems("/modelData", objlist);
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
		},
		ScoreCard_Add_proj: function() {
			var otable = this.getView().byId("tblRespScore");
			var arr = otable.getSelectedIndices();
			sap.ui.getCore().FinScore = [];
			for (var i = 0; i < arr.length; i++) {
				sap.ui.getCore().FinScore.push(otable.getModel().getData().modelData100[arr[i]]);
			}

			var dat = sap.ui.getCore().ODThis.getView().getController().aData;
			sap.ui.getCore().ODThis.getView().getController().aData = dat;
			var list = sap.ui.getCore().ODThis.getView().byId("Func_list");
			var oModel = new sap.ui.model.json.JSONModel();
			var dt = sap.ui.getCore().ODThis.getView().getController().aData;

			for (var ii = 0; ii < sap.ui.getCore().FinScore.length; ii++) {
				var wtg = sap.ui.getCore().FinScore[ii].WEIGHTAGE;
				dt.push({
					"EmpId": "",
					"GoalId": "",
					"GoalItemId": "",
					"GoalName": "",
					"Weightage": wtg + "%",
					"KraText": sap.ui.getCore().FinScore[ii].KPA_TEXT,
					"KpiText": sap.ui.getCore().FinScore[ii].KPI_TEXT,
					"GoalDate": "",
					"GoalSdate": ""
				});
			}
			oModel.setData({
				modelData: dt
			});
			list.setModel(oModel);
			var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList");
			list.bindItems("/modelData", objlist);
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
		},
		onCloseScoreCard: function() {
			var dialog = this.getView().byId("ScoreCard");
			dialog.destroy();
			dialog.close();
		},
		onCloseGoalLib: function() {
			var dialog = this.getView().byId("GoalLib");
			dialog.destroy();
			dialog.close();
		},

		///////// language change option ///////////////

		Russian_language: function() {

			// var sLocale = "ru";
			// var oBundle = jQuery.sap.resources({
			// 	url: "css/i18n.properties",
			// 	locale: sLocale
			// });
			var oRootPath = jQuery.sap.getModulePath("com.drl.pmsManagermobile");
			// set i18n model
			var oBundle = new sap.ui.model.resource.ResourceModel({
				bundleUrl: oRootPath + "/i18n/i18n_ru.properties"
			});
			oBundle = oBundle._oResourceBundle;
			sap.ui.getCore().oBundle_ru = oBundle;
			/* var sLocale = sap.ui.getCore().getConfiguration().getLanguage();*/

			var sMsg1 = oBundle.getText("TeamAppraisal");
			this.getView().byId("TeamAppraisal_ID").setText(sMsg1);

			var sMsg2 = oBundle.getText("Name");
			this.getView().byId("ID_NAME").setText(sMsg2);

			var sMsg3 = oBundle.getText("RoleBand");
			this.getView().byId("ID_ROLEBAND").setText(sMsg3);

			var sMsg4 = oBundle.getText("Status");
			this.getView().byId("ID_STATUS").setText(sMsg4);

			var sMsg5 = oBundle.getText("GoalSetting");
			this.getView().byId("ID_GOALSET").setText(sMsg5);

			var sMsg6 = oBundle.getText("GoalApproval");
			this.getView().byId("ID_GOALAPRL").setText(sMsg6);

			var sMsg7 = oBundle.getText("HalfYearlyReview");
			this.getView().byId("ID_HALFREVIEW").setText(sMsg7);

			var sMsg8 = oBundle.getText("GoalRevisit");
			this.getView().byId("ID_GOALREVISIT").setText(sMsg8);

			var sMsg9 = oBundle.getText("AnnualReview");
			this.getView().byId("ID_ANNUALREVIEW").setText(sMsg9);

			var sMsg10 = oBundle.getText("ARC");
			this.getView().byId("ID_ARC").setText(sMsg10);

			var sMsg11 = oBundle.getText("Finalsignoff");
			this.getView().byId("ID_SIGNOFF").setText(sMsg11);

			var sMsg9 = oBundle.getText("PerformancePath");
			sap.ui.getCore().Perf_path_text = sMsg9;

			var ru_msg1 = oBundle.getText("EMPcode");
			sap.ui.getCore().ru_empcode = ru_msg1;

			var ru_msg2 = oBundle.getText("RoleBand");
			sap.ui.getCore().ru_rleband = ru_msg2;

			var ru_msg3 = oBundle.getText("Department");
			sap.ui.getCore().ru_deprt = ru_msg3;

			var ru_msg4 = oBundle.getText("UnitBU");
			sap.ui.getCore().ru_unit = ru_msg4;

			var ru_msg5 = oBundle.getText("Manager");
			sap.ui.getCore().ru_mngrL1 = ru_msg5;

			var ru_msg6 = oBundle.getText("Reviewer");
			sap.ui.getCore().ru_mngrL2 = ru_msg6;

			var ru_msg7 = oBundle.getText("Matrixmanager");
			sap.ui.getCore().ru_mmngr = ru_msg7;

			var sMsg9 = oBundle.getText("PerformancePath");
			sap.ui.getCore().Perf_path_text = sMsg9;

			var sMsg10 = oBundle.getText("Goal");
			sap.ui.getCore().Goal_header = sMsg10;

			var sMsg11 = oBundle.getText("GoalApproval");
			sap.ui.getCore().Goal_approver = sMsg11;

			var sMsg22 = oBundle.getText("Perf_GoalSetting");
			sap.ui.getCore().Perf_GoalSetting = sMsg22;

			var sMsg23 = oBundle.getText("Perf_goalApproval");
			sap.ui.getCore().Perf_goalApproval = sMsg23;

			var sMsg24 = oBundle.getText("Perf_halfyearly");
			sap.ui.getCore().Perf_halfyearly = sMsg24;

			var sMsg25 = oBundle.getText("Perf_annualReview");
			sap.ui.getCore().Perf_annualReview = sMsg25;

			var sMsg26 = oBundle.getText("Perf_Finalsignoff");
			sap.ui.getCore().Perf_Finalsignoff = sMsg26;

			var sMsg27 = oBundle.getText("Perf_ARC");
			sap.ui.getCore().Perf_ARC = sMsg27;

			var sMsg13 = oBundle.getText("FunctionalGoals");
			sap.ui.getCore().ru_FunctionalGoals = sMsg13;

			var sMsg17 = oBundle.getText("ProjectGoals");
			sap.ui.getCore().ru_ProjectGoals = sMsg17;

			var sMsg18 = oBundle.getText("Approver");
			sap.ui.getCore().ru_Approve = sMsg18;

			var sMsg19 = oBundle.getText("returntoemp");
			sap.ui.getCore().ru_returnemp = sMsg19;

			var sMsg20 = oBundle.getText("Comment");
			sap.ui.getCore().ru_cmnt = sMsg20;

			var sMsg10 = oBundle.getText("Goal");
			sap.ui.getCore().Goal_header = sMsg10;

			var sMsg11 = oBundle.getText("Submit");
			sap.ui.getCore().submit = sMsg11;

			sap.ui.getCore().fun_owngoal_tital = oBundle.getText("AddFunctionalGoal");
			sap.ui.getCore().fun_owngoal_KRA = oBundle.getText("KRA_Goals");
			sap.ui.getCore().fun_owngoal_KPI = oBundle.getText("KPIMeasure");
			sap.ui.getCore().fun_owngoal_Weight = oBundle.getText("Weight");
			sap.ui.getCore().fun_owngoal_startDt = oBundle.getText("StartDate");
			sap.ui.getCore().fun_owngoal_complDt = oBundle.getText("CompletionDate");

			sap.ui.getCore().P_title = oBundle.getText("P_title");
			sap.ui.getCore().P_empinfo = oBundle.getText("P_empinfo");
			sap.ui.getCore().P_Fname = oBundle.getText("P_Fname");
			sap.ui.getCore().P_empNO = oBundle.getText("P_empNO");
			sap.ui.getCore().P_desg = oBundle.getText("P_desg");
			sap.ui.getCore().P_deprt = oBundle.getText("P_deprt");
			sap.ui.getCore().P_L_1 = oBundle.getText("P_L_1");
			sap.ui.getCore().P_L_1_desg = oBundle.getText("P_L_1_desg");
			sap.ui.getCore().P_L_2 = oBundle.getText("P_L_2");
			sap.ui.getCore().P_L_2_desg = oBundle.getText("P_L_2_desg");

		},

		onSettingLang: function() {
			sap.ui.getCore().ordersThis._getDialog007().open();

		},
		_getDialog007: function() {
			if (!this._oDialog007) {
				this._oDialog007 = sap.ui.xmlfragment("com.drl.pmsManagermobile.view.Setting", this);
				this.getView().addDependent(this._oDialog007);
			}
			return this._oDialog007;
		},
		onSettingSave: function() {
			//	try{
			jQuery.sap.require("jquery.sap.resources");
			var lang_select = sap.ui.getCore().byId("CBOX_Leng_setting");
			var selectIndex1 = lang_select.getSelectedIndex();

			if (selectIndex1 == 2) {

				// var sLocale = "ru";
				// var oBundle = jQuery.sap.resources({
				// 	url: "css/i18n.properties",
				// 	locale: sLocale
				// });
				var oRootPath = jQuery.sap.getModulePath("com.drl.pmsManagermobile");
				// set i18n model
				var oBundle = new sap.ui.model.resource.ResourceModel({
					bundleUrl: oRootPath + "/i18n/i18n_ru.properties"
				});
				oBundle = oBundle._oResourceBundle;
				sap.ui.getCore().oBundle_ru = oBundle;
				/* var sLocale = sap.ui.getCore().getConfiguration().getLanguage();*/

				var sMsg1 = oBundle.getText("TeamAppraisal");
				this.getView().byId("TeamAppraisal_ID").setText(sMsg1);

				var sMsg2 = oBundle.getText("Name");
				this.getView().byId("ID_NAME").setText(sMsg2);

				var sMsg3 = oBundle.getText("RoleBand");
				this.getView().byId("ID_ROLEBAND").setText(sMsg3);

				var sMsg4 = oBundle.getText("Status");
				this.getView().byId("ID_STATUS").setText(sMsg4);

				var sMsg5 = oBundle.getText("GoalSetting");
				this.getView().byId("ID_GOALSET").setText(sMsg5);

				var sMsg6 = oBundle.getText("GoalApproval");
				this.getView().byId("ID_GOALAPRL").setText(sMsg6);

				var sMsg7 = oBundle.getText("HalfYearlyReview");
				this.getView().byId("ID_HALFREVIEW").setText(sMsg7);

				var sMsg8 = oBundle.getText("GoalRevisit");
				this.getView().byId("ID_GOALREVISIT").setText(sMsg8);

				var sMsg9 = oBundle.getText("AnnualReview");
				this.getView().byId("ID_ANNUALREVIEW").setText(sMsg9);

				var sMsg10 = oBundle.getText("ARC");
				this.getView().byId("ID_ARC").setText(sMsg10);

				var sMsg11 = oBundle.getText("Finalsignoff");
				this.getView().byId("ID_SIGNOFF").setText(sMsg11);

				var sMsg9 = oBundle.getText("PerformancePath");
				sap.ui.getCore().Perf_path_text = sMsg9;

				var ru_msg1 = oBundle.getText("EMPcode");
				sap.ui.getCore().ru_empcode = ru_msg1;

				var ru_msg2 = oBundle.getText("RoleBand");
				sap.ui.getCore().ru_rleband = ru_msg2;

				var ru_msg3 = oBundle.getText("Department");
				sap.ui.getCore().ru_deprt = ru_msg3;

				var ru_msg4 = oBundle.getText("UnitBU");
				sap.ui.getCore().ru_unit = ru_msg4;

				var ru_msg5 = oBundle.getText("Manager");
				sap.ui.getCore().ru_mngrL1 = ru_msg5;

				var ru_msg6 = oBundle.getText("Reviewer");
				sap.ui.getCore().ru_mngrL2 = ru_msg6;

				var ru_msg7 = oBundle.getText("Matrixmanager");
				sap.ui.getCore().ru_mmngr = ru_msg7;

				var sMsg9 = oBundle.getText("PerformancePath");
				sap.ui.getCore().Perf_path_text = sMsg9;

				var sMsg10 = oBundle.getText("Goal");
				sap.ui.getCore().Goal_header = sMsg10;

				var sMsg11 = oBundle.getText("GoalApproval");
				sap.ui.getCore().Goal_approver = sMsg11;

				var sMsg22 = oBundle.getText("Perf_GoalSetting");
				sap.ui.getCore().Perf_GoalSetting = sMsg22;

				var sMsg23 = oBundle.getText("Perf_goalApproval");
				sap.ui.getCore().Perf_goalApproval = sMsg23;

				var sMsg24 = oBundle.getText("Perf_halfyearly");
				sap.ui.getCore().Perf_halfyearly = sMsg24;

				var sMsg25 = oBundle.getText("Perf_annualReview");
				sap.ui.getCore().Perf_annualReview = sMsg25;

				var sMsg26 = oBundle.getText("Perf_Finalsignoff");
				sap.ui.getCore().Perf_Finalsignoff = sMsg26;

				var sMsg27 = oBundle.getText("Perf_ARC");
				sap.ui.getCore().Perf_ARC = sMsg27;

				var sMsg13 = oBundle.getText("FunctionalGoals");
				sap.ui.getCore().ru_FunctionalGoals = sMsg13;

				var sMsg17 = oBundle.getText("ProjectGoals");
				sap.ui.getCore().ru_ProjectGoals = sMsg17;

				var sMsg18 = oBundle.getText("Approver");
				sap.ui.getCore().ru_Approve = sMsg18;

				var sMsg19 = oBundle.getText("returntoemp");
				sap.ui.getCore().ru_returnemp = sMsg19;

				var sMsg20 = oBundle.getText("Comment");
				sap.ui.getCore().ru_cmnt = sMsg20;

				var sMsg10 = oBundle.getText("Goal");
				sap.ui.getCore().Goal_header = sMsg10;

				var sMsg11 = oBundle.getText("Submit");
				sap.ui.getCore().submit = sMsg11;

				sap.ui.getCore().fun_owngoal_tital = oBundle.getText("AddFunctionalGoal");
				sap.ui.getCore().fun_owngoal_KRA = oBundle.getText("KRA_Goals");
				sap.ui.getCore().fun_owngoal_KPI = oBundle.getText("KPIMeasure");
				sap.ui.getCore().fun_owngoal_Weight = oBundle.getText("Weight");
				sap.ui.getCore().fun_owngoal_startDt = oBundle.getText("StartDate");
				sap.ui.getCore().fun_owngoal_complDt = oBundle.getText("CompletionDate");

				sap.ui.getCore().P_title = oBundle.getText("P_title");
				sap.ui.getCore().P_empinfo = oBundle.getText("P_empinfo");
				sap.ui.getCore().P_Fname = oBundle.getText("P_Fname");
				sap.ui.getCore().P_empNO = oBundle.getText("P_empNO");
				sap.ui.getCore().P_desg = oBundle.getText("P_desg");
				sap.ui.getCore().P_deprt = oBundle.getText("P_deprt");
				sap.ui.getCore().P_L_1 = oBundle.getText("P_L_1");
				sap.ui.getCore().P_L_1_desg = oBundle.getText("P_L_1_desg");
				sap.ui.getCore().P_L_2 = oBundle.getText("P_L_2");
				sap.ui.getCore().P_L_2_desg = oBundle.getText("P_L_2_desg");

			} else if (selectIndex1 == 1) {

				// var sLocale = "en";
				// var oBundle = jQuery.sap.resources({
				// 	url: "css/i18n.properties",
				// 	locale: sLocale
				// });
				var oRootPath = jQuery.sap.getModulePath("com.drl.pmsManagermobile");
				// set i18n model
				var oBundle = new sap.ui.model.resource.ResourceModel({
					bundleUrl: oRootPath + "/i18n/i18n_en.properties"

				});

				oBundle = oBundle._oResourceBundle;
				/* var sLocale = sap.ui.getCore().getConfiguration().getLanguage();*/

				var sMsg1 = oBundle.getText("TeamAppraisal");
				this.getView().byId("TeamAppraisal_ID").setText(sMsg1);

				var sMsg2 = oBundle.getText("Name");
				this.getView().byId("ID_NAME").setText(sMsg2);

				var sMsg3 = oBundle.getText("RoleBand");
				this.getView().byId("ID_ROLEBAND").setText(sMsg3);

				var sMsg4 = oBundle.getText("Status");
				this.getView().byId("ID_STATUS").setText(sMsg4);

				var sMsg5 = oBundle.getText("GoalSetting");
				this.getView().byId("ID_GOALSET").setText(sMsg5);

				var sMsg6 = oBundle.getText("GoalApproval");
				this.getView().byId("ID_GOALAPRL").setText(sMsg6);

				var sMsg7 = oBundle.getText("HalfYearlyReview");
				this.getView().byId("ID_HALFREVIEW").setText(sMsg7);

				var sMsg8 = oBundle.getText("GoalRevisit");
				this.getView().byId("ID_GOALREVISIT").setText(sMsg8);

				var sMsg9 = oBundle.getText("AnnualReview");
				this.getView().byId("ID_ANNUALREVIEW").setText(sMsg9);

				var sMsg10 = oBundle.getText("ARC");
				this.getView().byId("ID_ARC").setText(sMsg10);

				var sMsg11 = oBundle.getText("Finalsignoff");
				this.getView().byId("ID_SIGNOFF").setText(sMsg11);

				var sMsg9 = oBundle.getText("PerformancePath");
				sap.ui.getCore().Perf_path_text = sMsg9;

				var ru_msg1 = oBundle.getText("EMPcode");
				sap.ui.getCore().ru_empcode = ru_msg1;

				var ru_msg2 = oBundle.getText("RoleBand");
				sap.ui.getCore().ru_rleband = ru_msg2;

				var ru_msg3 = oBundle.getText("Department");
				sap.ui.getCore().ru_deprt = ru_msg3;

				var ru_msg4 = oBundle.getText("UnitBU");
				sap.ui.getCore().ru_unit = ru_msg4;

				var ru_msg5 = oBundle.getText("Manager");
				sap.ui.getCore().ru_mngrL1 = ru_msg5;

				var ru_msg6 = oBundle.getText("Reviewer");
				sap.ui.getCore().ru_mngrL2 = ru_msg6;

				var ru_msg7 = oBundle.getText("Matrixmanager");
				sap.ui.getCore().ru_mmngr = ru_msg7;

				var sMsg9 = oBundle.getText("PerformancePath");
				sap.ui.getCore().Perf_path_text = sMsg9;

				var sMsg10 = oBundle.getText("Goal");
				sap.ui.getCore().Goal_header = sMsg10;

				var sMsg11 = oBundle.getText("GoalApproval");
				sap.ui.getCore().Goal_approver = sMsg11;

				var sMsg22 = oBundle.getText("Perf_GoalSetting");
				sap.ui.getCore().Perf_GoalSetting = sMsg22;

				var sMsg23 = oBundle.getText("Perf_goalApproval");
				sap.ui.getCore().Perf_goalApproval = sMsg23;

				var sMsg24 = oBundle.getText("Perf_halfyearly");
				sap.ui.getCore().Perf_halfyearly = sMsg24;

				var sMsg25 = oBundle.getText("Perf_annualReview");
				sap.ui.getCore().Perf_annualReview = sMsg25;

				var sMsg26 = oBundle.getText("Perf_Finalsignoff");
				sap.ui.getCore().Perf_Finalsignoff = sMsg26;

				var sMsg27 = oBundle.getText("Perf_ARC");
				sap.ui.getCore().Perf_ARC = sMsg27;

				var sMsg13 = oBundle.getText("FunctionalGoals");
				sap.ui.getCore().ru_FunctionalGoals = sMsg13;

				var sMsg17 = oBundle.getText("ProjectGoals");
				sap.ui.getCore().ru_ProjectGoals = sMsg17;

				var sMsg18 = oBundle.getText("Approver");
				sap.ui.getCore().ru_Approve = sMsg18;

				var sMsg19 = oBundle.getText("returntoemp");
				sap.ui.getCore().ru_returnemp = sMsg19;

				var sMsg20 = oBundle.getText("Comment");
				sap.ui.getCore().ru_cmnt = sMsg20;

				var sMsg10 = oBundle.getText("Goal");
				sap.ui.getCore().Goal_header = sMsg10;

				var sMsg11 = oBundle.getText("Submit");
				sap.ui.getCore().submit = sMsg11;

				sap.ui.getCore().fun_owngoal_tital = oBundle.getText("AddFunctionalGoal");
				sap.ui.getCore().fun_owngoal_KRA = oBundle.getText("KRA_Goals");
				sap.ui.getCore().fun_owngoal_KPI = oBundle.getText("KPIMeasure");
				sap.ui.getCore().fun_owngoal_Weight = oBundle.getText("Weight");
				sap.ui.getCore().fun_owngoal_startDt = oBundle.getText("StartDate");
				sap.ui.getCore().fun_owngoal_complDt = oBundle.getText("CompletionDate");

				sap.ui.getCore().P_title = oBundle.getText("P_title");
				sap.ui.getCore().P_empinfo = oBundle.getText("P_empinfo");
				sap.ui.getCore().P_Fname = oBundle.getText("P_Fname");
				sap.ui.getCore().P_empNO = oBundle.getText("P_empNO");
				sap.ui.getCore().P_desg = oBundle.getText("P_desg");
				sap.ui.getCore().P_deprt = oBundle.getText("P_deprt");
				sap.ui.getCore().P_L_1 = oBundle.getText("P_L_1");
				sap.ui.getCore().P_L_1_desg = oBundle.getText("P_L_1_desg");
				sap.ui.getCore().P_L_2 = oBundle.getText("P_L_2");
				sap.ui.getCore().P_L_2_desg = oBundle.getText("P_L_2_desg");

			}

			sap.ui.getCore().ordersThis._getDialog007().close();
			//}catch(e){console.log("Language change exception"+e);}
		},
		onSettingCancel: function() {
			sap.ui.getCore().ordersThis._getDialog007().close();
		},
		onrowchange: function(oEvent) {
			var a = oEvent.getSource();
			var b = a.getRows()[oEvent.getParameters().rowIndex];
			var c = b.getCells()[0].getText();

			var nodeid;
			for (var i = 0; i < sap.ui.getCore().HireListSet.results.length; i++) {
				if (sap.ui.getCore().HireListSet.results[i].NodeText === c) {
					nodeid = sap.ui.getCore().HireListSet.results[i].NodeId;
				}
			}
			var item = sap.ui.getCore().HireTreeSet.results.filter(function(item) {
				if (item.ParentNodeId === nodeid) {
					return item;
				}
			});

			//binding code
			var reporteesData = item;
			var EmpList = [];
			var data = [];
			for (var i = 0; i < reporteesData.length; i++) {
				EmpList.push(reporteesData[i].EmpIdE);
				if (reporteesData[i].ApStatus === "2" && reporteesData[i].ApStatusSub === "3") {
					var status = "Goal Approval";
				} else if ((reporteesData[i].ApStatus === "0" || reporteesData[i].ApStatus === "2") && reporteesData[i].ApStatusSub === "") {
					var status = "Goal Setting";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "") {
					var status = "Half Yearly Review";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "3") {
					var status = "Half Yearly Review(L+1)";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "4") {
					var status = "Goal Revisit by Employee";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "5") {
					var status = "Goal Approval of Revisit";
				} else if (reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "6") {
					var status = "Self Appraisal";
				} else if (reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "2") {
					var status = "Annual Review(L+1)";
				} else if (reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "3") {
					var status = "Annual Review(L+2)";
				} else if (reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "4") {
					var status = "ARC";
				} else if (reporteesData[i].ApStatus === "5" && reporteesData[i].ApStatusSub === "") {
					var status = "Final Sign off";
				} else if (reporteesData[i].ApStatus === "7" && reporteesData[i].ApStatusSub === "") {
					var status = "Agree Completed";
				} else if (reporteesData[i].ApStatus === "9" && reporteesData[i].ApStatusSub === "") {
					var status = "Disagree Completed";
				}
				if (reporteesData[i].WorkLevel === "Accenture" || reporteesData[i].WorkLevel === "Ext.Aushilfe stempel" ||
					reporteesData[i].WorkLevel === "C & F Agents" || reporteesData[i].WorkLevel === "Data Entry Operator" ||
					reporteesData[i].WorkLevel === "Genpact" || reporteesData[i].WorkLevel === "HP") {
					status = "partner";
				}
				var temp_data = {
					Name: reporteesData[i].EmpLname + " " + reporteesData[i].EmpFname,
					WorkLevel: reporteesData[i].WorkLevel,
					perfECTStatus: status,
					GoalSetting: "",
					GoalSetting2: "",
					GoalSetting3: "",
					GoalSetting4: "",
					GoalSetting5: "",
					GoalSetting6: "",
					GoalSetting7: "",
					EmpId: "P" + reporteesData[i].EmpCode

				};
				data.push(temp_data);
			}

			var pnl = this.getView().byId("pnlResp");
			pnl.setHeaderText(c + " Team Appraisal");
			var tblresp = sap.ui.getCore().byId("tblRespScore");
			if (tblresp != undefined) {
				sap.ui.getCore().byId("tblRespScore").destroy();
			}

			var scroll = new sap.m.ScrollContainer({
				height: "100%",
				width: "100%",
				vertical: true
				 //id: "container"
			});

			var oTable1 = new sap.m.Table({
				id: "tblRespScore",
				width: "100%",
				layout: "ResponsiveGridLayout",
				fixedLayout: false,
				showSeparators: "All",
				mode: "None"
			}).addStyleClass("tblmrgin score");

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				//	width: "45%",
				header: new sap.m.Label({
					text: "Emp Id",
					design: "Bold"
				})
			}))
			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				//	width: "45%",
				header: new sap.m.Label({
					text: "Name",
					design: "Bold"
				})
			}));

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				//	width: "45%",
				header: new sap.m.Label({
					text: "Work Level",
					design: "Bold"
				})
			}));

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				//	width: "10%",
				header: new sap.m.Label({
					text: "Status",
					design: "Bold"
				})
			}));

			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "Goal Setting",
			// 		design: "Bold"
			// 	})
			// }));
			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "Goal Approval",
			// 		design: "Bold"
			// 	})
			// }));
			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "Half Yearly Review",
			// 		design: "Bold"
			// 	})
			// }));
			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "Goal Revisit",
			// 		design: "Bold"
			// 	})
			// }));
			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "Annual Review",
			// 		design: "Bold"
			// 	})
			// }));
			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "ARC",
			// 		design: "Bold"
			// 	})
			// }));
			// oTable1.addColumn(new sap.m.Column({
			// 	hAlign: "Center",
			// 	vAlign: "Middle",
			// 	width: "10%",
			// 	header: new sap.m.Label({
			// 		text: "Final signoff",
			// 		design: "Bold"
			// 	})
			// }));

			var oModel100 = new sap.ui.model.json.JSONModel();
			oModel100.setData({
				modelData100: data
			});
			var index = oEvent.mParameters.rowIndex - 1;
			if (oEvent.mParameters.rowIndex === 0) {

				oTable1.bindAggregation("items", "/modelData100", function(sId, oContext) {
					var value = oContext.getProperty("perfECTStatus");
					switch (value) {
						case "Goal Setting":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});

						case "Goal Approval":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus1",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;
											if (obj.perfECTStatus === "Goal Approval") {
												sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
												sap.ui.getCore().dialog.close();
											}
										}

									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});

						case "Half Yearly Review":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									})
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Half Yearly Review(L+1)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus2",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}

									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Goal Revisit by Employee":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Goal Approval of Revisit":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus3",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}

									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Self Appraisal":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"

									}).addStyleClass("Link"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Annual Review(L+1)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus4",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}

									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Annual Review(L+2)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}",
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "ARC":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										//id: "idbtnStatus55",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}
									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "Final Sign off":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus6",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}
									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon")

								]
							});
						case "Agree Completed":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus7",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}
									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "Disagree Completed":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus8",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}
									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "partner":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "",
									}),
									// new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// })
								]
							});
					}
				});
			} else if( oEvent.getSource().getModel().oData.items[0].items[index] !== undefined){
				if ("P"+oEvent.getSource().getModel().oData.items[0].items[index].ParentNodeId === sap.ui.getCore().username) {

				oTable1.bindAggregation("items", "/modelData100", function(sId, oContext) {
					var value = oContext.getProperty("perfECTStatus");
					switch (value) {
						case "Goal Setting":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});

						case "Goal Approval":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});

						case "Half Yearly Review":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Half Yearly Review(L+1)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Goal Revisit by Employee":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Goal Approval of Revisit":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Self Appraisal":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"

									}).addStyleClass("Link"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Annual Review(L+1)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Annual Review(L+2)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Button({
										id: "idbtnStatus9",
										text: "{perfECTStatus}",
										press: function(e) {
											sap.ui.getCore().dialog.open();
											var model = this.getModel();
											var path = e.getSource().getBindingContext().getPath();
											var obj = model.getProperty(path);
											//console.log(obj);
											sap.ui.getCore().EMPid = obj.EmpId;

											sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
											sap.ui.getCore().dialog.close();
										}
									}).addStyleClass("btnCls"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "ARC":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "Final Sign off":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon")

								]
							});
						case "Agree Completed":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "disagree Completed":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "partner":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "",
									}),
									// new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// })
								]
							});
					}
				});
			}} else {

				oTable1.bindAggregation("items", "/modelData100", function(sId, oContext) {
					var value = oContext.getProperty("perfECTStatus");
					switch (value) {
						case "Goal Setting":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});

						case "Goal Approval":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});

						case "Half Yearly Review":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Half Yearly Review(L+1)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Goal Revisit by Employee":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Goal Approval of Revisit":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task-2"
									// 	}).addStyleClass("icon"),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task-2"
									// 	}).addStyleClass("icon"),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task-2"
									// 	}).addStyleClass("icon"),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task"
									// 	}),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task"
									// 	}),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task"
									// 	}),
									// 	new sap.ui.core.Icon({
									// 		src: "sap-icon://circle-task"
									// 	})
								]
							});
						case "Self Appraisal":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"

									}).addStyleClass("Link"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Annual Review(L+1)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })
								]
							});
						case "Annual Review(L+2)":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "ARC":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "Final Sign off":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon")

								]
							});
						case "Agree Completed":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "disagree Completed":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "{perfECTStatus}"
									}),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task-2"
									// }).addStyleClass("icon"),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// }),
									// new sap.ui.core.Icon({
									// 	src: "sap-icon://circle-task"
									// })

								]
							});
						case "partner":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
										text: "{EmpId}"
									}),
									new sap.m.Label({
										text: "{Name}"
									}),
									new sap.m.Label({
										text: "{WorkLevel}"
									}),
									new sap.m.Label({
										text: "",
									}),
									// new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// }), new sap.m.Label({
									// 	text: "",
									// })
								]
							});
					}
				});
			}

			// oTable1.bindItems("/modelData100", new sap.m.ColumnListItem({
			// 	cells: [new sap.m.Text({
			// 			text: "{EmpLname}"
			// 		}).addStyleClass("txttbl"),
			// 		new sap.m.Text({
			// 			text: "{WorkLevel}"
			// 		}).addStyleClass("txttbl")
			// 		// new sap.m.Text({
			// 		// 	text: '{WEIGHTAGE}'
			// 		// })
			// 	]//
			// }));
			oTable1.setModel(oModel100);

			//change launguage 
			//oTable1.setHeaderText(sap.ui.getCore().scorecard_tbl_header);

			//	oTable1.placeAt(pnl);
			scroll.addContent(oTable1);
			scroll.placeAt(pnl);
		},
		onrowchange_handlerou: function(oEvent) {
			var c = sap.ui.getCore().USERDATA.EmpName;
			
			var nodeid;
			for (var i = 0; i < sap.ui.getCore().HireListSet.results.length; i++) {
				if (sap.ui.getCore().HireListSet.results[i].NodeText === c) {
					nodeid = sap.ui.getCore().HireListSet.results[i].NodeId;
				}
			}
			var item = sap.ui.getCore().HireTreeSet.results.filter(function(item) {
				if (item.ParentNodeId === nodeid) {
					return item;
				}
			});
			
			//binding code
			var reporteesData = item;
			var EmpList = [];
			var data=[];
			for(var i =0 ; i<reporteesData.length;i++){
					EmpList.push(reporteesData[i].EmpIdE);
					if(reporteesData[i].ApStatus === "2" && reporteesData[i].ApStatusSub === "3"){
						var status = "Goal Approval";
					}else if((reporteesData[i].ApStatus === "0" || reporteesData[i].ApStatus === "2")  && reporteesData[i].ApStatusSub === ""){
						var status = "Goal Setting";
					}else if(reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === ""){
						var status = "Half Yearly-Employee";
					}else if(reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "3"){
						var status = "Half Yearly-Manager";
					}else if(reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "4"){
						var status = "Goal Revisit-Employee";
					}else if(reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "5"){
						var status = "Goal Approval-Manager";
					}else if(reporteesData[i].ApStatus === "3" && reporteesData[i].ApStatusSub === "6"){
						var status = "Annual Self Appraisal-Employee";
					}else if(reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "2"){
						var status = "Annual Review-L+1";
					}else if(reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "3"){
						var status = "Annual Review-L+2";
					}else if(reporteesData[i].ApStatus === "4" && reporteesData[i].ApStatusSub === "4"){
						var status = "ARC";
					}else if(reporteesData[i].ApStatus === "5" && reporteesData[i].ApStatusSub === ""){
						var status = "Final Sign off";
					}else if(reporteesData[i].ApStatus === "7" && reporteesData[i].ApStatusSub === ""){
						var status = "Agree Completed";
					}else if(reporteesData[i].ApStatus === "9" && reporteesData[i].ApStatusSub === ""){
						var status = "Disagree Completed";
					}
					if(reporteesData[i].WorkLevel === "Accenture" || reporteesData[i].WorkLevel === "Ext.Aushilfe stempel" ||
								reporteesData[i].WorkLevel === "C & F Agents" || reporteesData[i].WorkLevel === "Data Entry Operator" ||
								reporteesData[i].WorkLevel === "Genpact" || reporteesData[i].WorkLevel === "HP"){
									status = "partner";
								}
						var temp_data = {
							Name : reporteesData[i].EmpLname + " " + reporteesData[i].EmpFname,
							WorkLevel : reporteesData[i].WorkLevel,
							perfECTStatus: status,
							GoalSetting: "",
							GoalSetting2:"",
							GoalSetting3:"",
							GoalSetting4:"",
							GoalSetting5:"",
							GoalSetting6:"",
							GoalSetting7:"",
							EmpId: "P"+reporteesData[i].EmpCode
							
						};
						data.push(temp_data);
			}

			var pnl = this.getView().byId("pnlResp");
			pnl.setHeaderText(c+" Team Appraisal");                         
			var tblresp = sap.ui.getCore().byId("tblRespScore");
			if (tblresp != undefined) {
				sap.ui.getCore().byId("tblRespScore").destroy();
			}
			var oTable1 = new sap.m.Table({
				id: "tblRespScore",
				width: "75%",
				layout: "ResponsiveGridLayout",
				fixedLayout: false,
				showSeparators: "All",
				mode: "None",
				noDataText: "No direct Reportees for this employee."
			}).addStyleClass("tblmrgin score");
			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "45%",
				header: new sap.m.Label({
					id: "ID_Emp",
					text: sap.ui.getCore().L_empid,
					design: "Bold"
				})
			}));
			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "45%",
				header: new sap.m.Label({
					id: "ID_NAME",
					text: sap.ui.getCore().L_name,
					design: "Bold"
				})
			}));

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "45%",
				header: new sap.m.Label({
					id: "ID_ROLEBAND",
					text: sap.ui.getCore().L_worklevel,
					design: "Bold"
				})
			}));

			oTable1.addColumn(new sap.m.Column({
				hAlign: "Center",
				vAlign: "Middle",
				width: "10%",
				header: new sap.m.Label({
					id: "ID_STATUS",
					text: sap.ui.getCore().L_status,
					design: "Bold"
				})
			}));
			
			var oModel100 = new sap.ui.model.json.JSONModel();
			oModel100.setData({
				modelData100: data
			});
			
			
				oTable1.bindAggregation("items", "/modelData100", function(sId, oContext) {
					var value = oContext.getProperty("perfECTStatus");
					switch(value) {
						case "Goal Setting":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Label({
							text: "{perfECTStatus}"
						})
					]
				});
					
					case "Goal Approval":
							return new sap.m.ColumnListItem({
								cells: [
									new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        if(obj.perfECTStatus === "Goal Approval"){
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        }
							}
						
						})
					]
				});	
				
				case "Half Yearly-Employee":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Label({
							text: "{perfECTStatus}"
						})
					]
				});
				case "Half Yearly-Manager":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						
						}).addStyleClass("Link")
					]
				});
				case "Goal Revisit-Employee":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Label({
							text: "{perfECTStatus}"
						})
					]
				});
				case "Goal Approval-Manager":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						
						}).addStyleClass("Link")
					]
				});
				case "Annual Self Appraisal-Employee":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Label({
							text: "{perfECTStatus}"
						
						}).addStyleClass("Link")
					]
				});
				case "Annual Review-L+1":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						
						}).addStyleClass("Link")
					]
				});
				case "Annual Review-L+2":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
						new sap.m.Label({
							text: "{perfECTStatus}",
						})
						
					]
				});
				case "ARC":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
						new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						}).addStyleClass("Link")
						
					]
				});
				case "Final Sign off":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
						new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
									sap.ui.getCore().ODThis.showBusyIndicator(20000, 0);
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						}).addStyleClass("Link")
						
					]
				});
				case "Agree Completed":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
						new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						}).addStyleClass("Link")
						
					]
				});
				case "Disagree Completed":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
						new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(e){
								
								var model = this.getModel();
						        var path = e.getSource().getBindingContext().getPath();
						        var obj = model.getProperty(path);
						        //console.log(obj);
						        sap.ui.getCore().EMPid = obj.EmpId;
						        
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
						        
							}
						}).addStyleClass("Link")
						
					]
				});
				case "partner":
							return new sap.m.ColumnListItem({
								cells: [
						new sap.m.Label({
							text: "{EmpId}"
						}),
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Label({
							text: "",
						})
					]
				});
					}
				});
			


			
			// oTable1.bindItems("/modelData100", new sap.m.ColumnListItem({
			// 	cells: [new sap.m.Text({
			// 			text: "{EmpLname}"
			// 		}).addStyleClass("txttbl"),
			// 		new sap.m.Text({
			// 			text: "{WorkLevel}"
			// 		}).addStyleClass("txttbl")
			// 		// new sap.m.Text({
			// 		// 	text: '{WEIGHTAGE}'
			// 		// })
			// 	]
			// }));
			oTable1.setModel(oModel100);

			//change launguage 
			//oTable1.setHeaderText(sap.ui.getCore().scorecard_tbl_header);

			oTable1.placeAt(pnl);
		}


	});

});