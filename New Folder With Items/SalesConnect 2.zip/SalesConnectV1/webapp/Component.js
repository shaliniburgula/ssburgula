jQuery.sap.declare("SalesConnectV1.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("SalesConnectV1.Component", {
	metadata: {
		"manifest": "json"
	}
});