jQuery.sap.declare("drlhubpagesfiori.util.Formatter");

jQuery.sap.require("sap.ui.core.format.DateFormat");

drlhubpagesfiori.util.Formatter = {

  _statusStateMap : {
    "Neu" : "Warning",
    "Initial" : "Success"
  },

  _statusStateMap1 : {
    "I" : "Warning",
    "A" : "Success"
  },

date : function (value) {
    if (value) {
      var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd-MM-yyyy"});
       var value = oDateFormat.format(new Date(value));

      if(value =='31-12-9999'){
        value="Not Applicable";
      }
      return value;
    } else {
      return value;
    }
  },


  numFormat: function (value) {

      var value = parseInt(value);
      if(value == "NaN"){
        value="";
      }
      return value;

  },

  quantity :  function (value) {
    try {
      return (value) ? parseFloat(value).toFixed(0) : value;
    } catch (err) {
      return "Not-A-Number";
    }
  }
};