sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "drlhubpagesfiori/model/models"
], function(UIComponent, Device, models) {
  "use strict";

  return UIComponent.extend("drlhubpagesfiori.Component", {

    metadata: {
       includes: ["css/custom.css"],
      routing: {
        config: {
          i18nBundle: "drlhubpagesfiori.i18n.messageBundle",
          routerClass: "sap.m.routing.Router",
          viewType: "XML",
          viewPath: "drlhubpagesfiori.view",
          targetControl: "idApp",
          targetAggregation: "content",
          clearTarget: false,



        },
        dependencies : {
          libs : [
            "sap.m"
          ],
          components : [
            "drlhubpagesfiori.view.Table"
          ]
        },

        routes : [

                        {
                              pattern: "",
                              view: "HUB",
                              viewId:"idHub",
                              name: "hubpages",
                              targetAggregation:"pages",
                        },
                        {
                              pattern: "PO",
                              view: "PO",
                              viewId:"idPO",
                              name: "POpage",
                              targetAggregation:"pages",
                        }
                        ,
                        {
                              pattern: "ASN",
                              view: "ASN",
                              viewId:"idASN",
                              name: "ASNpage",
                              targetAggregation:"pages",
                        },
                        {
                              pattern: "Invoice/{contextPath}",
                              view: "INV",
                              viewId:"idINV",
                              name: "Invoicepage",
                              targetAggregation:"pages",
                        },
                        {
                              pattern: "PODetails/{contextPath}",
                              view: "PODetails",
                              viewId:"idPODetails",
                              name: "PODetailspage",
                              targetAggregation:"pages",
                        },
                        {
                              pattern: "ViewPDF/{contextPath}",
                              view: "viewPDF",
                              viewType: "JS",
                              viewId:"idViewPDF",
                              name: "viewPDFpage",
                              targetAggregation:"pages",
                        },

                        {
                              pattern: "Notification/{contextPath}",
                              view: "Notification",
                              viewType: "XML",
                              viewId:"idNotifi",
                              name: "Notifipage",
                              targetAggregation:"pages",
                        }

                     ]
      }
    },

    /**
     * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
     * @public
     * @override
     */
    init: function() {

     /******************************************************************************************
      *                            Creating a User profile Object
      *******************************************************************************************/
    /* var oUser = sap.ui2.shell.getUser();
      var fullName;
      var userId;
      oUser.load({}, function(){
        var fullName = oUser.getFullName();
        var userId = oUser.getId();
        var welcomeMessage = oUser.getWelcomeMessage();
//debugger;
        console.log('you are loggin in with ' + fullName + ', your user id is ' + userId);

      }, function(sError){
        alert ('user fetching failed ' + sError );
      });
*/

      // end of creating a user profile object


      var mConfig = this.getMetadata().getConfig();
      // call the base components init function
      UIComponent.prototype.init.apply(this, arguments);

      // set the device model
      this.setModel(models.createDeviceModel(), "device");
      this.setModel(models.createResourceModel("drlhubpagesfiori.i18n.messageBundle"), "i18n");
      this.getRouter().initialize();
    },

    createContent : function() {

      var oView = sap.ui.view({
        id : "idApp",
        viewName : "drlhubpagesfiori.view.App",
        type : "XML",
        viewData : { component : this }
      });


    //  var i18nModel = new sap.ui.model.resource.ResourceModel({ bundleUrl : "i18n/messageBundle.properties" });
      //oView.setModel(i18nModel, "i18n");

      var deviceModel = new sap.ui.model.json.JSONModel(
          {
            isPhone : jQuery.device.is.phone,
            isNoPhone : !jQuery.device.is.phone,
            listMode : (jQuery.device.is.phone) ? "None"
                : "SingleSelectMaster",
            listItemType : (jQuery.device.is.phone) ? "Active"
                : "Inactive"
          });
      deviceModel.setDefaultBindingMode("OneWay");
      oView.setModel(deviceModel, "device");

      return oView;
    },
    getContentDensityClass : function() {
        if (this._sContentDensityClass === undefined) {
          // check whether FLP has already set the content density class; do nothing in this case
          if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {
            this._sContentDensityClass = "";
          } else if (!Device.system.phone) { // apply "compact" mode if touch is not supported

            this._sContentDensityClass = "sapUiSizeCompact";
          } else {

            // "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
            this._sContentDensityClass = "sapUiSizeCozy";
          }
        }

        return this._sContentDensityClass;
      }
  });

});