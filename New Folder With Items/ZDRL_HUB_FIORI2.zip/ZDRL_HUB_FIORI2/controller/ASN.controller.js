jQuery.sap.require("drlhubpagesfiori.util.Formatter");
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter"
], function(Controller,Filter) {
  "use strict";

  return Controller.extend("drlhubpagesfiori.controller.ASN", {
    onInit:function()
    {
    var dModel = new sap.ui.model.json.JSONModel();
      this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    
          var oContext = this.getView().getBindingContext();          
          var value="M03";
          
          var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_HUB_FIORI_SRV/", true, "", "");

    
      this.feedTransitData(oDataModel,dModel,oContext,value);
      this.feedPendingData(oDataModel,dModel,oContext,value);
      this.feedGateEntryData(oDataModel,dModel,oContext,value);
      this.feedPendGRNData(oDataModel,dModel,oContext,value);
      
    },

    /*onAfterRendering : function()
    {
      alert("after");
      var oIconTabBar = this.getView().byId("idIconTabASNBar")
          oIconTabBar.fireSelect({ //trying to select the WIP tab dynamically without a user click  
              key: "pendingGRN",  
              item: oIconTabBar.getItems()[3]  
          });  
          oIconTabBar.setSelectedKey("pendingGRN");
    },*/
    feedTransitData : function(oDataModel,dModel,oContext,value)
    {
      var dModelTransit = new sap.ui.model.json.JSONModel();
      var pathTransit ="AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '"+value+"' and Status eq '02'";
          
      oDataModel.read(pathTransit, oContext, [], false, function (data) {

        dModelTransit.setData(data);
                 
      }, function (err) {                              
        console.log("inside failure");                               
      });      

      sap.ui.getCore().setModel(dModelTransit,"ASNTranHubSetModel");
      sap.ui.getCore().byId("idASN").setModel(dModelTransit,"ASNTranHubSetModel");
      sap.ui.getCore().byId("idASN--idASNtableIntransit").setModel(dModelTransit);
    },
    feedPendingData : function(oDataModel,dModel,oContext,value)
    {
      var dModel = new sap.ui.model.json.JSONModel();
       var path ="AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '"+value+"' and Status eq '01'";
          
        oDataModel.read(path, oContext, [], false, function (data) {

             dModel.setData(data);
                   
        }, function (err) {                              
          console.log("inside failure");                               
        });      

        sap.ui.getCore().setModel(dModel,"ASNHubSetModel");
        sap.ui.getCore().byId("idASN").setModel(dModel,"ASNHubSetModel");
        sap.ui.getCore().byId("idASN--idASNtablePending").setModel(dModel);

    },
    feedGateEntryData : function(oDataModel,dModel,oContext,value)
    {
      var dModelGateEntry = new sap.ui.model.json.JSONModel();
      var pathGateEntry ="AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '"+value+"' and Status eq '03'";
          
      oDataModel.read(pathGateEntry, oContext, [], false, function (data) {

        dModelGateEntry.setData(data);
                 
      }, function (err) {                              
        console.log("inside failure");                               
      });      

      sap.ui.getCore().setModel(dModelGateEntry,"ASNGateEntryHubSetModel");
      sap.ui.getCore().byId("idASN").setModel(dModelGateEntry,"ASNGateEntryHubSetModel");
      sap.ui.getCore().byId("idASN--idASNtableGateEntry").setModel(dModelGateEntry);

    },
    feedPendGRNData : function (oDataModel,dModel,oContext,value)
    {
      var dModelPendGRN = new sap.ui.model.json.JSONModel();
      var pathPendGRN ="AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '"+value+"' and Status eq '04'";
          
      oDataModel.read(pathPendGRN, oContext, [], false, function (data) {

        dModelPendGRN.setData(data);
                 
      }, function (err) {                              
        console.log("inside failure");                               
      });      

      sap.ui.getCore().setModel(dModelPendGRN,"ASNPendGRNHubSetModel");
      sap.ui.getCore().byId("idASN").setModel(dModelPendGRN,"ASNPendGRNHubSetModel");
      sap.ui.getCore().byId("idASN--idASNtablePendingGRN").setModel(dModelPendGRN);
    },
    onNavBack: function() {

      this._oRouter.navTo("hubpages");

  },
  handleChange : function(oEvent)
  {
    //2016-04-20T00:00:00
    var sFrom = oEvent.getParameter("from");
    var sTo = oEvent.getParameter("to");
    var bValid = oEvent.getParameter("valid");

    console.log(sFrom);
    console.log(sTo);
    console.log(bValid);

    this._iEvent++;
     

    var oDRS = oEvent.oSource;
    if (bValid) {
      oDRS.setValueState(sap.ui.core.ValueState.None);
    } else {
      oDRS.setValueState(sap.ui.core.ValueState.Error);
    }

    var formattedStartDate = new Date(sFrom);
        var formattedEndDate = new Date(sTo);

        formattedStartDate = this.ui5ToOdatadataForLocalFiltering(sFrom, 'date');
        formattedEndDate = this.ui5ToOdatadataForLocalFiltering(sTo, 'date');
        
        console.log(formattedStartDate);
        console.log(formattedEndDate);
        
        formattedStartDate = this.formatDate(formattedStartDate);
        formattedEndDate = this.formatDate(formattedEndDate);
        
        console.log("_________");
        console.log(formattedStartDate);
        console.log(formattedEndDate);
        
        var filters = [];
        filters.push(new sap.ui.model.Filter("openSince", sap.ui.model.FilterOperator.BT, formattedStartDate, formattedEndDate)) 
                        var oFilter = new sap.ui.model.Filter(filters, false);
        
      
          sap.ui.getCore().byId("idASN--idASNtableIntransit").getBinding("items").filter(oFilter);



  },
  formatDate : function (value) {

      console.log(value);
      var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyy-MM-ddT00:00:00"}); 


      return oDateFormat.format(new Date(value));

  },
  
   ui5ToOdatadataForLocalFiltering : function(data, type) {
      if (type === 'date') {
                      var iDatadt = data;
                      var month = (iDatadt.getMonth() + 1);
                      var day = iDatadt.getDate()

                      if ((iDatadt.getMonth() + 1).toString().length < 2) {
                                      month = '0' + (iDatadt.getMonth() + 1);
                      }

                      if ((iDatadt.getDate()).toString().length < 2) {
                                      day = '0' + iDatadt.getDate();
                      }

                      iDatadt = iDatadt.getFullYear() +
                                      '-' + month +
                                      '-' + day +
                                      'T' + "00" +
                                      ':' + "00" +
                                      ':' + "00";

                      return iDatadt;
      }
      if (type == 'time') {
                      var iDataTime = data;
                      iDataTime = 'PT' + iDataTime.slice(0, 2) + 'H' + iDataTime.slice(3, 5) + 'M' + iDataTime.slice(6, 8) + 'S';
                      return iDataTime;
      }
}


  });

});