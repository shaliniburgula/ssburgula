var dModel, dModelASN, dModelINV;
var oContext, oContext;
var oDataModel;
var value;
var monthVal;
var ThreeMonths, SixMonths, YearValue;
var poCount,invCount,NotificationCount,notificationCountdata
sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller, POController) {
    "use strict";
    return Controller.extend("drlhubpagesfiori.controller.HUB", {
        onInit: function() {
            this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

/******************************************************************************************
      *                            Creating a User profile Object
      *******************************************************************************************/
/* var oUser = sap.ui2.shell.getUser();
      var fullName;
      var userId;
      oUser.load({}, function(){
        var fullName = oUser.getFullName();
        var userId = oUser.getId();
        var welcomeMessage = oUser.getWelcomeMessage();


      var userName = sap.ui.getCore().byId("idHub--idWelcomeMessage");

      userName.setText("Welcome "+fullName);
      }, function(sError){
     //   alert ('user fetching failed ' + sError );
      });

*/
      // end of creating a user profile object
            dModel = new sap.ui.model.json.JSONModel();
            oContext = sap.ui.getCore().byId("idHub").getBindingContext();

            oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_HUB_FIORI_SRV/",true, "", "");

            if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                value = "M03";
                this.feedData(oDataModel, dModel, oContext, value);
                this.feedDataASN(oDataModel, dModelASN, oContext, value);
                this.feedDataINV(oDataModel, dModelINV, oContext, value);
                sap.ui.getCore().byId("idHub--idSelection").setType("Emphasized");
            } else {
                this.feedData(oDataModel, dModel, oContext, monthVal);
                this.feedDataASN(oDataModel, dModelASN, oContext, monthVal);
                this.feedDataINV(oDataModel, dModelINV, oContext, monthVal);
            }
            var button1 = sap.ui.getCore().byId("idHub--idSelection").getType();
            var button2 = sap.ui.getCore().byId("idHub--idSelection").getType();
            var button3 = sap.ui.getCore().byId("idHub--idSelection").getType();
           if (button1 == "Emphasized") {
                sap.ui.getCore().byId("idHub--idSelection").setType("Emphasized");
                sap.ui.getCore().byId("idHub--idSelection1").setType("Default");
                sap.ui.getCore().byId("idHub--idSelection2").setType("Default");
            } else if (button2 == "Emphasized") {
                sap.ui.getCore().byId("idHub--idSelection").setType("Default");
                sap.ui.getCore().byId("idHub--idSelection1").setType("Emphasized");
                sap.ui.getCore().byId("idHub--idSelection2").setType("Default");
            } else if (button3 == "Emphasized") {
                sap.ui.getCore().byId("idHub--idSelection").setType("Default");
                sap.ui.getCore().byId("idHub--idSelection1").setType("Default");
                sap.ui.getCore().byId("idHub--idSelection2").setType("Emphasized");
            }

            poCount = "1";//sap.ui.getCore().getModel("PoHubCountSetModel").getData().results[0].Count;

            invCount = "2";//sap.ui.getCore().getModel("INVHubCountSetModel").getData().results[5].Count;

            NotificationCount = parseInt(poCount) + parseInt(invCount);
           notificationCountdata = {
                    results:[
                                 {count:""}

                            ]
          };

           var dModelNotCount = new sap.ui.model.json.JSONModel();
           notificationCountdata.results[0]['count'] = NotificationCount;
           dModelNotCount.setData(notificationCountdata);
           sap.ui.getCore().setModel(dModelNotCount,"NotificationModel");
           sap.ui.getCore().byId("idHub").setModel(dModelNotCount, "NotificationModel");
           sap.ui.getCore().byId("idHub--idIconTabBarMulti").setSelectedKey("Bell");

        },
        feedData: function(oDataModel, dModel, oContext, monthValue) {
            var path = "PoHubCountSet?$filter=DataType eq 'PO' and DataRange eq '" + monthValue +"'";
            oDataModel.read(path, oContext, [], false, function(data) {
                dModel.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().setModel(dModel, "PoHubCountSetModel");
            sap.ui.getCore().byId("idHub").setModel(dModel, "PoHubCountSetModel");
            var dModelAck = new sap.ui.model.json.JSONModel();
            var pathAck = "PoHubSet?$filter=DataType eq 'PO' and DataRange eq '" + monthValue +"' and Status eq '02'";

            var confirmArr = new Array();
            var dModelConf = new sap.ui.model.json.JSONModel();
            oDataModel.read(pathAck, oContext, [], false, function(data) {
                for (var i = 0; i <= data.results.length - 1; i++) {
                    if (data.results[i].PoStatTxt == "Confirmed") {
                        confirmArr.push(data.results[i]);
                    }
                }
                dModelConf.setData(confirmArr);
            }, function(err) {
                console.log("inside failure");
            });
            var confirmArrSize = confirmArr.length;
            var ConfirmJsondata = {
                results: [{
                    Item: confirmArrSize
                }, ]
            };
            var dModelConfButton = new sap.ui.model.json.JSONModel();
            dModelConfButton.setData(ConfirmJsondata.results[0]);
            sap.ui.getCore().setModel(dModelConfButton, "dModelConfButtonData");
            sap.ui.getCore().byId("idHub").setModel(dModelConfButton, "dModelConfButtonData");
        },
        feedDataASN: function(oDataModel, dModelASN, oContext, monthValue) {
            dModelASN = new sap.ui.model.json.JSONModel();
            var pathASN = "AsnHubCountSet?$filter=DataType eq 'ASN' and DataRange eq '" +
                monthValue + "'";
            oDataModel.read(pathASN, oContext, [], false, function(data) {
                dModelASN.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().setModel(dModelASN, "ASNHubCountSetModel");
            sap.ui.getCore().byId("idHub").setModel(dModelASN, "ASNHubCountSetModel");
        },
        feedDataINV: function(oDataModel, dModelINV, oContext, monthValue) {
            dModelINV = new sap.ui.model.json.JSONModel();
            var pathINV = "InvHubCountSet?$filter=DataType eq 'INV' and DataRange eq '" +
                monthValue + "'";
            oDataModel.read(pathINV, oContext, [], false, function(data) {
                dModelINV.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().setModel(dModelINV, "INVHubCountSetModel");
            sap.ui.getCore().byId("idHub").setModel(dModelINV, "INVHubCountSetModel");
        },
        onPressMonth: function(oEvent) {
            var id = oEvent.getSource().getId();
            sap.ui.getCore().byId("idHub").setBusy(true);
            jQuery.sap.delayedCall(5000, this, function() {
                if (id == "idHub--idSelection") {
                    sap.ui.getCore().byId("idHub--idSelection").setType("Emphasized");
                    sap.ui.getCore().byId("idHub--idSelection1").setType("Default");
                    sap.ui.getCore().byId("idHub--idSelection2").setType("Default");
                    var ThreeMonths = "M03";
                    monthVal = ThreeMonths;
                    this.feedData(oDataModel, dModel, oContext, ThreeMonths);
                    this.feedDataASN(oDataModel, dModelASN, oContext, ThreeMonths);
                    this.feedDataINV(oDataModel, dModelINV, oContext, ThreeMonths);
                    this.notificationCount();
                } else if (id == "idHub--idSelection1") {
                    sap.ui.getCore().byId("idHub--idSelection").setType("Default");
                    sap.ui.getCore().byId("idHub--idSelection1").setType("Emphasized");
                    sap.ui.getCore().byId("idHub--idSelection2").setType("Default");
                    SixMonths = "M06";
                    monthVal = SixMonths;
                    this.feedData(oDataModel, dModel, oContext, SixMonths);
                    this.feedDataASN(oDataModel, dModelASN, oContext, SixMonths);
                    this.feedDataINV(oDataModel, dModelINV, oContext, SixMonths);
                    this.notificationCount();
                } else if (id == "idHub--idSelection2") {
                    sap.ui.getCore().byId("idHub--idSelection").setType("Default");
                    sap.ui.getCore().byId("idHub--idSelection1").setType("Default");
                    sap.ui.getCore().byId("idHub--idSelection2").setType("Emphasized");
                    var Yearvalue = "M12";
                    monthVal = Yearvalue;
                    this.feedData(oDataModel, dModel, oContext, Yearvalue);
                    this.feedDataASN(oDataModel, dModelASN, oContext, Yearvalue);
                    this.feedDataINV(oDataModel, dModelINV, oContext, Yearvalue);
                    this.notificationCount();
                }
                sap.ui.getCore().byId("idHub").setBusy(false);
            });
        },
        pressPO: function() {
            this._oRouter.navTo("POpage");
        },
        pressASN: function() {
            this._oRouter.navTo("ASNpage");
        },
        pressINV: function() {
            this._oRouter.navTo("Invoicepage");
        },
        feedPOData: function(oDataModel, oContext, monthVal) {
            var dModelPO = new sap.ui.model.json.JSONModel();
            var path = "PoHubSet?$filter=DataType eq 'PO' and DataRange eq '" + monthVal +
                "' and Status eq '01'";
            oDataModel.read(path, oContext, [], false, function(data) {
                dModelPO.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idPO--idPOtableNew").setModel(dModelPO);

        },

        feedPODataConf: function(oDataModel, oContext, monthVal) {
            var confirmArr1 = new Array();
            var dModelconf1 = new sap.ui.model.json.JSONModel();
            var pathAck = "PoHubSet?$filter=DataType eq 'PO' and DataRange eq '" + monthVal +
                "' and Status eq '02'";
            oDataModel.read(pathAck, oContext, [], false, function(data) {
                for (var i = 0; i <= data.results.length - 1; i++) {
                    if (data.results[i].PoStatTxt == "Confirmed") {
                        confirmArr1.push(data.results[i]);
                    }
                }
                dModelconf1.setData(confirmArr1);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idPO--idPOtableconf").setModel(dModelconf1);
        },
        onClickPO: function(oEvent) {
            var buttonID = oEvent.getSource().getId();
            sap.ui.getCore().byId(buttonID).setType("Default");
            sap.ui.getCore().byId("idHub").setBusy(true);
            jQuery.sap.delayedCall(1500, this, function() {
                this._oRouter.navTo("POpage");
                if (buttonID == "idHub--idNewButton") {
                   sap.ui.getCore().byId("idPO--idIconTabBar").setSelectedKey("confirm");
                    sap.ui.getCore().byId("idPO--idIconTabBar").setSelectedKey("new");
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this.feedPOData(oDataModel, oContext, monthVal);
                    this.feedPODataConf(oDataModel, oContext, monthVal);
                }else if (buttonID == "idHub--idConfButton") {
                   sap.ui.getCore().byId("idPO--idIconTabBar").setSelectedKey("new");
                    sap.ui.getCore().byId("idPO--idIconTabBar").setSelectedKey("confirm");
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this.feedPOData(oDataModel, oContext, monthVal);
                    this.feedPODataConf(oDataModel, oContext, monthVal);
                }
                sap.ui.getCore().byId("idHub").setBusy(false);
                 sap.ui.getCore().byId(buttonID).setType("Transparent");
            });
        },
        onClickASN: function(oEvent) {
            var linkID = oEvent.getSource().getId();
            console.log(linkID);
            sap.ui.getCore().byId("idHub").setBusy(true);
            jQuery.sap.delayedCall(1500, this, function() {
                this._oRouter.navTo("ASNpage");
                if (linkID == "idHub--idASN1") {
                   sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("pendingShip");
                    sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("inTransit");
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this.feedASNDataTransit(oDataModel, oContext, monthVal);
                    this.feedASNDataPending(oDataModel, oContext, monthVal);
                    this.feedASNDataGateEntry(oDataModel, oContext, monthVal);
                    this.feedASNDataPendGRN(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idASN2") {
                  sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("gateentry");
                    sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("pendingShip");
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this.feedASNDataTransit(oDataModel, oContext, monthVal);
                    this.feedASNDataPending(oDataModel, oContext, monthVal);
                    this.feedASNDataGateEntry(oDataModel, oContext, monthVal);
                    this.feedASNDataPendGRN(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idASN3") {
                   sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("pendingShip");
                    sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("gateentry");
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this.feedASNDataTransit(oDataModel, oContext, monthVal);
                    this.feedASNDataPending(oDataModel, oContext, monthVal);
                    this.feedASNDataGateEntry(oDataModel, oContext, monthVal);
                    this.feedASNDataPendGRN(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idASN4") {
                   sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("pendingShip");
                  sap.ui.getCore().byId("idASN--idIconTabASNBar").setSelectedKey("pendingGRN");
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this.feedASNDataTransit(oDataModel, oContext, monthVal);
                    this.feedASNDataPending(oDataModel, oContext, monthVal);
                    this.feedASNDataGateEntry(oDataModel, oContext, monthVal);
                    this.feedASNDataPendGRN(oDataModel, oContext, monthVal);
                }
                sap.ui.getCore().byId("idHub").setBusy(false);
            });
        },
        onClickINV: function(oEvent) {
            var linkID = oEvent.getSource().getId();
            console.log(linkID);
            sap.ui.getCore().byId("idHub").setBusy(true);
            jQuery.sap.delayedCall(1500, this, function() {

                if (linkID == "idHub--idINV1") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("undDev");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV2") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("undDev");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV3") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("HC");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV4") {
                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey(
                        "holdPay");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV5") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("clrPay");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV6") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("PayCrd");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV7") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("InPr");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                } else if (linkID == "idHub--idINV8") {

                    if (monthVal != "M03" && monthVal != "M06" && monthVal != "M12") {
                        monthVal = value;
                    }
                    this._oRouter.navTo("Invoicepage",{contextPath:monthVal});
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Upload");
                    sap.ui.getCore().byId("idINV--idIconINVTabBar").setSelectedKey("Rejd");
                    this.feedINVupload(oDataModel, oContext, monthVal);
                    this.feedINVHardCopy(oDataModel, oContext, monthVal);
                    this.feedINVInProcess(oDataModel, oContext, monthVal);
                    this.feedINVUnderDev(oDataModel, oContext, monthVal);
                    this.feedINVHoldPay(oDataModel, oContext, monthVal);
                    this.feedINVClrPay(oDataModel, oContext, monthVal);
                    this.feedINVPayCrd(oDataModel, oContext, monthVal);
                    this.feedINVRej(oDataModel, oContext, monthVal);
                }
                sap.ui.getCore().byId("idHub").setBusy(false);
            });
        },
        feedASNDataTransit: function(oDataModel, oContext, monthVal) {
            var dModelASNTransit = new sap.ui.model.json.JSONModel();
            var path = "AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '" + monthVal +
                "' and Status eq '02'";
            oDataModel.read(path, oContext, [], false, function(data) {
                dModelASNTransit.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idASN--idASNtableIntransit").setModel(dModelASNTransit);
        },
        feedASNDataPending: function(oDataModel, oContext, monthVal) {
            var dModelPending = new sap.ui.model.json.JSONModel();
            var path = "AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '" + monthVal +
                "' and Status eq '01'";
            oDataModel.read(path, oContext, [], false, function(data) {
                dModelPending.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            console.log(dModelPending);
            sap.ui.getCore().byId("idASN--idASNtablePending").setModel(dModelPending);
        },
        feedASNDataGateEntry: function(oDataModel, oContext, monthVal) {
            var dModelGateEntry1 = new sap.ui.model.json.JSONModel();
            var pathGateEntry = "AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '" + monthVal +
                "' and Status eq '03'";
            oDataModel.read(pathGateEntry, oContext, [], false, function(data) {
                dModelGateEntry1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            console.log(dModelGateEntry1);
            sap.ui.getCore().byId("idASN--idASNtableGateEntry").setModel(dModelGateEntry1);
        },
        feedASNDataPendGRN: function(oDataModel, oContext, monthVal) {
            var dModelPendingGRN = new sap.ui.model.json.JSONModel();
            var pathPendGRN = "AsnHubSet?$filter=DataType eq 'ASN' and DataRange eq '" + monthVal +
                "' and Status eq '04'";
            oDataModel.read(pathPendGRN, oContext, [], false, function(data) {
                dModelPendingGRN.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idASN--idASNtablePendingGRN").setModel(dModelPendingGRN);
        },
        feedINVupload: function(oDataModel, oContext, monthVal) {
            var dModelUpload1 = new sap.ui.model.json.JSONModel();
            var path = "InvcHub01Set?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status eq '01'";
            oDataModel.read(path, oContext, [], false, function(data) {
                dModelUpload1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVUpload").setModel(dModelUpload1);
        },
        feedINVHardCopy: function(oDataModel, oContext, monthVal) {
            var dModelHC1 = new sap.ui.model.json.JSONModel();
            var pathHC = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '02'";
            oDataModel.read(pathHC, oContext, [], false, function(data) {
                dModelHC1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVHC").setModel(dModelHC1);

        },
        feedINVInProcess: function(oDataModel, oContext, monthVal) {
            var dModelInPr1 = new sap.ui.model.json.JSONModel();
            var pathInPr = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '03'";
            oDataModel.read(pathInPr, oContext, [], false, function(data) {
                dModelInPr1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVInProcess").setModel(dModelInPr1);
        },
        feedINVUnderDev: function(oDataModel, oContext, monthVal) {
            var dModelUD1 = new sap.ui.model.json.JSONModel();
            var pathUD = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '04'";
            oDataModel.read(pathUD, oContext, [], false, function(data) {
                dModelUD1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVUndDev").setModel(dModelUD1);
        },
        feedINVHoldPay: function(oDataModel, oContext, monthVal) {
            var dModelHoldPay1 = new sap.ui.model.json.JSONModel();
            var pathHoldPay = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '05'";
            oDataModel.read(pathHoldPay, oContext, [], false, function(data) {
                dModelHoldPay1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVHoldPay").setModel(dModelHoldPay1);
        },
        feedINVClrPay: function(oDataModel, oContext, monthVal) {
            var dModelClrPay1 = new sap.ui.model.json.JSONModel();
            var pathClrPay = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '06'";
            oDataModel.read(pathClrPay, oContext, [], false, function(data) {
                dModelClrPay1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().setModel(dModelClrPay1,"clearPayModel")
            sap.ui.getCore().byId("idINV--idINVClrPay").setModel(dModelClrPay1);

        },
        feedINVPayCrd: function(oDataModel, oContext, monthVal) {
            var dModelPayCrd1 = new sap.ui.model.json.JSONModel();
            var pathPayCrd = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '07'";
            oDataModel.read(pathPayCrd, oContext, [], false, function(data) {
                dModelPayCrd1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVPayCrd").setModel(dModelPayCrd1);
        },
        feedINVRej: function(oDataModel, oContext, monthVal) {
            var dModelRej1 = new sap.ui.model.json.JSONModel();
            var pathRej = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthVal +
                "' and Status1 eq '08'";
            oDataModel.read(pathRej, oContext, [], false, function(data) {
                dModelRej1.setData(data);
            }, function(err) {
                console.log("inside failure");
            });
            sap.ui.getCore().byId("idINV--idINVRej").setModel(dModelRej1);
        },
        onNotificationSelect : function()
        {
          var monthNotiValue;
            var oNotifiContext = sap.ui.getCore().byId("idHub").getBindingContext();

              var oNotifiDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_HUB_FIORI_SRV/",true, "", "");

          if(monthVal != "M03" && monthVal != "M06" && monthVal != "M12")
            {
              monthNotiValue = value;
            }
          else
            {
              monthNotiValue = monthVal;
            }

           this._oRouter.navTo("Notifipage",{contextPath:monthNotiValue});

           var dModelPONotification = new sap.ui.model.json.JSONModel();
             var path = "PoHubSet?$filter=DataType eq 'PO' and DataRange eq '" + monthNotiValue +
                 "' and Status eq '01'";
             oNotifiDataModel.read(path, oNotifiContext, [], false, function(data) {
               dModelPONotification.setData(data);
               console.log(data);
             }, function(err) {
                 console.log("inside failure");
             });
             sap.ui.getCore().byId("idNotifi--idPONotiGrp").setModel(dModelPONotification);


           var dModelClrPayNotification = new sap.ui.model.json.JSONModel();
             var pathClrPay = "InvcHubSet?$filter=DataType eq 'INV' and DataRange eq '" + monthNotiValue +
                 "' and Status1 eq '06'";
             oNotifiDataModel.read(pathClrPay, oNotifiContext, [], false, function(data) {
               dModelClrPayNotification.setData(data);

             }, function(err) {
                 console.log("inside failure");
             });


             sap.ui.getCore().byId("idNotifi--idINVNotiGrp").setModel(dModelClrPayNotification);

        },
        notificationCount : function()
        {
          poCount = "5";//sap.ui.getCore().getModel("PoHubCountSetModel").getData().results[0].Count;

            invCount = "2";//sap.ui.getCore().getModel("INVHubCountSetModel").getData().results[5].Count;

            NotificationCount = parseInt(poCount) + parseInt(invCount);
           notificationCountdata = {
                    results:[
                                 {count:""}

                            ]
          };

           var dModelNotCount = new sap.ui.model.json.JSONModel();
           notificationCountdata.results[0]['count'] = NotificationCount;
           dModelNotCount.setData(notificationCountdata);
           sap.ui.getCore().setModel(dModelNotCount,"NotificationModel");
           sap.ui.getCore().byId("idHub").setModel(dModelNotCount, "NotificationModel");
        }
    });
});