var PoNum; 
var NumPO;
var dataLength;
jQuery.sap.require("drlhubpagesfiori.util.Formatter");
sap.ui.define([
"sap/ui/core/mvc/Controller",
"sap/ui/model/Filter"
], function(Controller,Filter) {
"use strict";

return Controller.extend("drlhubpagesfiori.controller.PODetails", {
onInit:function()
{
this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
this._oRouter.attachRoutePatternMatched(this._handleRouteMatched,this); 
},
onBeforeRendering : function()
{
},
_handleRouteMatched: function(oEvent)
{
var oParamaeters = oEvent.getParameter("name");
if(oParamaeters!="PODetailspage")
{
return;
}
PoNum =  oEvent.getParameter("arguments").contextPath; //"0900000158";//
//PoNum =  "0900000158";
console.log(PoNum);
Number = PoNum;
var dModel = new sap.ui.model.json.JSONModel();        
       var oContext = this.getView().getBindingContext();      
       
       
var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_ACKNOWLEDGE_SRV/", true, "", "");
       var path ="POItemSet?$filter=POObjectId eq '"+PoNum+"'";
     
oDataModel.read(path, oContext, [], false, function (data) {
  dataLength = data.results.length;

  dModel.setData(data); 
              
}, function (err) {                       
console.log("inside failure");                       
});      
sap.ui.getCore().setModel(dModel,"POSetModel");
sap.ui.getCore().byId("idPODetails").setModel(dModel,"POSetModel");
sap.ui.getCore().byId("idPODetails--idPODetails").setModel(dModel);

if(dataLength<=0)
  {
    sap.ui.getCore().byId("idPODetails--accept").setEnabled(false);

  }
else
  {
  sap.ui.getCore().byId("idPODetails--accept").setEnabled(true);
  }
  var dModelHeader = new sap.ui.model.json.JSONModel();
var oDataModelHeader = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_ACKNOWLEDGE_SRV/", true, "", "");
var path ="POHeaderSet('"+PoNum+"') ";

oDataModelHeader.read(path, oContext, [], false, function (data) {

  dModelHeader.setData(data);

}, function (err) {
console.log("inside failure");
});

sap.ui.getCore().setModel(dModelHeader,"POHeaderSetModel");
sap.ui.getCore().byId("idPODetails").setModel(dModelHeader,"POHeaderSetModel");


},
acceptPO : function()
{
 sap.ui.getCore().byId("idPODetails").setBusy(true);
     jQuery.sap.delayedCall(5000, this, function() {


var path ="POHeaderSet('"+PoNum+"') ";
 var that = this;     
var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGW_PO_ACKNOWLEDGE_SRV/", true, "", "");
oDataModel.update(path,{ 
PoStat:'I1333',
PoStatTxt :'Confirmed'
},{
success: function()
{
  jQuery.sap.require("sap.m.MessageBox");
  sap.m.MessageBox.show("The Purchase Order is accepted successfully.", {
      icon: sap.m.MessageBox.Icon.SUCCESS,
     
      actions: [sap.m.MessageBox.Action.OK],
      onClose: function(oAction) {
          if (oAction == "OK") {
            var controller = sap.ui.controller("drlhubpagesfiori.controller.HUB");
             controller.onInit();
             that._oRouter = sap.ui.core.UIComponent.getRouterFor(that);
             that._oRouter.navTo("hubpages");
          }
      }.bind(that)
  });

/*sap.m.MessageBox.show("The Data has been Successfully Updated..",
sap.m.MessageBox.Icon.SUCCESS,"SUCCESS"); */
},
error: function(){
alert("failure");
}
} );
sap.ui.getCore().byId("idPODetails").setBusy(false);
     });
 
},


onNavBack: function() {
this._oRouter.navTo("POpage");
},

downloadPODetails : function(oEvent)
{
  window.open("/sap/opu/odata/sap/ZGW_PO_ACKNOWLEDGE_SRV/PDFCollection('"+PoNum+"')/$value/","_blank");
 //this._oRouter.navTo("viewPDFpage",{contextPath:PoNum});
 
}



});

});