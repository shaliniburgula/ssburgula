sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("Tile.controller.View1", {
			 press : function () {
                 sap.m.MessageToast.show("The generic tile is pressed");
        }
	});

});