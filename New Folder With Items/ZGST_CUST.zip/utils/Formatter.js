jQuery.sap.declare("GST_CUST.utils.Formatter");

jQuery.sap.require("sap.ui.core.Element");

GST_CUST.utils.Formatter = {

	streetFormat: function(street1, street2, street3) {

		var street = "";

		if (street1 !== "") {

			street = street1;

			if (street2 !== "") {

				street = street + "," + street2;

			} else if (street3 !== "") {

				street = street + "," + street3;

			}

		} else if (street2 !== "") {

			street = street2;

			if (street3 !== "") {

				street = street + "," + street3;

			}

		} else if (street3 !== "")

		{

			street = street3;

		}

		return street;

	},

	leadingZeros: function(value)

	{

		var formattedVal = parseInt(value);

		return formattedVal;

	},
	billAddrValid: function(street1,street2,street3,city,state,postalCode,CountryTxt){
	    var result = false;
	    var billingAddr = street1+","+street2+","+street3+","+city+","+state+","+postalCode+","+CountryTxt;
	    
	    	var businessAdd = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--BPStreet").getText()+","+sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--BPCity").getText()+","+
			sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--BPState").getText()+","+sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--BPPostalCode").getText()+","+
			sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--BPCountry").getText();
			
		//	var businessAdd = sap.ui.getCore().byId("__component0---gst--BPStreet").getText()+","+sap.ui.getCore().byId("__component0---gst--BPCity").getText()+","+
		//	sap.ui.getCore().byId("__component0---gst--BPState").getText()+","+sap.ui.getCore().byId("__component0---gst--BPPostalCode").getText()+","+
		//	sap.ui.getCore().byId("__component0---gst--BPCountry").getText();
	
	if(businessAdd !== billingAddr){
	    
	    result = true;
	}
	    
	    return true;
	    
	}

};