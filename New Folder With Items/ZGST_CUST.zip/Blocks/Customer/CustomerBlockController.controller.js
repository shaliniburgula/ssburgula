var fileCollectionMat = new Array();

var selectedIndex = "";

jQuery.sap.require("GST_CUST.utils.Formatter");

sap.ui.controller("GST_CUST.Blocks.Customer.CustomerBlockController", {

	onInit: function() {

		fileCollectionMat = new Array();

		selectedIndex = "";

		this.buildUI();

	},

	onExit: function() {},

	buildUI: function() {

		/*this.getView().byId("idMaterialTable").setModel(modelMatJson,"materialModel");*/

		var oUser = sap.ushell.Container.getUser();

		var user = oUser.getId();

		this.userId = user.split('C');
		var statusJson = new sap.ui.model.json.JSONModel();

		var statusmodel = {

			results: [
				{

					"key": "0",

					"Desc": " "

          },
          {

					"key": "DTA",

					"Desc": "DTA"

          },
				{

					"key": "SEZ",

					"Desc": "SEZ"

          },
				{

					"key": "EOU",

					"Desc": "EOU"

          },
				{

					"key": "Tax Exempted",

					"Desc": "Tax Exempted"

          }, {

					"key": "Trader",

					"Desc": "Trader"

          },
          {

					"key": "Not Applicable",

					"Desc": "Not Applicable"

          }

                        ]

		};

		statusJson.setData(statusmodel);

		this.getView().setModel(statusJson, "statusmodel");

		sap.ui.getCore().setModel(statusJson, "statusmodel");
   		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_CUST_SRV/", true, "", "");

		var goodsData = new sap.ui.model.json.JSONModel();

    //	var path = "BillingCustomerSet?$filter=CustomerCode eq '100785'"; 
	
		var path = "BillingCustomerSet?$filter=CustomerCode eq '" + this.userId[1] +"'";
	
		oDataModel.read(path, null, null, false, function(r) {

			goodsData.setData(r);

		});

		this.getView().setModel(goodsData, "goodsModel");

    /*	//business address and billing address validation
		
			var businessAdd = sap.ui.getCore().byId("__component0---gst--BPStreet").getText()+","+sap.ui.getCore().byId("__component0---gst--BPCity").getText()+","+
			sap.ui.getCore().byId("__component0---gst--BPState").getText()+","+sap.ui.getCore().byId("__component0---gst--BPPostalCode").getText()+","+
			sap.ui.getCore().byId("__component0---gst--BPCountry").getText();
			
			var billingAdd = this.getView().byId("BPStreet_B").getText()+","+this.getView().byId("BPCity_B").getText()+","+
			this.getView().byId("BPState_B").getText()+","+this.getView().byId("BPPostalCode_B").getText()+","+
		this.getView().byId("BPCountry_B").getText();
			
			if(businessAdd === billingAdd)
			{
			    this.getView().byId("idGSTNo").setEnabled(false);
			    this.getView().byId("busiAtt").setEnabled(false);
			    
			}
			else
			{
			    this.getView().byId("idGSTNo").setEnabled(true);
			    this.getView().byId("busiAtt").setEnabled(true);
			}
	*/
	},
onBillingAttachment : function()
{   
    	var T = new sap.ui.model.json.JSONModel();

			var dialog = sap.ui.getCore().byId("idDialogUpload");

			if (dialog === undefined) {

				dialog = sap.ui.xmlfragment("GST_CUST.fragments.UploadDocs", this.getView().getController());

				this.getView().addDependent();

			}

			var myjsonVen = new sap.ui.model.json.JSONModel();

			T = sap.ui.getCore().getModel("persModel").getData();

			var mydataVen = {

				"myFiles": []

			};

			myjsonVen.setData(mydataVen);

			if (T.FileName === "") {

			} else {

				sap.ui.getCore().setModel("FileModel", myjsonVen);

				sap.ui.getCore().byId("idFileTable").setModel(myjsonVen);

				sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({

					fileName: T.FileName,

					Updkz: "I"

				});

				sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

			}


			dialog.open();

			dialog.setModel("persModel");

    
},
	onBeforeRendering: function() {},

	onAfterRendering: function() {

		//this.getView().byId("idGoodsTable").setModel("goodsModel")

	},


	onClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogUpload");

		dialog.close();

	},

	handleUploadPress: function(evt) {

		fileCollectionMat = new Array();

		var myjsonMat = new sap.ui.model.json.JSONModel();

		var mydataMat = {

			"myFiles": []

		};

		myjsonMat.setData(mydataMat);

		sap.ui.getCore().setModel("FileModel", myjsonMat);

		sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionMat = new Array();

		}

		var oView = this.getView();

		var oUploader = sap.ui.getCore().byId("fileUploaderMat");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderMat");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

						};

						fileCollectionMat.push(fileData);

						that.setFileAttachments(fileCollectionMat);

						sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

						oFileUploader.setValue("");

						var dialog = sap.ui.getCore().byId("idDialogUpload");

						//var model = sap.ui.getCore().byId("idDialogUpload").getModel("ItemModel");

						var model = that.getView().getModel("persModel");

						var data = persModel.getData();

						data.FileContent_B = base64;

						data.FileContentType_B = contentType;

						data.FileLength_B = "";

						data.FileName_B = filename;

					model.setProperty(data);

						//console.log(model);

						//dialog.close();

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},

	onDeleteFile: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTable-")[1]);

		var items = sap.ui.getCore().byId("idFileTable").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListMat = {};

		var assFileMat = [];

		assFileListMat["myFiles"] = assFileMat;

		var myAssFileModelMat = new sap.ui.model.json.JSONModel();

		myAssFileModelMat.setData(assFileListMat);

		var myNewModelData = myAssFileModelMat.oData.myFiles;

		items = sap.ui.getCore().byId("idFileTable").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var matData = {};

			if (delFlag === "I") {

				matData.fileName = inputValue;

				matData.Updkz = delFlag;

				myNewModelData.push(matData);

			}

		}

		sap.ui.getCore().byId("idFileTable").setModel(myAssFileModelMat);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionMat.length; j++) {

				if (fileCollectionMat[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionMat[j].FileContent,

						FileContentType: fileCollectionMat[j].FileContentType,

						FileLength: fileCollectionMat[j].FileLength,

						FileName: fileCollectionMat[j].FileName,

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionMat = newfileCollection;

		this.setFileAttachments(fileCollectionMat);

		//to remove file from model

		var model = this.getView().getModel("persModel");

		var data = model.getData();

		data.FileContent_B = " ";

		data.FileContentType_B = "";

		data.FileLength_B = "";

		data.FileName_B = "";

		model.setProperty(data);

	},

	onChange: function(e) {

	/*	var sId = parseInt(e.getSource().getId().split("idGoodsTable-")[1]);

		var tableItems = this.getView().byId("idGoodsTable").getItems();

		var plantStatus = tableItems[sId].getAggregation("cells")[3].getSelectedItem().getText();

		this.getView().getModel("goodsModel").setProperty("/results/" + sId + "/PlantStatus", plantStatus);*/

	},

	onChangeStatusDialog: function(e) {

	},

	checkValidInput: function() {

		var r = true;

		if (sap.ui.getCore().byId("idVenDesc").getValue() === "") {

			sap.ui.getCore().byId("idVenDesc").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idVenDesc").setValueStateText("Invalid input");

			this.errorList[this.error] = "idVenDesc";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idVenDesc").setValueState(sap.ui.core.ValueState.None);

		}

		var gstNo = sap.ui.getCore().byId("idGSTNo").getValue();

		var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

		if (!gstNo.match(gst_regExp)) {

			sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.Error);

			this.errorList[this.error] = "idGSTNo";

			this.error++;

			r = false;

		} else if (sap.ui.getCore().byId("idGSTNo").getValue() === "") {

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idGSTNo").setValueStateText("Invalid input");

			this.errorList[this.error] = "idGSTNo";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.None);

		}



		if (sap.ui.getCore().byId("idAddNo").getValue() === "") {

			sap.ui.getCore().byId("idAddNo").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idAddNo").setValueStateText("Invalid input");

			this.errorList[this.error] = "idAddNo";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idAddNo").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt1").getValue() === "") {

			sap.ui.getCore().byId("idSt1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt2").getValue() === "") {

			sap.ui.getCore().byId("idSt2").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt2").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt2";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt2").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt3").getValue() === "") {

			sap.ui.getCore().byId("idSt3").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt3").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt3";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt3").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idPIN").getValue() === "") {

			sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idPIN").setValueStateText("Invalid input");

			this.errorList[this.error] = "idPIN";

			this.error++;

			r = false;

		} else {

			var pincode = sap.ui.getCore().byId("idPIN").getValue(); //content[0].mAggregations.items[1].mProperties.value

			var pin_regExp = /^[0-9]+$/;

			if (!pincode.match(pin_regExp)) {

				sap.m.MessageBox.alert("Please provide correct Postal Code");

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN";

				this.error++;

				r = false;

			} else if (pincode.length > 6) {

				sap.m.MessageBox.alert("Please enter valid Postal Code");

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.None);

			}

		}

		if (sap.ui.getCore().byId("idCity").getValue() === "") {

			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCity").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCity";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idCountry").getValue() === "") {

			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCountry").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCountry";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idState").getValue() === "") {

			sap.ui.getCore().byId("idState").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idState").setValueStateText("Invalid input");

			this.errorList[this.error] = "idState";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idState").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idEmailId").getValue() === "") {

			sap.ui.getCore().byId("idEmailId").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idEmailId").setValueStateText("Invalid input");

			this.errorList[this.error] = "idEmailId";

			this.error++;

			r = false;

		} else {

			var emailValue = sap.ui.getCore().byId("idEmailId").getValue();

			var email_regExp =
				/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5+})?$/i;

			if (!emailValue.match(email_regExp)) {

				sap.m.MessageBox.alert("Please provide Correct Email Address");

				sap.ui.getCore().byId("idEmailId").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idEmailId";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idEmailId").setValueState(sap.ui.core.ValueState.None);

			}

		}

		return r;

	},

	onFileValidation: function() {

		var attchModel = sap.ui.getCore().byId("idFileTableDiaGoods").getModel();

		if (attchModel === undefined || attchModel === "statusmodel") {

			sap.m.MessageBox.alert("Please Upload attachments");

			return false;

		}

		return true;

	},

    onClickBillAddr : function(){
        var dialog = sap.ui.getCore().byId("idDialogBillAddrDetails");

			if (dialog === undefined) {

				dialog = sap.ui.xmlfragment("GST_CUST.fragments.BillAddressesDetails", this.getView().getController());

				this.getView().addDependent(dialog);

			}
            dialog.open();
    },
    	onBillAddrClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogBillAddrDetails");

		dialog.destroy();

	},

	UploadGoodsAttch: function() {

		fileCollectionMat = new Array();

		var myjsonMat = new sap.ui.model.json.JSONModel();

		var mydataMat = {

			"myFilesGoods": []

		};

		myjsonMat.setData(mydataMat);

		sap.ui.getCore().setModel("FileModelGoods", myjsonMat);

		sap.ui.getCore().byId("idFileTableDiaGoods").setModel(myjsonMat);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionMat = new Array();

		}

		var oView = this.getView();

		var oUploader = sap.ui.getCore().byId("fileUploaderGoods");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderGoods");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

						};

						fileCollectionMat.push(fileData);

						that.setFileAttachments(fileCollectionMat);

						sap.ui.getCore().byId("idFileTableDiaGoods").getModel().getData().myFilesGoods.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTableDiaGoods").getModel().refresh(true);

						oFileUploader.setValue("");

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	onDeleteFileGoods: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTableDiaGoods-")[1]);

		var items = sap.ui.getCore().byId("idFileTableDiaGoods").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListMat = {};

		var assFileMat = [];

		assFileListMat["myFilesGoods"] = assFileMat;

		var myAssFileModelMat = new sap.ui.model.json.JSONModel();

		myAssFileModelMat.setData(assFileListMat);

		var myNewModelData = myAssFileModelMat.oData.myFilesGoods;

		items = sap.ui.getCore().byId("idFileTableDiaGoods").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var matData = {};

			if (delFlag === "I") {

				matData.fileName = inputValue;

				matData.Updkz = delFlag;

				myNewModelData.push(matData);

			}

		}

		sap.ui.getCore().byId("idFileTableDiaGoods").setModel(myAssFileModelMat);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionMat.length; j++) {

				if (fileCollectionMat[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionMat[j].FileContent,

						FileContentType: fileCollectionMat[j].FileContentType,

						FileLength: fileCollectionMat[j].FileLength,

						FileName: fileCollectionMat[j].FileName,

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionMat = newfileCollection;

		this.setFileAttachments(fileCollectionMat);

	},

	onValidation: function() {

		var r = false;

		this.errorList = [];

		this.error = 0;

		r = this.checkMandatoryFields(["idVenDesc", "idGSTNo",
        "idSt1", "idSt2", "idSt3", "idPIN", "idCity", "idCountry", "idState"], this);

		if (r) {

			this.errorList = [];

			this.error = 0;

			r = this.checkValidInput();

		}

		return r;

	},

	checkMandatoryFields: function(a, c) {

		var f = null;

		var r = true;

		for (var i = 0; i < a.length; i++) {
             var plant = sap.ui.getCore().byId("idStatusPlant").getSelectedItem().getText();
			f = sap.ui.getCore().byId(a[i]);

			if (f) {

				if (f.getValue() === "" && plant !=="Not Applicable") {

					r = false;

					this.errorList[this.error] = a[i];

					this.error++;

					if (f.setValueState) {

						f.setValueState(sap.ui.core.ValueState.Error);

						f.setValueStateText("Mandatory field");

						r = false

					}

				} else {

					if (f.setValueState) {

						f.setValueState(sap.ui.core.ValueState.None)

					}

				}

			}

		}

		return r;

	},

	checkValidInput: function() {

		var r = true;

		if (sap.ui.getCore().byId("idVenDesc").getValue() === "") {

			sap.ui.getCore().byId("idVenDesc").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idVenDesc").setValueStateText("Invalid input");

			this.errorList[this.error] = "idVenDesc";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idVenDesc").setValueState(sap.ui.core.ValueState.None);

		}
		var gstNo = sap.ui.getCore().byId("idGSTNo").getValue();

		var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

		if (!gstNo.match(gst_regExp)) {

			sap.m.MessageBox.alert("GST Number 1st two digits should be numeric ");

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.Error);

			this.errorList[this.error] = "idGSTNo";

			this.error++;

			r = false;

		} else if (sap.ui.getCore().byId("idGSTNo").getValue() === "") {

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idGSTNo").setValueStateText("Invalid input");

			this.errorList[this.error] = "idGSTNo";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idGSTNo").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt1").getValue() === "") {

			sap.ui.getCore().byId("idSt1").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt1").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt1";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt1").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt2").getValue() === "") {

			sap.ui.getCore().byId("idSt2").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt2").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt2";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt2").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idSt3").getValue() === "") {

			sap.ui.getCore().byId("idSt3").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idSt3").setValueStateText("Invalid input");

			this.errorList[this.error] = "idSt3";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idSt3").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idPIN").getValue() === "") {

			sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idPIN").setValueStateText("Invalid input");

			this.errorList[this.error] = "idPIN";

			this.error++;

			r = false;

		} else {

			var pincode = sap.ui.getCore().byId("idPIN").getValue(); //content[0].mAggregations.items[1].mProperties.value

			var pin_regExp = /^[0-9]+$/;

			if (!pincode.match(pin_regExp)) {

				sap.m.MessageBox.alert("Please provide correct Postal Code");

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN";

				this.error++;

				r = false;

			} else if (pincode.length > 6) {

				sap.m.MessageBox.alert("Please enter valid Postal Code");

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.Error);

				this.errorList[this.error] = "idPIN";

				this.error++;

				r = false;

			} else {

				sap.ui.getCore().byId("idPIN").setValueState(sap.ui.core.ValueState.None);

			}

		}

		if (sap.ui.getCore().byId("idCity").getValue() === "") {

			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCity").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCity";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCity").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idCountry").getValue() === "") {

			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idCountry").setValueStateText("Invalid input");

			this.errorList[this.error] = "idCountry";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idCountry").setValueState(sap.ui.core.ValueState.None);

		}

		if (sap.ui.getCore().byId("idState").getValue() === "") {

			sap.ui.getCore().byId("idState").setValueState(sap.ui.core.ValueState.Error);

			sap.ui.getCore().byId("idState").setValueStateText("Invalid input");

			this.errorList[this.error] = "idState";

			this.error++;

			r = false;

		} else {

			sap.ui.getCore().byId("idState").setValueState(sap.ui.core.ValueState.None);

		}


		return r;

	},

	onFileValidation: function() {

		var attchModel = sap.ui.getCore().byId("idFileTableDiaGoods").getModel();

		if (attchModel === undefined || attchModel === "statusmodel") {

			sap.m.MessageBox.alert("Please Upload attachments");

			return false;

		}

		return true;

	},
		onAddTable: function() {

		var result = this.onValidation();

		if (result) {

			var fileCheck = this.onFileValidation();

		}

		if (fileCheck) {

		//	var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-change-component---gst--Materialblock-Collapsed--idGoodsTable").getModel("goodsModel");

			 var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getModel("goodsModel"); 

			var length = goodsModelItems.oData.results.length + 1;

			var venDes = sap.ui.getCore().byId("idVenDesc").getValue();

			var goodsCode = "" + length;

			var GSTNo = sap.ui.getCore().byId("idGSTNo").getValue();

			var street1 = sap.ui.getCore().byId("idSt1").getValue();

			var street2 = sap.ui.getCore().byId("idSt2").getValue();

			var street3 = sap.ui.getCore().byId("idSt3").getValue();

			var pinCode = sap.ui.getCore().byId("idPIN").getValue();

			var city = sap.ui.getCore().byId("idCity").getValue();

			var country = sap.ui.getCore().byId("idCountry").getValue();

			var state = sap.ui.getCore().byId("idState").getValue();

			var fileContent = fileCollectionMat[0].FileContent;

			var fileContentType = fileCollectionMat[0].FileContentType;

			var fileLength = fileCollectionMat[0].FileLength;

			var fileName = fileCollectionMat[0].FileName;

			this.getView().byId("idGoodsTable").getModel("goodsModel").getData().results.push({

				VendorCode: this.userId[1],

				GoodsSupplierCode: goodsCode,

				GSTNumber: GSTNo,

				CompanyCode: "",

				VendorAccGrp: "",

				PurchasingOrg: "",

				VendorDesc: venDes,

				AddressNo: "",

				Street1: street1,

				Street2: street2,

				Street3: street3,

				PostalCode: pinCode,

				City: city,

				CountryKey: "",

				CountryTxt: country,

				StateCode: "",

				StateTxt: state,

				FileContent: fileContent,

				FileContentType: fileContentType,

				FileLength: fileLength,

				FileName: fileName,

			});

			this.getView().byId("idGoodsTable").getModel("goodsModel").refresh(true);

			var items = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Materialblock-Collapsed--idGoodsTable").getItems();

			for (var k = 0; k < goodsModelItems.oData.results.length; k++) {

				var key = goodsModelItems.oData.results[k].PlantStatus;

				items[k].getAggregation("cells")[3].setSelectedKey(key);

			}

			var dialog = sap.ui.getCore().byId("idDialogBillAddrDetails");

			dialog.destroy();

		}

	},
    
	onAttachment: function(e) {

		var id = e.getSource().getId()

		selectedIndex = parseInt(e.getSource().getId().split("idGoodsTable-")[1]);

		var model = this.getView().byId("idGoodsTable").getModel("goodsModel");

		var sPath = "/results/" + selectedIndex;

		var path = model.getProperty(sPath);

		var T = new sap.ui.model.json.JSONModel(path);

		var dialog = sap.ui.getCore().byId("idDialogUpload");

		if (dialog === undefined) {

			dialog = sap.ui.xmlfragment("GST_CUST.fragments.UploadDocs", this.getView().getController());

			this.getView().addDependent();

		}

		dialog.open();

		dialog.setModel(T, "ItemModel");

		if (T.oData.FileName === "") {

			var myjsonMat = new sap.ui.model.json.JSONModel();

			var mydataMat = {

				"myFiles": []

			};

			myjsonMat.setData(mydataMat);

			sap.ui.getCore().setModel("FileModel", myjsonMat);

			sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

			sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

		} else {

			myjsonMat = new sap.ui.model.json.JSONModel();

			mydataMat = {

				"myFiles": []

			};

			myjsonMat.setData(mydataMat);

			sap.ui.getCore().setModel("FileModel", myjsonMat);

			sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

			sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({

				fileName: T.oData.FileName,

				Updkz: "I"

			});

			sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

		}

	},

	onClose: function() {

		var dialog = sap.ui.getCore().byId("idDialogUpload");

		dialog.close();

	},

	handleUploadPress: function(evt) {

		fileCollectionMat = new Array();

		var myjsonMat = new sap.ui.model.json.JSONModel();

		var mydataMat = {

			"myFiles": []

		};

		myjsonMat.setData(mydataMat);

		sap.ui.getCore().setModel("FileModel", myjsonMat);

		sap.ui.getCore().byId("idFileTable").setModel(myjsonMat);

		var getFileCollection = this.getFileAttachments();

		if (getFileCollection === null) {

			fileCollectionMat = new Array();

		}

		var oView = this.getView();

		var oUploader = sap.ui.getCore().byId("fileUploaderMat");

		var oFileUploader = sap.ui.getCore().byId("fileUploaderMat");

		var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

		if (file === undefined) {

			sap.m.MessageBox.alert("Please Select the File");

		} else {

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename

						};

						fileCollectionMat.push(fileData);

						that.setFileAttachments(fileCollectionMat);

						sap.ui.getCore().byId("idFileTable").getModel().getData().myFiles.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTable").getModel().refresh(true);

						oFileUploader.setValue("");

						var dialog = sap.ui.getCore().byId("idDialogUpload");

						//var model = sap.ui.getCore().byId("idDialogUpload").getModel("ItemModel");

						var model = that.getView().getModel("goodsModel");

						var sPath = "/results/" + selectedIndex;

						var path = model.getProperty(sPath);

						var dataModel = new sap.ui.model.json.JSONModel(path);

						var data = dataModel.getData();

						data.FileContent = base64;

						data.FileContentType = contentType;

						data.FileLength = "";

						data.FileName = filename;

						data.attachmentSet = fileCollectionMat;

						model.setProperty(sPath, data);

						//console.log(model);

						//dialog.close();

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		}

	},

	setFileAttachments: function(files) {

		this.fileAttData = files;

	},

	getFileAttachments: function() {

		return this.fileAttData;

	},

	onDeleteFile: function(e) {

		var selectedRow = parseInt(e.getSource().getId().split("idFileTable-")[1]);

		var items = sap.ui.getCore().byId("idFileTable").getItems();

		items[selectedRow].getAggregation("cells")[2].setValue("D");

		var assFileListMat = {};

		var assFileMat = [];

		assFileListMat["myFiles"] = assFileMat;

		var myAssFileModelMat = new sap.ui.model.json.JSONModel();

		myAssFileModelMat.setData(assFileListMat);

		var myNewModelData = myAssFileModelMat.oData.myFiles;

		items = sap.ui.getCore().byId("idFileTable").getItems();

		for (var i = 0; i < items.length; i++) {

			var inputValue = items[i].getAggregation("cells")[0].getText();

			var delFlag = items[i].getAggregation("cells")[2].getValue();

			var matData = {};

			if (delFlag === "I") {

				matData.fileName = inputValue;

				matData.Updkz = delFlag;

				myNewModelData.push(matData);

			}

		}

		sap.ui.getCore().byId("idFileTable").setModel(myAssFileModelMat);

		var newfileCollection = new Array();

		for (var i = 0; i < myNewModelData.length; i++) {

			for (var j = 0; j < fileCollectionMat.length; j++) {

				if (fileCollectionMat[j].DocOrigin === myNewModelData[i].fileName) {

					var fileData = {

						FileContent: fileCollectionMat[j].FileContent,

						FileContentType: fileCollectionMat[j].FileContentType,

						FileLength: fileCollectionMat[j].FileLength,

						FileName: fileCollectionMat[j].FileName,

					};

					newfileCollection.push(fileData);

				}

			}

		}

		fileCollectionMat = newfileCollection;

		this.setFileAttachments(fileCollectionMat);

		//to remove file from model

		var model = this.getView().getModel("goodsModel");

		var sPath = "/results/" + selectedIndex;

		var path = model.getProperty(sPath);

		var dataModel = new sap.ui.model.json.JSONModel(path);

		var data = dataModel.getData();

		data.FileContent = " ";

		data.FileContentType = "";

		data.FileLength = "";

		data.FileName = "";

		data.attachmentSet = fileCollectionMat;

		model.setProperty(sPath, data);

	},
});