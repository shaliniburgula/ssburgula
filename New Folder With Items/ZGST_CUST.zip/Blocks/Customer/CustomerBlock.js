sap.ui.define(['sap/uxap/BlockBase'], function(BlockBase) {

	"use strict";

	var MaterialBlock = BlockBase.extend("GST_CUST.Blocks.Customer.CustomerBlock", {

		metadata: {

			views: {

				Collapsed: {

					viewName: "GST_CUST.Blocks.Customer.CustomerBlock",

					type: "XML"

				},

				Expanded: {

					viewName: "GST_CUST.Blocks.Customer.CustomerBlock",

					type: "XML"

				}

			}

		}

	});

	return MaterialBlock;

}, true);