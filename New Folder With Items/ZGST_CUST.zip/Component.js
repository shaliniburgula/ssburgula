sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"GST_CUST/model/models"
], function(UIComponent, Device, models) {

	"use strict";

	return UIComponent.extend("GST_CUST.Component", {

		metadata: {

			manifest: "json",

			includes: ["css/style.css"],

		},


		init: function() {

			// call the base component's init function

			UIComponent.prototype.init.apply(this, arguments);

			// set the device model

			this.setModel(models.createDeviceModel(), "device");

			this.getRouter().initialize();

		}

	});

});