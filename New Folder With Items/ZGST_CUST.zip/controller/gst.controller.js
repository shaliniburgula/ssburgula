var fileCollection = new Array();

sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "GST_CUST/utils/Formatter",
    "sap/ca/scfld/md/controller/BaseDetailController",
    "sap/m/MessageBox"
], function(Controller) {

	"use strict";

	return Controller.extend("GST_CUST.controller.gst", {

		onInit: function() {

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			this._oRouter.attachRoutePatternMatched(this._handleRouteMatched, this);

			var fileCollection = new Array();

			var oUser = sap.ushell.Container.getUser();

			var user = oUser.getId();

			this.userId = user.split('C');

			//this.userId = "500285";

			this.busyDialog = new sap.m.BusyDialog();

			var classifJson = new sap.ui.model.json.JSONModel();

			var classifmodel = {

				results: [
					{
						"classifi": "Company",
						"Desc": "Company"
          },
					{
						"classifi": "Partnership",
						"Desc": "Partnership"

          },

					{

						"classifi": "Indivdual",

						"Desc": "Indivdual"

          },

					{

						"classifi": "LLP",

						"Desc": "LLP"

          }



                        ]

			};

			classifJson.setData(classifmodel);

			this.getView().setModel(classifJson, "classifModel");

			var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_CUST_SRV/", true, "", "");

			var persData = new sap.ui.model.json.JSONModel();

			//	var persSet = "CustomerDetailsSet('100785')";

			var persSet = "CustomerDetailsSet('" + this.userId[1] + "')";

			oDataModel.read(persSet, null, null, false, function(r) {

				persData.setData(r);

			});

			sap.ui.getCore().setModel(persData, "persModel");

			this.getView().setModel(persData, "persModel");

		},

		onNavBack: function() {

			this._oRouter.navTo("home");

		},

		_handleRouteMatched: function(oEvent)

		{

			var oParamaeters = oEvent.getParameter("name");

			if (oParamaeters != "gstHome")

			{

				return;

			}

		},

		onAttachment: function() {

			var T = new sap.ui.model.json.JSONModel();

			var dialog = sap.ui.getCore().byId("idDialogVendor");

			if (dialog === undefined) {

				dialog = sap.ui.xmlfragment("GST_CUST.fragments.VendorDocs", this.getView().getController());

				this.getView().addDependent();

			}

			var myjsonVen = new sap.ui.model.json.JSONModel();

			T = sap.ui.getCore().getModel("persModel").getData();

			var mydataVen = {

				"myFiles": []

			};

			myjsonVen.setData(mydataVen);

			if (T.FileName === "") {

			} else {

				sap.ui.getCore().setModel("FileModel", myjsonVen);

				sap.ui.getCore().byId("idFileTableVendor").setModel(myjsonVen);

				sap.ui.getCore().byId("idFileTableVendor").getModel().getData().myFiles.push({

					fileName: T.FileName,

					Updkz: "I"

				});

				sap.ui.getCore().byId("idFileTableVendor").getModel().refresh(true);

			}

			dialog.open();

			dialog.setModel("persModel");

		},

		onAfterRendering: function() {

			var persModel = sap.ui.getCore().getModel("persModel").getData();
			console.log(persModel);

			var registration = persModel.RegistrationCheck;
			if (registration === "Y") {
				this.getView().byId("idRadioGrp").setSelectedIndex(0);
			} else {
				this.getView().byId("idRadioGrp").setSelectedIndex(1);
			}

			var constitution = persModel.BusinessConstitution;

			this.getView().byId("classifVendor").setSelectedKey(constitution);

			var primaryEmail = persModel.PrimaryEmail;
			var secondaryEmail = persModel.SecondaryEmail;
			var primaryPhone = persModel.PrimaryPhone;
			var secondaryPhone = persModel.SecondaryPhone;

			if (primaryPhone !== "") {
				sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").setValue(primaryPhone);
			}
			if (secondaryPhone !== "") {
				sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").setValue(secondaryPhone);
			}
			if (primaryEmail !== "") {
				sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPriMail").setValue(primaryEmail);
			}
			if (secondaryEmail !== "") {

				sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecMail").setValue(secondaryEmail);
			}
			//        var plantStatus = persModel.PlantStatus;
			//      sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--plant").setSelectedKey(plantStatus);

			var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getModel(

				"goodsModel");

			var items = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getItems();

			for (var k = 0; k < goodsModelItems.oData.results.length; k++) {

				var key = goodsModelItems.oData.results[k].PlantStatus;

				items[k].getAggregation("cells")[2].setSelectedKey(key);

			}

		},

		handleTypeMissmatch: function(oEvent) {

			var aFileTypes = oEvent.getSource().getFileType();

			jQuery.each(aFileTypes, function(key, value) {

				aFileTypes[key] = "*." + value

			});

			var sSupportedFileTypes = aFileTypes.join(", ");

			sap.m.MessageBox.error("The file type *." + oEvent.getParameter("fileType") +

				" is not supported. Choose one of the following types: " +

				sSupportedFileTypes);

		},

		handleValueChange: function(oEvent) {

		},

		setFileAttachments: function(files) {

			this.fileAttData = files;

		},

		getFileAttachments: function() {

			return this.fileAttData;

		},

		handleUploadComplete: function(oEvent) {

			var sResponse = oEvent.getParameter("response");

			if (sResponse) {

				var sMsg = "";

				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);

				if (m[1] == "200") {

					sMsg = "Return Code: " + m[1] + "\n" + m[2], "SUCCESS", "Upload Success";

					oEvent.getSource().setValue("");

				} else {

					sMsg = "Return Code: " + m[1] + "\n" + m[2], "ERROR", "Upload Error";

				}

				sap.m.MessageToast.show(sMsg);

			}

		},

		handleUploadPress: function(evt) {

			fileCollection = new Array();

			var myjson = new sap.ui.model.json.JSONModel();

			var mydata = {

				"myFiles": []

			};

			myjson.setData(mydata);

			sap.ui.getCore().setModel("FileModel", myjson);

			sap.ui.getCore().byId("idFileTableVendor").setModel(myjson);

			var getFileCollection = this.getFileAttachments();

			if (getFileCollection === null) {

				fileCollection = new Array();

			}

			var oView = this.getView();

			var oUploader = sap.ui.getCore().byId("vendorUploader");

			var oFileUploader = sap.ui.getCore().byId("vendorUploader");

			var file = jQuery.sap.domById(oUploader.getId() + "-fu").files[0];

			var BASE64_MARKER = 'data:' + file.type + ';base64,';

			var filename = file.name;

			var that = this;

			try {

				var reader = new FileReader();

				// On load set file contents to text view

				reader.onload = (function(theFile) {

					return function(evt) {

						var base64Index = evt.target.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;

						var base64 = evt.target.result.substring(base64Index);

						var docType = "";

						var contentType = "";

						if (file.type === "application/msword") {

							docType = "DOC";

							contentType = ".doc";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {

							docType = "DOC";

							contentType = ".docx";

						} else if (file.type === "image/jpeg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/jpg") {

							docType = "SIM";

							contentType = ".jpg";

						} else if (file.type === "image/gif") {

							docType = "SIM";

							contentType = ".gif";

						} else if (file.type === "application/pdf") {

							docType = "PDF";

							contentType = ".pdf";

						} else if (file.type === "text/plain") {

							docType = "TXT";

							contentType = ".txt";

						} else if (file.type === "image/tiff") {

							docType = "TIF";

							contentType = ".tiff";

						} else if (file.type === "application/xml") {

							docType = "XML";

							contentType = ".xml";

						} else if (file.type === "application/vnd.ms-excel" || file.type ===

							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xls";

						} else if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {

							docType = "XLS";

							contentType = ".xlsx";

						} else if (file.type === "video/mpeg") {

							docType = "MPP";

							contentType = ".m2v";

						} else if (file.type === "video/mp3") {

							docType = "MPP";

							contentType = ".mp3";

						}

						// *****************************

						var fileData = {

							// VendorCode: this.userId[1],

							FileContent: base64,

							FileContentType: contentType,

							FileLength: "",

							FileName: filename,

							StringUpload: ""

						};

						fileCollection.push(fileData);

						that.setFileAttachments(fileCollection);

						sap.ui.getCore().byId("idFileTableVendor").getModel().getData().myFiles.push({

							fileName: filename,

							Updkz: "I"

						});

						sap.ui.getCore().byId("idFileTableVendor").getModel().refresh(true);

						oFileUploader.setValue("");

						var model = that.getView().getModel("persModel");

						var dataModel = new sap.ui.model.json.JSONModel();

						var data = model.getData();

						data.FileContent = base64;

						data.FileContentType = contentType;

						data.FileLength = "";

						data.FileName = filename;

						//data.attachmentSet = fileCollectionMat;

						model.setProperty(data);

					};

				})(file);

				// Read in the file as text

				reader.readAsDataURL(file);

				return;

			} catch (e) {

				sap.m.MessageBox.alert("Error: seems File API is not supported on your browser");

				//do something

				return;

			}

		},

		onDeleteFile: function(e) {

			var selectedRow = parseInt(e.getSource().getId().split("idFileTableVendor-")[1]);

			var items = sap.ui.getCore().byId("idFileTableVendor").getItems();

			items[selectedRow].getAggregation("cells")[2].setValue("D");

			var assFileListMat = {};

			var assFileMat = [];

			assFileListMat["myFiles"] = assFileMat;

			var myAssFileModelMat = new sap.ui.model.json.JSONModel();

			myAssFileModelMat.setData(assFileListMat);

			var myNewModelData = myAssFileModelMat.oData.myFiles;

			items = sap.ui.getCore().byId("idFileTableVendor").getItems();

			for (var i = 0; i < items.length; i++) {

				var inputValue = items[i].getAggregation("cells")[0].getText();

				var delFlag = items[i].getAggregation("cells")[2].getValue();

				var taskData = {};

				if (delFlag === "I") {

					taskData.fileName = inputValue;

					taskData.Updkz = delFlag;

					myNewModelData.push(taskData);

				}

			}

			sap.ui.getCore().byId("idFileTableVendor").setModel(myAssFileModelMat);

			var newfileCollection = new Array();

			for (var i = 0; i < myNewModelData.length; i++) {

				for (var j = 0; j < fileCollection.length; j++) {

					if (fileCollection[j].DocOrigin === myNewModelData[i].fileName) {

						var fileData = {

							FileContent: fileCollection[j].FileContent,

							FileContentType: fileCollection[j].FileContentType,

							FileLength: fileCollection[j].FileLength,

							FileName: fileCollection[j].FileName

						};

						newfileCollection.push(fileData);

					}

				}

			}

			fileCollection = newfileCollection;

			this.setFileAttachments(fileCollection);

			//to remove file from model

			var model = this.getView().getModel("persModel");

			var dataModel = new sap.ui.model.json.JSONModel();

			var data = dataModel.getData();

			model.oData.FileContent = " ";

			model.oData.FileContentType = "";

			model.oData.FileLength = "";

			model.oData.FileName = "";

			model.oData.attachmentSet = fileCollection;

			//model.setProperty(data);

		},

		onClose: function() {

			var dialog = sap.ui.getCore().byId("idDialogVendor");

			dialog.close();

		},

		checkMandatoryFields: function() {

			var result = true;

			var liable = this.getView().byId("idRadioGrp").getSelectedIndex();
			if (liable === 0) {
				var gstNumber = this.getView().byId("GSTNInput").getValue();
				if (gstNumber === "") {
					this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.Error);

					this.getView().byId("GSTNInput").setValueStateText("Mandatory Field");
					result = false;
				} else if (gstNumber !== "")
				{
					var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

					if (!gstNumber.match(gst_regExp)) {

						this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.Error);

						this.getView().byId("GSTNInput").setValueStateText("GST Number should have 1st two digits has numeric");

						result = false;
					} else {
						this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.None);
						var vendorModel = this.getView().getModel("persModel");

						if (vendorModel.oData.FileName === "")

						{

							result = false;

						}

					}
				}

			} else {
				this.getView().byId("GSTNInput").setValueState(sap.ui.core.ValueState.None);
			}

			var goodsTableItems = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getItems();

			if (goodsTableItems.length > 0) {

				for (var i = 0; i < goodsTableItems.length; i++) {
					if (goodsTableItems[i].getAggregation("cells")[3].getEnabled()) {
						if (goodsTableItems[i].getAggregation("cells")[3].getValue() === "" && goodsTableItems[i].getAggregation("cells")[2].getSelectedItem().getText() !== "Not Applicable")

						{

							goodsTableItems[i].getAggregation("cells")[3].setValueState(sap.ui.core.ValueState.Error);

							goodsTableItems[i].getAggregation("cells")[3].setValueStateText("Mandatory Field");

							result = false;

						} else if (goodsTableItems[i].getAggregation("cells")[3].getValue() !== "" && goodsTableItems[i].getAggregation("cells")[2].getSelectedItem().getText() !== "Not Applicable")

						{
							var gst_regExp = /^[0-9]{2}[a-zA-Z]{1}[a-zA-Z0-9]*$/;

							if (!goodsTableItems[i].getAggregation("cells")[3].getValue().match(gst_regExp)) {

								goodsTableItems[i].getAggregation("cells")[3].setValueState(sap.ui.core.ValueState.Error);

								goodsTableItems[i].getAggregation("cells")[3].setValueStateText("GST Number should have 1st two digits has numeric");

								result = false;
							} else {
								goodsTableItems[i].getAggregation("cells")[3].setValueState(sap.ui.core.ValueState.None);
							}
						}

					}
				}
			}
			var goodsModelItems = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getModel(

				"goodsModel");

			if (goodsModelItems.oData.results.length > 0) {

				for (var i = 0; i < goodsModelItems.oData.results; i++) {
					if (goodsTableItems[i].getAggregation("cells")[4].getEnabled()) {
						if (goodsModelItems.oData.results[i].FileName === "")

						{

							result = false;

						}

					}
				}

			}

			if (goodsModelItems.oData.results.length > 0) {

				for (var i = 0; i < goodsModelItems.oData.results; i++) {
					if (goodsTableItems[i].getAggregation("cells")[2].getEnabled()) {
						if (goodsModelItems.oData.results[i].PlantStatus === "") {
							goodsTableItems[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.Error);
							result = false;
						} else {
							goodsTableItems[i].getAggregation("cells")[2].setValueState(sap.ui.core.ValueState.None);
						}
					}
				}

			}

			return result;

		},

		getMobValid: function() {

			var phone_regExp = /^[0-9]+$/;
			/*if (sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").getValue() !== "") {
				if (!sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").getValue().match(
						phone_regExp) && sap.ui.getCore()
					.byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").getValue() !== 10) {

					return false;

				} else if (sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").getValue().length !==
					10) {
					return false;
				}
			}*/
			sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").setValueState(sap.ui.core.ValueState
				.None);
			return true;

		},

		getSecMobValid: function() {

			var phone_regExp = /^[0-9]+$/;
			/*if (sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").getValue() !== "") {
				if (!sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").getValue().match(
					phone_regExp)) {

					return false;

				} else if (sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").getValue().length !==
					10) {
					return false;
				}
			}*/
			sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").setValueState(sap.ui.core
				.ValueState.None);
			return true;

		},

		getPriEmailValid: function() {
			var emailValue = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPriMail").getValue();
			if (emailValue !== "") {
				var email_regExp =
					/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5+})?$/i;

				if (!emailValue.match(email_regExp)) {

					sap.m.MessageBox.alert("Please provide Correct Primary Email Address");

					sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPriMail").setValueState(sap.ui.core
						.ValueState.Error);
					return false;
				}
			}
			sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPriMail").setValueState(sap.ui.core.ValueState
				.None);
			return true;

		},

		getSecEmailValid: function() {
			var emailValue = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecMail").getValue();
			if (emailValue !== "") {
				var email_regExp =
					/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5+})?$/i;

				if (!emailValue.match(email_regExp)) {

					sap.m.MessageBox.alert("Please provide Correct Secondary Email Address");

					sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecMail").setValueState(sap.ui.core
						.ValueState.Error);

					return false;
				}
			}
			sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecMail").setValueState(sap.ui.core.ValueState
				.None);
			return true;
		},

		onSubmit: function() {

			var result = this.checkMandatoryFields();

			if (result) {

				var primaryContact = this.getMobValid();

				if (primaryContact !== true) {

					this.busyDialog.close();

					sap.m.MessageBox.alert("Please provide Correct Primary Contact Number");
					sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").setValueState(sap.ui.core
						.ValueState.Error);
					return

				}

				var secondaryContact = this.getSecMobValid();

				if (secondaryContact !== true) {

					this.busyDialog.close();

					sap.m.MessageBox.alert("Please provide Correct Secondary Contact Number");
					sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").setValueState(sap.ui.core
						.ValueState.Error);
					return

				}

				var primaryEmail = this.getPriEmailValid();

				if (primaryEmail !== true) {

					this.busyDialog.close();

					sap.m.MessageBox.alert("Please provide Correct Email ID");
					sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPriMail").setValueState(sap.ui.core
						.ValueState.Error);
					return

				}
				var secondaryEmail = this.getSecEmailValid();

				if (secondaryEmail !== true) {

					this.busyDialog.close();

					sap.m.MessageBox.alert("Please provide Correct Email ID");
					sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecMail").setValueState(sap.ui.core
						.ValueState.Error);
					return

				}

				this.getView().setBusy(true);

				jQuery.sap.delayedCall(4000, this, function() {

					var dModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGST_CUST_SRV/", true);

					var B = new Array();

					var o = function(D, r) {

						var T = new sap.ui.model.json.JSONModel(D);

						var h = {};

						if (fileCollection.length > 0) {

							h.FileContent = fileCollection[0].FileContent;

							h.FileContentType = fileCollection[0].FileContentType;

							h.FileLength = fileCollection[0].FileLength;

							h.FileName = fileCollection[0].FileName;

						} else {

							h.FileContent = T.oData.FileContent;

							h.FileContentType = T.oData.FileContentType;

							h.FileLength = T.oData.FileLength;

							h.FileName = T.oData.FileName;

						}

						var radioKey = this.getView().byId("idRadioGrp").getSelectedIndex();

						var registration = "";
						if (radioKey === 0) {
							registration = "Y";
						} else {
							registration = "N";
						}

						h.GSTNumber = this.getView().byId("GSTNInput").getValue();

						h.CustomerCode = T.oData.CustomerCode;

						h.Name = T.oData.Name;

						h.AddressNo = T.oData.AddressNo;

						h.Street1 = T.oData.Street1;

						h.Street2 = T.oData.Street2;

						h.Street3 = T.oData.Street3;

						h.PostalCode = T.oData.PostalCode;

						h.City = T.oData.City;

						h.CountryKey = T.oData.CountryKey;

						h.CountryTxt = T.oData.CountryTxt;

						h.StateCode = T.oData.StateCode;

						h.StateTxt = T.oData.StateTxt;

						h.RegistrationCheck = registration;

						h.BusinessConstitution = this.getView().byId("classifVendor").getSelectedItem().getText();

						h.PrimaryPhone = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPContact").getValue();
						h.SecondaryPhone = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecContact").getValue();
						h.PrimaryEmail = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idPriMail").getValue();
						h.SecondaryEmail = sap.ui.getCore().byId("application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idSecMail").getValue();

						B.push(dModel.createBatchOperation("CustomerDetailsSet('" + this.userId[1] + "')", "PUT", h));
						//	B.push(dModel.createBatchOperation("CustomerDetailsSet('100785')", "PUT", h));

						var goodsModelItems = sap.ui.getCore().byId(
							"application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getModel("goodsModel");

						var goodsTableItems = sap.ui.getCore().byId(
							"application-ZGST_IMPL-manage-component---gst--Customerblock-Collapsed--idGoodsTable").getItems();

						for (var i = 0; i < goodsModelItems.oData.results.length; i++) {

							var goodsObj = {};

							goodsObj.CustomerCode = this.userId[1];

							goodsObj.BillCustomer = goodsModelItems.oData.results[i].BillCustomer;

							goodsObj.BillCustomerName = goodsModelItems.oData.results[i].BillCustomerName;

							goodsObj.AddressNo = goodsModelItems.oData.results[i].AddressNo;

							goodsObj.Street1 = goodsModelItems.oData.results[i].Street1;

							goodsObj.Street2 = goodsModelItems.oData.results[i].Street2;

							goodsObj.Street3 = goodsModelItems.oData.results[i].Street3;

							goodsObj.PostalCode = goodsModelItems.oData.results[i].PostalCode;

							goodsObj.City = goodsModelItems.oData.results[i].City;

							goodsObj.CountryKey = goodsModelItems.oData.results[i].CountryKey;

							goodsObj.CountryTxt = goodsModelItems.oData.results[i].CountryTxt;

							goodsObj.StateCode = goodsModelItems.oData.results[i].StateCode;

							goodsObj.StateTxt = goodsModelItems.oData.results[i].StateTxt;

							goodsObj.FileContent = goodsModelItems.oData.results[i].FileContent;

							goodsObj.FileContentType = goodsModelItems.oData.results[i].FileContentType;

							goodsObj.FileLength = goodsModelItems.oData.results[i].FileLength;

							goodsObj.FileName = goodsModelItems.oData.results[i].FileName;

							goodsObj.GSTNumber = goodsTableItems[i].getAggregation("cells")[3].getValue();
							goodsObj.PlantStatus = goodsTableItems[i].getAggregation("cells")[2].getSelectedItem().getText();

				B.push(dModel.createBatchOperation("BillingCustomerSet(CustomerCode='" + this.userId[1] + "',BillCustomer='" + goodsObj.BillCustomer +"')", "PUT", goodsObj));
			//	B.push(dModel.createBatchOperation("BillingCustomerSet(CustomerCode='100785',BillCustomer='" + goodsObj.BillCustomer + "')","PUT", goodsObj));

						}
						dModel.addBatchChangeOperations(B);
						dModel.submitBatch(dModel, jQuery.proxy(this.onRequestSuccess, this), jQuery.proxy(this.onRequestFailed, this));

						this.busyDialog.close()

					};

		dModel.read("CustomerDetailsSet('" + this.userId[1] + "')", null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed,this));

	//	dModel.read("CustomerDetailsSet('100785')", null, null, false, jQuery.proxy(o, this), jQuery.proxy(this.onRequestFailed, this));

					this.getView().setBusy(false);

				});

			} else {

				sap.m.MessageBox.alert("Please enter all the mandatory fields (Attachments and Input fields) ")

			}

		},

		onRequestFailed: function(e) {

			if (e.__batchResponses && e.__batchResponses.length > 0) {

				var j = e.__batchResponses[0].response.body;

				var n = $.parseJSON(j);

				this.result = {};

				this.result.error = n.error.message.value;

				this.busyDialog.close();

				sap.m.MessageBox.error(this.result.error);

			}

		},

		onRequestSuccess: function(e) {

			var that = this;

			if (e.__batchResponses && e.__batchResponses.length > 0) {

				if (Object.keys(e.__batchResponses[0]).indexOf("response") === 1) {

					var j = e.__batchResponses[0].response.body;

					var n = $.parseJSON(j);

					this.result = {};

					this.result.error = n.error.message.value;

					this.busyDialog.close();

					sap.m.MessageBox.error(this.result.error);

				} else {

					sap.m.MessageBox.show("Data saved Successfully", {

						icon: sap.m.MessageBox.Icon.SUCCESS,

						actions: [sap.m.MessageBox.Action.OK],

						onClose: function(oAction) {

							if (oAction == "OK") {

								location.reload(true);

							}

						}.bind(that)

					});

				}

			}

		}

	});

});