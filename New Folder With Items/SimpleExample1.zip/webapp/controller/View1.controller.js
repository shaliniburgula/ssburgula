sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("SimpleExample1.controller.View1", {
        
        onClick: function(){
            var name = this.getView().byId("idName").getValue();
            alert("Welcome to UI5 Advance Training" + name);
        }
	});

});