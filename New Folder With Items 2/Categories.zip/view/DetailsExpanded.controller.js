sap.ui.core.mvc.Controller.extend("Categories.view.DetailsExpanded", {

	onInit: function()
	{
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		if(sap.ui.Device.system.phone) {
			//Do not wait for the master when in mobile phone resolution
			this.oInitialLoadFinishedDeferred.resolve();
		} else {
			this.getView().setBusy(true);
			var oEventBus = this.getEventBus(); 
			oEventBus.subscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
			oEventBus.subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		}

		this.getRouter().attachRouteMatched(this.onRouteMatched, this);
	   /* var view = this.getView();
	    sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function(oEvent){
	        if(oEvent.getParameter("name") === "DetailsExpanded" ){
	            var context = new sap.ui.model.context(view.getModel(),'/'+oEvent.getParameter("arguments").entity);
	            view.setBindingContext(context);
	        }
	    },this);*/
	},
	onRouteMatched : function(oEvent) {
		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function () {
			var oView = this.getView();

			if(oEvent.getParameter("name") === "DetailsExpanded" ){
	            var context = new sap.ui.model.context(oView.getModel(),'/'+oEvent.getParameter("arguments").entity);
	            oView.setBindingContext(context);
	        }
			
		}, this));

	}
});