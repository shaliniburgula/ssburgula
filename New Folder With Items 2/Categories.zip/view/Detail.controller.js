sap.ui.core.mvc.Controller.extend("Categories.view.Detail", {

	onInit : function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		if(sap.ui.Device.system.phone) {
			//Do not wait for the master when in mobile phone resolution
			this.oInitialLoadFinishedDeferred.resolve();
		} else {
			this.getView().setBusy(true);
			var oEventBus = this.getEventBus(); 
			oEventBus.subscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
			oEventBus.subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		}

		this.getRouter().attachRouteMatched(this.onRouteMatched, this);
	},

	onMasterLoaded :  function (sChannel, sEvent) {
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
	},
	
	onMetadataFailed : function(){
		this.getView().setBusy(false);
		this.oInitialLoadFinishedDeferred.resolve();
        this.showEmptyView();	    
	},

	onRouteMatched : function(oEvent) {
		var oParameters = oEvent.getParameters();

		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function () {
			var oView = this.getView();

			// When navigating in the Detail page, update the binding context 
			if (oParameters.name !== "detail") { 
				return;
			}

			var sEntityPath = "/" + oParameters.arguments.entity;
			this.bindView(sEntityPath);

			var oIconTabBar = oView.byId("idIconTabBar");
			oIconTabBar.getItems().forEach(function(oItem) {
			    if(oItem.getKey() !== "selfInfo"){
    				oItem.bindElement(oItem.getKey());
			    }
			});

			// Specify the tab being focused
			var sTabKey = oParameters.arguments.tab;
			this.getEventBus().publish("Detail", "TabChanged", { sTabKey : sTabKey });

			if (oIconTabBar.getSelectedKey() !== sTabKey) {
				oIconTabBar.setSelectedKey(sTabKey);
			}
		}, this));

	},

	bindView : function (sEntityPath) {
		var oView = this.getView();
		oView.bindElement(sEntityPath); 

		//Check if the data is already on the client
		if(!oView.getModel().getData(sEntityPath)) {

			// Check that the entity specified was found.
			oView.getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
				var oData = oView.getModel().getData(sEntityPath);
				if (!oData) {
					this.showEmptyView();
					this.fireDetailNotFound();
				} else {
					this.fireDetailChanged(sEntityPath);
				}
			}, this));

		} else {
			this.fireDetailChanged(sEntityPath);
		}

	},

	showEmptyView : function () {
		this.getRouter().myNavToWithoutHash({ 
			currentView : this.getView(),
			targetViewName : "Categories.view.NotFound",
			targetViewType : "XML"
		});
	},

	fireDetailChanged : function (sEntityPath) {
		this.getEventBus().publish("Detail", "Changed", { sEntityPath : sEntityPath });
	},

	fireDetailNotFound : function () {
		this.getEventBus().publish("Detail", "NotFound");
	},

	onNavBack : function() {
		// This is only relevant when running on phone devices
		this.getRouter().myNavBack("main");
	},

	onDetailSelect : function(oEvent) {
		sap.ui.core.UIComponent.getRouterFor(this).navTo("detail",{
			entity : oEvent.getSource().getBindingContext().getPath().slice(1),
			tab: oEvent.getParameter("selectedKey")
		}, true);
	},

	openActionSheet: function() {

		if (!this._oActionSheet) {
			this._oActionSheet = new sap.m.ActionSheet({
				buttons: new sap.ushell.ui.footerbar.AddBookmarkButton()
			});
			this._oActionSheet.setShowCancelButton(true);
			this._oActionSheet.setPlacement(sap.m.PlacementType.Top);
		}
		
		this._oActionSheet.openBy(this.getView().byId("actionButton"));
	},

	getEventBus : function () {
		return sap.ui.getCore().getEventBus();
	},

	getRouter : function () {
		return sap.ui.core.UIComponent.getRouterFor(this);
	},
	
		CreateCategory: function () {
        var dialog = new sap.m.Dialog({
        title: 'Add Category Details',
    content: [
        new sap.ui.layout.form.SimpleForm({
                              maxWidth : 1024,
                              maxContainerCols: 2,
                              editable: true,
                               layout: "ResponsiveGridLayout",
                      labelSpanL:4,
                      labelSpanM:4,
                      columnsL:2,
                      columnsM:2,
                              content:[
                                 
                                  new sap.m.Label({text : "Category ID", design : "Bold", textAlign : "Begin"}),
                                  new sap.m.Input({value : " ",placeholder :"Enter Category ID ..."}),
                                  new sap.m.Label({text : "Category Name", design : "Bold", textAlign : "Begin"}),
                                  new sap.m.Input({value : " ",placeholder :"Enter Category Name ..."}),
                                  new sap.m.Label({text : "Category Description", design : "Bold", textAlign : "Begin"}),
                                  new sap.m.Input({value : " " ,placeholder :"Enter Category Description ..."} ),
                                  
                                  new sap.m.Button({text : "Add Category Details", type : "Emphasized", press : function() {
                                    var sServiceUrl="proxy/http/services.odata.org/V3/northwind/northwind.svc";

                                     
                                     var path = "/Categories";
                                        var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true, null);
                                        oModel.create(path,{
                                           CategoryID:sap.ui.getCore().byId("catID").getValue(),
                                            CategoryName:sap.ui.getCore().byId("catName").getValue(),
                                            Description:sap.ui.getCore().byId("catDes").getValue()
                                       },{
                                           success: function()
                                            {
                                                       alert("success");
                                                 },
                                                 error: function(){
                                                       alert("failure");
                                                 }
                                            } );
                                      
                                  }})
                                 
                                  ]
                    })
    ],

        beginButton: new sap.m.Button({
        text: 'Close',
        press: function () {
        dialog.close();
        }
        }),
        afterClose: function() {
        dialog.destroy();
        }
        });
        
        //to get access to the global model
        this.getView().addDependent(dialog);
        dialog.open();
},
	ModifyCategory: function () {
        var dialog = new sap.m.Dialog({
        title: 'Modify Category Details',
    content: [
        new sap.ui.layout.form.SimpleForm({
                              maxWidth : 1024,
                              maxContainerCols: 2,
                              editable: true,
                               layout: "ResponsiveGridLayout",
                      labelSpanL:4,
                      labelSpanM:4,
                      columnsL:2,
                      columnsM:2,
                              content:[
                                 
                                  new sap.m.Label({text : "Category ID", design : "Bold", textAlign : "Begin"}),
                                  new sap.m.Input({value : "{CategoryID}", id : "catID"}),
                                  new sap.m.Label({text : "Category Name", design : "Bold", textAlign : "Begin"}),
                                  new sap.m.Input({value : "{CategoryName} " , id : "catName"}),
                                  new sap.m.Label({text : "Category Description", design : "Bold", textAlign : "Begin"}),
                                  new sap.m.Input({value : "{Description}", id : "catDes"}),
                                  
                                  new sap.m.Button({text : "Update", type : "Emphasized", press : function() {
                                    var sServiceUrl="proxy/http/services.odata.org/V3/northwind/northwind.svc";

                                     var categoryid=sap.ui.getCore().byId("catID").getValue();
                                     var path = "/Categories('"+categoryid+"')";
                                        var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true, null);
                                        oModel.update(path,{
                                           
                                            CategoryName:sap.ui.getCore().byId("catName").getValue(),
                                            Description:sap.ui.getCore().byId("catDes").getValue()
                                       },{
                                           success: function()
                                            {
                                                       alert("success");
                                                 },
                                                 error: function(){
                                                       alert("failure");
                                                 }
                                            } );
                                      
                                  }
                                  }),
                                  new sap.m.Button({text : "Delete", type : "Emphasized" , press : function() {
                                    var sServiceUrl="proxy/http/services.odata.org/V3/northwind/northwind.svc";

                                     var categoryid=sap.ui.getCore().byId("catID").getValue();
                                     var path = "/Categories('"+categoryid+"')";
                                        var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true, null);
                                        oModel.remove(path,{
                                           
                                            CategoryName:sap.ui.getCore().byId("catName").getValue(),
                                            Description:sap.ui.getCore().byId("catDes").getValue()
                                       },{
                                           success: function()
                                            {
                                                       alert("success");
                                                 },
                                                 error: function(){
                                                       alert("failure");
                                                 }
                                            } );
                                      
                                  }})
                                  ]
                    })
    ],

        beginButton: new sap.m.Button({
        text: 'Close',
        press: function () {
        dialog.close();
        }
        }),
        afterClose: function() {
        dialog.destroy();
        }
        });
        
        //to get access to the global model
        this.getView().addDependent(dialog);
        dialog.open();
},        
	  
	  	goToExpandDetails :function(oEvent){
	  		
	    var cPath =oEvent.getSource().getBindingContextPath().substr(1);
	   alert(cPath);
	    sap.ui.core.UIComponent.getRouterFor(this).navTo("DetailsExpanded",{from:"Detail",entity:cPath});
	},
	
	onExit : function(oEvent){
	    var oEventBus = this.getEventBus();
    	oEventBus.unsubscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		oEventBus.unsubscribe("Component", "MetadataFailed", this.onMetadataFailed, this);
		if (this._oActionSheet) {
			this._oActionSheet.destroy();
			this._oActionSheet = null;
		}
	},
	expandPanel1 :function(){
		
		if(this.getView().byId("panel1").getExpanded())
			{
			this.getView().byId("panel2").setExpanded(false);
			}
	},
	expandPanel2 :function(){
		if(this.getView().byId("panel2").getExpanded())
			{
			this.getView().byId("panel1").setExpanded(false);
			}
	}
});