// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 Author in the list
// * All 3 Author have at least one books

sap.ui.define([
	"sap/ui/test/Opa5",
	"store_ui/store_ui/test/integration/arrangements/Arrangement","store_ui/store_ui/test/integration/MasterJourney",
	"store_ui/store_ui/test/integration/NavigationJourney",
	"store_ui/store_ui/test/integration/NotFoundJourney",
	"store_ui/store_ui/test/integration/BusyJourney",
	"store_ui/store_ui/test/integration/FLPIntegrationJourney"
], function (Opa5, Arrangement) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Arrangement(),
		viewNamespace: "store_ui.store_ui.view.",
		autoWait: true
	});
});
