sap.ui.define([
	"sap/ui/test/Opa5",
	"store_ui/store_ui/test/integration/arrangements/Arrangement",
	"store_ui/store_ui/test/integration/NavigationJourneyPhone",
	"store_ui/store_ui/test/integration/NotFoundJourneyPhone",
	"store_ui/store_ui/test/integration/BusyJourneyPhone"
], function (Opa5, Arrangement) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Arrangement(),
		viewNamespace: "store_ui.store_ui.view.",
		autoWait: true
	});
});
