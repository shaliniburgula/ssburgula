/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.Configuration");jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");jQuery.sap.require("sap.ca.scfld.md.app.Application");sap.ca.scfld.md.ConfigurationBase.extend("hcm.myteamcalendar.Configuration",{oServiceParams:{serviceList:[{name:"HCM_TEAM_CALENDAR_SRV",serviceUrl:"/sap/opu/odata/SAP/HCM_TEAM_CALENDAR_SRV/",isDefault:true,mockedDataSource:"/hcm.myteamcalendar/model/metadata.xml"}]},getServiceParams:function(){return this.oServiceParams;},getAppConfig:function(){return this.oAppConfig;},getServiceList:function(){return this.oServiceParams.serviceList;}});
