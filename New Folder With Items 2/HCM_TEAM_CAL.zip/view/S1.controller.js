/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("hcm.myteamcalendar.view.ConcurrentEmployment");
sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.myteamcalendar.view.S1", {
	onInit: function() {
		this._tcObject = {
			pernrCalendar: {},
			eventsCalendar: {},
			nonEventsCalendar: {}
		};
		this.calMode = "PEERS";
		this.allEmployeeMode = false;
		this.popover = {};
		this._eventModel = {};
		this.employeeHasTeam = false;
		var c = sap.ui.core.Component.getOwnerIdFor(this.getView());
		hcm.myteamcalendar.view.ConcurrentEmployment.setControllerInstance(this);
		var s = sap.ui.component(c).getComponentData().startupParameters;
		if ((s !== undefined) && (s.context !== undefined)) {
			this.firstDate = new Date(s.context[0]);
		} else {
			this.firstDate = new Date();
			this.firstDate.setHours(0, 0, 0, 0);
			if (this.firstDate.getTimezoneOffset() < 0) {
				this.firstDate.setMinutes((this.firstDate.getTimezoneOffset() * -1));
			}
		}
		this.endDate = new Date();
		this.endDate.setDate(this.endDate.getDate() + 13);
		this.calError = false;
		this.oBusyDialog = new sap.m.BusyDialog();
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.oResourceBundle = this.oApplication.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.oJsonModel = new sap.ui.model.json.JSONModel();
		this.oJsonModel.setSizeLimit(2000);
		if (sap.ui.Device.system.phone) {
			this.endDate.setDate(this.firstDate.getDate() + 6);
			this.byId("loggedInUserCalendar").setWeeksPerRow(1);
			this.byId("empWithEventsCalendar").setWeeksPerRow(1);
			var a = this.byId("overlapCalendarLegend");
			a.setExpanded(false);
		}
		this.byId("FTC_PAGE").fireNavButtonPress = function() {
			window.history.go(-1);
		};
	},
	onAfterRendering: function() {
		var s = this;
		if (!this.oApplication.pernr) {
			hcm.myteamcalendar.view.ConcurrentEmployment.getCEEnablement(this, function() {
				s.initializeView();
			});
		}
	},
	initializeView: function() {
		this.fetchCollection(this, this.fetchFilter(this));
		this._tcObject.pernrCalendar = this.byId("loggedInUserCalendar");
		this._tcObject.eventsCalendar = this.byId("empWithEventsCalendar");
		this._tcObject.eventsPanel = this.byId("eventsPanel");
		this._tcObject.myTeamFilter = this.byId("myTeamFilter");
		if (!this.employeeHasTeam) {
			this._tcObject.myTeamFilter.setVisible(false);
			this.checkReportees(this);
		}
		this._disabledDateSelection(this);
		this._setCalendarStartDate(this, this.firstDate);
	},
	_disabledDateSelection: function(c) {
		c._tcObject.pernrCalendar.getCalendar().ontap = function(e) {
			e.stopPropagation();
			return false;
		};
	},
	fetchFilter: function(c) {
		var s = c.firstDate;
		var e = c.endDate;
		var d = "$filter=StartDate eq datetime'" + s.getFullYear() + "-" + (s.getMonth() + 1) + "-" + s.getDate() + "T00:00:00'";
		d += " and  EndDate eq datetime'" + e.getFullYear() + "-" + (e.getMonth() + 1) + "-" + e.getDate() + "T00:00:00'";
		d += " and EmployeeID eq '" + c.oApplication.pernr + "'";
		if (this.calMode === "PEERS") {
			d += " and AppMode eq 'R'";
		} else {
			d += " and AppMode eq 'T'";
		}
		return d;
	},
	toUTCDate: function(d) {
		return new Date(d.setMinutes(d.getMinutes() + d.getTimezoneOffset()));
	},
	fetchCollection: function(c, f) {
		var s = this;
		this.oBusyDialog.open();
		c.oDataModel.read("EmployeeCollection", null, [f], true, function(d) {
			var u = d.results;
			if (new Date().getTimezoneOffset() > 0) {
				u = [];
				d.results.forEach(function(r) {
					r.StartDate = s.toUTCDate(r.StartDate);
					r.EndDate = s.toUTCDate(r.EndDate);
					u.push(r);
				});
			}
			c.oJsonModel.setData(u);
			c.getView().setModel(c.oJsonModel);
			if (c.allEmployeeMode) {
				c.toggleAllEmployees(true);
			} else {
				c.toggleAllEmployees(false);
			}
			c._assimilateEventModel();
		}, function(e) {
			c.handleTeamCalendarServerError(c, e);
		});
	},
	handleTeamCalendarServerError: function(c, e) {
		c.oBusyDialog.close();
		c._tcObject.eventsCalendar.setVisible(false);
		c.byId("idIconTabBarNoIcons").setVisible(false);
		c.byId("filterFooterButton").setVisible(false);
		c.calError = true;
		var s = {
			message: c.oResourceBundle.getText("SERVICE_ERROR"),
			details: e.response.body,
			type: sap.ca.ui.message.Type.ERROR
		};
		sap.ca.ui.message.showMessageBox(s);
	},
	iconBarSelected: function(e) {
		var c = this;
		var a = e.getParameter("key");
		if (c.calMode !== a) {
			c.calMode = a;
			c.oBusyDialog.open();
			this._eventModel = {};
			c.fetchCollection(c, c.fetchFilter(c));
		}
	},
	toggleAllEmployees: function(f) {
		var c = this;
		if (f) {
			c._tcObject.eventsPanel.setVisible(false);
			c.allEmployeeModelSwitch(true);
		} else {
			c._tcObject.eventsPanel.setVisible(true);
			c.allEmployeeModelSwitch(false);
		}
	},
	allEmployeeModelSwitch: function(f) {
		var t = this;
		t._assimilateEventModel();
		if (f) {
			var e = new sap.me.OverlapCalendarEvent({
				startDay: "{StartDate}",
				endDay: "{EndDate}",
				row: "{RowNumber}",
				type: "{CalendarEventType}",
				typeName: "",
				name: "{Name}"
			});
			t._tcObject.pernrCalendar.bindAggregation("calendarEvents", {
				path: "/",
				template: e
			}).addDelegate({
				onAfterRendering: function() {
					$("#" + t._tcObject.eventsCalendar.getId()).children(":first-child").hide();
					var c = $(".calendarVContainer").children();
					$(c).each(function(i, a) {
						$(a).find(".sapMeOverlapCalendarRow").attr("section", i);
					});
					t._initializeEventBindings(t);
				}
			});
		} else {
			t._attachCalendarAggregation();
		}
		t.oBusyDialog.close();
	},
	checkReportees: function(c) {
		c.calMode = "TEAM";
		c.oDataModel.read("EmployeeCollection", null, c.fetchFilter(c), true, function(d) {
			if ((d.results.length <= 1) || (d.results[0].EmployeeID === d.results[d.results.length - 1].EmployeeID)) {
				c.employeeHasTeam = false;
				c._tcObject.myTeamFilter.setVisible(false);
			} else {
				c.employeeHasTeam = true;
				c._tcObject.myTeamFilter.setVisible(true);
			}
			c.calMode = "PEERS";
		});
	},
	_assimilateEventModel: function() {
		var c = this;
		c._eventModel = {};
		c._eventModel.UNSORTED = {};
		var m = c.oJsonModel.getData();
		if (m.length > 0) {
			for (var i = 0; i < m.length; i++) {
				if (!c._eventModel[m[i].SectionCode]) {
					c._eventModel[m[i].SectionCode] = {};
				}
				if (!c._eventModel[m[i].SectionCode][m[i].RowNumber]) {
					c._eventModel[m[i].SectionCode][m[i].RowNumber] = [];
				}
				c._eventModel[m[i].SectionCode][m[i].RowNumber].push(m[i]);
				if (!c._eventModel.UNSORTED[m[i].RowNumber]) {
					c._eventModel.UNSORTED[m[i].RowNumber] = [];
				}
				c._eventModel.UNSORTED[m[i].RowNumber].push(m[i]);
			}
		}
		$._eventModel = c._eventModel;
		c.updateCalendarSections();
	},
	updateCalendarSections: function() {
		var e = this.byId("eventsPanel");
		var u = Object.keys(this._eventModel.UNSORTED).length;
		if (this._eventModel[1]) {
			var s = Object.keys(this._eventModel[1]);
			e.setHeaderText(this.oResourceBundle.getText("TEAMMEMBERS_WITH_EVENTS") + " (" + s.length + " " + this.oResourceBundle.getText("OUT_OF") +
				" " + (u - 1) + ")");
		} else {
			e.setHeaderText(this.oResourceBundle.getText("TEAMMEMBERS_WITH_EVENTS") + " (0)");
		}
	},
	_attachCalendarAggregation: function() {
		var c = this;
		var C = this.byId("overlapCalendarLegend");
		var e = new sap.me.OverlapCalendarEvent({
			startDay: "{StartDate}",
			endDay: "{EndDate}",
			row: "{RowNumber}",
			type: "{CalendarEventType}",
			typeName: "",
			name: "{Name}"
		});
		var l = new sap.ui.model.Filter("SectionCode", sap.ui.model.FilterOperator.EQ, "0");
		var E = new sap.ui.model.Filter("SectionCode", sap.ui.model.FilterOperator.EQ, "1");
		var s = new sap.ui.model.Sorter("Name", false);
		this._tcObject.pernrCalendar.bindAggregation("calendarEvents", {
			path: "/",
			template: e,
			filters: [l]
		}).addDelegate({
			onAfterRendering: function() {
				$("#" + c._tcObject.eventsCalendar.getId()).children(":first-child").hide();
				var o = $(".calendarVContainer").children();
				$(o).each(function(i, a) {
					$(a).find(".sapMeOverlapCalendarRow").attr("section", i);
				});
				c._initializeEventBindings(c);
			}
		});
		this._tcObject.eventsCalendar.bindAggregation("calendarEvents", {
			path: "/",
			template: e,
			filters: [E],
			sorter: [s]
		}).addDelegate({
			onAfterRendering: function() {
				$("#" + c._tcObject.eventsCalendar.getId()).children(":first-child").hide();
				var o = $(".calendarVContainer").children();
				$(o).each(function(i, a) {
					$(a).find(".sapMeOverlapCalendarRow").attr("section", i);
				});
				c._initializeEventBindings(c);
			}
		});
		if (C) {
			C.setLegendForNormal(this.oResourceBundle.getText("LEGEND_NR"));
			C.setLegendForType00(this.oResourceBundle.getText("LEGEND_00"));
			C.setLegendForType01(this.oResourceBundle.getText("LEGEND_01"));
			C.setLegendForType04(this.oResourceBundle.getText("LEGEND_04"));
			C.setLegendForType06(this.oResourceBundle.getText("LEGEND_06"));
			C.setLegendForType07(this.oResourceBundle.getText("LEGEND_07"));
			C.setLegendForToday(this.oResourceBundle.getText("LEGEND_TD"));
		}
	},
	getPopover: function(e, c) {
		var a = new sap.ui.layout.VerticalLayout();
		a.addStyleClass("popoverVLayout");
		if (e.length > 0) {
			for (var j = 0; j < e.length; j++) {
				a.addContent(new sap.m.Label({
					text: e[j].CalendarEventDescription
				}).addStyleClass("popoverLabel"));
			}
		}
		var p = new sap.m.ResponsivePopover({
			placement: sap.m.PlacementType.Auto,
			title: e[0].Name,
			contentWidth: "auto",
			contentHeight: "150px",
			content: [a],
			afterClose: function() {
				c.popupInstanceCount = 0;
				c.popover = {};
			}
		});
		return p;
	},
	_initializeEventBindings: function(c) {
		c.popupInstanceCount = 0;
		$(".sapMeOverlapCalendarRowLabels").css("width", "auto");
		$(".sapMeOverlapCalendarDay").on("click", function(e) {
			if (c.popupInstanceCount === 0) {
				var s = $("#" + e.target.id).parent().attr("section");
				var t = e.target.id.split("-");
				var r = t[t.length - 2];
				var a = t[t.length - 1];
				var b = new Date(c.firstDate.getTime());
				b.setDate(b.getDate() + parseInt(a, 10));
				b.setHours(0, 0, 0, 0);
				if (b.getTimezoneOffset() > 0) {
					b = c.toUTCDate(b);
				}
				var d = {};
				if (!s || c.allEmployeeMode === true) {
					d = $._eventModel.UNSORTED[r];
				} else {
					d = $._eventModel[s][r];
				}
				var f = [];
				for (var i = 0; i < d.length; i++) {
					if (d[i].CalendarEventType !== "00") {
						if (d[i].StartDate.toDateString() === b.toDateString()) {
							f.push(d[i]);
						} else if (d[i].StartDate.getTime() <= b.getTime() && d[i].EndDate.getTime() >= b.getTime()) {
							f.push(d[i]);
						}
					}
				}
				if (f.length > 0) {
					c.popover = c.getPopover(f, c);
					if (c.popover) {
						c.popupInstanceCount++;
						c.popover.openBy(e.target);
					}
				}
			}
		});
	},
	_changeDatesForCalendars: function(e) {
		var c = this;
		if (!c.calError) {
			c.firstDate = this._getJSDate(e.getParameter("firstDate"));
			c.firstDate.setHours(0, 0, 0, 0);
			if (c.firstDate.getTimezoneOffset() < 0) {
				c.firstDate.setMinutes((c.firstDate.getTimezoneOffset() * -1));
			}
			c.endDate = this._getJSDate(e.getParameter("endDate"));
			this.oBusyDialog.open();
			this._eventModel = {};
			this._setCalendarStartDate(c, c.firstDate);
			c.fetchCollection(c, c.fetchFilter(c));
		}
	},
	_getJSDate: function(d) {
		var D = d;
		if (d instanceof sap.ui.core.date.UniversalDate) {
			D = new Date(d.getTime());
		}
		return D;
	},
	_setCalendarStartDate: function(c, s) {
		c._tcObject.pernrCalendar.setStartDate(s);
		c._tcObject.eventsCalendar.setStartDate(s);
	},
	openCalendarFilter: function(e) {
		var c = this;
		var a = e.getSource();
		var f = new sap.m.ActionSheet({
			placement: sap.m.PlacementType.Top,
			buttons: [new sap.m.ToggleButton({
				pressed: c.allEmployeeMode ? false : true,
				text: c.oResourceBundle.getText("FILTER_BY_EMPLOYEE"),
				press: function() {
					c.allEmployeeMode = false;
					c.toggleAllEmployees(false);
				}
			}).addStyleClass("BTN_FLTR_EMP"), new sap.m.ToggleButton({
				pressed: c.allEmployeeMode ? true : false,
				text: c.oResourceBundle.getText("ALL_EMPLOYEES"),
				press: function() {
					c.allEmployeeMode = true;
					c.toggleAllEmployees(true);
				}
			}).addStyleClass("BTN_ALL_EMP")]
		});
		f.openBy(a);
	},
	getHeaderFooterOptions: function() {
		var _ = this;
		var o = {
			oEditBtn: {
				sId: "filterFooterButton",
				sIcon: "sap-icon://filter",
				onBtnPressed: function(e) {
					_.openCalendarFilter(e);
				}
			}
		};
		var h = new sap.ui.core.routing.HashChanger();
		var u = h.getHash();
		if (u.indexOf("Shell-runStandaloneApp") >= 0) {
			o.bSuppressBookmarkButton = true;
		}
		if (this.extHookChangeFooterButtons) {
			o = this.extHookChangeFooterButtons(o);
		}
		return o;
	},
	_invalidateCalendar: function() {
		if (this._tcObject) {
			this._tcObject.eventsCalendar.invalidate();
		}
	}
});