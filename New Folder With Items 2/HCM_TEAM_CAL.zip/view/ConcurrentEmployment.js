/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.view.ConcurrentEmployment");
hcm.myteamcalendar.view.ConcurrentEmployment = {
	getPersonellAssignments: function(a, s) {
		var b = this;
		a.oDataModel.read("/ConcurrentEmploymentSet", null, [], true, function(d) {
			s(d.results);
		}, function(e) {
			b.processError(e);
		});
	},
	processError: function(E) {
		var t = this;
		var m = "";
		var a = "";
		if (E.response) {
			var b = E.response.body;
			try {
				b = JSON.parse(b);
				if (b.error.innererror && b.error.innererror.errordetails) {
					var c = b.error.innererror.errordetails;
					for (var i = 0; i < c.length; i++) {
						a += c[i].code + " : " + c[i].message + "\n";
					}
				}
				if (a === "") {
					a = b.error.code + " : " + b.error.message.value;
				}
				m = b.error.message.value;
			} catch (e) {
				jQuery.sap.log.warning("Could parse the response", ["parseError"], ["hcm.myteamcalendar"]);
			}
		}
		if (m === "") {
			m = t.oResourceBundle.getText("INTERNAL_ERROR");
		}
		if (a === "") {
			a = t.oResourceBundle.getText("INTERNAL_ERROR_BODY");
		}
		var M = {
			message: m,
			details: a,
			type: sap.ca.ui.message.Type.ERROR
		};
		sap.ca.ui.utils.busydialog.releaseBusyDialog();
		sap.ca.ui.message.showMessageBox({
			type: M.type,
			message: M.message,
			details: M.details
		});
	},
	getCEEnablement: function(s, a) {
		this.initialize(s, a);
		var m = new sap.ui.model.json.JSONModel();
		this.getPersonellAssignments(s, function(d) {
			if (d.length > 1) {
				m.setData(d);
				s.oCEForm.setModel(m);
				s.oCEDialog.open();
			} else {
				s.oApplication.pernr = d[0].Pernr;
				a();
			}
		});
	},
	initialize: function(s, a) {
		var i = new sap.m.RadioButton({
			text: "{AssignmentText}",
			customData: new sap.ui.core.CustomData({
				"key": "Pernr",
				"value": "{Pernr}"
			})
		});
		s.oCESelect = new sap.m.RadioButtonGroup().bindAggregation("buttons", "/", i);
		s.oCEForm = new sap.ui.layout.form.Form({
			layout: new sap.ui.layout.form.ResponsiveGridLayout({
				labelSpanL: 12,
				labelSpanM: 12,
				labelSpanS: 12,
				columnsL: 2,
				columnsM: 2
			}),
			formContainers: new sap.ui.layout.form.FormContainer({
				formElements: [new sap.ui.layout.form.FormElement({
					label: new sap.m.Label({
						text: s.oResourceBundle.getText("PERSONAL_ASSIGN")
					}),
					fields: s.oCESelect
				})]
			})
		});
		s.oCEDialog = new sap.m.Dialog({
			title: s.oResourceBundle.getText("PERSONAL_ASSIGN_TITLE"),
			content: s.oCEForm,
			buttons: [new sap.m.Button({
				text: s.oResourceBundle.getText("DIALOG_OK"),
				press: function() {
					s.oCEDialog.close();
					s.oCEDialog.Cancelled = false;
					s.oApplication.pernr = s.oCESelect.getSelectedButton().data().Pernr;
					a();
				}
			}), new sap.m.Button({
				text: s.oResourceBundle.getText("CANCEL"),
				press: function() {
					s.oCEDialog.close();
					s.oCEDialog.Cancelled = true;
					window.history.go(-1);
				}
			})]
		});
		s.oCEDialog.attachAfterClose(function() {
			if (!s.oApplication.pernr && !s.oCEDialog.Cancelled) {
				s.oCEDialog.open();
			}
		});
	},
	setControllerInstance: function(c) {
		this.cntrlInstance = c;
	},
	getControllerInstance: function() {
		return this.cntrlInstance;
	}
};