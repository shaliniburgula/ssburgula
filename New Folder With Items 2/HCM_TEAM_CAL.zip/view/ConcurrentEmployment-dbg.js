/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.view.ConcurrentEmployment");
/*global hcm:true */
hcm.myteamcalendar.view.ConcurrentEmployment = {
	getPersonellAssignments: function(appController, fSuccess) {
		var self = this;
		appController.oDataModel.read(
			"/ConcurrentEmploymentSet",
			null, [],
			true,
			function(oData) {
				fSuccess(oData.results);
			},
			function(oError) {
				self.processError(oError);
			});
	},
	processError: function(oError) {
		var that = this;
		var message = "";
		var messageDetails = "";
		if (oError.response) {
			var body = oError.response.body;
			try {
				body = JSON.parse(body);
				if (body.error.innererror && body.error.innererror.errordetails) {

					var errors = body.error.innererror.errordetails;
					for (var i = 0; i < errors.length; i++) {
						messageDetails += errors[i].code + " : " + errors[i].message + "\n";
					}
				}
				if (messageDetails === "") {
					messageDetails = body.error.code + " : " + body.error.message.value;
				}
				message = body.error.message.value;
			} catch (e) {
				jQuery.sap.log.warning("Could parse the response", ["parseError"], ["hcm.myteamcalendar"]);
			}
		}
		if (message === "") {
			message = that.oResourceBundle.getText("INTERNAL_ERROR");
		}
		if (messageDetails === "") {
			messageDetails = that.oResourceBundle.getText("INTERNAL_ERROR_BODY");
		}
		var oMessage = {
			message: message,
			details: messageDetails,
			type: sap.ca.ui.message.Type.ERROR
		};
		//release busy dialog
		sap.ca.ui.utils.busydialog.releaseBusyDialog();

		sap.ca.ui.message.showMessageBox({
			type: oMessage.type,
			message: oMessage.message,
			details: oMessage.details
		});
	},

	getCEEnablement: function(self, successHandler) {
		this.initialize(self, successHandler);
		var oModel = new sap.ui.model.json.JSONModel();
		this.getPersonellAssignments(self, function(data) {
			if (data.length > 1) {
				oModel.setData(data);
				self.oCEForm.setModel(oModel);
				self.oCEDialog.open();
			} else {
				self.oApplication.pernr = data[0].Pernr;
				successHandler();
			}
		});
	},
	initialize: function(self, successHandler) {
		var itemTemplate = new sap.m.RadioButton({
			text: "{AssignmentText}",
			customData: new sap.ui.core.CustomData({
				"key": "Pernr",
				"value": "{Pernr}"
			})
		});
		self.oCESelect = new sap.m.RadioButtonGroup().bindAggregation("buttons", "/", itemTemplate);
		self.oCEForm = new sap.ui.layout.form.Form({
			layout: new sap.ui.layout.form.ResponsiveGridLayout({
				labelSpanL: 12,
				//emptySpanL: 0,
				labelSpanM: 12,
				//emptySpanM: 2,
				labelSpanS: 12,
				columnsL: 2,
				columnsM: 2
			}),
			formContainers: new sap.ui.layout.form.FormContainer({
				formElements: [
					new sap.ui.layout.form.FormElement({
						label: new sap.m.Label({
							text: self.oResourceBundle.getText("PERSONAL_ASSIGN")
						}),
						fields: self.oCESelect
					})
				]
			})
		});
		self.oCEDialog = new sap.m.Dialog({
			title: self.oResourceBundle.getText("PERSONAL_ASSIGN_TITLE"),
			content: self.oCEForm,
			buttons: [
				new sap.m.Button({
					text: self.oResourceBundle.getText("DIALOG_OK"),
					press: function() {
						self.oCEDialog.close();
						self.oCEDialog.Cancelled = false;
						self.oApplication.pernr = self.oCESelect.getSelectedButton().data().Pernr;
						successHandler();
					}
				}),
				new sap.m.Button({
					text: self.oResourceBundle.getText("CANCEL"),
					press: function() {
						self.oCEDialog.close();
						self.oCEDialog.Cancelled = true;
						window.history.go(-1);
						/* eslint-enable sap-browser-api-warning */
						//}
					}
				})
			]
		});
		self.oCEDialog.attachAfterClose(function() {
			if (!self.oApplication.pernr && !self.oCEDialog.Cancelled) {
				self.oCEDialog.open();
			}
		});
	},
	setControllerInstance: function(cntrlInstance) {
		this.cntrlInstance = cntrlInstance;
	},
	getControllerInstance: function() {
		return this.cntrlInstance;
	}
};