/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("hcm.myteamcalendar.view.ConcurrentEmployment");
/*global hcm:true */
sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.myteamcalendar.view.S1", {
	onInit: function() {
		/* Initializations */
		this._tcObject = {
			pernrCalendar: {},
			eventsCalendar: {},
			nonEventsCalendar: {}
		};
		//Calendar Defaults
		this.calMode = "PEERS"; // "PEERS" mode is the default calendar mode at launch. The other value is "TEAM" mode (Chosen from nav bar)
		this.allEmployeeMode = false; //The "Filtered Employee Mode" is set to default and "All Employee Mode" would be false
		this.popover = {}; //To maintain one instance to prevent multiple instances be opened on click of any cell

		this._eventModel = {}; // Take in the incoming model and segregate Section Codes and Row numbers for Event handling, and quickview
		this.employeeHasTeam = false; //The check for logged-in employee, if he is a manager and has a team
		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
		hcm.myteamcalendar.view.ConcurrentEmployment.setControllerInstance(this);
		var oStartupParameters = sap.ui.component(sComponentId).getComponentData().startupParameters;
		if ((oStartupParameters !== undefined) && (oStartupParameters.context !== undefined)) {
			this.firstDate = new Date(oStartupParameters.context[0]);
		} else {
			this.firstDate = new Date();
			this.firstDate.setHours(0, 0, 0, 0);  //MELN2281084
			if (this.firstDate.getTimezoneOffset() < 0) { 
				//in case user is ahead of GMT (e.g. GMT+1) the timezone offset gets added				
				this.firstDate.setMinutes((this.firstDate.getTimezoneOffset() * -1));
			}
		}
		this.endDate = new Date();
		this.endDate.setDate(this.endDate.getDate() + 13); //End date to be separated from Start Date by 14 days. 14th day is the end date.
		this.calError = false; //Error flag to be monitored across application.

		this.oBusyDialog = new sap.m.BusyDialog();

		/* Models */
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.oResourceBundle = this.oApplication.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.oJsonModel = new sap.ui.model.json.JSONModel();
		/* Set calendar rows to single week for mobile device */
		this.oJsonModel.setSizeLimit(2000);
		if (sap.ui.Device.system.phone) {
			this.endDate.setDate(this.firstDate.getDate() + 6);
			this.byId("loggedInUserCalendar").setWeeksPerRow(1);
			this.byId("empWithEventsCalendar").setWeeksPerRow(1);
			var a = this.byId("overlapCalendarLegend");
			a.setExpanded(false);
		}
		/* Code for Back Button */
		this.byId("FTC_PAGE").fireNavButtonPress = function() {
			window.history.go(-1);
		};
	},

	onAfterRendering: function() {
		var self = this;
		if (!this.oApplication.pernr) {
			hcm.myteamcalendar.view.ConcurrentEmployment.getCEEnablement(this, function() {
				self.initializeView();
			});
		}
	},

	initializeView: function() {
		//Initial Service call with "Peers" selection and "Filter Employee" and current date as default for two weeks
		this.fetchCollection(this, this.fetchFilter(this));
		this._tcObject.pernrCalendar = this.byId("loggedInUserCalendar");
		this._tcObject.eventsCalendar = this.byId("empWithEventsCalendar");

		this._tcObject.eventsPanel = this.byId("eventsPanel");

		/* Check if the logged in employee has reportees - Only on first load */
		this._tcObject.myTeamFilter = this.byId("myTeamFilter");
		if (!this.employeeHasTeam) {
			this._tcObject.myTeamFilter.setVisible(false);
			this.checkReportees(this);
		}
		this._disabledDateSelection(this); //Prevent Calendar date click. Only on the first calendar
		
		/* Date change for the calendars. Current date is set as starting date */
		this._setCalendarStartDate(this, this.firstDate);
	},

	/**
	 * Prevents calendar's date selection
	 * @params controller
	 */
	_disabledDateSelection: function(controller) {
		controller._tcObject.pernrCalendar.getCalendar().ontap = function(event) {
			event.stopPropagation();
			return false;
		};
	},

	/** 
	 * Prepares the filter before service call. All required parameters would be available from the controller object
	 */
	fetchFilter: function(controller) {
		var startDate = controller.firstDate;
		var endDate = controller.endDate;
		
		var dateFilter = "$filter=StartDate eq datetime'" + startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" + startDate.getDate() +
			"T00:00:00'";
		dateFilter += " and  EndDate eq datetime'" + endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" +
			endDate.getDate() + "T00:00:00'";
		dateFilter += " and EmployeeID eq '" + controller.oApplication.pernr + "'";
		
		if (this.calMode === "PEERS") {
			dateFilter += " and AppMode eq 'R'";
		} else {
			dateFilter += " and AppMode eq 'T'";
		}
		return dateFilter;
	},
	/** 
	 * convert local time to UTC time (add timezone offset)
	 */
	toUTCDate: function(date) {
		return new Date(date.setMinutes(date.getMinutes() + date.getTimezoneOffset()));
	},
	/** 
	 * read all employee events from backend for the displayed timespan
	 */
	fetchCollection: function(controller, filter) {
		var self = this;
		this.oBusyDialog.open();
		controller.oDataModel.read("EmployeeCollection", null, [filter], true, function(data) {
			var utcResults = data.results;
			if (new Date().getTimezoneOffset() > 0) {  //MELN2281084
				//if user is behind GMT (e.g. GMT-3) we convert the dates to UTC
				utcResults = [];
				data.results.forEach(function(result) {
					result.StartDate = self.toUTCDate(result.StartDate);
					result.EndDate = self.toUTCDate(result.EndDate);
					utcResults.push(result);
				});
			}
			controller.oJsonModel.setData(utcResults);
			controller.getView().setModel(controller.oJsonModel);
			if (controller.allEmployeeMode) {
				controller.toggleAllEmployees(true);
			} else {
				controller.toggleAllEmployees(false);
			}
			controller._assimilateEventModel();

		}, function(error) {
			controller.handleTeamCalendarServerError(controller, error);
		});
	},

	/*
        Stops all navigations and operations when encountered with server error
    */
	handleTeamCalendarServerError: function(controller, error) {
		controller.oBusyDialog.close();
		controller._tcObject.eventsCalendar.setVisible(false);
		controller.byId("idIconTabBarNoIcons").setVisible(false);
		controller.byId("filterFooterButton").setVisible(false);
		controller.calError = true;
		var oSettings = {
			message: controller.oResourceBundle.getText("SERVICE_ERROR"),
			details: error.response.body,
			type: sap.ca.ui.message.Type.ERROR
		};
		sap.ca.ui.message.showMessageBox(oSettings);
	},

	/*
        Switches between Peer/Reports view on the navigation bar
    */
	iconBarSelected: function(event) {
		var controller = this;
		var eventKey = event.getParameter("key");
		if (controller.calMode !== eventKey) {
			controller.calMode = eventKey;
			controller.oBusyDialog.open();
			this._eventModel = {};
			controller.fetchCollection(controller, controller.fetchFilter(controller));
		}
	},

	/* 
        Toggles between the "Show All Employees" view and the filtered view
        If the flag is true, then the "Show All Employees" view will be turned on
    */
	toggleAllEmployees: function(flag) {
		var controller = this;
		if (flag) {
			controller._tcObject.eventsPanel.setVisible(false);
			controller.allEmployeeModelSwitch(true);
		} else {
			controller._tcObject.eventsPanel.setVisible(true);
			controller.allEmployeeModelSwitch(false);
		}
	},

	allEmployeeModelSwitch: function(flag) {
		var that = this;
		that._assimilateEventModel();
		if (flag) {
			var eventTemplate = new sap.me.OverlapCalendarEvent({
				startDay: "{StartDate}",
				endDay: "{EndDate}",
				row: "{RowNumber}",
				type: "{CalendarEventType}",
				typeName: "",
				name: "{Name}"
			});
			that._tcObject.pernrCalendar.bindAggregation("calendarEvents", {
				path: "/",
				template: eventTemplate
			}).addDelegate({
				onAfterRendering: function() {
					$("#" + that._tcObject.eventsCalendar.getId()).children(":first-child").hide();
					var oCalendarElements = $(".calendarVContainer").children();
					$(oCalendarElements).each(function(index, element) {
						$(element).find(".sapMeOverlapCalendarRow").attr("section", index);
					});
					that._initializeEventBindings(that); 
				}
			});
		} else {
			that._attachCalendarAggregation();
		}

		that.oBusyDialog.close();
	},

	/**
	 * Will be called only a on fresh start of Team Calendar and immediately after the "Peer" service call.
	 * Checks if the logged-in employee has a team under him. So, the service will be called with app mode of "T"
	 * If the resulting employee count is less 1 (the logged-in employee is included in the result),
	 * then "Team" tab will be disabled
	 */
	checkReportees: function(controller) {
		controller.calMode = "TEAM";
		controller.oDataModel.read("EmployeeCollection", null, controller.fetchFilter(controller), true, function(data) {
			if ((data.results.length <= 1) ||
				(data.results[0].EmployeeID === data.results[data.results.length - 1].EmployeeID)) {
				controller.employeeHasTeam = false;
				controller._tcObject.myTeamFilter.setVisible(false);
			} else {
				controller.employeeHasTeam = true;
				controller._tcObject.myTeamFilter.setVisible(true);
			}
			controller.calMode = "PEERS"; //Reset the calMode back to Peers.
		});
	},

	/**
	 * Loads up the  _eventModel with event information from the incoming model.
	 * Information from this object would be used for Event Popup
	 */
	_assimilateEventModel: function() {
		var controller = this;
		controller._eventModel = {};
		controller._eventModel.UNSORTED = {};

		var oModelData = controller.oJsonModel.getData();
		if (oModelData.length > 0) {
			for (var i = 0; i < oModelData.length; i++) {
				if (!controller._eventModel[oModelData[i].SectionCode]) {
					controller._eventModel[oModelData[i].SectionCode] = {};
				}
				if (!controller._eventModel[oModelData[i].SectionCode][oModelData[i].RowNumber]) {
					controller._eventModel[oModelData[i].SectionCode][oModelData[i].RowNumber] = [];
				}
				controller._eventModel[oModelData[i].SectionCode][oModelData[i].RowNumber].push(oModelData[i]);

				if (!controller._eventModel.UNSORTED[oModelData[i].RowNumber]) {
					controller._eventModel.UNSORTED[oModelData[i].RowNumber] = [];
				}
				controller._eventModel.UNSORTED[oModelData[i].RowNumber].push(oModelData[i]);
			}
		}
		$._eventModel = controller._eventModel;
		controller.updateCalendarSections();
	},

	/*
        Updates the panel header text for Events Calendar
    */
	updateCalendarSections: function() {
		var eventsPanel = this.byId("eventsPanel");
		var unsortedEmployeeCount = Object.keys(this._eventModel.UNSORTED).length;

		if (this._eventModel[1]) {
			var section1 = Object.keys(this._eventModel[1]);
			eventsPanel.setHeaderText(this.oResourceBundle.getText("TEAMMEMBERS_WITH_EVENTS") + " (" + section1.length + " " +
				this.oResourceBundle.getText("OUT_OF") + " " + (unsortedEmployeeCount - 1) + ")");
		} else {
			eventsPanel.setHeaderText(this.oResourceBundle.getText("TEAMMEMBERS_WITH_EVENTS") + " (0)");
		}
	},

	_attachCalendarAggregation: function() {
		var controller = this;
		var oCalendarLegend = this.byId("overlapCalendarLegend");
		var eventTemplate = new sap.me.OverlapCalendarEvent({
			startDay: "{StartDate}",
			endDay: "{EndDate}",
			row: "{RowNumber}",
			type: "{CalendarEventType}",
			typeName: "",
			name: "{Name}"
		});
		/* Current Week + next week filter */
		var oLoggedInUserFilter = new sap.ui.model.Filter("SectionCode", sap.ui.model.FilterOperator.EQ, "0");
		var oEmpWithEventsFilter = new sap.ui.model.Filter("SectionCode", sap.ui.model.FilterOperator.EQ, "1");
		var oSorter = new sap.ui.model.Sorter("Name", false);

		this._tcObject.pernrCalendar.bindAggregation("calendarEvents", {
			path: "/",
			template: eventTemplate,
			filters: [oLoggedInUserFilter]
		}).addDelegate({
			onAfterRendering: function() {
				$("#" + controller._tcObject.eventsCalendar.getId()).children(":first-child").hide();
				var oCalendarElements = $(".calendarVContainer").children();
				$(oCalendarElements).each(function(index, element) {
					$(element).find(".sapMeOverlapCalendarRow").attr("section", index);
				});
				controller._initializeEventBindings(controller); 	
			}
		});

		this._tcObject.eventsCalendar.bindAggregation("calendarEvents", {
			path: "/",
			template: eventTemplate,
			filters: [oEmpWithEventsFilter],
			sorter: [oSorter]
		}).addDelegate({
			onAfterRendering: function() {
				$("#" + controller._tcObject.eventsCalendar.getId()).children(":first-child").hide();
				var oCalendarElements = $(".calendarVContainer").children();
				$(oCalendarElements).each(function(index, element) {
					$(element).find(".sapMeOverlapCalendarRow").attr("section", index);
				});
				controller._initializeEventBindings(controller); 	
			}
		});

		//Fixed Legend Types
		if (oCalendarLegend) {
			oCalendarLegend.setLegendForNormal(this.oResourceBundle.getText("LEGEND_NR"));
			oCalendarLegend.setLegendForType00(this.oResourceBundle.getText("LEGEND_00"));
			oCalendarLegend.setLegendForType01(this.oResourceBundle.getText("LEGEND_01"));
			oCalendarLegend.setLegendForType04(this.oResourceBundle.getText("LEGEND_04"));
			oCalendarLegend.setLegendForType06(this.oResourceBundle.getText("LEGEND_06"));
			oCalendarLegend.setLegendForType07(this.oResourceBundle.getText("LEGEND_07"));
			oCalendarLegend.setLegendForToday(this.oResourceBundle.getText("LEGEND_TD"));
		}

	},

	getPopover: function(events, controller) {
		var eventLayout = new sap.ui.layout.VerticalLayout();
		eventLayout.addStyleClass("popoverVLayout");
		if (events.length > 0) {
			for (var j = 0; j < events.length; j++) {
				eventLayout.addContent(new sap.m.Label({
					text: events[j].CalendarEventDescription
				}).addStyleClass("popoverLabel"));
			}
		}
		var oPopOver = new sap.m.ResponsivePopover({
			placement: sap.m.PlacementType.Auto,
			title: events[0].Name,
			contentWidth: "auto",
			contentHeight: "150px",
			content: [eventLayout],
			afterClose: function() {
				controller.popupInstanceCount = 0; //Reset instance count to prevent opening multiple popovers
				controller.popover = {};
			}
		});
		return oPopOver;
	},

	/**
	 * Manual "click" event handlers for all the days on the calendar
	 * Every day is checked against the _eventModel to figure out the events for a day
	 * A popup is created dynamically and attached to the clicked element with "auto" popover placement
	 */
	_initializeEventBindings: function(controller) {
		controller.popupInstanceCount = 0;
		$(".sapMeOverlapCalendarRowLabels").css("width", "auto");
		$(".sapMeOverlapCalendarDay").on("click", function(event) {
			if (controller.popupInstanceCount === 0) {
				var sectionID = $("#" + event.target.id).parent().attr("section");
				var targetSplits = event.target.id.split("-");
				var row = targetSplits[targetSplits.length - 2];
				
				/* Calculate Offset date */
				var column = targetSplits[targetSplits.length - 1];
				
				var tDate = new Date(controller.firstDate.getTime());
				tDate.setDate(tDate.getDate() + parseInt(column, 10));
				tDate.setHours(0, 0, 0, 0);
				if (tDate.getTimezoneOffset() > 0) {
					//if user is behind GMT (e.g. GMT-3) we convert to UTC date (for later comparison)
					tDate = controller.toUTCDate(tDate);
				}
				
				var sectionElements = {};
				if (!sectionID || controller.allEmployeeMode === true) {
					sectionElements = $._eventModel.UNSORTED[row];
				} else {
					sectionElements = $._eventModel[sectionID][row];
				}
				
				var events = [];
				//iterate through all row elements to find all that match the clicked day (tDate)
				for (var i = 0; i < sectionElements.length; i++) {
					if (sectionElements[i].CalendarEventType !== "00") {
						//check for 1-day events
						if (sectionElements[i].StartDate.toDateString() === tDate.toDateString()) {
							events.push(sectionElements[i]);
						//check for multi-day events
						} else if (sectionElements[i].StartDate.getTime() <= tDate.getTime() &&
								   sectionElements[i].EndDate.getTime()   >= tDate.getTime()) {     //MELN2305707
							events.push(sectionElements[i]);
						}
					}
				}
				if (events.length > 0) {
					controller.popover = controller.getPopover(events, controller);
					if (controller.popover) {
						controller.popupInstanceCount++;
						controller.popover.openBy(event.target);
					}
				}
			}
		});
	},
	/**
	 * Called everytime when navigation buttons are clicked on the calendar
	 * @param event
	 */
	_changeDatesForCalendars: function(event) {
		var controller = this;
		if (!controller.calError) {
			//MELN2281084
			controller.firstDate = this._getJSDate(event.getParameter("firstDate"));
			controller.firstDate.setHours(0, 0, 0, 0);
			if (controller.firstDate.getTimezoneOffset() < 0) {
				controller.firstDate.setMinutes((controller.firstDate.getTimezoneOffset() * -1));
			}
			controller.endDate = this._getJSDate(event.getParameter("endDate"));

			this.oBusyDialog.open();
			this._eventModel = {};
			
			this._setCalendarStartDate(controller, controller.firstDate);
			
			controller.fetchCollection(controller, controller.fetchFilter(controller));
		}
	},
	_getJSDate: function(date) {
		var aDate = date;
		if (date instanceof sap.ui.core.date.UniversalDate) {
			aDate = new Date(date.getTime());
		}
		return aDate;
	},
	/**
	 * Called in order to set the start date in the OverlapCalender
	 */
	_setCalendarStartDate: function(controller, startDate) { //MELN2281084
		controller._tcObject.pernrCalendar.setStartDate(startDate);
		controller._tcObject.eventsCalendar.setStartDate(startDate);
	},
	/**
	 * Invoked by the filter button on the bottom of the Footer Bar.
	 * Toggles between "All Employee" view and "Filtered Employee View"
	 * @param event
	 */
	openCalendarFilter: function(event) {
		var controller = this;
		var clickedButton = event.getSource();

		var oFilterActionSheet = new sap.m.ActionSheet({
			placement: sap.m.PlacementType.Top,
			buttons: [
				new sap.m.ToggleButton({
					pressed: controller.allEmployeeMode ? false : true,
					text: controller.oResourceBundle.getText("FILTER_BY_EMPLOYEE"),
					press: function() {
						controller.allEmployeeMode = false;
						controller.toggleAllEmployees(false);
					}
				}).addStyleClass("BTN_FLTR_EMP"),
				new sap.m.ToggleButton({
					pressed: controller.allEmployeeMode ? true : false,
					text: controller.oResourceBundle.getText("ALL_EMPLOYEES"),
					press: function() {
						controller.allEmployeeMode = true;
						controller.toggleAllEmployees(true);
					}
				}).addStyleClass("BTN_ALL_EMP")
			]
		});
		oFilterActionSheet.openBy(clickedButton);
	},

	getHeaderFooterOptions: function() {
		var _this = this;
		var objHeaderFooterOptions = {
			oEditBtn: {
				sId: "filterFooterButton",
				sIcon: "sap-icon://filter",
				onBtnPressed: function(evt) {
					_this.openCalendarFilter(evt);
				}
			}
		};

		var hc = new sap.ui.core.routing.HashChanger();
		var oUrl = hc.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHeaderFooterOptions.bSuppressBookmarkButton = true;
		}

		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.myleaverequest.view.S1~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */
		if (this.extHookChangeFooterButtons) {
			objHeaderFooterOptions = this.extHookChangeFooterButtons(objHeaderFooterOptions);
		}
		return objHeaderFooterOptions;
	},

	/**
	 * Invalidate called when a panel is expanded.
	 * When failed to call this, the calendar will render without employee names and events
	 * Manual invalidation required to trigger rendering
	 */
	_invalidateCalendar: function() {
		if (this._tcObject) {
			this._tcObject.eventsCalendar.invalidate();
		}
	}
});