jQuery.sap.registerPreloadedModules({
"name":"hcm/myteamcalendar/Component-preload",
"version":"2.0",
"modules":{
	"hcm/myteamcalendar/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

// extent of sap.ca.scfld.md.ComponentBase
sap.ca.scfld.md.ComponentBase.extend("hcm.myteamcalendar.Component", {
	metadata : sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		"name": "Fullscreen Sample",
		"version" : "1.8.14",
		"library" : "hcm.myteamcalendar",
		"includes" : [],
		"dependencies" : {
			"libs" : ["sap.m", "sap.me"],
			"components" : []
		},
		"config" : {
            "resourceBundle": "i18n/i18n.properties",
            "titleResource" : "FULLSCREEN_TITLE" 
            	
		},
		"viewPath" : "hcm.myteamcalendar.view",
		"fullScreenPageRoutes" : {
			// fill the routes to your full screen pages in here.
			"fullscreen" : {
				"pattern" : "",
				"view" : "S1"
			}
		//	"subscreen" : {
		//		"pattern" : "second",
		//		"view" : "S2"
		//	}
		}
	}),	

	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
		var oViewData = {component: this};
		var oComponentData = this.getComponentData();
		return sap.ui.view({
			viewName : "hcm.myteamcalendar.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		}); /* Returns main view*/
	}
});
},
	"hcm/myteamcalendar/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("hcm.myteamcalendar.Configuration", {

	oServiceParams: {
		serviceList: [
			{
				name: "HCM_TEAM_CALENDAR_SRV",
				serviceUrl: "/sap/opu/odata/SAP/HCM_TEAM_CALENDAR_SRV/", //oData service relative path
				isDefault: true,
				mockedDataSource: "/hcm.myteamcalendar/model/metadata.xml"
			}
		]
	},

	getServiceParams: function () {
		return this.oServiceParams;
	},

	getAppConfig: function() {
		return this.oAppConfig;
	},

	/**
	 * @inherit
	 */
	getServiceList: function () {
		return this.oServiceParams.serviceList;
	}

});
},
	"hcm/myteamcalendar/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */

sap.ui.controller("hcm.myteamcalendar.Main", {

	onInit : function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");				
		sap.ca.scfld.md.Startup.init("hcm.myteamcalendar", this);
		
		var effectiveUrl = jQuery.sap.getModulePath("hcm.myteamcalendar") + "/" + "css/mtc.css";

		jQuery.sap.includeStyleSheet(effectiveUrl);
		
	}
});
},
	"hcm/myteamcalendar/Main.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n           xmlns="sap.m" controllerName="hcm.myteamcalendar.Main"  displayBlock="true" height="100%">\n        <App id="fioriContent" showHeader="false">\n        </App>\n</core:View>',
	"hcm/myteamcalendar/i18n/i18n.properties":'# MyTeamCalendar property file\r\n# __ldi.translation.uuid=9000ab30-5931-11e4-8ed6-0800200c9a66\r\n\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE= Team Calendar\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS= Team Members With Events\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM= My Reports\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS= My Peers\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS= Previous Week\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT= Next Week\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE= Events\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES= All Employees\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE= With Events\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR= Working Day\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00= Non-Working Day\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01= Time Off\r\n\r\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\r\nLEGEND_04= Birthday/Anniversary\r\n\r\n#XFLD: Legend Label - Type06 - Public Holiday\r\nLEGEND_06= Public Holiday\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07= Others\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD= Today\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR= Unable to fetch data. Contact your system administrator.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY= An internal error Occurred. Please contact system administrator.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR= Internal Error\r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Choose a Personnel Assignment\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Personnel Assignments\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF= out of\r\n\r\n#XBUT:Button Ok text for Dialog\r\nDIALOG_OK=OK\r\n\r\n#XBUT:Button Cancel text\r\nCANCEL=Cancel',
	"hcm/myteamcalendar/i18n/i18n_ar.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=\\u062A\\u0642\\u0648\\u064A\\u0645 \\u0627\\u0644\\u0641\\u0631\\u064A\\u0642\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u0623\\u0639\\u0636\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u064A\\u0642 \\u0628\\u0623\\u062D\\u062F\\u0627\\u062B\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=\\u062A\\u0642\\u0627\\u0631\\u064A\\u0631\\u064A\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=\\u0623\\u0642\\u0631\\u0627\\u0646\\u064A\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u0627\\u0644\\u0623\\u0633\\u0628\\u0648\\u0639 \\u0627\\u0644\\u0633\\u0627\\u0628\\u0642\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=\\u0627\\u0644\\u0623\\u0633\\u0628\\u0648\\u0639 \\u0627\\u0644\\u062A\\u0627\\u0644\\u064A\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u0627\\u0644\\u0623\\u062D\\u062F\\u0627\\u062B\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u062C\\u0645\\u064A\\u0639 \\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\\u064A\\u0646\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=\\u0628\\u0623\\u062D\\u062F\\u0627\\u062B\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u064A\\u0648\\u0645 \\u0639\\u0645\\u0644\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u064A\\u0648\\u0645 \\u0639\\u0637\\u0644\\u0629\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u063A\\u064A\\u0627\\u0628\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=\\u0639\\u064A\\u062F \\u0627\\u0644\\u0645\\u064A\\u0644\\u0627\\u062F/\\u0627\\u0644\\u0630\\u0643\\u0631\\u0649 \\u0627\\u0644\\u0633\\u0646\\u0648\\u064A\\u0629\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u0627\\u0644\\u0639\\u0637\\u0644\\u0629 \\u0627\\u0644\\u0631\\u0633\\u0645\\u064A\\u0629\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=\\u0623\\u062E\\u0631\\u0649\n\n#XFLD: Legend Label - Today\nLEGEND_TD=\\u0627\\u0644\\u064A\\u0648\\u0645\n\n#YMSE: Service Call Error\nSERVICE_ERROR=\\u062A\\u0639\\u0630\\u0631 \\u0627\\u0633\\u062A\\u0631\\u062C\\u0627\\u0639 \\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A. \\u0627\\u0644\\u0631\\u062C\\u0627\\u0621 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0628\\u0645\\u0633\\u0624\\u0648\\u0644 \\u0627\\u0644\\u0646\\u0638\\u0627\\u0645.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=\\u062D\\u062F\\u062B \\u062E\\u0637\\u0623 \\u062F\\u0627\\u062E\\u0644\\u064A. \\u0628\\u0631\\u062C\\u0627\\u0621 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0628\\u0645\\u0633\\u0624\\u0648\\u0644 \\u0627\\u0644\\u0646\\u0638\\u0627\\u0645.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=\\u062E\\u0637\\u0623 \\u062F\\u0627\\u062E\\u0644\\u064A\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=\\u0627\\u062E\\u062A\\u0631 \\u062A\\u0639\\u064A\\u064A\\u0646 \\u0645\\u0648\\u0638\\u0641\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=\\u062A\\u0639\\u064A\\u064A\\u0646\\u0627\\u062A \\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\\u064A\\u0646\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=\\u0645\\u0646 \\u0623\\u0635\\u0644\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=\\u0645\\u0648\\u0627\\u0641\\u0642\n\n#XBUT:Button Cancel text\nCANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\n',
	"hcm/myteamcalendar/i18n/i18n_bg.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=\\u041A\\u0430\\u043B\\u0435\\u043D\\u0434\\u0430\\u0440 \\u043D\\u0430 \\u0435\\u043A\\u0438\\u043F\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u0427\\u043B\\u0435\\u043D\\u043E\\u0432\\u0435 \\u043D\\u0430 \\u0435\\u043A\\u0438\\u043F \\u0441\\u044A\\u0441 \\u0441\\u044A\\u0431\\u0438\\u0442\\u0438\\u044F\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043E\\u0442\\u0447\\u0435\\u0442\\u0438\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043A\\u043E\\u043B\\u0435\\u0433\\u0438\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u041F\\u0440\\u0435\\u0434\\u0438\\u0448\\u043D\\u0430 \\u0441\\u0435\\u0434\\u043C\\u0438\\u0446\\u0430\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=\\u0421\\u043B\\u0435\\u0434\\u0432\\u0430\\u0449\\u0430\\u0442\\u0430 \\u0441\\u0435\\u0434\\u043C\\u0438\\u0446\\u0430\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u0421\\u044A\\u0431\\u0438\\u0442\\u0438\\u044F\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u0412\\u0441\\u0438\\u0447\\u043A\\u0438 \\u0441\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\\u0438\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=\\u0421\\u044A\\u0441 \\u0441\\u044A\\u0431\\u0438\\u0442\\u0438\\u044F\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u0420\\u0430\\u0431\\u043E\\u0442\\u0435\\u043D \\u0434\\u0435\\u043D\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u041D\\u0435\\u0440\\u0430\\u0431\\u043E\\u0442\\u0435\\u043D \\u0434\\u0435\\u043D\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u0421\\u0432\\u043E\\u0431\\u043E\\u0434\\u043D\\u043E \\u0432\\u0440\\u0435\\u043C\\u0435\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=\\u0420\\u043E\\u0436\\u0434\\u0435\\u043D \\u0434\\u0435\\u043D/\\u0413\\u043E\\u0434\\u0438\\u0448\\u043D\\u0438\\u043D\\u0430\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u041E\\u0444\\u0438\\u0446\\u0438\\u0430\\u043B\\u0435\\u043D \\u043F\\u0440\\u0430\\u0437\\u043D\\u0438\\u043A\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=\\u0414\\u0440\\u0443\\u0433\n\n#XFLD: Legend Label - Today\nLEGEND_TD=\\u0414\\u043D\\u0435\\u0441\n\n#YMSE: Service Call Error\nSERVICE_ERROR=\\u041D\\u0435\\u0432\\u044A\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u0438\\u0437\\u0432\\u043B\\u0438\\u0447\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0434\\u0430\\u043D\\u043D\\u0438. \\u0421\\u0432\\u044A\\u0440\\u0436\\u0435\\u0442\\u0435 \\u0441\\u0435 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u044F \\u0441\\u0438\\u0441\\u0442\\u0435\\u043C\\u0435\\u043D \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=\\u0412\\u044A\\u0437\\u043D\\u0438\\u043A\\u043D\\u0430 \\u0432\\u044A\\u0442\\u0440\\u0435\\u0448\\u043D\\u0430 \\u0433\\u0440\\u0435\\u0448\\u043A\\u0430. \\u041C\\u043E\\u043B\\u044F \\u0441\\u0432\\u044A\\u0440\\u0436\\u0435\\u0442\\u0435 \\u0441\\u0435 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u044F \\u0441\\u0438\\u0441\\u0442\\u0435\\u043C\\u0435\\u043D \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=\\u0412\\u044A\\u0442\\u0440\\u0435\\u0448\\u043D\\u0430 \\u0433\\u0440\\u0435\\u0448\\u043A\\u0430\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=\\u0418\\u0437\\u0431\\u0435\\u0440\\u0435\\u0442\\u0435 \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=\\u041E\\u0442\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=\\u041E\\u0442\\u043A\\u0430\\u0437\n',
	"hcm/myteamcalendar/i18n/i18n_cs.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Kalend\\u00E1\\u0159 t\\u00FDmu\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u010Clenov\\u00E9 t\\u00FDmu s ud\\u00E1lostmi\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=M\\u00E9 v\\u00FDkazy\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Moji kolegov\\u00E9\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=P\\u0159edchoz\\u00ED t\\u00FDden\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Dal\\u0161\\u00ED t\\u00FDden\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Ud\\u00E1losti\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=V\\u0161ichni zam\\u011Bstnanci\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=S ud\\u00E1lostmi\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Pracovn\\u00ED den\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Nepracovn\\u00ED den\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Volno\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Narozeniny/v\\u00FDro\\u010D\\u00ED\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Sv\\u00E1tek\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Jin\\u00E9\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Dnes\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Nelze na\\u010D\\u00EDst data. Obra\\u0165te se na spr\\u00E1vce syst\\u00E9mu.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Do\\u0161lo k intern\\u00ED chyb\\u011B. Obra\\u0165te se na spr\\u00E1vce syst\\u00E9mu.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Intern\\u00ED chyba\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Zvolte pracovn\\u00ED smlouvu\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Pracovn\\u00ED smlouvy\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Z\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Zru\\u0161it\n',
	"hcm/myteamcalendar/i18n/i18n_de.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Teamkalender\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Teammitglieder mit Ereignissen\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Meine Mitarbeiter\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Meine Kollegen\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Vorherige Woche\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=N\\u00E4chste Woche\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Ereignisse\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Alle Mitarbeiter\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Mit Ereignissen\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Arbeitstag\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Arbeitsfreier Tag\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Abwesenheit\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Geburtstag/Jubil\\u00E4um\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Feiertag\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Sonstiges\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Heute\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Daten k\\u00F6nnen nicht abgerufen werden. Wenden Sie sich an Ihre Systemadministration.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Es ist ein interner Fehler aufgetreten. Wenden Sie sich an Ihre Systemadministration.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Interner Fehler\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=W\\u00E4hlen Sie einen Besch\\u00E4ftigungsvertrag\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Besch\\u00E4ftigungsvertr\\u00E4ge\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=von\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Abbrechen\n',
	"hcm/myteamcalendar/i18n/i18n_en.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Team Calendar\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Team Members With Events\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=My Reports\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=My Peers\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Previous Week\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Next Week\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Events\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=All Employees\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=With Events\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Working Day\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Non-Working Day\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Time Off\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Birthday/Anniversary\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Public Holiday\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Other\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Today\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Unable to retrieve data. Contact your system administrator.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=An internal error has occurred. Please contact your system administrator.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Internal error\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Choose a Personnel Assignment\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Personnel Assignments\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Out Of\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Cancel\n',
	"hcm/myteamcalendar/i18n/i18n_en_US_sappsd.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=[[[\\u0162\\u0113\\u0105\\u0271 \\u0108\\u0105\\u013A\\u0113\\u014B\\u018C\\u0105\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=[[[\\u0162\\u0113\\u0105\\u0271 \\u039C\\u0113\\u0271\\u0183\\u0113\\u0157\\u015F \\u0174\\u012F\\u0163\\u0125 \\u0114\\u028B\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=[[[\\u039C\\u0177 \\u0158\\u0113\\u03C1\\u014F\\u0157\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219]]]\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=[[[\\u039C\\u0177 \\u01A4\\u0113\\u0113\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=[[[\\u01A4\\u0157\\u0113\\u028B\\u012F\\u014F\\u0171\\u015F \\u0174\\u0113\\u0113\\u0137\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=[[[\\u0143\\u0113\\u03C7\\u0163 \\u0174\\u0113\\u0113\\u0137\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=[[[\\u0114\\u028B\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=[[[\\u0100\\u013A\\u013A \\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=[[[\\u0174\\u012F\\u0163\\u0125 \\u0114\\u028B\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=[[[\\u0174\\u014F\\u0157\\u0137\\u012F\\u014B\\u011F \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=[[[\\u0143\\u014F\\u014B-\\u0174\\u014F\\u0157\\u0137\\u012F\\u014B\\u011F \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=[[[\\u0162\\u012F\\u0271\\u0113 \\u014E\\u0192\\u0192\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=[[[\\u0181\\u012F\\u0157\\u0163\\u0125\\u018C\\u0105\\u0177/\\u0100\\u014B\\u014B\\u012F\\u028B\\u0113\\u0157\\u015F\\u0105\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=[[[\\u01A4\\u0171\\u0183\\u013A\\u012F\\u010B \\u0124\\u014F\\u013A\\u012F\\u018C\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=[[[\\u014E\\u0163\\u0125\\u0113\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Legend Label - Today\nLEGEND_TD=[[[\\u0162\\u014F\\u018C\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#YMSE: Service Call Error\nSERVICE_ERROR=[[[\\u016E\\u014B\\u0105\\u0183\\u013A\\u0113 \\u0163\\u014F \\u0192\\u0113\\u0163\\u010B\\u0125 \\u018C\\u0105\\u0163\\u0105. \\u0108\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163 \\u0177\\u014F\\u0171\\u0157 \\u015F\\u0177\\u015F\\u0163\\u0113\\u0271 \\u0105\\u018C\\u0271\\u012F\\u014B\\u012F\\u015F\\u0163\\u0157\\u0105\\u0163\\u014F\\u0157.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=[[[\\u0100\\u014B \\u012F\\u014B\\u0163\\u0113\\u0157\\u014B\\u0105\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157 \\u014E\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C. \\u01A4\\u013A\\u0113\\u0105\\u015F\\u0113 \\u010B\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163 \\u015F\\u0177\\u015F\\u0163\\u0113\\u0271 \\u0105\\u018C\\u0271\\u012F\\u014B\\u012F\\u015F\\u0163\\u0157\\u0105\\u0163\\u014F\\u0157.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=[[[\\u012C\\u014B\\u0163\\u0113\\u0157\\u014B\\u0105\\u013A \\u0114\\u0157\\u0157\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=[[[\\u0108\\u0125\\u014F\\u014F\\u015F\\u0113 \\u0105 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u014B\\u0113\\u013A \\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=[[[\\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u014B\\u0113\\u013A \\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=[[[\\u014F\\u0171\\u0163 \\u014F\\u0192\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=[[[\\u014E\\u0136\\u2219\\u2219]]]\n\n#XBUT:Button Cancel text\nCANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\n',
	"hcm/myteamcalendar/i18n/i18n_en_US_saptrc.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=xRUWskylOZDRsOeSiV5Zag_Team Calendar\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=T3lxrEf3tCeLfUSSCBuz2A_Team Members With Events\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=SqwgptMHvo4wXazMw0U2Mg_My Reports\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=eFFdeRNvVTeIuAEKWRAqIg_My Peers\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=z89CNdNUZzWAZfTo/y5Bpg_Previous Week\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=D9MHLcTS+R9D1PKhNzBVGA_Next Week\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=CBG5SMTxVkD1lzRUsw4Q2g_Events\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=ATV1RnvAK7e4xP1LstdTPg_All Employees\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=beztbkWUwkA7V1NWqk/A0A_With Events\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=l6XaHbKCkOfv272X4x5MtA_Working Day\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=dBbZiNviahVAOdd1VAp5Qg_Non-Working Day\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=GacY16LkvNNbqQiy7LPxSA_Time Off\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=xFK/EFcT6imJyBOQfm+ZbQ_Birthday/Anniversary\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=BeAa8GzYNIkSt6NW0MoAgA_Public Holiday\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=IN0MFBoJg/cb2ycvlbDzvQ_Others\n\n#XFLD: Legend Label - Today\nLEGEND_TD=TOeXvmjKbWBJS/WCnK13dg_Today\n\n#YMSE: Service Call Error\nSERVICE_ERROR=PbxyzbLGYcJK1QoMP/cZeg_Unable to fetch data. Contact your system administrator.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=STFT43ZtscW9ofbomRE+cg_An internal error Occurred. Please contact system administrator.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=+RP7rgf/pkeFxwtcUAWMXQ_Internal Error\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=xxivLSss+CjiI+lGzDopKA_Choose a Personnel Assignment\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=DzXHjjsd5yhs1r2wG3Htrg_Personnel Assignments\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Dfb2Q0P7iiRl13kxAyMjgw_out of\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=M69ynMncekf4Wt+wz0ixkA_OK\n\n#XBUT:Button Cancel text\nCANCEL=35MfvuPpUccKVoRYnr1FOA_Cancel\n',
	"hcm/myteamcalendar/i18n/i18n_en_ar.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u062A\\u0642\\u0648\\u064A\\u0645 \\u0627\\u0644\\u0641\\u0631\\u064A\\u0642\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=\\u0623\\u0639\\u0636\\u0627\\u0621 \\u0627\\u0644\\u0641\\u0631\\u064A\\u0642 \\u0628\\u0623\\u062D\\u062F\\u0627\\u062B\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=\\u062A\\u0642\\u0627\\u0631\\u064A\\u0631\\u064A\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=\\u0623\\u0642\\u0631\\u0627\\u0646\\u064A\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=\\u0627\\u0644\\u0623\\u0633\\u0628\\u0648\\u0639 \\u0627\\u0644\\u0633\\u0627\\u0628\\u0642\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=\\u0627\\u0644\\u0623\\u0633\\u0628\\u0648\\u0639 \\u0627\\u0644\\u062A\\u0627\\u0644\\u064A\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=\\u0627\\u0644\\u0623\\u062D\\u062F\\u0627\\u062B\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=\\u062C\\u0645\\u064A\\u0639 \\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\\u064A\\u0646\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=\\u0628\\u0623\\u062D\\u062F\\u0627\\u062B\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=\\u064A\\u0648\\u0645 \\u0639\\u0645\\u0644\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=\\u064A\\u0648\\u0645 \\u0639\\u0637\\u0644\\u0629\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=\\u063A\\u064A\\u0627\\u0628\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=\\u0639\\u0637\\u0644\\u0629 \\u0631\\u0633\\u0645\\u064A\\u0629\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=\\u0639\\u064A\\u062F \\u0627\\u0644\\u0645\\u064A\\u0644\\u0627\\u062F/\\u0627\\u0644\\u0630\\u0643\\u0631\\u0649 \\u0627\\u0644\\u0633\\u0646\\u0648\\u064A\\u0629\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=\\u0623\\u062E\\u0631\\u0649\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=\\u0627\\u0644\\u064A\\u0648\\u0645\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=\\u062A\\u0639\\u0630\\u0631 \\u0627\\u0633\\u062A\\u0631\\u062C\\u0627\\u0639 \\u0627\\u0644\\u0628\\u064A\\u0627\\u0646\\u0627\\u062A. \\u0627\\u0644\\u0631\\u062C\\u0627\\u0621 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0628\\u0645\\u0633\\u0624\\u0648\\u0644 \\u0627\\u0644\\u0646\\u0638\\u0627\\u0645.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=\\u0645\\u0646 \\u0623\\u0635\\u0644\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_cs.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Kalend\\u00E1\\u0159 t\\u00FDmu\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=\\u010Clenov\\u00E9 t\\u00FDmu s ud\\u00E1lostmi\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=M\\u00E9 v\\u00FDkazy\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Moji kolegov\\u00E9\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=P\\u0159edchoz\\u00ED t\\u00FDden\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Dal\\u0161\\u00ED t\\u00FDden\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Ud\\u00E1losti\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=V\\u0161ichni zam\\u011Bstnanci\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=S ud\\u00E1lostmi\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Pracovn\\u00ED den\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Nepracovn\\u00ED den\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Volno\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Sv\\u00E1tek\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Narozeniny/v\\u00FDro\\u010D\\u00ED\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Jin\\u00E9\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Dnes\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Nelze na\\u010D\\u00EDst data. Obra\\u0165te se na spr\\u00E1vce syst\\u00E9mu.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=Z\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_de.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Teamkalender\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Teammitglieder mit Ereignissen\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Meine Mitarbeiter\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Meine Kollegen\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Vorherige Woche\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=N\\u00E4chste Woche\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Ereignisse\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Alle Mitarbeiter\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Mit Ereignissen\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Arbeitstag\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Arbeitsfreier Tag\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Abwesenheit\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Feiertag\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Geburtstag/Jubil\\u00E4um\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Sonstiges\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Heute\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Daten k\\u00F6nnen nicht abgerufen werden. Wenden Sie sich an Ihre Systemadministration.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=von\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_en.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Team Calendar\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Team Members With Events\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=My Reports\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=My Peers\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Previous Week\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Next Week\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Events\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=All Employees\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=With Events\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Working Day\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Non-Working Day\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Time Off\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Public Holiday\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Birthday/Anniversary\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Other\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Today\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Unable to retrieve data. Contact your system administrator.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=Out Of\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_es.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Cal.equipo\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Miembros del equipo con eventos\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Mis informes\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Mis colegas\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Semana anterior\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Semana siguiente\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Eventos\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Todos los empleados\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Con eventos\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=D\\u00EDa laborable\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=D\\u00EDa no laborable\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Tiempo libre\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=D\\u00EDa festivo\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Cumplea\\u00F1os/Aniversario\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Otros\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Hoy\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=No se han podido recuperar datos. P\\u00F3ngase en contacto con el administrador del sistema.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=Fuera de\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_fr.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Calendrier de l\'\\u00E9quipe\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Membres de l\'\\u00E9quipe avec \\u00E9v\\u00E9nements\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Mes rapports\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Mes pairs\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Semaine pr\\u00E9c\\u00E9dente\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Semaine suivante\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=\\u00C9v\\u00E9nements\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Tous les salari\\u00E9s\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Avec \\u00E9v\\u00E9nements\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Jour ouvr\\u00E9\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Jour ch\\u00F4m\\u00E9\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Temps libre\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Jour f\\u00E9ri\\u00E9\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Anniversaire/Anniversaire de service\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Autres\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Aujourd\'hui\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Impossible de r\\u00E9cup\\u00E9rer les donn\\u00E9es. Contactez l\'administrateur syst\\u00E8me.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=sur\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_hu.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Csoportnapt\\u00E1r\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Csoporttagok esem\\u00E9nyekkel\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Saj\\u00E1t besz\\u00E1mol\\u00F3k\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=T\\u00E1rsak\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=El\\u0151z\\u0151 h\\u00E9t\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=K\\u00F6vetkez\\u0151 h\\u00E9ten\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Esem\\u00E9nyek\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=\\u00D6sszes alkalmazott\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Esem\\u00E9nyekkel\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Munkanap\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Nem munkanap\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=T\\u00E1voll\\u00E9t\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=\\u00DCnnepnap\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Sz\\u00FClet\\u00E9snap/\\u00E9vfordul\\u00F3\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Egy\\u00E9b\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Ma\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Nem lehetett leh\\u00EDvni az adatokat. \\u00C9rtes\\u00EDtse a rendszeradminisztr\\u00E1tort.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=/\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_it.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Calendario del team\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Membri del team con eventi\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=I miei report\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=I miei colleghi\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Settimana precedente\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Settimana successiva\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Eventi\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Tutti i dipendenti\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Con eventi\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Giorno lavorativo\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Giorno non lavorativo\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Ferie e permessi\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Giorno festivo\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Compleanno/Anniversario\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Altro\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Oggi\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Impossibile chiamare i dati. Contatta l\'amministratore di sistema.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=Su\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_iw.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u05DC\\u05D5\\u05D7 \\u05E9\\u05E0\\u05D4 \\u05E9\\u05DC \\u05E6\\u05D5\\u05D5\\u05EA\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=\\u05D7\\u05D1\\u05E8\\u05D9 \\u05E6\\u05D5\\u05D5\\u05EA \\u05E2\\u05DD \\u05D0\\u05D9\\u05E8\\u05D5\\u05E2\\u05D9\\u05DD\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=\\u05D4\\u05D3\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=\\u05D4\\u05E2\\u05DE\\u05D9\\u05EA\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=\\u05D4\\u05E9\\u05D1\\u05D5\\u05E2 \\u05D4\\u05E7\\u05D5\\u05D3\\u05DD\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=\\u05D4\\u05E9\\u05D1\\u05D5\\u05E2 \\u05D4\\u05D1\\u05D0\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=\\u05D0\\u05D9\\u05E8\\u05D5\\u05E2\\u05D9\\u05DD\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=\\u05DB\\u05DC \\u05D4\\u05E2\\u05D5\\u05D1\\u05D3\\u05D9\\u05DD\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=\\u05E2\\u05DD \\u05D0\\u05D9\\u05E8\\u05D5\\u05E2\\u05D9\\u05DD\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=\\u05D9\\u05D5\\u05DD \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=\\u05D9\\u05D5\\u05DD \\u05E9\\u05D0\\u05D9\\u05E0\\u05D5 \\u05D9\\u05D5\\u05DD \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=\\u05D7\\u05D2 \\u05E8\\u05E9\\u05DE\\u05D9\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=\\u05D9\\u05D5\\u05DD \\u05D4\\u05D5\\u05DC\\u05D3\\u05EA/\\u05D9\\u05D5\\u05DD \\u05E9\\u05E0\\u05D4\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=\\u05D0\\u05D7\\u05E8\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=\\u05D4\\u05D9\\u05D5\\u05DD\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=\\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05DC\\u05D0\\u05D7\\u05D6\\u05E8 \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD. \\u05E6\\u05D5\\u05E8 \\u05E7\\u05E9\\u05E8 \\u05E2\\u05DD \\u05DE\\u05E0\\u05D4\\u05DC \\u05D4\\u05DE\\u05E2\\u05E8\\u05DB\\u05EA \\u05E9\\u05DC\\u05DA.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=\\u05DE\\u05EA\\u05D5\\u05DA\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_ja.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u30C1\\u30FC\\u30E0\\u30AB\\u30EC\\u30F3\\u30C0\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=\\u30C1\\u30FC\\u30E0\\u30E1\\u30F3\\u30D0\\u30FC (\\u30A4\\u30D9\\u30F3\\u30C8\\u3042\\u308A)\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=My \\u30EC\\u30DD\\u30FC\\u30C8\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=My \\u30D4\\u30A2\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=\\u524D\\u9031\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=\\u7FCC\\u9031\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=\\u30A4\\u30D9\\u30F3\\u30C8\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=\\u5168\\u5F93\\u696D\\u54E1\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=\\u30A4\\u30D9\\u30F3\\u30C8\\u3042\\u308A\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=\\u52E4\\u52D9\\u65E5\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=\\u975E\\u52E4\\u52D9\\u65E5\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=\\u4F11\\u65E5\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=\\u795D\\u65E5\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=\\u8A95\\u751F\\u65E5/\\u8A18\\u5FF5\\u65E5\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=\\u305D\\u306E\\u4ED6\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=\\u672C\\u65E5\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=\\u30C7\\u30FC\\u30BF\\u3092\\u53D6\\u5F97\\u3067\\u304D\\u307E\\u305B\\u3093\\u3002\\u30B7\\u30B9\\u30C6\\u30E0\\u7BA1\\u7406\\u8005\\u306B\\u9023\\u7D61\\u3057\\u3066\\u304F\\u3060\\u3055\\u3044\\u3002\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=/\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_no.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Teamkalender\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Teammedlemmer med hendelser\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Mine rapporter\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Mine kollegaer\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Forrige uke\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Neste uke\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Hendelser\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Alle medarbeidere\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Med hendelser\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Virkedag\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Fridag\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Fritid\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Helgedag\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Bursdag/jubileum\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Annet\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=I dag\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Kan ikke hente tilbake data. Kontakt systemansvarlig.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=av\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_pl.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Kalendarz zespo\\u0142u\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Cz\\u0142onkowie zespo\\u0142u ze zdarzeniami\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Moje raporty\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Moi wsp\\u00F3\\u0142pracownicy\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Poprzedni tydzie\\u0144\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Nast\\u0119pny tydzie\\u0144\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Zdarzenia\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Wszyscy pracownicy\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Ze zdarzeniami\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Dzie\\u0144 roboczy\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Dzie\\u0144 wolny od pracy\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Dni wolne\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Dzie\\u0144 \\u015Bwi\\u0105teczny\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Urodziny/rocznica\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Inne\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Dzisiaj\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Nie mo\\u017Cna wywo\\u0142a\\u0107 danych. Skontaktuj si\\u0119 z administratorem systemu.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=z\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_pt.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Calend\\u00E1rio de equipe\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Membros da equipe com eventos\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Meus relat\\u00F3rios\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=Meus colegas\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=Semana ant.\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Pr\\u00F3x.semana\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Eventos\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=Tds.funcions.\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Com eventos\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=Dia \\u00FAtil\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=Dia livre\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Tempo livre\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Feriado\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Anivers\\u00E1rio\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Outro\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Hoje\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Imposs\\u00EDvel recuperar dados. Contate o administrador do sistema.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=Fora de\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_ru.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u041A\\u0430\\u043B\\u0435\\u043D\\u0434\\u0430\\u0440\\u044C \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=\\u0423\\u0447\\u0430\\u0441\\u0442\\u043D\\u0438\\u043A\\u0438 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u0441 \\u0441\\u043E\\u0431\\u044B\\u0442\\u0438\\u044F\\u043C\\u0438\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=\\u041C\\u043E\\u0438 \\u043E\\u0442\\u0447\\u0435\\u0442\\u044B\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=\\u041C\\u043E\\u0438 \\u043A\\u043E\\u043B\\u043B\\u0435\\u0433\\u0438\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=\\u041F\\u0440\\u0435\\u0434\\u044B\\u0434\\u0443\\u0449\\u0430\\u044F \\u043D\\u0435\\u0434\\u0435\\u043B\\u044F\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=\\u0421\\u043B\\u0435\\u0434\\u0443\\u044E\\u0449\\u0430\\u044F \\u043D\\u0435\\u0434\\u0435\\u043B\\u044F\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=\\u0421\\u043E\\u0431\\u044B\\u0442\\u0438\\u044F\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=\\u0412\\u0441\\u0435 \\u0441\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\\u0438\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=\\u0421 \\u0441\\u043E\\u0431\\u044B\\u0442\\u0438\\u044F\\u043C\\u0438\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=\\u0420\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=\\u041D\\u0435\\u0440\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=\\u0421\\u0432\\u043E\\u0431\\u043E\\u0434\\u043D\\u043E\\u0435 \\u0432\\u0440\\u0435\\u043C\\u044F\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=\\u041F\\u0440\\u0430\\u0437\\u0434\\u043D\\u0438\\u0447\\u043D\\u044B\\u0439 \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=\\u0414\\u0435\\u043D\\u044C \\u0440\\u043E\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F/\\u044E\\u0431\\u0438\\u043B\\u0435\\u0439\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=\\u041F\\u0440\\u043E\\u0447\\u0435\\u0435\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=\\u0421\\u0435\\u0433\\u043E\\u0434\\u043D\\u044F\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=\\u041D\\u0435\\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u0432\\u044B\\u0437\\u0432\\u0430\\u0442\\u044C \\u0434\\u0430\\u043D\\u043D\\u044B\\u0435. \\u041E\\u0431\\u0440\\u0430\\u0442\\u0438\\u0442\\u0435\\u0441\\u044C \\u043A \\u0441\\u0438\\u0441\\u0442\\u0435\\u043C\\u043D\\u043E\\u043C\\u0443 \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440\\u0443.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=\\u0438\\u0437\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_tr.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=Ekip takvimi\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=Olaylarla ekip \\u00FCyeleri\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=Raporlar\\u0131m\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=E\\u015Fd\\u00FCzey \\u00E7al\\u0131\\u015Fanlar\\u0131m\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=\\u00D6nceki hafta\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=Gelecek hafta\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=Etkinlikler\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=T\\u00FCm \\u00E7al\\u0131\\u015Fanlar\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=Olaylarla\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=\\u0130\\u015F g\\u00FCn\\u00FC\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=\\u00C7al\\u0131\\u015F\\u0131lmayan g\\u00FCn\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=Bo\\u015F zaman\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=Resmi tatil\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=Do\\u011Fum g\\u00FCn\\u00FC/y\\u0131ld\\u00F6n\\u00FCm\\u00FC\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=Di\\u011Fer\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=Bug\\u00FCn\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=Veriler al\\u0131nam\\u0131yor. Sistem y\\u00F6neticinizle irtibata ge\\u00E7in.\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=/\r\n',
	"hcm/myteamcalendar/i18n/i18n_en_zh_CN.properties":'\r\n#XTIT: this is the title for the fullscreen section\r\nFULLSCREEN_TITLE=\\u56E2\\u961F\\u65E5\\u5386\r\n\r\n#XGRP: Team Members with Events Group\r\nTEAMMEMBERS_WITH_EVENTS=\\u56E2\\u961F\\u6210\\u5458\\uFF08\\u6709\\u4E8B\\u4EF6\\uFF09\r\n\r\n#XCRD: My Reports - Tab Strip Item\r\nMY_TEAM=\\u6211\\u7684\\u4E0B\\u5C5E\r\n\r\n#XCRD: My Peers - Tab Strip Item\r\nMY_PEERS=\\u6211\\u7684\\u540C\\u4E8B\r\n\r\n#XBUT: Navigate to previous month\r\nNAVIGATE_PREVIOUS=\\u4E0A\\u5468\r\n\r\n#XBUT: Navigate to next month\r\nNAVIGATE_NEXT=\\u4E0B\\u5468\r\n\r\n#XTIT: Events Title for Quickview\r\nEVENTS_TITLE=\\u4E8B\\u4EF6\r\n\r\n#XBUT: All Employee Filter\r\nALL_EMPLOYEES=\\u6240\\u6709\\u5458\\u5DE5\r\n\r\n#XBUT: Employees With Events\r\nFILTER_BY_EMPLOYEE=\\u5305\\u542B\\u4E8B\\u4EF6\r\n\r\n#XFLD: Legend Label - Normal - Working Day\r\nLEGEND_NR=\\u5DE5\\u4F5C\\u65E5\r\n\r\n#XFLD: Legend Label - Type00 - Non-Working Day\r\nLEGEND_00=\\u975E\\u5DE5\\u4F5C\\u65E5\r\n\r\n#XFLD: Legend Label - Type01 - Time Off \r\nLEGEND_01=\\u4F11\\u5047\r\n\r\n#XFLD: Legend Label - Type04 - Public Holiday\r\nLEGEND_04=\\u6CD5\\u5B9A\\u5047\\u65E5\r\n\r\n#XFLD: Legend Label - Type06 - Birthday/Anniversary\r\nLEGEND_06=\\u751F\\u65E5/\\u5468\\u5E74\\u7EAA\\u5FF5\\u65E5\r\n\r\n#XFLD: Legend Label - Type07 - Others\r\nLEGEND_07=\\u5176\\u4ED6\r\n\r\n#XFLD: Legend Label - Today\r\nLEGEND_TD=\\u4ECA\\u5929\r\n\r\n#YMSE: Service Call Error\r\nSERVICE_ERROR=\\u65E0\\u6CD5\\u68C0\\u7D22\\u6570\\u636E\\u3002\\u8BF7\\u8054\\u7CFB\\u7CFB\\u7EDF\\u7BA1\\u7406\\u5458\\u3002\r\n\r\n#XFLD: Out of Label - 5 out of 10 employees \r\nOUT_OF=/\r\n',
	"hcm/myteamcalendar/i18n/i18n_es.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Cal.equipo\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Miembros del equipo con eventos\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Mis informes\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Mis colegas\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Semana anterior\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Semana siguiente\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Eventos\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Todos los empleados\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Con eventos\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=D\\u00EDa laborable\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=D\\u00EDa no laborable\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Tiempo libre\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Cumplea\\u00F1os/Aniversario\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=D\\u00EDa festivo\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Otros\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Hoy\n\n#YMSE: Service Call Error\nSERVICE_ERROR=No se han podido recuperar datos. P\\u00F3ngase en contacto con el administrador del sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Se ha producido un error interno. P\\u00F3ngase en contacto con el administrador del sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Error interno\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Seleccione un contrato de ocupaci\\u00F3n\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Contratos de ocupaci\\u00F3n\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Fuera de\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Cancelar\n',
	"hcm/myteamcalendar/i18n/i18n_fr.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Calendrier de l\'\\u00E9quipe\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Membres de l\'\\u00E9quipe avec \\u00E9v\\u00E9nements\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Mes rapports\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Mes pairs\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Semaine pr\\u00E9c\\u00E9dente\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Semaine suivante\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u00C9v\\u00E9nements\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Tous les salari\\u00E9s\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Avec \\u00E9v\\u00E9nements\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Jour ouvr\\u00E9\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Jour ch\\u00F4m\\u00E9\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Temps libre\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Anniversaire/Anniversaire de service\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Jour f\\u00E9ri\\u00E9\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Autres\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Aujourd\'hui\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Impossible de r\\u00E9cup\\u00E9rer les donn\\u00E9es. Contactez l\'administrateur syst\\u00E8me.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Une erreur interne s\'est produite. Contactez l\'administrateur syst\\u00E8me.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Erreur interne\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=S\\u00E9lectionner un contrat de travail\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Contrats de travail\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=sur\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Interrompre\n',
	"hcm/myteamcalendar/i18n/i18n_hr.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Timski kalendar\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u010Clanovi tima s doga\\u0111ajima\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Moji podre\\u0111eni zaposlenici\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Moji ravnopravni zaposlenici\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Prethodni tjedan\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Sljede\\u0107i tjedan\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Doga\\u0111aji\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Svi zaposlenici\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=S doga\\u0111ajima\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Radni dan\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Neradni dan\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Dopust\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Ro\\u0111endan/godi\\u0161njica\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Dr\\u017Eavni praznik\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Drugo\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Danas\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Dohva\\u0107anje podataka nije mogu\\u0107e. Kontaktirajte svog administratora sustava.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Pojavila se interna gre\\u0161ka. Molimo, kontaktirajte svog administratora sustava.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Interna gre\\u0161ka\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Izaberite ugovor o radu\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Ugovori o radu\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Od\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Otka\\u017Ei\n',
	"hcm/myteamcalendar/i18n/i18n_hu.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Csoportnapt\\u00E1r\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Csoporttagok esem\\u00E9nyekkel\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Saj\\u00E1t besz\\u00E1mol\\u00F3k\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=T\\u00E1rsak\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=El\\u0151z\\u0151 h\\u00E9t\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=K\\u00F6vetkez\\u0151 h\\u00E9ten\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Esem\\u00E9nyek\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u00D6sszes alkalmazott\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Esem\\u00E9nyekkel\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Munkanap\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Nem munkanap\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=T\\u00E1voll\\u00E9t\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Sz\\u00FClet\\u00E9snap/\\u00E9vfordul\\u00F3\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u00DCnnepnap\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Egy\\u00E9b\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Ma\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Nem lehetett leh\\u00EDvni az adatokat. \\u00C9rtes\\u00EDtse a rendszeradminisztr\\u00E1tort.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Bels\\u0151 hiba t\\u00F6rt\\u00E9nt. K\\u00E9rem, vegye fel a kapcsolatot rendszeradminisztr\\u00E1tor\\u00E1val.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Bels\\u0151 hiba\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Foglalkoztat\\u00E1si szerz\\u0151d\\u00E9s v\\u00E1laszt\\u00E1sa\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Foglalkoztat\\u00E1si szerz\\u0151d\\u00E9sek\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=/\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=M\\u00E9gse\n',
	"hcm/myteamcalendar/i18n/i18n_it.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Calendario del team\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Membri del team con eventi\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=I miei dipendenti a riporto diretto\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=I miei colleghi\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Settimana precedente\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Settimana successiva\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Eventi\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Tutti i dipendenti\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Con eventi\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Giorno lavorativo\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Giorno non lavorativo\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Ferie e permessi\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Compleanno/Anniversario\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Giorno festivo\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Altro\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Oggi\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Impossibile chiamare i dati. Contatta l\'amministratore di sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Si \\u00E8 verificato un errore interno; contatta l\'amministratore del sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Errore interno\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Seleziona un contratto d\'impiego\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Contratti d\'impiego\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Su\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Annulla\n',
	"hcm/myteamcalendar/i18n/i18n_iw.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=\\u05DC\\u05D5\\u05D7 \\u05E9\\u05E0\\u05D4 \\u05E9\\u05DC \\u05E6\\u05D5\\u05D5\\u05EA\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u05D7\\u05D1\\u05E8\\u05D9 \\u05E6\\u05D5\\u05D5\\u05EA \\u05E2\\u05DD \\u05D0\\u05D9\\u05E8\\u05D5\\u05E2\\u05D9\\u05DD\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=\\u05D4\\u05D3\\u05D5\\u05D7\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=\\u05D4\\u05E2\\u05DE\\u05D9\\u05EA\\u05D9\\u05DD \\u05E9\\u05DC\\u05D9\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u05D4\\u05E9\\u05D1\\u05D5\\u05E2 \\u05D4\\u05E7\\u05D5\\u05D3\\u05DD\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=\\u05D4\\u05E9\\u05D1\\u05D5\\u05E2 \\u05D4\\u05D1\\u05D0\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u05D0\\u05D9\\u05E8\\u05D5\\u05E2\\u05D9\\u05DD\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u05DB\\u05DC \\u05D4\\u05E2\\u05D5\\u05D1\\u05D3\\u05D9\\u05DD\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=\\u05E2\\u05DD \\u05D0\\u05D9\\u05E8\\u05D5\\u05E2\\u05D9\\u05DD\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u05D9\\u05D5\\u05DD \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u05D9\\u05D5\\u05DD \\u05E9\\u05D0\\u05D9\\u05E0\\u05D5 \\u05D9\\u05D5\\u05DD \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=\\u05D9\\u05D5\\u05DD \\u05D4\\u05D5\\u05DC\\u05D3\\u05EA/\\u05D9\\u05D5\\u05DD \\u05E9\\u05E0\\u05D4\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u05D7\\u05D2 \\u05E8\\u05E9\\u05DE\\u05D9\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=\\u05D0\\u05D7\\u05E8\n\n#XFLD: Legend Label - Today\nLEGEND_TD=\\u05D4\\u05D9\\u05D5\\u05DD\n\n#YMSE: Service Call Error\nSERVICE_ERROR=\\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05DC\\u05D0\\u05D7\\u05D6\\u05E8 \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD. \\u05E6\\u05D5\\u05E8 \\u05E7\\u05E9\\u05E8 \\u05E2\\u05DD \\u05DE\\u05E0\\u05D4\\u05DC \\u05D4\\u05DE\\u05E2\\u05E8\\u05DB\\u05EA \\u05E9\\u05DC\\u05DA.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4 \\u05E4\\u05E0\\u05D9\\u05DE\\u05D9\\u05EA. \\u05E6\\u05D5\\u05E8 \\u05E7\\u05E9\\u05E8 \\u05E2\\u05DD \\u05DE\\u05E0\\u05D4\\u05DC \\u05D4\\u05DE\\u05E2\\u05E8\\u05DB\\u05EA.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=\\u05E9\\u05D2\\u05D9\\u05D0\\u05D4 \\u05E4\\u05E0\\u05D9\\u05DE\\u05D9\\u05EA\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=\\u05D1\\u05D7\\u05E8 \\u05D4\\u05E7\\u05E6\\u05D0\\u05EA \\u05E2\\u05D5\\u05D1\\u05D3\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=\\u05D4\\u05E7\\u05E6\\u05D0\\u05D5\\u05EA \\u05E2\\u05D5\\u05D1\\u05D3\\u05D9\\u05DD\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=\\u05DE\\u05EA\\u05D5\\u05DA\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=\\u05D1\\u05D8\\u05DC\n',
	"hcm/myteamcalendar/i18n/i18n_ja.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=\\u30C1\\u30FC\\u30E0\\u30AB\\u30EC\\u30F3\\u30C0\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u30C1\\u30FC\\u30E0\\u30E1\\u30F3\\u30D0\\u30FC (\\u30A4\\u30D9\\u30F3\\u30C8\\u3042\\u308A)\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=My \\u30EC\\u30DD\\u30FC\\u30C8\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=My \\u30D4\\u30A2\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u524D\\u9031\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=\\u7FCC\\u9031\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u30A4\\u30D9\\u30F3\\u30C8\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u5168\\u5F93\\u696D\\u54E1\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=\\u30A4\\u30D9\\u30F3\\u30C8\\u3042\\u308A\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u52E4\\u52D9\\u65E5\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u975E\\u52E4\\u52D9\\u65E5\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u4F11\\u65E5\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=\\u8A95\\u751F\\u65E5/\\u8A18\\u5FF5\\u65E5\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u795D\\u65E5\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=\\u305D\\u306E\\u4ED6\n\n#XFLD: Legend Label - Today\nLEGEND_TD=\\u672C\\u65E5\n\n#YMSE: Service Call Error\nSERVICE_ERROR=\\u30C7\\u30FC\\u30BF\\u3092\\u53D6\\u5F97\\u3067\\u304D\\u307E\\u305B\\u3093\\u3002\\u30B7\\u30B9\\u30C6\\u30E0\\u7BA1\\u7406\\u8005\\u306B\\u9023\\u7D61\\u3057\\u3066\\u304F\\u3060\\u3055\\u3044\\u3002\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=\\u5185\\u90E8\\u30A8\\u30E9\\u30FC\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\u3002\\u30B7\\u30B9\\u30C6\\u30E0\\u7BA1\\u7406\\u8005\\u306B\\u9023\\u7D61\\u3057\\u3066\\u304F\\u3060\\u3055\\u3044\\u3002\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=\\u5185\\u90E8\\u30A8\\u30E9\\u30FC\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=\\u5F93\\u696D\\u54E1\\u5272\\u5F53\\u306E\\u9078\\u629E\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=\\u5F93\\u696D\\u54E1\\u5272\\u5F53\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=/\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=\\u4E2D\\u6B62\n',
	"hcm/myteamcalendar/i18n/i18n_no.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Teamkalender\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Teammedlemmer med hendelser\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Mine rapporter\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Mine kollegaer\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Forrige uke\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Neste uke\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Hendelser\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Alle medarbeidere\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Med hendelser\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Virkedag\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Fridag\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Fritid\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=F\\u00F8dselsdag/jubileum\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Helgedag\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Annet\n\n#XFLD: Legend Label - Today\nLEGEND_TD=I dag\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Kan ikke hente tilbake data. Kontakt systemansvarlig.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=En intern feil har oppst\\u00E5tt. Kontakt systemansvarlig.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Intern feil\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Velg en ansettelseskontrakt\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Ansettelseskontrakter\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=av\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Avbryt\n',
	"hcm/myteamcalendar/i18n/i18n_pl.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Kalendarz zespo\\u0142u\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Cz\\u0142onkowie zespo\\u0142u ze zdarzeniami\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Moje raporty\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Moi wsp\\u00F3\\u0142pracownicy\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Poprzedni tydzie\\u0144\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Nast\\u0119pny tydzie\\u0144\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Zdarzenia\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Wszyscy pracownicy\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Ze zdarzeniami\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Dzie\\u0144 roboczy\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Dzie\\u0144 wolny od pracy\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Dni wolne\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Urodziny/rocznica\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Dzie\\u0144 \\u015Bwi\\u0105teczny\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Inne\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Dzisiaj\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Nie mo\\u017Cna wywo\\u0142a\\u0107 danych. Skontaktuj si\\u0119 z administratorem systemu.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d wewn\\u0119trzny. Skontaktuj si\\u0119 z administratorem systemu.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=B\\u0142\\u0105d wewn\\u0119trzny\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Wybierz umow\\u0119 o prac\\u0119\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Umowy o prac\\u0119\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=z\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Anuluj\n',
	"hcm/myteamcalendar/i18n/i18n_pt.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Calend\\u00E1rio de equipe\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Membros da equipe com eventos\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Meus relat\\u00F3rios\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Meus colegas\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Semana ant.\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Pr\\u00F3x.semana\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Eventos\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Tds.funcions.\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Com eventos\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Dia \\u00FAtil\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Dia livre\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Tempo livre\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Anivers\\u00E1rio\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Feriado\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Outro\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Hoje\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Imposs\\u00EDvel recuperar dados. Contate o administrador do sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Ocorreu um erro interno. Contate o administrador do sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Erro interno\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Selecionar um contrato de emprego\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Contratos de emprego\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Fora de\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Anular\n',
	"hcm/myteamcalendar/i18n/i18n_ro.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Calendar echip\\u0103\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Membri echip\\u0103 cu evenimente\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Angaja\\u0163ii mei\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Colegii mei\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=S\\u0103pt\\u0103m\\u00E2na precedent\\u0103\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=S\\u0103pt\\u0103m\\u00E2na urm\\u0103toare\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Evenimente\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=To\\u0163i angaja\\u0163ii\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Cu evenimente\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Zi lucr\\u0103toare\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Zi nelucr\\u0103toare\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Zile libere\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Zi de na\\u015Ftere/aniversare\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=S\\u0103rb\\u0103toare legal\\u0103\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Altele\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Ast\\u0103zi\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Imposibil de reg\\u0103sit date. Contacta\\u0163i administratorul dvs.de sistem.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=A ap\\u0103rut o eroare intern\\u0103. Contacta\\u0163i administratorul dvs.de sistem.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Eroare intern\\u0103\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Alege\\u0163i un contract de munc\\u0103\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Contracte de munc\\u0103\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Din\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Anulare\n',
	"hcm/myteamcalendar/i18n/i18n_ru.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=\\u041A\\u0430\\u043B\\u0435\\u043D\\u0434\\u0430\\u0440\\u044C \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u0423\\u0447\\u0430\\u0441\\u0442\\u043D\\u0438\\u043A\\u0438 \\u0433\\u0440\\u0443\\u043F\\u043F\\u044B \\u0441 \\u0441\\u043E\\u0431\\u044B\\u0442\\u0438\\u044F\\u043C\\u0438\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=\\u041C\\u043E\\u0438 \\u043E\\u0442\\u0447\\u0435\\u0442\\u044B\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=\\u041C\\u043E\\u0438 \\u043A\\u043E\\u043B\\u043B\\u0435\\u0433\\u0438\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u041F\\u0440\\u0435\\u0434\\u044B\\u0434\\u0443\\u0449\\u0430\\u044F \\u043D\\u0435\\u0434\\u0435\\u043B\\u044F\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=\\u0421\\u043B\\u0435\\u0434\\u0443\\u044E\\u0449\\u0430\\u044F \\u043D\\u0435\\u0434\\u0435\\u043B\\u044F\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u0421\\u043E\\u0431\\u044B\\u0442\\u0438\\u044F\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u0412\\u0441\\u0435 \\u0441\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\\u0438\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=\\u0421 \\u0441\\u043E\\u0431\\u044B\\u0442\\u0438\\u044F\\u043C\\u0438\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u0420\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0434\\u0435\\u043D\\u044C\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u041D\\u0435\\u0440\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0434\\u0435\\u043D\\u044C\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u0421\\u0432\\u043E\\u0431\\u043E\\u0434\\u043D\\u043E\\u0435 \\u0432\\u0440\\u0435\\u043C\\u044F\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=\\u0414\\u0435\\u043D\\u044C \\u0440\\u043E\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F/\\u044E\\u0431\\u0438\\u043B\\u0435\\u0439\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u041F\\u0440\\u0430\\u0437\\u0434\\u043D\\u0438\\u0447\\u043D\\u044B\\u0439 \\u0434\\u0435\\u043D\\u044C\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=\\u041F\\u0440\\u043E\\u0447\\u0435\\u0435\n\n#XFLD: Legend Label - Today\nLEGEND_TD=\\u0421\\u0435\\u0433\\u043E\\u0434\\u043D\\u044F\n\n#YMSE: Service Call Error\nSERVICE_ERROR=\\u041D\\u0435\\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u0432\\u044B\\u0437\\u0432\\u0430\\u0442\\u044C \\u0434\\u0430\\u043D\\u043D\\u044B\\u0435. \\u041E\\u0431\\u0440\\u0430\\u0442\\u0438\\u0442\\u0435\\u0441\\u044C \\u043A \\u0441\\u0438\\u0441\\u0442\\u0435\\u043C\\u043D\\u043E\\u043C\\u0443 \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440\\u0443.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=\\u041F\\u0440\\u043E\\u0438\\u0437\\u043E\\u0448\\u043B\\u0430 \\u0432\\u043D\\u0443\\u0442\\u0440\\u0435\\u043D\\u043D\\u044F\\u044F \\u043E\\u0448\\u0438\\u0431\\u043A\\u0430. \\u041E\\u0431\\u0440\\u0430\\u0442\\u0438\\u0442\\u0435\\u0441\\u044C \\u043A \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440\\u0443.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=\\u0412\\u043D\\u0443\\u0442\\u0440\\u0435\\u043D\\u043D\\u044F\\u044F \\u043E\\u0448\\u0438\\u0431\\u043A\\u0430\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=\\u0412\\u044B\\u0431\\u0440\\u0430\\u0442\\u044C \\u0442\\u0440\\u0443\\u0434\\u043E\\u0432\\u043E\\u0439 \\u0434\\u043E\\u0433\\u043E\\u0432\\u043E\\u0440\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=\\u0422\\u0440\\u0443\\u0434\\u043E\\u0432\\u044B\\u0435 \\u0434\\u043E\\u0433\\u043E\\u0432\\u043E\\u0440\\u044B\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=\\u0438\\u0437\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=\\u041E\\u041A\n\n#XBUT:Button Cancel text\nCANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\n',
	"hcm/myteamcalendar/i18n/i18n_sh.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Kalendar tima\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u010Clanovi tima sa doga\\u0111ajima\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Moji izve\\u0161taji\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Moje kolege\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Prethodna nedelja\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Slede\\u0107a nedelja\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Doga\\u0111aji\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Svi zaposleni\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Sa doga\\u0111ajima\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Radni dan\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Neradni dan\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Slobodni dani\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Ro\\u0111endan/godi\\u0161njica\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Dr\\u017Eavni praznik\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Drugo\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Danas\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Nije mogu\\u0107e pozvati podatke. Obavestite sistemskog administratora.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Interna gre\\u0161ka. Obavestite sistemskog administratora.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Interna gre\\u0161ka\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Izaberite ugovor o radu\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Ugovori o radu\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Od\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Odustani\n',
	"hcm/myteamcalendar/i18n/i18n_sk.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Kalend\\u00E1r t\\u00EDmu\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u010Clenovia t\\u00EDmu s udalos\\u0165ami\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Moji podriaden\\u00ED pracovn\\u00EDci\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Moji kolegovia\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Predch\\u00E1dzaj\\u00FAci t\\u00FD\\u017Ede\\u0148\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Nasleduj\\u00FAci t\\u00FD\\u017Ede\\u0148\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Udalosti\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=V\\u0161etci zamestnanci\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=S udalos\\u0165ami\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Pracovn\\u00FD de\\u0148\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Nepracovn\\u00FD de\\u0148\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Vo\\u013Eno\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Narodeniny/v\\u00FDro\\u010Die\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Sviatok\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=In\\u00E9\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Dnes\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Nie je mo\\u017En\\u00E9 na\\u010D\\u00EDta\\u0165 d\\u00E1ta. Obr\\u00E1\\u0165te sa na spr\\u00E1vcu syst\\u00E9mu.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Vyskytla sa intern\\u00E1 chyba. Obr\\u00E1\\u0165te sa na spr\\u00E1vcu syst\\u00E9mu.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Intern\\u00E1 chyba\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Vyberte pracovn\\u00FA zmluvu\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Pracovn\\u00E9 zmluvy\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=z\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Zru\\u0161i\\u0165\n',
	"hcm/myteamcalendar/i18n/i18n_sl.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Koledar tima\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u010Clani skupine z dogodki\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Moji poro\\u010Devalci\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=Moji enakovredni\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=Prej\\u0161nji teden\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Naslednji teden\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Dogodki\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=Vsi zaposleni\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Z dogodki\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=Delovni dan\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=Dela prost dan\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=Prosti \\u010Das\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Rojstni dan/jubilej\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Praznik\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Drugo\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Danes\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Podatkov ni mogo\\u010De pridobiti. Obrnite se na svojega administratorja sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Pri\\u0161lo je do interne napake. Prosim, obrnite se na svojega administratorja sistema.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Interna napaka\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Izberite pogodbo o delu\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Pogodbe o delu\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=Od\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=OK\n\n#XBUT:Button Cancel text\nCANCEL=Prekinitev\n',
	"hcm/myteamcalendar/i18n/i18n_tr.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=Ekip takvimi\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=Olaylarla ekip \\u00FCyeleri\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=Raporlar\\u0131m\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=E\\u015Fd\\u00FCzey \\u00E7al\\u0131\\u015Fanlar\\u0131m\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u00D6nceki hafta\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=Gelecek hafta\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=Etkinlikler\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=T\\u00FCm \\u00E7al\\u0131\\u015Fanlar\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=Olaylarla\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u0130\\u015F g\\u00FCn\\u00FC\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u00C7al\\u0131\\u015F\\u0131lmayan g\\u00FCn\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u0130zin g\\u00FCn\\u00FC\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=Do\\u011Fum g\\u00FCn\\u00FC/y\\u0131ld\\u00F6n\\u00FCm\\u00FC\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=Resmi tatil\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=Di\\u011Fer\n\n#XFLD: Legend Label - Today\nLEGEND_TD=Bug\\u00FCn\n\n#YMSE: Service Call Error\nSERVICE_ERROR=Veriler al\\u0131nam\\u0131yor. Sistem y\\u00F6neticinizle irtibata ge\\u00E7in.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=Dahili hata ortaya \\u00E7\\u0131kt\\u0131. Sistem y\\u00F6neticinizle irtibata ge\\u00E7in.\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=Dahili hata\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Personel tayini se\\u00E7\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Personel tayinleri\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=/\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=Tamam\n\n#XBUT:Button Cancel text\nCANCEL=\\u0130ptal et\n',
	"hcm/myteamcalendar/i18n/i18n_zh_CN.properties":'\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=\\u56E2\\u961F\\u65E5\\u5386\n\n#XGRP: Team Members with Events Group\nTEAMMEMBERS_WITH_EVENTS=\\u56E2\\u961F\\u6210\\u5458\\uFF08\\u6709\\u4E8B\\u4EF6\\uFF09\n\n#XCRD: My Reports - Tab Strip Item\nMY_TEAM=\\u6211\\u7684\\u4E0B\\u5C5E\n\n#XCRD: My Peers - Tab Strip Item\nMY_PEERS=\\u6211\\u7684\\u540C\\u4E8B\n\n#XBUT: Navigate to previous month\nNAVIGATE_PREVIOUS=\\u4E0A\\u5468\n\n#XBUT: Navigate to next month\nNAVIGATE_NEXT=\\u4E0B\\u5468\n\n#XTIT: Events Title for Quickview\nEVENTS_TITLE=\\u4E8B\\u4EF6\n\n#XBUT: All Employee Filter\nALL_EMPLOYEES=\\u6240\\u6709\\u5458\\u5DE5\n\n#XBUT: Employees With Events\nFILTER_BY_EMPLOYEE=\\u5305\\u542B\\u4E8B\\u4EF6\n\n#XFLD: Legend Label - Normal - Working Day\nLEGEND_NR=\\u5DE5\\u4F5C\\u65E5\n\n#XFLD: Legend Label - Type00 - Non-Working Day\nLEGEND_00=\\u975E\\u5DE5\\u4F5C\\u65E5\n\n#XFLD: Legend Label - Type01 - Time Off \nLEGEND_01=\\u4F11\\u5047\n\n#XFLD: Legend Label - Type04 - Birthday/Anniversary\nLEGEND_04=\\u751F\\u65E5/\\u5468\\u5E74\\u7EAA\\u5FF5\\u65E5\n\n#XFLD: Legend Label - Type06 - Public Holiday\nLEGEND_06=\\u516C\\u5171\\u5047\\u65E5\n\n#XFLD: Legend Label - Type07 - Others\nLEGEND_07=\\u5176\\u4ED6\n\n#XFLD: Legend Label - Today\nLEGEND_TD=\\u4ECA\\u5929\n\n#YMSE: Service Call Error\nSERVICE_ERROR=\\u65E0\\u6CD5\\u68C0\\u7D22\\u6570\\u636E\\u3002\\u8BF7\\u8054\\u7CFB\\u7CFB\\u7EDF\\u7BA1\\u7406\\u5458\\u3002\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR_BODY=\\u53D1\\u751F\\u5185\\u90E8\\u9519\\u8BEF\\u3002\\u8BF7\\u8054\\u7CFB\\u7CFB\\u7EDF\\u7BA1\\u7406\\u5458\\u3002\n\n#YMSE: Generic Error Message\nINTERNAL_ERROR=\\u5185\\u90E8\\u9519\\u8BEF\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=\\u9009\\u62E9\\u4EBA\\u4E8B\\u5206\\u914D\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=\\u4EBA\\u4E8B\\u5206\\u914D\n\n#XFLD: Out of Label - 5 out of 10 employees \nOUT_OF=/\n\n#XBUT:Button Ok text for Dialog\nDIALOG_OK=\\u786E\\u5B9A\n\n#XBUT:Button Cancel text\nCANCEL=\\u53D6\\u6D88\n',
	"hcm/myteamcalendar/view/ConcurrentEmployment.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.view.ConcurrentEmployment");
/*global hcm:true */
hcm.myteamcalendar.view.ConcurrentEmployment = {
	getPersonellAssignments: function(appController, fSuccess) {
		var self = this;
		appController.oDataModel.read(
			"/ConcurrentEmploymentSet",
			null, [],
			true,
			function(oData) {
				fSuccess(oData.results);
			},
			function(oError) {
				self.processError(oError);
			});
	},
	processError: function(oError) {
		var that = this;
		var message = "";
		var messageDetails = "";
		if (oError.response) {
			var body = oError.response.body;
			try {
				body = JSON.parse(body);
				if (body.error.innererror && body.error.innererror.errordetails) {

					var errors = body.error.innererror.errordetails;
					for (var i = 0; i < errors.length; i++) {
						messageDetails += errors[i].code + " : " + errors[i].message + "\n";
					}
				}
				if (messageDetails === "") {
					messageDetails = body.error.code + " : " + body.error.message.value;
				}
				message = body.error.message.value;
			} catch (e) {
				jQuery.sap.log.warning("Could parse the response", ["parseError"], ["hcm.myteamcalendar"]);
			}
		}
		if (message === "") {
			message = that.oResourceBundle.getText("INTERNAL_ERROR");
		}
		if (messageDetails === "") {
			messageDetails = that.oResourceBundle.getText("INTERNAL_ERROR_BODY");
		}
		var oMessage = {
			message: message,
			details: messageDetails,
			type: sap.ca.ui.message.Type.ERROR
		};
		//release busy dialog
		sap.ca.ui.utils.busydialog.releaseBusyDialog();

		sap.ca.ui.message.showMessageBox({
			type: oMessage.type,
			message: oMessage.message,
			details: oMessage.details
		});
	},

	getCEEnablement: function(self, successHandler) {
		this.initialize(self, successHandler);
		var oModel = new sap.ui.model.json.JSONModel();
		this.getPersonellAssignments(self, function(data) {
			if (data.length > 1) {
				oModel.setData(data);
				self.oCEForm.setModel(oModel);
				self.oCEDialog.open();
			} else {
				self.oApplication.pernr = data[0].Pernr;
				successHandler();
			}
		});
	},
	initialize: function(self, successHandler) {
		var itemTemplate = new sap.m.RadioButton({
			text: "{AssignmentText}",
			customData: new sap.ui.core.CustomData({
				"key": "Pernr",
				"value": "{Pernr}"
			})
		});
		self.oCESelect = new sap.m.RadioButtonGroup().bindAggregation("buttons", "/", itemTemplate);
		self.oCEForm = new sap.ui.layout.form.Form({
			layout: new sap.ui.layout.form.ResponsiveGridLayout({
				labelSpanL: 12,
				//emptySpanL: 0,
				labelSpanM: 12,
				//emptySpanM: 2,
				labelSpanS: 12,
				columnsL: 2,
				columnsM: 2
			}),
			formContainers: new sap.ui.layout.form.FormContainer({
				formElements: [
					new sap.ui.layout.form.FormElement({
						label: new sap.m.Label({
							text: self.oResourceBundle.getText("PERSONAL_ASSIGN")
						}),
						fields: self.oCESelect
					})
				]
			})
		});
		self.oCEDialog = new sap.m.Dialog({
			title: self.oResourceBundle.getText("PERSONAL_ASSIGN_TITLE"),
			content: self.oCEForm,
			buttons: [
				new sap.m.Button({
					text: self.oResourceBundle.getText("DIALOG_OK"),
					press: function() {
						self.oCEDialog.close();
						self.oCEDialog.Cancelled = false;
						self.oApplication.pernr = self.oCESelect.getSelectedButton().data().Pernr;
						successHandler();
					}
				}),
				new sap.m.Button({
					text: self.oResourceBundle.getText("CANCEL"),
					press: function() {
						self.oCEDialog.close();
						self.oCEDialog.Cancelled = true;
						window.history.go(-1);
						/* eslint-enable sap-browser-api-warning */
						//}
					}
				})
			]
		});
		self.oCEDialog.attachAfterClose(function() {
			if (!self.oApplication.pernr && !self.oCEDialog.Cancelled) {
				self.oCEDialog.open();
			}
		});
	},
	setControllerInstance: function(cntrlInstance) {
		this.cntrlInstance = cntrlInstance;
	},
	getControllerInstance: function() {
		return this.cntrlInstance;
	}
};
},
	"hcm/myteamcalendar/view/S1.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("hcm.myteamcalendar.view.ConcurrentEmployment");
/*global hcm:true */
sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.myteamcalendar.view.S1", {
	onInit: function() {
		/* Initializations */
		this._tcObject = {
			pernrCalendar: {},
			eventsCalendar: {},
			nonEventsCalendar: {}
		};
		//Calendar Defaults
		this.calMode = "PEERS"; // "PEERS" mode is the default calendar mode at launch. The other value is "TEAM" mode (Chosen from nav bar)
		this.allEmployeeMode = false; //The "Filtered Employee Mode" is set to default and "All Employee Mode" would be false
		this.popover = {}; //To maintain one instance to prevent multiple instances be opened on click of any cell

		this._eventModel = {}; // Take in the incoming model and segregate Section Codes and Row numbers for Event handling, and quickview
		this.employeeHasTeam = false; //The check for logged-in employee, if he is a manager and has a team
		var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView());
		hcm.myteamcalendar.view.ConcurrentEmployment.setControllerInstance(this);
		var oStartupParameters = sap.ui.component(sComponentId).getComponentData().startupParameters;
		if ((oStartupParameters !== undefined) && (oStartupParameters.context !== undefined)) {
			this.firstDate = new Date(oStartupParameters.context[0]);
		} else {
			this.firstDate = new Date();
			this.firstDate.setHours(0, 0, 0, 0);  //MELN2281084
			if (this.firstDate.getTimezoneOffset() < 0) { 
				//in case user is ahead of GMT (e.g. GMT+1) the timezone offset gets added				
				this.firstDate.setMinutes((this.firstDate.getTimezoneOffset() * -1));
			}
		}
		this.endDate = new Date();
		this.endDate.setDate(this.endDate.getDate() + 13); //End date to be separated from Start Date by 14 days. 14th day is the end date.
		this.calError = false; //Error flag to be monitored across application.

		this.oBusyDialog = new sap.m.BusyDialog();

		/* Models */
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.oResourceBundle = this.oApplication.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		this.oJsonModel = new sap.ui.model.json.JSONModel();
		/* Set calendar rows to single week for mobile device */
		this.oJsonModel.setSizeLimit(2000);
		if (sap.ui.Device.system.phone) {
			this.endDate.setDate(this.firstDate.getDate() + 6);
			this.byId("loggedInUserCalendar").setWeeksPerRow(1);
			this.byId("empWithEventsCalendar").setWeeksPerRow(1);
			var a = this.byId("overlapCalendarLegend");
			a.setExpanded(false);
		}
		/* Code for Back Button */
		this.byId("FTC_PAGE").fireNavButtonPress = function() {
			window.history.go(-1);
		};
	},

	onAfterRendering: function() {
		var self = this;
		if (!this.oApplication.pernr) {
			hcm.myteamcalendar.view.ConcurrentEmployment.getCEEnablement(this, function() {
				self.initializeView();
			});
		}
	},

	initializeView: function() {
		//Initial Service call with "Peers" selection and "Filter Employee" and current date as default for two weeks
		this.fetchCollection(this, this.fetchFilter(this));
		this._tcObject.pernrCalendar = this.byId("loggedInUserCalendar");
		this._tcObject.eventsCalendar = this.byId("empWithEventsCalendar");

		this._tcObject.eventsPanel = this.byId("eventsPanel");

		/* Check if the logged in employee has reportees - Only on first load */
		this._tcObject.myTeamFilter = this.byId("myTeamFilter");
		if (!this.employeeHasTeam) {
			this._tcObject.myTeamFilter.setVisible(false);
			this.checkReportees(this);
		}
		this._disabledDateSelection(this); //Prevent Calendar date click. Only on the first calendar
		
		/* Date change for the calendars. Current date is set as starting date */
		this._setCalendarStartDate(this, this.firstDate);
	},

	/**
	 * Prevents calendar's date selection
	 * @params controller
	 */
	_disabledDateSelection: function(controller) {
		controller._tcObject.pernrCalendar.getCalendar().ontap = function(event) {
			event.stopPropagation();
			return false;
		};
	},

	/** 
	 * Prepares the filter before service call. All required parameters would be available from the controller object
	 */
	fetchFilter: function(controller) {
		var startDate = controller.firstDate;
		var endDate = controller.endDate;
		
		var dateFilter = "$filter=StartDate eq datetime'" + startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" + startDate.getDate() +
			"T00:00:00'";
		dateFilter += " and  EndDate eq datetime'" + endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" +
			endDate.getDate() + "T00:00:00'";
		dateFilter += " and EmployeeID eq '" + controller.oApplication.pernr + "'";
		
		if (this.calMode === "PEERS") {
			dateFilter += " and AppMode eq 'R'";
		} else {
			dateFilter += " and AppMode eq 'T'";
		}
		return dateFilter;
	},
	/** 
	 * convert local time to UTC time (add timezone offset)
	 */
	toUTCDate: function(date) {
		return new Date(date.setMinutes(date.getMinutes() + date.getTimezoneOffset()));
	},
	/** 
	 * read all employee events from backend for the displayed timespan
	 */
	fetchCollection: function(controller, filter) {
		var self = this;
		this.oBusyDialog.open();
		controller.oDataModel.read("EmployeeCollection", null, [filter], true, function(data) {
			var utcResults = data.results;
			if (new Date().getTimezoneOffset() > 0) {  //MELN2281084
				//if user is behind GMT (e.g. GMT-3) we convert the dates to UTC
				utcResults = [];
				data.results.forEach(function(result) {
					result.StartDate = self.toUTCDate(result.StartDate);
					result.EndDate = self.toUTCDate(result.EndDate);
					utcResults.push(result);
				});
			}
			controller.oJsonModel.setData(utcResults);
			controller.getView().setModel(controller.oJsonModel);
			if (controller.allEmployeeMode) {
				controller.toggleAllEmployees(true);
			} else {
				controller.toggleAllEmployees(false);
			}
			controller._assimilateEventModel();

		}, function(error) {
			controller.handleTeamCalendarServerError(controller, error);
		});
	},

	/*
        Stops all navigations and operations when encountered with server error
    */
	handleTeamCalendarServerError: function(controller, error) {
		controller.oBusyDialog.close();
		controller._tcObject.eventsCalendar.setVisible(false);
		controller.byId("idIconTabBarNoIcons").setVisible(false);
		controller.byId("filterFooterButton").setVisible(false);
		controller.calError = true;
		var oSettings = {
			message: controller.oResourceBundle.getText("SERVICE_ERROR"),
			details: error.response.body,
			type: sap.ca.ui.message.Type.ERROR
		};
		sap.ca.ui.message.showMessageBox(oSettings);
	},

	/*
        Switches between Peer/Reports view on the navigation bar
    */
	iconBarSelected: function(event) {
		var controller = this;
		var eventKey = event.getParameter("key");
		if (controller.calMode !== eventKey) {
			controller.calMode = eventKey;
			controller.oBusyDialog.open();
			this._eventModel = {};
			controller.fetchCollection(controller, controller.fetchFilter(controller));
		}
	},

	/* 
        Toggles between the "Show All Employees" view and the filtered view
        If the flag is true, then the "Show All Employees" view will be turned on
    */
	toggleAllEmployees: function(flag) {
		var controller = this;
		if (flag) {
			controller._tcObject.eventsPanel.setVisible(false);
			controller.allEmployeeModelSwitch(true);
		} else {
			controller._tcObject.eventsPanel.setVisible(true);
			controller.allEmployeeModelSwitch(false);
		}
	},

	allEmployeeModelSwitch: function(flag) {
		var that = this;
		that._assimilateEventModel();
		if (flag) {
			var eventTemplate = new sap.me.OverlapCalendarEvent({
				startDay: "{StartDate}",
				endDay: "{EndDate}",
				row: "{RowNumber}",
				type: "{CalendarEventType}",
				typeName: "",
				name: "{Name}"
			});
			that._tcObject.pernrCalendar.bindAggregation("calendarEvents", {
				path: "/",
				template: eventTemplate
			}).addDelegate({
				onAfterRendering: function() {
					$("#" + that._tcObject.eventsCalendar.getId()).children(":first-child").hide();
					var oCalendarElements = $(".calendarVContainer").children();
					$(oCalendarElements).each(function(index, element) {
						$(element).find(".sapMeOverlapCalendarRow").attr("section", index);
					});
					that._initializeEventBindings(that); 
				}
			});
		} else {
			that._attachCalendarAggregation();
		}

		that.oBusyDialog.close();
	},

	/**
	 * Will be called only a on fresh start of Team Calendar and immediately after the "Peer" service call.
	 * Checks if the logged-in employee has a team under him. So, the service will be called with app mode of "T"
	 * If the resulting employee count is less 1 (the logged-in employee is included in the result),
	 * then "Team" tab will be disabled
	 */
	checkReportees: function(controller) {
		controller.calMode = "TEAM";
		controller.oDataModel.read("EmployeeCollection", null, controller.fetchFilter(controller), true, function(data) {
			if ((data.results.length <= 1) ||
				(data.results[0].EmployeeID === data.results[data.results.length - 1].EmployeeID)) {
				controller.employeeHasTeam = false;
				controller._tcObject.myTeamFilter.setVisible(false);
			} else {
				controller.employeeHasTeam = true;
				controller._tcObject.myTeamFilter.setVisible(true);
			}
			controller.calMode = "PEERS"; //Reset the calMode back to Peers.
		});
	},

	/**
	 * Loads up the  _eventModel with event information from the incoming model.
	 * Information from this object would be used for Event Popup
	 */
	_assimilateEventModel: function() {
		var controller = this;
		controller._eventModel = {};
		controller._eventModel.UNSORTED = {};

		var oModelData = controller.oJsonModel.getData();
		if (oModelData.length > 0) {
			for (var i = 0; i < oModelData.length; i++) {
				if (!controller._eventModel[oModelData[i].SectionCode]) {
					controller._eventModel[oModelData[i].SectionCode] = {};
				}
				if (!controller._eventModel[oModelData[i].SectionCode][oModelData[i].RowNumber]) {
					controller._eventModel[oModelData[i].SectionCode][oModelData[i].RowNumber] = [];
				}
				controller._eventModel[oModelData[i].SectionCode][oModelData[i].RowNumber].push(oModelData[i]);

				if (!controller._eventModel.UNSORTED[oModelData[i].RowNumber]) {
					controller._eventModel.UNSORTED[oModelData[i].RowNumber] = [];
				}
				controller._eventModel.UNSORTED[oModelData[i].RowNumber].push(oModelData[i]);
			}
		}
		$._eventModel = controller._eventModel;
		controller.updateCalendarSections();
	},

	/*
        Updates the panel header text for Events Calendar
    */
	updateCalendarSections: function() {
		var eventsPanel = this.byId("eventsPanel");
		var unsortedEmployeeCount = Object.keys(this._eventModel.UNSORTED).length;

		if (this._eventModel[1]) {
			var section1 = Object.keys(this._eventModel[1]);
			eventsPanel.setHeaderText(this.oResourceBundle.getText("TEAMMEMBERS_WITH_EVENTS") + " (" + section1.length + " " +
				this.oResourceBundle.getText("OUT_OF") + " " + (unsortedEmployeeCount - 1) + ")");
		} else {
			eventsPanel.setHeaderText(this.oResourceBundle.getText("TEAMMEMBERS_WITH_EVENTS") + " (0)");
		}
	},

	_attachCalendarAggregation: function() {
		var controller = this;
		var oCalendarLegend = this.byId("overlapCalendarLegend");
		var eventTemplate = new sap.me.OverlapCalendarEvent({
			startDay: "{StartDate}",
			endDay: "{EndDate}",
			row: "{RowNumber}",
			type: "{CalendarEventType}",
			typeName: "",
			name: "{Name}"
		});
		/* Current Week + next week filter */
		var oLoggedInUserFilter = new sap.ui.model.Filter("SectionCode", sap.ui.model.FilterOperator.EQ, "0");
		var oEmpWithEventsFilter = new sap.ui.model.Filter("SectionCode", sap.ui.model.FilterOperator.EQ, "1");
		var oSorter = new sap.ui.model.Sorter("Name", false);

		this._tcObject.pernrCalendar.bindAggregation("calendarEvents", {
			path: "/",
			template: eventTemplate,
			filters: [oLoggedInUserFilter]
		}).addDelegate({
			onAfterRendering: function() {
				$("#" + controller._tcObject.eventsCalendar.getId()).children(":first-child").hide();
				var oCalendarElements = $(".calendarVContainer").children();
				$(oCalendarElements).each(function(index, element) {
					$(element).find(".sapMeOverlapCalendarRow").attr("section", index);
				});
				controller._initializeEventBindings(controller); 	
			}
		});

		this._tcObject.eventsCalendar.bindAggregation("calendarEvents", {
			path: "/",
			template: eventTemplate,
			filters: [oEmpWithEventsFilter],
			sorter: [oSorter]
		}).addDelegate({
			onAfterRendering: function() {
				$("#" + controller._tcObject.eventsCalendar.getId()).children(":first-child").hide();
				var oCalendarElements = $(".calendarVContainer").children();
				$(oCalendarElements).each(function(index, element) {
					$(element).find(".sapMeOverlapCalendarRow").attr("section", index);
				});
				controller._initializeEventBindings(controller); 	
			}
		});

		//Fixed Legend Types
		if (oCalendarLegend) {
			oCalendarLegend.setLegendForNormal(this.oResourceBundle.getText("LEGEND_NR"));
			oCalendarLegend.setLegendForType00(this.oResourceBundle.getText("LEGEND_00"));
			oCalendarLegend.setLegendForType01(this.oResourceBundle.getText("LEGEND_01"));
			oCalendarLegend.setLegendForType04(this.oResourceBundle.getText("LEGEND_04"));
			oCalendarLegend.setLegendForType06(this.oResourceBundle.getText("LEGEND_06"));
			oCalendarLegend.setLegendForType07(this.oResourceBundle.getText("LEGEND_07"));
			oCalendarLegend.setLegendForToday(this.oResourceBundle.getText("LEGEND_TD"));
		}

	},

	getPopover: function(events, controller) {
		var eventLayout = new sap.ui.layout.VerticalLayout();
		eventLayout.addStyleClass("popoverVLayout");
		if (events.length > 0) {
			for (var j = 0; j < events.length; j++) {
				eventLayout.addContent(new sap.m.Label({
					text: events[j].CalendarEventDescription
				}).addStyleClass("popoverLabel"));
			}
		}
		var oPopOver = new sap.m.ResponsivePopover({
			placement: sap.m.PlacementType.Auto,
			title: events[0].Name,
			contentWidth: "auto",
			contentHeight: "150px",
			content: [eventLayout],
			afterClose: function() {
				controller.popupInstanceCount = 0; //Reset instance count to prevent opening multiple popovers
				controller.popover = {};
			}
		});
		return oPopOver;
	},

	/**
	 * Manual "click" event handlers for all the days on the calendar
	 * Every day is checked against the _eventModel to figure out the events for a day
	 * A popup is created dynamically and attached to the clicked element with "auto" popover placement
	 */
	_initializeEventBindings: function(controller) {
		controller.popupInstanceCount = 0;
		$(".sapMeOverlapCalendarRowLabels").css("width", "auto");
		$(".sapMeOverlapCalendarDay").on("click", function(event) {
			if (controller.popupInstanceCount === 0) {
				var sectionID = $("#" + event.target.id).parent().attr("section");
				var targetSplits = event.target.id.split("-");
				var row = targetSplits[targetSplits.length - 2];
				
				/* Calculate Offset date */
				var column = targetSplits[targetSplits.length - 1];
				
				var tDate = new Date(controller.firstDate.getTime());
				tDate.setDate(tDate.getDate() + parseInt(column, 10));
				tDate.setHours(0, 0, 0, 0);
				if (tDate.getTimezoneOffset() > 0) {
					//if user is behind GMT (e.g. GMT-3) we convert to UTC date (for later comparison)
					tDate = controller.toUTCDate(tDate);
				}
				
				var sectionElements = {};
				if (!sectionID || controller.allEmployeeMode === true) {
					sectionElements = $._eventModel.UNSORTED[row];
				} else {
					sectionElements = $._eventModel[sectionID][row];
				}
				
				var events = [];
				//iterate through all row elements to find all that match the clicked day (tDate)
				for (var i = 0; i < sectionElements.length; i++) {
					if (sectionElements[i].CalendarEventType !== "00") {
						//check for 1-day events
						if (sectionElements[i].StartDate.toDateString() === tDate.toDateString()) {
							events.push(sectionElements[i]);
						//check for multi-day events
						} else if (sectionElements[i].StartDate.getTime() <= tDate.getTime() &&
								   sectionElements[i].EndDate.getTime()   >= tDate.getTime()) {     //MELN2305707
							events.push(sectionElements[i]);
						}
					}
				}
				if (events.length > 0) {
					controller.popover = controller.getPopover(events, controller);
					if (controller.popover) {
						controller.popupInstanceCount++;
						controller.popover.openBy(event.target);
					}
				}
			}
		});
	},
	/**
	 * Called everytime when navigation buttons are clicked on the calendar
	 * @param event
	 */
	_changeDatesForCalendars: function(event) {
		var controller = this;
		if (!controller.calError) {
			//MELN2281084
			controller.firstDate = this._getJSDate(event.getParameter("firstDate"));
			controller.firstDate.setHours(0, 0, 0, 0);
			if (controller.firstDate.getTimezoneOffset() < 0) {
				controller.firstDate.setMinutes((controller.firstDate.getTimezoneOffset() * -1));
			}
			controller.endDate = this._getJSDate(event.getParameter("endDate"));

			this.oBusyDialog.open();
			this._eventModel = {};
			
			this._setCalendarStartDate(controller, controller.firstDate);
			
			controller.fetchCollection(controller, controller.fetchFilter(controller));
		}
	},
	_getJSDate: function(date) {
		var aDate = date;
		if (date instanceof sap.ui.core.date.UniversalDate) {
			aDate = new Date(date.getTime());
		}
		return aDate;
	},
	/**
	 * Called in order to set the start date in the OverlapCalender
	 */
	_setCalendarStartDate: function(controller, startDate) { //MELN2281084
		controller._tcObject.pernrCalendar.setStartDate(startDate);
		controller._tcObject.eventsCalendar.setStartDate(startDate);
	},
	/**
	 * Invoked by the filter button on the bottom of the Footer Bar.
	 * Toggles between "All Employee" view and "Filtered Employee View"
	 * @param event
	 */
	openCalendarFilter: function(event) {
		var controller = this;
		var clickedButton = event.getSource();

		var oFilterActionSheet = new sap.m.ActionSheet({
			placement: sap.m.PlacementType.Top,
			buttons: [
				new sap.m.ToggleButton({
					pressed: controller.allEmployeeMode ? false : true,
					text: controller.oResourceBundle.getText("FILTER_BY_EMPLOYEE"),
					press: function() {
						controller.allEmployeeMode = false;
						controller.toggleAllEmployees(false);
					}
				}).addStyleClass("BTN_FLTR_EMP"),
				new sap.m.ToggleButton({
					pressed: controller.allEmployeeMode ? true : false,
					text: controller.oResourceBundle.getText("ALL_EMPLOYEES"),
					press: function() {
						controller.allEmployeeMode = true;
						controller.toggleAllEmployees(true);
					}
				}).addStyleClass("BTN_ALL_EMP")
			]
		});
		oFilterActionSheet.openBy(clickedButton);
	},

	getHeaderFooterOptions: function() {
		var _this = this;
		var objHeaderFooterOptions = {
			oEditBtn: {
				sId: "filterFooterButton",
				sIcon: "sap-icon://filter",
				onBtnPressed: function(evt) {
					_this.openCalendarFilter(evt);
				}
			}
		};

		var hc = new sap.ui.core.routing.HashChanger();
		var oUrl = hc.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHeaderFooterOptions.bSuppressBookmarkButton = true;
		}

		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.myleaverequest.view.S1~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */
		if (this.extHookChangeFooterButtons) {
			objHeaderFooterOptions = this.extHookChangeFooterButtons(objHeaderFooterOptions);
		}
		return objHeaderFooterOptions;
	},

	/**
	 * Invalidate called when a panel is expanded.
	 * When failed to call this, the calendar will render without employee names and events
	 * Manual invalidation required to trigger rendering
	 */
	_invalidateCalendar: function() {
		if (this._tcObject) {
			this._tcObject.eventsCalendar.invalidate();
		}
	}
});
},
	"hcm/myteamcalendar/view/S1.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View\n\txmlns:core="sap.ui.core"\n\txmlns="sap.m"\n\txmlns:l="sap.ui.layout"\n\txmlns:u="sap.me" controllerName="hcm.myteamcalendar.view.S1" height="100%">\n\t<Page id="FTC_PAGE" showNavButton="true" title="{i18n>FULLSCREEN_TITLE}">\n\t\t<content>\n\t\t\t<IconTabBar\n                    class="iconTabBarPaddingTop"\n                    id="idIconTabBarNoIcons"\n                    expandable= "false"\n                    select="iconBarSelected">\n\t\t\t\t<items>\n\t\t\t\t\t<IconTabFilter\n                        id="myPeersFilter"\n                        key="PEERS"\n                        text="{i18n>MY_PEERS}">\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t\t<IconTabFilter\n                        id="myTeamFilter"\n                        key="TEAM"\n                        text="{i18n>MY_TEAM}">\n\t\t\t\t\t</IconTabFilter>\n\t\t\t\t\t<!-- extension added to add icon tab filter -->\n\t\t\t\t\t<core:ExtensionPoint name="mtc_IconTabFilterExtension"></core:ExtensionPoint>\n\t\t\t\t</items>\n\t\t\t</IconTabBar>\n\t\t\t<ScrollContainer id="calendarScrollContainer" width="100%" class="calendarSContainer">\n\t\t\t\t<l:VerticalLayout width="100%" height="75%" class="calendarVContainer">\n\t\t\t\t\t<u:OverlapCalendar \n                        id="loggedInUserCalendar"\n                        weeksPerRow="2"\n                        class="loggedInUserCalendar"\n                        swipeToNavigate="false"\n                        changeDate="_changeDatesForCalendars">\n\t\t\t\t\t</u:OverlapCalendar>\n\t\t\t\t\t<!-- Overlap Calendar with Events -->\n\t\t\t\t\t<Panel\n                        id="eventsPanel"\n    \t\t            expandable = "true"\n                    \texpanded = "true"\n                    \theaderText= "{i18n>TEAMMEMBERS_WITH_EVENTS}"\n                    \texpand = "_invalidateCalendar"\n                    \tclass="eventPanel">\n\t\t\t\t\t\t<content>\n\t\t\t\t\t\t\t<u:OverlapCalendar \n                                id="empWithEventsCalendar"\n                                class="empWithEventsCalendar"\n                                swipeToNavigate="false"\n                                weeksPerRow="2">\n\t\t\t\t\t\t\t</u:OverlapCalendar>\n\t\t\t\t\t\t</content>\n\t\t\t\t\t</Panel>\n\t\t\t\t</l:VerticalLayout>\n\t\t\t</ScrollContainer>\n\t\t\t<l:VerticalLayout id="calendarLegendVLayout" width="100%" height="25%" class="legendContainer">\n\t\t\t\t<u:CalendarLegend\n                        id="overlapCalendarLegend"\n                        expanded="true"\n                        width="100%">\n\t\t\t\t</u:CalendarLegend>\n\t\t\t</l:VerticalLayout>\n\t\t</content>\n\t</Page>\n</core:View>'
}});
