/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myteamcalendar.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
sap.ca.scfld.md.ComponentBase.extend("hcm.myteamcalendar.Component", {
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		"name": "Fullscreen Sample",
		"version": "1.8.14",
		"library": "hcm.myteamcalendar",
		"includes": [],
		"dependencies": {
			"libs": ["sap.m", "sap.me"],
			"components": []
		},
		"config": {
			"resourceBundle": "i18n/i18n.properties",
			"titleResource": "FULLSCREEN_TITLE"
		},
		"viewPath": "hcm.myteamcalendar.view",
		"fullScreenPageRoutes": {
			"fullscreen": {
				"pattern": "",
				"view": "S1"
			}
		}
	}),
	createContent: function() {
		var v = {
			component: this
		};
		var c = this.getComponentData();
		return sap.ui.view({
			viewName: "hcm.myteamcalendar.Main",
			type: sap.ui.core.mvc.ViewType.XML,
			viewData: v
		});
	}
});