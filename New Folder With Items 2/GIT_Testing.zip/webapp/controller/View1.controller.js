sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.GIT.test.GIT_Testing.controller.View1", {
		onInit: function () {

		}
	});
});