sap.ui.define([
	"com/GIT/test/GIT_Testing/test/unit/controller/View1.controller"
], function () {
	"use strict";
});