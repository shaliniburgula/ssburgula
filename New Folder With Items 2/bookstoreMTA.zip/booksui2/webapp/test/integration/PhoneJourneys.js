/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"booksui2/booksui2/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"booksui2/booksui2/test/integration/pages/App",
	"booksui2/booksui2/test/integration/pages/Browser",
	"booksui2/booksui2/test/integration/pages/Master",
	"booksui2/booksui2/test/integration/pages/Detail",
	"booksui2/booksui2/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "booksui2.booksui2.view."
	});

	sap.ui.require([
		"booksui2/booksui2/test/integration/NavigationJourneyPhone",
		"booksui2/booksui2/test/integration/NotFoundJourneyPhone",
		"booksui2/booksui2/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});