/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 Author in the list
// * All 3 Author have at least one books

sap.ui.require([
	"sap/ui/test/Opa5",
	"booksui/booksui/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"booksui/booksui/test/integration/pages/App",
	"booksui/booksui/test/integration/pages/Browser",
	"booksui/booksui/test/integration/pages/Master",
	"booksui/booksui/test/integration/pages/Detail",
	"booksui/booksui/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "booksui.booksui.view."
	});

	sap.ui.require([
		"booksui/booksui/test/integration/MasterJourney",
		"booksui/booksui/test/integration/NavigationJourney",
		"booksui/booksui/test/integration/NotFoundJourney",
		"booksui/booksui/test/integration/BusyJourney"
	], function () {
		QUnit.start();
	});
});