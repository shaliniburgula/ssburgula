/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"booksui/booksui/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"booksui/booksui/test/integration/pages/App",
	"booksui/booksui/test/integration/pages/Browser",
	"booksui/booksui/test/integration/pages/Master",
	"booksui/booksui/test/integration/pages/Detail",
	"booksui/booksui/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "booksui.booksui.view."
	});

	sap.ui.require([
		"booksui/booksui/test/integration/NavigationJourneyPhone",
		"booksui/booksui/test/integration/NotFoundJourneyPhone",
		"booksui/booksui/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});