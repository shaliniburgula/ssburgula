# MTA-BookStore
BookStore app with MTA (multiple target application) concept
You can read more info about the app in the following blog post: 
https://blogs.sap.com/2017/05/11/develop-a-full-stack-application-for-cf-using-sap-web-ide/
