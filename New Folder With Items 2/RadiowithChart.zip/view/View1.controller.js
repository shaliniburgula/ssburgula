var oVizFrame;
var oModel;
var oPopOver;
sap.ui.controller("view.View1", {
    
	onInit: function() {
	    	oVizFrame = this.getView().byId("idVizFrameBar");
            oModel = new sap.ui.model.json.JSONModel();
            oPopOver = this.getView().byId("idPopOver");
		/*var cityJSONObj = new sap.ui.model.json.JSONModel();
		var citydata = {
				           cityList:[
				                     {cityname: "city1"},
				                     {cityname: "city2"},
				                     {cityname: "city3"},
				                     {cityname: "city4"},
				                     {cityname: "city5"},
				                     {cityname: "city6"}
				                  		                     
				                     ]
				};
		cityJSONObj.setData(citydata);
		sap.ui.getCore().setModel(cityJSONObj,"cityModel");
		var oList = this.getView().byId("idlist");
		oList.attachEvent("updateFinished", function() {
		var items = this.getView().byId("idlist").getItems();
		if(items.length>0)
			{
				var aValues=[];
			  if(items.length>4)
				  {
				  		for(var i=0;i<4;i++)
				  			{
						  			items[i].setSelected(true);
						  			var cname = items[i].getTitle();
						  			
						  			aValues.push(cname);
				  			}
				  }
			  else
				  {
							  for(var i=0;i<items.length;i++)
					  			{
							  			items[i].setSelected(true);
							  			var cname = items[i].getTitle();
							  			
							  			aValues.push(cname);
					  			}
				  }
			  
			  feedValueAxis.setValues(aValues);
			}
		
		}, this);*/
		
	        var columnData={
        	    "company": [{
        	    	"year":"2001",
        	        "city1": 1,
        	        "city2": 2
        	       
        	    },{
        	    	"year":"2002",
        	    	"city1": 5,
          	        "city2": 4
        	       
        	    }, {
        	    	"year":"2003",
        	    	"city1": 4,
          	        "city2": 3
        	       
        	    }, {
        	    	"year":"2004",
        	    	  "city1": 9,
          	        "city2": 6
        	       
        	    },  {
        	    	"year":"2005",
        	    	  "city1": 7,
          	        "city2": 5
        	       
        	    }],
        	    "country": [{
        	    	"year":"2001",
        	        "city1": 10,
        	        "city2": 20
        	       
        	    },{
        	    	"year":"2002",
        	    	"city1": 25,
          	        "city2": 17
        	       
        	    }, {
        	    	"year":"2003",
        	    	"city1": 8,
          	        "city2": 2
        	       
        	    }, {
        	    	"year":"2004",
        	    	  "city1": 19,
          	        "city2": 16
        	       
        	    },  {
        	    	"year":"2005",
        	    	  "city1": 17,
          	        "city2": 15
        	       
        	    }],
        	    "state": [{
        	    	"year":"2001",
        	        "city1": 21,
        	        "city2": 23
        	       
        	    },{
        	    	"year":"2002",
        	    	"city1": 50,
          	        "city2": 40
        	       
        	    }, {
        	    	"year":"2003",
        	    	"city1": 14,
          	        "city2": 13
        	       
        	    }, {
        	    	"year":"2004",
        	    	  "city1": 29,
          	        "city2": 36
        	       
        	    },  {
        	    	"year":"2005",
        	    	  "city1": 37,
          	        "city2": 45
        	       
        	    }]
        	};
        
      
        oModel.setData(columnData);

        var oDataset = new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [{
                name: "fullyear",
                value: "{year}"
            }],
            measures: [{
                name: 'city1',
                value: '{city1}'
            },{
                name: "city2",
                value: "{city2}"
            }],
            data: {
                path: "/company"
            }
        });
        oVizFrame.setDataset(oDataset);
        oVizFrame.setModel(oModel);

         feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                'uid': "valueAxis",
                'type': "Measure",
                'values': ["city1","city2"]
            });

            feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({

                'uid': "categoryAxis",

                'type': "Dimension",

                'values': ["fullyear"]

            });

        oVizFrame.setVizProperties({
        	 valueAxis: {
                
                 title: {
                     visible: true,
                     text: "Revenue"
                 }
             },
            legend: {
                title: {
                    visible: false
                }
            },
            title: {
                visible: true,
                text: 'Revenue by Year and profit'
            }
        });
        oVizFrame.addFeed(feedValueAxis);

        oVizFrame.addFeed(feedCategoryAxis);

        //oVizFrame.addFeed(feedColor);

        oPopOver.connect(oVizFrame.getVizUid());


	},

    onChange : function(oEvent){
        var selectedKey = oEvent.getSource().mProperties.selectedIndex;
       
       if(selectedKey ===1){
        var oDataset = new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [{
                name: "fullyear",
                value: "{year}"
            }],
            measures: [{
                name: 'city1',
                value: '{city1}'
            },{
                name: "city2",
                value: "{city2}"
            }],
            data: {
                path: "/country"
            }
        });
        oVizFrame.setDataset(oDataset);
        oVizFrame.setModel(oModel);
       }else if(selectedKey ===2){
        var oDataset = new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [{
                name: "fullyear",
                value: "{year}"
            }],
            measures: [{
                name: 'city1',
                value: '{city1}'
            },{
                name: "city2",
                value: "{city2}"
            }],
            data: {
                path: "/state"
            }
        });
        oVizFrame.setDataset(oDataset);
        oVizFrame.setModel(oModel);
       }else if(selectedKey ===0){
        var oDataset = new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [{
                name: "fullyear",
                value: "{year}"
            }],
            measures: [{
                name: 'city1',
                value: '{city1}'
            },{
                name: "city2",
                value: "{city2}"
            }],
            data: {
                path: "/company"
            }
        });
        oVizFrame.setDataset(oDataset);
        oVizFrame.setModel(oModel);
       }
    }
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf view.View1
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf view.View1
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf view.View1
*/
//	onExit: function() {
//
//	}

});