sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("Example.controller.View1", {
	onclick:function(){
		alert("hi");
	}
	});

});