/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/App",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Browser",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Master",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Detail",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.drl.hrinfotype.masterdetail.view."
	});

	sap.ui.require([
		"com/drl/hrinfotype/masterdetail/test/integration/NavigationJourneyPhone",
		"com/drl/hrinfotype/masterdetail/test/integration/NotFoundJourneyPhone",
		"com/drl/hrinfotype/masterdetail/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});