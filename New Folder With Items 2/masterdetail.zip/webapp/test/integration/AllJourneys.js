/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 WorkScheduleCollection in the list
// * All 3 WorkScheduleCollection have at least one workScheduleWorkScheduleLegend

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/App",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Browser",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Master",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/Detail",
	"com/drl/hrinfotype/masterdetail/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.drl.hrinfotype.masterdetail.view."
	});

	sap.ui.require([
		"com/drl/hrinfotype/masterdetail/test/integration/MasterJourney",
		"com/drl/hrinfotype/masterdetail/test/integration/NavigationJourney",
		"com/drl/hrinfotype/masterdetail/test/integration/NotFoundJourney",
		"com/drl/hrinfotype/masterdetail/test/integration/BusyJourney",
		"com/drl/hrinfotype/masterdetail/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});