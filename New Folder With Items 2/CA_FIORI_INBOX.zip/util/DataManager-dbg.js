/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.utils.busydialog");

sap.ui.base.EventProvider.extend("cross.fnd.fiori.inbox.util.DataManager", {
	
	sMode: "TABLET",
	oModel: null,
	oPostActionModel: null,
	oDecisionOptions: {},
	oBaseController: null,
	_oScenarioConfig: null,
	FUNCTION_IMPORT_CONFIRM: "Confirm",
	FUNCTION_IMPORT_DECISION: "Decision",
	FUNCTION_IMPORT_DECISIONOPTIONS: "DecisionOptions",
	aSystemInfoCollection: null,
	aSubstitutionProfilesCollection: null,
	
	// startup (url) parameters
	sScenarioId: null,				// scenarioId
	bAllItems: null,				// allItems		values: true, false
	bIsMassActionEnabled: null,		// massAction	values: true, false
	bIsQuickActionEnabled: null,	// quickAction	values: true, false
	sDefaultSortBy: null,			// sortBy		value: taskCollection field name
	iListSize: 100,
	
	sCustomAttributeDefinitionNavProperty : "CustomAttributeDefinitionData",
	sClaimAction : "Claim",
	sReleaseAction : "Release",
	sTaskDefinitionCollectionName : "TaskDefinitionCollection",
	
	constructor : function(oModel, oBaseController) {
		
		sap.ui.base.EventProvider.apply(this);
		this.oBaseController = oBaseController;
		
		
		// handle startup URL parameters
		if (this.oBaseController.getOwnerComponent().getComponentData()) {
			var oStartupParameters = this.oBaseController.getOwnerComponent().getComponentData().startupParameters;
			if (oStartupParameters) {
				// scenarioId
				if (oStartupParameters.scenarioId && oStartupParameters.scenarioId.length > 0) {
					this.sScenarioId = oStartupParameters.scenarioId[0];
				}
				// allItems
				if (oStartupParameters.allItems && oStartupParameters.allItems.length > 0) {
					this.bAllItems = oStartupParameters.allItems[0] == "true" ? true : false;
				}
				// massAction
				if (oStartupParameters.massAction && oStartupParameters.massAction.length > 0) {
					if(oStartupParameters.massAction[0] == "true") {
						this.bIsMassActionEnabled = true;
					} else if(oStartupParameters.massAction[0] == "false") {
						this.bIsMassActionEnabled = false;
					}
				}
				// quickAction
				if (oStartupParameters.quickAction && oStartupParameters.quickAction.length > 0) {
					if (oStartupParameters.quickAction[0] == "true") {
						this.bIsQuickActionEnabled = true;
					} else if (oStartupParameters.quickAction[0] == "false") {
						this.bIsQuickActionEnabled = false;
					}
				}
				// sortBy
				if (oStartupParameters.sortBy && oStartupParameters.sortBy.length > 0) {
					this.sDefaultSortBy = oStartupParameters.sortBy[0];
				}
				// listSize
				if (oStartupParameters.listSize && oStartupParameters.listSize.length > 0) {
					this.iListSize = oStartupParameters.listSize[0];
				}
			}
		} else {
			// Application running in local dev environment
			this.sScenarioId = jQuery.sap.getUriParameters().get("scenarioId");
			this.bAllItems = jQuery.sap.getUriParameters().get("allItems") == "true" ? true : false;
			if (jQuery.sap.getUriParameters().get("massAction") == "true") {
				this.bIsMassActionEnabled = true;
			} else if (jQuery.sap.getUriParameters().get("massAction") == "false") {
				this.bIsMassActionEnabled = false;
			}
			if (jQuery.sap.getUriParameters().get("quickAction") == "true") {
				this.bIsQuickActionEnabled = true;
			} else if (jQuery.sap.getUriParameters().get("quickAction") == "false") {
				this.bIsQuickActionEnabled = false;
			}
			this.sDefaultSortBy = jQuery.sap.getUriParameters().get("sortBy");
			if (jQuery.sap.getUriParameters().get("listSize") > 0) {
				this.iListSize = jQuery.sap.getUriParameters().get("listSize");
			}
		}
		
		this.oModel = oModel;
		if (this.oModel) {
			this.oModel.setUseBatch(true);
		}
		
		this.oPostActionModel = this.oBaseController.getView().getModel("POSTACTION");
		
		this.oi18nResourceBundle = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle();
		this.oLoader = new sap.m.BusyDialog();

	},
	
	attachItemRemoved : function(oData, fnFunction, oListener) {
		this.attachEvent(cross.fnd.fiori.inbox.util.DataManager.M_EVENTS.ItemRemoved, oData, fnFunction, oListener);
		return this;
	},
	
	fireItemRemoved : function(mArguments) {
		this.fireEvent(cross.fnd.fiori.inbox.util.DataManager.M_EVENTS.ItemRemoved, mArguments);
		return this;
	},
	
	loadInitialAppData: function(fnSuccess) {
		if (!this.sScenarioId || !this.oModel) {
			// required
			return null;
		}
		var that = this;

		//Setup request for ConsumerScenario
		var sFilterValue = "(ConsumerType eq '" + jQuery.sap.encodeURL(this.sMode) + 
        "') and (UniqueName eq '" + jQuery.sap.encodeURL(this.sScenarioId) + "')";
		
		var fnSuccessCallback = function(oData) {
			that.oLoader.close();
			if (oData.hasOwnProperty("__batchResponses") && oData.__batchResponses.length == 2) {
				// Result from batch read
				var aErrors = [];
				var oFOBatchResp = oData.__batchResponses[0];
				if (oFOBatchResp.hasOwnProperty("data") && oFOBatchResp.statusCode >= '200' && oFOBatchResp.statusCode < '300') {
					// Successful request
					that._processFilterOptionsResult(oFOBatchResp.data);
					
				} else if (oFOBatchResp.hasOwnProperty("response") && oFOBatchResp.response.statusCode >= '400') {
					aErrors.push(JSON.parse(oFOBatchResp.response.body));
				}
				
				var oCSBatchResp = oData.__batchResponses[1];
				if (oCSBatchResp.hasOwnProperty("data") && oCSBatchResp.statusCode >= '200' && oCSBatchResp.statusCode < '300') {
					// Successful request
					fnSuccess(that._processConsumerScenarioResult(oCSBatchResp.data));
					
				} else if (oCSBatchResp.hasOwnProperty("response") && oCSBatchResp.response.statusCode >= '400') {
					aErrors.push(JSON.parse(oCSBatchResp.response.body));
				}
				
				that._handleBatchErrors(aErrors);
			}
			
		};
		
		var fnErrorCallback = function(oError) {
			that.oLoader.close();
			that.oDataRequestFailed(oError);
		};
		
		that.oLoader.open();
		//CSRF token validation/refresh handled inside - here it would not be needed because token is valid at app startup
		var aRequests = [ "/FilterOptionCollection","/ConsumerScenarioCollection" ];
		that.fireBatch({aPaths:aRequests ,aUrlParameters:["", "$filter=" + encodeURIComponent(sFilterValue) ], 
			sMethod:"GET",sBatchGroupId:"FilterOptionsAndConsumerScenarioCollection",numberOfRequests:aRequests.length,fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback});
		
	},
	
	fireBatch:function(mParameters){
		this.oModel.setDeferredBatchGroups([mParameters.sBatchGroupId]);
		var sPath;
		var oEntry = {
	    	batchGroupId : mParameters.sBatchGroupId
	    };

		for (var i = 0; i < mParameters.numberOfRequests; i++) {
			if (mParameters.aUrlParameters) {
				oEntry.urlParameters = mParameters.aUrlParameters[i];
			}
			if (mParameters.aProperties) {
				oEntry.properties = mParameters.aProperties[i];
			}
			if (mParameters.sPath) {
				sPath = mParameters.sPath;
			} 
			else if (mParameters.aPaths) {
				sPath = mParameters.aPaths[i];
			}
			if (!jQuery.sap.startsWith(sPath, "/")) {
				sPath = "/" + sPath;
			}
			if (mParameters.sMethod == "GET") {
				this.oModel.read(sPath, oEntry);
			} 
			else if (mParameters.sMethod == "POST") {
				oEntry.changeSetId = "changeSetId" + i;
				this.oModel.createEntry(sPath, oEntry);
			}
			else if (mParameters.sMethod == "DELETE") {
				oEntry.changeSetId = "changeSetId" + i;
				this.oModel.remove(sPath, oEntry);
			}
			// to call FunctionImport in post, use this method
			else if (mParameters.sMethod == "FUNCTIONIMPORT") {
				oEntry.changeSetId = "changeSetId" + i;
				oEntry.method = "POST";
				this.oModel.callFunction(sPath, oEntry);
			}
			
		}
		
		this.oModel.submitChanges({batchGroupId : mParameters.sBatchGroupId, success : mParameters.fnSuccessCallback , error : mParameters.fnErrorCallback });
	},
	
	_handleBatchErrors: function(aErrors, sCustomMessage) {
		if (aErrors.length > 0) {
			if (sCustomMessage) {
				
				var sDetails = "";
				jQuery.each(aErrors, $.proxy(function(index, oError) {
					sDetails += this.getErrorMessage(oError) + "\n";
				}, this));
				var oError = {
						customMessage: {
							message: sCustomMessage,
							details: sDetails
						}
				};
				
			} else {
				
				var sMessage = "";
				var sBodyValue = "";
				for (var i = 0; i < aErrors.length; i++) {
					if (aErrors[i].hasOwnProperty("error")) {
						sMessage += aErrors[i].error.message.value;
					} else if (aErrors[i].hasOwnProperty("response")) {
						sMessage += aErrors[i].message;
						var body = JSON.parse(aErrors[i].response.body);
						sBodyValue += body.error.message.value + "\n";
					}
					if (i < aErrors.length-1) {
						sMessage += "\n";
					}
				}
				
				var oError = {
						message: sMessage,
						response: {
							body: sBodyValue
						}
				};
			}
			
			this.oDataRequestFailed(oError);
		}
	},
	
	processListAfterAction : function (sOrigin, sInstanceId) {
		// find the next item to select
		this.oBaseController.findNextVisibleItem(sOrigin, sInstanceId);
		// processing required in S2.controller's handleMasterRequestCompleted method
        this.oModel.bDataChangeProcessingRequired = true;
        
        if(this.oModel.bFullRefreshNeeded) {
        	this.oModel.refresh();
        	this.oModel.bFullRefreshNeeded = false;
        	this.fireItemRemoved();
        } else {
        	// to update the changed task collection
        	this.fnRefreshSingleTaskData(sOrigin, sInstanceId);
        }
	},
	
	clearDecisionOptionsCache: function() {
		this.oDecisionOptions = {};
	},
    
    _processConsumerScenarioResult: function(oData) {
    	if (oData.results.length == 0) {
			// nothing found
			this._scenarioRequestFailed();
			return;
		} 
    	
		var oMainParseRegexp = new RegExp(";o=([A-Z0-9_]+)/.+\\?\\$filter=(.+)"); 
		var oFilterParseRegexp = new RegExp("TaskDefinitionID eq '(.+)'");
    	
    	// after merge only one entry shall exists with maybe different scenario ids
    	
    	var oConsumerScenarioData = {};
		var oScenarioObjects = {};
		
    	jQuery.each(oData.results, function(iIndex, oEntry) {
			var oScenario = oScenarioObjects[oEntry.UniqueName];
			if (!oScenario) {
				oScenario = oEntry;
				oScenario.ScenarioServiceInfos = [];
				oScenarioObjects[oScenario.UniqueName] = oScenario;
			} else {
				oScenario.TotalItems = oScenario.TotalItems + oEntry.TotalItems;
			}
			
			var aResult = oMainParseRegexp.exec(oEntry.ScenarioServiceURL);
			if (aResult) {
				var sOrigin = aResult[1];
				var aTaskDefinitionIDs = [];
				
				var aFilterExprs = aResult[2].split(" or ");
				for (var i = 0; i < aFilterExprs.length; i++) {
					aResult = oFilterParseRegexp.exec(aFilterExprs[i]);
					if (aResult)
						aTaskDefinitionIDs.push(aResult[1]);
				}
				
				if (aTaskDefinitionIDs.length > 0) {				
					var oScenarioServiceInfo = {
						Origin: sOrigin,
						TaskDefinitionIDs: aTaskDefinitionIDs
					};
				
					oScenario.ScenarioServiceInfos.push(oScenarioServiceInfo);
				}
			}
		});
    	
    	//this loop is required to bring the scenario object one level up
    	//the property name is the unique name of the scenario that cannot be used as getter
		jQuery.each(oScenarioObjects, function(iIndex, oScenario) {
			oConsumerScenarioData = oScenario;
		});
		this._oScenarioConfig = oConsumerScenarioData;
		return oConsumerScenarioData;
    },
    
    getScenarioConfig: function() {
    	var oConfig = this._oScenarioConfig;
    	
    	if (oConfig == null) {
    		oConfig = {};
    	}
    	oConfig.AllItems = this.bAllItems;
    	if (this.bIsMassActionEnabled != null) { 
    		// if we have url parameter, than it overrides the backend config
    		oConfig.IsMassActionEnabled = this.bIsMassActionEnabled;
    	}
    	if (oConfig.IsMassActionEnabled === undefined) {
    		// if there is no customizing nor url parameter, the default is true
    		oConfig.IsMassActionEnabled = true;
    	}
    	if (this.bIsQuickActionEnabled != null) {
    		// if we have url parameter, than it overrides the backend config
    		oConfig.IsQuickActionEnabled = this.bIsQuickActionEnabled;
    	}
    	if (oConfig.IsQuickActionEnabled === undefined) {
    		// if there is no customizing nor url parameter, the default is true
    		oConfig.IsQuickActionEnabled = true;
    	}
    	if (this.sDefaultSortBy != null) {
    		oConfig.SortBy = this.sDefaultSortBy;
    	}
    	if ((!oConfig.SortBy) && (oConfig.UniqueName === undefined)) {
    		// set the default sorting if on scenarioId is given
    		oConfig.SortBy = "CreatedOn";
    	}
    	if ((!oConfig.DisplayName) && (oConfig.AllItems)) {
    		oConfig.DisplayName = this.oi18nResourceBundle.getText("ALL_ITEMS_SCENARIO_DISPLAY_NAME");
    	}
    	
    	return oConfig;
    },
    
    getListSize: function() {
    	return this.iListSize;
    },
    
    _scenarioRequestFailed: function() {
    	var oError = {
    					customMessage: {
    						message: this.oi18nResourceBundle.getText("DataManager.scenarioReadFailed"),
    						details: this.oi18nResourceBundle.getText("DataManager.scenarioReadFailedDetail")
    					}
    	};
    	this.oDataRequestFailed(oError);
    },
    
    sendMultiAction: function(aItems, oDecisionOption, sNote, onSuccess, onError) {
    	var aRequests = [];
    	var aParams = [];
    	var that = this;
    	for (var i = 0; i < aItems.length; i++) {
    		var oItem = aItems[i];
       		var sParams = "SAP__Origin='"+ jQuery.sap.encodeURL(oItem.SAP__Origin) +
			"'&InstanceID='" + jQuery.sap.encodeURL(oItem.InstanceID) +
			"'&DecisionKey='" + jQuery.sap.encodeURL(oDecisionOption.DecisionKey) + "'";
       		
       		if (sNote && sNote.length > 0)
       			sParams += "&Comments='" + jQuery.sap.encodeURL(sNote) + "'";
       		aRequests.push(this.FUNCTION_IMPORT_DECISION);
    		aParams.push(sParams);
    	}
    	
    	var fnSuccessCallback = function(oData) {
			that.oLoader.close();
			
			var aBatchResponses = oData.__batchResponses;
			var aSuccessList = [];
			var aErrorList = [];
			
			for (var i = 0; i < aBatchResponses.length; i++) {
				var oBatchResponse = aBatchResponses[i];
				var oItem = aItems[i];
				var bSuccess = false;
				var oItemStatus = {
						SAP__Origin: oItem.SAP__Origin,
						InstanceID: oItem.InstanceID
				};
				
				if (oBatchResponse.hasOwnProperty("__changeResponses")) {
					var oChangeResponse = oBatchResponse.__changeResponses[0];
					
					if (oChangeResponse.statusCode >= "200" && oChangeResponse.statusCode < "300")
						bSuccess = true;
				}
				
				if (bSuccess) {
					oItemStatus.message = that.oi18nResourceBundle.getText("multi.processed");
					aSuccessList.push(oItemStatus);
				} else {
					oItemStatus.message = JSON.parse(oBatchResponse.response.body).error.message.value;
					aErrorList.push(oItemStatus);
				}
			}
			
			if (onSuccess)
				onSuccess(aSuccessList, aErrorList);
    	};
    	
    	var fnErrorCallback = function(oError) {
    		that.oLoader.close();
			that.oDataRequestFailed(oError);
			
			if (onError)
				onError(oError);
    	};
    	
		that.oLoader.open();
		that.fireBatch({aPaths:aRequests ,aUrlParameters:aParams, sMethod:"POST",sBatchGroupId:"ImportDecisions1",numberOfRequests:aRequests.length,
			fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback});
    },
    
    readDetailWithDecisionOptions: function(sCtxPath, aExpandEntitySets, sOrigin, sInstanceID, fnSuccess) {
    	if (!sCtxPath || !sOrigin || !sInstanceID) {
			// required
			return null;
		}
		var that = this;
		var aDecisionOptions = [];
		
		//Setup request for FilterOptions
		var aRequests = [];
		var aParams = [];
		

		for(var i=0;i<aExpandEntitySets.length;i++){
			aRequests.push(sCtxPath+"/" +aExpandEntitySets[i]);
			aParams.push("");
		}
		
		//Decision options request setup as second inner request
    	if (!this.oDecisionOptions[sOrigin + sInstanceID]) {
    		//not in the cache yet
    		var sParams = "SAP__Origin='"+ jQuery.sap.encodeURL(sOrigin) + 
			"'&InstanceID='" + jQuery.sap.encodeURL(sInstanceID) + "'";
    		aRequests.push("/" + this.FUNCTION_IMPORT_DECISIONOPTIONS);
    		aParams.push(sParams);
    		that.bDecisionOptionsCached = false;
    	}
    	else {
    		//result from the cache
    		aDecisionOptions = this.oDecisionOptions[sOrigin + sInstanceID];
    		that.bDecisionOptionsCached = true;
    	}
		
		var fnSuccessCallback = function(oData) {
			if (oData.hasOwnProperty("__batchResponses") && oData.__batchResponses.length >= 1) {
				
				var oTaskData = that.oModel.getProperty(sCtxPath);
				for(var i=0;i<aExpandEntitySets.length;i++){
					oTaskData[aExpandEntitySets[i]] = oData.__batchResponses[i].data;
				}
				oData.__batchResponses[0].data = oTaskData; // taskCollection detail data
				if(!that.bDecisionOptionsCached){
					oData.__batchResponses[1] = oData.__batchResponses[oData.__batchResponses.length-1]; //decision options data
					oData.__batchResponses.splice(2,oData.__batchResponses.length-1);
				}
				else
					oData.__batchResponses.splice( 1, oData.__batchResponses.length-1);
				
				// Result from batch read
				var aErrors = [];
				var bIsSecondDetailRequest = false;
				
				//Decision options result must be checked first because it's needed for the details results to call the success callback 
				if (!that.bDecisionOptionsCached) {
					//Decision options data was requested as second inner request
					var oDOBatchResp = oData.__batchResponses[1];
					if (oDOBatchResp.hasOwnProperty("data") && oDOBatchResp.statusCode >= '200' && oDOBatchResp.statusCode < '300') {
						aDecisionOptions = oDOBatchResp.data.results;
				    	//Caching the decision options for S2 and S3
						that.oDecisionOptions[sOrigin + sInstanceID] = oDOBatchResp.data.results;
						
					} else if (oDOBatchResp.hasOwnProperty("response") && oDOBatchResp.response.statusCode >= '400') {
						aErrors.push(JSON.parse(oDOBatchResp.response.body));
					}
				} 
				
				//Details response processing
				//Details data was requested as first inner request
				var oDetailsBatchResp = oData.__batchResponses[0];
				if (oDetailsBatchResp.hasOwnProperty("data") && oDetailsBatchResp.statusCode >= '200' && oDetailsBatchResp.statusCode < '300') {
					that.oLoader.close();
					//decision options data already available from server or cache at this point, call success callback
					fnSuccess(oDetailsBatchResp.data, aDecisionOptions);
					
				} else if (oDetailsBatchResp.hasOwnProperty("response") && oDetailsBatchResp.response.statusCode >= '400') {
					//detail fetch with expand Comments/CreatedByDetails failed try without it
					bIsSecondDetailRequest = true;
					that._doReadDetail(sCtxPath, aExpandEntitySets, false,
			    			function(oData) {
								//decision options data already available from server or cache at this point, call success callback
								that.oLoader.close();
								fnSuccess(oData, aDecisionOptions);
							},
			    			function(oError) {
								//second detail fetch without expand Comments/CreatedByDetails also failed
								that.oLoader.close();
								aErrors.push(oError);
								that._handleBatchErrors(aErrors);
			    			}
					);
				}
				
				if (bIsSecondDetailRequest) {
					//detail fetch without expand Comments/CreatedByDetails ongoing, no error processing at this point
					return;
				}

				that._handleBatchErrors(aErrors);
			}
		};
		
		var fnErrorCallback = function(oError) {
			//Entire batch request failed
			that.oLoader.close();
			that.oDataRequestFailed(oError);
		};
		
		that.oLoader.open();
		//CSRF token validation/refresh handled inside
		that.fireBatch({aPaths:aRequests ,aUrlParameters:aParams, sMethod:"GET",sBatchGroupId:"DetailWithDecisionOptions",numberOfRequests:aRequests.length,
		fnSuccessCallback:jQuery.proxy(fnSuccessCallback,this),fnErrorCallback:fnErrorCallback});
		
    },
    
    
    // read custom attributes definitions from TaskDefinitionCollection
    readCustomAttributeDefinitionData:function( sOrigin, sTaskDefinitionID, fnSuccessCallback ){
    	var that = this;
    	var sContextPath = "/" + that.sTaskDefinitionCollectionName + "(SAP__Origin='" + jQuery.sap.encodeURL(sOrigin) +"',TaskDefinitionID='" + jQuery.sap.encodeURL(sTaskDefinitionID) +"')";
    	var sExpand = { $expand: that.sCustomAttributeDefinitionNavProperty };
    	
    	var fnSuccess = function(data, response){
    		//fix to handle crashing when task has no custom attribute definition but has custom attributes
    		if(data.CustomAttributeDefinitionData.results.length==0){
    			jQuery.sap.log.error("No definition found for Custom Attributes.");
    			return;
    		}
    		fnSuccessCallback(data);
    	};
    	var fnErrorCallback = function( oError ) {
			that.oDataRequestFailed( oError );
		};
    	this.oDataRead(sContextPath,
    			null, 
    			sExpand, 
    			true,
    			fnSuccess,
    			fnErrorCallback);
    	
    },
    
	readDecisionOptions: function(sOrigin, sInstanceID, onSuccess, onError) {

		//Try to read the decision options from cache
		if (this.oDecisionOptions[sOrigin + sInstanceID]) {
			if (onSuccess) {
				onSuccess(this.oDecisionOptions[sOrigin + sInstanceID]);
			}
			return;
		}

		var that = this;
		that.oLoader.open();
		this.oDataRead("/" + this.FUNCTION_IMPORT_DECISIONOPTIONS,
			null,
			{SAP__Origin: "'"+sOrigin+"'",
			InstanceID : "'"+sInstanceID+"'"
			},
			false,
			function (oData, oResponse) {
				that.oLoader.close();
				if (oData && oData.results) {
					// store the results in the cache
					that.oDecisionOptions[sOrigin + sInstanceID] = oData.results;
					if (onSuccess) {
						onSuccess(oData.results);
					}
				}
			},
			function (oError) {
				that.oLoader.close();
				that.oDataRequestFailed(oError);
				if (onError) {
					onError(oError);
				}
			}
		);
	},
    
    /**
     * Private method for repeating the detail request in batch response without Comments/CreatedByDetails
     */
    _doReadDetail: function(sContextPath, aExpandEntitySets, bIncludeCreatedByDetails, fnSuccess, fnError) {
    	var sExpand;
    	
    	if (!bIncludeCreatedByDetails)
    		var i = aExpandEntitySets.indexOf("Comments/CreatedByDetails");
    		if (i >= 0) {
    			aExpandEntitySets[i] = "Comments";
    		}
    	sExpand = {$expand:aExpandEntitySets.join(",")};
    	this.oDataRead(sContextPath,
    			null, 
    			sExpand, 
    			true,
    			fnSuccess,
    			fnError);
    },
    
    readPotentialOwners: function(sOrigin, sInstanceID, fnSuccess, fnError) {
    	var that = this;
    	that.oLoader.open();
    	this.oDataRead("/TaskCollection(SAP__Origin='" + jQuery.sap.encodeURL(sOrigin) + 
    			"',InstanceID='" + jQuery.sap.encodeURL(sInstanceID) + "')/PotentialOwners",
    			null, 
    			null, 
    			true,
    			function(oData, oResponse) {
    				that.oLoader.close();
    				if (oData) {
						if (fnSuccess) {
							fnSuccess(oData);
						}
					}
    			},
    			function(oError) {
    				that.oLoader.close();
    				that.oDataRequestFailed(oError);
    				if (fnError)
    					fnError(oError);
    			}
    	);
    },
    
    /**
     * method to read user info collection for a user
     */
    readUserInfo: function(sSAP_Origin, sUserID, fnSuccess, fnError) {
    	var that = this;
    	that.oLoader.open();
    	this.oDataRead("/UserInfoCollection(SAP__Origin='"+ sSAP_Origin + "',UniqueName='" + sUserID + "')",
    			null, 
    			null, 
    			true,
    			function(oData, oResponse) {
    				that.oLoader.close();
    		  		if (oData) {
    		  			fnSuccess(oData);
    		  		}
    			},
    			function(oError) {
    				that.oLoader.close();
    				that.oDataRequestFailed(oError);
    				if (fnError)
    					fnError(oError);
    			});
    },

	_processFilterOptionsResult: function(oData) {
		this.oPriorityMap = {};
		this.oStatusMap = {};
		var oNameMap;
		
		jQuery.each(oData.results, $.proxy(function(iIndex, oEntry) {
			if (oEntry.Type == "PRIORITY") {
				if (!this.oPriorityMap.hasOwnProperty(oEntry.SAP__Origin))
					this.oPriorityMap[oEntry.SAP__Origin] = {};
			
				oNameMap = this.oPriorityMap[oEntry.SAP__Origin];
				oNameMap[oEntry.TechnicalName] = oEntry.DisplayName;
			} 
			else if (oEntry.Type == "STATUS") {
				if (!this.oStatusMap.hasOwnProperty(oEntry.SAP__Origin))
					this.oStatusMap[oEntry.SAP__Origin] = {};
			
				oNameMap = this.oStatusMap[oEntry.SAP__Origin];
				oNameMap[oEntry.TechnicalName] = oEntry.DisplayName;
			}
		}, this));
	},
	
	getPriorityDisplayName : function(sOrigin, sTechnicalName) {
		  var oNameMap;
		  
		  if (sOrigin == null || sTechnicalName == null)
			  throw "sOrigin and sTechnicalName mustn't be null";
		  
		  if (this.oPriorityMap && this.oPriorityMap.hasOwnProperty(sOrigin)) {
			  oNameMap = this.oPriorityMap[sOrigin];
			  if (oNameMap.hasOwnProperty(sTechnicalName))
				  return oNameMap[sTechnicalName];
		  }
		  
		  return null;
	 },
	  
	 getStatusDisplayName : function(sOrigin, sTechnicalName) {
		 var oNameMap;
			  
		  if (sOrigin == null || sTechnicalName == null)
			  throw "sOrigin and sTechnicalName mustn't be null";
			  
		  if (this.oStatusMap && this.oStatusMap.hasOwnProperty(sOrigin)) {
			  oNameMap = this.oStatusMap[sOrigin];
			  if (oNameMap.hasOwnProperty(sTechnicalName))
				  return oNameMap[sTechnicalName];
		  }
			  
		  return null;
	 },	 
	 getErrorMessageKey: function(sFIName) {
		
		 switch (sFIName) {
		 	case this.sReleaseAction:
				return "dialog.error.release";
				break;
			case this.sClaimAction:
				return "dialog.error.claim";
				break;
			
			default:
				return "dialog.error.generic.action";
		 }
		
	 },

	 sendAction: function(sFIName, oDecision, sNote, fnSuccess, fnError) {
		 
		 this.oModel.bFullRefreshNeeded = true;
		 
         var sErrorMessage = this.oi18nResourceBundle.getText(this.getErrorMessageKey(sFIName));
        
         var oUrlParams = {
                                        SAP__Origin: "'" + encodeURIComponent(oDecision.SAP__Origin) + "'",
                                        InstanceID: "'" + (oDecision.InstanceID) + "'"
        };
        
         if (oDecision.DecisionKey) {
                        oUrlParams.DecisionKey = "'" + oDecision.DecisionKey + "'";
        }
          
         if (sNote && sNote.length > 0) {
                        oUrlParams.Comments = "'" + sNote + "'";
        }
        
         this._performPost("/" + sFIName, oDecision.SAP__Origin, oUrlParams,
                                        $.proxy(function () {
                                                        // remove the processed item from the list
                                                        this.processListAfterAction(oDecision.SAP__Origin, oDecision.InstanceID);
                                                        // call the original success function
                                                        if (fnSuccess) {
                                                                        fnSuccess();
                                                        }
                                        }, this, oDecision, fnSuccess),
                                        $.proxy(function (oError) {
                                                        // call the original error function
                                                        if (fnError) {
                                                                        fnError(oError);
                                                        }
                                        }, this), sErrorMessage);
          
	 },

	  
	  doForward: function(sOrigin, sInstanceID, sUserId, sNote, fnSuccess, fnError) {
		  
		  this.oModel.bFullRefreshNeeded = true;
		  
		  var oUrlParams = {
			SAP__Origin : "'" + sOrigin + "'",
			InstanceID : "'" + sInstanceID + "'",
			ForwardTo : "'" + sUserId + "'",
			Comments : "'" + sNote + "'"
		  };

		  this._performPost("/Forward", sOrigin, oUrlParams, 
				  $.proxy(function () {
					  // remove the processed item from the list
					  this.processListAfterAction(sOrigin, sInstanceID);
					  // call the original success function
					  fnSuccess();
				  }, this), fnError, this.oi18nResourceBundle.getText("dialog.error.forward"));
	  },
	  
	 doMassForward: function(aItems, oAgent, sNote, fnSuccess, fnError) {
		  
		var aRequests = [];
		var aParams = [];
		var that = this;
		
		for (var i = 0; i < aItems.length; i++) {
			var oItem = aItems[i];
			var sPath = "/Forward";
			var sParams = "SAP__Origin='"+ jQuery.sap.encodeURL(oItem.SAP__Origin) +
			"'&InstanceID='" + jQuery.sap.encodeURL(oItem.InstanceID) +
			"'&ForwardTo='" + jQuery.sap.encodeURL(oAgent.UniqueName) + "'";
			
			if (sNote && sNote.length > 0)
				sParams += "&Comments='" + jQuery.sap.encodeURL(sNote) + "'";
			
			aRequests.push(sPath);
			aParams.push(sParams);
		}
		
    	var fnSuccessCallback = function(oData) {
			that.oLoader.close();
			var aBatchResponses = oData.__batchResponses;
			var aSuccessList = [];
			var aErrorList = [];
			
			for (var i = 0; i < aBatchResponses.length; i++) {
				var oBatchResponse = aBatchResponses[i];
				var oItem = aItems[i];
				var bSuccess = false;
				var oItemStatus = {
						SAP__Origin: oItem.SAP__Origin,
						InstanceID: oItem.InstanceID
				};
				
				if (oBatchResponse.hasOwnProperty("__changeResponses")) {
					var oChangeResponse = oBatchResponse.__changeResponses[0];
					
					if (oChangeResponse.statusCode >= "200" && oChangeResponse.statusCode < "300")
						bSuccess = true;
				}
				
				if (bSuccess) {
					oItemStatus.message = that.oi18nResourceBundle.getText("multi.processed");
					aSuccessList.push(oItemStatus);
				} else {
					oItemStatus.message = JSON.parse(oBatchResponse.response.body).error.message.value;
					aErrorList.push(oItemStatus);
				}
			}
			
			if (fnSuccess)
				fnSuccess(aSuccessList, aErrorList, oAgent);
    	};
    	
    	var fnErrorCallback = function(oError) {
			that.oLoader.close();
			that.oDataRequestFailed(oError);
			
			if (fnError)
				fnError(oError);
    	};
    	
		that.oLoader.open();
		that.fireBatch({aPaths:aRequests ,aUrlParameters:aParams, sMethod:"POST",sBatchGroupId:"massForward",numberOfRequests:aRequests.length,
			fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback});

	  },
	  
	  searchUsers: function(sOrigin, sSearchPattern, iMaxResults, fnSuccess) {
		  this.oLoader.open();
		  var that = this;
		  var oParams = {
				  SAP__Origin: "'" + sOrigin + "'",
				  SearchPattern: "'" + sSearchPattern + "'",
				  MaxResults: iMaxResults
		  };
		  this.oDataRead("/SearchUsers",
					null,
					oParams,
					false,
					function (oData, oResponse) {
						that.oLoader.close();
						if (oData && oData.results) {
							if (fnSuccess) {
								fnSuccess(oData.results);
							}
						}
					},
					function (oError) {
						that.oLoader.close();
						that.oDataRequestFailed(oError);
					}
			);
	  },	  
	  
	  _performPost: function(sPath, sOrigin, oUrlParams, fnSuccess, fnError, sErrorMsg) {
		  this.oLoader.open();
						this.oDataCreate(
							sPath,
							sOrigin,
							oUrlParams,
							undefined,
							undefined,
							// the success callback
							$.proxy(function(oData, oResponse) {
								this.oLoader.close();
								$.sap.log.info("successful action");
								if (fnSuccess) {
									$.proxy(fnSuccess(oData, oResponse), this);
								}
							}, this),
							// the error callback - TODO refine with nice error popup
							$.proxy(function(oError) {
								this.oLoader.close();
								// creating a custom message to display
								if (sErrorMsg) {
									
									var sDetails = this.getErrorMessage(oError);
									var oError = {
											customMessage: {
												message: sErrorMsg,
												details: sDetails
											}
									
									};
								}else{
									var sDetails = this.getErrorMessage(oError);
									var oError = {
											customMessage: {
												message: oError.message,
												details: sDetails
											}
									
									};
									oError.customMessage.details = sDetails;
								}
			    				this.oDataRequestFailed(oError);
			    				if (fnError)
			    					fnError(oError);
							}, this)
						);
	  },
	  
	  oDataRequestFailed: function(oError) {
		  var sMessage;
		  var sDetails;
		  
		  if (oError.hasOwnProperty("customMessage")) {
			  sMessage = oError.customMessage.message;
			  sDetails = oError.customMessage.details;		
		  } else {
			  if (oError.response && oError.response.statusCode == "0"){
				  sMessage = this.oi18nResourceBundle.getText("DataManager.connectionError");
			  }else{
				  sMessage = this.oi18nResourceBundle.getText("DataManager.HTTPRequestFailed");
			  }
			  if (oError.response && oError.response.body != "" && oError.response.statusCode == "400") {
				  var oParsedError = JSON.parse(oError.response.body);
				  sDetails = oParsedError.error.message.value;
			  } else {
				  sDetails = oError.response ? oError.response.body : null;
			  }
		  }
		  
		  var oParameters = {message: sMessage,
		                     responseText: sDetails};
		  
		  this.oModel.fireRequestFailed(oParameters);
	  },
	  
	  oDataRead: function(sPath, oContext, oUrlParams, bAsync, fnSuccess, fnError) {
		  this.oModel.read( sPath, {urlParameters:oUrlParams, success:fnSuccess, error:fnError});
	  },

	  oDataCreate: function(sPath, sOrigin, oUrlParams, oData, oContext, fnSuccess, fnError) {
          var oSettings = {
                                          context : oContext,
                                          success: fnSuccess,
                                          error: fnError,
                                          urlParameters: oUrlParams
          };
          this.oPostActionModel.create(sPath, oData, oSettings);
	  },

	  
	  oDataAddOperationsAndSubmitBatch: function(aReadOperations, aChangeOperations, fnSuccess, fnError, bAsync) {
		  
		  this.oPostActionModel.clearBatch();
			  
		  if (aReadOperations)
			  this.oPostActionModel.addBatchReadOperations(aReadOperations);
			  
		  if (aChangeOperations) {
			  // Embed change operations in different change sets.
			  
			  for (var i = 0; i < aChangeOperations.length; i++)
				  this.oPostActionModel.addBatchChangeOperations([aChangeOperations[i]]);
		  }
		  
		  this.oPostActionModel.submitBatch(fnSuccess, fnError, bAsync);
	  },
	  
	  oDataConvertHeaders: function(sConvertHeader, mHeaders) {
	      for (var sHeaderName in mHeaders) {
	    	  if (sHeaderName !== sConvertHeader && sHeaderName.toLowerCase() === sConvertHeader.toLowerCase()) {
	    		  var oHeaderValue = mHeaders[sHeaderName];
	              delete mHeaders[sHeaderName];
	              mHeaders[sConvertHeader] = oHeaderValue;
	              break;
	          }
	      }
	  },
	  
	  addComment: function(sSAP__Origin, sInstanceID, sComment, fnSuccess, fnError) {
		  var oUrlParams = {
			SAP__Origin : "'" + sSAP__Origin + "'",
			InstanceID : "'" + sInstanceID + "'",
			Text : "'" + sComment + "'"
		  };

		  this._performPost("/AddComment", sSAP__Origin, oUrlParams,
					$.proxy(function () {
						// remove the processed item from the list
						this.processListAfterAction(sSAP__Origin, sInstanceID);
						// call the original success function
						if (fnSuccess) {
							fnSuccess();
						}
					}, this, fnSuccess),
					$.proxy(function () {
						// remove the processed item from the list
						this.processListAfterAction(sSAP__Origin, sInstanceID);
						// call the original error function
						if (fnError) {
							fnError();
						}
					}, this), this.oi18nResourceBundle.getText("dialog.error.addComment")
		  );		  
	  },
	  
	  _createSubstitutionRule: function(oAddSubstituteEntry, aProviders, fnSuccess, fnError) {
		  var aRequests = [];
		  var aParams = [];
		  var aPropertiesArray = [];
          var that = this;
          //looping through all the backends where the substitution rule was not created successfully
          jQuery.each(aProviders, function(i, sProvider) {
                    var oTempEntry = {};
                    oTempEntry = jQuery.extend(true, {}, oAddSubstituteEntry);
                    oTempEntry.SAP__Origin = sProvider;
                    aRequests.push("/SubstitutionRuleCollection");
                    aParams.push("");
                    aPropertiesArray.push(oTempEntry );
                    
          });
          
          var fnSuccessCallback = function(oData) {
                   that.oLoader.close();
                    var aBatchResponses = oData.__batchResponses;
                    var aSuccessList = [];
                    var aErrorList = [];
                    
                    jQuery.each (aBatchResponses, function (index, oBatchResponse) {
                    	var bSuccess = false;
                    	if (oBatchResponse.hasOwnProperty("__changeResponses")) {
                    		var oChangeResponse = oBatchResponse.__changeResponses[0];
                    		if (oChangeResponse.statusCode >= "200" && oChangeResponse.statusCode < "300")
                    			bSuccess = true;
                    	}
                    	if (bSuccess) {
                    		// pushing index to aSuccessList
                    		aSuccessList.push(index);
                    	} else {
                    		aErrorList.push(oBatchResponse);
                    	}
                    });
                    
                    //display error message if substitution rule creation fails in one of the backends
                    if(aErrorList.length>0) {
                    	var sErrorMessage = aSuccessList.length > 0 ? that.oi18nResourceBundle.getText("substn.create.multi.error") : that.oi18nResourceBundle.getText("substn.create.error");
                    	that._handleBatchErrors(aErrorList, sErrorMessage);
                    }    
                    //show a success message if rule was created successfully in all the backends and perform a refresh
                    if (fnSuccess) {
                    	  fnSuccess(aSuccessList, aErrorList);
                    }
                    that.oLoader.close();
          };
          
          var fnErrorCallback = function(oError) {
                   that.oLoader.close();
                    that.oDataRequestFailed(oError);
                    if (fnError) {
                    	fnError(oError);
                    }
         };
         that.oLoader.open();
         that.fireBatch({aPaths:aRequests ,aUrlParameters:aParams, sMethod:"POST",sBatchGroupId:"ImportDecisions",numberOfRequests:aRequests.length,fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback,aProperties:aPropertiesArray});
      },
	  
	  readSubstitutionData : function(fnSuccess) {
			var that = this;
			
			var aRequests = [];
			var aParams = [];
			
			//Fetch the Substitution Rules
			aRequests.push("/SubstitutionRuleCollection");
			aParams.push("");
			
			//System Collection setup as first inner request
	    	if (!this.aSystemInfoCollection) {
	    		//not in the cache yet
	    		aRequests.push("/SystemInfoCollection");
	    		aParams.push("");
	    	} 
			
	    	//System Collection setup as second inner request
	    	if (!this.aSubstitutionProfilesCollection) {
	    		//not in the cache yet
				aRequests.push("/SubstitutionProfileCollection");
				aParams.push("");
	    	} 
			
    		var fnSuccessCallback = function(oData) {
    			if (oData.hasOwnProperty("__batchResponses") && oData.__batchResponses.length >= 1) {
    				// Result from batch read
    				var aErrors = [];
    				
    				if (oData.__batchResponses.length == 3) {

    					//Substitution Profile options data was requested as third inner request
    					var oSPBatchResp = oData.__batchResponses[2];
    					// if one of the call in batch request fails, do not cache the data
    					if (!(aErrors.length > 0) && oSPBatchResp.hasOwnProperty("data") && oSPBatchResp.statusCode >= '200' && oSPBatchResp.statusCode < '300') {
    						//Caching the Substitution Profiles
    						that.aSubstitutionProfilesCollection = oSPBatchResp.data.results;
    					} else if (oSPBatchResp.hasOwnProperty("response") && oSPBatchResp.response.statusCode >= '400') {
    						aErrors.push(JSON.parse(oSPBatchResp.response.body));
    					}
    					
    					//System Info data was requested as second inner request
    					var oSIBatchResp = oData.__batchResponses[1];
    					// if one of the call in batch request fails, do not cache the data
    					if (!(aErrors.length > 0) && oSIBatchResp.hasOwnProperty("data") && oSIBatchResp.statusCode >= '200' && oSIBatchResp.statusCode < '300') {
    						//Caching the System Info
    						that.aSystemInfoCollection = oSIBatchResp.data.results;
    					} else if (oSIBatchResp.hasOwnProperty("response") && oSIBatchResp.response.statusCode >= '400') {
    						aErrors.push(JSON.parse(oSIBatchResp.response.body));
    					}
    				} 
    				
    				//Substitution Rules data was requested as first inner request
    				var oSRBatchResp = oData.__batchResponses[0];
    				// call fnSuccess only if all the calls in the batch request are successful
    				if (!(aErrors.length > 0) && oSRBatchResp.hasOwnProperty("data") && oSRBatchResp.statusCode >= '200' && oSRBatchResp.statusCode < '300') {
    					fnSuccess(oSRBatchResp.data, that.aSubstitutionProfilesCollection, that.aSystemInfoCollection);
    				} else if (oSRBatchResp.hasOwnProperty("response") && oSRBatchResp.response.statusCode >= '400') {
    					aErrors.push(JSON.parse(oSRBatchResp.response.body));
    				}
    				
    				that.oLoader.close();
    				that._handleBatchErrors(aErrors);
    			}
    		};
    		
    		var fnErrorCallback = function(oError) {
    			//Entire batch request failed
    			that.oLoader.close();
    			that.oDataRequestFailed(oError);
    		};
    		
    		that.oLoader.open();
    		that.fireBatch({aPaths:aRequests ,aUrlParameters:aParams, sMethod:"GET",sBatchGroupId:"SubstitutionData",numberOfRequests:aRequests.length,
    			fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback});
		},
		
	    deleteAttachment: function(sSAP__Origin, sInstanceID, sAttachmentId, fnSuccess, fnError){
	    	var that = this;
	    	var sPath = "/AttachmentCollection(SAP__Origin='" + jQuery.sap.encodeURL(sSAP__Origin) + 
			"',InstanceID='" + jQuery.sap.encodeURL(sInstanceID) + "',ID='" + jQuery.sap.encodeURL(sAttachmentId) + "')/$value";
	    	
	    	var aRequests = [];
	    	aRequests.push(sPath);
	    	var fnSuccessCallback = function(){
	    		that.processListAfterAction(sSAP__Origin, sInstanceID);
	    		fnSuccess();
	    	};
	    	var fnErrorCallback = function(){
	    		fnError();
	    	};
	    	
	    	this.fireBatch({aPaths:aRequests ,aUrlParameters:"", sMethod:"DELETE",sBatchGroupId:"DeleteAttachment",numberOfRequests:aRequests.length,fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback});
	    },
	    
	    deleteSubstitution: function(aRuleKeys, fnSuccess) {
	    	var that = this;
	    	if (aRuleKeys.length === 1) { // if only one substitution rule needs to be deleted
	    		

	    		var oUrlParams = {
					SubstitutionRuleID : "'" + aRuleKeys[0].SubstitutionRuleId + "'", 
					SAP__Origin : "'" + aRuleKeys[0].SAP__Origin + "'"
	    		};


	    		this._performPost("/DeleteSubstitutionRule", aRuleKeys[0].SAP__Origin, oUrlParams, fnSuccess, null, this.oi18nResourceBundle.getText("substn.delete.error"));
	    		
	    	} else if(aRuleKeys.length > 1) { // if more than one delete requests need to be sent
	    		
	    		var aRequests = [];
	    		var aParams = [];
	    		
	    		// creating batch requests
	    		jQuery.each(aRuleKeys, $.proxy(function(index, oRule) {
	    			var oEntry = this.getDeleteSubtnEntry(oRule);
	    			aRequests.push(oEntry.rule);
	    			aParams.push(oEntry.parameters);
	    		}, this));
	    		
	    		var fnSuccessCallback = function(oData) {
					that.oLoader.close();
					var aBatchResponses = oData.__batchResponses;
					var aSuccessList = [];
					var aErrorList = [];
					var sDetails  = "";
					
					jQuery.each(aBatchResponses, function(index, oBatchResponse) {
						
						var bSuccess = false;
						
						if (oBatchResponse.hasOwnProperty("__changeResponses")) {
							var oChangeResponse = oBatchResponse.__changeResponses[0];
							
							if (oChangeResponse.statusCode >= "200" && oChangeResponse.statusCode < "300") {
								aSuccessList.push(index);
								bSuccess = true;
							}
						}
						
						if (!bSuccess) {
							aErrorList.push(oBatchResponse);
						} 
						
					});
					
					if (aSuccessList.length > 0) {
						fnSuccess(aSuccessList, aErrorList);
					}
					
					if (aErrorList.length > 0) {
						var sErrorMessage = aSuccessList.length > 0 ? this.oi18nResourceBundle.getText("substn.delete.multi.error") : this.oi18nResourceBundle.getText("substn.delete.error");
						this._handleBatchErrors(aErrorList, sErrorMessage);
					}
					
		    	};
	    		
	    		var fnErrorCallback = function(oError) {
	    			that.oLoader.close();
	    			var sDetails = this.getErrorMessage(oError);
					var oError = {
							customMessage: {
								message: this.oi18nResourceBundle.getText("substn.delete.error"),
								details: sDetails
							}
					
					};
					this.oDataRequestFailed(oError);
		    	};
		    	
		    	that.oLoader.open();
		    	that.fireBatch({aPaths:aRequests ,aUrlParameters:aParams, sMethod:"FUNCTIONIMPORT",sBatchGroupId:"DeleteSubstitution",numberOfRequests:aRequests.length,
		    		fnSuccessCallback:fnSuccessCallback,fnErrorCallback:fnErrorCallback});
	    	}
	    	
		},
		
		getDeleteSubtnEntry: function(oRule) {
			return {
				rule: "/DeleteSubstitutionRule", 
				parameters: {
					SubstitutionRuleID : jQuery.sap.encodeURL(oRule.SubstitutionRuleId),
					SAP__Origin : jQuery.sap.encodeURL(oRule.SAP__Origin) 
					} 
			};
		},
		
		getErrorMessage: function(oError) {
/*			if (oError.response && oError.response.body != "") {
				return oError.response.body;
			}*/
	    	if(oError.response && oError.response.body && oError.response.body != ""){
				try{
					var oMessage = JSON.parse(oError.response.body);
					 return (oMessage.error.message.value ? oMessage.error.message.value : null);
				}catch(e){
					return oError.response.body;
				}
	        }else if(oError.responseText && oError.responseText != ""){
				try{
					var oMessage = JSON.parse(oError.responseText);
					 return (oMessage.error.message.value ? oMessage.error.message.value : null);
				}catch(e){
					return oError.responseText;
				}
	        }else {
	        	return null;
	        }			
		},
					
		readSubstitutionProfiles: function(onSuccess, onError) {
			if (this.aSubstitutionProfilesCollection) {
				if (onSuccess) {
					onSuccess(this.aSubstitutionProfilesCollection);
				}
				return;
			}
					
			var that = this;
			that.oLoader.open();
					
			this.oDataRead("/SubstitutionProfileCollection",
					null,
					null,
					false,
					function (oData, oResponse) {
						that.oLoader.close();
						if (oData && oData.results) {
							if (onSuccess) {
								onSuccess(oData.results);
							}
						}
					},
					function (oError) {
						that.oLoader.close();
						that.oDataRequestFailed(oError);
						if (onError) {
							onError(oError);
						}
					}
				);
		},
		
		readSystemInfoCollection: function(onSuccess, onError) {
			if (this.aSystemInfoCollection) {
				if (onSuccess) {
					onSuccess(this.aSystemInfoCollection);
				}
				return;
			}
					
			var that = this;
			that.oLoader.open();		
			this.oDataRead("/SystemInfoCollection",
					null,
					null,
					false,
					function (oData, oResponse) {
						that.oLoader.close();
						if (oData && oData.results) {
							if (onSuccess) {
								onSuccess(oData.results);
							}
						}
					},
					function (oError) {
						that.oLoader.close();
						that.oDataRequestFailed(oError);
						if (onError) {
							onError(oError);
						}
					}
				);
		},
		
		readTaskDefinitionCollection: function(onSuccess, onError ) {
			var that = this;
			that.oLoader.open();		
			this.oDataRead("/TaskDefinitionCollection",
					null,
					null,
					false,
					function (oData, oResponse) {
						that.oLoader.close();
						if (oData && oData.results) {
							if (onSuccess) {
								onSuccess(oData.results);
							}
						}
					},
					function (oError) {
						that.oLoader.close();
						that.oDataRequestFailed(oError);
						if (onError) {
							onError(oError);
						}
					}
				);
		},		
		
		// refreshes data of a collection in the odata model if any change
		fnRefreshSingleTaskData: function(sOrigin, sInstanceID){
			var that = this;
			var sContextPath = "/" + "TaskCollection" + "(SAP__Origin='" + jQuery.sap.encodeURL(sOrigin) +"',InstanceID='" + jQuery.sap.encodeURL(sInstanceID) +"')";
			
			var fnSuccess = function(oData){
				that.fireItemRemoved();
				$.sap.log.info("successfully updated odata model");
			};
	    
	    	var fnErrorCallback = function( oError ) {
				that.oDataRequestFailed( oError );
			};
	    	this.oDataRead(sContextPath,
	    			null, 
	    			null, 
	    			true,
	    			jQuery.proxy(fnSuccess, that),
	    	fnErrorCallback);
		},
		
		fnGetDataWithCountSupport: function( sOrigin, sInstanceID, bGetCount, fnSuccessCallback, sEntity ){
			var that = this;
			if(!bGetCount)
				that.oLoader.open();
			var sCountString = bGetCount ? "/$count" : "";
			
			var sContextPath = "/" + "TaskCollection" + "(SAP__Origin='" + jQuery.sap.encodeURL(sOrigin) +"',InstanceID='" + jQuery.sap.encodeURL(sInstanceID) +"')/"+ sEntity + sCountString;
	    
	    	var fnErrorCallback = function( oError ) {
	    		if(!bGetCount)
	    		that.oLoader.close();
				that.oDataRequestFailed( oError );
			};
	    	this.oDataRead(sContextPath,
	    			null, 
	    			null, 
	    			true,
	    			function(oData){
	    		if(!bGetCount)
	    		that.oLoader.close();
	    		fnSuccessCallback(oData);
	    	},
	    	fnErrorCallback);
		},

		fnReadCommentsAndCreatedByDetails: function(aRequests, aParameters, fnSuccess){
			this.oLoader.open();
			var that = this;
			var fnErrorCallback = function( oError ) {
	    		that.oLoader.close();
				that.oDataRequestFailed( oError );
			};
			var fnSuccessLocal = function( data ){
				that.oLoader.close();
				fnSuccess(data);
			};
			that.fireBatch({aPaths:aRequests ,aUrlParameters:aParameters,sMethod:"GET",sBatchGroupId:"CommentsAndCreatedByDetails",numberOfRequests:aRequests.length,fnSuccessCallback:fnSuccessLocal,fnErrorCallback:fnErrorCallback});
		}
});

cross.fnd.fiori.inbox.util.DataManager.M_EVENTS = { ItemRemoved : "itemRemoved" };
