/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
cross.fnd.fiori.inbox.ODataModelExtension = (function() {

 return {
  overrideLoadData : function(oDataModel, bAllItems) {
   if (!oDataModel) return;

   if (bAllItems) {
    // All tasks scenario 
    oDataModel._loadData = function(sPath, aParams, fnSuccess, fnError, oContext, bCache, fnHandleUpdate, fnCompleted){

      /*
       * TODO: Johannes, Malte: check whether this is OK or not?
       *
       * We added a 5th parameter to support loading data within a context scope.
       * In case of the ExactBrowser this led to the issue, that fn: checkUpdate
       * updated all the bindings and also the root binding, which finally reset
       * the ExactBrowser and the nested levels will not show up. By adding the
       * context to this function it is possible now to update only the relevant
       * bindings!
       *
       * To reproduce the issue just avoid to pass the binding context to the
       * checkUpdate function and use the following Snippix sample: #3867
       *
       * Other change is in the ODataModel where this function is called when
       * loading additional contexts.
       */

     var oRequestHandle,
      requests = [],
      aParamsCopy,
      fnCustomSorter = this.extFnCustomSorter,
      fnCustomGrouper = this.extFnCustomGrouper,
      sGroupingProperty= this.extSGroupingProperty;

     var sFilterParam = "$filter=";

     if (!this.aTaskDefinitionIDFilterKeys)
      this.aTaskDefinitionIDFilterKeys = [];
     if (!this.aStatusFilterKeys)
      this.aStatusFilterKeys = [];

     if (sPath && sPath.indexOf("SAP__Origin") == -1) {
      //List binding data fetch - TaskCollection in batch

       var aFilterExprs = [];

       // Task Definition ID

       var sTaskDefinitionIDFilter = "";
       var iTaskDefinitionIDFilterCount = 0;

       for (var j = 0; j < this.aTaskDefinitionIDFilterKeys.length; j++) {
        // Check aTaskDefinitionIDFilterKeys if we are filtering for task definition IDs.

        if (sTaskDefinitionIDFilter != "")
         sTaskDefinitionIDFilter += " or ";

        sTaskDefinitionIDFilter += "TaskDefinitionID eq '" + this.aTaskDefinitionIDFilterKeys[j] + "'";

        iTaskDefinitionIDFilterCount++;
       }
       if (iTaskDefinitionIDFilterCount > 1) {
        sTaskDefinitionIDFilter = "(" + sTaskDefinitionIDFilter + ")";
       }

       if (iTaskDefinitionIDFilterCount > 0) {
        aFilterExprs.push(sTaskDefinitionIDFilter);
       }

       // Status

       var aStatusFilterKeys = this.aStatusFilterKeys.slice(0);
       if (aStatusFilterKeys.length == 0) {
        // Default status filter.

        aStatusFilterKeys.push("READY");
        aStatusFilterKeys.push("RESERVED");
        aStatusFilterKeys.push("IN_PROGRESS");
        aStatusFilterKeys.push("EXECUTED");
       }

       var sStatusFilter = "";

       for (var j = 0; j < aStatusFilterKeys.length; j++) {
        if (sStatusFilter != "")
         sStatusFilter += " or ";

        sStatusFilter += "Status eq '" + aStatusFilterKeys[j] + "'";
       }

       if (aStatusFilterKeys.length > 1)
        sStatusFilter = "(" + sStatusFilter + ")";

       aFilterExprs.push(sStatusFilter);

       // Construct filter string from aFilterExprs.

       var sFilterExpr = aFilterExprs.join(" and ");

       // Append aFilterExprs to aParams.

       aParamsCopy = aParams.slice(0);

       var iFilterIndex = null;

       for (var j = 0; j < aParamsCopy.length; j++) {
        if (aParamsCopy[j].indexOf(sFilterParam) == 0) {
         iFilterIndex = j;
         break;
        }
       }

       if (iFilterIndex != null) {
        // Filter parameter already exists.

        var sOriginalFilterExpr = aParamsCopy[iFilterIndex].substr(sFilterParam.length);

        sFilterExpr = encodeURIComponent(" and " + sFilterExpr);
        aParamsCopy[iFilterIndex] = sFilterParam + "(" + sOriginalFilterExpr + sFilterExpr + ")";
       } else {
        // No filter parameter present.

        sFilterExpr = encodeURIComponent(sFilterExpr);
        aParamsCopy.push(sFilterParam + "(" + sFilterExpr + ")");
       }

       //SAPUI5 version from 1.19.1-SNASPHOT
       var sRequestUrl = this._createRequestUrl(sPath, null, aParamsCopy, null, bCache || this.bCache);
       var oRequest = this._createRequest(sRequestUrl, "GET", true);

       requests.push(oRequest);
     } else {
      //Detail binding data fetch - TaskCollection detail not in batch
      var sUrl = this._createRequestUrl(sPath, null, aParams, null, bCache || this.bCache);
      var oRequest = this._createRequest(sUrl, "GET", true);
      requests.push(oRequest);
     }

     // request the data of the service for the given path
     var that = this;

     function _handleSuccess(oData, oResponse) {

      var oResultData = undefined;
      var mChangedEntities = {};
      if (sPath && sPath.indexOf("SAP__Origin") == -1) {
       //List binding data fetch - TaskCollection in batch
       var aItems = [];
       if (oData.hasOwnProperty("__batchResponses")) {
        // Result from batch read
        $.sap.log.info("Start read batch responses");
        // query was a batch request


        var oErrors = [];
        for ( var i = 0; i < oData.__batchResponses.length; i++) {
         var batchResp = oData.__batchResponses[i];
         if (batchResp.hasOwnProperty("data") && batchResp.statusCode >= '200' && batchResp.statusCode < '300') {
          // Successful request
          var aEntries = batchResp.data.results;
          if (aEntries != null) {
           for ( var j = 0; j < aEntries.length; j++) {
            aItems.push(aEntries[j]);
           }
          } else {
           aItems.push(batchResp.data);
          }

         } else if (batchResp.hasOwnProperty("response") && batchResp.response.statusCode >= '400') {
          that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false, errorobject: null});
          that.fireRequestFailed(null);
          oErrors.push(JSON.parse(batchResp.response.body.value));
          $.sap.log.error("Error when querying batch responses");

         }
        }

        // Do (client-side) custom grouping/sorting, if needed.

        if (fnCustomGrouper || fnCustomSorter) {
         var aGroups = [];

         if (fnCustomGrouper || sGroupingProperty) {
          // Either standard or custom grouping is active.

          var oGroup;
          var sGroupingValue;

          for (var i = 0; i < aItems.length; i++) {
           if (sGroupingValue !== aItems[i][sGroupingProperty]) {
            sGroupingValue = aItems[i][sGroupingProperty];
            oGroup = {
              GroupingValue: sGroupingValue,
              Elements: []
            };
            aGroups.push(oGroup);
           }

           oGroup.Elements.push(aItems[i]);
          }

          if (fnCustomGrouper)
           aGroups.sort(fnCustomGrouper);
         } else {
          // No grouping, put everything into one group.

          aGroups.push({
           GroupingValue: null,
           Elements: aItems
          });
         }

         if (fnCustomSorter) {
          // If custom sorting is needed, then do it for each group.

          for (var i = 0; i < aGroups.length; i++)
           aGroups[i].Elements.sort(fnCustomSorter);
         }

         // Concatenate groups into a single result array.

         aItems = [];

         for (var i = 0; i < aGroups.length; i++)
          aItems = aItems.concat(aGroups[i].Elements);
        }

        if (oErrors.length > 0) {
         var details = oErrors[0];
         for (var i = 1; i < oErrors.length; i++) {
          details += "/n" + oErrors[i];
         }
         that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false, errorobject: null});
         that.fireRequestFailed(null);
        }

       } else {
        $.sap.log.info("OData:" + oData);
       }

       oData.results = aItems;
       oResultData = oData;

      } else {
       //Detail binding data fetch - TaskCollection detail - standard code

       oResultData = oData;
       if (that.bUseBatch) { // process batch response
        // check if errors occurred in the batch
        var aErrorResponses = that._getBatchErrors(oData);
        if (aErrorResponses.length > 0) {
         // call handle error with the first error.
         _handleError(aErrorResponses[0]);
         return false;
        }

        if (oResultData.__batchResponses && oResultData.__batchResponses.length > 0) {
         oResultData = oResultData.__batchResponses[0].data;
        } else {
         jQuery.sap.log.fatal("The following problem occurred: No data was retrieved by service: " + oResponse.requestUri);
        }
       }

       aResults = aResults.concat(oResultData.results);
      }

      // no data available
      if (!oResultData) {
       jQuery.sap.log.fatal("The following problem occurred: No data was retrieved by service: " + oResponse.requestUri);
       that.sChangeKey = null;
       that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false});
       return false;
      }

      // check if not all requested data was loaded
      if (oResultData.__next){
       // replace request uri with next uri to retrieve additional data
       var oURI = new URI(oResultData.__next);
       requests[0].requestUri = oURI.absoluteTo(oResponse.requestUri).toString();
       readRequestedData(requests);
      }else{
       // all data is read so merge all data
       jQuery.extend(oResultData.results, aResults);
       // broken implementations need this
       if (oResultData.results && !jQuery.isArray(oResultData.results)) {
        oResultData = oResultData.results;
       }

       // adding the result data to the data object
       that._importData(oResultData, mChangedEntities);
       if (fnSuccess) {
        fnSuccess(oResultData);
       }

       that.checkUpdate(false, mChangedEntities);
       if (fnCompleted) {
        fnCompleted();
       }

       that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: true});
      }
     }

     function _handleError(oError) {
      if (fnError) {
       fnError();
      }

      var mParameters = that._handleError(oError);
      var sMessage = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle().getText("DataManager.HTTPRequestFailed");
      var sDetails = oError.response ? oError.response.body : null;
      mParameters = {message: sMessage,
        responseText: sDetails};

      that.sChangeKey = null;

      that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false, errorobject: mParameters});
      that.fireRequestFailed(mParameters);

     }

     /**
      * this method is used to retrieve all desired data. It triggers additional read requests if the server paging size
      * permits to return all the requested data. This could only happen for servers with support for oData > 2.0.
      */
     function readRequestedData(requests){
      // execute the request and use the metadata if available
      var oRequestHandle = null;
      if (that.bUseBatch) {

       var _submitReadBatch = function() {
        that.clearBatch();
        // batch requests only need the path without the service URL
        // extract query of url and combine it with the path...

        for (var i=0; i<requests.length; i++) {
         var sUriQuery = URI.parse(requests[i].requestUri).query;
         var sRequestUrl = sPath.replace(/\/$/, ""); // remove trailing slash if any
         sRequestUrl += sUriQuery ? "?" + sUriQuery : "";

         var oReadOp = that.createBatchOperation(sRequestUrl, "GET");
         that.addBatchReadOperations([oReadOp]);
        }

        oRequestHandle = that.submitBatch(_handleSuccess, _handleError, requests[0].async);
       };

       _submitReadBatch();
      }

      if (fnHandleUpdate) { 
       fnHandleUpdate(oRequestHandle);
      }
     }

     // execute request
     var aResults = [];
     this.fireRequestSent({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + this.oHeaders["Accept"]});
     readRequestedData(requests);
    };

   } else {
    // Normal scenario with scenario id
    oDataModel._loadData = function(sPath, aParams, fnSuccess, fnError, oContext, bCache, fnHandleUpdate, fnCompleted){

      /*
       * TODO: Johannes, Malte: check whether this is OK or not?
       *
       * We added a 5th parameter to support loading data within a context scope.
       * In case of the ExactBrowser this led to the issue, that fn: checkUpdate
       * updated all the bindings and also the root binding, which finally reset
       * the ExactBrowser and the nested levels will not show up. By adding the
       * context to this function it is possible now to update only the relevant
       * bindings!
       *
       * To reproduce the issue just avoid to pass the binding context to the
       * checkUpdate function and use the following Snippix sample: #3867
       *
       * Other change is in the ODataModel where this function is called when
       * loading additional contexts.
       */

     var oRequestHandle,
      requests = [],
      aParamsCopy,
      fnCustomSorter = this.extFnCustomSorter,
      fnCustomGrouper = this.extFnCustomGrouper,
      sGroupingProperty= this.extSGroupingProperty;

     var sFilterParam = "$filter=";

     if (!this.aTaskDefinitionIDFilterKeys)
      this.aTaskDefinitionIDFilterKeys = [];
     if (!this.aStatusFilterKeys)
      this.aStatusFilterKeys = [];

     if (sPath && sPath.indexOf("SAP__Origin") == -1) {
      //List binding data fetch - TaskCollection in batch
      for (var i=0; i < this.ScenarioServiceInfos.length; i++) {
       // Assemble filter expression.

       var oScenarioServiceInfo = this.ScenarioServiceInfos[i];
       var aFilterExprs = [];

       // Step 1: TaskDefinitionID

       var sTaskDefinitionIDFilter = "";
       var iTaskDefinitionIDFilterCount = 0;

       for (var j = 0; j < oScenarioServiceInfo.TaskDefinitionIDs.length; j++) {
        // Check aTaskDefinitionIDFilterKeys if we are filtering for task definition IDs.

        if (this.aTaskDefinitionIDFilterKeys.length > 0 &&
         this.aTaskDefinitionIDFilterKeys.indexOf(oScenarioServiceInfo.TaskDefinitionIDs[j]) == -1)
         continue;

        if (sTaskDefinitionIDFilter != "")
         sTaskDefinitionIDFilter += " or ";

        sTaskDefinitionIDFilter += "TaskDefinitionID eq '" + oScenarioServiceInfo.TaskDefinitionIDs[j] + "'";

        iTaskDefinitionIDFilterCount++;
       }

       // If the TaskDefinitionID filter is empty, then skip this service url.

       if (iTaskDefinitionIDFilterCount == 0)
        continue;
       else if (iTaskDefinitionIDFilterCount > 1)
        sTaskDefinitionIDFilter = "(" + sTaskDefinitionIDFilter + ")";

       aFilterExprs.push(sTaskDefinitionIDFilter);

       // Step 2: SAP__Origin

       aFilterExprs.push("SAP__Origin eq '" + oScenarioServiceInfo.Origin + "'");

       // Step 3: Status

       var aStatusFilterKeys = this.aStatusFilterKeys.slice(0);
       if (aStatusFilterKeys.length == 0) {
        // Default status filter.

        aStatusFilterKeys.push("READY");
        aStatusFilterKeys.push("RESERVED");
        aStatusFilterKeys.push("IN_PROGRESS");
        aStatusFilterKeys.push("EXECUTED");
       }

       var sStatusFilter = "";

       for (var j = 0; j < aStatusFilterKeys.length; j++) {
        if (sStatusFilter != "")
         sStatusFilter += " or ";

        sStatusFilter += "Status eq '" + aStatusFilterKeys[j] + "'";
       }

       if (aStatusFilterKeys.length > 1)
        sStatusFilter = "(" + sStatusFilter + ")";

       aFilterExprs.push(sStatusFilter);

       // Construct filter string from aFilterExprs.

       var sFilterExpr = aFilterExprs.join(" and ");

       // Append aFilterExprs to aParams.

       aParamsCopy = aParams.slice(0);

       var iFilterIndex = null;

       for (var j = 0; j < aParamsCopy.length; j++) {
        if (aParamsCopy[j].indexOf(sFilterParam) == 0) {
         iFilterIndex = j;
         break;
        }
       }

       if (iFilterIndex != null) {
        // Filter parameter already exists.

        var sOriginalFilterExpr = aParamsCopy[iFilterIndex].substr(sFilterParam.length);

        sFilterExpr = encodeURIComponent(" and " + sFilterExpr);
        aParamsCopy[iFilterIndex] = sFilterParam + "(" + sOriginalFilterExpr + sFilterExpr + ")";
       } else {
        // No filter parameter present.

        sFilterExpr = encodeURIComponent(sFilterExpr);
        aParamsCopy.push(sFilterParam + "(" + sFilterExpr + ")");
       }

       //SAPUI5 version from 1.19.1-SNASPHOT
       var sRequestUrl = this._createRequestUrl(sPath, null, aParamsCopy, null, bCache || this.bCache);
       var oRequest = this._createRequest(sRequestUrl, "GET", true);

       //SAPUI5 version before 1.19.1-SNASPHOT
       //var oRequest = this._createRequest(sPath, aParamsCopy, true, bCache || this.bCache);
       requests.push(oRequest);
      }
     } else {
      //Detail binding data fetch - TaskCollection detail not in batch
      var sUrl = this._createRequestUrl(sPath, null, aParams, null, bCache || this.bCache);
      var oRequest = this._createRequest(sUrl, "GET", true);
      requests.push(oRequest);
     }

     // request the data of the service for the given path
     var that = this;

     function _handleSuccess(oData, oResponse) {

      var oResultData = undefined;
      var mChangedEntities = {};
      if (sPath && sPath.indexOf("SAP__Origin") == -1) {
       //List binding data fetch - TaskCollection in batch
       var aItems = [];
       if (oData.hasOwnProperty("__batchResponses")) {
        // Result from batch read
        $.sap.log.info("Start read batch responses");
        // query was a batch request


        var oErrors = [];
        for ( var i = 0; i < oData.__batchResponses.length; i++) {
         var batchResp = oData.__batchResponses[i];
         if (batchResp.hasOwnProperty("data") && batchResp.statusCode >= '200' && batchResp.statusCode < '300') {
          // Successful request
          var aEntries = batchResp.data.results;
          if (aEntries != null) {
           for ( var j = 0; j < aEntries.length; j++) {
            aItems.push(aEntries[j]);
           }
          } else {
           aItems.push(batchResp.data);
          }

         } else if (batchResp.hasOwnProperty("response") && batchResp.response.statusCode >= '400') {
          that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false, errorobject: null});
          that.fireRequestFailed(null);
          oErrors.push(JSON.parse(batchResp.response.body.value));
          $.sap.log.error("Error when querying batch responses");

         }
        }

        // Do (client-side) custom grouping/sorting, if needed.

        if (fnCustomGrouper || fnCustomSorter) {
         var aGroups = [];

         if (fnCustomGrouper || sGroupingProperty) {
          // Either standard or custom grouping is active.

          var oGroup;
          var sGroupingValue;

          for (var i = 0; i < aItems.length; i++) {
           if (sGroupingValue !== aItems[i][sGroupingProperty]) {
            sGroupingValue = aItems[i][sGroupingProperty];
            oGroup = {
              GroupingValue: sGroupingValue,
              Elements: []
            };
            aGroups.push(oGroup);
           }

           oGroup.Elements.push(aItems[i]);
          }

          if (fnCustomGrouper)
           aGroups.sort(fnCustomGrouper);
         } else {
          // No grouping, put everything into one group.

          aGroups.push({
           GroupingValue: null,
           Elements: aItems
          });
         }

         if (fnCustomSorter) {
          // If custom sorting is needed, then do it for each group.

          for (var i = 0; i < aGroups.length; i++)
           aGroups[i].Elements.sort(fnCustomSorter);
         }

         // Concatenate groups into a single result array.

         aItems = [];

         for (var i = 0; i < aGroups.length; i++)
          aItems = aItems.concat(aGroups[i].Elements);
        }

        if (oErrors.length > 0) {
         var details = oErrors[0];
         for (var i = 1; i < oErrors.length; i++) {
          details += "/n" + oErrors[i];
         }
         that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false, errorobject: null});
         that.fireRequestFailed(null);
        }

       } else {
        $.sap.log.info("OData:" + oData);
       }

       oData.results = aItems;
       oResultData = oData;

      } else {
       //Detail binding data fetch - TaskCollection detail - standard code

       oResultData = oData;
       if (that.bUseBatch) { // process batch response
        // check if errors occurred in the batch
        var aErrorResponses = that._getBatchErrors(oData);
        if (aErrorResponses.length > 0) {
         // call handle error with the first error.
         _handleError(aErrorResponses[0]);
         return false;
        }

        if (oResultData.__batchResponses && oResultData.__batchResponses.length > 0) {
         oResultData = oResultData.__batchResponses[0].data;
        } else {
         jQuery.sap.log.fatal("The following problem occurred: No data was retrieved by service: " + oResponse.requestUri);
        }
       }

       aResults = aResults.concat(oResultData.results);
      }

      // no data available
      if (!oResultData) {
       jQuery.sap.log.fatal("The following problem occurred: No data was retrieved by service: " + oResponse.requestUri);
       that.sChangeKey = null;
       that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false});
       return false;
      }

      // check if not all requested data was loaded
      if (oResultData.__next){
       // replace request uri with next uri to retrieve additional data
       var oURI = new URI(oResultData.__next);
       requests[0].requestUri = oURI.absoluteTo(oResponse.requestUri).toString();
       readRequestedData(requests);
      }else{
       // all data is read so merge all data
       jQuery.extend(oResultData.results, aResults);
       // broken implementations need this
       if (oResultData.results && !jQuery.isArray(oResultData.results)) {
        oResultData = oResultData.results;
       }

       // adding the result data to the data object
       that._importData(oResultData, mChangedEntities);
       if (fnSuccess) {
        fnSuccess(oResultData);
       }

       that.checkUpdate(false, mChangedEntities);
       if (fnCompleted) {
        fnCompleted();
       }

       that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: true});
      }
     }

     function _handleError(oError) {
      if (fnError) {
       fnError();
      }

      var mParameters = that._handleError(oError);
      var sMessage = sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle().getText("DataManager.HTTPRequestFailed");
      var sDetails = oError.response ? oError.response.body : null;
      mParameters = {message: sMessage,
        responseText: sDetails};

      that.sChangeKey = null;

      that.fireRequestCompleted({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + that.oHeaders["Accept"], success: false, errorobject: mParameters});
      that.fireRequestFailed(mParameters);

     }

     /**
      * this method is used to retrieve all desired data. It triggers additional read requests if the server paging size
      * permits to return all the requested data. This could only happen for servers with support for oData > 2.0.
      */
     function readRequestedData(requests){
      // execute the request and use the metadata if available
      var oRequestHandle = null;
      if (that.bUseBatch) {

       var _submitReadBatch = function() {
        that.clearBatch();
        // batch requests only need the path without the service URL
        // extract query of url and combine it with the path...

        for (var i=0; i<requests.length; i++) {
         var sUriQuery = URI.parse(requests[i].requestUri).query;
         var sRequestUrl = sPath.replace(/\/$/, ""); // remove trailing slash if any
         sRequestUrl += sUriQuery ? "?" + sUriQuery : "";

         var oReadOp = that.createBatchOperation(sRequestUrl, "GET");
         that.addBatchReadOperations([oReadOp]);
        }

        oRequestHandle = that.submitBatch(_handleSuccess, _handleError, requests[0].async);
       };

       _submitReadBatch();
      }

      if (fnHandleUpdate) { 
       fnHandleUpdate(oRequestHandle);
      }
     }

     // execute request
     var aResults = [];
     this.fireRequestSent({url : requests[0].requestUri, type : "GET", async : requests[0].async, info: "Accept headers:" + this.oHeaders["Accept"]});
     readRequestedData(requests);
    };
   }



  }
 };

}());
