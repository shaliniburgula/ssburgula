/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
cross.fnd.fiori.inbox.Conversions = (function() {

	var sUrl = jQuery.sap.getModulePath("cross.fnd.fiori.inbox") + "/util/ProcessLogConfig.json";
	var oProcessLogConfig = jQuery.sap.sjax({url: sUrl, dataType: "json"}).data || {};
	
	return {
		formatterPriority : function(sOrigin, sTechnicalName) {
			
			if (!sOrigin || !sTechnicalName) {
				return null;
			}
			var oDataManager = sap.ca.scfld.md.app.Application.getImpl().getComponent().getDataManager();
			
			var sDisplayName = oDataManager.getPriorityDisplayName(sOrigin, sTechnicalName);
			if (sDisplayName != null)
				return sDisplayName;
			
			// try hardcoded values.
			
			switch (sTechnicalName) {
			case "VERY_HIGH" :
				return this.getModel("i18n").getProperty("view.Workflow.priorityVeryHigh");
			case "HIGH" :
				return this.getModel("i18n").getProperty("view.Workflow.priorityHigh");
			case "MEDIUM" :
				return this.getModel("i18n").getProperty("view.Workflow.priorityMedium");
			case "LOW" :
				return this.getModel("i18n").getProperty("view.Workflow.priorityLow");
			}
			
			// if nothing found, return the technical name
			
			return sTechnicalName;
		},
		
		formatterPriorityState : function(sTechnicalName) {

			switch (sTechnicalName) {
			case "VERY_HIGH" :
				return sap.ui.core.ValueState.Error;
			case "HIGH" :
				return sap.ui.core.ValueState.Warning;
			case "MEDIUM" :
			case "LOW" :
			default :
				return sap.ui.core.ValueState.None;
			}
		},
		
		formatterStatusForReserved : function(bSupportsRelease) {

			if (bSupportsRelease) {
				return this.getModel("i18n").getProperty("view.Workflow.reservedByYou");
			} else {
				return null;
			}
		},
		
		formatterEscalationState : function(bIsEscalated) {
			if (bIsEscalated) {
				return this.getModel("i18n").getProperty("view.Workflow.escalated");
			} else {
				return null;
			}
		},
		
		formatterVisibilityOfIconTab: function (bVisible) {
			// if not implemented then do not show the icon tab 
			return (bVisible) ? bVisible : false;
		},

		formatterHtml: function (oDescription) {
			var sString = "";
			
			if (oDescription) {
				if (oDescription.DescriptionAsHtml) {
					sString = oDescription.DescriptionAsHtml;
				} else {
					sString = oDescription.Description;
				};
			}
			
			if (sString) {
				var sFinal = sString.replace(/<a /g, "<a target=\"blank\" ");
				sString = '<div class="sapMText">' + sFinal + '</div>';
			}

			return sString;
		},

		
		formatterCommentsIcon : function (sMimeType, sIconUrl) {
			if (sMimeType) {
				return sIconUrl;
			} else {
				return null;
			}
		},
		
		formatterForwardUserIcon : function (sMimeType, sIconUrl) {
			if (sMimeType) {
				return sIconUrl;
			} else {
				return "sap-icon://person-placeholder";
			}
		},
		
		
		formatterIsNotZero: function (value) {
			return !!value;
		},
		
		formatterAgentName: function(sDisplayName, sUniqueName) {
			if (sDisplayName) {
				return sDisplayName;
			} else {
				return sUniqueName;
			}
		},
		formatterUserName: function(sDisplayName, sUniqueName) {
			return sDisplayName ? sDisplayName : sUniqueName;
			
		},
		
		formatterActionIcon: function (sAction) {
			return oProcessLogConfig[sAction] && oProcessLogConfig[sAction].icon;
		},
		
		formatterActionText: function (sAction) {
			return this.getModel("i18n").getProperty(sAction);
		},
		
		formatterActionUsername: function (sName, sAction) {
			if (oProcessLogConfig[sAction] && oProcessLogConfig[sAction].showUsername) {
				return sName;
			}
			return "";
		},
		
		formatterZeroToNull: function(value){
			//required by history tab counter: not to show "0" when there is no history
			return(value==0 ? null : value);
		},
		
		formatterSubstitutedText: function(sSubstitutedUserName) {
			if (sSubstitutedUserName) {
				return this.getModel("i18n").getResourceBundle().getText("view.Workflow.Substituted", sSubstitutedUserName);
			} else {
				return null;
			}
		},
		
		formatterDeadLineIndicator: function(dCompletionDeadLine) {
			var oDate = new Date();
			if (dCompletionDeadLine && dCompletionDeadLine - oDate < 0) {
				return this.getModel("i18n").getProperty("view.Workflow.Overdue"); 
			} else {
				return null;
			}
		},
		
		formatterDeadLineIndicatorState: function(dCompletionDeadLine) {
			var oDate = new Date();
			if (dCompletionDeadLine && dCompletionDeadLine - oDate < 0) {
				return sap.ui.core.ValueState.Error; 
			} else {
				return sap.ui.core.ValueState.None;
			}
		},
		
		getEmployeeAddress: function (oAddress) {
			var sAddress = "";
			jQuery.each(oAddress, function(key, value) {
				if (jQuery.type(value) === "string") {
					value = value.trim();
					sAddress = value ? sAddress + value + " " : sAddress + value;
				}
			});
			return sAddress;
		},
		
		formatterStatus: function(sOrigin, sTechnicalName) {
			
			if (!sOrigin || !sTechnicalName) {
				return null;
			}
			var oDataManager = sap.ca.scfld.md.app.Application.getImpl().getComponent().getDataManager();
			
			var sDisplayName = oDataManager.getStatusDisplayName(sOrigin, sTechnicalName);
			if (sDisplayName != null)
				return sDisplayName;
			
			// try hardcoded values.
			
			switch (sTechnicalName) {
			case "READY" :
				return this.getModel("i18n").getProperty("view.Workflow.status.ready");
			case "IN_PROGRESS" || "INPROGRESS" :
				return this.getModel("i18n").getProperty("view.Workflow.status.in_progress");
			case "RESERVED" :
				return this.getModel("i18n").getProperty("view.Workflow.status.reserved");
			case "EXECUTED" :
				return this.getModel("i18n").getProperty("view.Workflow.status.executed");
			}
			
			// if nothing found, return the technical name
			
			return sTechnicalName;
		},
		
		 /* formats custom attribute values according to the definition provided
	     *  and returns back formatted values
	      */
	    fnCustomAttributeTypeFormatter: function( sValue, sType ){
	    	var iFinalValue;
	    	switch( sType ) {
		        case 'Edm.String' : {
		        	iFinalValue = sValue;
					break;
		        }
		        case 'Edm.DateTime' : {
		        	var oDateFormatter = sap.ca.ui.model.format.DateFormat.getDateTimeInstance();
	    			sValue = new Date(sValue);
	    			if(sValue!="Invalid Date")
	    				iFinalValue = oDateFormatter.innerFormat.format(sValue);
	    			else
	    				iFinalValue = sValue;
		        	break;
		        }
		        case 'Edm.Boolean' : {
		        	if( sValue=="true")
		        		iFinalValue = sap.ca.scfld.md.app.Application.getImpl().getComponent().oDataManager.oi18nResourceBundle.getText("CUST_ATTR_TRUE");
		        	else if( sValue=="false")
		        		iFinalValue = sap.ca.scfld.md.app.Application.getImpl().getComponent().oDataManager.oi18nResourceBundle.getText("CUST_ATTR_FALSE");
		        	break;
		        }
		        case 'Edm.Int64' : {
		        	var oNumberFormatter = sap.ui.core.format.NumberFormat.getInstance();
		        	iFinalValue = oNumberFormatter.format(sValue);
		        	break;
		        }
		        case 'Edm.Int32' : {
		        	var oNumberFormatter = sap.ui.core.format.NumberFormat.getInstance();
		        	iFinalValue = oNumberFormatter.format(sValue);
		        	break;
		        }
		        case 'Edm.Int16' : {
		        	var oNumberFormatter = sap.ui.core.format.NumberFormat.getInstance();
		        	iFinalValue = oNumberFormatter.format(sValue);
		        	break;
		        }
		        case 'Edm.Time' : {
		        	var oDateFormatter = sap.ca.ui.model.format.DateFormat.getTimeInstance();
	    			var sDate = new Date(sValue);
		        	if(sDate!="Invalid Date")
		        		iFinalValue = oDateFormatter.innerFormat.format(sDate);
		        	else
		        		iFinalValue = sValue;
		        	break;
		        }
		        case 'Edm.Single' : {
		        	var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance();
		        	iFinalValue = numberFormat.format(sValue);
		        	break;
		        }
		        case 'Edm.Double' : {
		        	var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance();
		        	iFinalValue = numberFormat.format(sValue);
		        	break;
		        }
		        case 'Edm.Decimal' : {
		        	var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance();
		        	iFinalValue = numberFormat.format(sValue);
		        	break;
		        		
		        }
		        default: {
		        	iFinalValue = sValue;
		        	break;	       
		        }
	            
	    	}
	    	return iFinalValue;
	    },
	    
	    formatterDueDate: function (sDate) {
	    	if (sDate) {
	    		var oDateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
	    		var sFormattedDate = oDateFormatter.innerFormat.format(sDate, false);
	    		return sap.ca.scfld.md.app.Application.getImpl().getComponent().oDataManager.oi18nResourceBundle.getText("view.Workflow.dueOn", sFormattedDate);
	    	}
	    	return;
	    },
	    
	    formatterCreatedDate: function (sDate) {
	    	if (sDate) {
	    		var oDateFormatter = sap.ca.ui.model.format.DateFormat.getDateInstance();
	    		var sFormattedDate = oDateFormatter.innerFormat.format(sDate, false);
	    		return sap.ca.scfld.md.app.Application.getImpl().getComponent().oDataManager.oi18nResourceBundle.getText("view.Workflow.createdOn", sFormattedDate);
	    	}
	    	return;
	    }
	};
}());
