/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("cross.fnd.fiori.inbox.Main", {

	onInit : function() {
        jQuery.sap.require("sap.ca.scfld.md.Startup");
        jQuery.sap.require("sap.ca.ui.model.type.Date");
        jQuery.sap.require("cross.fnd.fiori.inbox.util.Conversions");
        jQuery.sap.require("cross.fnd.fiori.inbox.util.SupportInfo");
        jQuery.sap.require("cross.fnd.fiori.inbox.util.oDataReadExtension"); //TODO: remove it if this workaround not needed
        jQuery.sap.require("sap.ca.ui.model.format.FormattingLibrary");
        jQuery.sap.require("sap.ca.ui.dialog.factory");
        sap.ca.scfld.md.Startup.init('cross.fnd.fiori.inbox', this);
        
        var aDropDownButtons = [];
        
        if (!jQuery.device.is.phone) {
        	this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        	
        	var oSubstButton = new sap.m.Button({
        		text: sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle().getText("substn.navigation_button"),
        		icon: "sap-icon://citizen-connect",
        		press: (jQuery.proxy(function() {
        			this.oRouter.navTo('substitution', {} , false);
        		}, this))
        	});
        	
        	aDropDownButtons.push(oSubstButton);
        	
        }

        var oSupportInfoButton = new sap.m.Button({
        	text: sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle().getText("supportinfo.navigation_button"),
        	icon: "sap-icon://message-information",
        	press: function(oEvent){
        				sap.ca.scfld.md.app.Application.getImpl().getComponent().getEventBus().publish("cross.fnd.fiori.inbox", "open_supportinfo",{source:"MAIN"});
        				cross.fnd.fiori.inbox.util.SupportInfo.open();
        			}
        });
        
        aDropDownButtons.push(oSupportInfoButton);
        
        sap.ushell.services.AppConfiguration.addApplicationSettingsButtons(aDropDownButtons);
	},
	
	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * 
	 * @memberOf MainXML
	 */
	onExit : function() {
		//exit cleanup code here
	}	
	
});
