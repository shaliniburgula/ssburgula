/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("cross.fnd.fiori.inbox.util.Forward");
jQuery.sap.require("cross.fnd.fiori.inbox.util.SupportInfo");
jQuery.sap.require("cross.fnd.fiori.inbox.util.Conversions");
jQuery.sap.require("cross.fnd.fiori.inbox.util.DataManager");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("sap.ca.ui.model.type.DateTime");
jQuery.sap.require("sap.collaboration.components.fiori.sharing.Component");
jQuery.sap.require("sap.collaboration.components.fiori.sharing.dialog.Component");
jQuery.sap.require("sap.ui.commons.TextArea"); //TimeLine control uses it, but it does not load it
jQuery.sap.require("sap.suite.ui.commons.Timeline");
jQuery.sap.require("sap.suite.ui.commons.TimelineItem");

sap.ca.scfld.md.controller.BaseDetailController.extend("cross.fnd.fiori.inbox.view.S3", {
	
//	Controller Hook method definitions 

//	This hook method can be used to perform additional requests for example
//	It is called in the success callback of the detail data fetch
	extHookOnDataLoaded: null,

//	This hook method can be used to add custom related entities to the expand list of the detail data request
//	It is called when the detail view is displayed and before the detail data fetch starts
	extHookGetEntitySetsToExpand: null,
	
//	This hook method can be used to add and change buttons for the detail view footer
//	It is called when the decision options for the detail item are fetched successfully
	extHookChangeFooterButtons: null,
	
	// the model of the detail view
	oModel2: null,
	
	// cached detailed data for selected item
	oDetailData2: null,
	
    onInit: function() {
        //execute the onInit for the base class BaseDetailController
        sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);

        //-- set the default oData Model
        var oView = this.getView();
        
        this.i18nBundle = oView.getModel("i18n").getResourceBundle();
        
		sap.ca.scfld.md.app.Application.getImpl().getComponent()
		.getEventBus().subscribe("cross.fnd.fiori.inbox", "open_supportinfo", this.onSupportInfoOpenEvent, this);

    	// for Handling Custom Attributes creation/removal
    	this.aCA=[];
    	this.aTaskDefinitionData = [];
    	this.aTaskDefinitionDataObject = {};
    	this.aUIExecutionLinkCatchedData = [];
        var sUrlParams = this.getView().getModel().sUrlParams;

		//if upload enabled, must set xsrf token
		//and the base64 encodingUrl service for IE9 support!
		
        this.oRouter.attachRouteMatched(this.handleNavToDetail, this);
        
        this.oHeaderFooterOptions = {};

        this.oTabBar = oView.byId("tabBar");        

        var oTimeline = this.byId("timeline");
        if (oTimeline) {
	        var oTimelineItemTemplate = new sap.suite.ui.commons.TimelineItem({
	        	icon: {
	        		path: "detail>ActionName",
	        		formatter: cross.fnd.fiori.inbox.Conversions.formatterActionIcon
	        	},
	        	userName: {
	        		parts: [{path: "detail>PerformedByName"}, {path: "detail>ActionName"}],
	        		formatter: cross.fnd.fiori.inbox.Conversions.formatterActionUsername
	        	},
	        	title: {
	        		path: "detail>ActionName",
	        		formatter: cross.fnd.fiori.inbox.Conversions.formatterActionText
	        	},
	        	dateTime: "{detail>Timestamp}"
	        });
	        oTimeline.bindAggregation("content", {
	        	path: "detail>/ProcessingLogs/results",
	        	template: oTimelineItemTemplate
	        });
        }
        
    },

    handleNavToDetail: function(oEvent){
    	if (oEvent.getParameter("name") === "detail") {
    		
    		var sInstanceID = oEvent.getParameter("arguments").InstanceID;
    		if (sInstanceID.search(":") == (sInstanceID.length - 1)) {
    			return;
    		}
    		
    		// Deep link scenario: if the detail navigation happens before the S2 list was downloaded, navigate to a different URL
    		// so when the list data arrives and the item gets selected the URL will change, and the navigation won't be stopped
    		if (jQuery.isEmptyObject(this.getView().getModel().oData)) {
    			var oParameters = {
    				SAP__Origin : oEvent.getParameters().arguments.SAP__Origin,
					InstanceID : oEvent.getParameters().arguments.InstanceID + ":",
					contextPath : oEvent.getParameters().arguments.contextPath
    			};
				this.oRouter.navTo("detail", oParameters, true);
				return;
    		}
    		
    		//In case of a list item selection the first tab shall be selected
    		//Exception: Comment is added on the comment tab - this tab must stay selected or nav to detail on phone
    		if (!this.stayOnDetailScreen || jQuery.device.is.phone) {
    			var oDescriptionTab = this.oTabBar.getItems()[0];
        		this.oTabBar.setSelectedItem(oDescriptionTab);
    		} else {
    			this.stayOnDetailScreen = false;
    		}
    		
    		var oRefreshData = {
					sCtxPath: "/" + oEvent.getParameters().arguments.contextPath,
					sInstanceID: sInstanceID,
					sSAP__Origin: oEvent.getParameter("arguments").SAP__Origin,
					bCommentCreated: false
			};
    		this.refreshData(oRefreshData);
    	}
    },
    
    refreshData: function(oRefreshData) {
    	//clearing already present custom attributes from DOM
    	this.clearCustomAttributes();
    	
    	//clear attachment control
        var oAttachmentData = { Attachments:[] };  
        this.byId('uploadCollection').setModel(new sap.ui.model.json.JSONModel(oAttachmentData));
    	
    	var oView = this.getView();
		var oContext = new sap.ui.model.Context(oView.getModel(), oRefreshData.sCtxPath);
		oView.setBindingContext(oContext);
		
		// store the context path to be used for the delayed downloads
		this.sCtxPath = oRefreshData.sCtxPath;
		
		var oItem = oView.getModel().getData(oContext.getPath(), oContext);
		this.oModel2 = new sap.ui.model.json.JSONModel(oItem);
		oView.setModel(this.oModel2, "detail");
		
		this._updateHeaderTitle(oItem);		

		if (!this.bIsControllerInited) {
			var oComponent = sap.ca.scfld.md.app.Application.getImpl().getComponent();
    		this.oDataManager = oComponent.getDataManager();
            if (!this.oDataManager) {
            	var oOriginalModel = this.getView().getModel();
            	this.oDataManager = new cross.fnd.fiori.inbox.util.DataManager(oOriginalModel, this);
            	oComponent.setDataManager(this.oDataManager);
            }
            this.oDataManager.attachItemRemoved(jQuery.proxy(this._handleItemRemoved, this));
            this.bIsControllerInited = true;
		}

		/*
		 * Manual detail request via DataManager in batch with decision options together
		 * Automatic request with view binding would cause a S2 list re-rendering - SAPUI5 issue
		 */
		var that = this;
		var fnSuccess = function(oDetailData, aDecisionOptions) {
			
			/**
	         * @ControllerHook Provide custom logic after the item detail data received
	         * This hook method can be used to perform additional requests for example
	         * It is called in the success callback of the detail data fetch
	         * @callback cross.fnd.fiori.inbox.view.S3~extHookOnDataLoaded
	         * @param {object} oDetailData - contains the item detail data
	         * @return {void}
	         */
			if (that.extHookOnDataLoaded) {
				that.extHookOnDataLoaded(oDetailData);
			}
			
			if(sap.ui.Device.system.desktop){ // fetching UIExecutionLink data from cache if available ( only in desktop)
				var sKey = oDetailData.SAP__Origin + oDetailData.InstanceID;
				if( oDetailData.UIExecutionLink && oDetailData.UIExecutionLink.InstanceID ){ // not in cache, put in cache
					this.aUIExecutionLinkCatchedData[sKey] = oDetailData.UIExecutionLink;
				}
				else{ // get from cache
					oDetailData.UIExecutionLink = this.aUIExecutionLinkCatchedData[sKey];
				}
			}
			
			that.oModel2.setData(oDetailData);

			//save detail data (used to fix the flickering of ProcessingLogs tab after detail screen refresh)
			that.oDetailData2 = oDetailData;
			
			that.createDecisionButtons(aDecisionOptions, oRefreshData.sSAP__Origin);
			that.addShareOnJamAndEmail();
			//set target URL for attachment upload
			var oConfigClass = jQuery.sap.getObject("cross.fnd.fiori.inbox.Configuration");
			var oConfiguration = new oConfigClass();
			var sBaseUrl = oConfiguration.getServiceList()[0].serviceUrl;

			var oUploadCollection = this.byId("uploadCollection");
			oUploadCollection.setUploadUrl(sBaseUrl + oRefreshData.sCtxPath + "/Attachments");
			// attachment model
            var data = { Attachments:[] };
			
			if (this.oModel2.getData().TaskSupports.Attachments ) {
				that.fnCountUpdater("Attachments", oDetailData.SAP__Origin, oDetailData.InstanceID );
			}
			that.fnCountUpdater("Comments", oDetailData.SAP__Origin, oDetailData.InstanceID );
			if (this.oModel2.getData().TaskSupports.ProcessingLogs )
				that.fnCountUpdater("ProcessingLogs", oDetailData.SAP__Origin, oDetailData.InstanceID );
			if (this.oModel2.getData().TaskSupports.TaskObject ) {
				that.fnCountUpdater("ObjectLinks", oDetailData.SAP__Origin, oDetailData.InstanceID );
			}

			var sUrlParams = that.getView().getModel().sUrlParams;
			
            if (that.byId("tabBar").getSelectedKey() == "NOTES" && this.oModel2.getData().HasComments ) {
            	that.fnReadCommentsAndCreatedByDetails();
            }
            if (that.byId("tabBar").getSelectedKey() == "ATTACHMENTS" && this.oModel2.getData().HasAttachments ) {
            	that.fnFetchAttachments();
            }
            if (that.byId("tabBar").getSelectedKey() == "PROCESSINGLOGS" && this.oModel2.getData().TaskSupports.ProcessingLogs ) {
            	that.fnFetchProcessingLogs();
            }
            if (that.byId("tabBar").getSelectedKey() == "OBJECTLINKS" && this.oModel2.getData().TaskSupports.TaskObject ) {
            	that.fnFetchObjectLinks();
            }
            
            //now dynamically create custom attributes if exists for the task
            if(oDetailData.CustomAttributeData.results.length>0)
            this.fnHandleCustomAttributeCreation( oView, oDetailData );

		};
		
		// At the start of each fetch:
		// - Initialize tabbar to show only description tab.
		// - Clear footer.
		if (this.oHeaderFooterOptions) {
			
	    	this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
    			oPositiveAction: null,
    			oNegativeAction: null,
    			buttonList: [],
    			oJamOptions: null,
	    	});
	    	
	    	this.refreshHeaderFooterOptions();
		}
		
		//provide the ctxPath for the detail data request and the origin + instance id for the decision options request and cache key
		//var aExpandEntitySets = ["Attachments", "Description", "Comments/CreatedByDetails"];
//		var aExpandEntitySets = ["Description", "ProcessingLogs","CustomAttributeData"];
//TODO add ProcessingLogs		
		var aExpandEntitySets = ["Description","CustomAttributeData"];
		//fetch task execution UI link only for desktop and tablet
		var sKey = oRefreshData.sSAP__Origin + oRefreshData.sInstanceID;
		if(sap.ui.Device.system.desktop && !this.aUIExecutionLinkCatchedData[sKey] ){
			aExpandEntitySets.push("UIExecutionLink");
		}
		
		 

		
		/**
         * @ControllerHook Add additional entities related to the work item
         * This hook method can be used to add custom related entities to the expand list of the detail data request
         * It is called when the detail view is displayed and before the detail data fetch starts
         * @callback cross.fnd.fiori.inbox.view.S3~extHookGetEntitySetsToExpand
         * @return {array} aEntitySets - contains the names of the related entities
         */
		if (this.extHookGetEntitySetsToExpand) {
			var aEntitySets = this.extHookGetEntitySetsToExpand();
			// append custom entity sets to the default list
			aExpandEntitySets.push.apply(aExpandEntitySets, aEntitySets);
		}
		
		if(this.oModel2!=null)
			this.fnClearCachedData();
		this.oDataManager.readDetailWithDecisionOptions(oRefreshData.sCtxPath, aExpandEntitySets, oRefreshData.sSAP__Origin, oRefreshData.sInstanceID, jQuery.proxy(fnSuccess, this));
		
		
		
 
    },
    
    // dynamic creation of custom attributes
    
    fnHandleCustomAttributeCreation : function( oView, oDetailData ){
    	this.clearCustomAttributes();	//clearing already present custom attributes from DOM
    	var aCustomAttributeElements = this.aCA;	//reference to global aCA which stores dynamically created elements to clear from DOM  when not needed
    	var that = this;
    	
    	
    	
    	//callback after a successful call is made to get CustomAttributeData definitions
    	var fnSuccessCustomAttribute = function( oData, bCachedData ){
    		if( bCachedData != true ) {// if data is not fetched from Cache, put it in cache
    			that.aTaskDefinitionData.push( oData );
    			for( var i=0; i<oData.CustomAttributeDefinitionData.results.length; i++ )
    			that.aTaskDefinitionDataObject[ oData.TaskDefinitionID + "_" + oData.CustomAttributeDefinitionData.results[i].Name ] = oData.CustomAttributeDefinitionData.results[i];
    			that.aTaskDefinitionDataObject[ oData.TaskDefinitionID + "_Exists" ]  = "true"; // extra value in cache to check if definition Id for a task exists in cache
    			
    		}
    		var oCustomAttributesContainer = oView.byId( "customAttributesContainer" );	//getting parent element for dynamic child element creation
    		
            for( var i = 0; i < oDetailData.CustomAttributeData.results.length; i++ ){ // iterate each custom attribute
            	var sAttributeName = oDetailData.CustomAttributeData.results[i].Name;
                var sDefinitionLabelName;
                var sLabelType;
                var bDefinitionPresent = false;
                
                sLabelType = that.aTaskDefinitionDataObject[ oDetailData.TaskDefinitionID + "_" + sAttributeName ].Type;
                sDefinitionLabelName = that.aTaskDefinitionDataObject[ oDetailData.TaskDefinitionID + "_" + sAttributeName ].Label;
                if(sLabelType && sDefinitionLabelName) bDefinitionPresent = true;
               
                if( bDefinitionPresent == true ){ // show attribute only if it's definition is present
                	var oNewFormElement = new sap.ui.layout.form.FormElement ( "", {} );
                	oNewFormElement.setLayoutData( new sap.ui.commons.layout.ResponsiveFlowLayoutData ( "", { linebreak:true, margin:false } ) );
                	var oLabel = new sap.m.Label ( "", { text : sDefinitionLabelName } );
                    oLabel.setLayoutData( new sap.ui.commons.layout.ResponsiveFlowLayoutData ( "", {  weight:3, minWidth:192 } ) );
                    oNewFormElement.setLabel( oLabel );
                    var sValue = cross.fnd.fiori.inbox.Conversions.fnCustomAttributeTypeFormatter( oDetailData.CustomAttributeData.results[i].Value, sLabelType );
                    var oText = new sap.m.Text ( "", { text:sValue } );
                    oText.setLayoutData( new sap.ui.commons.layout.ResponsiveFlowLayoutData ( "", { weight:5 } ) );
                    oNewFormElement.addField( oText );
	                oCustomAttributesContainer.addFormElement( oNewFormElement );
	                aCustomAttributeElements.push( oNewFormElement );
                }
            }
            
        };
    	
    	var oComponent = sap.ca.scfld.md.app.Application.getImpl().getComponent();
    	this.oDataManager = oComponent.getDataManager();
    	var bCached = false;
    	var iCachedElement;
    	for( var i=0; i < that.aTaskDefinitionData.length; i++ ){
    		if( that.aTaskDefinitionDataObject[ oDetailData.TaskDefinitionID + "_Exists" ] == "true"  ){
    			bCached = true;
    			iCachedElement = i; // get position of required element in cached object
    			break;
    		}
    	}
    	if( bCached ){ // if data for selected task definition id is cached, take cached data from aTaskDefinitionData
    		fnSuccessCustomAttribute( "" , true );
    	}
    	else{ // else fetch new data
    		this.oDataManager.readCustomAttributeDefinitionData( oDetailData.SAP__Origin, oDetailData.TaskDefinitionID, fnSuccessCustomAttribute );
    	}
    },
    
    
    clearCustomAttributes : function(){
    	if( this.aCA.length>0 ){
    		for( var i=0; i<this.aCA.length; i++ )
    		this.aCA[i].destroy();
    		this.aCA = [];
    		
    	}
    },
    onAttachmentChange : function(e){
		var oUploadCollection = this.byId("uploadCollection");
		var sFileName = e.getParameters().getParameters().files[0].name;

		//remove extension
		var iLastDot = sFileName.lastIndexOf(".");
		if(iLastDot != -1){
			sFileName = sFileName.substr(0, iLastDot);
		}

		oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
			name: "x-csrf-token",
			value: this.getXsrfToken()
		}));
		oUploadCollection.addHeaderParameter(new sap.m.UploadCollectionParameter({
			name: "slug",
			value: sFileName
		}));
		oUploadCollection.addParameter(new sap.m.UploadCollectionParameter({
			name: "x-csrf-token",
			value: this.getXsrfToken()
		}));
		oUploadCollection.addParameter(new sap.m.UploadCollectionParameter({
			name: "slug",
			value: sFileName
		}));
		
		
    },
    
    onAttachmentUploadComplete : function(e){
    	this.stayOnDetailScreen = true;
    	var oItem = this.oModel2.getData();
    	if(e.getParameters().getParameters().status == 201){
    		sap.ca.ui.message.showMessageToast(this.i18nBundle.getText("dialog.success.attachmentUpload"));
    		this.byId('uploadCollection').rerender();
    		this.oDataManager.processListAfterAction(oItem.SAP__Origin, oItem.InstanceID);
    	}else{
	    	var sErrorText = this.i18nBundle.getText("dialog.error.attachmentUpload"); 
    		sap.ca.ui.message.showMessageBox({
	             type: sap.ca.ui.message.Type.ERROR,
	             message: sErrorText,
	             details: ""
	         }, $.proxy(function(){
	        	 this.oDataManager.processListAfterAction(oItem.SAP__Origin, oItem.InstanceID);
	         },this));
    	}
    },
    
    onAttachmentDeleted : function(e){
    	var sAttachmentId = e.getParameters().documentId;
    	var oItem = this.oModel2.getData();
    	this.oDataManager.deleteAttachment(oItem.SAP__Origin, oItem.InstanceID, sAttachmentId, 
			$.proxy(function(){
				sap.ca.ui.message.showMessageToast(this.i18nBundle.getText("dialog.success.attachmentDeleted"));
				this.byId('uploadCollection').rerender();
				this.stayOnDetailScreen = true;
			}, this),
			$.proxy(function(oError){
		    	 var sErrorText = this.i18nBundle.getText("dialog.error.attachmentDelete");
		         sap.ca.ui.message.showMessageBox({
		             type: sap.ca.ui.message.Type.ERROR,
		             message: sErrorText,
		             details: ""
		         }, $.proxy(function(){
		        	 this.oDataManager.processListAfterAction(oItem.SAP__Origin, oItem.InstanceID);
		         },this));
			}, this)
    	);
    	
    },
    
    buildFileDescriptorObject:function (value) {
      	 
        var oFile = {
            name : value.FileName,
            size : value.FileSize,
            url : value.__metadata.media_src,
            uploadedDate : value.CreatedAt,
            contributor : value.CreatedByName,
            mimeType : value.mime_type,
            fileId : value.ID
        };

        return oFile;
    }, 
    
    getXsrfToken: function() {
        var sToken = this.getView().getModel().getHeaders()['x-csrf-token'];
        if (!sToken) {
 
            this.getView().getModel().refreshSecurityToken(
                function(e, o) {
                    sToken = o.headers['x-csrf-token'];
                },
                function() {
                     sap.ca.ui.message.showMessageBox({
                         type: sap.ca.ui.message.Type.ERROR,
                         message: 'Could not get XSRF token',
                         details: ''
                     });
                },
                false);
        }
        return sToken;
    },

	onFileUploadFailed : function(e) {
		 var sErrorText = this.i18nBundle.getText("dialog.error.attachmentUpload");
	     sap.ca.ui.message.showMessageBox({
	         type: sap.ca.ui.message.Type.ERROR,
	         message: sErrorText,
	         details: e.getParameters().exception
	     });
	},
    
	addShareOnJamAndEmail: function () {
		
		var oJamOptions = { 
				oShareSettings : { 
					object : { 
						id : window.location.href, 
						share :  this.getJamDescription()
					} 
				},
			};
		
		var oEmailSettings = { 
				sSubject: this.getMailSubject() , 
				fGetMailBody: jQuery.proxy(this.getMailBody, this) 
			};
		
		var oButtonList = {};
		
		oButtonList.oEmailSettings = oEmailSettings;
		oButtonList.oJamOptions = oJamOptions;

		/**
         * @ControllerHook Modify the footer buttons
         * This hook method can be used to add and change buttons for the detail view footer
         * It is called when the decision options for the detail item are fetched successfully
         * @callback cross.fnd.fiori.inbox.view.S3~extHookChangeFooterButtons
         * @param {object} oButtonList - contains the positive, negative buttons and the additional button list.
         * @return {void}
         */
    	if (this.extHookChangeFooterButtons) {
    		this.extHookChangeFooterButtons(oButtonList);
    		
    		oEmailSettings = oButtonList.oEmailSettings;
    		oJamOptions = oButtonList.oJamOptions;
    	}
    	
    	this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
			oJamOptions : oJamOptions,
			oEmailSettings: oEmailSettings
    	});
    	
    	this.refreshHeaderFooterOptions();
    },
    
    _getDescriptionForShare: function(sDescriptionText) {
       	var oData = this.oModel2.getData();
    	var sBody = "\n\n" + this.i18nBundle.getText("share.email.body.detailsOfTheItem") + "\n\n";
    	var oDateFormatter = sap.ui.core.format.DateFormat.getDateInstance();
    	if (oData.TaskTitle != "") {
    		sBody += this.i18nBundle.getText("item.taskTitle", oData.TaskTitle) + "\n";
    	}
    	if (oData.Priority != "") {
    		sBody += this.i18nBundle.getText("item.priority", cross.fnd.fiori.inbox.Conversions.formatterPriority.call(this.getView(), oData.SAP__Origin, oData.Priority)) + "\n";
    	}
    	if (oData.CompletionDeadLine) {
    		sBody += this.i18nBundle.getText("item.dueDate", oDateFormatter.format(oData.CompletionDeadLine, true)) + "\n";
    	}
    	if (sDescriptionText) {
    		// use override text if given
    		sBody += this.i18nBundle.getText("item.description", sDescriptionText) + "\n";
    	} else if ((oData.Description) && (oData.Description.Description) && (oData.Description.Description != "")) {
    		sBody += this.i18nBundle.getText("item.description", oData.Description.Description.trim()) + "\n";
    	}
    	var sCreator = oData.CreatedByName;
    	if (sCreator == "") {
    		sCreator = oData.CreatedBy;
    	}
    	if (sCreator != "") {
    		sBody += this.i18nBundle.getText("item.createdBy", sCreator) + "\n";
    	}
    	if (oData.CreatedOn) {
    		sBody += this.i18nBundle.getText("item.createdOn", oDateFormatter.format(oData.CreatedOn, true)) + "\n";
    	}
  		
    	return sBody;    	
    },
    
    _getDescriptionForShareInMail: function(sDescriptionText) {
    	var sBody = this._getDescriptionForShare(sDescriptionText);  
  		sBody += this.i18nBundle.getText("share.email.body.link", window.location.href.split("(").join("%28").split(")").join("%29")) + "\n";
  		
  		return sBody;
    },
    
    getJamDescription: function() {
    	var sBody = this._getDescriptionForShare();  

    	return sBody;
    },
    
    getMailSubject: function() {
    	var oData = this.oModel2.getData();
    	var sPriority = cross.fnd.fiori.inbox.Conversions.formatterPriority.call(this.getView(), oData.SAP__Origin, oData.Priority);
    	var sCreatedBy = oData.CreatedByName;
    	var sTaskTitle = oData.TaskTitle;
    	if (sCreatedBy == "") {
        	return this.i18nBundle.getText("share.email.subject_no_user" , [sPriority, sTaskTitle]);
    	} else {
        	return this.i18nBundle.getText("share.email.subject" , [sPriority, sCreatedBy, sTaskTitle]);
    	}
    },
    
    getMailBody: function() {
    	
    	// Internet Explorer supports only shorter mailto urls, we pass only the items url this case
    	if (jQuery.browser.msie) {
    		return window.location.href.split("(").join("%28").split(")").join("%29");
    	}

    	var sFullMailBody = this._getDescriptionForShareInMail();
    	var sMailSubject = this.getMailSubject();
    	// due to a limitation in most browsers, don't let the mail link longer than 2000 chars
    	var sFullMailUrl = sap.m.URLHelper.normalizeEmail(null, sMailSubject, sFullMailBody);
    	if (sFullMailUrl.length > 2000) {
    		// mail url too long, we need to reduce the description field's size
    		var oData = this.oModel2.getData();
    		var sMinimalMailBody = this._getDescriptionForShareInMail(" ");
    		var sMinimalMailUrl = sap.m.URLHelper.normalizeEmail(null, sMailSubject, sMinimalMailBody);
    		var iMaxDescriptionLength = 2000 - sMinimalMailUrl.length;
    		var sDescription = "";
    		if (oData.Description) {
    			sDescription = window.encodeURIComponent(oData.Description.Description.trim());
       		}
    		sDescription = sDescription.substring(0,iMaxDescriptionLength);
    		
    		// if we cut encoded chars in half the decoding won't work (encoded chars can have length of 9)
    		// remove the encoded part from the end
    		var bDecodeSucceeded = false;
    		while (!bDecodeSucceeded || sDescription.length == 0) {
    			bDecodeSucceeded = true;
    			try {
    				sDescription = window.decodeURIComponent(sDescription);
    			} catch(oError) {
    				sDescription = sDescription.substring(0,sDescription.length-1);
        			bDecodeSucceeded = false;
    			}
    		}
    		sDescription = sDescription.substring(0, sDescription.length-3) + "...";
    		
    		var sTruncatedMailBody = this._getDescriptionForShareInMail(sDescription);
    		return sTruncatedMailBody;
    	}
    	
    	return sFullMailBody;
	},
    
    _handleItemRemoved: function(oEvent) {

    	//Successful request processing - navigate back to list on phone
    	if (jQuery.device.is.phone && !this.getView().getParent().getParent().isMasterShown()) {
    		
    		if (!this.stayOnDetailScreen) {
    			this.oRouter.navTo("master", {}, jQuery.device.is.phone);
        		// after overwriting the history state that points to the
        		// item which is not available any more, we can step back because
        		// the previos history state is also the master list
        		window.history.back();
    		} else {
    			var oRefreshData = {
    					sCtxPath: this.getView().getBindingContext().getPath(),
    					sInstanceID: this.oModel2.getData().InstanceID,
    					sSAP__Origin: this.oModel2.getData().SAP__Origin,
    					bCommentCreated: true
    			};
    			this.refreshData(oRefreshData);
    		}
    		
    	}
    },

    _updateHeaderTitle: function(oData) {
    	//-- update header
    	if (oData) {
	    	this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
	        	sDetailTitle: oData.TaskTitle
	    	});
	    	
	    	this.refreshHeaderFooterOptions();
    	}
    },

    _isTaskConfirmable: function(oItem){
//    	if (oItem.TaskSupports.Confirm)
    	if (oItem.Status == 'EXECUTED'){
    		return true;
    	}else{
    		return false;
    	}
    },
    
    createDecisionButtons: function (aDecisionOptions, sOrigin) {
    	var oPositiveAction = null;
    	var oNegativeAction = null;
    	var aButtonList = [];

    	var that = this;

    	var oItem = this.oModel2.getData();
    	
    	if (!this._isTaskConfirmable(oItem)){    		
        	for (var i = 0; i < aDecisionOptions.length; i++) {
        		var oDecisionOption = aDecisionOptions[i];
        		oDecisionOption.SAP__Origin = sOrigin;
        		if (oDecisionOption.Nature === "POSITIVE") {
        			oPositiveAction = {
        				sBtnTxt : oDecisionOption.DecisionText,
        				onBtnPressed  : (function (oDecision) {
        					return function() {
        						that.showDecisionDialog(that.oDataManager.FUNCTION_IMPORT_DECISION, oDecision, true);
        					};
        				})(oDecisionOption)
        			};
        		} else if (oDecisionOption.Nature === "NEGATIVE") {
        			oNegativeAction = {
        				sBtnTxt : oDecisionOption.DecisionText,
        				onBtnPressed  : (function (oDecision) {
        					return function() {
        						that.showDecisionDialog(that.oDataManager.FUNCTION_IMPORT_DECISION, oDecision, true);
        					};
        				})(oDecisionOption)
        			};
        		} else {
        			aButtonList.push({
        				sBtnTxt : oDecisionOption.DecisionText,
        				onBtnPressed  : (function (oDecision) {
        					return function() {
        						that.showDecisionDialog(that.oDataManager.FUNCTION_IMPORT_DECISION, oDecision, true);
        					};
        				})(oDecisionOption)
        			});
        		}
        	}
        }
    	
    	// add the confirm button
    	if (this._isTaskConfirmable(oItem)){
       		// add the claim button to the end
    		oPositiveAction = {
    			sI18nBtnTxt : "XBUT_CONFIRM",
				onBtnPressed  : (function (oDecision) {
					return function() {
						that.showConfirmationDialog(that.oDataManager.FUNCTION_IMPORT_CONFIRM, oItem);
					};
				})(oItem)    		
    		};    		
    	}  
    	
    	// add the claim button
    	if (oItem.SupportsClaim) {
    		// add the claim button to the end
    		aButtonList.push({
    			sI18nBtnTxt : "XBUT_CLAIM",
    			onBtnPressed  : function(oEvent) {
    				that.sendAction("Claim", oItem, null);
    			}
    		});
    	}
    	
    	// add the release button
    	if (oItem.SupportsRelease) {
    		// add the release button to the end
    		aButtonList.push({
    			sI18nBtnTxt : "XBUT_RELEASE",
    			onBtnPressed  : function(oEvent) {
    				that.sendAction("Release", oItem, null);
    			}
    		});
    	}
    	
    	// add the forward button 
    	if (oItem.SupportsForward) {    	
			aButtonList.push({
				sI18nBtnTxt : "XBUT_FORWARD",
				onBtnPressed  : jQuery.proxy(this.onForwardPopUp, this)
			});
    	}
    	
    	//add the open task button to the end
    	 if(sap.ui.Device.system.desktop && oItem.UIExecutionLink && oItem.UIExecutionLink.GUI_Link !== ""){
        	aButtonList.push({
        						sI18nBtnTxt : "XBUT_OPEN",
        						onBtnPressed  : function(oEvent) {
        								that.openTaskUIWindow();
        						}
        					 });        	
    	}
        
		var oButtonList = {};
		oButtonList.oPositiveAction = oPositiveAction;
		oButtonList.oNegativeAction = oNegativeAction;
		oButtonList.aButtonList = aButtonList;

		/**
         * @ControllerHook Modify the footer buttons
         * This hook method can be used to add and change buttons for the detail view footer
         * It is called when the decision options for the detail item are fetched successfully
         * @callback cross.fnd.fiori.inbox.view.S3~extHookChangeFooterButtons
         * @param {object} oButtonList - contains the positive, negative buttons and the additional button list.
         * @return {void}
         */
    	if (this.extHookChangeFooterButtons) {
    		this.extHookChangeFooterButtons(oButtonList);
    		
    		oPositiveAction = oButtonList.oPositiveAction;
    		oNegativeAction = oButtonList.oNegativeAction;
    		aButtonList = oButtonList.aButtonList;
    	}
    	
    	this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
    			oPositiveAction : oPositiveAction,
    			oNegativeAction : oNegativeAction,
    			buttonList : aButtonList,
    			// remove bookmark button
    			bSuppressBookmarkButton : true
    	});
    	
    	this.refreshHeaderFooterOptions();
    },
    
	startForwardFilter: function(oListItem, sQuery) {
		sQuery = sQuery.toLowerCase();
		var sFullName = oListItem.getBindingContext().getProperty("DisplayName").toLowerCase();
		var sDepartment = oListItem.getBindingContext().getProperty("Department").toLowerCase();

		return (sFullName.indexOf(sQuery) != -1) ||
			(sDepartment.indexOf(sQuery) != -1);
	},

	closeForwardPopUp: function(oResult) {
		if (oResult && oResult.bConfirmed) {
			var oItem = this.oModel2.getData();
			var sOrigin = oItem.SAP__Origin;
			var sInstanceID = oItem.InstanceID;	

			this.oDataManager.doForward(sOrigin, sInstanceID,
					oResult.oAgentToBeForwarded.UniqueName, oResult.sNote, jQuery.proxy(function() {
						sap.ca.ui.message.showMessageToast(this.i18nBundle.getText("dialog.success.forward", oResult.oAgentToBeForwarded.DisplayName));
					}, this));
		}
	},

    onForwardPopUp: function() {
		var oItem = this.oModel2.getData();
		var sOrigin = oItem.SAP__Origin;
		var sInstanceID = oItem.InstanceID;	

		cross.fnd.fiori.inbox.util.Forward.open(
			jQuery.proxy(this.startForwardFilter, this),
			jQuery.proxy(this.closeForwardPopUp, this)
		);

		this.oDataManager.readPotentialOwners(sOrigin, sInstanceID,
			jQuery.proxy(this._PotentialOwnersSuccess, this));
    },

    _PotentialOwnersSuccess: function(oResult) {
    	cross.fnd.fiori.inbox.util.Forward.setAgents(oResult.results);
		cross.fnd.fiori.inbox.util.Forward.setOrigin(this.oModel2.getData().SAP__Origin);
	},

	onEmployeeLaunchTask: function(oEvent) {
		var oItem = this.oModel2.getData();
		var sOrigin = oItem.SAP__Origin;
		var sCreatedBy = oItem.CreatedBy;	

		// get control that triggers the BusinessCard
		var oControl = oEvent.getSource();
		if (oControl._getLinkControl) oControl = oControl._getLinkControl();

		this.oDataManager.readUserInfo(sOrigin, sCreatedBy,
			jQuery.proxy(this._showEmployeeCard, this, oControl));
	},

	onEmployeeLaunchCommentSender: function(oEvent) {
		// Business card on Notes
		var oItem = this.oModel2.getData();
		var sOrigin = oItem.SAP__Origin;
		var sCreatedBy = oEvent.getSource().getBindingContext("detail").getProperty("CreatedBy");

		// get control that triggers the BusinessCard
		var oControl = oEvent.getSource();
		if (oControl._getLinkSender()) oControl = oControl._getLinkSender();

		this.oDataManager.readUserInfo(sOrigin, sCreatedBy,
				jQuery.proxy(this._showEmployeeCard, this, oControl));

	},

	onEmployeeLaunchCommentIcon: function(oEvent) {
		// Business card on Notes
		var sOrigin = oEvent.getSource().getBindingContext().getProperty("SAP__Origin");
		var sCreatedBy = oEvent.getSource().getBindingContext("detail").getModel().getProperty(oEvent.getSource().getBindingContext("detail").getPath()).CreatedBy;

		if (!sOrigin) {
			//Deep link scenario
			var oItem = this.oModel2.getData();
			sOrigin = oItem.SAP__Origin;
		}
		
		// get control that triggers the BusinessCard
		//TODO: private method is called, UI5 support is needed
		var oControl = oEvent.getSource();
		if (oControl._getImageControl) oControl = oControl._getImageControl();

		/*
		this.oDataManager.readUserInfo(sOrigin, sInstanceID,
				jQuery.proxy(function(oResult) {
					this.fnEmployeeLaunch(oResult, oControl);
				},this));
		*/
		this.oDataManager.readUserInfo(sOrigin, sCreatedBy,
				jQuery.proxy(this._showEmployeeCard, this, oControl));

	},

	_showEmployeeCard: function(oControl, oResult) {
		var oItem = this.oModel2.getData();
		var sTaskTitle = oItem.TaskTitle;

		var oEmpData = {
				title : this.getView().getModel("i18n").getProperty("bc.title.employee"),
				name : oResult.DisplayName,
				imgurl : cross.fnd.fiori.inbox.Conversions.formatterCommentsIcon(oResult.mime_type, oResult.__metadata.media_src),
				department : oResult.Department,
				contactmobile : oResult.MobilePhone,
				contactphone : oResult.WorkPhone,
				contactemail : oResult.Email,
				contactemailsubj : sTaskTitle,
				companyname: oResult.Company
			};

		// call 'Business Card' reuse component
		var oEmployeeLaunch = new sap.ca.ui.quickoverview.EmployeeLaunch(oEmpData);
		oEmployeeLaunch.openBy(oControl);
	},

	onAttachmentShow : function(oEvent) {
        var oContext = oEvent.getSource().getBindingContext("detail");
        var sMediaSrc = oContext.getProperty().__metadata.media_src;
        sap.m.URLHelper.redirect(sMediaSrc, true);
	},

	showDecisionDialog : function(sFunctionImportName, oDecision, bShowNote) {
		sap.ca.ui.dialog.confirmation.open({
				question : this.i18nBundle.getText("XMSG_DECISION_QUESTION", oDecision.DecisionText),
				showNote : bShowNote,
				title : this.i18nBundle.getText("XTIT_SUBMIT_DECISION"),
				confirmButtonLabel : this.i18nBundle.getText("XBUT_SUBMIT"),
				noteMandatory: oDecision.CommentMandatory,
			}, jQuery.proxy(function(oDecision, oResult){
				if(oResult.isConfirmed){
					this.sendAction(sFunctionImportName, oDecision, oResult.sNote);
				}
			},
			this, oDecision)
		);
	},
	
	showConfirmationDialog : function(sFunctionImportName, oItem) {
		sap.ca.ui.dialog.confirmation.open({
				question : this.i18nBundle.getText("XMSG_CONFIRM_QUESTION"),
				showNote : false,
				title : this.i18nBundle.getText("XTIT_SUBMIT_CONFIRM"),
				confirmButtonLabel : this.i18nBundle.getText("XBUT_CONFIRM"),
			}, jQuery.proxy(function(oItem, oResult){
				if(oResult.isConfirmed){
					this.sendAction(sFunctionImportName, oItem, null);
				}
			},
			this, oItem)
		);
	},	
	
	onCommentPost : function(oEvent){
		var sComment = oEvent.getParameter("value");
		if (sComment && sComment.length > 0) {
			this.stayOnDetailScreen = true;
			this.sendAction('AddComment', null, sComment);
		}
	},
	
	sendAction: function(sFunctionImportName, oDecision, sNote) {
		var that = this;
		var sSuccessMessage;
		var fnAfterSendActionFailed = function(){
			that.oDataManager.processListAfterAction(oDecision.SAP__Origin, oDecision.InstanceID);
		};
		
		switch (sFunctionImportName) {
			case "Release":
				sSuccessMessage = "dialog.success.release";
				break;
			case "Claim":
				sSuccessMessage = "dialog.success.reserve";
				break;
			case "AddComment":
				sSuccessMessage = "dialog.success.addComment";
				break;
			case "Confirm":
				sSuccessMessage = "dialog.success.completed";
				break;
			default:
				sSuccessMessage = "dialog.success.complete";
		}
		
		switch (sFunctionImportName){
			case 'AddComment': {
				var oItem = this.oModel2.getData();
				this.oDataManager.addComment(oItem.SAP__Origin, oItem.InstanceID, sNote, jQuery.proxy(function(){
					jQuery.sap.delayedCall(500, this, function() {
						sap.ca.ui.message.showMessageToast(this.i18nBundle.getText(sSuccessMessage));
					});
				}, this));
				break;
			}
			default: {
				this.oDataManager.sendAction(sFunctionImportName, oDecision, sNote,
					jQuery.proxy(function(oData) {
						// item is removed from S2 list in the data manager
						jQuery.sap.delayedCall(500, this, function() {
							sap.ca.ui.message.showMessageToast(this.i18nBundle.getText(sSuccessMessage));
						});
					}, this, oDecision),
					
					jQuery.proxy(function(oError){
						sap.ca.ui.message.showMessageBox({
						       type: sap.ca.ui.message.Type.ERROR,
						       message: oError.customMessage.message,
						       details: oError.customMessage.details? oError.customMessage.details : "",
						   }, fnAfterSendActionFailed);
					},this)
				);
			}
		}
	},
	
	refreshHeaderFooterOptions: function() {
		this._oHeaderFooterOptions = jQuery.extend(this._oHeaderFooterOptions, this.oHeaderFooterOptions);		
   		this.setHeaderFooterOptions(this._oHeaderFooterOptions);
	},
	
	openTaskUIWindow : function(){
		var sAppliedTheme  =  sap.ui.getCore().getConfiguration().getTheme();
		var cssURL = "";
		var rStandardThemePattern = /^sap_hcb/i;
		
		var mTaskAppThemesMap = {
	        sap_hcb: {
	          WDJ: "/com.sap.ui.lightspeed/themes/sap_hcb",
	          WDA: "sap_hcb"
	        }
	    };
   
		if ( rStandardThemePattern.test( sAppliedTheme ) ){
		     cssURL += "&sap-ui-theme="+ jQuery.sap.encodeURL(sAppliedTheme);
		        var oTaskAppThemeMap = mTaskAppThemesMap[ sAppliedTheme ];
		        if(oTaskAppThemeMap){
		            cssURL += oTaskAppThemeMap['WDJ']? "&sap-cssurl="+location.protocol+"//"+location.host +":" + location.port + oTaskAppThemeMap['WDJ'] :"";
		            cssURL += oTaskAppThemeMap['WDA']? "&sap-theme="+ jQuery.sap.encodeURL(oTaskAppThemeMap['WDA']) :"";
		        }
		}
		else{
		    cssURL += "&sap-ui-theme="+ jQuery.sap.encodeURL(sAppliedTheme);
		}
	
		var sURL = this.oModel2.getData().UIExecutionLink.GUI_Link;
		if(jQuery.sap.validateUrl(sURL)){
			sURL = sURL + cssURL;
			sap.m.URLHelper.redirect(sURL, true);
		}else{
			sap.ca.ui.message.showMessageBox({
							 type: sap.ca.ui.message.Type.ERROR,
							 message: this.i18nBundle.getText("dialog.error.taskExecutionUI"),
			});
		}
	},
	
	onTabSelect: function(oControlEvent) {
		var sSelectedTab = oControlEvent.getParameters().selectedKey;
		var oModelData = this.oModel2? this.oModel2.getData() : "";
		
		switch( sSelectedTab ){
			// if comments tab selected, comments present and there are no comments cached, fetch comments
			case "NOTES":
				if(oModelData.HasComments == true && (!oModelData.Comments.results  || ( oModelData.Comments.results && oModelData.Comments.results.length != oModelData.CommentsCount ))){
					this.fnReadCommentsAndCreatedByDetails();
				}
				break;
			
			// if attachment tab selected, attachments present and there are no attachments cached, fetch attachments
			case "ATTACHMENTS":
				if(  oModelData.HasAttachments == true && !oModelData.Attachments.results ){
					this.fnFetchAttachments();
				}
				break;
			
			case "PROCESSINGLOGS":
				if(  oModelData.TaskSupports.ProcessingLogs == true && !oModelData.ProcessingLogs.results ){
					this.fnFetchProcessingLogs();
				}
				break;
				
			case "OBJECTLINKS":
				if(  oModelData.TaskSupports.TaskObject === true && !oModelData.ObjectLinks && oModelData.ObjectLinksCount>0 ){
					this.fnFetchObjectLinks();
				}
				break;
		}
	},
	
	/* reads attachments when clicked on the attachments tab */
	fnFetchAttachments: function(){
		var oModelData = this.oModel2.getData();
		var that = this;
		
		var fnSuccess = function(oAttachmentData){
			that.oModel2.setProperty("/Attachments", oAttachmentData ); // populate the view's model with attachment data
			var data = { Attachments:[] };
			//build json model
            if (oAttachmentData.results && oAttachmentData.results.length > 0) {
            	 $.each(oAttachmentData.results, function (index, value) {
                     data.Attachments.push(that.buildFileDescriptorObject(value));
             });
            }
            
            //now bind the JSON model directly to the file upload control
            that.byId('uploadCollection').setModel(new sap.ui.model.json.JSONModel(data));
            that.byId('uploadCollection').rerender();
		};
		
		that.oDataManager.fnGetDataWithCountSupport( oModelData.SAP__Origin, oModelData.InstanceID, false, fnSuccess, "Attachments" );
	},
	
	/* Updates the count in the model */
	fnCountUpdater: function( sKey, sSAP__Origin, sInstanceID ){
		var that = this;
		
		switch( sKey ){
		case "Attachments":
			this.oDataManager.fnGetDataWithCountSupport( sSAP__Origin, sInstanceID, true, function(sNumberOFAttachments){
				that.oModel2.setProperty("/AttachmentsCount", sNumberOFAttachments );
				that.fnHandleNoTextCreation("Attachments");
			}, "Attachments");
			break;
		case "Comments":
			this.oDataManager.fnGetDataWithCountSupport( sSAP__Origin, sInstanceID, true, function(sNumberOFComments){
				that.oModel2.setProperty("/CommentsCount", sNumberOFComments );
				that.fnHandleNoTextCreation("Comments");
			}, "Comments");
			break;
		case "ProcessingLogs":
			this.oDataManager.fnGetDataWithCountSupport( sSAP__Origin, sInstanceID, true, function( sNumberOfLogs ){
				 that.oModel2.setProperty("/ProcessingLogsCount", sNumberOfLogs );	 
				 that.fnHandleNoTextCreation("ProcessingLogs");
			 }, "ProcessingLogs");
			break;
		case "ObjectLinks" :
			this.oDataManager.fnGetDataWithCountSupport( sSAP__Origin, sInstanceID , true, function( sNumberOfLinks ){
				that.oModel2.setProperty("/ObjectLinksCount", sNumberOfLinks );
				that.fnHandleNoTextCreation("ObjectLinks");
			 }, "TaskObjects");
			break;
		}
	},
	
	fnHandleNoTextCreation: function(sEntity){
		var that = this;
		var oModelData = this.oModel2.getData();

		switch(sEntity){
			case "Comments":
				var oCommentsTab = that.byId("MIBCommentList");
				if(oModelData.CommentsCount && oModelData.CommentsCount>0)
					oCommentsTab.setNoDataText( that.i18nBundle.getText("XMSG_LOADING") );
				else if(oModelData.CommentsCount && oModelData.CommentsCount==0)
					oCommentsTab.setNoDataText(that.i18nBundle.getText("view.CreateComment.noComments"));
				break;
			case "Attachments":
				var oAttachmentsTab = that.byId("uploadCollection");
				if(oModelData.AttachmentsCount && oModelData.AttachmentsCount>0)
					oAttachmentsTab.setNoDataText( that.i18nBundle.getText("XMSG_LOADING") );
				else if(oModelData.AttachmentsCount && oModelData.AttachmentsCount==0)
					oAttachmentsTab.setNoDataText(that.i18nBundle.getText("view.Attachments.noAttachments"));
				break;
			case "ProcessingLogs":
				var oHistoryTab = that.byId("timeline");
				if(oModelData.ProcessingLogsCount && oModelData.ProcessingLogsCount>0)
					oHistoryTab.setNoDataText( that.i18nBundle.getText("XMSG_LOADING") );
				else if(oModelData.ProcessingLogsCount && oModelData.ProcessingLogsCount==0)
					oHistoryTab.setNoDataText(that.i18nBundle.getText("view.ProcessLogs.noProcessLog"));
				break;
			case "ObjectLinks":
				var oObjectLinksTab = that.byId("MIBObjectLinksList");
				if(oModelData.ObjectLinksCount && oModelData.ObjectLinksCount>0)
					oObjectLinksTab.setNoDataText( that.i18nBundle.getText("XMSG_LOADING") );
				else if(oModelData.ObjectLinksCount && oModelData.ObjectLinksCount==0)
					oObjectLinksTab.setNoDataText(that.i18nBundle.getText("view.ObjectLinks.noObjectLink"));
				break;
			default:
				break;
		}
	},
	
	fnClearCachedData: function(){
		this.oModel2.setProperty("/AttachmentsCount", "" );
		this.oModel2.setProperty("/CommentsCount", "" );
		this.oModel2.setProperty("/ProcessingLogsCount", "" );	
		this.oModel2.setProperty("/ObjectLinksCount", "" );
		this.oModel2.setProperty("/ProcessingLogs", "" ); // to fetch new data on every refresh for processing logs
		this.oModel2.setProperty("/Attachments", "" ); // to fetch new attachments on every refresh
		this.oModel2.setProperty("/Comments", "" ); // to fetch new comments on every refresh
	},
	
	fnFetchProcessingLogs: function(){
		var oModelData = this.oModel2.getData();
		var fnSuccess = function(data){
			this.oModel2.setProperty("/ProcessingLogs",data);
		};
		this.oDataManager.fnGetDataWithCountSupport( oModelData.SAP__Origin, oModelData.InstanceID , false , jQuery.proxy( fnSuccess, this), "ProcessingLogs" );
		
	},

	fnFetchObjectLinks : function(){
        var oModelData = this.oModel2.getData();
        var iObjectLinkNumber = 0;
        var fnSuccess = function(data){
                for (var i = 0 ;i < data.results.length; i++) {
                        if(!data.results[i].Label) {
                                iObjectLinkNumber = iObjectLinkNumber + 1;
                                data.results[i].Label = this.i18nBundle.getText("object.link.label") + " " + iObjectLinkNumber ;
                        }
                }
                this.oModel2.setProperty("/ObjectLinks",data);
        };
        this.oDataManager.fnGetDataWithCountSupport( oModelData.SAP__Origin, oModelData.InstanceID , false , jQuery.proxy( fnSuccess, this), "TaskObjects" );
	},
	
	/* Reads comments and createdBy details when clicked on the comments tab */
	fnReadCommentsAndCreatedByDetails : function(){
		var that = this;
		var sContextPath = this.sCtxPath;
		var aRequests = [sContextPath+"/Comments"];
		var oModelData = this.oModel2.getData();
        var fnSuccess = function(data){
        	oModelData.Comments = data.__batchResponses[0].data;
        	that.oModel2.setData(oModelData);
        	that.byId('MIBNoteIconTabFilter').rerender();
        };
        this.oDataManager.fnReadCommentsAndCreatedByDetails(aRequests,["$expand=CreatedByDetails" ],fnSuccess);
	},
	
	onSupportInfoOpenEvent : function(sChannelId, sEventId, oSupportInfoOpenEvent) {
		if (oSupportInfoOpenEvent.source === "MAIN") {
            //To support info
			var oCustomAttributeDefinition = null;
            var oItem = this.oModel2.getData();
            if(this.aTaskDefinitionData && this.aTaskDefinitionData.length === 1 && this.aTaskDefinitionData[0].CustomAttributeDefinitionData.results){
            	oCustomAttributeDefinition = this.aTaskDefinitionData[0].CustomAttributeDefinitionData.results;
            }
            cross.fnd.fiori.inbox.util.SupportInfo.setTask(oItem, oCustomAttributeDefinition);
		}
	}
	
});
