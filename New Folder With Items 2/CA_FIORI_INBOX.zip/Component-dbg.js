/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// define a root UIComponent which exposes the main view
jQuery.sap.declare("cross.fnd.fiori.inbox.Component");
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("cross.fnd.fiori.inbox.Configuration");
jQuery.sap.require("sap.ui.core.routing.Router");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

// new Component
sap.ca.scfld.md.ComponentBase.extend("cross.fnd.fiori.inbox.Component", {
	
	metadata : sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name": "My Inbox", // F0862
		"version" : "1.6.2",
		"library" : "cross.fnd.fiori.inbox",
		"includes" : [ 
		    "css/inbox.css"
		],
		"dependencies" : { 
			"libs" : [ 
				"sap.m",
				"sap.me"
			],  
			"components" : [ 
			] 
		},
		"config" : {
			"resourceBundle" : "i18n/i18n.properties",
			"titleResource" : "SHELL_TITLE",
			"icon" : "sap-icon://approvals",
			"favIcon" : "./resources/sap/ca/ui/themes/base/img/favicon/Approve_Requests.ico", //FIXME: should use F0392, but resource is not like that for W1s
			"homeScreenIconPhone" : "./resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/57_iPhone_Desktop_Launch.png", //FIXME: should use F0392, but resource is not like that for 
			"homeScreenIconPhone@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/114_iPhone-Retina_Web_Clip.png", //FIXME: should use F0392, but resource is not like that for 
			"homeScreenIconTablet" : "./resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/72_iPad_Desktop_Launch.png", //FIXME: should use F0392, but resource is not like that for 
			"homeScreenIconTablet@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/Approve_Requests/144_iPad_Retina_Web_Clip.png", //FIXME: should use F0392, but resource is not like that for 
			"startupImage320x460" : "./resources/sap/ca/ui/themes/base/img/splashscreen/320_x_460.png",
			"startupImage640x920" : "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_920.png",
			"startupImage640x1096" : "./resources/sap/ca/ui/themes/base/img/splashscreen/640_x_1096.png",
			"startupImage768x1004" : "./resources/sap/ca/ui/themes/base/img/splashscreen/768_x_1004.png",
			"startupImage748x1024" : "./resources/sap/ca/ui/themes/base/img/splashscreen/748_x_1024.png",
			"startupImage1536x2008" : "./resources/sap/ca/ui/themes/base/img/splashscreen/1536_x_2008.png",
			"startupImage1496x2048" : "./resources/sap/ca/ui/themes/base/img/splashscreen/1496_x_2048.png"
		},
		
		// Navigation related properties
		
		viewPath : "cross.fnd.fiori.inbox.view",
		
		detailPageRoutes : {
			"detail" : {
                "pattern" : "detail/{SAP__Origin}/{InstanceID}/{contextPath}",
                "view" : "S3"
			},
			"multi_select_summary" : {
                "pattern" : "multi_select_summary",
                "view" : "MultiSelectSummary"
			}
		},
		
		fullScreenPageRoutes : {
            "detail_deep" : {
               "pattern" : "detail_deep/{SAP__Origin}/{InstanceID}/{contextPath}",
               "view" : "S3"
            },
            "substitution" : {
                "pattern" : "substitution",
                "view" : "ViewSubstitution"
             }
		}
		
	}),
		
	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
        var oViewData = {component: this};
        
		return sap.ui.view({
			viewName : "cross.fnd.fiori.inbox.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	},
	
	setDataManager : function(oDataManager) {
		this.oDataManager = oDataManager;
	},

	getDataManager : function() {
		return this.oDataManager;
	}
});
