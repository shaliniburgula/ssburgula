/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("cross.fnd.fiori.inbox.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
 
sap.ca.scfld.md.ConfigurationBase.extend("cross.fnd.fiori.inbox.Configuration", {

	oServiceParams: {
        serviceList: [
            {
                name: "TASKPROCESSING",
                masterCollection: "TaskCollection",
                serviceUrl: "/sap/opu/odata/IWPGW/TASKPROCESSING;mo;v=2/",
                isDefault: true,
                mockedDataSource: "/cross.fnd.fiori.inbox/model/metadata.xml",
                useBatch: true,
                useV2ODataModel:true,
                noBusyIndicator:true
            },
            {
                name: "POSTACTION",
                masterCollection: "TaskCollection",
                serviceUrl: "/sap/opu/odata/IWPGW/TASKPROCESSING;mo;v=2/",
                isDefault: false,
                useBatch: true,
                useV2ODataModel:true,
                noBusyIndicator:true
            }
        ]
    },

    getServiceParams: function () {
        return this.oServiceParams;
    },

    /**
     * @inherit
     */
    getServiceList: function () {
        return this.oServiceParams.serviceList;
    },

    getMasterKeyAttributes : function() {
        return ["Id"];
    }

});
