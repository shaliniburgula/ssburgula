jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 Author in the list
// * All 3 Author have at least one books

sap.ui.require([
	"sap/ui/test/Opa5",
	"booksCRUD/booksCRUD/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"booksCRUD/booksCRUD/test/integration/pages/App",
	"booksCRUD/booksCRUD/test/integration/pages/Browser",
	"booksCRUD/booksCRUD/test/integration/pages/Master",
	"booksCRUD/booksCRUD/test/integration/pages/Detail",
	"booksCRUD/booksCRUD/test/integration/pages/Create",
	"booksCRUD/booksCRUD/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "booksCRUD.booksCRUD.view."
	});

	sap.ui.require([
		"booksCRUD/booksCRUD/test/integration/MasterJourney",
		"booksCRUD/booksCRUD/test/integration/NavigationJourney",
		"booksCRUD/booksCRUD/test/integration/NotFoundJourney",
		"booksCRUD/booksCRUD/test/integration/BusyJourney",
		"booksCRUD/booksCRUD/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});