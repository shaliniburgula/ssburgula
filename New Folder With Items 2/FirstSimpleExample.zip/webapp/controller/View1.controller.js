sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("FirstSimpleExample.controller.View1", {

onClick  :function()
{
    var  input = this.getView().byId("idName").getValue();
    alert("Welcome to SAP UI5 Advance"+input);
}
	});

});