sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("GT.GridTable.controller.View1", {
		onInit: function () {
				var dataObject = [
				{Product: "Power Projector 4713", Weight: "33", Status :"Error"},
				{Product: "Gladiator MX", Weight: "33", Status :"Error"},
				{Product: "Hurricane GX", Weight: "45", Status :"Success"},
				{Product: "Webcam", Weight: "33", Status :"Error"},
				{Product: "Monitor Locking Cable", Weight: "41", Status :"Warning"},
				{Product: "Laptop Case", Weight: "64", Status :"Information"}]
				;
	
	var model = new sap.ui.model.json.JSONModel();
		model.setData({
			modelData: {
			productsData : []
			}
			});
		sap.ui.getCore().setModel(model);
		sap.ui.getCore().getModel().setProperty("/modelData/productsData", dataObject);
		this.getView().byId("table").setModel(model);
		
			
	var oTable = this.getView().byId("table");
	
		oTable.setRowSettingsTemplate(new sap.ui.table.RowSettings({
					highlight: "{Status}"
				}));
		
			var oTemplate = oTable.getRowActionTemplate();
			if (oTemplate) {
				oTemplate.destroy();
				oTemplate = null;
			}		
		oTemplate = new sap.ui.table.RowAction({items: [
							new sap.ui.table.RowActionItem({
								type: "Navigation",
								press: this.fnPress(),
								visible: true
							}),
							new sap.ui.table.RowActionItem({type: "Delete", press: this.fnPress()})
						]});
						
						oTable.setRowActionTemplate(oTemplate);
						oTable.setRowActionCount(2);
		
	/*var oItemNavigation = oTable.getItemNavigation();
	var oItemRef = oItemNavigation.getItemDomRefs();
	//oTable.getRows()[0].getCells()[0]
	
	for(var i = 1; i< oItemRef.length ; i++){
	var oDomRef = oItemRef[i].cells[0];
	var oCheckBoxId = oDomRef.childNodes[0].childNodes[0].id;
	var oTextMatch =  oTable.getAggregation("rows")[i-1].getCells()[1].getText();
	if(oTextMatch == "33"){
	var oSelectBox =  sap.ui.getCore().byId(oCheckBoxId);
	oSelectBox.setEnabled(false);
	}
	}*/
		},
		
		fnPress : function(){
			sap.m.MessageToast.show("hi");
		}
		
		
	});
});