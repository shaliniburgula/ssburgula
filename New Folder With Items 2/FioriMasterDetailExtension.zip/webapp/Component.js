jQuery.sap.declare("EmployeeDetails.FioriMasterDetailExtension.Component");
// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "EmployeeDetails",
	// Use the below URL to run the extended application when SAP-delivered application located in a local cloud environment:
	//url: jQuery.sap.getModulePath("EmployeeDetails.FioriMasterDetailExtension") + "/../../FioriMasterDetail"	
	// Use the below url to run the extended application when SAP-delivered application located in a cloud environment:
	url: jQuery.sap.getModulePath("EmployeeDetails.FioriMasterDetailExtension") +
		"/../orion/file/p1941489552trial$P1941489552-OrionContent/FioriMasterDetail" // we use a URL relative to our own component
		// extension application is deployed with customer namespace
});
this.EmployeeDetails.Component.extend("EmployeeDetails.FioriMasterDetailExtension.Component", {
	metadata: {
		version: "1.0",
		config: {},
		customizing: {
			"sap.ui.viewExtensions": {
				"EmployeeDetails.view.Master": {
					"extListItemInfo": {
						"className": "sap.ui.core.Fragment",
						"fragmentName": "EmployeeDetails.FioriMasterDetailExtension.view.Master_extListItemInfoCustom",
						"type": "XML"
					}
				}
			},
			"sap.ui.viewReplacements": {
				"EmployeeDetails.view.Master": {
					"viewName": "EmployeeDetails.FioriMasterDetailExtension.view.MasterCustom",
					"type": "XML"
				}
			},
			"sap.ui.controllerExtensions": {
				"EmployeeDetails.view.Master": {
					"controllerName": "EmployeeDetails.FioriMasterDetailExtension.view.MasterCustom"
				}
			}
		}
	}
});