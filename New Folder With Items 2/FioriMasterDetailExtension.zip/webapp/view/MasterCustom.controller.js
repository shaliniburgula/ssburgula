sap.ui.controller("EmployeeDetails.FioriMasterDetailExtension.view.MasterCustom", {
    go: function()
    {
        alert("fiori Cusmoication succefully completed");
    }
    
	//    onInit: function () {
	//        this.oInitialLoadFinishedDeferred = jQuery.Deferred();
	//        var oEventBus = this.getEventBus();
	//        oEventBus.subscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
	//        var oList = this.getView().byId("list");
	//        oList.attachEvent("updateFinished", function () {
	//            this.oInitialLoadFinishedDeferred.resolve();
	//            oEventBus.publish("Master", "InitialLoadFinished");
	//        }, this);
	//        if (sap.ui.Device.system.phone) {
	//            return;
	//        }
	//        this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
	//        oEventBus.subscribe("Detail", "Changed", this.onDetailChanged, this);
	//        oEventBus.subscribe("Detail", "NotFound", this.onNotFound, this);
	//    },
	//    onRouteMatched: function (oEvent) {
	//        var sName = oEvent.getParameter("name");
	//        if (sName !== "main") {
	//            return;
	//        }
	//        this.loadDetailView();
	//        this.waitForInitialListLoading(function () {
	//            this.selectFirstItem();
	//        });
	//    },
	//    onDetailChanged: function (sChanel, sEvent, oData) {
	//        var sEntityPath = oData.sEntityPath;
	//        this.waitForInitialListLoading(function () {
	//            var oList = this.getView().byId("list");
	//            var oSelectedItem = oList.getSelectedItem();
	//            if (oSelectedItem && oSelectedItem.getBindingContext().getPath() === sEntityPath) {
	//                return;
	//            }
	//            var aItems = oList.getItems();
	//            for (var i = 0; i < aItems.length; i++) {
	//                if (aItems[i].getBindingContext().getPath() === sEntityPath) {
	//                    oList.setSelectedItem(aItems[i], true);
	//                    break;
	//                }
	//            }
	//        });
	//    },
	//    onDetailTabChanged: function (sChanel, sEvent, oData) {
	//        this.sTab = oData.sTabKey;
	//    },
	//    loadDetailView: function () {
	//        this.getRouter().myNavToWithoutHash({
	//            currentView: this.getView(),
	//            targetViewName: "EmployeeDetails.view.Detail",
	//            targetViewType: "XML"
	//        });
	//    },
	//    waitForInitialListLoading: function (fnToExecute) {
	//        jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(fnToExecute, this));
	//    },
	//    onNotFound: function () {
	//        this.getView().byId("list").removeSelections();
	//    },
	//    selectFirstItem: function () {
	//        var oList = this.getView().byId("list");
	//        var aItems = oList.getItems();
	//        if (aItems.length) {
	//            oList.setSelectedItem(aItems[0], true);
	//            this.loadDetailView();
	//            oList.fireSelect({ "listItem": aItems[0] });
	//        } else {
	//            this.getRouter().myNavToWithoutHash({
	//                currentView: this.getView(),
	//                targetViewName: "EmployeeDetails.view.NotFound",
	//                targetViewType: "XML"
	//            });
	//        }
	//    },
	//    onSearch: function () {
	//        this.oInitialLoadFinishedDeferred = jQuery.Deferred();
	//        var filters = [];
	//        var searchString = this.getView().byId("searchField").getValue();
	//        if (searchString && searchString.length > 0) {
	//            filters = [new sap.ui.model.Filter("welltype", sap.ui.model.FilterOperator.Contains, searchString)];
	//        }
	//        this.getView().byId("list").getBinding("items").filter(filters);
	//        if (sap.ui.Device.system.phone) {
	//            return;
	//        }
	//        this.waitForInitialListLoading(function () {
	//            this.selectFirstItem();
	//        });
	//    },
	//    onSelect: function (oEvent) {
	//        this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
	//    },
	//    showDetail: function (oItem) {
	//        var bReplace = jQuery.device.is.phone ? false : true;
	//        this.getRouter().navTo("detail", {
	//            from: "master",
	//            entity: oItem.getBindingContext().getPath().substr(1),
	//            tab: this.sTab
	//        }, bReplace);
	//    },
	//    getEventBus: function () {
	//        return sap.ui.getCore().getEventBus();
	//    },
	//    getRouter: function () {
	//        return sap.ui.core.UIComponent.getRouterFor(this);
	//    },
	//    onExit: function (oEvent) {
	//        var oEventBus = this.getEventBus();
	//        oEventBus.unsubscribe("Detail", "TabChanged", this.onDetailTabChanged, this);
	//        oEventBus.unsubscribe("Detail", "Changed", this.onDetailChanged, this);
	//        oEventBus.unsubscribe("Detail", "NotFound", this.onNotFound, this);
	//    }
});