sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.drl.hcm.EMP_TRANSFER.controller.home", {

		onInit: function() {
			var oModel = new sap.ui.model.json.JSONModel({
				"Action": [{
					"key":0,
					"name": "Intra",
					"sub": [{
						"subno": "Intra BU (eg: BPE to HR)"
					}, {
						"subno": "Intra Unit (eg: HR-C&B to TAT)"
					}]
				}, {
					"key":1,
				"name": "Inter",
					"sub": [{
						"subno": "Inter BU (eg: CTO1 to FTO1)"
					}, {
						"subno": "Inter Unit (eg: FTO1 to FTO3)"
					}]
				}]
			});
			sap.ui.getCore().setModel(oModel, "actionModel");
			this.getView().byId("idSelectAction").setModel(oModel, "actionModel");       
			
				var oTimeModel = new sap.ui.model.json.JSONModel({
				"mgmtStatus": [{
					"key":0,
					"name": "No-Time evaluation"
				}, {
					"key":1,
					"name": "Time evaluation of actual times"
				}, {
					"key":2,
					"name": "PDC time evaluation"
				}, {
					"key":7,
					"name": "Time evaluation without payroll integration"
				}, {
					"key":8,
					"name": "External services"
				}, {
					"key":9,
					"name": "Time evaluation of planned times"
				}]
			});
			sap.ui.getCore().setModel(oTimeModel, "TimeModel");
			this.getView().byId("idSelectMgmtStatus").setModel(oTimeModel, "TimeModel");       
			
				var dialog = sap.ui.getCore().byId("idDialogEmployeeNo");
				if (dialog === undefined) {
					dialog = sap.ui.xmlfragment("com.drl.hcm.EMP_TRANSFER.fragments.employee", this.getView().getController());
					this.getView().addDependent(dialog);
				}
				dialog.open();
				//Code for not closing dialog when ESC key is pressed
				dialog.attachBrowserEvent("keydown", function(oEvent) {
					if(oEvent.keyCode === 27){
					oEvent.stopPropagation();
					oEvent.preventDefault();
					}
				});	
				
			
		},
		
		onSelectionAction: function(evt) {
			 var b = "";
		        b = evt.getParameter("selectedItem").getKey();
		    	this.subComboBind(b);
		},
		subComboBind : function(b){
			var data = sap.ui.getCore().getModel("actionModel").getData().Action[b];
    		var subModel = new sap.ui.model.json.JSONModel();
    		subModel.setData(data);
    		sap.ui.getCore().setModel(subModel,"subModel");
    		this.getView().byId("idSelectSubAction").setModel(subModel,"subModel");
  		},
  		onEmpNoSubmit : function(){
  				var dialog = sap.ui.getCore().byId("idDialogEmployeeNo");
  				dialog.close();
  		},
  		onChangeEmployee : function(){
  				var dialog = sap.ui.getCore().byId("idDialogEmployeeNo");
				if (dialog === undefined) {
					dialog = sap.ui.xmlfragment("com.drl.hcm.EMP_TRANSFER.fragments.employee", this.getView().getController());
					this.getView().addDependent(dialog);
				}
				dialog.open();
			
  		}
	});
});