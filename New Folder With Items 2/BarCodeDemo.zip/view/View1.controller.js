
sap.ui.controller("view.View1", {

onscan:function(){
    var input = this.getView().byId("idBarCode");
    
    cordova.plugins.barcodeScanner.scan(
        function(result){
            input.setValue(result.text);
        },
        function(error){
             sap.m.MessageBox.show("unable to scan due to improper barcode",{
                icon:  sap.m.MessageBox.Icon.ERROR,
                title:"ERROR",
                styleClass: "sapUiSizeCompact"
        });
        });
}

});