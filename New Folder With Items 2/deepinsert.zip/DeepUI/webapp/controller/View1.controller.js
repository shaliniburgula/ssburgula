sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("DeepUI.DeepUI.controller.View1", {
	 onPress : function(){
	 	var sPayload = {
	"Object":
	{
	    "Parent":{
	        "Id":-1,
	        "Description":"Deep Insert Parent Object",
	        "Temperature":25.2,
	        "Timestamp":20170511183353,
	        "Child":[{
	            "Id":-1,
	            "ParentId":-1,
	            "Description":"Deep Insert Child Object 1"
	        },
	        {
	            "Id":-1,
	            "ParentId":-1,
	            "Description":"Deep Insert Child Object 2"
	        }]
	    }
	}
};

var sUrl = 'https://ndve96svbus5180cinsert-nodejsdeep.cfapps.us10.hana.ondemand.com/DeepInsert.xsjs';
$.ajax({
	url:sUrl,
	type:'POST',
	data:JSON.stringify(sPayload),
	dataType:'json',
	contentType:'application/json',
	headers: {
		"Authorization": "Basic " + btoa('username:password')
	  },
	success: function(data) {
		alert(data.Id);
	},
	error: function(error) {
		alert(error.responseText ? error.responseText : error.statusText);
  }
});
	 }
	});
});