sap.ui.controller("accenture.view.View1", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf accenture.view.View1
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf accenture.view.View1
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf accenture.view.View1
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf accenture.view.View1
*/
//	onExit: function() {
//
//	}


onInit:function()
{
      var Datalist={
                  mydata:  [ 
                                            {
			     EmpName:'Samara',
			     EmpNo:"11110555",
			     Designation:"SE",
			     Location:"Hyderabad"
			     },
			     {
			     EmpName:'Sreenivas',
			     EmpNo:"63524189",
			     Designation:"TL",
			     Location:"Bangalore"
			     },
			     {
			     EmpName:'Siva',
			     EmpNo:"75421562",
			     Designation:"SSE",
			     Location:"Bangalore"
			     },
			     {
			     EmpName:'Balajee',
			     EmpNo:"12596384",
			     Designation:"SE",
			     Location:"Bangalore"
			     },
			     {
				     EmpName:'Ishita',
				     EmpNo:"12365895",
				      Designation:"ASE",
				      Location:"Bangalore"
		       }
	] 
		    
		};
	var mymodel= new sap.ui.model.json.JSONModel(Datalist);
	this.getView().setModel(mymodel);

}
});