sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("fragment.fragment.controller.View1", {

		Create: function () {
			if (!this._oCreateAllocDialog) {
				this._oCreateAllocDialog = sap.ui.xmlfragment("fragment.fragment.view.createDeep", this);
				this.getView().addDependent(this._oCreateAllocDialog);
			}
			var oModel = new sap.ui.model.json.JSONModel({
				assigmentno: "",
				rdes: "",
				fromdate: "",
				todate: "",
				slstrgt: "",
				cstmrtrgt: "",
				Assgstatus:"",
				statusText: "",
				allctdexpns: "",
				userid: "",
				assignedby: "",
				SalesTargetAch: "",
				worklog: {
					worklogno: "",
					custaddres: "",
					custphno: "",
					amount: "",
					statu: "",
					SalesStatusText: "",
					feedback: "",
					FeedbackDesc: "",
					prdid: "",
					quantity: "",
					custdetail: "",
					CreatedTime: ""
				}

			});

			this._oCreateAllocDialog.setModel(oModel);
			this._oCreateAllocDialog.open();
		},

		onCreate: function (oEvent) {

			var oModel = oEvent.getSource().getModel();
			console.log(oModel);

		}
	});
});