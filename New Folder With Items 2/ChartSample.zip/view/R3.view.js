sap.ui.jsview("accenture.view.R3",{
    
    getControllerName : function()
    {
        return "accenture.view.R3";
    },
    
    createContent: function(oController){
        var rPage = new sap.m.Page({
            title:"Report R3",
            showNavButton:true,
            navButtonTip:function()
            {
                app.to(page);
            }
        });
        
        var myModel= oController.getMyModel(2,3,14);
        var myChart=oController.createMyChart("R3Chart","R3 Chart",myModel);
        rPage.addContent(myChart);
        return rPage;
    }
    
});