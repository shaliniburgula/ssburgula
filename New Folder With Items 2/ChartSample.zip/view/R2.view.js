sap.ui.jsview("accenture.view.R2",{
    
    getControllerName : function()
    {
        return "accenture.view.R2";
    },
    
    createContent: function(oController){
        var rPage = new sap.m.Page({
            title:"Report R2",
            showNavButton:true,
            navButtonTip:function()
            {
                app.to(page);
            }
        });
        
        var myModel= oController.getMyModel(2,3,14);
        var myChart=oController.createMyChart("R2Chart","R2 Chart",myModel);
        rPage.addContent(myChart);
        return rPage;
    }
    
});