sap.ui.jsview("accenture.view.home", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf accenture.view.home
	*/ 
	getControllerName : function() {
		return "accenture.view.home";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf accenture.view.home
	*/ 
	createContent : function(oController) {
		 var imageTitle = new sap.m.Image({src: "images/Jellyfish.jpg", width: "20em", height: "10em", layoutData: new sap.m.FlexItemData({growFactor: 1})});
		 
         var imageR1 = new sap.m.Image({src: "images/Koala.jpg", width: "6.66em", height: "10em", layoutData: new sap.m.FlexItemData({growFactor: 1}),
                press: function(){
                            app.to(page_R1, "flip");
                   }
         });
         var imageR2 = new sap.m.Image({src: "images/Lighthouse.jpg", width: "6.66em", height: "10em", layoutData: new sap.m.FlexItemData({growFactor: 1}),
          press: function(){
                            app.to(page_R2, "flip");
                   }
         });
           var imageR3 = new sap.m.Image({src: "images/Tulips.jpg", width: "6.66em", height: "10em", layoutData: new sap.m.FlexItemData({growFactor: 1}),
            press: function(){
                            app.to(page_R3, "flip");
                   }
         });
             

        
        
         var hbox1 = new sap.m.HBox({
                   items: [imageTitle],
                   alignItems : sap.m.FlexAlignItems.Center
         });

         var hbox2 = new sap.m.HBox({
                   items: [imageR1,imageR2, imageR3],
                   alignItems : sap.m.FlexAlignItems.Center
         });

         var vbox1 = new sap.m.VBox({
                   items: [hbox1, hbox2],
                   alignItems : sap.m.FlexAlignItems.Center
         });

         return vbox1;

}


});