sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("Localization.controller.View1", {

    onInit: function()
    {
        var i18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl:".i18n/i18n.properties"
        });
        
        this.getView().setModel(i18nModel,"i18n");
    }
	});

});