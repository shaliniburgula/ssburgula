sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"K4XBS7/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("K4XBS7.Component", {

		metadata: {
			manifest: "json"
		},
	
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
		  var tableJsondata = {
				                  relateddata:[
				                               {Name:"X",systemName:"K4X"},
                                               {Name:"Y",systemName:"K4X"},
                                               {Name:"A",systemName:"BS7"},
                                               {Name:"B",systemName:"BS7"},
                                               {Name:"C",systemName:"BS7"}                                             
                                             
                                           ]
		  						};    
		 
		  var tableJsonObj = new sap.ui.model.json.JSONModel();
		  tableJsonObj.setData(tableJsondata);
		  sap.ui.getCore().setModel(tableJsonObj,"systemModel");

		}
	});
});