sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("hr.controller.Approver_2", {


			onnav:function(){
				sap.ui.core.UIComponent.getRouterFor(this).navTo("_Approver");
				
			},

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf hr.view.Approver_2
		 */
			onInit: function() {
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this._oRouter.attachRouteMatched(this._handleRouteMatched, this);
				var state = [{
				state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
				value: 10
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Negative,
				value: 20
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
				value: 30
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Planned,
				value: 40
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Critical,
				value: 50
			}];

			var oDataProcessFlowLanesOnly = {
				lanes: [{
					id: "0",
					icon: "sap-icon://accept",
					label: "Goal Setting",
					position: 0,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
						value: 10
					}]
				}, {
					id: "1",
					icon: "sap-icon://hr-approval",
					label: "Goal Approval",
					position: 1,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
						value: 10
					}]
				}, {
					id: "2",
					icon: "sap-icon://survey",
					label: "Half Yearly Review",
					position: 2
				}, {
					id: "3",
					icon: "sap-icon://activity-assigned-to-goal",
					label: "Goal Revisit",
					position: 3
				}, {
					id: "4",
					icon: "sap-icon://hr-approval",
					label: "Goal Approval",
					position: 4
				}, {
					id: "6",
					icon: "sap-icon://approvals",
					label: "Anuual Review",
					position: 5
				}, {
					id: "7",
					icon: "sap-icon://monitor-payments",
					label: "ARC",
					position: 6
				}, {
					id: "8",
					icon: "sap-icon://signature",
					label: "Final Sign Off",
					position: 7
				}]
			};

			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");

			viewPf2.byId("processflow2").updateModel();
			},
		_handleRouteMatched: function() {
			this.getView().byId("Appr_reject_cmnt").setVisible(false);
			
			this.getView().getController().setHeaderDet();
				this.getView().getController().goalsGET();
			
		},
		goalsGET: function(){
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MMM-yyyy"
				});
			var goals= sap.ui.getCore().GOALS.results;
			var functionalGoals = [];
			var projectGoals = [];
			for(var i=0;i<goals.length;i++){
				if(goals[i].GoalId ==='0001'){
					functionalGoals.push(goals[i]);
				}
				else if(goals[i].GoalId ==='0002'){
					projectGoals.push(goals[i]);
				}
			}
			//functional goal set
						var dat = sap.ui.getCore().ODThis.getView().getController().aData;
						dat = dat.concat(functionalGoals);
						sap.ui.getCore().ODThis.getView().getController().aData = dat;
						var list = sap.ui.getCore().ODThis.getView().byId("Func_list_Apr");
						var oModel = new sap.ui.model.json.JSONModel();
						var dt = [];
						
						for(var ii=0;ii<dat.length;ii++){
							var wtg = parseInt(dat[ii].Weightage);
							dt.push({
								"EmpId": dat[ii].EmpId,
								"GoalId":dat[ii]. GoalId,
								"GoalItemId":dat[ii].GoalItemId,
								"GoalName": dat[ii].GoalName,
								"Weightage": wtg + "%",
								"KraText": dat[ii].KraText,
								"KpiText": dat[ii].KpiText,
								"GoalDate":oDateFormat.format(dat[ii].GoalDate),
								"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
							});
						}
						oModel.setData({
							modelData: dt
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("func_ObjList_Apr");
						list.bindItems("/modelData", objlist);
				
			
			//project goal set
						dat = sap.ui.getCore().ODThis.getView().getController().aData_proj;
						dat = dat.concat(projectGoals);
						sap.ui.getCore().ODThis.getView().getController().aData_proj = dat;
						list = sap.ui.getCore().ODThis.getView().byId("Proj_list_Apr");
						oModel = new sap.ui.model.json.JSONModel();
						dt = [];
						
						for(ii=0;ii<dat.length;ii++){
							wtg = parseInt(dat[ii].Weightage);
							dt.push({
								"EmpId": dat[ii].EmpId,
								"GoalId":dat[ii]. GoalId,
								"GoalItemId":dat[ii].GoalItemId,
								"GoalName": dat[ii].GoalName,
								"Weightage": wtg + "%",
								"KraText": dat[ii].KraText,
								"KpiText": dat[ii].KpiText,
								"GoalDate": oDateFormat.format(dat[ii].GoalDate),
								"GoalSdate": oDateFormat.format(dat[ii].GoalSdate)
							});
						}
						oModel.setData({
							modelData: dt
						});
						list.setModel(oModel);
						var objlist = sap.ui.getCore().ODThis.getView().byId("proj_ObjList_Apr");
						list.bindItems("/modelData", objlist);
		},
		setHeaderDet: function(){
			var HDR_INFO = sap.ui.getCore().USERDATA;
			this.byId("HD").setObjectTitle(HDR_INFO.EmpName+" |");
			this.byId("HD").setObjectSubtitle(HDR_INFO.DesignText);
			this.byId("HD").setObjectImageURI(sap.ui.getCore().USERDATA.EmpImage);
			this.byId("HD_empcode").setText(" : "+HDR_INFO.EmpId);
			this.byId("HD_roleB").setText(" : "+HDR_INFO.BandText);
			this.byId("HD_dept").setText(" : "+HDR_INFO.DepartText);
			this.byId("HD_unit").setText(" : "+HDR_INFO.UnitText);
			this.byId("HD_mngNM").setText(" : "+HDR_INFO.ApprName);
			this.byId("HD_revNM").setText(" : "+HDR_INFO.OtherName);
			this.byId("HD_mmngr").setText(" : "+HDR_INFO.PartApprName);
			
		},


		radio_select : function(){
			var selectedkey = sap.ui.getCore().byId("Approver_2--__group0").getSelectedIndex();
			if(selectedkey === 1){
				this.getView().byId("Appr_reject_cmnt").setVisible(true);
			}
			else{
				this.getView().byId("Appr_reject_cmnt").setVisible(false);
			}
		},
		mngr_submit: function(){
				sap.ui.core.UIComponent.getRouterFor(this).navTo("_Approver",{});
		}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf hr.view.Approver_2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf hr.view.Approver_2
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf hr.view.Approver_2
		 */
		//	onExit: function() {
		//
		//	}

	});

});