sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("hr.controller.Approver", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf hr.view.Approver
		 */
			onInit: function() {
						this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						this._oRouter.attachRouteMatched(this._handleRouteMatched, this);
			},
			
			_handleRouteMatched: function() {
				var view = this.getView();
				sap.ui.getCore().ODThis = this;
				
				
			
				var apr_tbl = sap.ui.getCore().byId("Approver--TBL_APRLSTATUS");
				
				var data = [{Name:"Anil Reddy",WorkLevel:"R 1A",perfECTStatus : "Goal Setting",GoalSetting:"",GoalSetting2:"",GoalSetting3:"",GoalSetting4:"",GoalSetting5:"",GoalSetting6:"",GoalSetting7:""}];
				
				var oModel5 = new sap.ui.model.json.JSONModel();
				oModel5.setData({
					modelData: data
					
				});
			
				apr_tbl.setModel(oModel5);
				var template = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Label({
							text: "{Name}"
						}),
						new sap.m.Label({
							text: "{WorkLevel}"
						}),
							new sap.m.Link({
							text: "{perfECTStatus}",
							press:function(){
								
								sap.ui.core.UIComponent.getRouterFor(sap.ui.getCore().ODThis).navTo("_Approver_2");
							}
						
						}),
							new sap.ui.core.Icon({
							src:"sap-icon://circle-task-2"
						}).addStyleClass("icon"),
						new sap.ui.core.Icon({
							src:"sap-icon://border"
						}),
						new sap.ui.core.Icon({
							
						}),
						new sap.m.Label({
							text: "{GoalSetting4}"
						}),
						new sap.m.Label({
							text: "{GoalSetting5}"
						}),
						new sap.m.Label({
							text: "{GoalSetting6}"
						}),
						new sap.m.Label({
							text: "{GoalSetting7}"
						})
					]
				});
				apr_tbl.bindItems("/modelData", template);
				
			},
			handleLinkPress:function(){
				alert("h");
			},
			
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf hr.view.Approver
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf hr.view.Approver
		 */
			onAfterRendering: function() {
				var view = this.getView();
				
				
			},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf hr.view.Approver
		 */
		//	onExit: function() {
		//
		//	}
		onNavBack:function(){
			sap.ui.core.UIComponent.getRouterFor(this).navTo("_Login");

		}

	});

});