jQuery.sap.declare("com.accenture.CashFlow.Utils.Formatter");

jQuery.sap.require("sap.ui.core.Element");

com.accenture.CashFlow.Utils.Formatter = {
	currencyFormatter : function(oCurrValue){
			 var sBrowserLocale = "de-DE" ;//sap.ui.getCore().getConfiguration().getLanguage();
			var oLocale = new sap.ui.core.Locale(sBrowserLocale);
			var oLocaleData = new sap.ui.core.LocaleData(oLocale);
			var oCurrency = new sap.ui.model.type.Currency(oLocaleData.mData.currencyFormat);
			return oCurrency.formatValue([oCurrValue,"€"], "string");

		},

};