jQuery.sap.require("com.accenture.CashFlow.Utils.CustomFormatter");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/Popover',
	'sap/m/Button',
	'com/accenture/CashFlow/Utils/CustomFormatter'
], function (Controller, Popover, Button, CustomFormatter) {
	"use strict";

	return Controller.extend("com.accenture.CashFlow.controller.CashFlowHome", {
		onInit: function () {
				this.initCustomFormat();	
            var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						visible: true
					}

				},
				valueAxis: {
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				legend: {
					visible: true,
					title: {
						visible: false,
						text: "Current Month Net Cash by CompanyCode"
					}
				},
				title: {
					visible: true,
					text: "Current Month Net Cash by Company Code"
				}
			});
			this._oPopover = this.getView().byId("idPopOver");
			this._oPopover.connect(oVizFrame.getVizUid());
			this._oPopover.connect(oVizFrame.getVizUid());
			var scales = [{
				"feed": "color",
				"palette": ["#6d05b9", "#e60811", "#1a0a98", "#16b5e6"]
			}];
			oVizFrame.setVizScales(scales);
			
			
			//New code 
			var oVizFrame2 = this.oVizFrame2 = this.getView().byId("idVizFrame2");	
			var settingsModel = ({
				value: [["Cost1", "Revenue","Cost"]],
				vizType: ["stacked_combination"],
				dataset: [{
					dimensions: [{
						name: 'Week',
						value: "{Week}"
                    }],
					measures: [{
						name: 'Cost1',
					//	value: '{Cost1}'
					value : '{Cost1}'
                    }, {
						name: 'Revenue',
						value: '{Revenue}'
                   }, {
						name: 'Cost',
						value: '{Cost}'
                   }],
					data: {
						path: "/milk1"
					}
                }],
				rules: [{
					plotArea: {
					     
						dataPointStyle: {
						"rules": [
							{
							"dataContext": [{
								"Week": { in : ["Sep -17","Oct-17","Nov -17"]
								},
								"Revenue": "*"
							}],
							"properties": {
								"pattern": "diagonalLightStripe"
					
							},
							
							displayName: "Inflow Cash"
						},
						{
							"dataContext": [{
								"Week": { in : ["Sep -17","Oct-17","Nov -17"]
								},
								"Cost1": "*"
							}],
							"properties": {
								"pattern": "diagonalLightStripe"
							},
							displayName: "Outflow Cash"
						},
						{
							"dataContext": [{
								"Week": { in : ["Sep -17","Oct-17","Nov -17"]
								},
								"Cost": "*"
							}],
							"properties": {
						
                            "lineType":"dash"
							},
							displayName: "Net"
						}
						]
						}
					}
                }],
                
				commonrules: {
				plotArea: {
					dataLabel: {
						formatString: CustomFormatter.FIORI_LABEL_SHORTFORMAT_2,//'0,00,000.00€'
						visible: true
						
						
					},
					dataShape: {
						primaryAxis: ["bar", "bar", "line"]
					},
				/*	gridline:{
						type:"dash"
					}
				*//*	dataPoint:{
						stroke: {
							color:"#000fff"
						}
					}*/
				},
				valueAxis: {
					label:{
						formatString: '0,00,000.00€'
						},	
					title: {
						visible: false,
					
					}
				},
				categoryAxis: {
					title: {
						visible: true,
							text: "Monthly"
					}
				},
				legend: {
					visible: false,
					title: {
						visible: false,
						text: "Cash Flow Forecast"
					}
				},
				title: {
					visible: true,
					text: "Cash Flow Forecast"
				},
				legendGroup: {
			         layout: {
			             position: "bottom"
			       }

    				},
				}
			});
			var bindValue = settingsModel;
		
			var oPopOver = this.getView().byId("idPopOver2");

			var oDataset = new sap.viz.ui5.data.FlattenedDataset(bindValue.dataset[0]);
			oVizFrame2.setDataset(oDataset);
			oVizFrame2.setVizType(bindValue.vizType[0]);
			oVizFrame2.setVizProperties(bindValue.commonrules); 
			oVizFrame2.setVizProperties(bindValue.rules[0]);
			
				this._oPopover2 = this.getView().byId("idPopOver2");
			this._oPopover2.connect(oVizFrame2.getVizUid());
				var scales1 = [{
				"feed": "color",
				"palette": ["#bb0f0f", "#689652", "#ffec14", "#060e00", "#bb0f0f"]
			}];
			oVizFrame2.setVizScales(scales1);

			var feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': ["Week"]
				}),
			 feedActualValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Cost1"]
				}),
				feedAdditionalValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Revenue"]
				}),
				feedCostValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Cost"]
				});
			
			oVizFrame2.removeAllFeeds(); 
			oVizFrame2.addFeed(feedCategoryAxis);
			oVizFrame2.addFeed(feedActualValues);
			oVizFrame2.addFeed(feedAdditionalValues);
			oVizFrame2.addFeed(feedCostValues);
			

			//New code for VizFrame3
				var oVizFrame3 = this.oVizFrame3 = this.getView().byId("idVizFrame3");	
			var settingsModelBB = ({
				value: [["Cost1", "Revenue","Cost"]],
				vizType: ["stacked_combination"],
				dataset: [{
					dimensions: [{
						name: 'Week',
						value: "{Week}"
                    }],
					measures: [{
						name: 'Cost1',
						value: '{Cost1}'
                    }, {
						name: 'Revenue',
						value: '{Revenue}'
                   }, {
						name: 'Cost',
						value: '{Cost}'
                   }],
					data: {
						path: "/milk1"
					}
                }],
				rules: [{
					plotArea: {
					     
						dataPointStyle: {
						"rules": [
							{
							"dataContext": [{
								"Week": { in : ["Sep -17","Oct-17","Nov -17"]
								},
								"Revenue": "*"
							}],
							"properties": {
							"lineType":"dash"
								
							},
							displayName: "Net cash flow"
						},
						{
							"dataContext": [{
								"Week": { in : ["Sep -17","Oct-17","Nov -17"]
								},
								"Cost1": "*"
							}],
							"properties": {
								"lineType":"dash"
							},
							displayName: "Opening Balance"
						},
						{
							"dataContext": [{
								"Week": { in : ["Sep -17","Oct-17","Nov -17"]
								},
								"Cost": "*"
							}],
							"properties": {
						
                            "lineType":"dash"
							},
							displayName: "Ending Balance"
						}
						]
						}
					}
                }],
                
				commonrules: {
				plotArea: {
					dataLabel: {
						visible: true,
						
					},
					dataShape: {
						primaryAxis: ["line", "line", "line"]
					}
				},
				valueAxis: {
					label:{
						formatString: '0,00,000.00€'
					},	
					title: {
						visible: false,
					
					}
				},
				categoryAxis: {
					title: {
						visible: true,
							text: "Monthly"
					}
				},
			legend: {
					visible: false,
					title: {
						visible: false,
						text: "Opening and Ending Bank Balance Trend"
					}
				},
				title: {
					visible: true,
					text: "Opening and Ending Bank Balance Trend"
				},
				legendGroup: {
			         layout: {
			             position: "bottom"
			       }

    				},
				}
			});
			var bindValueBB = settingsModelBB;
		
			var oPopOverBB = this.getView().byId("idPopOver3");

			var oDatasetBB = new sap.viz.ui5.data.FlattenedDataset(bindValue.dataset[0]);
			oVizFrame3.setDataset(oDatasetBB);
			oVizFrame3.setVizType(bindValueBB.vizType[0]);
			oVizFrame3.setVizProperties(bindValueBB.commonrules); 
			oVizFrame3.setVizProperties(bindValueBB.rules[0]);
			
				this._oPopover3 = this.getView().byId("idPopOver3");
			this._oPopover3.connect(oVizFrame3.getVizUid());
			
		
			var feedCategoryAxisBB = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': ["Week"]
				}),
			 feedActualValuesBB = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Cost1"]
				}),
				feedAdditionalValuesBB = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Revenue"]
				}),
				feedCostValuesBB = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Cost"]
				});
			
			oVizFrame3.removeAllFeeds(); 
			oVizFrame3.addFeed(feedCategoryAxisBB);
			oVizFrame3.addFeed(feedActualValuesBB);
			oVizFrame3.addFeed(feedAdditionalValuesBB);
			oVizFrame3.addFeed(feedCostValuesBB);
			/*
			var oVizFrame3 = this.oVizFrame3 = this.getView().byId("idVizFrame3");
			oVizFrame3.setVizProperties({
				plotArea: {
					dataLabel: {
						visible: true
					},
					window: {
						start: "firstDataPoint",
						end: "lastDataPoint"
					}

				},
				valueAxis: {
					title: {
						visible: true
					}
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				legend: {
					visible: true,
					title: {
						visible: false,
						text: "Opening and Ending Bank Balance Trend"
					}
				},
				title: {
					visible: true,
					text: "Opening and Ending Bank Balance Trend"
				}
			});
			this._oPopover3 = this.getView().byId("idPopOver3");
			this._oPopover3.connect(oVizFrame3.getVizUid());
			this._oPopover3.connect(oVizFrame3.getVizUid());
				var scale3s = [{
					"feed": "color",
					"palette": ["#6d05b9", "#e60811", "#1a0a98", "#16b5e6"]
				}];
				oVizFrame.setVizScales(scales);
			*/
		},
		onSetupPress: function (event) {
			var popover = new Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [
					new Button({
						text: '	Save Screen Variant as',
						type: sap.m.ButtonType.Transparent
					}),
					new Button({
						text: 'Open Screen Variant',
						type: sap.m.ButtonType.Transparent
					}),
					new Button({
						text: 'Save default view',
						type: sap.m.ButtonType.Transparent
					})
				]
			}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

			popover.openBy(event.getSource());
		},
		onReportPress: function (event) {
			var popover = new Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [
					new Button({
						text: '	Print',
						type: sap.m.ButtonType.Transparent
					}),
					new Button({
						text: 'Send by e-mail',
						type: sap.m.ButtonType.Transparent
					}),
					new Button({
						text: 'Export to Excel Sheet ',
						type: sap.m.ButtonType.Transparent
					})
				]
			}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

			popover.openBy(event.getSource());
		},
		onBank: function () {
			this.getView().byId("idVizFrame2").setVisible(false);
			this.getView().byId("idVizFrame").setVisible(false);
			this.getView().byId("idVizFrame3").setVisible(true);
			this.getView().byId("id4").setVisible(true);
			this.getView().byId("id5").setVisible(true);
			this.getView().byId("id6").setVisible(true);
			this.getView().byId("id1").setVisible(false);
			this.getView().byId("id2").setVisible(false);
			this.getView().byId("id3").setVisible(false);
		},
		onCash: function () {
			this.getView().byId("idVizFrame2").setVisible(true);
			this.getView().byId("idVizFrame").setVisible(true);
			this.getView().byId("idVizFrame3").setVisible(false);
			this.getView().byId("id4").setVisible(false);
			this.getView().byId("id5").setVisible(false);
			this.getView().byId("id6").setVisible(false);
			this.getView().byId("id1").setVisible(true);
			this.getView().byId("id2").setVisible(true);
			this.getView().byId("id3").setVisible(true);
		},
		onHomePress: function () {
			this.onCash();
		},
		currencyFormatter : function(){
			alert("currValue");
		},
		initCustomFormat: function() {
			CustomFormatter.registerCustomFormat();
		},

	});
});