/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function() {
	"use strict";

	sap.ui.require([
		"FC/FC/test/integration/PhoneJourneys"
	], function() {
		QUnit.start();
	});
});