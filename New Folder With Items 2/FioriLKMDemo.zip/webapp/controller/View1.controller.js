sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("accenture.controller.View1", {
          go: function()
          {
              this.getOwnerComponent().getRouter().navTo("secondView");
          }
	});

});