sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("Local.controller.View1", {
	
	onInit: function()
	{
                 

var i18nModel = new sap.ui.model.resource.ResourceModel({
	bundleUrl:"./i18n/i18n.properties"

});

this.getView().setModel(i18nModel,"i18n");

    var browLang = 	sap.ui.getCore().getConfiguration().getLanguage();
    
  
    	this.getView().byId("idLang").setSelectedKey(browLang);
   
  

	},
	languageChange : function()
	{
		var selectedLang = this.getView().byId("idLang").getSelectedItem().getKey();
	
			sap.ui.getCore().getConfiguration().setLanguage(selectedLang);
	}
	
	});

});