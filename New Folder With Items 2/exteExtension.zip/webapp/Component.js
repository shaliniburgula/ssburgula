jQuery.sap.declare("test.exteExtension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "test",
	// Use the below URL to run the extended application when SAP-delivered application located in a local cloud environment:
	//url: jQuery.sap.getModulePath("test.exteExtension") + "/../../exte/webapp"	
	// Use the below url to run the extended application when SAP-delivered application located in a cloud environment:
	url: jQuery.sap.getModulePath("test.exteExtension") + "/../orion/file/p1941489552trial$P1941489552-OrionContent/exte/webapp"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.test.Component.extend("test.exteExtension.Component", {
	metadata: {
		manifest: "json"
	}
});