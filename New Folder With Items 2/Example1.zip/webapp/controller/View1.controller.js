sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("Example1.controller.View1", {



onPress : function()
{
	var oRouter =  sap.ui.core.UIComponent.getRouterFor(this); 
	oRouter.navTo("view2");

}
	});

});