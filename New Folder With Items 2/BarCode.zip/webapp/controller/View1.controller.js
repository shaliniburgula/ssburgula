var Latitude = undefined;
var Longitude = undefined;
var map = null;
var geocoder = new google.maps.Geocoder();
var formatedAddress = " ";
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("BarCode.controller.View1", {
		onscan: function() {
			var input = this.getView().byId("idBarCode");
			 navigator.geolocation.getCurrentPosition(this.onMapSuccess, this.onMapError, { enableHighAccuracy: true });

			cordova.plugins.barcodeScanner.scan(
				function(result) {
					input.setValue(result.text);
				},
				function(error) {
					sap.m.MessageBox.show("unable to scan due to improper barcode", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "ERROR",
						styleClass: "sapUiSizeCompact"
					});
				});
		},


		onMapSuccess: function(position) {

			Latitude = position.coords.latitude;
			Longitude = position.coords.longitude;

			// this.getMap(Latitude, Longitude);
			var mapOptions = {
				center: new google.maps.LatLng(Latitude, Longitude),
				zoom: 1,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};

			map = new google.maps.Map(document.getElementById("__xmlview0--map_canvas"), mapOptions);

			var latLong = new google.maps.LatLng(Latitude, Longitude);

			var marker = new google.maps.Marker({
				position: latLong
			});
			var that = this;
			marker.setMap(map);
			map.setZoom(15);
			map.setCenter(marker.getPosition());
			geocoder.geocode({
					latLng: latLong
				},
				function(responses) {
					if (responses && responses.length > 0) {
						formatedAddress = responses[0].formatted_address;
						//console.log(document.getElementById("__xmlview0--idAddress"));
						sap.m.MessageToast.show("You are at : " + formatedAddress);
					} else {
						sap.m.MessageToast.show('Not getting Any address for given latitude and longitude.');
					}
				});
		},

		// Get map by using coordinates 

		getMap: function(latitude, longitude) {

			var mapOptions = {
				center: new google.maps.LatLng(0, 0),
				zoom: 1,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};

			map = new google.maps.Map(document.getElementById("map"), mapOptions);

			var latLong = new google.maps.LatLng(latitude, longitude);

			var marker = new google.maps.Marker({
				position: latLong
			});

			marker.setMap(map);
			map.setZoom(15);
			map.setCenter(marker.getPosition());
		},

		// Success callback for watching your changing position 

		onMapWatchSuccess: function(position) {

			var updatedLatitude = position.coords.latitude;
			var updatedLongitude = position.coords.longitude;

			if (updatedLatitude != Latitude && updatedLongitude != Longitude) {

				Latitude = updatedLatitude;
				Longitude = updatedLongitude;

				this.getMap(updatedLatitude, updatedLongitude);
			}
		},

		// Error callback 

		onMapError: function(error) {
			console.log('code: ' + error.code + '\n' +
				'message: ' + error.message + '\n');
		},

		// Watch your changing position 

		watchMapPosition: function() {

			return navigator.geolocation.watchPosition(this.onMapWatchSuccess, this.onMapError, {
				enableHighAccuracy: true
			});
		},
		onPressOut : function(){
		    var barCode = this.getView().byId("idBarCode").getValue();
		    var outBarCodeArr = new Array();
		    outBarCodeArr = barCode.split(';');
		    var fromLoc = formatedAddress;
		    	var oDataModel = new sap.ui.model.odata.ODataModel("http://sapnwg75d.mydrreddys.com:8001/sap/opu/odata/sap/ZCODE_SCAN_SRV/", true,"developer01","devngw75"); 
		    //	var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZCODE_SCAN_SRV/", true); 
		    	var createPath = "BarCodeDetailsSet"
		    	
		    	var disYR = outBarCodeArr[1].substring(0, 4);
		    	var disMM = outBarCodeArr[1].substring(4,6);
		    	var disDD = outBarCodeArr[1].substring(6,8);
		    var	outObj = {
				DeliveryNote: outBarCodeArr[0],
				DispatchDate: disYR+"-"+disMM+"-"+disDD+"T00:00:00",
			   /* DeletionIndicator :outBarCodeArr[2],*/
			    Plant : outBarCodeArr[2] ,
			    Payer: outBarCodeArr[3],
			    TotalCases : outBarCodeArr[4],
			    VehicleNo : outBarCodeArr[5],
			    DestLocation : outBarCodeArr[6],
			    FromLocation : fromLoc
			};
		    	oDataModel.create(createPath, outObj, null, function(responseBody, sucRes) {
                    sap.m.MessageBox.show("Data saved successfully");
				}, function(failRes) {
					var errorBodyAdd = JSON.parse(failRes.response.body);
						sap.m.MessageBox.error("\\n Error Message: " + errorBodyAdd.error.message.value);

				});
		    
		},
		/*onPressIn : function(){
		    var deliveryNote = this.getView().byId("idBarCode").getValue();
		    var batch="xyz";
		    var toLoc = formatedAddress;
		    	var oDataModel = new sap.ui.model.odata.ODataModel("http://sapnwg75d.mydrreddys.com:8001/sap/opu/odata/sap/ZCODE_SCAN_SRV/", true); 
		    	var updatePath = "BarCodeDetailsSet(DeliveryNote='"+deliveryNote+"',Batch='"+batch+"')";
		    	
		    var		inObj = {
				DeliveryNote: deliveryNote,
				Batch: batch,
			    EndLocation:"abc"
			};
		    	oDataModel.update(updatePath, inObj, null, function(responseBody, sucRes) {
                    sap.m.MessageToast.show("Data updated successfully");
				}, function(failRes) {
					var errorBodyUpdate = JSON.parse(failRes.response.body);
						sap.m.MessageBox.error("\\n Message: " + errorBodyUpdate.error.message.value);


				});
		    
		}*/
	});
});