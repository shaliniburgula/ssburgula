jQuery.sap.declare("accenture.MasterDetailEmployeesExtension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "accenture",
	// Use the below URL to run the extended application when SAP-delivered application located in a local cloud environment:
	//url: jQuery.sap.getModulePath("accenture.MasterDetailEmployeesExtension") + "/../../MasterDetailEmployees/webapp"	
	// Use the below url to run the extended application when SAP-delivered application located in a cloud environment:
	url: jQuery.sap.getModulePath("accenture.MasterDetailEmployeesExtension") +
		"/../orion/file/p1941489552trial$P1941489552-OrionContent/MasterDetailEmployees/webapp"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.accenture.Component.extend("accenture.MasterDetailEmployeesExtension.Component", {
	metadata: {
		manifest: "json"
	}
});