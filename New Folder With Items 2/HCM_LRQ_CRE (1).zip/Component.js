/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myleaverequest.Component");
jQuery.sap.require("hcm.myleaverequest.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
sap.ca.scfld.md.ComponentBase.extend("hcm.myleaverequest.Component", {
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
		"name": "My Leave Request",
		"version": "1.7.15",
		"library": "hcm.myleaverequest",
		"includes": ["css/scfld.css"],
		"dependencies": {
			"libs": ["sap.m", "sap.me"],
			"components": []
		},
		"config": {
			"resourceBundle": "i18n/i18n.properties",
			"titleResource": "app.Identity"
		},
		viewPath: "hcm.myleaverequest.view",
		masterPageRoutes: {
			"master": {
				"pattern": "history",
				"view": "S3"
			}
		},
		detailPageRoutes: {
			"detail": {
				"pattern": "detail/{contextPath}",
				"view": "S6B"
			}
		},
		fullScreenPageRoutes: {
			"home": {
				"pattern": "",
				"view": "S1"
			},
			"change": {
				"pattern": "change/{requestID}",
				"view": "S1"
			},
			"entitlements": {
				"pattern": "entitlements",
				"view": "S2"
			}
		}
	}),
	createContent: function() {
		var v = {
			component: this
		};
		return sap.ui.view({
			viewName: "hcm.myleaverequest.Main",
			type: sap.ui.core.mvc.ViewType.XML,
			viewData: v
		});
	}
});