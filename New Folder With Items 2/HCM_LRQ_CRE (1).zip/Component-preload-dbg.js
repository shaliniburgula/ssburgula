jQuery.sap.registerPreloadedModules({
"name":"hcm/myleaverequest/Component-preload",
"version":"2.0",
"modules":{
	"hcm/myleaverequest/Component.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myleaverequest.Component");
jQuery.sap.require("hcm.myleaverequest.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

sap.ca.scfld.md.ComponentBase.extend("hcm.myleaverequest.Component", {
		metadata : sap.ca.scfld.md.ComponentBase.createMetaData("MD", {
			"name" : "My Leave Request",
			"version" : "1.7.15",
			"library" : "hcm.myleaverequest",
			"includes" : ["css/scfld.css"],
				"dependencies" : {
				"libs" : ["sap.m", "sap.me"],
			"components" : []
			},
			"config" : {
				"resourceBundle" : "i18n/i18n.properties",
				"titleResource" : "app.Identity"
			//	"icon" : "sap-icon://Fiori2/F0002",
			//	"favIcon" : "./resources/sap/ca/ui/themes/base/img/favicon/F0002_My_Accounts.ico",
			//	"homeScreenIconPhone" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/57_iPhone_Desktop_Launch.png",
			//	"homeScreenIconPhone@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/114_iPhone-Retina_Web_Clip.png",
			//	"homeScreenIconTablet" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/72_iPad_Desktop_Launch.png",
			//	"homeScreenIconTablet@2" : "./resources/sap/ca/ui/themes/base/img/launchicon/F0002_My_Accounts/144_iPad_Retina_Web_Clip.png",
		},
		viewPath : "hcm.myleaverequest.view",
		
		masterPageRoutes : {
			"master" : {
				"pattern" : "history",
				"view" : "S3"				
			}
		},
		
		detailPageRoutes :{
			// fill the routes to your detail pages in here. The application will navigate from the master
			// page to route
			// "detail" leading to detail screen S3.
			// If this is not desired please define your own route "detail"
			"detail" : {
					"pattern" : "detail/{contextPath}",
					"view" : "S6B"
			}
		},
		
		fullScreenPageRoutes : {
			// fill the routes to your full screen pages in here.
				"home" : {
					"pattern" : "",
					"view" : "S1"
				},
				"change" : {
					"pattern" : "change/{requestID}",
					"view" : "S1"
				},
				"entitlements" : {
					"pattern" : "entitlements",
					"view" : "S2"
				}
			}
	}),
	
	/**
	 * Initialize the application
	 *
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {

		var oViewData = {
			component : this
		};
		return sap.ui.view({
			viewName : "hcm.myleaverequest.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	}
});

},
	"hcm/myleaverequest/Configuration.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myleaverequest.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("hcm.myleaverequest.Configuration", {
	oServiceParams: {
		serviceList: [{		
			name: "My Leave Request",
			masterCollection: "LeaveRequestCollection",
			serviceUrl: "/sap/opu/odata/sap/HCM_LEAVE_REQ_CREATE_SRV/", //oData service relative path
			isDefault: true,
			mockedDataSource: "/hcm.myleaverequest/model/metadata.xml"
		}]
	},

	getServiceParams : function() {
		return this.oServiceParams;
	},

	/**
	 * @inherit
	 */
	getServiceList : function() {
		return this.getServiceParams().serviceList;
	},

	getMasterKeyAttributes : function() {
		//return the key attribute of your master list item
		return ["Id"];
	}
});
},
	"hcm/myleaverequest/Main.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.myleaverequest.Main", {
	/*global hcm:true*/
	onInit: function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		sap.ca.scfld.md.Startup.init("hcm.myleaverequest", this);
	},
	onExit: function() {
		//exit cleanup code here
		try {
			var oController = hcm.myleaverequest.utils.ConcurrentEmployment.getControllerInstance();
			hcm.myleaverequest.utils.UIHelper.setPernr("");
			if (oController.oCEDialog.isOpen()) {
				oController.oCEDialog.Cancelled = true;
				oController.oCEDialog.close();
			}
		} catch (e) {
			jQuery.sap.log.error("couldn't execute onExit", ["onExit failed in main controller"], ["hcm.myleaverequest.Main"]);
		}
	}
});
},
	"hcm/myleaverequest/Main.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core" xmlns="sap.m"\n\tcontrollerName="hcm.myleaverequest.Main" displayBlock="true" height="100%">\n\t<NavContainer id="fioriContent" showHeader="false">\n\t</NavContainer>\n</core:View>',
	"hcm/myleaverequest/i18n/i18n.properties":'# Texts for the leave request create app\n# __ldi.translation.uuid=4e51c570-5913-11e4-8ed6-0800200c9a66\n# GUID was created with http://www.famkruithof.net/uuid/uuidgen\n# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n\n#XTIT: Application name (shown in browser header bar or as browser tab title)\napp.Identity=My Leave Requests\n\n#XTIT: title of the home view\nLR_TITLE_HOME_VIEW=My Leave Requests\n\n#XTIT: title of the leave create view\nLR_TITLE_CREATE_VIEW=Request Leave\n\n#XTIT: title of the leave change view\nLR_TITLE_CHANGE_VIEW=Change Leave Request\n\n#XTIT: title of the Entitlements view\nLR_TITLE_BALANCE_VIEW=Entitlements\n\n#XTIT: title of the leave History view\nLR_TITLE_HISTORY_VIEW=History\n\n#XTIT: title of the leave details view\nLR_TITLE_DETAILS_VIEW=Leave Details\n\n#XTIT: title of the leave requests\nLR_TITLE_LEAVE_REQUESTS=Leave Requests\n\n#XTIT: title of the leave request\nLR_TITLE_LEAVE_REQUEST=Leave Request\n\n#XTIT: deductible\nLR_BALANCE_DEDUCTIBLE=Category\n\n#XTIT: Balance\nLR_BALANCE_BALANCE=Available\n\n#XTIT: Used\nLR_BALANCE_USED=Used\n\n#XTIT: Requested\nLR_BALANCE_REQUESTED=Requested\n\n#XTIT: Quota\nLR_BALANCE_QUOTA=Entitlements\n\n#XTIT: Entitlement\nLR_ENTITLEMENT_QUOTA=Entitlement\n\n#XTIT: Send leave request\nLR_TITLE_SEND=Send Leave Request\n\n#XTIT: Cancel leave request\nLR_TITLE_WITHDRAW=Withdraw Leave Request\n\n#XTIT: ATTENTION Tile text line break after 12 characters!\nLR_BALANCE_TILE=Entitlements \n\n#XTIT: ATTENTION Tile text line break after 12 characters!\nLR_HISTORY_TILE=History\n\n#XTIT: ATTENTION Tile text line break after 12 characters!\nLR_CREATE_LEAVE_TILE=Create Leave Request\n\n#XBUT\nLR_SHOW_HIST=History\n\n#XBUT\nLR_CREATE_LEAVE=Request Leave\n\n#XBUT: text for "send leave request" button\nLR_SEND=Send\n\n#XBUT: text for ok button \nLR_OK=OK\n\n#XBUT: text for reset button \nLR_RESET=Reset\n\n#XBUT: text for cancel button e.g. on the day range picker screen\nLR_CANCEL=Cancel\n\n#XBUT: text for change button on the Leave Overview details screen\nLR_CHANGE=Change\n\n#XBUT: text for cancel button on the Leave Overview details screen\nLR_WITHDRAW=Withdraw\n\n#XSEL\nLR_UPDATED=Updated \n\n#XFLD\nLR_NOTE=Note\n\n#XFLD\nLR_CUSTOM1=Custom Field 1\n\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\nLR_BOOKED=used\n\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\nLR_REMAINING=available\n\n#XFLD\nLR_LOWERCASE_DAYS=days\n\n#XFLD\nLR_LOWERCASE_DAY=day\n\n#XFLD\nLR_LOWERCASE_HOURS=hours\n\n#XFLD\nLR_LOWERCASE_HOUR=hour\n\n#XFLD\nLR_UP_TO=Valid Upto\n\n#XFLD\nLR_FROM=From\n\n#XFLD\nLR_TO=To\n\n#XFLD: Hyphen for Date Formatting\nLR_HYPHEN=-\n\n#XTIT: title of error dialog\nLR_PROBLEM=A problem occurred\n\n#XTIT: title of confirmation dialog\nLR_CONFIRMATION=Confirmation\n\n#YMSG\nLR_CONFIRMATIONMSG=Do you want to send this leave request to {0}?\n\n#YMSG\nLR_WITHDRAWNMSG=Do you want to withdraw this leave request?\n\n#XFLD\nLR_DAYS=days\n\n#XFLD\nLR_DAY=day\n\n#XFLD\nLR_HOURS=hours\n\n#XFLD\nLR_HOUR=hour\n\n#XFLD\nLR_REQUEST=Requested\n\n#XSEL: day type (legend)\nLR_DTYPE_TODAY=Today\n\n#XSEL: day type (legend)\nLR_DTYPE_SELECTED=Selected Day\n\n#YMSG: processing\nLR_PROCESSING=Processing...\n\n#YMSG\nLR_SUBMITDONE=Your leave request was sent to {0}\n\n#YMSG\nLR_WITHDRAWDONE=Your leave request was withdrawn\n\n#YMSG\nLR_AX_MODEL_NOT_REG=A technical problem has occurred\\n\\nError Details:\\nInternal error; model not registered\n\n#YMSG\nLR_AX_PARSE_ERR=A technical problem has occurred\\n\\nError Details:\\nProtocol error; could not parse HTTP response\n\n#YMSG\nLR_DD_NO_APPROVER=A technical problem has occurred\\n\\nError Details:\\nProtocol error; approver name missing in response\n\n#YMSG\nLR_DD_NO_CFG=A technical problem has occurred\\n\\nError Details:\\nProtocol error; configuration missing in response\n\n#YMSG\nLR_DD_NO_BALANCES=A technical problem has occurred\\n\\nError Details:\\nProtocol error; balances missing in response\n\n#YMSG\nLR_DD_PARSE_ERR=A technical problem has occurred\\n\\nError Details:\\nProtocol error; could not parse response\n\n#YMSG\nLR_DD_COMM_ERR=A problem has occurred with your connection\n\n#YMSG\nLR_DD_GENERIC_ERR=An error has occurred\n\n#YMSG\nLR_CT_PARSE_ERR=A technical problem has occurred\\n\\nError Details:\\nProtocol error; Could not parse response\n\n#XFLD\nLR_S1_PENDING:Pending\n\n#YMSG\nLR_UNKNOWN=Unknown\n\n#XSEL: (legend)\nLR_NONWORKING=Non-Working Day\n\n#XSEL: (legend)\nLR_APPROVELEAVE=Approved\n\n#XSEL: (legend)\nLR_REJECTEDLEAVE=Rejected \n\n#XSEL: (legend)\nLR_APPROVEPENDING=Approval Pending\n\n#XSEL: (legend)\nLR_PUBLICHOLIDAY=Public Holiday\n\n#XSEL: (legend)\nLR_WORKINGDAY=Working Day\n\n#XSEL: (legend)\nLR_DELETIONREQUESTED=Cancellation Requested\n\n#XTIT\nLR_DELETION_REQ=Cancellation Request\n\n#XTIT\nLR_CHANGE_REQ=Change Request\n\n#XTIT\nLR_CHANGE_PENDING=Change Pending\n\n#XTIT\nLR_CANCEL_PENDING=Cancellation Pending\n\n#XTIT\nLR_CHANGE_DONE=Change Approved\n\n#XTIT\nLR_CANCEL_DONE=Cancellation Approved\n\n#XTIT: Original\nLR_OLD_VERSION=Original\n\n#XTIT: Leave Changes\nLR_NEW_VERSION=Changed\n\n#XFLD: Label for Approver Selection\nLR_APPROVER=Approver\n\n#XFLD: Label for Attendance/Absence Hours\nLR_ABS_HOURS=Att./Absence Hours\n\n#XFLD: Label for Attachments\nLR_ATTACHMENTS=Attachments\n\n#XFLD: Placeholder for Attachments\nLR_ATTACHMENT= Add attachment\n\n#XFLD: Label for Start Time\nLR_START_TIME=Start Time\n\n#XFLD: Label for Start Time\nLR_END_TIME=End Time\n\n#YMSG: Error message to display, if the file upload fails\nLR_ATTACHMENT_ERROR= Cannot upload the attachment. \n\n#YMSG: warning message to show if the file type is not supported\nLR_ATTACHMENT_TYPECHECK= This attachment type is not supported. \n\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\nLR_ATTACHMENT_SIZECHECK= File size is too big. Please select a file less than 25MB.\n\n#XFLD: Select Personnel Assignment Label\nPERSONAL_ASSIGN=Choose a Personnel Assignment\n\n#XTIT: Select Personnel Assignment Title\nPERSONAL_ASSIGN_TITLE=Personnel Assignments\n\n',
	"hcm/myleaverequest/i18n/i18n_ar.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=\\u0637\\u0644\\u0628\\u0627\\u062A \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u064A\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=\\u0637\\u0644\\u0628\\u0627\\u062A \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0627\\u0644\\u062E\\u0627\\u0635\\u0629 \\u0628\\u064A\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=\\u062A\\u063A\\u064A\\u064A\\u0631 \\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=\\u0627\\u0644\\u062D\\u0642\\u0648\\u0642\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=\\u0627\\u0644\\u0633\\u062C\\u0644\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u0637\\u0644\\u0628\\u0627\\u062A \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=\\u0627\\u0644\\u0641\\u0626\\u0629\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=\\u0645\\u062A\\u0648\\u0641\\u0631\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=\\u0645\\u0633\\u062A\\u062E\\u062F\\u064E\\u0645\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=\\u0645\\u0637\\u0644\\u0648\\u0628\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=\\u0627\\u0644\\u062D\\u0642\\u0648\\u0642\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=\\u0627\\u0644\\u062D\\u0642\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=\\u0625\\u0631\\u0633\\u0627\\u0644 \\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=\\u0633\\u062D\\u0628 \\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=\\u0627\\u0644\\u062D\\u0642\\u0648\\u0642\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=\\u0627\\u0644\\u0633\\u062C\\u0644\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=\\u0625\\u0646\\u0634\\u0627\\u0621 \\u0637\\u0644\\u0628 \\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XBUT\r\nLR_SHOW_HIST=\\u0633\\u062C\\u0644\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u0637\\u0644\\u0628 \\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=\\u0625\\u0631\\u0633\\u0627\\u0644\r\n\r\n#XBUT: text for ok button \r\nLR_OK=\\u0645\\u0648\\u0627\\u0641\\u0642\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=\\u0625\\u0639\\u0627\\u062F\\u0629 \\u062A\\u0639\\u064A\\u064A\\u0646\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=\\u062A\\u063A\\u064A\\u064A\\u0631\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=\\u0633\\u062D\\u0628\r\n\r\n#XSEL\r\nLR_UPDATED=\\u062A\\u0645 \\u062A\\u062D\\u062F\\u064A\\u062B\\u0647\r\n\r\n#XFLD\r\nLR_NOTE=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0629\r\n\r\n#XFLD\r\nLR_CUSTOM1=\\u0627\\u0644\\u062D\\u0642\\u0644 \\u0627\\u0644\\u0645\\u062E\\u0635\\u0635 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=\\u0645\\u0633\\u062A\\u062E\\u062F\\u064E\\u0645\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=\\u0645\\u062A\\u0648\\u0641\\u0631\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=\\u0623\\u064A\\u0627\\u0645\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=\\u064A\\u0648\\u0645\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=\\u0633\\u0627\\u0639\\u0627\\u062A\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=\\u0633\\u0627\\u0639\\u0629\r\n\r\n#XFLD\r\nLR_UP_TO=\\u0635\\u0627\\u0644\\u062D \\u062D\\u062A\\u0649\r\n\r\n#XFLD\r\nLR_FROM=\\u0645\\u0646\r\n\r\n#XFLD\r\nLR_TO=\\u0625\\u0644\\u0649\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=\\u062A\\u0623\\u0643\\u064A\\u062F\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0625\\u0631\\u0633\\u0627\\u0644 \\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0647\\u0630\\u0627 \\u0625\\u0644\\u0649 {0}\\u061F\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=\\u0647\\u0644 \\u062A\\u0631\\u064A\\u062F \\u0633\\u062D\\u0628 \\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0647\\u0630\\u0627\\u061F\r\n\r\n#XFLD\r\nLR_DAYS=\\u0623\\u064A\\u0627\\u0645\r\n\r\n#XFLD\r\nLR_DAY=\\u064A\\u0648\\u0645\r\n\r\n#XFLD\r\nLR_HOURS=\\u0633\\u0627\\u0639\\u0627\\u062A\r\n\r\n#XFLD\r\nLR_HOUR=\\u0633\\u0627\\u0639\\u0629\r\n\r\n#XFLD\r\nLR_REQUEST=\\u0645\\u0637\\u0644\\u0648\\u0628\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=\\u0627\\u0644\\u064A\\u0648\\u0645\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=\\u064A\\u0648\\u0645 (\\u0623\\u064A\\u0627\\u0645) \\u0645\\u062D\\u062F\\u062F\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=\\u062C\\u0627\\u0631\\u064D \\u0627\\u0644\\u0645\\u0639\\u0627\\u0644\\u062C\\u0629...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=\\u062A\\u0645 \\u0625\\u0631\\u0633\\u0627\\u0644 \\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0627\\u0644\\u062E\\u0627\\u0635 \\u0628\\u0643 \\u0625\\u0644\\u0649 {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=\\u062A\\u0645 \\u0633\\u062D\\u0628 \\u0637\\u0644\\u0628 \\u0625\\u062C\\u0627\\u0632\\u062A\\u0643\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u062F\\u0627\\u062E\\u0644\\u064A\\u061B \\u0644\\u0645 \\u064A\\u062A\\u0645 \\u062A\\u0633\\u062C\\u064A\\u0644 \\u0627\\u0644\\u0646\\u0645\\u0648\\u0630\\u062C\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u0641\\u064A \\u0627\\u0644\\u0628\\u0631\\u0648\\u062A\\u0648\\u0643\\u0648\\u0644\\u061B \\u062A\\u0639\\u0630\\u0631 \\u062A\\u062D\\u0644\\u064A\\u0644 \\u0627\\u0633\\u062A\\u062C\\u0627\\u0628\\u0629 HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u0641\\u064A \\u0627\\u0644\\u0628\\u0631\\u0648\\u062A\\u0648\\u0643\\u0648\\u0644\\u061B \\u0627\\u0633\\u0645 \\u0627\\u0644\\u0645\\u0639\\u062A\\u0645\\u0650\\u062F \\u0645\\u0641\\u0642\\u0648\\u062F \\u0641\\u064A \\u0627\\u0644\\u0627\\u0633\\u062A\\u062C\\u0627\\u0628\\u0629\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u0641\\u064A \\u0627\\u0644\\u0628\\u0631\\u0648\\u062A\\u0648\\u0643\\u0648\\u0644\\u061B \\u0627\\u0644\\u062A\\u0643\\u0648\\u064A\\u0646 \\u0645\\u0641\\u0642\\u0648\\u062F \\u0641\\u064A \\u0627\\u0644\\u0627\\u0633\\u062A\\u062C\\u0627\\u0628\\u0629\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u0641\\u064A \\u0627\\u0644\\u0628\\u0631\\u0648\\u062A\\u0648\\u0643\\u0648\\u0644\\u061B \\u0627\\u0644\\u0623\\u0631\\u0635\\u062F\\u0629 \\u0645\\u0641\\u0642\\u0648\\u062F\\u0629 \\u0641\\u064A \\u0627\\u0644\\u0627\\u0633\\u062A\\u062C\\u0627\\u0628\\u0629\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u0641\\u064A \\u0627\\u0644\\u0628\\u0631\\u0648\\u062A\\u0648\\u0643\\u0648\\u0644\\u061B \\u062A\\u0639\\u0630\\u0631 \\u062A\\u062D\\u0644\\u064A\\u0644 \\u0627\\u0644\\u0627\\u0633\\u062A\\u062C\\u0627\\u0628\\u0629\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u0641\\u064A \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=\\u062D\\u062F\\u062B \\u062E\\u0637\\u0623\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=\\u062D\\u062F\\u062B\\u062A \\u0645\\u0634\\u0643\\u0644\\u0629 \\u062A\\u0642\\u0646\\u064A\\u0629\\n\\n\\u062A\\u0641\\u0627\\u0635\\u064A\\u0644 \\u0627\\u0644\\u062E\\u0637\\u0623\\:\\n\\u062E\\u0637\\u0623 \\u0641\\u064A \\u0627\\u0644\\u0628\\u0631\\u0648\\u062A\\u0648\\u0643\\u0648\\u0644\\u061B \\u062A\\u0639\\u0630\\u0631 \\u062A\\u062D\\u0644\\u064A\\u0644 \\u0627\\u0644\\u0627\\u0633\\u062A\\u062C\\u0627\\u0628\\u0629\r\n\r\n#XFLD\r\nLR_S1_PENDING=\\u0645\\u0639\\u0644\\u0642\r\n\r\n#YMSG\r\nLR_UNKNOWN=\\u063A\\u064A\\u0631 \\u0645\\u0639\\u0631\\u0648\\u0641\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=\\u064A\\u0648\\u0645 \\u0639\\u0637\\u0644\\u0629\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=\\u0645\\u0639\\u062A\\u0645\\u064E\\u062F\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=\\u0645\\u0631\\u0641\\u0648\\u0636\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=\\u0641\\u064A \\u0627\\u0646\\u062A\\u0638\\u0627\\u0631 \\u0627\\u0644\\u0627\\u0639\\u062A\\u0645\\u0627\\u062F\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=\\u0639\\u0637\\u0644\\u0629 \\u0631\\u0633\\u0645\\u064A\\u0629\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=\\u064A\\u0648\\u0645 \\u0639\\u0645\\u0644\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=\\u0645\\u0637\\u0644\\u0648\\u0628 \\u0627\\u0644\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u0637\\u0644\\u0628 \\u0627\\u0644\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=\\u0637\\u0644\\u0628 \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=\\u0641\\u064A \\u0627\\u0646\\u062A\\u0638\\u0627\\u0631 \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=\\u0641\\u064A \\u0627\\u0646\\u062A\\u0638\\u0627\\u0631 \\u0627\\u0644\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=\\u062A\\u0645 \\u0627\\u0639\\u062A\\u0645\\u0627\\u062F \\u0627\\u0644\\u062A\\u063A\\u064A\\u064A\\u0631\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=\\u062A\\u0645 \\u0627\\u0639\\u062A\\u0645\\u0627\\u062F \\u0627\\u0644\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=\\u0627\\u0644\\u0623\\u0635\\u0644\\u064A\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=\\u062A\\u0645 \\u062A\\u063A\\u064A\\u064A\\u0631\\u0647\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=\\u0627\\u0644\\u0645\\u0639\\u062A\\u0645\\u0650\\u062F\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=\\u0627\\u0644\\u062D\\u0636\\u0648\\u0631/\\u0627\\u0644\\u063A\\u064A\\u0627\\u0628 \\u0628\\u0627\\u0644\\u0633\\u0627\\u0639\\u0627\\u062A\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=\\u0627\\u0644\\u0645\\u0631\\u0641\\u0642\\u0627\\u062A\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=\\u0625\\u0636\\u0627\\u0641\\u0629 \\u0645\\u0631\\u0641\\u0642\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=\\u0648\\u0642\\u062A \\u0627\\u0644\\u0628\\u062F\\u0621\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=\\u0648\\u0642\\u062A \\u0627\\u0644\\u0627\\u0646\\u062A\\u0647\\u0627\\u0621\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=\\u062A\\u0639\\u0630\\u0631 \\u062A\\u062D\\u0645\\u064A\\u0644 \\u0627\\u0644\\u0645\\u0631\\u0641\\u0642\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=\\u0646\\u0648\\u0639 \\u0627\\u0644\\u0645\\u0631\\u0641\\u0642 \\u0647\\u0630\\u0627 \\u063A\\u064A\\u0631 \\u0645\\u062F\\u0639\\u0648\\u0645\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=\\u062D\\u062C\\u0645 \\u0627\\u0644\\u0645\\u0644\\u0641 \\u0643\\u0628\\u064A\\u0631 \\u062C\\u062F\\u064B\\u0627\\u061B \\u0628\\u0631\\u062C\\u0627\\u0621 \\u062A\\u062D\\u062F\\u064A\\u062F \\u0645\\u0644\\u0641 \\u0628\\u062D\\u062C\\u0645 \\u0623\\u0642\\u0644 \\u0645\\u0646 25 \\u0645\\u064A\\u062C\\u0627 \\u0628\\u0627\\u064A\\u062A.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_cs.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Moje \\u017E\\u00E1dosti o dovolenou\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Moje \\u017E\\u00E1dosti o dovolenou\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u017D\\u00E1dost o dovolenou\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Zm\\u011Bna \\u017E\\u00E1dosti o dovolenou\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=N\\u00E1roky\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Historie\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Detaily dovolen\\u00E9\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u017D\\u00E1dosti o dovolenou\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u017D\\u00E1dost o dovolenou\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Kategorie\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=K dispozici\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Pou\\u017Eito\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Po\\u017Eadov\\u00E1no\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=N\\u00E1roky\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=N\\u00E1rok\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Odeslat \\u017E\\u00E1dost o dovolenou\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Zru\\u0161en\\u00ED \\u017E\\u00E1dosti o dovolenou\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=N\\u00E1roky\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Historie\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Vytvo\\u0159it \\u017E\\u00E1dost o dovolenou\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Historie\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u017D\\u00E1dost o dovolenou\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Odeslat\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Resetovat\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Zru\\u0161it\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Zm\\u011Bnit\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Zru\\u0161it\r\n\r\n#XSEL\r\nLR_UPDATED=Aktualizov\\u00E1no\r\n\r\n#XFLD\r\nLR_NOTE=Pozn\\u00E1mka\r\n\r\n#XFLD\r\nLR_CUSTOM1=U\\u017Eivatelsk\\u00E9 pole 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=vyu\\u017Eito\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=disponibiln\\u00ED\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=dny\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=den\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=hodiny\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=hodina\r\n\r\n#XFLD\r\nLR_UP_TO=Plat\\u00ED do\r\n\r\n#XFLD\r\nLR_FROM=Od\r\n\r\n#XFLD\r\nLR_TO=Do\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Do\\u0161lo k probl\\u00E9mu\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Potvrzen\\u00ED\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Odeslat tuto \\u017E\\u00E1dost o dovolenou p\\u0159\\u00EDjemci\\: {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Chcete \\u017E\\u00E1dost o dovolenou zru\\u0161it?\r\n\r\n#XFLD\r\nLR_DAYS=dny\r\n\r\n#XFLD\r\nLR_DAY=Den\r\n\r\n#XFLD\r\nLR_HOURS=Hodiny\r\n\r\n#XFLD\r\nLR_HOUR=Hodina\r\n\r\n#XFLD\r\nLR_REQUEST=Po\\u017Eadov\\u00E1no\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Dnes\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Vybran\\u00E9 dny\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Prob\\u00EDh\\u00E1 zpracov\\u00E1n\\u00ED...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Va\\u0161e \\u017E\\u00E1dost o dovolenou byla odesl\\u00E1na p\\u0159\\u00EDjemci\\: {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Va\\u0161e \\u017E\\u00E1dost o dovolenou byla zru\\u0161ena\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nIntern\\u00ED chyba; model nen\\u00ED registrov\\u00E1n\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nChyba protokolu; nepoda\\u0159ilo se analyzovat odezvu HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nChyba protokolu; v odezv\\u011B chyb\\u00ED jm\\u00E9no schvalovatele\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nChyba protokolu; v odezv\\u011B chyb\\u00ED konfigurace\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nChyba protokolu; v odezv\\u011B chyb\\u011Bj\\u00ED z\\u016Fstatky\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nChyba protokolu; nepoda\\u0159ilo se analyzovat odezvu\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Do\\u0161lo k probl\\u00E9mu s va\\u0161\\u00EDm p\\u0159ipojen\\u00EDm\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Do\\u0161lo k chyb\\u011B\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Do\\u0161lo k technick\\u00E9 chyb\\u011B\\n\\nDetaily chyby\\:\\nChyba protokolu; nepoda\\u0159ilo se analyzovat odezvu\r\n\r\n#XFLD\r\nLR_S1_PENDING=Nevy\\u0159\\u00EDzeno\r\n\r\n#YMSG\r\nLR_UNKNOWN=Nen\\u00ED zn\\u00E1mo\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Nepracovn\\u00ED den\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Schv\\u00E1leno\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Zam\\u00EDtnuto\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Nevy\\u0159\\u00EDzen\\u00E9 schv\\u00E1len\\u00ED\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Sv\\u00E1tek\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Pracovn\\u00ED den\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Po\\u017Eadov\\u00E1no zru\\u0161en\\u00ED\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u017D\\u00E1dost o zru\\u0161en\\u00ED\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=\\u017D\\u00E1dost o zm\\u011Bnu\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Nevy\\u0159\\u00EDzen\\u00E1 zm\\u011Bna\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Nevy\\u0159\\u00EDzen\\u00E9 zru\\u0161en\\u00ED\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Zm\\u011Bna schv\\u00E1lena\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Schv\\u00E1len\\u00E9 zru\\u0161en\\u00ED\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=P\\u016Fvodn\\u00ED\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Zm\\u011Bn\\u011Bno\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Schvalovatel\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Hodiny p\\u0159\\u00EDtomnosti/nep\\u0159\\u00EDtomnosti\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=P\\u0159\\u00EDlohy\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=P\\u0159ipojit p\\u0159\\u00EDlohu\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Po\\u010D\\u00E1te\\u010Dn\\u00ED \\u010Das\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Koncov\\u00FD \\u010Das\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Nepoda\\u0159ilo se uploadovat p\\u0159\\u00EDlohu\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Tento typ p\\u0159\\u00EDlohy nen\\u00ED podporov\\u00E1n\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Soubor je p\\u0159\\u00EDli\\u0161 velk\\u00FD. Vyberte soubor, kter\\u00FD je men\\u0161\\u00ED ne\\u017E 25 MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_de.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Meine Abwesenheitsantr\\u00E4ge\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Meine Abwesenheitsantr\\u00E4ge\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Abwesenheit beantragen\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Abwesenheitsantrag \\u00E4ndern\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Anspr\\u00FCche\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Verlauf\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Abwesenheitsdetails\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Abwesenheitsantr\\u00E4ge\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Abwesenheitsantrag\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Kategorie\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Verf\\u00FCgbar\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Verwendet\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Beantragt\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Anspr\\u00FCche\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Anspruch\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Abwesenheitsantrag senden\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Abwesenheitsantrag stornieren\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Anspr\\u00FCche\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Verlauf\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Abwesenheitsantrag anlegen\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Verlauf\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Abwesenheit beantragen\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Senden\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Zur\\u00FCcksetzen\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Abbrechen\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=\\u00C4ndern\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Stornieren\r\n\r\n#XSEL\r\nLR_UPDATED=Aktualisiert\r\n\r\n#XFLD\r\nLR_NOTE=Notiz\r\n\r\n#XFLD\r\nLR_CUSTOM1=Benutzerdefiniertes Feld 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=verbraucht\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=verf\\u00FCgbar\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=Tage\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=Tag\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=Stunden\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=Stunde\r\n\r\n#XFLD\r\nLR_UP_TO=G\\u00FCltig bis\r\n\r\n#XFLD\r\nLR_FROM=Von\r\n\r\n#XFLD\r\nLR_TO=Bis\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Fehler aufgetreten\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Best\\u00E4tigung\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Abwesenheitsantrag an {0} senden?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=M\\u00F6chten Sie diesen Abwesenheitsantrag stornieren?\r\n\r\n#XFLD\r\nLR_DAYS=Tage\r\n\r\n#XFLD\r\nLR_DAY=Tag\r\n\r\n#XFLD\r\nLR_HOURS=Stunden\r\n\r\n#XFLD\r\nLR_HOUR=Stunde\r\n\r\n#XFLD\r\nLR_REQUEST=Beantragt\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Heute\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Ausgew\\u00E4hlte Tage\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Verarbeitung l\\u00E4uft ...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Ihr Abwesenheitsantrag wurde an {0} gesendet\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Ihr Abwesenheitsantrag wurde storniert\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nInterner Fehler, Modell nicht registriert\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nProtokollfehler, HTTP-Antwort kann nicht analysiert werden\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nProtokollfehler, Genehmigender fehlt in Antwort\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nProtokollfehler, Konfiguration fehlt in Antwort\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nProtokollfehler, Salden fehlen in Antwort\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nProtokollfehler, Antwort kann nicht analysiert werden\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Verbindungsfehler\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Es ist ein Fehler aufgetreten\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Ein technisches Problem ist aufgetreten.\\n\\nFehlerdetails\\:\\nProtokollfehler, Antwort kann nicht analysiert werden\r\n\r\n#XFLD\r\nLR_S1_PENDING=Ausstehend\r\n\r\n#YMSG\r\nLR_UNKNOWN=Unbekannt\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Arbeitsfreier Tag\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Genehmigt\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Abgelehnt\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Genehmigung ausstehend\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Feiertag\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Arbeitstag\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Stornierung beantragt\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Stornierungsantrag\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Antrag \\u00E4ndern\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=\\u00C4nderung ausstehend\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Stornierung ausstehend\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=\\u00C4nderung wurde genehmigt\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Stornierung wurde genehmigt\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Ge\\u00E4ndert\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Genehmigender\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Anwesenheits-/Abwesenheitsstunden\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Anlagen\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Anlage hinzuf\\u00FCgen\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Beginn (Zeit)\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Ende (Zeit)\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Die Anlage konnte nicht hochgeladen werden.\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Diese Anlagenart wird nicht unterst\\u00FCtzt.\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Die Datei ist zu gro\\u00DF. W\\u00E4hlen Sie eine Datei aus, die kleiner als 25 MB ist.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_en.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=My Leave Requests\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=My Leave Requests\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Request Leave\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Change Leave Request\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Entitlements\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=History\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Leave Details\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Leave Requests\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Leave Request\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Category\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Available\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Used\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Requested\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Entitlements\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Entitlement\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Send Leave Request\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Withdraw Leave Request\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Entitlements\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=History\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Create Leave Request\r\n\r\n#XBUT\r\nLR_SHOW_HIST=History\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Request Leave\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Send\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Reset\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Cancel\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Change\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Withdraw\r\n\r\n#XSEL\r\nLR_UPDATED=Updated\r\n\r\n#XFLD\r\nLR_NOTE=Note\r\n\r\n#XFLD\r\nLR_CUSTOM1=Custom Field 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=used\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=available\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=days\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=day\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=hours\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=hour\r\n\r\n#XFLD\r\nLR_UP_TO=Valid Until\r\n\r\n#XFLD\r\nLR_FROM=From\r\n\r\n#XFLD\r\nLR_TO=To\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=A problem occurred\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Confirmation\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Send this leave request to {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Do you want to withdraw this leave request?\r\n\r\n#XFLD\r\nLR_DAYS=days\r\n\r\n#XFLD\r\nLR_DAY=Day\r\n\r\n#XFLD\r\nLR_HOURS=Hours\r\n\r\n#XFLD\r\nLR_HOUR=Hour\r\n\r\n#XFLD\r\nLR_REQUEST=Requested\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Today\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Selected Day(s)\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Processing...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Your leave request was sent to {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Your leave request was withdrawn\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=A technical problem has occurred\\n\\nError Details\\:\\nInternal error; model not registered\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; could not parse HTTP response\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; approver name missing in response\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; configuration missing in response\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; balances missing in response\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; could not parse response\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=A problem has occurred with your connection\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=An error has occurred\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; could not parse response\r\n\r\n#XFLD\r\nLR_S1_PENDING=Pending\r\n\r\n#YMSG\r\nLR_UNKNOWN=Unknown\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Non-Working Day\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Approved\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Rejected\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Approval Pending\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Public Holiday\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Working Day\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Cancellation Requested\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Cancellation Request\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Change Request\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Change Pending\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Cancellation Pending\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Change Approved\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Cancellation Approved\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Changed\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Approver\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Attendance/Absence Hours\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Attachments\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Add Attachment\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Start Time\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=End Time\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Could not upload the attachment\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=This attachment type is not supported\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=File size is too big. Please select a file less than 25MB in size.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_en_US_sappsd.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=[[[\\u039C\\u0177 \\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=[[[\\u039C\\u0177 \\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=[[[\\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163 \\u013B\\u0113\\u0105\\u028B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113 \\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=[[[\\u0114\\u014B\\u0163\\u012F\\u0163\\u013A\\u0113\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=[[[\\u0124\\u012F\\u015F\\u0163\\u014F\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=[[[\\u013B\\u0113\\u0105\\u028B\\u0113 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=[[[\\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=[[[\\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=[[[\\u0108\\u0105\\u0163\\u0113\\u011F\\u014F\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=[[[\\u0100\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=[[[\\u016E\\u015F\\u0113\\u018C]]]\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=[[[\\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=[[[\\u0114\\u014B\\u0163\\u012F\\u0163\\u013A\\u0113\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=[[[\\u0114\\u014B\\u0163\\u012F\\u0163\\u013A\\u0113\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=[[[\\u015C\\u0113\\u014B\\u018C \\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=[[[\\u0174\\u012F\\u0163\\u0125\\u018C\\u0157\\u0105\\u0175 \\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=[[[\\u0114\\u014B\\u0163\\u012F\\u0163\\u013A\\u0113\\u0271\\u0113\\u014B\\u0163\\u015F \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=[[[\\u0124\\u012F\\u015F\\u0163\\u014F\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=[[[\\u0108\\u0157\\u0113\\u0105\\u0163\\u0113 \\u013B\\u0113\\u0105\\u028B\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT\r\nLR_SHOW_HIST=[[[\\u0124\\u012F\\u015F\\u0163\\u014F\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=[[[\\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163 \\u013B\\u0113\\u0105\\u028B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=[[[\\u015C\\u0113\\u014B\\u018C]]]\r\n\r\n#XBUT: text for ok button \r\nLR_OK=[[[\\u014E\\u0136\\u2219\\u2219]]]\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=[[[\\u0158\\u0113\\u015F\\u0113\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=[[[\\u0174\\u012F\\u0163\\u0125\\u018C\\u0157\\u0105\\u0175\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL\r\nLR_UPDATED=[[[\\u016E\\u03C1\\u018C\\u0105\\u0163\\u0113\\u018C \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_NOTE=[[[\\u0143\\u014F\\u0163\\u0113]]]\r\n\r\n#XFLD\r\nLR_CUSTOM1=[[[\\u0108\\u0171\\u015F\\u0163\\u014F\\u0271 \\u0191\\u012F\\u0113\\u013A\\u018C 1\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=[[[\\u0171\\u015F\\u0113\\u018C]]]\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=[[[\\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=[[[\\u018C\\u0105\\u0177\\u015F]]]\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=[[[\\u018C\\u0105\\u0177\\u2219]]]\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=[[[\\u0125\\u014F\\u0171\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=[[[\\u0125\\u014F\\u0171\\u0157]]]\r\n\r\n#XFLD\r\nLR_UP_TO=[[[\\u01B2\\u0105\\u013A\\u012F\\u018C \\u016E\\u03C1\\u0163\\u014F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_FROM=[[[\\u0191\\u0157\\u014F\\u0271]]]\r\n\r\n#XFLD\r\nLR_TO=[[[\\u0162\\u014F\\u2219\\u2219]]]\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=[[[-\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=[[[\\u0100 \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=[[[\\u0108\\u014F\\u014B\\u0192\\u012F\\u0157\\u0271\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=[[[\\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u015F\\u0113\\u014B\\u018C \\u0163\\u0125\\u012F\\u015F \\u013A\\u0113\\u0105\\u028B\\u0113 \\u0157\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163 \\u0163\\u014F {0}?]]]\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=[[[\\u010E\\u014F \\u0177\\u014F\\u0171 \\u0175\\u0105\\u014B\\u0163 \\u0163\\u014F \\u0175\\u012F\\u0163\\u0125\\u018C\\u0157\\u0105\\u0175 \\u0163\\u0125\\u012F\\u015F \\u013A\\u0113\\u0105\\u028B\\u0113 \\u0157\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163?\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_DAYS=[[[\\u018C\\u0105\\u0177\\u015F]]]\r\n\r\n#XFLD\r\nLR_DAY=[[[\\u018C\\u0105\\u0177\\u2219]]]\r\n\r\n#XFLD\r\nLR_HOURS=[[[\\u0125\\u014F\\u0171\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_HOUR=[[[\\u0125\\u014F\\u0171\\u0157]]]\r\n\r\n#XFLD\r\nLR_REQUEST=[[[\\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=[[[\\u0162\\u014F\\u018C\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=[[[\\u015C\\u0113\\u013A\\u0113\\u010B\\u0163\\u0113\\u018C \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=[[[\\u01A4\\u0157\\u014F\\u010B\\u0113\\u015F\\u015F\\u012F\\u014B\\u011F...\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_SUBMITDONE=[[[\\u0176\\u014F\\u0171\\u0157 \\u013A\\u0113\\u0105\\u028B\\u0113 \\u0157\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163 \\u0175\\u0105\\u015F \\u015F\\u0113\\u014B\\u0163 \\u0163\\u014F {0}]]]\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=[[[\\u0176\\u014F\\u0171\\u0157 \\u013A\\u0113\\u0105\\u028B\\u0113 \\u0157\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163 \\u0175\\u0105\\u015F \\u0175\\u012F\\u0163\\u0125\\u018C\\u0157\\u0105\\u0175\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u012C\\u014B\\u0163\\u0113\\u0157\\u014B\\u0105\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u0271\\u014F\\u018C\\u0113\\u013A \\u014B\\u014F\\u0163 \\u0157\\u0113\\u011F\\u012F\\u015F\\u0163\\u0113\\u0157\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u01A4\\u0157\\u014F\\u0163\\u014F\\u010B\\u014F\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u010B\\u014F\\u0171\\u013A\\u018C \\u014B\\u014F\\u0163 \\u03C1\\u0105\\u0157\\u015F\\u0113 \\u0124\\u0162\\u0162\\u01A4 \\u0157\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u01A4\\u0157\\u014F\\u0163\\u014F\\u010B\\u014F\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u0105\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u0157 \\u014B\\u0105\\u0271\\u0113 \\u0271\\u012F\\u015F\\u015F\\u012F\\u014B\\u011F \\u012F\\u014B \\u0157\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u01A4\\u0157\\u014F\\u0163\\u014F\\u010B\\u014F\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u010B\\u014F\\u014B\\u0192\\u012F\\u011F\\u0171\\u0157\\u0105\\u0163\\u012F\\u014F\\u014B \\u0271\\u012F\\u015F\\u015F\\u012F\\u014B\\u011F \\u012F\\u014B \\u0157\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u01A4\\u0157\\u014F\\u0163\\u014F\\u010B\\u014F\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u0183\\u0105\\u013A\\u0105\\u014B\\u010B\\u0113\\u015F \\u0271\\u012F\\u015F\\u015F\\u012F\\u014B\\u011F \\u012F\\u014B \\u0157\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u01A4\\u0157\\u014F\\u0163\\u014F\\u010B\\u014F\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u010B\\u014F\\u0171\\u013A\\u018C \\u014B\\u014F\\u0163 \\u03C1\\u0105\\u0157\\u015F\\u0113 \\u0157\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=[[[\\u0100 \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C \\u0175\\u012F\\u0163\\u0125 \\u0177\\u014F\\u0171\\u0157 \\u010B\\u014F\\u014B\\u014B\\u0113\\u010B\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=[[[\\u0100\\u014B \\u0113\\u0157\\u0157\\u014F\\u0157 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=[[[\\u0100 \\u0163\\u0113\\u010B\\u0125\\u014B\\u012F\\u010B\\u0105\\u013A \\u03C1\\u0157\\u014F\\u0183\\u013A\\u0113\\u0271 \\u0125\\u0105\\u015F \\u014F\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C\\n\\n\\u0114\\u0157\\u0157\\u014F\\u0157 \\u010E\\u0113\\u0163\\u0105\\u012F\\u013A\\u015F\\:\\n\\u01A4\\u0157\\u014F\\u0163\\u014F\\u010B\\u014F\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157; \\u0108\\u014F\\u0171\\u013A\\u018C \\u014B\\u014F\\u0163 \\u03C1\\u0105\\u0157\\u015F\\u0113 \\u0157\\u0113\\u015F\\u03C1\\u014F\\u014B\\u015F\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLR_S1_PENDING=[[[\\u01A4\\u0113\\u014B\\u018C\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG\r\nLR_UNKNOWN=[[[\\u016E\\u014B\\u0137\\u014B\\u014F\\u0175\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=[[[\\u0143\\u014F\\u014B-\\u0174\\u014F\\u0157\\u0137\\u012F\\u014B\\u011F \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=[[[\\u0158\\u0113\\u0135\\u0113\\u010B\\u0163\\u0113\\u018C \\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0105\\u013A \\u01A4\\u0113\\u014B\\u018C\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=[[[\\u01A4\\u0171\\u0183\\u013A\\u012F\\u010B \\u0124\\u014F\\u013A\\u012F\\u018C\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=[[[\\u0174\\u014F\\u0157\\u0137\\u012F\\u014B\\u011F \\u010E\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u013A\\u0105\\u0163\\u012F\\u014F\\u014B \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT\r\nLR_DELETION_REQ=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u013A\\u0105\\u0163\\u012F\\u014F\\u014B \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113 \\u0158\\u0113\\u01A3\\u0171\\u0113\\u015F\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113 \\u01A4\\u0113\\u014B\\u018C\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u013A\\u0105\\u0163\\u012F\\u014F\\u014B \\u01A4\\u0113\\u014B\\u018C\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113 \\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u013A\\u0105\\u0163\\u012F\\u014F\\u014B \\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=[[[\\u014E\\u0157\\u012F\\u011F\\u012F\\u014B\\u0105\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=[[[\\u0108\\u0125\\u0105\\u014B\\u011F\\u0113\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=[[[\\u0100\\u03C1\\u03C1\\u0157\\u014F\\u028B\\u0113\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=[[[\\u0100\\u0163\\u0163./\\u0100\\u0183\\u015F\\u0113\\u014B\\u010B\\u0113 \\u0124\\u014F\\u0171\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=[[[\\u0100\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=[[[\\u0100\\u018C\\u018C \\u0105\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=[[[\\u015C\\u0163\\u0105\\u0157\\u0163 \\u0162\\u012F\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=[[[\\u0114\\u014B\\u018C \\u0162\\u012F\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=[[[\\u0108\\u0105\\u014B\\u014B\\u014F\\u0163 \\u0171\\u03C1\\u013A\\u014F\\u0105\\u018C \\u0163\\u0125\\u0113 \\u0105\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163. \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=[[[\\u0162\\u0125\\u012F\\u015F \\u0105\\u0163\\u0163\\u0105\\u010B\\u0125\\u0271\\u0113\\u014B\\u0163 \\u0163\\u0177\\u03C1\\u0113 \\u012F\\u015F \\u014B\\u014F\\u0163 \\u015F\\u0171\\u03C1\\u03C1\\u014F\\u0157\\u0163\\u0113\\u018C. \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=[[[\\u0191\\u012F\\u013A\\u0113 \\u015F\\u012F\\u017E\\u0113 \\u012F\\u015F \\u0163\\u014F\\u014F \\u0183\\u012F\\u011F. \\u01A4\\u013A\\u0113\\u0105\\u015F\\u0113 \\u015F\\u0113\\u013A\\u0113\\u010B\\u0163 \\u0105 \\u0192\\u012F\\u013A\\u0113 \\u013A\\u0113\\u015F\\u015F \\u0163\\u0125\\u0105\\u014B 25\\u039C\\u0181.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=[[[\\u0108\\u0125\\u014F\\u014F\\u015F\\u0113 \\u0105 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u014B\\u0113\\u013A \\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=[[[\\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u014B\\u0113\\u013A \\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_en_US_saptrc.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=zqy2mSJO59Hsb1lZCN/98A_My Leave Requests\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=aXkVZk9088GvhlC3dBtSdA_My Leave Requests\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=4AsKO7uAJ7zDLw9TEIbX3g_Request Leave\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=PzJCDVhWmEw1nNNhLnxSIA_Change Leave Request\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=C5LbFePtH8yv34FuWTP2lw_Entitlements\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=SD/w+lYnAUnj1HQpm3lSuw_History\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=+GgLaM7MgRSYxamSGHU0jw_Leave Details\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=ysZKo4uwUb8seHC1IP2q9Q_Leave Requests\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=5FIkC448pvlfmBxPX071cw_Leave Request\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=7mNU73uz5ELuZSe6ozmc0g_Category\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=i18plHa/GGZePsmzd2q2nw_Available\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=rURv5xPKLWykinajV6QN6g_Used\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=xzQXE6w6V6Dj9T28Kqjykw_Requested\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=3FCM0BdUASi7yTb4DZmJQA_Entitlements\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=7hr8iF9BFXGObBQS81ScZQ_Entitlement\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=66a3dYiDrIct9OxhOze6dQ_Send Leave Request\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=d3gac5J02keduZw8ITuhkQ_Withdraw Leave Request\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=NiEWXoShei2pfpj3kVWhcA_Entitlements \r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=rHdys/ibnjZbEiOR3Yv/9g_History\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=5rv0pEqOAtomPKb6L7xhsg_Create Leave Request\r\n\r\n#XBUT\r\nLR_SHOW_HIST=wwl/i45CFf9Z2ld1oFOjVQ_History\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=9wwmnAvBHMKj0MbhhpBUqQ_Request Leave\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=25EB3bxQOp+sHWQhiM3kCg_Send\r\n\r\n#XBUT: text for ok button \r\nLR_OK=KLju0LlJ6M2nuJgSAR6tmA_OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=IOWSRkW8SX7OPdyzqdK55A_Reset\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=XkLJe6yB6hPTfXQPpAknSQ_Cancel\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=SmPXeniGhi3KAyLwG3UfDg_Change\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=WOv2SYJftPhzmpq0RKS2gw_Withdraw\r\n\r\n#XSEL\r\nLR_UPDATED=Lm28pFS5NUl5UbdM4HZMtw_Updated \r\n\r\n#XFLD\r\nLR_NOTE=FcAOtkNqDZGIhAXZHTaOUw_Note\r\n\r\n#XFLD\r\nLR_CUSTOM1=BGZTGbMbVIdwghhna9TErA_Custom Field 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=tFaWxoxEhKIaps/llA1n6A_used\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=BF36PXoOaWMOA2S0pJKybw_available\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=yPuBw00I3+qV6f7b/HY7UA_days\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=lYvtQTXsTNGhTf8vgkTYZA_day\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=91b7H+jk8y+dF1Kj3hVXFQ_hours\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=JhUVsGb8ihkStkqtOVgp/w_hour\r\n\r\n#XFLD\r\nLR_UP_TO=IVKQ2LrnFCs4PcdU0aAc5A_Valid Upto\r\n\r\n#XFLD\r\nLR_FROM=u91TXquiiOVzm5COQLyd3w_From\r\n\r\n#XFLD\r\nLR_TO=57Amx4+J5BqVtWZAKB8VtQ_To\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=BXnnkm8wvNc34ToU6wnAvQ_-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=VPZhtvaOI5xEWvnsHZDHDg_A problem occurred\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=ljgKMN5QoSZEjSuZFM+aDg_Confirmation\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=8Hr1IAmlm+Rw/hm0xxeGHQ_Do you want to send this leave request to {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=r6oJkhDx0ZEjgm+qlYawQA_Do you want to withdraw this leave request?\r\n\r\n#XFLD\r\nLR_DAYS=J0ZcgJ5ml8FG7I4gQGbM4Q_days\r\n\r\n#XFLD\r\nLR_DAY=aMzdBPiyLXaz7wwn67fw7w_day\r\n\r\n#XFLD\r\nLR_HOURS=fT5mnYD07vIYRL/RwiciNw_hours\r\n\r\n#XFLD\r\nLR_HOUR=pDFNKfXSf999XNI4GqhNuA_hour\r\n\r\n#XFLD\r\nLR_REQUEST=dcoaYbMSQg9Clarb+Wd8Gg_Requested\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=VuRWbqlWgdTO0C9K9n7KsQ_Today\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=nT7mAYGmmk9MVW7cfiuyTw_Selected Day\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=LQLbPO5Gjc94v8aLs5pNnQ_Processing...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=2094juUqCFUGsezHNVua8w_Your leave request was sent to {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=bRwHRhK0dmSd1rSYJaxHPA_Your leave request was withdrawn\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=o8BEXkWQBeepT8Q1Ie5FyQ_A technical problem has occurred\\n\\nError Details\\:\\nInternal error; model not registered\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=QJtvnlIVT3VR5sEdyl4Jzw_A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; could not parse HTTP response\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=3VrY0+YTu+r4ASi6Ypj10w_A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; approver name missing in response\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=olFh/sWzkbCtUw9x2G3b8Q_A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; configuration missing in response\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=SmLULD6vpxBO+GzqVS7kvw_A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; balances missing in response\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=4wSEnB2bxxAaiT4gzlySCQ_A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; could not parse response\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=5FKaf8kGsUV8mHjedCUk8w_A problem has occurred with your connection\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=WoirtiUJAbkjY2u109t77g_An error has occurred\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=17HTkvehZjiL9bQ841b7ig_A technical problem has occurred\\n\\nError Details\\:\\nProtocol error; Could not parse response\r\n\r\n#XFLD\r\nLR_S1_PENDING=tUS18n/bpGuO2wJtOhdgsQ_Pending\r\n\r\n#YMSG\r\nLR_UNKNOWN=Ryr63ALx0KhHRGlosL29PA_Unknown\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=/dfNQuFHl58+uKBjh9LbcQ_Non-Working Day\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=4AupdiJdHKE/7WPUQFb2PA_Approved\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=38glQeztx1cfTHlwyUFSSg_Rejected \r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=CBeqy/TkJ7uNZgb4ujkBmQ_Approval Pending\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=JBWjAQyMU2hZQv70+oDFMA_Public Holiday\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=eI8kNQQ+rPMV+Usi78SI3A_Working Day\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Vv/1mtt1KzWoynID4yDurg_Cancellation Requested\r\n\r\n#XTIT\r\nLR_DELETION_REQ=MCYerTG6UgiYCHUcwgmS5g_Cancellation Request\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=iUMvR5ENN+GHk0xCTn1yEA_Change Request\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=eRSJN8MJOh/X+SVT1QQ0gQ_Change Pending\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Y69q0ATqz+K5mfG/y9bQag_Cancellation Pending\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=IOfX9jR9TpjlB1BN7nTclQ_Change Approved\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=rnZOnl8aGK5ZlXxk3GHpIw_Cancellation Approved\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=BWVkUvIabAVPGZRLaZxwiA_Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=zHKNygMy5gqNddyxDe3AqA_Changed\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=eqPgnV8CT5VKkCtO2nLVCA_Approver\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=W32Pku6tLXS/QYwYO8xjYA_Att./Absence Hours\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=lG/Xmxirk7hRen1qKU3a5A_Attachments\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=AYbxTSF2Ax/dsishCtb7Eg_Add attachment\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=1F1yIOqhDRIo2ym2UyzN8Q_Start Time\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Npal5/Ia95P+Rcq/eCS37A_End Time\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=903QL/m89V74aqlqXZzAEA_Cannot upload the attachment. \r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=ZlklDHjMS1U19q4hz01T4Q_This attachment type is not supported. \r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=OGAK9Te/MJp9LsR5D6xF1g_File size is too big. Please select a file less than 25MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Mj2iD568aELxrU46FBBmyg_Choose a Personnel Assignment\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=vHoUVllHZypfrvmZAtufVw_Personnel Assignments\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_es.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Solicitud de ausencia\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Solicitud de ausencia\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Solicitar ausencia\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Modificar solicitud de ausencia\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Derechos\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Historial\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Detalles de la ausencia\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Solicitudes de ausencia\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Solicitud de ausencia\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Categor\\u00EDa\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Disponible\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Utilizados\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Solicitados\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Derechos\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Derecho\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Enviar solicitud de ausencia\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Anular solicitud de ausencia\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Derechos\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Historial\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Crear solicitud de ausencia\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Historial\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Solicitar ausencia\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Enviar\r\n\r\n#XBUT: text for ok button \r\nLR_OK=Aceptar\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Reinicializar\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Cancelar\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Cambiar\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Anular\r\n\r\n#XSEL\r\nLR_UPDATED=Actualizado\r\n\r\n#XFLD\r\nLR_NOTE=Nota\r\n\r\n#XFLD\r\nLR_CUSTOM1=Campo personalizado 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=utilizados\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=disponibles\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=d\\u00EDas\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=d\\u00EDa\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=Horas\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=Hora\r\n\r\n#XFLD\r\nLR_UP_TO=V\\u00E1lido hasta\r\n\r\n#XFLD\r\nLR_FROM=De\\:\r\n\r\n#XFLD\r\nLR_TO=A\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Ha ocurrido un problema\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Confirmaci\\u00F3n\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u00BFEnviar esta solicitud de ausencia a {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=\\u00BFDesea anular esta solicitud de ausencia?\r\n\r\n#XFLD\r\nLR_DAYS=d\\u00EDas\r\n\r\n#XFLD\r\nLR_DAY=D\\u00EDa\r\n\r\n#XFLD\r\nLR_HOURS=Horas\r\n\r\n#XFLD\r\nLR_HOUR=Hora\r\n\r\n#XFLD\r\nLR_REQUEST=Solicitados\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Hoy\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=D\\u00EDa(s) seleccionado(s)\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Procesando...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Su solicitud de ausencia se ha enviado a {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Se ha anulado su solicitud de ausencia\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError interno; modelo no registrado\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError de protocolo; no se ha podido analizar sint\\u00E1cticamente la respuesta HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError de protocolo; falta el nombre del autorizador en la respuesta\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError de protocolo; falta configuraci\\u00F3n en la respuesta\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError de protocolo; faltan saldos en la respuesta\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError de protocolo; no se ha podido analizar sint\\u00E1cticamente la respuesta \r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Ha ocurrido un problema con su conexi\\u00F3n\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Se ha producido un error\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Ha ocurrido un problema t\\u00E9cnico\\n\\nDetalles del error\\:\\nError de protocolo; no se ha podido analizar sint\\u00E1cticamente la respuesta \r\n\r\n#XFLD\r\nLR_S1_PENDING=Pendiente\r\n\r\n#YMSG\r\nLR_UNKNOWN=Desconocido\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=D\\u00EDa no laborable\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Autorizado\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Rechazadas\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Aprobaci\\u00F3n pendiente\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=D\\u00EDa festivo\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=D\\u00EDa laborable\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Cancelaci\\u00F3n solicitada\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Solicitud de cancelaci\\u00F3n\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Solicitud de modificaci\\u00F3n\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Modificaci\\u00F3n pendiente\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Cancelaci\\u00F3n pendiente\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Modificaci\\u00F3n aprobada\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Cancelaci\\u00F3n aprobada\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Modificados\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Autorizador\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Horas de ausencia/presencia\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Anexos\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=A\\u00F1adir anexo\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Hora de inicio\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Hora de fin\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=No se ha podido cargar el anexo\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Este tipo de anexo no est\\u00E1 soportado\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=El tama\\u00F1o del fichero es demasiado grande. Seleccione un fichero con un tama\\u00F1o inferior a 25MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_fr.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Mes demandes de cong\\u00E9\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Mes demandes de cong\\u00E9\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Demande de cong\\u00E9\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Modification de demande de cong\\u00E9\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Droits\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Historique\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=D\\u00E9tails du cong\\u00E9\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Demandes de cong\\u00E9s\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Demande de cong\\u00E9\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Cat\\u00E9gorie\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Disponible(s)\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Utilis\\u00E9(s)\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Demand\\u00E9\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Droits\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Droit\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Envoi de demande de cong\\u00E9\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Retrait de demande de cong\\u00E9\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Droits\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Historique\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Cr\\u00E9ation de demande de cong\\u00E9\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Historique\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Demander cong\\u00E9\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Envoyer\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=R\\u00E9initialiser\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Annuler\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Modifier\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Retirer\r\n\r\n#XSEL\r\nLR_UPDATED=Mise \\u00E0 jour effectu\\u00E9e\r\n\r\n#XFLD\r\nLR_NOTE=Note\r\n\r\n#XFLD\r\nLR_CUSTOM1=Zone personnalisable 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=utilis\\u00E9(s)\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=disponible(s)\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=jours\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=jour\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=heures\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=heure\r\n\r\n#XFLD\r\nLR_UP_TO=Fin de validit\\u00E9\r\n\r\n#XFLD\r\nLR_FROM=Du\r\n\r\n#XFLD\r\nLR_TO=Au\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Un probl\\u00E8me s\'est produit.\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Confirmation\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Envoyer cette demande de cong\\u00E9 \\u00E0 {0}\\u00A0?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Souhaitez-vous retirer cette demande de cong\\u00E9 ?\r\n\r\n#XFLD\r\nLR_DAYS=Jours\r\n\r\n#XFLD\r\nLR_DAY=Jour\r\n\r\n#XFLD\r\nLR_HOURS=Heures\r\n\r\n#XFLD\r\nLR_HOUR=Heure\r\n\r\n#XFLD\r\nLR_REQUEST=Demand\\u00E9\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Aujourd\'hui\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Jour(s) s\\u00E9lectionn\\u00E9(s)\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=En cours de traitement...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Votre demande de cong\\u00E9 a \\u00E9t\\u00E9 envoy\\u00E9e \\u00E0 {0}.\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Votre demande de cong\\u00E9 a \\u00E9t\\u00E9 retir\\u00E9e.\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur interne, mod\\u00E8le non enregistr\\u00E9.\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur de protocole, impossible d\'analyser la r\\u00E9ponse HTTP.\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur de protocole, le nom de l\'approbateur ne figure pas dans la r\\u00E9ponse.\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur de protocole, la configuration ne figure pas dans la r\\u00E9ponse.\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur de protocole, les soldes ne figurent pas dans la r\\u00E9ponse.\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur de protocole, impossible d\'analyser la r\\u00E9ponse.\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Un probl\\u00E8me de connexion s\'est produit.\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Une erreur s\'est produite.\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Un probl\\u00E8me technique est survenu.\\n\\nD\\u00E9tails de l\'erreur\\u00A0\\:\\nerreur de protocole, impossible d\'analyser la r\\u00E9ponse.\r\n\r\n#XFLD\r\nLR_S1_PENDING=En attente\r\n\r\n#YMSG\r\nLR_UNKNOWN=Inconnu\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Jour ch\\u00F4m\\u00E9\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Approuv\\u00E9\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Refus\\u00E9\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Approbation en attente\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Jour f\\u00E9ri\\u00E9\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Jour ouvr\\u00E9\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Annulation demand\\u00E9e\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Demande d\'annulation\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Demande de modification\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Modification en attente\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Annulation en attente\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Modification approuv\\u00E9e\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Annulation approuv\\u00E9e\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Modifi\\u00E9\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Approbateur\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Heures de pr\\u00E9sence/d\'absence\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Pi\\u00E8ces jointes\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Ajouter une pi\\u00E8ce jointe\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Heure de d\\u00E9but\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Heure de fin\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Impossible de t\\u00E9l\\u00E9charger la pi\\u00E8ce jointe\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Ce type de pi\\u00E8ce jointe n\'est pas pris en charge.\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Taille du fichier trop importante. S\\u00E9lectionnez un fichier dont la taille est inf\\u00E9rieure \\u00E0 25 Mo.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_hu.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Saj\\u00E1t t\\u00E1voll\\u00E9tk\\u00E9relmek\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Saj\\u00E1t t\\u00E1voll\\u00E9tk\\u00E9relmek\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=T\\u00E1voll\\u00E9t k\\u00E9r\\u00E9se\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=T\\u00E1voll\\u00E9tk\\u00E9relem m\\u00F3dos\\u00EDt\\u00E1sa\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Ig\\u00E9nyek\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=T\\u00F6rt\\u00E9net\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=T\\u00E1voll\\u00E9t r\\u00E9szletei\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=T\\u00E1voll\\u00E9tk\\u00E9relmek\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=T\\u00E1voll\\u00E9tk\\u00E9relem\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Kateg\\u00F3ria\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Rendelkez\\u00E9sre \\u00E1ll\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Felhaszn\\u00E1lt\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Ig\\u00E9nyelt\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Ig\\u00E9nyek\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Ig\\u00E9ny\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=T\\u00E1voll\\u00E9tk\\u00E9relem k\\u00FCld\\u00E9se\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=T\\u00E1voll\\u00E9tk\\u00E9relem visszavon\\u00E1sa\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Ig\\u00E9nyek\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=T\\u00F6rt\\u00E9net\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=T\\u00E1voll\\u00E9tk\\u00E9relem l\\u00E9trehoz\\u00E1sa\r\n\r\n#XBUT\r\nLR_SHOW_HIST=T\\u00F6rt\\u00E9net\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=T\\u00E1voll\\u00E9t k\\u00E9r\\u00E9se\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=K\\u00FCld\\u00E9s\r\n\r\n#XBUT: text for ok button \r\nLR_OK=Rendben\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Vissza\\u00E1ll\\u00EDt\\u00E1s\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=M\\u00E9gse\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=M\\u00F3dos\\u00EDt\\u00E1s\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Visszavon\\u00E1s\r\n\r\n#XSEL\r\nLR_UPDATED=Aktualiz\\u00E1lva\r\n\r\n#XFLD\r\nLR_NOTE=Megjegyz\\u00E9s\r\n\r\n#XFLD\r\nLR_CUSTOM1=1. egy\\u00E9ni mez\\u0151\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=felhaszn\\u00E1lva\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=\\u00E1ll rendelkez\\u00E9sre\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=napok\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=nap\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=\\u00F3ra\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=\\u00F3ra\r\n\r\n#XFLD\r\nLR_UP_TO=\\u00C9rv\\u00E9nyes eddig\\:\r\n\r\n#XFLD\r\nLR_FROM=Kezdete\\:\r\n\r\n#XFLD\r\nLR_TO=V\\u00E9ge\\:\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Hiba t\\u00F6rt\\u00E9nt\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Visszaigazol\\u00E1s\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Elk\\u00FCldi ezt a t\\u00E1voll\\u00E9tk\\u00E9relmet a k\\u00F6vetkez\\u0151nek\\: {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Visszavonja ezt a t\\u00E1voll\\u00E9tk\\u00E9relmet?\r\n\r\n#XFLD\r\nLR_DAYS=napok\r\n\r\n#XFLD\r\nLR_DAY=Nap\r\n\r\n#XFLD\r\nLR_HOURS=\\u00D3r\\u00E1k\r\n\r\n#XFLD\r\nLR_HOUR=\\u00D3ra\r\n\r\n#XFLD\r\nLR_REQUEST=Ig\\u00E9nyelt\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Ma\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Kiv\\u00E1lasztott napok\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Feldolgoz\\u00E1s...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=T\\u00E1voll\\u00E9tk\\u00E9relme el lett k\\u00FCldve\\: {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=T\\u00E1voll\\u00E9tk\\u00E9relme visszavonva\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nBels\\u0151 hiba; a modell nincs regisztr\\u00E1lva\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nProtokollhiba; nem siker\\u00FClt a HTTP-v\\u00E1lasz elemz\\u00E9se\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nProtokollhiba; a v\\u00E1lasz nem tartalmazza az enged\\u00E9lyez\\u0151 nev\\u00E9t\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nProtokollhiba; a v\\u00E1lasz nem tartalmazza a konfigur\\u00E1ci\\u00F3t\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nProtokollhiba; a v\\u00E1lasz nem tartalmazza az egyenlegeket\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nProtokollhiba; nem siker\\u00FClt a v\\u00E1lasz elemz\\u00E9se\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Probl\\u00E9ma volt a kapcsolattal\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Hiba t\\u00F6rt\\u00E9nt\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=M\\u0171szaki hiba t\\u00F6rt\\u00E9nt\\n\\nHiba r\\u00E9szletei\\:\\nProtokollhiba; nem siker\\u00FClt a v\\u00E1lasz elemz\\u00E9se\r\n\r\n#XFLD\r\nLR_S1_PENDING=F\\u00FCgg\\u0151ben\r\n\r\n#YMSG\r\nLR_UNKNOWN=Ismeretlen\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Nem munkanap\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=J\\u00F3v\\u00E1hagyva\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Elutas\\u00EDtva\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=J\\u00F3v\\u00E1hagy\\u00E1s f\\u00FCgg\\u0151ben\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=\\u00DCnnepnap\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Munkanap\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Visszavon\\u00E1st k\\u00E9rt\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Visszavon\\u00E1si k\\u00E9relem\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=K\\u00E9relem m\\u00F3dos\\u00EDt\\u00E1sa\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=M\\u00F3dos\\u00EDt\\u00E1s f\\u00FCgg\\u0151ben\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Visszavon\\u00E1s f\\u00FCgg\\u0151ben\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=M\\u00F3dos\\u00EDt\\u00E1s enged\\u00E9lyezve\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Visszavon\\u00E1s enged\\u00E9lyezve\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Eredeti\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=M\\u00F3dos\\u00EDtva\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Enged\\u00E9lyez\\u0151\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Jelenl\\u00E9t/t\\u00E1voll\\u00E9t \\u00F3r\\u00E1kban\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Mell\\u00E9kletek\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Mell\\u00E9klet hozz\\u00E1ad\\u00E1sa\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Kezd\\u00E9s id\\u0151pontja\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Befejez\\u00E9s id\\u0151pontja\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Nem lehetett felt\\u00F6lteni a mell\\u00E9kletet\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Ezt a fajta mell\\u00E9kletet nem t\\u00E1mogatja a rendszer\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=A f\\u00E1jl t\\u00FAl nagy. K\\u00E9rem, olyan f\\u00E1jlt v\\u00E1lasszon, melynek m\\u00E9rete nem haladja meg a 25MB-ot.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_it.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Le mie richieste di ferie\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Le mie richieste di ferie\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Richiedi ferie\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Modifica richiesta di ferie\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Diritti\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Storico\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Dettagli ferie\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Richieste di ferie\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Richiesta di ferie\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Categoria\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Disponibile\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Goduto\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Richiesto\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Diritti\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Diritto\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Invia richiesta di ferie\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Ritira richiesta di ferie\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Diritti\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Storico\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Crea richiesta di ferie\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Storico\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Richiedi ferie\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Invia\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Resetta\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Annulla\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Modifica\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Ritira\r\n\r\n#XSEL\r\nLR_UPDATED=Aggiornato\r\n\r\n#XFLD\r\nLR_NOTE=Nota\r\n\r\n#XFLD\r\nLR_CUSTOM1=Campo personalizzato 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=usufruiti\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=disponibili\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=giorni\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=giorno\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=ore\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=ora\r\n\r\n#XFLD\r\nLR_UP_TO=Valido fino al\r\n\r\n#XFLD\r\nLR_FROM=Da\r\n\r\n#XFLD\r\nLR_TO=A\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Si \\u00E8 verificato un problema\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Conferma\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Inviare questa richiesta di ferie a {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Ritirare questa richiesta di ferie?\r\n\r\n#XFLD\r\nLR_DAYS=giorni\r\n\r\n#XFLD\r\nLR_DAY=Giorno\r\n\r\n#XFLD\r\nLR_HOURS=Ore\r\n\r\n#XFLD\r\nLR_HOUR=Ora\r\n\r\n#XFLD\r\nLR_REQUEST=Richiesto\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Oggi\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Giorni selezionati\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=In elaborazione...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=La richiesta di ferie \\u00E8 stata inviata a {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=La tua richiesta di ferie \\u00E8 stata ritirata\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore interno; modello non registrato\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore di protocollo; analisi sintattica della risposta HTTP non riuscita\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore di protocollo; nome approvatore mancante nella risposta\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore di protocollo; configurazione mancante nella risposta\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore di protocollo; saldi mancanti nella risposta\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore di protocollo; analisi sintattica della risposta non riuscita\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Problema rilevato nella connessione\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Si \\u00E8 verificato un errore\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Si \\u00E8 verificato un problema tecnico\\n\\nDettagli dell\'errore\\:\\nErrore di protocollo; analisi sintattica della risposta non riuscita\r\n\r\n#XFLD\r\nLR_S1_PENDING=In sospeso\r\n\r\n#YMSG\r\nLR_UNKNOWN=Sconosciuto\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Giorno non lavorativo\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Approvato\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Rifiutato\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=In attesa di approvazione\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Giorno festivo\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Giorno lavorativo\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Annullamento richiesto\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Richiesta di annullamento\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Modifica la richiesta\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Modifica in sospeso\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Annullamento in sospeso\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Modifica approvata\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Annullamento approvato\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Originale\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Modificato\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Approvatore\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Presenza/Assenza in ore\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Allegati\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Aggiungi allegato\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Ora di inizio\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Ora di fine\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Allegato non caricato\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Questo tipo di allegato non \\u00E8 supportato\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Dimensioni file troppo elevate. Seleziona un file inferiore ai 25MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_iw.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=\\u05D1\\u05E7\\u05E9\\u05D5\\u05EA \\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05E9\\u05DC\\u05D9\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=\\u05D1\\u05E7\\u05E9\\u05D5\\u05EA \\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05E9\\u05DC\\u05D9\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u05D1\\u05E7\\u05E9 \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=\\u05E9\\u05E0\\u05D4 \\u05D1\\u05E7\\u05E9\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=\\u05D6\\u05DB\\u05D0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=\\u05D4\\u05D9\\u05E1\\u05D8\\u05D5\\u05E8\\u05D9\\u05D4\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=\\u05E4\\u05E8\\u05D8\\u05D9 \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u05D1\\u05E7\\u05E9\\u05D5\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u05D1\\u05E7\\u05E9\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=\\u05E7\\u05D8\\u05D2\\u05D5\\u05E8\\u05D9\\u05D4\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=\\u05D9\\u05DE\\u05D9\\u05DD \\u05E0\\u05D5\\u05EA\\u05E8\\u05D5\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=\\u05D9\\u05DE\\u05D9\\u05DD \\u05E0\\u05D5\\u05E6\\u05DC\\u05D5\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=\\u05DE\\u05D1\\u05D5\\u05E7\\u05E9\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=\\u05D6\\u05DB\\u05D0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=\\u05D6\\u05DB\\u05D0\\u05D5\\u05EA\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=\\u05E9\\u05DC\\u05D7 \\u05D1\\u05E7\\u05E9\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=\\u05D4\\u05E1\\u05E8 \\u05D1\\u05E7\\u05E9\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=\\u05D6\\u05DB\\u05D0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=\\u05D4\\u05D9\\u05E1\\u05D8\\u05D5\\u05E8\\u05D9\\u05D4\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=\\u05E6\\u05D5\\u05E8 \\u05D1\\u05E7\\u05E9\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XBUT\r\nLR_SHOW_HIST=\\u05D4\\u05D9\\u05E1\\u05D8\\u05D5\\u05E8\\u05D9\\u05D4\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u05D1\\u05E7\\u05E9 \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=\\u05E9\\u05DC\\u05D7\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=\\u05D0\\u05E4\\u05E1\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=\\u05D1\\u05D8\\u05DC\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=\\u05E9\\u05E0\\u05D4\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=\\u05D4\\u05E1\\u05E8\r\n\r\n#XSEL\r\nLR_UPDATED=\\u05E2\\u05D5\\u05D3\\u05DB\\u05DF\r\n\r\n#XFLD\r\nLR_NOTE=\\u05D4\\u05E2\\u05E8\\u05D4\r\n\r\n#XFLD\r\nLR_CUSTOM1=\\u05E9\\u05D3\\u05D4 \\u05DE\\u05D5\\u05EA\\u05D0\\u05DD \\u05D0\\u05D9\\u05E9\\u05D9\\u05EA 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=\\u05E0\\u05D5\\u05E6\\u05DC\\u05D5\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=\\u05E0\\u05D5\\u05EA\\u05E8\\u05D5\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=\\u05D9\\u05DE\\u05D9\\u05DD\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=\\u05D9\\u05D5\\u05DD\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=\\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=\\u05E9\\u05E2\\u05D4\r\n\r\n#XFLD\r\nLR_UP_TO=\\u05D1\\u05EA\\u05D5\\u05E7\\u05E3 \\u05E2\\u05D3\r\n\r\n#XFLD\r\nLR_FROM=\\u05DE-\r\n\r\n#XFLD\r\nLR_TO=\\u05E2\\u05D3\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=\\u05D0\\u05D9\\u05E9\\u05D5\\u05E8\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u05D4\\u05D0\\u05DD \\u05DC\\u05E9\\u05DC\\u05D5\\u05D7 \\u05D0\\u05EA \\u05D1\\u05E7\\u05E9\\u05EA \\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05D4\\u05D6\\u05D5 \\u05D0\\u05DC {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=\\u05D4\\u05D0\\u05DD \\u05D1\\u05E8\\u05E6\\u05D5\\u05E0\\u05DA \\u05DC\\u05D4\\u05E1\\u05D9\\u05E8 \\u05D1\\u05E7\\u05E9\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05D6\\u05D5?\r\n\r\n#XFLD\r\nLR_DAYS=\\u05D9\\u05DE\\u05D9\\u05DD\r\n\r\n#XFLD\r\nLR_DAY=\\u05D9\\u05D5\\u05DD\r\n\r\n#XFLD\r\nLR_HOURS=\\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XFLD\r\nLR_HOUR=\\u05E9\\u05E2\\u05D4\r\n\r\n#XFLD\r\nLR_REQUEST=\\u05DE\\u05D1\\u05D5\\u05E7\\u05E9\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=\\u05D4\\u05D9\\u05D5\\u05DD\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=\\u05D9\\u05DE\\u05D9\\u05DD \\u05E9\\u05E0\\u05D1\\u05D7\\u05E8\\u05D5\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=\\u05DE\\u05E2\\u05D1\\u05D3...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=\\u05D1\\u05E7\\u05E9\\u05EA \\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05E9\\u05DC\\u05DA \\u05E0\\u05E9\\u05DC\\u05D7\\u05D4 \\u05D0\\u05DC {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=\\u05D1\\u05E7\\u05E9\\u05EA \\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05E9\\u05DC\\u05DA \\u05D4\\u05D5\\u05E1\\u05E8\\u05D4\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05D4 \\u05E4\\u05E0\\u05D9\\u05DE\\u05D9\\u05EA; \\u05D3\\u05D2\\u05DD \\u05DC\\u05D0 \\u05E0\\u05E8\\u05E9\\u05DD\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05EA \\u05E4\\u05E8\\u05D5\\u05D8\\u05D5\\u05E7\\u05D5\\u05DC; \\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05D4\\u05D9\\u05D4 \\u05DC\\u05E0\\u05EA\\u05D7 \\u05EA\\u05D2\\u05D5\\u05D1\\u05EA HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05EA \\u05E4\\u05E8\\u05D5\\u05D8\\u05D5\\u05E7\\u05D5\\u05DC; \\u05E9\\u05DD \\u05D4\\u05DE\\u05D0\\u05E9\\u05E8 \\u05D7\\u05E1\\u05E8 \\u05D1\\u05EA\\u05D2\\u05D5\\u05D1\\u05D4\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05EA \\u05E4\\u05E8\\u05D5\\u05D8\\u05D5\\u05E7\\u05D5\\u05DC; \\u05EA\\u05E6\\u05D5\\u05E8\\u05D4 \\u05D7\\u05E1\\u05E8\\u05D4 \\u05D1\\u05EA\\u05D2\\u05D5\\u05D1\\u05D4\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05EA \\u05E4\\u05E8\\u05D5\\u05D8\\u05D5\\u05E7\\u05D5\\u05DC; \\u05D9\\u05EA\\u05E8\\u05D5\\u05EA \\u05D7\\u05E1\\u05E8\\u05D5\\u05EA \\u05D1\\u05EA\\u05D2\\u05D5\\u05D1\\u05D4\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05EA \\u05E4\\u05E8\\u05D5\\u05D8\\u05D5\\u05E7\\u05D5\\u05DC; \\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05D4\\u05D9\\u05D4 \\u05DC\\u05E0\\u05EA\\u05D7 \\u05EA\\u05D2\\u05D5\\u05D1\\u05D4\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05E2\\u05DD \\u05D4\\u05D7\\u05D9\\u05D1\\u05D5\\u05E8 \\u05E9\\u05DC\\u05DA\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05D1\\u05E2\\u05D9\\u05D4 \\u05D8\\u05DB\\u05E0\\u05D9\\u05EA\\n\\n\\u05E4\\u05E8\\u05D8\\u05D9 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4\\:\\n\\u05E9\\u05D2\\u05D9\\u05D0\\u05EA \\u05E4\\u05E8\\u05D5\\u05D8\\u05D5\\u05E7\\u05D5\\u05DC; \\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05D4\\u05D9\\u05D4 \\u05DC\\u05E0\\u05EA\\u05D7 \\u05EA\\u05D2\\u05D5\\u05D1\\u05D4\r\n\r\n#XFLD\r\nLR_S1_PENDING=\\u05D1\\u05D4\\u05DE\\u05EA\\u05E0\\u05D4\r\n\r\n#YMSG\r\nLR_UNKNOWN=\\u05DC\\u05D0 \\u05D9\\u05D3\\u05D5\\u05E2\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=\\u05D9\\u05D5\\u05DD \\u05E9\\u05D0\\u05D9\\u05E0\\u05D5 \\u05D9\\u05D5\\u05DD \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=\\u05D0\\u05D5\\u05E9\\u05E8\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=\\u05E0\\u05D3\\u05D7\\u05D4\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=\\u05D0\\u05D9\\u05E9\\u05D5\\u05E8 \\u05D1\\u05D4\\u05DE\\u05EA\\u05E0\\u05D4\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=\\u05D7\\u05D2 \\u05E8\\u05E9\\u05DE\\u05D9\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=\\u05D9\\u05D5\\u05DD \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=\\u05D4\\u05D5\\u05D2\\u05E9\\u05D4 \\u05D1\\u05E7\\u05E9\\u05D4 \\u05DC\\u05D1\\u05D9\\u05D8\\u05D5\\u05DC\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u05D1\\u05E7\\u05E9\\u05EA \\u05D1\\u05D9\\u05D8\\u05D5\\u05DC\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=\\u05D1\\u05E7\\u05E9\\u05EA \\u05E9\\u05D9\\u05E0\\u05D5\\u05D9\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9 \\u05D1\\u05D4\\u05DE\\u05EA\\u05E0\\u05D4\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=\\u05D1\\u05D9\\u05D8\\u05D5\\u05DC \\u05D1\\u05D4\\u05DE\\u05EA\\u05E0\\u05D4\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=\\u05E9\\u05D9\\u05E0\\u05D5\\u05D9 \\u05D0\\u05D5\\u05E9\\u05E8\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=\\u05D1\\u05D9\\u05D8\\u05D5\\u05DC \\u05D0\\u05D5\\u05E9\\u05E8\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=\\u05DE\\u05E7\\u05D5\\u05E8\\u05D9\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=\\u05E9\\u05D5\\u05E0\\u05D4\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=\\u05DE\\u05D0\\u05E9\\u05E8\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=\\u05E9\\u05E2\\u05D5\\u05EA \\u05D4\\u05D9\\u05E2\\u05D3\\u05E8\\u05D5\\u05EA/\\u05E0\\u05D5\\u05DB\\u05D7\\u05D5\\u05EA\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=\\u05E7\\u05D1\\u05E6\\u05D9\\u05DD \\u05DE\\u05E6\\u05D5\\u05E8\\u05E4\\u05D9\\u05DD\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=\\u05D4\\u05D5\\u05E1\\u05E3 \\u05E7\\u05D5\\u05D1\\u05E5 \\u05DE\\u05E6\\u05D5\\u05E8\\u05E3\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=\\u05E9\\u05E2\\u05EA \\u05D4\\u05EA\\u05D7\\u05DC\\u05D4\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=\\u05E9\\u05E2\\u05EA \\u05E1\\u05D9\\u05D5\\u05DD\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=\\u05DC\\u05D0 \\u05E0\\u05D9\\u05EA\\u05DF \\u05D4\\u05D9\\u05D4 \\u05DC\\u05D4\\u05E2\\u05DC\\u05D5\\u05EA \\u05D0\\u05EA \\u05D4\\u05E7\\u05D5\\u05D1\\u05E5 \\u05D4\\u05DE\\u05E6\\u05D5\\u05E8\\u05E3\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=\\u05E1\\u05D5\\u05D2 \\u05D6\\u05D4 \\u05E9\\u05DC \\u05E7\\u05D5\\u05D1\\u05E5 \\u05DE\\u05E6\\u05D5\\u05E8\\u05E3 \\u05D0\\u05D9\\u05E0\\u05D5 \\u05E0\\u05EA\\u05DE\\u05DA\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=\\u05E7\\u05D5\\u05D1\\u05E5 \\u05D2\\u05D3\\u05D5\\u05DC \\u05DE\\u05D3\\u05D9. \\u05D1\\u05D7\\u05E8 \\u05D1\\u05E7\\u05D5\\u05D1\\u05E5 \\u05E7\\u05D8\\u05DF \\u05DE-25MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_ja.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=\\u4F11\\u6687\\u7533\\u8ACB\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=\\u4F11\\u6687\\u7533\\u8ACB\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u4F11\\u6687\\u7533\\u8ACB\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=\\u4F11\\u6687\\u7533\\u8ACB\\u5909\\u66F4\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=\\u4F11\\u6687\\u4ED8\\u4E0E\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=\\u5C65\\u6B74\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=\\u4F11\\u6687\\u8A73\\u7D30\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u4F11\\u6687\\u7533\\u8ACB\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u4F11\\u6687\\u7533\\u8ACB\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=\\u30AB\\u30C6\\u30B4\\u30EA\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=\\u5229\\u7528\\u53EF\\u80FD\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=\\u6D88\\u5316\\u6E08\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=\\u7533\\u8ACB\\u6E08\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=\\u4F11\\u6687\\u4ED8\\u4E0E\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=\\u4F11\\u6687\\u4ED8\\u4E0E\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=\\u4F11\\u6687\\u7533\\u8ACB\\u9001\\u4FE1\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=\\u4F11\\u6687\\u7533\\u8ACB\\u53D6\\u6D88\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=\\u4F11\\u6687\\u4ED8\\u4E0E\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=\\u5C65\\u6B74\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=\\u4F11\\u6687\\u7533\\u8ACB\\u767B\\u9332\r\n\r\n#XBUT\r\nLR_SHOW_HIST=\\u5C65\\u6B74\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u4F11\\u6687\\u7533\\u8ACB\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=\\u9001\\u4FE1\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=\\u30EA\\u30BB\\u30C3\\u30C8\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=\\u4E2D\\u6B62\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=\\u5909\\u66F4\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=\\u53D6\\u6D88\r\n\r\n#XSEL\r\nLR_UPDATED=\\u66F4\\u65B0\\u6E08\r\n\r\n#XFLD\r\nLR_NOTE=\\u30E1\\u30E2\r\n\r\n#XFLD\r\nLR_CUSTOM1=\\u30E6\\u30FC\\u30B6\\u5B9A\\u7FA9\\u9805\\u76EE 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=\\u6D88\\u5316\\u6E08\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=\\u5229\\u7528\\u53EF\\u80FD\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=\\u65E5\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=\\u65E5\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=\\u6642\\u9593\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=\\u6642\\u9593\r\n\r\n#XFLD\r\nLR_UP_TO=\\u6709\\u52B9\\u671F\\u9650\r\n\r\n#XFLD\r\nLR_FROM=\\u958B\\u59CB\r\n\r\n#XFLD\r\nLR_TO=\\u7D42\\u4E86\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=\\u78BA\\u8A8D\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u3053\\u306E\\u4F11\\u6687\\u7533\\u8ACB\\u3092 {0} \\u306B\\u9001\\u4FE1\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=\\u3053\\u306E\\u4F11\\u6687\\u7533\\u8ACB\\u3092\\u53D6\\u308A\\u6D88\\u3057\\u307E\\u3059\\u304B\\u3002\r\n\r\n#XFLD\r\nLR_DAYS=\\u65E5\r\n\r\n#XFLD\r\nLR_DAY=\\u65E5\r\n\r\n#XFLD\r\nLR_HOURS=\\u6642\\u9593\r\n\r\n#XFLD\r\nLR_HOUR=\\u6642\\u9593\r\n\r\n#XFLD\r\nLR_REQUEST=\\u7533\\u8ACB\\u6E08\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=\\u672C\\u65E5\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=\\u9078\\u629E\\u65E5\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=\\u51E6\\u7406\\u4E2D...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=\\u4F11\\u6687\\u7533\\u8ACB\\u304C {0} \\u306B\\u9001\\u4FE1\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=\\u4F11\\u6687\\u7533\\u8ACB\\u304C\\u53D6\\u308A\\u6D88\\u3055\\u308C\\u307E\\u3057\\u305F\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u5185\\u90E8\\u30A8\\u30E9\\u30FC\\: \\u30E2\\u30C7\\u30EB\\u304C\\u767B\\u9332\\u3055\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u30D7\\u30ED\\u30C8\\u30B3\\u30EB\\u30A8\\u30E9\\u30FC\\: HTTP \\u5FDC\\u7B54\\u3092\\u30D1\\u30FC\\u30B9\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u30D7\\u30ED\\u30C8\\u30B3\\u30EB\\u30A8\\u30E9\\u30FC\\: \\u5FDC\\u7B54\\u306B\\u627F\\u8A8D\\u8005\\u540D\\u304C\\u542B\\u307E\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u30D7\\u30ED\\u30C8\\u30B3\\u30EB\\u30A8\\u30E9\\u30FC\\: \\u5FDC\\u7B54\\u306B\\u8A2D\\u5B9A\\u304C\\u542B\\u307E\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u30D7\\u30ED\\u30C8\\u30B3\\u30EB\\u30A8\\u30E9\\u30FC\\: \\u5FDC\\u7B54\\u306B\\u30D0\\u30E9\\u30F3\\u30B9\\u304C\\u542B\\u307E\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u30D7\\u30ED\\u30C8\\u30B3\\u30EB\\u30A8\\u30E9\\u30FC\\: \\u5FDC\\u7B54\\u3092\\u30D1\\u30FC\\u30B9\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=\\u63A5\\u7D9A\\u6642\\u306B\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=\\u30A8\\u30E9\\u30FC\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=\\u6280\\u8853\\u7684\\u306A\\u554F\\u984C\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\n\\n\\u30A8\\u30E9\\u30FC\\u8A73\\u7D30\\: \\n\\u30D7\\u30ED\\u30C8\\u30B3\\u30EB\\u30A8\\u30E9\\u30FC\\: \\u5FDC\\u7B54\\u3092\\u30D1\\u30FC\\u30B9\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n#XFLD\r\nLR_S1_PENDING=\\u4FDD\\u7559\r\n\r\n#YMSG\r\nLR_UNKNOWN=\\u672A\\u5B9A\\u7FA9\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=\\u4F11\\u65E5\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=\\u627F\\u8A8D\\u6E08\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=\\u5374\\u4E0B\\u6E08\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=\\u627F\\u8A8D\\u4FDD\\u7559\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=\\u795D\\u65E5\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=\\u52E4\\u52D9\\u65E5\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=\\u53D6\\u6D88\\u4F9D\\u983C\\u6E08\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u53D6\\u6D88\\u4F9D\\u983C\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=\\u7533\\u8ACB\\u5909\\u66F4\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=\\u5909\\u66F4\\u4FDD\\u7559\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=\\u53D6\\u6D88\\u4FDD\\u7559\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=\\u5909\\u66F4\\u627F\\u8A8D\\u6E08\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=\\u53D6\\u6D88\\u627F\\u8A8D\\u6E08\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=\\u5909\\u66F4\\u524D\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=\\u5909\\u66F4\\u5F8C\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=\\u627F\\u8A8D\\u8005\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=\\u51FA\\u52E4/\\u4F11\\u52D9\\u6642\\u9593\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=\\u6DFB\\u4ED8\\u6587\\u66F8\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=\\u6DFB\\u4ED8\\u6587\\u66F8\\u8FFD\\u52A0\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=\\u958B\\u59CB\\u6642\\u523B\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=\\u7D42\\u4E86\\u6642\\u523B\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=\\u6DFB\\u4ED8\\u6587\\u66F8\\u3092\\u30A2\\u30C3\\u30D7\\u30ED\\u30FC\\u30C9\\u3067\\u304D\\u307E\\u305B\\u3093\\u3067\\u3057\\u305F\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=\\u3053\\u306E\\u6DFB\\u4ED8\\u6587\\u66F8\\u30BF\\u30A4\\u30D7\\u306F\\u30B5\\u30DD\\u30FC\\u30C8\\u3055\\u308C\\u3066\\u3044\\u307E\\u305B\\u3093\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=\\u30D5\\u30A1\\u30A4\\u30EB\\u30B5\\u30A4\\u30BA\\u304C\\u5927\\u304D\\u3059\\u304E\\u307E\\u3059\\u3002\\u30B5\\u30A4\\u30BA\\u304C 25MB \\u672A\\u6E80\\u306E\\u30D5\\u30A1\\u30A4\\u30EB\\u3092\\u9078\\u629E\\u3057\\u3066\\u304F\\u3060\\u3055\\u3044\\u3002\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_no.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Mine frav\\u00E6rss\\u00F8knader\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Mine frav\\u00E6rss\\u00F8knader\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=S\\u00F8k om frav\\u00E6r\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Endre frav\\u00E6rss\\u00F8knad\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Krav\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Historikk\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Frav\\u00E6rsdetaljer\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Frav\\u00E6rss\\u00F8knader\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Frav\\u00E6rss\\u00F8knad\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Kategori\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=tilgjengelig\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=brukt\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Rekvirert\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Krav\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Krav\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Send frav\\u00E6rss\\u00F8knad\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Annuller frav\\u00E6rss\\u00F8knad\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Krav\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Historikk\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Opprett frav\\u00E6rss\\u00F8knad\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Historikk\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=S\\u00F8k om frav\\u00E6r\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Send\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Tilbakestill\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Avbryt\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Endre\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Annuller\r\n\r\n#XSEL\r\nLR_UPDATED=Oppdatert\r\n\r\n#XFLD\r\nLR_NOTE=Merknad\r\n\r\n#XFLD\r\nLR_CUSTOM1=Brukerdefinert felt 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=brukt\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=tilgjengelig\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=dager\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=dag\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=timer\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=time\r\n\r\n#XFLD\r\nLR_UP_TO=Gyldig til\r\n\r\n#XFLD\r\nLR_FROM=Fra\r\n\r\n#XFLD\r\nLR_TO=Til\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Feil har oppst\\u00E5tt\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Bekreftelse\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Sende denne frav\\u00E6rss\\u00F8knaden til {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Vil du annullere denne frav\\u00E6rss\\u00F8knaden?\r\n\r\n#XFLD\r\nLR_DAYS=dager\r\n\r\n#XFLD\r\nLR_DAY=dag\r\n\r\n#XFLD\r\nLR_HOURS=timer\r\n\r\n#XFLD\r\nLR_HOUR=time\r\n\r\n#XFLD\r\nLR_REQUEST=Rekvirert\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=I dag\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Valgte dager\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Behandler ...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Frav\\u00E6rss\\u00F8knaden er sendt til {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Frav\\u00E6rss\\u00F8knaden din er annullert\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nIntern feil, modell er ikke registrert\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nProtokollfeil, kan ikke analysere HTTP-svar\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nProtokollfeil, godkjennernavn mangler i svar\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nProtokollfeil, konfigurasjon mangler i svar\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nProtokollfeil, saldoer mangler i svar\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nProtokollfeil, kan ikke analysere svar\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Forbindelsesfeil\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Det har oppst\\u00E5tt en feil\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Et teknisk problem har oppst\\u00E5tt\\n\\nFeildetaljer\\:\\nProtokollfeil, kan ikke analysere svar\r\n\r\n#XFLD\r\nLR_S1_PENDING=Venter\r\n\r\n#YMSG\r\nLR_UNKNOWN=Ukjent\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Fridag\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Godkjent\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Avvist\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Venter p\\u00E5 godkjenning\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Helgedag\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Virkedag\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Annullering \\u00F8nsket\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Annulleringsforesp\\u00F8rsel\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Endringsforesp\\u00F8rsel\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Venter p\\u00E5 endring\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Venter p\\u00E5 annullering\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Endring godkjent\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Annullering godkjent\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Endret\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Godkjenner\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Fremm\\u00F8te-/frav\\u00E6rstimer\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Vedlegg\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Tilf\\u00F8y vedlegg\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Starttidspunkt\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Sluttidspunkt\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Kan ikke laste opp vedlegg\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Vedleggstypen st\\u00F8ttes ikke\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Filst\\u00F8rrelsen er for stor. Velg en fil som er mindre enn 25 MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_pl.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Moje wnioski urlopowe\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Moje wnioski urlopowe\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Wniosek o urlop\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Zmiana wniosku urlopowego\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Uprawnienia\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Historia\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Szczeg\\u00F3\\u0142y urlopu\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Wnioski urlopowe\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Wniosek urlopowy\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Kategoria\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Dost\\u0119pne\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Wykorzystane\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Wnioskowane\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Uprawnienia\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Uprawnienie\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Wysy\\u0142anie wniosku urlopowego\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Wycofanie wniosku urlopowego\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Uprawnienia\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Historia\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Nowy wniosek urlopowy\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Historia\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Wniosek o urlop\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Wy\\u015Blij\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Resetuj\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Anuluj\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Zmie\\u0144\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Wycofaj\r\n\r\n#XSEL\r\nLR_UPDATED=Zaktualizowane\r\n\r\n#XFLD\r\nLR_NOTE=Notatka\r\n\r\n#XFLD\r\nLR_CUSTOM1=Pole u\\u017Cytkownika 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=wykorzystanych\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=dost\\u0119pnych\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=dni\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=dzie\\u0144\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=godziny\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=godzina\r\n\r\n#XFLD\r\nLR_UP_TO=Wa\\u017Cne do\r\n\r\n#XFLD\r\nLR_FROM=Od\r\n\r\n#XFLD\r\nLR_TO=Do\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Wyst\\u0105pi\\u0142 problem\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Potwierdzenie\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Wys\\u0142a\\u0107 ten wniosek urlopowy do {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Czy chcesz wycofa\\u0107 ten wniosek urlopowy?\r\n\r\n#XFLD\r\nLR_DAYS=dni\r\n\r\n#XFLD\r\nLR_DAY=Dzie\\u0144\r\n\r\n#XFLD\r\nLR_HOURS=Godziny\r\n\r\n#XFLD\r\nLR_HOUR=Godzina\r\n\r\n#XFLD\r\nLR_REQUEST=Wnioskowane\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Dzisiaj\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Wybrane dni\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Przetwarzanie...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Wys\\u0142ano wniosek urlopowy do {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Wycofano wniosek urlopowy\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d wewn\\u0119trzny; nie zarejestrowano modelu\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d protoko\\u0142u; nie mo\\u017Cna by\\u0142o przeanalizowa\\u0107 sk\\u0142adni odpowiedzi HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d protoko\\u0142u; brak nazwiska osoby zatwierdzaj\\u0105cej w odpowiedzi\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d protoko\\u0142u; brak konfiguracji w odpowiedzi\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d protoko\\u0142u; brak sald w odpowiedzi\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d protoko\\u0142u; nie mo\\u017Cna by\\u0142o przeanalizowa\\u0107 sk\\u0142adni odpowiedzi\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d po\\u0142\\u0105czenia\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d techniczny\\n\\nSzczeg\\u00F3\\u0142y b\\u0142\\u0119du\\:\\nB\\u0142\\u0105d protoko\\u0142u; nie mo\\u017Cna by\\u0142o przeanalizowa\\u0107 sk\\u0142adni odpowiedzi\r\n\r\n#XFLD\r\nLR_S1_PENDING=Oczekuje\r\n\r\n#YMSG\r\nLR_UNKNOWN=Nieznane\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Dzie\\u0144 wolny od pracy\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Zatwierdzone\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Odrzucone\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Oczekuje na zatwierdzenie\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Dzie\\u0144 \\u015Bwi\\u0105teczny\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Dzie\\u0144 roboczy\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Za\\u017C\\u0105dano anulowania\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u017B\\u0105danie anulowania\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Wniosek o zmian\\u0119\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Zmiana oczekuje\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Anulowanie oczekuje\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Zatwierdzono zmian\\u0119\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Zatwierdzono anulowanie\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Oryginalne\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Zmienione\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Osoba zatwierdzaj\\u0105ca\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Godziny obecno\\u015Bci/nieobecno\\u015Bci\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Za\\u0142\\u0105czniki\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Dodaj za\\u0142\\u0105cznik\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Czas rozpocz\\u0119cia\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Czas zako\\u0144czenia\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Nie mo\\u017Cna by\\u0142o wczyta\\u0107 za\\u0142\\u0105cznika\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Ten typ za\\u0142\\u0105cznika nie jest obs\\u0142ugiwany\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Za du\\u017Cy rozmiar pliku. Wybierz plik mniejszy ni\\u017C 25 MB.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_pt.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=Minhas solicita\\u00E7\\u00F5es de aus\\u00EAncia\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=Minhas solicita\\u00E7\\u00F5es de aus\\u00EAncia\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=Solicitar aus\\u00EAncia\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=Modificar solicita\\u00E7\\u00E3o de aus\\u00EAncia\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Direitos\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Hist\\u00F3rico\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=Detalhes de aus\\u00EAncia\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=Solicita\\u00E7\\u00F5es aus\\u00EAncia\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=Solicita\\u00E7\\u00E3o de aus\\u00EAncia\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Categoria\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Dispon\\u00EDvel\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Utilizado\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Solicitado\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Direitos\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Direito\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=Enviar solicita\\u00E7\\u00E3o de aus\\u00EAncia\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=Estornar solicita\\u00E7\\u00E3o de aus\\u00EAncia\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Direitos\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Hist\\u00F3rico\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=Criar solicita\\u00E7\\u00E3o de aus\\u00EAncia\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Hist\\u00F3rico\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=Solicitar aus\\u00EAncia\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=Enviar\r\n\r\n#XBUT: text for ok button \r\nLR_OK=OK\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=Reinicializar\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=Anular\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=Modificar\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Estornar\r\n\r\n#XSEL\r\nLR_UPDATED=Atualizada\r\n\r\n#XFLD\r\nLR_NOTE=Nota\r\n\r\n#XFLD\r\nLR_CUSTOM1=Campo personalizado 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=gozados\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=dispon\\u00EDveis\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=dias\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=dia\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=horas\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=hora\r\n\r\n#XFLD\r\nLR_UP_TO=V\\u00E1lido at\\u00E9\r\n\r\n#XFLD\r\nLR_FROM=De\r\n\r\n#XFLD\r\nLR_TO=A\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Ocorreu um problema\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Confirma\\u00E7\\u00E3o\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=Enviar essa solicita\\u00E7\\u00E3o de aus\\u00EAncia para {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Estornar essa solicita\\u00E7\\u00E3o de aus\\u00EAncia?\r\n\r\n#XFLD\r\nLR_DAYS=Dias\r\n\r\n#XFLD\r\nLR_DAY=Dia\r\n\r\n#XFLD\r\nLR_HOURS=Horas\r\n\r\n#XFLD\r\nLR_HOUR=Hora\r\n\r\n#XFLD\r\nLR_REQUEST=Solicitada\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Hoje\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Dia(s) selecionado(s)\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=Processando...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=Sua solicita\\u00E7\\u00E3o de aus\\u00EAncia foi enviada para {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=Sua solicita\\u00E7\\u00E3o de aus\\u00EAncia foi estornada\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro interno; modelo n\\u00E3o registrado\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro de protocolo; n\\u00E3o foi poss\\u00EDvel analisar resposta HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro de protocolo; falta nome do autorizador na resposta\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro de protocolo; falta configura\\u00E7\\u00E3o na resposta\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro de protocolo; faltam saldos na resposta\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro de protocolo; n\\u00E3o foi poss\\u00EDvel analisar resposta\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Ocorreu um problema com sua conex\\u00E3o\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Ocorreu um erro\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Ocorreu um problema t\\u00E9cnico\\n\\nDetalhes do erro\\:\\nErro de protocolo; n\\u00E3o foi poss\\u00EDvel analisar resposta\r\n\r\n#XFLD\r\nLR_S1_PENDING=Pendente\r\n\r\n#YMSG\r\nLR_UNKNOWN=Desconhecida\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=Dia livre\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Aprovada\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Rejeitada\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Aprova\\u00E7\\u00E3o pendente\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Feriado\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=Dia \\u00FAtil\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=Cancelamento solicitado\r\n\r\n#XTIT\r\nLR_DELETION_REQ=Solicita\\u00E7\\u00E3o de cancelamento\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=Modificar solicita\\u00E7\\u00E3o\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=Modificar pendente\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=Cancelamento pendente\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=Modifica\\u00E7\\u00E3o aprovada\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=Cancelamento aprovado\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Original\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=Modificada\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Autorizador\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Horas de presen\\u00E7a/aus\\u00EAncia\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Anexos\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Adicionar anexo\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Hora de in\\u00EDcio\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Hora de fim\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Imposs\\u00EDvel carregar o anexo\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Tipo de anexo n\\u00E3o suportado\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Tamanho do arquivo \\u00E9 muito grande. Selecione um arquivo com menos de 25MB de tamanho.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_ru.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=\\u041C\\u043E\\u0438 \\u0437\\u0430\\u044F\\u0432\\u043A\\u0438 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=\\u041C\\u043E\\u0438 \\u0437\\u0430\\u044F\\u0432\\u043A\\u0438 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0441\\u0438\\u0442\\u044C \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=\\u041F\\u0440\\u0430\\u0432\\u0430\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=\\u0418\\u0441\\u0442\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=\\u041E\\u0442\\u043F\\u0443\\u0441\\u043A \\u043F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u0417\\u0430\\u044F\\u0432\\u043A\\u0438 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u0417\\u0430\\u044F\\u0432\\u043A\\u0430 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=\\u041A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=\\u0414\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u043E\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=\\u0418\\u0441\\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u043D\\u043E\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0448\\u0435\\u043D\\u043E\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=\\u041F\\u0440\\u0430\\u0432\\u0430\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=\\u041F\\u0440\\u0430\\u0432\\u043E\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=\\u041E\\u0442\\u043F\\u0440\\u0430\\u0432\\u0438\\u0442\\u044C \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=\\u041E\\u0442\\u043E\\u0437\\u0432\\u0430\\u0442\\u044C \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=\\u041F\\u0440\\u0430\\u0432\\u0430\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=\\u0418\\u0441\\u0442\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=\\u0421\\u043E\\u0437\\u0434\\u0430\\u0442\\u044C \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XBUT\r\nLR_SHOW_HIST=\\u0418\\u0441\\u0442\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0441\\u0438\\u0442\\u044C \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=\\u041E\\u0442\\u043F\\u0440\\u0430\\u0432\\u0438\\u0442\\u044C\r\n\r\n#XBUT: text for ok button \r\nLR_OK=\\u041E\\u041A\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=\\u0421\\u0431\\u0440\\u043E\\u0441\\u0438\\u0442\\u044C\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=\\u041E\\u0442\\u043E\\u0437\\u0432\\u0430\\u0442\\u044C\r\n\r\n#XSEL\r\nLR_UPDATED=\\u041E\\u0431\\u043D\\u043E\\u0432\\u043B\\u0435\\u043D\\u043E\r\n\r\n#XFLD\r\nLR_NOTE=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u0435\r\n\r\n#XFLD\r\nLR_CUSTOM1=\\u041F\\u043E\\u043B\\u0435 \\u043A\\u043B\\u0438\\u0435\\u043D\\u0442\\u0430 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=\\u0438\\u0441\\u043F\\u043E\\u043B\\u044C\\u0437\\u043E\\u0432\\u0430\\u043D\\u043E\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=\\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u043E\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=\\u0434\\u043D.\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=\\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=\\u0447.\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=\\u0447\\u0430\\u0441\r\n\r\n#XFLD\r\nLR_UP_TO=\\u0414\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u043E \\u043F\\u043E\r\n\r\n#XFLD\r\nLR_FROM=\\u0421\r\n\r\n#XFLD\r\nLR_TO=\\u041F\\u043E\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=\\u041F\\u043E\\u0434\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u041E\\u0442\\u043F\\u0440\\u0430\\u0432\\u0438\\u0442\\u044C \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A {0}?\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=\\u041E\\u0442\\u043E\\u0437\\u0432\\u0430\\u0442\\u044C \\u044D\\u0442\\u0443 \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A?\r\n\r\n#XFLD\r\nLR_DAYS=\\u0434\\u043D.\r\n\r\n#XFLD\r\nLR_DAY=\\u0434\\u0435\\u043D\\u044C\r\n\r\n#XFLD\r\nLR_HOURS=\\u0447.\r\n\r\n#XFLD\r\nLR_HOUR=\\u0447\\u0430\\u0441\r\n\r\n#XFLD\r\nLR_REQUEST=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0448\\u0435\\u043D\\u043E\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=\\u0421\\u0435\\u0433\\u043E\\u0434\\u043D\\u044F\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=\\u0412\\u044B\\u0431\\u0440\\u0430\\u043D\\u043D\\u044B\\u0439 \\u0434\\u0435\\u043D\\u044C(\\u0434\\u043D\\u0438)\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=\\u041E\\u0431\\u0440\\u0430\\u0431\\u043E\\u0442\\u043A\\u0430...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=\\u0417\\u0430\\u044F\\u0432\\u043A\\u0430 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A \\u043E\\u0442\\u043F\\u0440\\u0430\\u0432\\u043B\\u0435\\u043D\\u0430 {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=\\u0412\\u0430\\u0448\\u0430 \\u0437\\u0430\\u044F\\u0432\\u043A\\u0430 \\u043D\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A \\u043E\\u0442\\u043E\\u0437\\u0432\\u0430\\u043D\\u0430\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u0412\\u043D\\u0443\\u0442\\u0440\\u0435\\u043D\\u043D\\u044F\\u044F \\u043E\\u0448\\u0438\\u0431\\u043A\\u0430, \\u043C\\u043E\\u0434\\u0435\\u043B\\u044C \\u043D\\u0435 \\u0437\\u0430\\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0438\\u0440\\u043E\\u0432\\u0430\\u043D\\u0430\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u041E\\u0448\\u0438\\u0431\\u043A\\u0430 \\u043F\\u0440\\u043E\\u0442\\u043E\\u043A\\u043E\\u043B\\u0430, \\u043D\\u0435\\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u043F\\u0440\\u043E\\u0430\\u043D\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u043E\\u0432\\u0430\\u0442\\u044C \\u043E\\u0442\\u0432\\u0435\\u0442 HTTP\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u041E\\u0448\\u0438\\u0431\\u043A\\u0430 \\u043F\\u0440\\u043E\\u0442\\u043E\\u043A\\u043E\\u043B\\u0430, \\u0432 \\u043E\\u0442\\u0432\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0442 \\u0438\\u043C\\u0435\\u043D\\u0438 \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0430\\u044E\\u0449\\u0435\\u0433\\u043E\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u041E\\u0448\\u0438\\u0431\\u043A\\u0430 \\u043F\\u0440\\u043E\\u0442\\u043E\\u043A\\u043E\\u043B\\u0430, \\u0432 \\u043E\\u0442\\u0432\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0442 \\u043A\\u043E\\u043D\\u0444\\u0438\\u0433\\u0443\\u0440\\u0430\\u0446\\u0438\\u0438\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u041E\\u0448\\u0438\\u0431\\u043A\\u0430 \\u043F\\u0440\\u043E\\u0442\\u043E\\u043A\\u043E\\u043B\\u0430, \\u0432 \\u043E\\u0442\\u0432\\u0435\\u0442\\u0435 \\u043D\\u0435\\u0442 \\u043E\\u0441\\u0442\\u0430\\u0442\\u043A\\u043E\\u0432\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u041E\\u0448\\u0438\\u0431\\u043A\\u0430 \\u043F\\u0440\\u043E\\u0442\\u043E\\u043A\\u043E\\u043B\\u0430, \\u043D\\u0435\\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u043F\\u0440\\u043E\\u0430\\u043D\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u043E\\u0432\\u0430\\u0442\\u044C \\u043E\\u0442\\u0432\\u0435\\u0442\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430 \\u0441 \\u0441\\u043E\\u0435\\u0434\\u0438\\u043D\\u0435\\u043D\\u0438\\u0435\\u043C\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u043E\\u0448\\u0438\\u0431\\u043A\\u0430\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=\\u0412\\u043E\\u0437\\u043D\\u0438\\u043A\\u043B\\u0430 \\u0442\\u0435\\u0445\\u043D\\u0438\\u0447\\u0435\\u0441\\u043A\\u0430\\u044F \\u043F\\u0440\\u043E\\u0431\\u043B\\u0435\\u043C\\u0430\\n\\n\\u041F\\u043E\\u0434\\u0440\\u043E\\u0431\\u043D\\u043E\\u0441\\u0442\\u0438\\:\\n\\u041E\\u0448\\u0438\\u0431\\u043A\\u0430 \\u043F\\u0440\\u043E\\u0442\\u043E\\u043A\\u043E\\u043B\\u0430, \\u043D\\u0435\\u0432\\u043E\\u0437\\u043C\\u043E\\u0436\\u043D\\u043E \\u043F\\u0440\\u043E\\u0430\\u043D\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u043E\\u0432\\u0430\\u0442\\u044C \\u043E\\u0442\\u0432\\u0435\\u0442\r\n\r\n#XFLD\r\nLR_S1_PENDING=\\u041E\\u0436\\u0438\\u0434\\u0430\\u0435\\u0442\r\n\r\n#YMSG\r\nLR_UNKNOWN=\\u041D\\u0435\\u0438\\u0437\\u0432\\u0435\\u0441\\u0442\\u043D\\u043E\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=\\u041D\\u0435\\u0440\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u043E\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=\\u041E\\u0442\\u043A\\u043B\\u043E\\u043D\\u0435\\u043D\\u043E\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=\\u041E\\u0436\\u0438\\u0434\\u0430\\u0435\\u0442 \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=\\u041F\\u0440\\u0430\\u0437\\u0434\\u043D\\u0438\\u0447\\u043D\\u044B\\u0439 \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=\\u0420\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0434\\u0435\\u043D\\u044C\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0448\\u0435\\u043D\\u0430 \\u043E\\u0442\\u043C\\u0435\\u043D\\u0430\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0441 \\u043D\\u0430 \\u043E\\u0442\\u043C\\u0435\\u043D\\u0443\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=\\u0417\\u0430\\u043F\\u0440\\u043E\\u0441 \\u043D\\u0430 \\u0438\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u0435 \\u0432 \\u043E\\u0436\\u0438\\u0434\\u0430\\u043D\\u0438\\u0438\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0430 \\u0432 \\u043E\\u0436\\u0438\\u0434\\u0430\\u043D\\u0438\\u0438\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u0438\\u0435 \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u043E\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0430 \\u0443\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0435\\u043D\\u0430\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=\\u041E\\u0440\\u0438\\u0433\\u0438\\u043D\\u0430\\u043B\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=\\u0418\\u0437\\u043C\\u0435\\u043D\\u0435\\u043D\\u043E\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=\\u0423\\u0442\\u0432\\u0435\\u0440\\u0436\\u0434\\u0430\\u044E\\u0449\\u0438\\u0439\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=\\u0427\\u0430\\u0441\\u044B \\u043F\\u0440\\u0438\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0438\\u044F/\\u043E\\u0442\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0438\\u044F\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=\\u0412\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=\\u0414\\u043E\\u0431\\u0430\\u0432\\u0438\\u0442\\u044C \\u0432\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=\\u0412\\u0440\\u0435\\u043C\\u044F \\u043D\\u0430\\u0447\\u0430\\u043B\\u0430\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=\\u0412\\u0440\\u0435\\u043C\\u044F \\u043E\\u043A\\u043E\\u043D\\u0447\\u0430\\u043D\\u0438\\u044F\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=\\u041D\\u0435 \\u0443\\u0434\\u0430\\u043B\\u043E\\u0441\\u044C \\u0437\\u0430\\u0433\\u0440\\u0443\\u0437\\u0438\\u0442\\u044C \\u0432\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=\\u042D\\u0442\\u043E\\u0442 \\u0442\\u0438\\u043F \\u0432\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u044F \\u043D\\u0435 \\u043F\\u043E\\u0434\\u0434\\u0435\\u0440\\u0436\\u0438\\u0432\\u0430\\u0435\\u0442\\u0441\\u044F\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=\\u0421\\u043B\\u0438\\u0448\\u043A\\u043E\\u043C \\u0431\\u043E\\u043B\\u044C\\u0448\\u043E\\u0439 \\u0440\\u0430\\u0437\\u043C\\u0435\\u0440 \\u0444\\u0430\\u0439\\u043B\\u0430; \\u0432\\u044B\\u0431\\u0435\\u0440\\u0438\\u0442\\u0435 \\u0444\\u0430\\u0439\\u043B \\u0440\\u0430\\u0437\\u043C\\u0435\\u0440\\u043E\\u043C \\u043C\\u0435\\u043D\\u0435\\u0435 25 \\u041C\\u0411\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_tr.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=\\u0130zin taleplerim\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=\\u0130zin taleplerim\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u0130zin talep et\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=\\u0130zin talebini de\\u011Fi\\u015Ftir\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=Haklar\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=Ge\\u00E7mi\\u015F\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=\\u0130zin ayr\\u0131nt\\u0131lar\\u0131\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u0130zin talepleri\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u0130zin talebi\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=Kategori\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=Kullan\\u0131labilir\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=Kullan\\u0131ld\\u0131\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=Talep edildi\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=Haklar\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=Hak\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=\\u0130zin talebini g\\u00F6nder\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=\\u0130zin talebini geri al\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=Haklar\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=Ge\\u00E7mi\\u015F\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=\\u0130zin talebi olu\\u015Ftur\r\n\r\n#XBUT\r\nLR_SHOW_HIST=Ge\\u00E7mi\\u015F\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u0130zin talep et\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=G\\u00F6nder\r\n\r\n#XBUT: text for ok button \r\nLR_OK=Tamam\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=S\\u0131f\\u0131rla\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=\\u0130ptal et\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=De\\u011Fi\\u015Fiklik\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=Geri al\r\n\r\n#XSEL\r\nLR_UPDATED=G\\u00FCncellendi\r\n\r\n#XFLD\r\nLR_NOTE=Not\r\n\r\n#XFLD\r\nLR_CUSTOM1=\\u00D6zel alan 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=kullan\\u0131lan\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=Kullan\\u0131labilir\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=g\\u00FCn\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=g\\u00FCn\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=saat\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=saat\r\n\r\n#XFLD\r\nLR_UP_TO=Ge\\u00E7erlilik biti\\u015Fi\r\n\r\n#XFLD\r\nLR_FROM=Ba\\u015Flang\\u0131\\u00E7\r\n\r\n#XFLD\r\nLR_TO=Biti\\u015F\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=Problem ortaya \\u00E7\\u0131kt\\u0131\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=Teyit\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u0130zin talebi g\\u00F6nderilsin mi? Al\\u0131c\\u0131\\: {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=Bu izin talebini geri almak istiyor musunuz?\r\n\r\n#XFLD\r\nLR_DAYS=g\\u00FCn\r\n\r\n#XFLD\r\nLR_DAY=G\\u00FCn\r\n\r\n#XFLD\r\nLR_HOURS=Saat\r\n\r\n#XFLD\r\nLR_HOUR=Saat\r\n\r\n#XFLD\r\nLR_REQUEST=Talep edildi\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=Bug\\u00FCn\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=Se\\u00E7ilen g\\u00FCn(ler)\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=\\u0130\\u015Fleniyor...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=\\u0130zin talebiniz g\\u00F6nderildi. Al\\u0131c\\u0131\\: {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=\\u0130zin talebiniz geri al\\u0131nd\\u0131\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nDahili hata; model kaydedilmedi\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nG\\u00FCnl\\u00FCk hatas\\u0131; HTTP cevab\\u0131 ayr\\u0131\\u015Ft\\u0131r\\u0131lamad\\u0131\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nG\\u00FCnl\\u00FCk hatas\\u0131; cevapta onaylayan ad\\u0131 eksik\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nG\\u00FCnl\\u00FCk hatas\\u0131; konfig\\u00FCrasyon cevapta eksik\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nG\\u00FCnl\\u00FCk hatas\\u0131; cevapta bakiyeler eksik\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nG\\u00FCnl\\u00FCk hatas\\u0131; cevap ayr\\u0131\\u015Ft\\u0131r\\u0131lamad\\u0131\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=Ba\\u011Flant\\u0131n\\u0131zla problem ortaya \\u00E7\\u0131kt\\u0131\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=Hata ortaya \\u00E7\\u0131kt\\u0131\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=Teknik problem ortaya \\u00E7\\u0131kt\\u0131\\n\\nHata ayr\\u0131nt\\u0131lar\\u0131\\:\\nG\\u00FCnl\\u00FCk hatas\\u0131; cevap ayr\\u0131\\u015Ft\\u0131r\\u0131lamad\\u0131\r\n\r\n#XFLD\r\nLR_S1_PENDING=Beklemede\r\n\r\n#YMSG\r\nLR_UNKNOWN=Bilinmiyor\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=\\u00C7al\\u0131\\u015F\\u0131lmayan g\\u00FCn\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=Onayland\\u0131\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=Reddedildi\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=Onay beklemede\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=Resmi tatil\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=\\u0130\\u015F g\\u00FCn\\u00FC\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=\\u0130ptal talep edildi\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u0130ptal talebi\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=De\\u011Fi\\u015Fiklik talebi\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=De\\u011Fi\\u015Fiklik beklemede\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=\\u0130ptal beklemede\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=De\\u011Fi\\u015Fiklik onayland\\u0131\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=\\u0130ptal onayland\\u0131\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=Orijinal\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=De\\u011Fi\\u015Ftirildi\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=Onaylayan\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=Devam/devams\\u0131zl\\u0131k saatleri\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=Ekler\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=Ek ekle\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=Ba\\u015Flang\\u0131\\u00E7 saati\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=Biti\\u015F saati\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=Ek y\\u00FCklenemedi\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=Bu ek t\\u00FCr\\u00FC desteklenmiyor\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=Dosya boyutu \\u00E7ok b\\u00FCy\\u00FCk. Boyut olarak 25MB\'tan daha k\\u00FC\\u00E7\\u00FCk dosya se\\u00E7in.\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/i18n/i18n_zh_CN.properties":'# GUID was created with http://www.famkruithof.net/uuid/uuidgen\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n\r\n#XTIT: Application name (shown in browser header bar or as browser tab title)\r\napp.Identity=\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: title of the home view\r\nLR_TITLE_HOME_VIEW=\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: title of the leave create view\r\nLR_TITLE_CREATE_VIEW=\\u7533\\u8BF7\\u4F11\\u5047\r\n\r\n#XTIT: title of the leave change view\r\nLR_TITLE_CHANGE_VIEW=\\u66F4\\u6539\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: title of the Entitlements view\r\nLR_TITLE_BALANCE_VIEW=\\u5E94\\u5F97\\u4F11\\u5047\r\n\r\n#XTIT: title of the leave History view\r\nLR_TITLE_HISTORY_VIEW=\\u5386\\u53F2\\u8BB0\\u5F55\r\n\r\n#XTIT: title of the leave details view\r\nLR_TITLE_DETAILS_VIEW=\\u4F11\\u5047\\u8BE6\\u7EC6\\u4FE1\\u606F\r\n\r\n#XTIT: title of the leave requests\r\nLR_TITLE_LEAVE_REQUESTS=\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: title of the leave request\r\nLR_TITLE_LEAVE_REQUEST=\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: deductible\r\nLR_BALANCE_DEDUCTIBLE=\\u7C7B\\u522B\r\n\r\n#XTIT: Balance\r\nLR_BALANCE_BALANCE=\\u53EF\\u7528\r\n\r\n#XTIT: Used\r\nLR_BALANCE_USED=\\u5DF2\\u4F7F\\u7528\r\n\r\n#XTIT: Requested\r\nLR_BALANCE_REQUESTED=\\u5DF2\\u7533\\u8BF7\r\n\r\n#XTIT: Quota\r\nLR_BALANCE_QUOTA=\\u5E94\\u5F97\\u4F11\\u5047\r\n\r\n#XTIT: Entitlement\r\nLR_ENTITLEMENT_QUOTA=\\u5E94\\u5F97\r\n\r\n#XTIT: Send leave request\r\nLR_TITLE_SEND=\\u53D1\\u9001\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: Cancel leave request\r\nLR_TITLE_WITHDRAW=\\u64A4\\u9500\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_BALANCE_TILE=\\u5E94\\u5F97\\u4F11\\u5047\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_HISTORY_TILE=\\u5386\\u53F2\\u8BB0\\u5F55\r\n\r\n#XTIT: ATTENTION Tile text line break after 12 characters!\r\nLR_CREATE_LEAVE_TILE=\\u521B\\u5EFA\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#XBUT\r\nLR_SHOW_HIST=\\u5386\\u53F2\\u8BB0\\u5F55\r\n\r\n#XBUT\r\nLR_CREATE_LEAVE=\\u7533\\u8BF7\\u4F11\\u5047\r\n\r\n#XBUT: text for "send leave request" button\r\nLR_SEND=\\u53D1\\u9001\r\n\r\n#XBUT: text for ok button \r\nLR_OK=\\u786E\\u5B9A\r\n\r\n#XBUT: text for reset button \r\nLR_RESET=\\u91CD\\u7F6E\r\n\r\n#XBUT: text for cancel button e.g. on the day range picker screen\r\nLR_CANCEL=\\u53D6\\u6D88\r\n\r\n#XBUT: text for change button on the Leave Overview details screen\r\nLR_CHANGE=\\u66F4\\u6539\r\n\r\n#XBUT: text for cancel button on the Leave Overview details screen\r\nLR_WITHDRAW=\\u64A4\\u9500\r\n\r\n#XSEL\r\nLR_UPDATED=\\u66F4\\u65B0\\u4E8E\r\n\r\n#XFLD\r\nLR_NOTE=\\u6CE8\\u91CA\r\n\r\n#XFLD\r\nLR_CUSTOM1=\\u81EA\\u5B9A\\u4E49\\u5B57\\u6BB5 1\r\n\r\n#XFLD: used vacation, lower case for status under calendar. Reads "X days [line feed] used"\r\nLR_BOOKED=\\u5DF2\\u7528\r\n\r\n#XFLD: Available balance, lower case for status under calendar. Reads "X days [line feed] available"\r\nLR_REMAINING=\\u53EF\\u7528\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAYS=\\u5929\r\n\r\n#XFLD\r\nLR_LOWERCASE_DAY=\\u5929\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOURS=\\u5C0F\\u65F6\r\n\r\n#XFLD\r\nLR_LOWERCASE_HOUR=\\u5C0F\\u65F6\r\n\r\n#XFLD\r\nLR_UP_TO=\\u6709\\u6548\\u671F\\u81F3\r\n\r\n#XFLD\r\nLR_FROM=\\u81EA\r\n\r\n#XFLD\r\nLR_TO=\\u81F3\r\n\r\n#XFLD: Hyphen for Date Formatting\r\nLR_HYPHEN=-\r\n\r\n#XTIT: title of error dialog\r\nLR_PROBLEM=\\u51FA\\u73B0\\u95EE\\u9898\r\n\r\n#XTIT: title of confirmation dialog\r\nLR_CONFIRMATION=\\u786E\\u8BA4\r\n\r\n#YMSG\r\nLR_CONFIRMATIONMSG=\\u662F\\u5426\\u5C06\\u6B64\\u4F11\\u5047\\u7533\\u8BF7\\u53D1\\u9001\\u7ED9 {0}\\uFF1F\r\n\r\n#YMSG\r\nLR_WITHDRAWNMSG=\\u662F\\u5426\\u8981\\u64A4\\u9500\\u6B64\\u4F11\\u5047\\u7533\\u8BF7\\uFF1F\r\n\r\n#XFLD\r\nLR_DAYS=\\u5929\r\n\r\n#XFLD\r\nLR_DAY=\\u5929\r\n\r\n#XFLD\r\nLR_HOURS=\\u5C0F\\u65F6\r\n\r\n#XFLD\r\nLR_HOUR=\\u5C0F\\u65F6\r\n\r\n#XFLD\r\nLR_REQUEST=\\u5DF2\\u7533\\u8BF7\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_TODAY=\\u4ECA\\u5929\r\n\r\n#XSEL: day type (legend)\r\nLR_DTYPE_SELECTED=\\u9009\\u5B9A\\u65E5\\u671F\r\n\r\n#YMSG: processing\r\nLR_PROCESSING=\\u6B63\\u5728\\u5904\\u7406...\r\n\r\n#YMSG\r\nLR_SUBMITDONE=\\u5DF2\\u5C06\\u60A8\\u7684\\u4F11\\u5047\\u7533\\u8BF7\\u53D1\\u9001\\u7ED9 {0}\r\n\r\n#YMSG\r\nLR_WITHDRAWDONE=\\u5DF2\\u64A4\\u9500\\u60A8\\u7684\\u4F11\\u5047\\u7533\\u8BF7\r\n\r\n#YMSG\r\nLR_AX_MODEL_NOT_REG=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u5185\\u90E8\\u9519\\u8BEF\\uFF1B\\u672A\\u6CE8\\u518C\\u6A21\\u578B\r\n\r\n#YMSG\r\nLR_AX_PARSE_ERR=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u534F\\u8BAE\\u9519\\u8BEF\\uFF1B\\u65E0\\u6CD5\\u89E3\\u6790 HTTP \\u54CD\\u5E94\r\n\r\n#YMSG\r\nLR_DD_NO_APPROVER=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u534F\\u8BAE\\u9519\\u8BEF\\uFF1B\\u54CD\\u5E94\\u4E2D\\u7F3A\\u5C11\\u5BA1\\u6279\\u4EBA\\u59D3\\u540D\r\n\r\n#YMSG\r\nLR_DD_NO_CFG=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u534F\\u8BAE\\u9519\\u8BEF\\uFF1B\\u54CD\\u5E94\\u4E2D\\u7F3A\\u5C11\\u914D\\u7F6E\r\n\r\n#YMSG\r\nLR_DD_NO_BALANCES=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u534F\\u8BAE\\u9519\\u8BEF\\uFF1B\\u54CD\\u5E94\\u4E2D\\u7F3A\\u5C11\\u5269\\u4F59\\u4F11\\u5047\r\n\r\n#YMSG\r\nLR_DD_PARSE_ERR=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u534F\\u8BAE\\u9519\\u8BEF\\uFF1B\\u65E0\\u6CD5\\u89E3\\u6790\\u54CD\\u5E94\r\n\r\n#YMSG\r\nLR_DD_COMM_ERR=\\u8FDE\\u63A5\\u51FA\\u73B0\\u95EE\\u9898\r\n\r\n#YMSG\r\nLR_DD_GENERIC_ERR=\\u51FA\\u9519\r\n\r\n#YMSG\r\nLR_CT_PARSE_ERR=\\u51FA\\u73B0\\u6280\\u672F\\u95EE\\u9898\\n\\n\\u9519\\u8BEF\\u8BE6\\u7EC6\\u4FE1\\u606F\\uFF1A\\n\\u534F\\u8BAE\\u9519\\u8BEF\\uFF1B\\u65E0\\u6CD5\\u89E3\\u6790\\u54CD\\u5E94\r\n\r\n#XFLD\r\nLR_S1_PENDING=\\u5F85\\u5B9A\r\n\r\n#YMSG\r\nLR_UNKNOWN=\\u672A\\u77E5\r\n\r\n#XSEL: (legend)\r\nLR_NONWORKING=\\u975E\\u5DE5\\u4F5C\\u65E5\r\n\r\n#XSEL: (legend)\r\nLR_APPROVELEAVE=\\u5DF2\\u6279\\u51C6\r\n\r\n#XSEL: (legend)\r\nLR_REJECTEDLEAVE=\\u5DF2\\u62D2\\u7EDD\r\n\r\n#XSEL: (legend)\r\nLR_APPROVEPENDING=\\u5F85\\u5BA1\\u6279\r\n\r\n#XSEL: (legend)\r\nLR_PUBLICHOLIDAY=\\u6CD5\\u5B9A\\u5047\\u65E5\r\n\r\n#XSEL: (legend)\r\nLR_WORKINGDAY=\\u5DE5\\u4F5C\\u65E5\r\n\r\n#XSEL: (legend)\r\nLR_DELETIONREQUESTED=\\u5DF2\\u7533\\u8BF7\\u53D6\\u6D88\r\n\r\n#XTIT\r\nLR_DELETION_REQ=\\u53D6\\u6D88\\u7533\\u8BF7\r\n\r\n#XTIT\r\nLR_CHANGE_REQ=\\u53D8\\u66F4\\u7533\\u8BF7\r\n\r\n#XTIT\r\nLR_CHANGE_PENDING=\\u5F85\\u66F4\\u6539\r\n\r\n#XTIT\r\nLR_CANCEL_PENDING=\\u5F85\\u53D6\\u6D88\r\n\r\n#XTIT\r\nLR_CHANGE_DONE=\\u53D8\\u66F4\\u5DF2\\u6279\\u51C6\r\n\r\n#XTIT\r\nLR_CANCEL_DONE=\\u53D6\\u6D88\\u5DF2\\u6279\\u51C6\r\n\r\n#XTIT: Original\r\nLR_OLD_VERSION=\\u539F\\u59CB\r\n\r\n#XTIT: Leave Changes\r\nLR_NEW_VERSION=\\u5DF2\\u66F4\\u6539\r\n\r\n#XFLD: Label for Approver Selection\r\nLR_APPROVER=\\u5BA1\\u6279\\u4EBA\r\n\r\n#XFLD: Label for Attendance/Absence Hours\r\nLR_ABS_HOURS=\\u51FA\\u52E4/\\u7F3A\\u52E4\\u65F6\\u6570\r\n\r\n#XFLD: Label for Attachments\r\nLR_ATTACHMENTS=\\u9644\\u4EF6\r\n\r\n#XFLD: Placeholder for Attachments\r\nLR_ATTACHMENT=\\u6DFB\\u52A0\\u9644\\u4EF6\r\n\r\n#XFLD: Label for Start Time\r\nLR_START_TIME=\\u5F00\\u59CB\\u65F6\\u95F4\r\n\r\n#XFLD: Label for Start Time\r\nLR_END_TIME=\\u7ED3\\u675F\\u65F6\\u95F4\r\n\r\n#YMSG: Error message to display, if the file upload fails\r\nLR_ATTACHMENT_ERROR=\\u65E0\\u6CD5\\u4E0A\\u8F7D\\u9644\\u4EF6\r\n\r\n#YMSG: warning message to show if the file type is not supported\r\nLR_ATTACHMENT_TYPECHECK=\\u4E0D\\u652F\\u6301\\u6B64\\u9644\\u4EF6\\u7C7B\\u578B\r\n\r\n#YMSG: Warning message to show if the file size exceeds 25MB- Mega Bytes\r\nLR_ATTACHMENT_SIZECHECK=\\u6587\\u4EF6\\u592A\\u5927\\u3002\\u8BF7\\u9009\\u62E9\\u5927\\u5C0F\\u5728 25MB \\u4EE5\\u4E0B\\u7684\\u6587\\u4EF6\\u3002\r\n\r\n#XFLD: Select Personnel Assignment Label\r\n\r\n#XTIT: Select Personnel Assignment Title\r\n\r\n',
	"hcm/myleaverequest/utils/CalendarTools.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
jQuery.sap.declare("hcm.myleaverequest.utils.CalendarTools");

hcm.myleaverequest.utils.CalendarTools = (function() {
	var _resourceBundle = null;
	return {
		// The oCache object holds one attribute for each month that has already been read
		// This attribute holds an Object with one array of days for each of the supported day type based on LR status (SENT, POSTED, APPROVED) 
		// plus one array for the day types derived from the workschedule (WEEKEND, PHOLIDAY)
		oCache : {},
		init : function(oresourceBundle) {
			_resourceBundle = oresourceBundle;
		},

		clearCache : function() {
			hcm.myleaverequest.utils.CalendarTools.oCache = {};
		},

		getDayLabelsForMonth : function(oDate, successCallback, errorCallback) {
			// this method reads the leave requests and work schedules for the month oDate is within and also for the previous and next month.
			// the results are evaluated (leave requests with status SENT, POSTED, APPROVED are considered; workschedules with status 1 
			// (WEEKEND) and 2 (PHOLIDAY) are considered)
			// the results are returned and stored in oCache for later use

			// returns day labels for the complete oDate's month

			// successCallback(oDayLabels, oUserData)
			// oDayLabels example:
			//	{
			//		"PHOLIDAY": ["2013-04-30T22:00:00.000Z",
			//			"2013-05-08T22:00:00.000Z",
			//			"2013-05-18T22:00:00.000Z",
			//			"2013-05-19T22:00:00.000Z"],
			//		"SENT": ["2013-05-01T22:00:00.000Z",
			//			"2013-05-06T22:00:00.000Z",
			//			"2013-05-13T22:00:00.000Z",
			//			"2013-05-14T22:00:00.000Z",
			//			"2013-05-15T22:00:00.000Z",
			//			"2013-05-16T22:00:00.000Z",
			//			"2013-05-20T22:00:00.000Z",
			//			"2013-05-21T22:00:00.000Z",
			//			"2013-05-22T22:00:00.000Z",
			//			"2013-05-23T22:00:00.000Z",
			//			"2013-05-25T22:00:00.000Z",
			//			"2013-05-26T22:00:00.000Z"],
			//		"WEEKEND": ["2013-05-03T22:00:00.000Z",
			//			"2013-05-04T22:00:00.000Z",
			//			"2013-05-10T22:00:00.000Z",
			//			"2013-05-11T22:00:00.000Z",
			//			"2013-05-17T22:00:00.000Z",
			//			"2013-05-24T22:00:00.000Z",
			//			"2013-05-25T22:00:00.000Z"],
			//		"POSTED": ["2013-05-28T22:00:00.000Z",
			//			"2013-05-29T22:00:00.000Z"]
			//	}

			// errorCallback(aErrorMessages, oUserData)

			// check if requested results are already in the cache
			var oRequestedMonthStartDate = hcm.myleaverequest.utils.CalendarTools.calcMonthStartDate(oDate); // use the 1st day of the month as key
			var oNextMonthStartDate = hcm.myleaverequest.utils.CalendarTools.calcNextMonthStartDate(oRequestedMonthStartDate);
			var oPreviousMonthStartDate = hcm.myleaverequest.utils.CalendarTools.calcPreviousMonthStartDate(oRequestedMonthStartDate);
	
			// check if work schedule results are already in the cache for 3 months
			var oCachedResult = hcm.myleaverequest.utils.CalendarTools.oCache[oRequestedMonthStartDate];
			var oCachedResultPrevious = hcm.myleaverequest.utils.CalendarTools.oCache[oPreviousMonthStartDate];
			var oCachedResultNext =hcm.myleaverequest.utils.CalendarTools.oCache[oNextMonthStartDate];
			
			var oStartDate = oPreviousMonthStartDate;
			var oEndDate = oNextMonthStartDate;
			
			//return only if all 3 months work schedules exist
			if (! ((oCachedResult === undefined) || (oCachedResultPrevious === undefined) ||( oCachedResultNext === undefined))) {
				successCallback(oCachedResult);
				return;
			}			
			
			//this is for the initial call
			if(oCachedResult === undefined){
				oEndDate = hcm.myleaverequest.utils.CalendarTools.approximateMonthEndDate(oNextMonthStartDate);
			}
			//if previous month doesn't exist
			else if(oCachedResultPrevious === undefined){
				oEndDate = hcm.myleaverequest.utils.CalendarTools.approximateMonthEndDate(oPreviousMonthStartDate);
				oStartDate = new Date(oPreviousMonthStartDate.getFullYear(), oPreviousMonthStartDate.getMonth() - 2, 1);
				oNextMonthStartDate = oPreviousMonthStartDate;
				oPreviousMonthStartDate = oStartDate;
				oRequestedMonthStartDate = new Date(oStartDate.getFullYear(), oStartDate.getMonth() + 1, 1);
			}
			//if next month doesn't exist
			else if(oCachedResultNext === undefined){
				oStartDate = oNextMonthStartDate;
				oEndDate = new Date(oStartDate.getFullYear(), oStartDate.getMonth() + 2, 1);
				oPreviousMonthStartDate = oStartDate;
				oNextMonthStartDate = oEndDate;
				oEndDate = hcm.myleaverequest.utils.CalendarTools.approximateMonthEndDate(oEndDate);
				oRequestedMonthStartDate = new Date(oStartDate.getFullYear(), oStartDate.getMonth() + 1, 1);
			}
			
			var _aLeaveRequests = null;
			var _aWorkSchedules = null;
			var _alreadyFailed = false;

			var fnSuccessCalback = successCallback;
			var fnErrorCallback = errorCallback;

			hcm.myleaverequest.utils.DataManager.getLeaveRequestsForTimePeriod(oStartDate, oEndDate, function(
					aLeaveRequests) {
				if (_alreadyFailed) {
					return;
				}
				_aLeaveRequests = aLeaveRequests;
				if (_aWorkSchedules !== null) {
					hcm.myleaverequest.utils.CalendarTools._finish(oStartDate, oEndDate, oRequestedMonthStartDate,
							oPreviousMonthStartDate, oNextMonthStartDate, _aLeaveRequests, _aWorkSchedules, fnSuccessCalback,
							fnErrorCallback);
				}
			}, function(aErrorMessages) {
				if (_alreadyFailed) {
					return;
				}
				_alreadyFailed = true;
				errorCallback(aErrorMessages);
			});

			hcm.myleaverequest.utils.DataManager.getWorkSchedulesForTimePeriod(oStartDate, oEndDate, function(
					aWorkSchedules) {
				if (_alreadyFailed) {
					return;
				}
				_aWorkSchedules = aWorkSchedules;
				if (_aLeaveRequests !== null) {
					hcm.myleaverequest.utils.CalendarTools._finish(oStartDate, oEndDate, oRequestedMonthStartDate,
							oPreviousMonthStartDate, oNextMonthStartDate, _aLeaveRequests, _aWorkSchedules, fnSuccessCalback,
							fnErrorCallback);
				}
			}, function(aErrorMessages) {
				if (_alreadyFailed) {
					return;
				}
				_alreadyFailed = true;
				errorCallback(aErrorMessages);
			});
		},

		_calcDayLabelsForMonth : function(_aLeaveRequests, _aWorkSchedules, oMonthStartDate, iDayOffset) {
			// This method checks for every day of the moth the Work Schedules staus and the status of leave requests for that day.
			// It returns an object containing one array of date objects for each of the following categories
			// APPROVED, SENT, POSTED, WEEKEND, PHOLIDAY
			// This information is used in S4 to set the colors of the days in the calendar control
			var oResult = {};
			var iMonthDayCount = hcm.myleaverequest.utils.CalendarTools.calcMonthDayCount(oMonthStartDate);
			for ( var iDay = 0; iDay < iMonthDayCount; iDay++) {
				var oDayDate = new Date(oMonthStartDate.getFullYear(), oMonthStartDate.getMonth(), iDay + 1);
				var bLeaveFound = false;
				for ( var iLeave = 0; iLeave < _aLeaveRequests.length; iLeave++) {
					if (_aLeaveRequests[iLeave].StatusCode
							&& (_aLeaveRequests[iLeave].StatusCode === "SENT" || _aLeaveRequests[iLeave].StatusCode === "POSTED" 
								|| _aLeaveRequests[iLeave].StatusCode === "APPROVED" || _aLeaveRequests[iLeave].StatusCode === "REJECTED")) {
						var oStart = hcm.myleaverequest.utils.Formatters.getDate(_aLeaveRequests[iLeave].StartDate);
						var oEnd = hcm.myleaverequest.utils.Formatters.getDate(_aLeaveRequests[iLeave].EndDate);
						oStart = new Date(oStart.getUTCFullYear(), oStart.getUTCMonth(), oStart.getUTCDate(),0,0,0);
						oEnd = new Date(oEnd.getUTCFullYear(), oEnd.getUTCMonth(), oEnd.getUTCDate(),0,0,0);
						if (hcm.myleaverequest.utils.CalendarTools.dayRangeMatch(oDayDate, oStart, oEnd)) {
							if (!oResult[_aLeaveRequests[iLeave].StatusCode]) {
								oResult[_aLeaveRequests[iLeave].StatusCode] = [oDayDate];
							} else {
								oResult[_aLeaveRequests[iLeave].StatusCode].push(oDayDate);
							}
							bLeaveFound = true;
						}
					}
				}
				if (!bLeaveFound && _aWorkSchedules.length > 0 && _aWorkSchedules[0].StatusValues.length > iDayOffset + iDay) {
				    var oDayStatus = (_aWorkSchedules[0].StatusValues[iDayOffset + iDay]).toString();
					if (oDayStatus === "2") {
						if (!oResult.WEEKEND) {
							oResult.WEEKEND = [oDayDate];
						} else {
							oResult.WEEKEND.push(oDayDate);
						}
					} else if (oDayStatus === "1") {
						if (!oResult.PHOLIDAY) {
							oResult.PHOLIDAY = [oDayDate];
						} else {
							oResult.PHOLIDAY.push(oDayDate);
						}
					} else if (oDayStatus === "0") {
						if (!oResult.WORKDAY) {
							oResult.WORKDAY = [oDayDate];
						} else {
							oResult.WORKDAY.push(oDayDate);
						}
					}
				}
			}
			return oResult;
		},

		_finish : function(oStartDate, oEndDate, oRequestedMonthStartDate, oPreviousMonthStartDate, oNextMonthStartDate,
				_aLeaveRequests, _aWorkSchedules, successCallback, errorCallback) {

			var oDayLabels;

			try {
				var iDayOffset = 0;
				if (oStartDate < oRequestedMonthStartDate) {
					hcm.myleaverequest.utils.CalendarTools.oCache[oPreviousMonthStartDate] = this._calcDayLabelsForMonth(_aLeaveRequests, _aWorkSchedules, oPreviousMonthStartDate, 0);
					iDayOffset += hcm.myleaverequest.utils.CalendarTools.calcMonthDayCount(oPreviousMonthStartDate);
				}
				oDayLabels = hcm.myleaverequest.utils.CalendarTools.oCache[oRequestedMonthStartDate] = this._calcDayLabelsForMonth(
				    _aLeaveRequests, _aWorkSchedules, oRequestedMonthStartDate, iDayOffset);
				iDayOffset += hcm.myleaverequest.utils.CalendarTools.calcMonthDayCount(oRequestedMonthStartDate);
				var oRequestedEndDate = hcm.myleaverequest.utils.CalendarTools.approximateMonthEndDate(oRequestedMonthStartDate);
				if (oEndDate > oRequestedEndDate) {
					hcm.myleaverequest.utils.CalendarTools.oCache[oNextMonthStartDate] = this._calcDayLabelsForMonth(
							_aLeaveRequests, _aWorkSchedules, oNextMonthStartDate, iDayOffset);
				}
				//include all three months
				var oDayLabelsPrev = hcm.myleaverequest.utils.CalendarTools.oCache[oPreviousMonthStartDate];
				var oDayLabelsNext = hcm.myleaverequest.utils.CalendarTools.oCache[oNextMonthStartDate];
				
				var statusList = ["SENT", "APPROVED", "POSTED", "REJECTED", "WEEKEND" , "PHOLIDAY", "WORKDAY" ];
				
				for( var i = 0; i < statusList.length; i++){		
					if(!oDayLabels[statusList[i]]){
						oDayLabels[statusList[i]] = [];
					}
					if(oDayLabelsPrev[statusList[i]]){
						for(var j = 0;j < oDayLabelsPrev[statusList[i]].length;j++){
							oDayLabels[statusList[i]].push(oDayLabelsPrev[statusList[i]][j]);
						}
					}
					if(oDayLabelsNext[statusList[i]]){
						if(oDayLabelsNext[statusList[i]]){
							for( var k = 0;k < oDayLabelsNext[statusList[i]].length;k++){
								oDayLabels[statusList[i]].push(oDayLabelsNext[statusList[i]][k]);
							}
						}
					}
				}
			} catch (e) {
				errorCallback([_resourceBundle.getText("LR_CT_PARSE_ERR") + " (CalendarTools.getDayLabelsForMonth)"]);
				return;
			}
			successCallback(oDayLabels);
		},

		calcMonthStartDate : function(oDate) {
			var oMonthStartDate = new Date(oDate.getFullYear(), oDate.getMonth(), 1, 0, 0, 0);
			oMonthStartDate.setMilliseconds(0);
			return oMonthStartDate;
		},

		approximateMonthEndDate : function(oDate) {
			var oEndDate = new Date(oDate.getFullYear(), oDate.getMonth(), 1, 0, 0, 0);
			oEndDate.setDate(oEndDate.getDate() + 31); // a little more does not affect calculations in this scenario
			return oEndDate;
		},

		calcNextMonthStartDate : function(oDate) {
			return new Date(oDate.getFullYear(), oDate.getMonth() + 1, 1);
		},

		calcPreviousMonthStartDate : function(oDate) {
			return new Date(oDate.getFullYear(), oDate.getMonth() - 1, 1);
		},

		calcMonthDayCount : function(oDate) {
			// calculates the number of days of the month containing oDate
			var days = 32 - new Date(oDate.getFullYear(), oDate.getMonth(), 32).getDate();
			if(days < 32 && days > 27){
			    return days;
			}else{
				jQuery.sap.log.warning("Failed to calculate number of days in utils.CalendarTools.calcMonthDayCount with input" + oDate.toString());
				throw "error in calculating number of days in a month.\nFunction:utils.CalendarTools.calcMonthDayCount\nInput: " + oDate.toString() + "\nOutput:"+days;
			}
		},

		dayRangeMatch : function(oDayDate, oStartDate, oEndDate) {
			// is the day described with oDayDate within the range?
			// we calculate with days, therefore we remove the time components, and rely on the fact, that oDayDate does not have one
			var oFixedStart = new Date(oStartDate.getFullYear(), oStartDate.getMonth(), oStartDate.getDate()); // remove time component
			var oFixedEnd = new Date(oEndDate.getFullYear(), oEndDate.getMonth(), oEndDate.getDate()); // remove time component
			if (oFixedStart <= oDayDate && oFixedEnd >= oDayDate){ 
			    return true;
			}
			return false;
		}
	};

}());
},
	"hcm/myleaverequest/utils/ConcurrentEmployment.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.myleaverequest.utils.ConcurrentEmployment");
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
/*global hcm:true */
hcm.myleaverequest.utils.ConcurrentEmployment = {

	getCEEnablement: function(self, successHandler) {
		var that = this;
		if (!that.iAmAlreadyCalled) {
			that.iAmAlreadyCalled = true;
		} else {
			//this is to handle consecutive call when history is refreshed
			that.secondSuccessHandler = successHandler;
			return;
		}

		this.initialize(self, successHandler);
		var oModel = new sap.ui.model.json.JSONModel();
		hcm.myleaverequest.utils.DataManager.getPersonellAssignments(self, function(data) {
			if (data.length > 1) {
				oModel.setData(data);
				self.oCEForm.setModel(oModel);
				self.oCEDialog.open();
			} else {
				self.oApplication.pernr = data[0].Pernr;
				hcm.myleaverequest.utils.UIHelper.setPernr(data[0].Pernr);
				successHandler();
			}
		});
	},
	initialize: function(self, successHandler) {
		var that = this;
		this.setControllerInstance(self);
		var itemTemplate = new sap.m.RadioButton({
			text: "{AssignmentText}",
			//key: "{Pernr}"
			customData: new sap.ui.core.CustomData({
				"key": "Pernr",
				"value": "{Pernr}"
			})
		});
		self.oCESelect = new sap.m.RadioButtonGroup().bindAggregation("buttons", "/", itemTemplate);
		self.oCEForm = new sap.ui.layout.form.Form({
			maxContainerCols: 2,
			class: "sapUiLargeMarginTopBottom",
			layout: new sap.ui.layout.form.ResponsiveGridLayout({
				labelSpanL: 12,
				//emptySpanL: 0,
				labelSpanM: 12,
				//emptySpanM: 2,
				labelSpanS: 12,
				columnsL: 2,
				columnsM: 2
			}),
			formContainers: new sap.ui.layout.form.FormContainer({
				formElements: [
                                       new sap.ui.layout.form.FormElement({
						label: new sap.m.Label({
							text: self.resourceBundle.getText("PERSONAL_ASSIGN")
						}),
						fields: self.oCESelect
					})
                               ]
			})
		});

		self.oCEDialog = new sap.m.Dialog({
			title: self.resourceBundle.getText("PERSONAL_ASSIGN_TITLE"),
			class: "sapUiContentPadding sapUiLargeMarginTopBottom",
			content: self.oCEForm,
			buttons: [
			    new sap.m.Button({
					text: self.resourceBundle.getText("LR_OK"),
					press: function() {
						that.iAmAlreadyCalled = false;
						self.oCEDialog.close();
						self.oCEDialog.Cancelled = false;
						self.oApplication.pernr = self.oCESelect.getSelectedButton().data().Pernr;
						hcm.myleaverequest.utils.UIHelper.setPernr(self.oApplication.pernr);
						successHandler();
						if (that.secondSuccessHandler) {
							that.secondSuccessHandler();
							that.secondSuccessHandler = null;
						}
					}
				}),
			    new sap.m.Button({
					text: self.resourceBundle.getText("LR_CANCEL"),
					press: function() {
						that.iAmAlreadyCalled = false;
						self.oCEDialog.close();
						self.oCEDialog.Cancelled = true;
						/*var oHistory = sap.ui.core.routing.History.getInstance();
                        var sPreviousHash = oHistory.getPreviousHash();
                        //The history contains a previous entry           
                            if (sPreviousHash !== undefined)*/
						/* eslint-disable sap-browser-api-warning */
						window.history.go(-1);
						/* eslint-enable sap-browser-api-warning */
						//}
					}
				})

			]
		});
		self.oCEDialog.attachAfterClose(function() {
			if (!self.oApplication.pernr && !self.oCEDialog.Cancelled) {
				self.oCEDialog.open();
			}
		});
	},
	setControllerInstance: function(me) {
		this.me = me;
	},

	getControllerInstance: function() {
		return this.me;
	}

};
},
	"hcm/myleaverequest/utils/DataManager.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.declare("hcm.myleaverequest.utils.DataManager");
/*global hcm:true */
hcm.myleaverequest.utils.DataManager = (function() {
	var _modelBase = null;
	var _resourceBundle = null;
	var _cachedModelObj = {};
	_cachedModelObj.exist = true;

	return {
		init: function(oDataModel, oresourceBundle) {
			_modelBase = oDataModel;
			_modelBase.setCountSupported(false);
			_resourceBundle = oresourceBundle;
		},

		getBaseODataModel: function() {
			return _modelBase;
		},

		setCachedModelObjProp: function(propName, propObj) {
			_cachedModelObj[propName] = propObj;
		},

		getCachedModelObjProp: function(propName) {
			return _cachedModelObj[propName];
		},

		getApprover: function(successCallback, errorCallback) {
			var sPath = "ApproverCollection";
			var arrParams = ["$select=ApproverEmployeeName,ApproverEmployeeID,ApproverUserID"];
			this._getOData(sPath, null, arrParams, function(objResponse) {
				var sApproverName,approverEmployeeID;
				try {
					var oResult = objResponse.results;
					if (oResult instanceof Array) {
						for (var i = 0; i < oResult.length; i++) {
							sApproverName = oResult[i].ApproverEmployeeName;
							approverEmployeeID = oResult[i].ApproverEmployeeID;
						}
					}
					if (sApproverName === undefined) {
						errorCallback([_resourceBundle.getText("LR_DD_NO_APPROVER") + " (DataManager.getApprover)"]);
						return;
					}
				} catch (e) {
					errorCallback([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getApprover)"]);
					return;
				}
				successCallback(sApproverName,approverEmployeeID);
			}, function(objResponse) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});

		},

		getConfiguration: function() {
			var deferredDefaultType = $.Deferred();
			var sPath = "ConfigurationCollection";
			var arrParams = ['$select=DefaultApproverEmployeeID,DefaultApproverEmployeeName,RecordInClockHoursAllowedInd,RecordInClockTimesAllowedInd'];

			if (!_cachedModelObj.DefaultConfigurations) {
				this._getOData(sPath, null, arrParams, function(objResponse) {
					var oConfiguration;
					try {
						var oResult = objResponse.results;
						if (oResult instanceof Array) {
							oConfiguration = oResult[0];
						}
						if (oConfiguration === undefined) {
							deferredDefaultType.reject(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
							return;
						}
					} catch (e) {
						deferredDefaultType.reject(hcm.myleaverequest.utils.DataManager.parseErrorMessages(e));
						return;
					}
					_cachedModelObj.DefaultConfigurations = oConfiguration;
					//successCallback(oConfiguration);
					deferredDefaultType.resolve(oConfiguration);

				}, function(objResponse) {
					deferredDefaultType.reject(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
				});
			} else {
				deferredDefaultType.resolve(_cachedModelObj.DefaultConfigurations);
			}
			return deferredDefaultType.promise();
		},

		getAbsenceTypeCollection: function() {
			var deferredAbsTypeColl = $.Deferred();
			var sPath = "AbsenceTypeCollection";
			var oParams = ['$select=InfoType,DefaultType,AbsenceTypeName,AbsenceTypeCode,AllowedDurationPartialDayInd,AllowedDurationMultipleDayInd,NoteVisibleInd,ApproverReadOnlyInd,ApproverVisibleInd,AttachmentEnabled,AttachmentMandatory,AttachMaxSize,AttachRestrictFileType,AttachSupportFileType'];
			if (!_cachedModelObj.AbsenceTypeCollection) {
				this._getOData(sPath, null, oParams, function(objResponse) {
					_cachedModelObj.AbsenceTypeCollection = objResponse.results;
					//successCallback(objResponse.results);
					deferredAbsTypeColl.resolve(objResponse.results);
				}, function(objResponse) {
					deferredAbsTypeColl.reject(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
				});
			} else {
				deferredAbsTypeColl.resolve(_cachedModelObj.AbsenceTypeCollection);
			}
			return deferredAbsTypeColl.promise();
		},

		getBalancesForAbsenceType: function(sAbsenceTypeCode, successCallback, errorCallback) {
            var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			var sPath = "AbsenceTypeCollection(EmployeeID='" + oPernr + "',AbsenceTypeCode='" + sAbsenceTypeCode +
				"')/absenceTypeTimeAccount";
			var arrParams = ["$select=BalancePlannedQuantity,BalanceAvailableQuantity,BalanceUsedQuantity,TimeUnitName,TimeAccountTypeName"];

			this._getOData(sPath, null, arrParams, function(objResponse) {
				var sBalancePlanned = null,
					sBalanceAvailable = null,
					sBalanceUsed = null,
					sBalanceTotalUsedQuantity = null;
				var sTimeUnitNamePlanned = null,
					sTimeUnitNameAvailable = null,
					sTimeAccountTypeName = null;
				var iBalancePlanned = null,
					iBalanceAvailable = null,
					iBalanceUsed = null;
				var doValuesExist = false; //used to hide balances in the view
				try {
					var oResult = objResponse.results;
					if (oResult instanceof Array && oResult.length > 0) {
						doValuesExist = true;
						sTimeUnitNamePlanned = oResult[0].TimeUnitName;
						sTimeUnitNameAvailable = oResult[0].TimeUnitName;
						sTimeAccountTypeName = oResult[0].TimeAccountTypeName;
						for (var i = 0; i < oResult.length; i++) {
							iBalancePlanned += parseFloat(oResult[i].BalancePlannedQuantity);
							iBalanceAvailable += parseFloat(oResult[i].BalanceAvailableQuantity);
							iBalanceUsed += parseFloat(oResult[i].BalanceUsedQuantity);
						}
						sBalancePlanned = hcm.myleaverequest.utils.Formatters.BALANCE(iBalancePlanned.toString());
						sBalanceAvailable = hcm.myleaverequest.utils.Formatters.BALANCE(iBalanceAvailable.toString());
						sBalanceUsed = hcm.myleaverequest.utils.Formatters.BALANCE(iBalanceUsed.toString());
						sBalanceTotalUsedQuantity = hcm.myleaverequest.utils.Formatters.BALANCE((iBalanceUsed + iBalancePlanned).toString());
					}
				} catch (e) {
					errorCallback([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getBalancesForAbsenceType)"]);
					return;
				}
				successCallback(sBalancePlanned, sTimeUnitNamePlanned, sBalanceAvailable, sTimeUnitNameAvailable,
					sTimeAccountTypeName, sBalanceUsed, sBalanceTotalUsedQuantity, doValuesExist);
			}, function(objResponse) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});
		},

		getPendingLeaves: function(successCallback, errorCallback) {

			this.getConsolidatedLeaveRequests(function(sPendingLeaves) {
				var aLeaveRequests = sPendingLeaves.LeaveRequestCollection;
				var iPendingLeaves = 0;
				for (var i = 0; i < aLeaveRequests.length; i++) {
					if (aLeaveRequests[i].StatusCode === "SENT") {
						iPendingLeaves++;
					} else if (aLeaveRequests[i].aRelatedRequests !== undefined && aLeaveRequests[i].aRelatedRequests.length > 0) {
						if (aLeaveRequests[i].aRelatedRequests[0].StatusCode === "SENT") {
							iPendingLeaves++;
						}
					}
				}
				successCallback(iPendingLeaves + "");
			}, errorCallback);
		},

		getConsolidatedLeaveRequests: function(successCallback, errorCallback) {
			var sPath = "LeaveRequestCollection";
			var oParams = [
				'$select=ApproverEmployeeID,ApproverEmployeeName,EmployeeID,RequestID,ChangeStateID,LeaveKey,ActionCode,StatusCode,StatusName,AbsenceTypeCode,AbsenceTypeName,InfoType,StartDate,StartTime,EndDate,EndTime,WorkingHoursDuration,WorkingDaysDuration,Notes,ActionDeleteInd,ActionModifyInd,LeaveRequestType,AttachmentDetails'
				];
            var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
            oParams.push("$filter=EmployeeID eq '" + oPernr + "'");
			this._getOData(sPath, null, oParams, function(objResponse) {
				var aLeaveRequests = [];
				try {
					var oResult = objResponse.results;
					if (!oResult instanceof Array) {
						errorCallback([_resourceBundle.getText("LR_DD_NO_CFG") + " (DataManager.getConsolidatedLeaveRequests)"]);
						return;
					}
					var oRelatedRequestsByLeaveKey = {}; // object of arrays
					for (var i = 0; i < oResult.length; i++) {
						if ((oResult[i].LeaveRequestType === "2" || oResult[i].LeaveRequestType === "3") && oResult[i].LeaveKey) {
							if (!oRelatedRequestsByLeaveKey[oResult[i].LeaveKey]) {
								oRelatedRequestsByLeaveKey[oResult[i].LeaveKey] = [];
							}
							oRelatedRequestsByLeaveKey[oResult[i].LeaveKey].push(oResult[i]);
						}
					}
					for (var i = 0; i < oResult.length; i++) {
						if (oResult[i].LeaveRequestType !== "2" && oResult[i].LeaveRequestType !== "3") {
							if (oResult[i].LeaveKey && oRelatedRequestsByLeaveKey[oResult[i].LeaveKey]) {
								oResult[i].aRelatedRequests = oRelatedRequestsByLeaveKey[oResult[i].LeaveKey];
								for (var j = 0; j < oResult[i].aRelatedRequests.length; j++) {
									oResult[i].Notes = oResult[i].aRelatedRequests[j].Notes + oResult[i].Notes;
								}
							}
							aLeaveRequests.push(oResult[i]);
						}
					}
				} catch (e) {
					errorCallback([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getConsolidatedLeaveRequests)"]);
					return;
				}
				successCallback({
					LeaveRequestCollection: aLeaveRequests
				});
			}, function(objResponse) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});
		},

		getTimeAccountCollection: function(successCallback, errorCallback) {

			var sPath = "TimeAccountCollection";
			this._getOData(sPath, null, null, function(objResponse) {
				var aTimeAccounts = [];
				try {
					// var oResult = this.getTimeAccountCollectionDataFromXml(this.parseXml(sResponse));
					var oResult = objResponse.results;
					if (!oResult instanceof Array) {
						errorCallback([_resourceBundle.getText("LR_DD_NO_CFG") + " (DataManager.getTimeAccountCollection)"]);
						return;
					}
					for (var i = 0; i < oResult.length; i++) {
						delete oResult[i]['__metadata'];
						aTimeAccounts.push(oResult[i]);
					}
				} catch (e) {
					errorCallback([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getTimeAccountCollection)"]);
					return;
				}
				successCallback({
					TimeAccountCollection: aTimeAccounts
				});
			}, function(objResponse) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});
		},

		submitLeaveRequest: function(oNewEntry, bProcessCheckOnlyInd, successCallback, errorCallback, uploadFileAttachments) {
			oNewEntry.ProcessCheckOnlyInd = (bProcessCheckOnlyInd ? true : false);
			this._postOData("LeaveRequestCollection", oNewEntry, function(objResponseData, objResponse) {
				var objMsg = "";
				if (objResponse.headers["sap-message"]) {
					objMsg = JSON.parse(objResponse.headers["sap-message"]);
				}
				if(!objResponseData.RequestID){
				    var msg = objMsg || _resourceBundle.getText("LR_DD_GENERIC_ERR");
				    hcm.myleaverequest.utils.UIHelper.errorDialog(msg);
				}else{
				hcm.myleaverequest.utils.UIHelper.setIsChangeAction(true);
				if(uploadFileAttachments){
				uploadFileAttachments(successCallback,objResponseData, objMsg);
				}}
				
			}, function(objResponseData) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponseData));
			});
		},

		changeLeaveRequest: function(oModifiedEntry, bProcessCheckOnlyInd, successCallback, errorCallback, uploadFileAttachments) {
			oModifiedEntry.ProcessCheckOnlyInd = (bProcessCheckOnlyInd ? true : false);
			var _this = this;
			this._postOData("LeaveRequestCollection", oModifiedEntry, function(objResponseData, objResponse) {
				var objMsg = "";
				if (objResponse.headers["sap-message"]) {
					objMsg = JSON.parse(objResponse.headers["sap-message"]);
				}
				if(!objResponseData.RequestID){
				    var msg = objMsg || _resourceBundle.getText("LR_DD_GENERIC_ERR");
				    hcm.myleaverequest.utils.UIHelper.errorDialog(msg);
				}else{
				hcm.myleaverequest.utils.UIHelper.setIsChangeAction(true);
				if(uploadFileAttachments){
				uploadFileAttachments(successCallback,objResponseData, objMsg);
				}}
			}, function(objResponseData) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponseData));
			});
		},

		withdrawLeaveRequest: function(sStatusCode, sEmployeeId, sRequestId, sChangeStateId, sLeaveKey, successCallback,
			errorCallback) {
            this.recallLeaveRequest(sEmployeeId, sRequestId, sChangeStateId, sLeaveKey, successCallback, errorCallback);
			/*if (this.isRecallableLeaveRequest(sStatusCode, sLeaveKey)) {
				this.recallLeaveRequest(sEmployeeId, sRequestId, sChangeStateId, sLeaveKey, successCallback, errorCallback);
			} else {
				this.createDeleteLeaveRequest(sEmployeeId, sRequestId, sChangeStateId, sLeaveKey, successCallback,
					errorCallback);
			}*/
		},

		getLeaveRequestsForTimePeriod: function(oStartDate, oEndDate, successCallback, errorCallback) {

			// aLeaveRequests example:
			// [{
			// "StatusCode": "REJECTED",
			// "StatusName": "Abgelehnt",
			// "AbsenceTypeCode": "0148",
			// "AbsenceTypeName": "Krankheit",
			// "StartDate": Date,
			// "StartTime": "PT00H00M00S",
			// "EndDate": Date,
			// "EndTime": "PT00H00M00S",
			// },
			// {
			// "StatusCode": "REJECTED",
			// "StatusName": "Abgelehnt",
			// "AbsenceTypeCode": "0148",
			// "AbsenceTypeName": "Krankheit",
			// "StartDate": Date,
			// "StartTime": "PT00H00M00S",
			// "EndDate": Date,
			// "EndTime": "PT00H00M00S",
			// }]

			// GET
			// /sap/opu/odata/GBHCM/LEAVEREQUEST;v=2/LeaveRequestCollection?$format=json&$filter=StartDate%20eq%20datetime'2013-01-01T00%3A00%3A00'
			// HTTP/1.1

			var sStartDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(oStartDate) + 'T00:00:00';
			var sEndDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(oEndDate) + 'T00:00:00';
			var sPath = "LeaveRequestCollection";
            var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			var arrParams = ["$filter=StartDate eq datetime'" + sStartDate + "' and EndDate eq datetime'" + sEndDate + "' and EmployeeID eq '" + oPernr + "'",
					"$select=StatusCode,StatusName,AbsenceTypeCode,AbsenceTypeName,StartDate,StartTime,EndDate,EndTime"];
            
			this._getOData(sPath, null, arrParams, function(objResponse) {
				var aLeaveRequests = [];
				try {
					var oResult = objResponse.results;

					if (oResult instanceof Array) {
						for (var i = 0; i < oResult.length; i++) {
							var oRequest = new Object();
							oRequest.StatusCode = oResult[i].StatusCode;
							oRequest.StatusName = oResult[i].StatusName;
							oRequest.AbsenceTypeCode = oResult[i].AbsenceTypeCode;
							oRequest.AbsenceTypeName = oResult[i].AbsenceTypeName;
							oRequest.StartDate = oResult[i].StartDate;
							oRequest.StartTime = oResult[i].StartTime;
							oRequest.EndDate = oResult[i].EndDate;
							oRequest.EndTime = oResult[i].EndTime;
							aLeaveRequests.push(oRequest);
						}
					}
				} catch (e) {
					errorCallback([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getLeaveRequestsForTimePeriod)"]);
					return;
				}
				successCallback(aLeaveRequests);
			}, function(objResponse) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});
		},

		getWorkSchedulesForTimePeriod: function(oStartDate, oEndDate, successCallback, errorCallback) {

			// aWorkSchedules example:
			// [{
			// "StartDate": Date,
			// "EndDate": Date,
			// "StatusValues": "222000000220200222200000",
			// },
			// {
			// "StartDate": Date,
			// "EndDate": Date,
			// "StatusValues": "222000000220200222200000",
			// }]

			// GET
			// /sap/opu/odata/GBHCM/LEAVEREQUEST;v=2/WorkScheduleCollection?$format=json&$filter=StartDate%20eq%20datetime'2013-3-1T00%3A00'and%20EndDate%20eq%20datetime'2013-5-31T00%3A00'
			// HTTP/1.1

			var sStartDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(oStartDate) + 'T00:00:00';
			var sEndDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(oEndDate) + 'T00:00:00';
			var sPath = "WorkScheduleCollection";
            var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			var arrParams = ["$filter=StartDate eq datetime'" + sStartDate + "' and EndDate eq datetime'" + sEndDate + "' and EmployeeID eq '" + oPernr + "'",
				"$select=EmployeeID,StartDate,EndDate,StatusValues"];

			this._getOData(sPath, null, arrParams, function(objResponse) {
				var aWorkSchedules = [];
				try {
					// var oResult = this.getWorkScheduleCollectionDataFromXml(this.parseXml(sResponse));
					var oResult = objResponse.results;
					if (oResult instanceof Array) {
						for (var i = 0; i < oResult.length; i++) {
							var oSchedule = new Object();
							oSchedule.StartDate = oResult[i].StartDate;
							oSchedule.EndDate = oResult[i].EndDate;
							oSchedule.StatusValues = oResult[i].StatusValues;
							aWorkSchedules.push(oSchedule);
						}
					}
				} catch (e) {
					errorCallback([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getWorkSchedulesForTimePeriod)"]);
					return;
				}
				successCallback(aWorkSchedules);
			}, function(objResponse) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});
		},

		// =======
		// private
		// =======

		isRecallableLeaveRequest: function(sStatusCode, sLeaveKey) {
			if (sStatusCode === "CREATED"){
				return true;
			}
			if (!sLeaveKey){
				return true;
			}
			for (var i = 0; i < sLeaveKey.length; i++) {
				var c = sLeaveKey.charAt(i);
				if (c !== " " && c !== "\t" && c !== "\v" && c !== "\r" && c !== "\n" && c !== "0")
				{
				    	return false;
				}
			}
			return true;
		},

		createDeleteLeaveRequest: function(sEmployeeId, sRequestId, sChangeStateId, sLeaveKey, successCallback,
			errorCallback) {

			var sBody = {};
			sBody.ActionCode = 03;
			sBody.EmployeeID = sEmployeeId;
			sBody.RequestID = sRequestId;
			sBody.ChangeStateID = sChangeStateId;
			sBody.LeaveKey = sLeaveKey;
			sBody.ProcessCheckOnlyInd = false;

			this._postOData("LeaveRequestCollection", sBody, function(objResponseData, objResponse) {
				var objMsg = "";
				if (objResponse.headers["sap-message"]) {
					objMsg = JSON.parse(objResponse.headers["sap-message"]);
				}
				successCallback(objResponseData, objMsg);
			}, function(objResponseData) {
				errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponseData));
			});
		},

		recallLeaveRequest: function(sEmployeeId, sRequestId, sChangeStateId, sLeaveKey, successCallback, errorCallback) {
			this._deleteOData("LeaveRequestCollection(EmployeeID='" + sEmployeeId + "',RequestID='" + sRequestId + "',ChangeStateID=" +
				sChangeStateId + ",LeaveKey='" + sLeaveKey + "')", function(objResponse) {
					successCallback(objResponse);
				}, function(objResponse) {
					errorCallback(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
				});
		},

		parseErrorMessages: function(objResponse) {
			if (objResponse.response && objResponse.response.body) {
				var dynamicSort = function(property) {
					var sortOrder = 1;
					if (property[0] === "-") {
						sortOrder = -1;
						property = property.substr(1);
					}
					return function(a, b) {
						var result;
						if (a[property] < b[property]) {
							result = -1;
						} else if (a[property] > b[property]) {
							result = 1;
						} else {
							result = 0;
						}
						return result * sortOrder;
					};
				};
				try {
					var oResponse = JSON.parse(objResponse.response.body);
					if (oResponse.error && oResponse.error.message && oResponse.error.message.value) {
						var result = [];
						result.push(oResponse.error.message.value);
						if (oResponse.error.innererror && oResponse.error.innererror.errordetails && oResponse.error.innererror.errordetails instanceof Array) {
							oResponse.error.innererror.errordetails.sort(dynamicSort("severity"));
							for (var i = 0; i < oResponse.error.innererror.errordetails.length; i++) {
								if (oResponse.error.innererror.errordetails[i].message) {
									var message = oResponse.error.innererror.errordetails[i].message;
									/*if (oResponse.error.innererror.errordetails[i].code) {
										message += " [" + oResponse.error.innererror.errordetails[i].code + "]";
									}*/
									if (oResponse.error.innererror.errordetails[i].severity) {
										message += " (" + oResponse.error.innererror.errordetails[i].severity + ")";
									}
									result.push(message);
								}
							}
						}
						return result;
					}
				} catch (e) {
					jQuery.sap.log.warning("couldn't parse error message", ["parseErrorMessages"], ["DataManger"]);
				}
			} else {
				return [_resourceBundle.getText("LR_DD_GENERIC_ERR") + objResponse.message];
			}
		},

		getXmlNodeValue: function(oNode) {

			try {
				if (oNode.childNodes.length !== 1)
					return null;
				switch (oNode.childNodes[0].nodeType) {
					case 3:
						return oNode.childNodes[0].data;
				}
			} catch (e) {
				return null;
			}
		},

		getDateFromString: function(sValue) {

			// creates a date from yyyy-mm-ddTHH:MM:SS without timezone shift
			if (sValue.length !== 19){
				return null;
			}
			if (sValue.charAt(4) !== '-' || sValue.charAt(7) !== '-' || sValue.charAt(10) !== 'T' || sValue.charAt(13) !== ':' || sValue.charAt(16) !==	':'){
				return null;
				}
			var year = sValue.substring(0, 4) * 1;
			var month = sValue.substring(5, 7) * 1;
			var day = sValue.substring(8, 10) * 1;
			var hour = sValue.substring(11, 13) * 1;
			var minute = sValue.substring(14, 16) * 1;
			var second = sValue.substring(17, 19) * 1;
			return new Date(year, month - 1, day, hour, minute, second);
		},

        searchApprover: function(searchString, successCallback){
            var sPath = "ApproverCollection";
            var searchPernr ='';
            if(!isNaN(searchString)){
                searchPernr = searchString;
            }
            searchString = encodeURIComponent(searchString);
			var arrParams = ["$filter=ApproverEmployeeName eq '" + searchString + "' and ApproverEmployeeID eq '" + searchPernr + "'"];
			this._getOData(sPath, null, arrParams, function(objResponse) {
				try {
					var oResult = objResponse.results;
					if (oResult instanceof Array) {
							successCallback(objResponse);
					}
				} catch (e) {
					hcm.myleaverequest.utils.DataManager.parseErrorMessages([_resourceBundle.getText("LR_DD_PARSE_ERR") + " (DataManager.getApprover)"]);
					 sap.ca.ui.utils.busydialog.releaseBusyDialog();
					return;
				}
			}, function(objResponse) {
			    sap.ca.ui.utils.busydialog.releaseBusyDialog();
			    hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse);
			});
        },
        getPersonellAssignments : function(appController, fSuccess) {
                        this._getOData("/ConcurrentEmploymentSet", null, [], function(oData) {
									fSuccess(oData.results);
								},
								function(oError) {
									hcm.myleaverequest.utils.DataManager.parseErrorMessages(oError);
								});
		},
		_getOData: function(sPath, oContext, oUrlParams, successCallback, errorCallback) {
            if(sPath === "AbsenceTypeCollection" || sPath === "ConfigurationCollection" || sPath === "TimeAccountCollection"){
                var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
                oUrlParams = oUrlParams ? oUrlParams : [];
                oUrlParams.push("$filter=EmployeeID eq '" + oPernr + "'");
            }
			_modelBase.read(sPath, oContext, oUrlParams, true, function(response) {
				successCallback(response);
			}, function(response) {
				errorCallback(response);
			});

		},

		_postOData: function(sPath, sBody, successCallback, errorCallback) {
			_modelBase.create(sPath, sBody, null, successCallback, errorCallback);
		},

		_deleteOData: function(sPath, successCallback, errorCallback) {

			var oParameters = {};
			oParameters.fnSuccess = successCallback;
			oParameters.fnError = errorCallback;
			_modelBase.remove(sPath, oParameters);
		},
		Xml2Json: function (node) {
            var data = {}, that = this;
            // append a value
            var Add = function (name, value) {
                if (data[name]) {
                    if (data[name].constructor !== Array) {
                        data[name] = [data[name]];
                    }
                    data[name][data[name].length] = value;
                } else {
                    data[name] = value;
                }
            };
            // element attributes
            var c, cn;
            for (c = 0;c < node.attributes.length ; c++) {
                cn = node.attributes[c];
                Add(cn.name, cn.value);
            }
            // child elements
            for (c = 0; c < node.childNodes.length; c++) {
                cn = node.childNodes[c];
                if (cn.nodeType === 1) {
                    if (cn.childNodes.length === 1 && cn.firstChild.nodeType === 3) {
                        // text value
                        Add(cn.nodeName, cn.firstChild.nodeValue);
                    } else {
                        // sub-object
                        Add(cn.nodeName, that.Xml2Json(cn));
                    }
                }
            }
            return data;
    }

	};

}());
},
	"hcm/myleaverequest/utils/Formatters.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.declare("hcm.myleaverequest.utils.Formatters");
/*global hcm:true*/
hcm.myleaverequest.utils.Formatters = (function() {
	return {
		init: function(resourseBundle) {
			this.resourceBundle = resourseBundle;
		},

		getDate: function(oValue) {
			var oDate;
			if (oValue instanceof Date) {
				oDate = oValue;
			} else {
				if (typeof oValue !== "string" && !(oValue instanceof String)) {
					return null;
				}
				if (oValue.length < 8) {
					return null;
				}
				if (oValue.substring(0, 6) !== "/Date(" || oValue.substring(oValue.length - 2, oValue.length) !== ")/") {
					return null;
				}
				var dateValue = oValue.substring(6, 6 + oValue.length - 8);
				oDate = new Date();
				oDate.setTime(dateValue * 1);
			}

			return oDate;
		},

		stripDecimals: function(sNumber) {
			while (sNumber.length > 0 && sNumber.charAt(0) === "0") {
				sNumber = sNumber.substring(1, 1 + sNumber.length - 1);
			}
			var pos = sNumber.indexOf(".");
			if (pos < 0) {
				if (sNumber.length < 1) {
					return "0";
				}
				return sNumber;
			}
			while (sNumber.charAt(sNumber.length - 1) === "0") {
				sNumber = sNumber.substring(0, sNumber.length - 1);
			}
			if (sNumber.charAt(sNumber.length - 1) === ".") {
				sNumber = sNumber.substring(0, sNumber.length - 1);
			}
			if (sNumber.length < 1) {
				return "0";
			}
			if (sNumber.length > 0 && sNumber.charAt(0) === ".") {
				return "0" + sNumber;
			}
			return sNumber;
		},

		adjustSeparator: function(number) {
			try {
				if (!isNaN(parseFloat(number)) && isFinite(number)) {
					var numberFormatter = sap.ca.ui.model.format.NumberFormat
						.getInstance();
					if (number.indexOf(".") > 0) {
						numberFormatter.oFormatOptions.decimals = 2;
					}
					return numberFormatter.format(number);
				}
			} catch (e) {}
			return "";
		},

		// format date MMMyyyy
		DATE_ODATA_MMMyyyy: function(oValue) {

			var oDate = hcm.myleaverequest.utils.Formatters.getDate(oValue);
			if (oDate !== null) {
				var oDateFormat = sap.ca.ui.model.format.DateFormat
					.getInstance({
						pattern: "MMM yyyy"
					});
				return oDateFormat.format(oDate, true);
			} else {
				return null;
			}
		},

		// format date EEEdMMMyyyy
		DATE_ODATA_EEEdMMMyyyy: function(oValue, sStyle) {
			var oDate = hcm.myleaverequest.utils.Formatters.getDate(oValue);
			var oDateFormat;
			if (oDate !== null) {
				if (sStyle) {
					oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
							style: sStyle
						});
					return oDateFormat.format(oDate, true);
				} else {
					if (sap.ui.Device.system.phone === true) {
						oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
								style: "medium"
							});
						return oDateFormat.format(oDate, true);
					} else {
						oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
								style: "medium"
							});
						return oDateFormat.format(oDate, true);
					}
				}
			} else {
				return null;
			}
		},

		// format date EEEdMMMyyyy
		DATE_ODATA_EEEdMMMyyyyLong: function(oValue, sStyle) {

			var oDate = hcm.myleaverequest.utils.Formatters.getDate(oValue);
			var oDateFormat;
			if (oDate !== null) {
				if (sStyle) {
					oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
							style: sStyle
						});
					return oDateFormat.format(oDate, true);
				} else {
					if (sap.ui.Device.system.phone === true) {
						oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
								style: "long"
							});
						return oDateFormat.format(oDate, true);
					} else {
						oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
								style: "full"
							});
						return oDateFormat.format(oDate, true);
					}
				}
			} else {
				return null;
			}
		},

		// format date ddMMMyyyy
		DATE_ODATA_ddMMMyyyy: function(oValue) {
			var oDate = hcm.myleaverequest.utils.Formatters.getDate(oValue);

			if (oDate !== null) {
				var oDateFormat = sap.ca.ui.model.format.DateFormat
					.getInstance({
						pattern: "dd.MM.yyyy"
					});
				return oDateFormat.format(oDate, true);
			} else {
				return null;
			}
		},

		// format date YYYYMMdd
		DATE_YYYYMMdd: function(oDate) {

			if (oDate === undefined)
				return "";

			var oDateFormat = sap.ca.ui.model.format.DateFormat.getInstance({
				pattern: "YYYY-MM-dd"
			});

			return oDateFormat.format(oDate);
		},

		BALANCE: function(oValue) {

			if (oValue === undefined)
				return "";

			if (typeof oValue !== 'string' && !(oValue instanceof String))
				return "";

			return hcm.myleaverequest.utils.Formatters
				.adjustSeparator(hcm.myleaverequest.utils.Formatters
					.stripDecimals(oValue));
		},

		//return duration Hours in 00:00 format 
		DURATION_FORMAT: function(sHours) {
			if (sHours.indexOf(".") > -1) {
				var duration = sHours.split(".");
				var hours = duration[0].toString();
				if (parseInt(duration[1]) < 10) duration[1] = parseInt(duration[1]) * 10;
				var minutes = (parseInt(duration[1]) * 60) / 100;
				minutes = Math.round(minutes);
				minutes = minutes.toString();
				if (minutes < 10) minutes = "0" + minutes;
				return hours + ":" + minutes;
			} else
				return sHours + ":00";

		},

		// return duration days or hours depending on input
		DURATION: function(sDays, sHours) {

			if (sDays === undefined || sHours === undefined)
				return "";

			sDays = hcm.myleaverequest.utils.Formatters
				.stripDecimals(sDays);
            if(sDays){
			var pos = sDays.indexOf(".");
			if (pos < 0)
				return hcm.myleaverequest.utils.Formatters.adjustSeparator(sDays);
            }
			return hcm.myleaverequest.utils.Formatters.DURATION_FORMAT(hcm.myleaverequest.utils.Formatters.stripDecimals(sHours));
		},

		// determine duration unit based on leave time range
		DURATION_UNIT: function(sDays, sHours) {

			if (sDays === undefined || sHours === undefined)
				return "";

			sDays = hcm.myleaverequest.utils.Formatters
				.stripDecimals(sDays);
            if(sDays){
                var pos = sDays.indexOf(".");
			if (pos < 0)
				return (sDays * 1 !== 1) ? hcm.myleaverequest.utils.Formatters.resourceBundle
					.getText("LR_DAYS") : hcm.myleaverequest.utils.Formatters.resourceBundle
					.getText("LR_DAY");
            }
			return (sHours * 1 !== 1) ? hcm.myleaverequest.utils.Formatters.resourceBundle
				.getText("LR_HOURS") : hcm.myleaverequest.utils.Formatters.resourceBundle.getText("LR_HOUR");
		},

		// check leave time range whether below 1 day
		isHalfDayLeave: function(sDays) {

			if (sDays === undefined)
				return false;

			sDays = hcm.myleaverequest.utils.Formatters
				.stripDecimals(sDays);

			var pos = sDays.indexOf(".");
			if (pos < 0)
				return false;

			return true;
		},

		// time formatter
		TIME_hhmm: function(oValue) {

			if (oValue === undefined)
				return "";

			var oDate;

			if (oValue instanceof Date) {
				oDate = oValue;
			} else if (oValue.ms) {
				var hours = (oValue.ms / (3600 * 1000)) | 0;
				var minutes = ((oValue.ms - (hours * 3600 * 1000)) / (60 * 1000)) | 0;
				var seconds = ((oValue.ms - (hours * 3600 * 1000) - (minutes * 60 * 1000)) / 1000) | 0;
				oDate = new Date();
				oDate.setHours(hours, minutes, seconds, 0);
			} else {
				if (typeof oValue !== 'string' && !(oValue instanceof String))
					return "";
				if (oValue.length !== 6)
					return "";
				var hours = oValue.substring(0, 2) * 1;
				var minutes = oValue.substring(2, 4) * 1;
				var seconds = oValue.substring(4, 6) * 1;
				oDate = new Date();
				oDate.setHours(hours, minutes, seconds, 0);
			}

			var oDateFormat = sap.ca.ui.model.format.DateFormat
				.getTimeInstance({
					style: "short"
				});
			var sTime = oDateFormat.format(oDate);
			var aTimeSegments = sTime.split(":");
			var sAmPm = "";
			var lastSeg = aTimeSegments[aTimeSegments.length - 1];

			// chop off seconds
			// check for am/pm at the end
			if (isNaN(lastSeg)) {
				var aAmPm = lastSeg.split(" ");
				// result array can only have 2 entries
				aTimeSegments[aTimeSegments.length - 1] = aAmPm[0];
				sAmPm = " " + aAmPm[1];
			}
			return (aTimeSegments[0] + ":" + aTimeSegments[1] + sAmPm);

		},

		// format date and time in format EEEdMMMyyyy
		FORMAT_DATETIME: function(sPrefix, oValue) {

			return sPrefix + " " + hcm.myleaverequest.utils.Formatters
				.DATE_ODATA_EEEdMMMyyyy(oValue);
		},

		// history view date and label formatters: related dates are the ones
		// from an original leave request
		// where a change request has been submitted

		// header label indicating cancel or change request pending
		FORMATTER_INTRO: function(aRelatedRequests) {
			if (!aRelatedRequests || aRelatedRequests.length < 1) {
				return "";
			}
			var sLeaveRequestType = aRelatedRequests[0].LeaveRequestType;
			var sStatusCode = aRelatedRequests[0].StatusCode;
			if (sLeaveRequestType && sLeaveRequestType.toString() === "2") {
				if (sStatusCode === "SENT") {
					return hcm.myleaverequest.utils.Formatters.resourceBundle
						.getText("LR_CHANGE_PENDING");
				}
				if (sStatusCode === "APPROVED") {
					return hcm.myleaverequest.utils.Formatters.resourceBundle
						.getText("LR_CHANGE_DONE");
				}
			}
			if (sLeaveRequestType && sLeaveRequestType.toString() === "3") {
				if (sStatusCode === "SENT") {
					return hcm.myleaverequest.utils.Formatters.resourceBundle
						.getText("LR_CANCEL_PENDING");
				}
				if (sStatusCode === "APPROVED") {
					return hcm.myleaverequest.utils.Formatters.resourceBundle
						.getText("LR_CANCEL_DONE");
				}
			}
			return "";
		},

		// format end date
		FORMAT_ENDDATE: function(sHyphen, sWorkingDaysDuration, sStartTime,
			sEndDate, sEndTime) {
			try {
				if (sHyphen && sWorkingDaysDuration && sStartTime && sEndDate && sEndTime) {
					if (hcm.myleaverequest.utils.Formatters
						.isHalfDayLeave(sWorkingDaysDuration)) {
						return hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(sStartTime) + " " + sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(sEndTime);
					} else if (sWorkingDaysDuration * 1 !== 1) {
						return sHyphen + " " + hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(sEndDate);
					}
				}
			} catch (e) {
				// ignore
			}
			return "";
		},

		// format end date
		FORMAT_ENDDATE_LONG: function(sHyphen, sWorkingDaysDuration, sStartTime,
			sEndDate, sEndTime) {
			try {
				if (sHyphen && sWorkingDaysDuration && sStartTime && sEndDate && sEndTime) {
					if (hcm.myleaverequest.utils.Formatters
						.isHalfDayLeave(sWorkingDaysDuration)) {
						return hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(sStartTime) + " " + sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(sEndTime);
					} else if (sWorkingDaysDuration * 1 != 1) {
						return sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.DATE_ODATA_EEEdMMMyyyyLong(sEndDate);
					}
				}
			} catch (e) {
				// ignore
			}
			return "";
		},

		// visibility setter for original/changed date range labels
		SET_RELATED_VISIBILITY: function(aRelatedRequests) {
			return aRelatedRequests !== undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2";
		},

		SET_RELATED_START_DATE_VISIBILITY: function(aRelatedRequests) {
			return aRelatedRequests !== undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2" && aRelatedRequests[
				0].StartDate != undefined;
		},

		// format related start date
		FORMAT_RELATED_START_DATE: function(aRelatedRequests) {
			if (aRelatedRequests !== undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2" && aRelatedRequests[0].StartDate !=
				undefined) {
				try {
					return hcm.myleaverequest.utils.Formatters
						.DATE_ODATA_EEEdMMMyyyy(aRelatedRequests[0].StartDate);
				} catch (e) {}
			}
			return "";
		},

		FORMAT_RELATED_START_DATE_LONG: function(aRelatedRequests) {
			if (aRelatedRequests !== undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2" && aRelatedRequests[0].StartDate !=
				undefined) {
				try {
					return hcm.myleaverequest.utils.Formatters
						.DATE_ODATA_EEEdMMMyyyyLong(aRelatedRequests[0].StartDate);
				} catch (e) {}
			}
			return "";
		},

		// set related end date from change request visible if available
		SET_RELATED_END_DATE_VISIBILITY: function(aRelatedRequests) {
			return aRelatedRequests != undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2" && aRelatedRequests[
					0].WorkingDaysDuration != undefined && aRelatedRequests[0].StartDate != undefined && aRelatedRequests[0].EndDate != undefined && !
				aRelatedRequests[0].EndTime != undefined && (hcm.myleaverequest.utils.Formatters
					.isHalfDayLeave(aRelatedRequests[0].WorkingDaysDuration) || aRelatedRequests[0].WorkingDaysDuration * 1 != 1);
		},

		// format related end date
		FORMAT_RELATED_END_DATE: function(sHyphen, aRelatedRequests) {
			if (aRelatedRequests != undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2" && aRelatedRequests[0].WorkingDaysDuration !=
				undefined && aRelatedRequests[0].StartDate != undefined && aRelatedRequests[0].EndDate != undefined && !aRelatedRequests[0].EndTime !=
				undefined) {
				try {
					if (hcm.myleaverequest.utils.Formatters
						.isHalfDayLeave(aRelatedRequests[0].WorkingDaysDuration)) {
						return hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(aRelatedRequests[0].StartTime) + " " + sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(aRelatedRequests[0].EndTime);
					}
					if (aRelatedRequests[0].WorkingDaysDuration * 1 != 1) {
						return sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.DATE_ODATA_EEEdMMMyyyy(aRelatedRequests[0].EndDate);
					}
				} catch (e) {}
			}
			return "";
		},

		FORMAT_RELATED_END_DATE_LONG: function(sHyphen, aRelatedRequests) {
			if (aRelatedRequests != undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2" && aRelatedRequests[0].WorkingDaysDuration !=
				undefined && aRelatedRequests[0].StartDate != undefined && aRelatedRequests[0].EndDate != undefined && !aRelatedRequests[0].EndTime !=
				undefined) {
				try {
					if (hcm.myleaverequest.utils.Formatters
						.isHalfDayLeave(aRelatedRequests[0].WorkingDaysDuration)) {
						return hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(aRelatedRequests[0].StartTime) + " " + sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.TIME_hhmm(aRelatedRequests[0].EndTime);
					}
					if (aRelatedRequests[0].WorkingDaysDuration * 1 != 1) {
						return sHyphen + " " + hcm.myleaverequest.utils.Formatters
							.DATE_ODATA_EEEdMMMyyyyLong(aRelatedRequests[0].EndDate);
					}
				} catch (e) {}
			}
			return "";
		},

		State: function(status) {
			status = status.toLowerCase();
			switch (status) {
				case "sent":
					return null;
				case "posted":
					return "Success";
				case "approved":
					return "Success";
				case "rejected":
					return "Error";
				default:
					return null;
			}

		},

		/**
		 * Adds BalanceUsedQuantity, BalanceApprovedQuantity & BalanceRequestedQuantity
		 * @param {String} BalanceUsedQuantity
		 * @param {String} BalanceApprovedQuantity
		 * @param {String} BalanceRequestedQuantity
		 * @return {String} totalUsed
		 */
		calculateUsed: function(BalanceUsedQuantity, BalanceApprovedQuantity, BalanceRequestedQuantity) {
			var sBalanceTotalUsedQuantity = parseFloat(BalanceUsedQuantity) + parseFloat(BalanceApprovedQuantity) + parseFloat(
				BalanceRequestedQuantity);
			sBalanceTotalUsedQuantity = hcm.myleaverequest.utils.Formatters.BALANCE(sBalanceTotalUsedQuantity.toString());
			return sBalanceTotalUsedQuantity;
		},
	_parseNotes: function(notesString) {
		try {
			var notesArray = notesString.split("::NEW::");
			var result = [];
			var oEntry = {};
			var temp, i, d, t, oDate;
			for (i = 1; i < notesArray.length; i++) {
				oEntry = {};
				temp = notesArray[i].split("::::");
				oEntry.Pernr = temp[0];
				oEntry.Author = temp[1];
				oEntry.Text = temp[2];
				d = temp[3].toString();
				t = temp[4].toString();
				oDate = new Date(d.substring(0, 4), parseInt(d.substring(4, 6), 10) - 1, d.substring(6, 8), t.substring(0, 2), t.substring(2, 4), t.substring(4, 6));
				var oDateFormat = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({style: 'medium'});
				oEntry.Timestamp = oDateFormat.format(oDate);
				result.push(oEntry);
			}
			return {
				"NotesCollection": result
			};
		} catch (e) {
			//log the error
			jQuery.sap.log.error("Failed to parse notes details in utils.Formatters._parsenotes with input" + notesString);
		}
	},
	_parseAttachments: function(attachmentString, RequestID,oModel) {
		try {
			var attachments = attachmentString.split("::NEW::");
			var result = [];
			var oEntry = {};
			var temp, i, d, t, oDate;
			var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			//first one will be junk
			for (i = 1; i < attachments.length; i++) {
				oEntry = {};
				temp = attachments[i].split("::::");
				oEntry.FileName = temp[0];
				oEntry.FileType = '';
				oEntry.Contributor = temp[2];
				d = temp[3].toString();
				t = temp[4].toString();
				oDate = new Date(d.substring(0, 4), parseInt(d.substring(4, 6), 10) - 1, d.substring(6, 8), t.substring(0, 2), t.substring(2, 4), t.substring(4, 6));
				var oDateFormat = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({style: 'medium'});
				oEntry.UploadedDate = oDateFormat.format(oDate);
				oEntry.DocumentId = temp[5];
				oEntry.Status = temp[6];
				oEntry.FilePath = temp[7];
				oEntry.FileSize = parseFloat(temp[8],10);
				oEntry.FileSizeDesc = temp[9];
				oEntry.MimeType = temp[1];
				if(temp[5]){
				   oEntry.FileUrl = oModel.sServiceUrl + "/FileAttachmentSet(EmployeeID='" + oPernr + "',LeaveRequestId='" + RequestID + "',ArchivDocId='" + temp[5] + "')/$value";
				}
				else{
				    jQuery.sap.log.error("ArchivDocId is missing for LeaveRequestID:" + RequestID, [], ["hcm.myleaverequest.utils.Formatters._parseAttachments"]);
				    oEntry.FileUrl = "";
				}
				result.push(oEntry);
			}
			return {
				"AttachmentsCollection": result
			};
		} catch (e) {
			//log the error
			jQuery.sap.log.error("Failed to parse notes details in utils.Formatters._parseAttachments with input" + attachmentString);
		}
	}

	};

}());
},
	"hcm/myleaverequest/utils/UIHelper.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.declare("hcm.myleaverequest.utils.UIHelper");

hcm.myleaverequest.utils.UIHelper = (function() {
	var _cntrlrInst = null;
	var _objLeaveRequestCollection = null;
	var _isLeaveCollCached = false;
	var _isWithDrawn = [];
	var _isChangeAction = false;
	var _isWithDrawAction = false;
	var _pernr = null;
	return {

		setControllerInstance : function(oControllerInst) {
			_cntrlrInst = oControllerInst;
		},

		getControllerInstance : function() {
			return _cntrlrInst;
		},
		setRoutingProperty : function(objLeaveRequestCollection) {
			if(objLeaveRequestCollection){
				for ( var oItemIndex = 0; oItemIndex < objLeaveRequestCollection.length; oItemIndex++) {
					var oLeaveKey = objLeaveRequestCollection[oItemIndex].LeaveKey;
					var oRequestID = objLeaveRequestCollection[oItemIndex].RequestID;
					if(oRequestID !== ""){
						objLeaveRequestCollection[oItemIndex]._navProperty = oRequestID;
					}else{
						objLeaveRequestCollection[oItemIndex]._navProperty = oLeaveKey;
					}
				}
			}
			_objLeaveRequestCollection = objLeaveRequestCollection;
		},

		getRoutingProperty : function() {
			return _objLeaveRequestCollection;
		},
		setIsLeaveCollCached : function(isLeaveCollCached) {
			_isLeaveCollCached = isLeaveCollCached;
		},

		getIsLeaveCollCached : function() {
			return _isLeaveCollCached;
		},
		
		setIsWithDrawn : function(id) {
			_isWithDrawn.push(id);
		},

		getIsWithDrawn : function(id) {
			if(jQuery.inArray(id,_isWithDrawn) >= 0)
			return true;
			else return false;
		},
		
		setIsChangeAction : function(oStatus) {
			_isChangeAction = oStatus;
		},

		getIsChangeAction : function() {
			return _isChangeAction;
		},
		
		setIsWithDrawAction : function(oStatus) {
			_isWithDrawAction = oStatus;
		},

		getIsWithDrawAction : function() {
			return _isWithDrawAction;
		},
		setPernr : function(oPernr) {
			_pernr = oPernr;
		},

		getPernr : function() {
			return _pernr;
		},
		errorDialog : function(messages) {

			var _errorTxt = "";
			var _firstMsgTxtLine = "";
			var _detailmsg = "";
			var oSettings = "";

			if (typeof messages === "string") {
				oSettings = {
					message : messages,
					type : sap.ca.ui.message.Type.ERROR
				};
			} else if (messages instanceof Array) {

				for ( var i = 0; i < messages.length; i++) {
					_errorTxt = "";
					if (typeof messages[i] === "string") {
						_errorTxt = messages[i];
					} else if (typeof messages[i] === "object") {
						_errorTxt = messages[i].value;
					}
					_errorTxt.trim();
					if( _errorTxt !== ""){
    					if (i === 0) {
    						_firstMsgTxtLine = _errorTxt;
    					} else {
    						_detailmsg = _detailmsg + _errorTxt + "\n";
    					}
					}
				}

				if (_detailmsg == "") { // do not show any details if none are there
					oSettings = {
						message : _firstMsgTxtLine,
						type : sap.ca.ui.message.Type.ERROR
					};
				} else {
					oSettings = {
						message : _firstMsgTxtLine,
						details : _detailmsg,
						type : sap.ca.ui.message.Type.ERROR
					};
				}

			}
			sap.ca.ui.message.showMessageBox(oSettings);
		}

	};

}());
},
	"hcm/myleaverequest/view/S1.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
jQuery.sap.require("hcm.myleaverequest.utils.ConcurrentEmployment");
jQuery.sap.require("hcm.myleaverequest.utils.CalendarTools");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("sap.ca.ui.dialog.Dialog");
jQuery.sap.require("sap.m.MessageToast");
jQuery.support.useFlexBoxPolyfill = false;
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("sap.ui.thirdparty.sinon");

/*global hcm window setTimeout sinon:true*/
sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.myleaverequest.view.S1", {

	extHookChangeFooterButtons: null,
	extHookRouteMatchedHome: null,
	extHookRouteMatchedChange: null,
	extHookClearData: null,
	extHookInitCalendar: null,
	extHookTapOnDate: null,
	extHookSetHighlightedDays: null,
	extHookDeviceDependantLayout: null,
	extHookSubmit: null,
	extHookOnSubmitLRCfail: null,
	extHookOnSubmitLRCsuccess: null,
	extHookCallDialog: null,

	onInit: function() {
		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
		hcm.myleaverequest.utils.Formatters.init(this.resourceBundle);
		hcm.myleaverequest.utils.CalendarTools.init(this.resourceBundle);
		this.oDataModel = hcm.myleaverequest.utils.DataManager.getBaseODataModel();
		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
		this._buildHeaderFooter();
		this._initCntrls();
		sap.ui.getCore().getEventBus().subscribe("hcm.myleaverequest.LeaveCollection", "refresh", this._onLeaveCollRefresh, this);

	},

	_initCntrls: function() {

		this.changeMode = false; // true: S4 is called by history view for existing lr
		this.oChangeModeData = {}; // container for LR data coming from history view in change mode
		this.selRange = {}; // Object holding the selected dates of the calendar control
		this.selRange.start = null; // earliest selected date or singel selected date
		this.selRange.end = null; // latest selected date or null for single days
		this.aLeaveTypes = []; // array of absence types for current user
		this.leaveType = {}; // currently selected absence type

		this.iPendingRequestCount = 0;

		// ----variables used during onSend:
		this.bSubmitOK = null; // true when the submit simulation was successful
		this.bApproverOK = null; // true when the approving manager could be determined
		this.oSubmitResult = {};
		this.sApprover = ""; // Approving manager - used in confirmation popup
		this.bSimulation = true; // used in oData call for submit of lr - true: just check user entry false: do posting
		this._isLocalReset = false;

		// ------- convenience variables for screen elements
		this.oBusy = null;
		this.formContainer = this.byId("LRS4_FRM_CNT_BALANCES");
		this.timeInputElem = this.byId("LRS4_FELEM_TIMEINPUT");
		this.balanceElem = this.byId("LRS4_FELEM_BALANCES");
		this.noteElem = this.byId("LRS4_FELEM_NOTE");
		this.timeFrom = this.byId("LRS4_DAT_STARTTIME");
		this.timeTo = this.byId("LRS4_DAT_ENDTIME");
		this.legend = this.byId("LRS4_LEGEND");
		this.remainingVacation = this.byId("LRS4_TXT_REMAINING_DAYS");
		this.bookedVacation = this.byId("LRS4_TXT_BOOKED_DAYS");
		this.note = this.byId("LRS4_TXA_NOTE");
		this.cale = this.byId("LRS4_DAT_CALENDAR");
		this.slctLvType = this.byId("SLCT_LEAVETYPE");
		this.calSelResetData = [];
		this._initCalendar(); // set up layout + fill calendar with events
		this._deviceDependantLayout();
		this.objectResponse = null;
		this.ResponseMessage = null;
	},

	_onLeaveCollRefresh: function() {
		hcm.myleaverequest.utils.CalendarTools.clearCache();
	},

	onAfterRendering: function() {
		var that = this;
		$(window).on("orientationchange", function(event) {
			//passing the type orientation to decide number of months to be displayed
			that._orientationDependancies(event.orientation);
		});

		if (!sap.ui.getCore().getConfiguration().getRTL()) {
			//to align the text and total days available to right
			this.byId('LRS4_TXT_REMAININGDAY').onAfterRendering = function() {
				jQuery(this.getDomRef()).css({
					'text-align': 'right' /*for IE and web kit browsers*/
				});
			};
			//to enhance the font of days used/available
			this.byId('LRS4_TXT_REMAINING_DAYS').onAfterRendering = function() {
				jQuery(this.getDomRef()).css({
					'font-size': '1.5rem',
					'font-weight': '700',
					'text-align': 'right'
				});
			};

		} else {
			// in case of LTR text direction
			//to align the text and total days available to left
			this.byId('LRS4_TXT_REMAININGDAY').onAfterRendering = function() {
				jQuery(this.getDomRef()).css({
					'text-align': 'left' /*for IE and web kit browsers*/
				});
			};
			//to enhance the font of days used/available
			this.byId('LRS4_TXT_REMAINING_DAYS').onAfterRendering = function() {
				jQuery(this.getDomRef()).css({
					'font-size': '1.5rem',
					'font-weight': '700',
					'text-align': 'left'
				});
			};
		}
		this.byId('LRS4_TXT_BOOKED_DAYS').onAfterRendering = function() {
			jQuery(this.getDomRef()).css({
				'font-size': '1.5rem',
				'font-weight': '700'
			});
		};
	},

	_buildHeaderFooter: function() {
		var _this = this;
		this.objHeaderFooterOptions = {
			sI18NFullscreenTitle: "",
			oEditBtn: {
				sId: "LRS4_BTN_SEND",
				sI18nBtnTxt: "LR_SEND",
				onBtnPressed: function(evt) {
					_this.onSendClick(evt);
				}
			},
			buttonList: [{
				sId: "LRS4_BTN_CANCEL",
				sI18nBtnTxt: "LR_RESET",
				onBtnPressed: function(evt) {
					_this.onCancelClick(evt);
				}
			}, {
				sId: "LRS4_BTN_ENTITLEMENT",
				sI18nBtnTxt: "LR_BALANCE_TILE",
				onBtnPressed: function(evt) {
					_this.onEntitlementClick(evt);
				}
			}, {
				sId: "LRS4_BTN_HISTORY",
				sI18nBtnTxt: "LR_HISTORY_TILE",
				onBtnPressed: function(evt) {
					_this.onHistoryClick(evt);
				}
			}]
		};
		var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			this.objHeaderFooterOptions.bSuppressBookmarkButton = true;
		}

		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.myleaverequest.view.S1~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */
		if (this.extHookChangeFooterButtons) {
			this.objHeaderFooterOptions = this.extHookChangeFooterButtons(this.objHeaderFooterOptions);
		}
	},

	_handleRouteMatched: function(evt) {
		var _this = this;

		if (evt.getParameter("name") === "home") {

			hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
			this.objHeaderFooterOptions.sI18NFullscreenTitle = "LR_CREATE_LEAVE_TILE";
			this.setHeaderFooterOptions(this.objHeaderFooterOptions);
			hcm.myleaverequest.utils.UIHelper.setControllerInstance(this);
			this.oChangeModeData = {};
			this.changeMode = false;
			this.byId("fileupload").setVisible(false);
			this._clearData();
			hcm.myleaverequest.utils.CalendarTools.clearCache();
			var sComponentId = sap.ui.core.Component.getOwnerIdFor(this.getView()); //get the pernr from the cross app nav
			var oStartUpParameters = sap.ui.component(sComponentId).getComponentData().startupParameters;
			var oPernr;
			if (oStartUpParameters && oStartUpParameters.pernr) {
				oPernr = oStartUpParameters.pernr[0];
				hcm.myleaverequest.utils.UIHelper.setPernr(oPernr);
			} else {
				oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			}
			if (oPernr) {
				_this.initializeView();
			} else {
				hcm.myleaverequest.utils.ConcurrentEmployment.getCEEnablement(this, function() {
					_this.initializeView();
				});
			}

			if (_this.cale && _this.cale.getSelectedDates().length === 0) {
				_this.setBtnEnabled("LRS4_BTN_SEND", false);
			} else {
				_this.setBtnEnabled("LRS4_BTN_SEND", true);
			}

			/**
			 * @ControllerHook Extend load behavior of home view
			 * This hook method can be used to add UI or business logic
			 * It is called when the routeMatched event name match with home
			 * @callback hcm.myleaverequest.view.S1~extHookRouteMatchedHome
			 */
			if (this.extHookRouteMatchedHome) {
				this.extHookRouteMatchedHome();
			}

		} else if (evt.getParameter("name") === "change") {

			hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
			this.objHeaderFooterOptions.sI18NFullscreenTitle = "LR_TITLE_CHANGE_VIEW";
			this.setHeaderFooterOptions(this.objHeaderFooterOptions);
			hcm.myleaverequest.utils.UIHelper.setControllerInstance(this);
			this.oChangeModeData = {};
			this.changeMode = true;
			this._clearData();

			var currntRequestId = evt.getParameters().arguments.requestID;

			var curntLeaveRequest = null,
				i;

			var consolidatedLeaveRequestcollection = hcm.myleaverequest.utils.DataManager.getCachedModelObjProp("ConsolidatedLeaveRequests");

			if (consolidatedLeaveRequestcollection) {
				for (i = 0; i < consolidatedLeaveRequestcollection.length; i++) {
					if (consolidatedLeaveRequestcollection[i].RequestID == currntRequestId) {
						curntLeaveRequest = consolidatedLeaveRequestcollection[i];
					}
				}

				//requestID is null
				if (curntLeaveRequest == null) {
					for (i = 0; i < consolidatedLeaveRequestcollection.length; i++) {
						if (consolidatedLeaveRequestcollection[i].LeaveKey == currntRequestId) {
							curntLeaveRequest = consolidatedLeaveRequestcollection[i];
						}
					}
				}
			}

			if (!curntLeaveRequest) {
				/*hcm.myleaverequest.utils.UIHelper.errorDialog([this.resourceBundle.getText("LR_DD_GENERIC_ERR"), 
					                                                    "hcm.myleaverequest.view.S1",
					                                                    "_handleRouteMatched",
					                                                    "curntLeaveRequest is null"]);*/
				jQuery.sap.log.warning("curntLeaveRequest is null", "_handleRouteMatched", "hcm.myleaverequest.view.S1");
				this.oRouter.navTo("home", {}, true);
			} else {
				var startDate_UTC = hcm.myleaverequest.utils.Formatters.getDate(curntLeaveRequest.StartDate);
				var endDate_UTC = hcm.myleaverequest.utils.Formatters.getDate(curntLeaveRequest.EndDate);
				startDate_UTC = new Date(startDate_UTC.getUTCFullYear(), startDate_UTC.getUTCMonth(), startDate_UTC.getUTCDate(), 0, 0, 0);
				endDate_UTC = new Date(endDate_UTC.getUTCFullYear(), endDate_UTC.getUTCMonth(), endDate_UTC.getUTCDate(), 0, 0, 0);
				_this.oChangeModeData.requestId = curntLeaveRequest.RequestID;
				_this.oChangeModeData.leaveTypeCode = curntLeaveRequest.AbsenceTypeCode;
				_this.oChangeModeData.startDate = startDate_UTC.toString();
				_this.oChangeModeData.endDate = endDate_UTC.toString();
				_this.oChangeModeData.requestID = curntLeaveRequest.RequestID;
				_this.oChangeModeData.noteTxt = curntLeaveRequest.Notes;
				_this.oChangeModeData.startTime = curntLeaveRequest.StartTime;
				_this.oChangeModeData.endTime = curntLeaveRequest.EndTime;
				_this.oChangeModeData.employeeID = curntLeaveRequest.EmployeeID;
				_this.oChangeModeData.changeStateID = curntLeaveRequest.ChangeStateID;
				_this.oChangeModeData.leaveKey = curntLeaveRequest.LeaveKey;
				_this.oChangeModeData.evtType = _this._getCaleEvtTypeForStatus(curntLeaveRequest.StatusCode);
				_this.oChangeModeData.StatusCode = curntLeaveRequest.StatusCode;
				_this.oChangeModeData.ApproverEmployeeID = curntLeaveRequest.ApproverEmployeeID;
				_this.oChangeModeData.ApproverEmployeeName = curntLeaveRequest.ApproverEmployeeName;
				_this.oChangeModeData.WorkingHoursDuration = curntLeaveRequest.WorkingHoursDuration;
				_this.oChangeModeData.AttachmentDetails = curntLeaveRequest.AttachmentDetails;
				_this._setUpLeaveTypeData(_this.oChangeModeData.leaveTypeCode);
				_this._copyChangeModeData();
				//disable time inputs if the leaveRange > 1
				if (_this.cale.getSelectedDates().length > 1) {
					if (this.timeFrom) {
						this.timeFrom.setValue("");
						this.timeFrom.setEnabled(false);
					}
					if (this.timeTo) {
						this.timeTo.setValue("");
						this.timeTo.setEnabled(false);
					}
				}
				// send button should be disabled if no date is selected
				if (_this.cale && _this.cale.getSelectedDates().length === 0) {
					_this.setBtnEnabled("LRS4_BTN_SEND", false);
				} else {
					_this.setBtnEnabled("LRS4_BTN_SEND", true);
				}
			}
			//sap.ca.ui.utils.busydialog.releaseBusyDialog();

			/**
			 * @ControllerHook Extend load behavior of change view
			 * This hook method can be used to add UI or business logic
			 * It is called when the routeMatched event name match with change
			 * @callback hcm.myleaverequest.view.S1~extHookRouteMatchedChange
			 */
			if (this.extHookRouteMatchedChange) {
				this.extHookRouteMatchedChange();
			}
		}

	},

	_copyChangeModeData: function() {
		// In change mode the data to be displayed is not entered by the user instead it
		// comes from the LR selected in the history view - This method fills the data coming
		// from the history view into the screen elements of S4
		var _oStartTime = null;
		var _oEndTime = null;
		var _HH = 0;
		var _MM = 0;

		// set Start and End date for calendar
		if (this.oChangeModeData === {}) {
			return;
		}

		this.selRange.start = this.oChangeModeData.startDate;
		this.selRange.end = this.oChangeModeData.endDate;
		if (this.selRange.start === this.selRange.end) {
			this.selRange.end = null;
			if (this.cale) {
				this.cale.toggleDatesSelection([this.selRange.start], true);
			}
		} else {
			if (this.cale) {
				this.cale.toggleDatesRangeSelection(this.selRange.start, this.selRange.end, true);
			}
		}
		if (this.cale) {
			this.cale.setCurrentDate(this.selRange.start);
			this._setHighlightedDays(this.cale.getCurrentDate());
		}

		// set simple ones
		this.requestID = this.oChangeModeData.requestID;
		if (this.note) { // App Designer specific: in case note field was removed
			//remove previous note if exists
			if (!!this.byId("LRS4_NOTE") && this.byId("LRS4_NOTE").getContent().length > 2)
				this.byId("LRS4_NOTE").removeContent(1);

			//adding note text only if exists
			if (!!this.oChangeModeData.noteTxt && this.oChangeModeData.noteTxt !== "") {
				var oDataNotes = hcm.myleaverequest.utils.Formatters._parseNotes(this.oChangeModeData.noteTxt);
				var tempNote = "";
				for (var i = 0; i < oDataNotes.NotesCollection.length; i++) {
					tempNote = tempNote + oDataNotes.NotesCollection[i].Author + ":" + oDataNotes.NotesCollection[i].Text + "\n";
				}

				var noteText = new sap.m.Text({
					width: "100%",
					wrapping: true,
					layoutData: new sap.ui.layout.ResponsiveFlowLayoutData({
						weight: 8
					})
				});
				noteText.setText(tempNote);
				this.byId("LRS4_NOTE").insertContent(noteText, 1);
			}
		}
		//add attachments if exist
		if (this.oChangeModeData.AttachmentDetails) {
			var oDataFiles = hcm.myleaverequest.utils.Formatters._parseAttachments(this.oChangeModeData.AttachmentDetails, this.oChangeModeData.RequestID,
				this.oDataModel);
			if (oDataFiles.AttachmentsCollection.length > 0) {
				var attachmentsModel = new sap.ui.model.json.JSONModel(oDataFiles);
				this.byId("fileupload").setModel(attachmentsModel, "files");
				this.byId("fileupload").setVisible(true);
			} else {
				this.byId("fileupload").setVisible(false);
			}
		}
		// set start and end Time
		if (typeof this.oChangeModeData.startTime === "string") {
			if (this.timeFrom) {
				if (this.oChangeModeData.startTime === "000000") {
					this.timeFrom.setValue("");
				} else {
					this.timeFrom.setValue(this.oChangeModeData.startTime.substring(0, 2) + ":" + this.oChangeModeData.startTime.substring(2, 4));
				}
			}
			if (this.timeTo) {
				if (this.oChangeModeData.endTime === "000000") {
					this.timeTo.setValue("");
				} else {
					this.timeTo.setValue(this.oChangeModeData.endTime.substring(0, 2) + ":" + this.oChangeModeData.endTime.substring(2, 4));
				}
			}
		} else {
			_oStartTime = new Date(this.oChangeModeData.startTime.ms);
			_HH = _oStartTime.getUTCHours();
			_MM = _oStartTime.getUTCMinutes();
			_HH = (_HH < 10 ? "0" : "") + _HH;
			_MM = (_MM < 10 ? "0" : "") + _MM;
			if (this.timeFrom) {
				this.timeFrom.setValue(_HH + ":" + _MM);
			}

			_oEndTime = new Date(this.oChangeModeData.endTime.ms);
			_HH = _oEndTime.getUTCHours();
			_MM = _oEndTime.getUTCMinutes();
			_HH = (_HH < 10 ? "0" : "") + _HH;
			_MM = (_MM < 10 ? "0" : "") + _MM;
			if (this.timeTo) {
				this.timeTo.setValue(_HH + ":" + _MM);
			}
			// this.timeFrom = _oStartTime.getHours().toString() + ":" + _oStartTime.getMinutes();
		}
		//if (this.send) {
		if (this.cale & this.cale.getSelectedDates().length === 0) {
			//this.send.setEnabled(false);
			this.setBtnEnabled("LRS4_BTN_SEND", false);
		} else {
			//this.send.setEnabled(true);
			this.setBtnEnabled("LRS4_BTN_SEND", true);
		}
		//};
		if (this.oChangeModeData.WorkingHoursDuration) {
			this.byId("LRS4_ABS_HOURS").setValue(this.oChangeModeData.WorkingHoursDuration);
		}
	},
	_clearData: function() {
		// All screen elements that can be changed by a user are set back to their initial values
		// This refresh is done when the screen is started (onNavigateTo) and when a new LR has
		// successfully been submitted (onSubmitLRCsuccess) and when changing/creating a LR is
		// aborted with the cancel button (onCancel)
		// This method does NO refresh of the ajax buffer or the calendarTool buffer
		if (!this.changeMode) {
			this._clearDateSel();
		}

		if (this._isLocalReset) {
			for (var i = 0; i < this.calSelResetData.length; i++) {
				this.cale.toggleDatesType(this.calSelResetData[i].calEvt, this.calSelResetData[i].evtType, false);
			}
			this.calSelResetData = [];
		}
		//Retain the change mode data.. needed in case if employee tries to change the leave consecutively
		if (!this.changeMode) {
			this.oChangeModeData = {};
		}
		if (this.cale) {
			this.cale.setCurrentDate(new Date());
		}
		if (this.note) { // App Designer specific: in case note field was removed
			this.note.setValue("");
			//remove previous note if exists
			if (!!this.byId("LRS4_NOTE") && this.byId("LRS4_NOTE").getContent().length > 2)
				this.byId("LRS4_NOTE").removeContent(1);
		}
		if (this.timeFrom) {
			this.timeFrom.setValue("");
			this.timeFrom.rerender(); //workaround since setValue won't remove HTML content in the input box in Mobile devices
			this.timeFrom.setEnabled(true);
		}
		if (this.timeTo) {
			this.timeTo.setValue("");
			this.timeTo.rerender(); //workaround since setValue won't remove HTML content in the input box in Mobile devices
			this.timeTo.setEnabled(true);
		}
		if (this.byId("LRS4_ABS_HOURS")) {
			this.byId("LRS4_ABS_HOURS").setValue("");
			this.byId("LRS4_ABS_HOURS").rerender(); //workaround since setValue won't remove HTML content in the input box in Mobile devices
			this.byId("LRS4_ABS_HOURS").setEnabled(true);
		}
		if (this.byId("fileUploader")) {
			this.byId("fileUploader").setValue("");
		}
		this.setBtnEnabled("LRS4_BTN_SEND", false);
		if (this.byId("LRS4_LBL_TITLE")) {
			this.byId("LRS4_LBL_TITLE").setText(this.resourceBundle.getText("LR_TITLE_CREATE_VIEW"));
		}

		// set leave type to default absence type + get balances for absence type
		if (this.aLeaveTypes.length > 0 && this.changeMode === false && this._isLocalReset === true) {

			//var defaultLeaveObj = hcm.myleaverequest.utils.DataManager.getCachedModelObjProp("DefaultConfigurations");
			this._setUpLeaveTypeData();
			// The selection inthe drop down list needs also to be reset to the default value but
			// setting the selected item programatically in sap.m.list does not work once the selection
			// was done by a real tap event...
			// Therefore then list content is destroyed and rebuild here which also resets the selection.
			// The tap handler will then set the selection to the default value (first list item)
		}

		this._isLocalReset = false;

		/**
		 * @ControllerHook Extend behavior of clearing of data
		 * This hook method can be used to add UI or business logic
		 * It is called when the clearData method executes
		 * @callback hcm.myleaverequest.view.S1~extHookClearData
		 */
		if (this.extHookClearData) {
			this.extHookClearData();
		}

	},

	_clearDateSel: function() {
		// remove all selected days from the calendar control and from selRange
		if (this.cale) {
			this.cale.unselectAllDates();
		}
		this.selRange.end = null;
		this.selRange.start = null;
		//if (this.send) {
		//this.send.setEnabled(false);
		this.setBtnEnabled("LRS4_BTN_SEND", false);
		//}
	},

	_initCalendar: function() {
		// Here the initial setup for the calendar and the calendar legend is done
		// this setting is refined depending on the used device and device orientation
		// in deviceDependantLayout() and leaveTypeDependantSettings()
		if (this.cale) {
			this.cale.setSwipeToNavigate(true);
			// handler for paging in calendar
			this.cale.attachChangeCurrentDate(this._onChangeCurrentDate, this);
			// handler for date selection
			this.cale.attachTapOnDate(this._onTapOnDate, this);
			// disable swipe range selection -> we do the range selection using 'tap'
			this.cale.setEnableMultiselection(false);
			// setup display for moth
			this.cale.setWeeksPerRow(1);

		}

		// create legend
		if (this.legend) {
			this.legend.setLegendForNormal(this.resourceBundle.getText("LR_WORKINGDAY"));
			this.legend.setLegendForType00(this.resourceBundle.getText("LR_NONWORKING"));
			this.legend.setLegendForType01(this.resourceBundle.getText("LR_APPROVELEAVE"));
			this.legend.setLegendForType04(this.resourceBundle.getText("LR_APPROVEPENDING"));
			this.legend.setLegendForType06(this.resourceBundle.getText("LR_PUBLICHOLIDAY"));
			this.legend.setLegendForType07(this.resourceBundle.getText("LR_REJECTEDLEAVE"));
			this.legend.setLegendForToday(this.resourceBundle.getText("LR_DTYPE_TODAY"));
			this.legend.setLegendForSelected(this.resourceBundle.getText("LR_DTYPE_SELECTED"));
		}

		/**
		 * @ControllerHook Extend behavior of initializing calendar
		 * This hook method can be used to add UI or business logic
		 * It is called when the initCalendar method executes
		 * @callback hcm.myleaverequest.view.S1~extHookInitCalendar
		 */
		if (this.extHookInitCalendar) {
			this.extHookInitCalendar();
		}

	},

	//TODO Orientation
	registerForOrientationChange: function(oApp) {
		// called by Main.controller.js during init
		// registration is only done on tablets
		if (sap.ui.Device.system.tablet) {
			this.parentApp = oApp;
			oApp.attachOrientationChange(jQuery.proxy(this._onOrientationChanged, this));
		}
	},

	_onOrientationChanged: function() {
		// the dynamic layout for orientation changes is done in leaveTypeDependantSettings
		this._leaveTypeDependantSettings(this.leaveType);
	},

	_onTapOnDate: function(evt) {
		// tap handler for calendar control
		// Depending on the AllowedDurationMultipleDayInd the selection of a single day or a range of days is allowed
		// selecting a singel day: tap on a day
		// deselecting a sngle day: select a different day or tap again on a selected day
		// selecting a range of days: tap on one day to select it then tap an a different day to select both
		// days and all days between them
		// deselecting a range: tapping an a day while a range of days is selected deselects the range and the tapped
		// day becomes selected
		var _aSelction;

		if (this.cale) {
			_aSelction = this.cale.getSelectedDates();
		}

		if (this.leaveType.AllowedDurationMultipleDayInd === false) {
			// there are Absence Types where partial days AND multiple days are allowed
			// || this.leaveType.AllowedDurationPartialDayInd === true) {
			// only one day may be selected at a time
			// no special treatment needed

		} else if (this.leaveType.AllowedDurationMultipleDayInd) {
			// Ranges and single days are allowed
			if (_aSelction.length === 0) {
				// ************** a selection was removed *****************
				if (this.selRange.start !== null && this.selRange.end !== null) {
					// a selected range was deselected -> the new selection replaces the old}
					this._clearDateSel();
					if (evt.getParameters().date !== "") {
						this.selRange.start = evt.getParameters().date;
						if (this.cale) {
							this.cale.toggleDatesSelection([this.selRange.start], true);
						}
					}
				} else if (this.selRange.start !== null && this.selRange.end === null) {
					// A single field was deselected -> remove selection
					this._clearDateSel();
				}
			}
			// // ************** something was selected *****************
			else if (this.selRange.start === null) {
				// start date of range selected
				this.selRange.start = evt.getParameters().date;
			} else if (this.selRange.end === null) {
				// end date of range selected
				this.selRange.end = evt.getParameters().date;
				if (this.cale) {
					this.cale.toggleDatesRangeSelection(this.selRange.start, this.selRange.end, true);
				}
			} else {
				this.selRange.start = evt.getParameters().date;
				this.selRange.end = null;
				// this.selRange.lastTap = null;
				if (this.cale) {
					this.cale.toggleDatesSelection([this.selRange.start], true);
				}
			}
		}

		// if partial days AND multiple days are allowed the time input fields shall only be open
		// for input if a single day is selected
		if (this.leaveType.AllowedDurationMultipleDayInd === true && this.timeFrom && this.timeTo) {
			_aSelction = this.cale.getSelectedDates();
			if (_aSelction.length > 1) {
				this.timeFrom.setValue("");
				this.timeTo.setValue("");
				this.byId("LRS4_ABS_HOURS").setValue("");
				this.timeFrom.setEnabled(false);
				this.timeTo.setEnabled(false);
				this.byId("LRS4_ABS_HOURS").setEnabled(false);
			} else {
				this.timeFrom.setEnabled(true);
				this.timeTo.setEnabled(true);
				this.byId("LRS4_ABS_HOURS").setEnabled(true);
			}

		}

		if (this.cale && this.cale.getSelectedDates().length === 0) {
			this.setBtnEnabled("LRS4_BTN_SEND", false);
		} else {
			this.setBtnEnabled("LRS4_BTN_SEND", true);
		}

		/**
		 * @ControllerHook Extend behavior of tap on Date
		 * This hook method can be used to add UI or business logic
		 * It is called when the onTapOnDate method executes
		 * @callback hcm.myleaverequest.view.S1~extHookTapOnDate
		 */
		if (this.extHookTapOnDate) {
			this.extHookTapOnDate();
		}

	},

	_setHighlightedDays: function(strDate) {
		// This method triggers the reading of the calendar events from the backend for the
		// currently displayed month as well as the previous and next month.
		// Buffering of the calendar events is done in calendarTools.js
		var _oDate;
		//incorporating framework change
		try {
			_oDate = sap.me.Calendar.parseDate(strDate);
		} catch (e) {
			_oDate = new Date(strDate);
		}
		//sap.ca.ui.utils.busydialog.requireBusyDialog();
		hcm.myleaverequest.utils.CalendarTools.getDayLabelsForMonth(_oDate, this._getCalLabelsOK,
			this._getCalLabelsError);

		/**
		 * @ControllerHook Extend behavior of highlighted days
		 * This hook method can be used to add UI or business logic
		 * It is called when the setHighlightedDays method executes
		 * @callback hcm.myleaverequest.view.S1~extHookSetHighlightedDays
		 */
		if (this.extHookSetHighlightedDays) {
			this.extHookSetHighlightedDays();
		}

	},

	_getCalLabelsOK: function(oCalEvents) {
			var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
			/*
    		 maps the back end status to the corresponding sap.me.calendar event type
    		 sap.me.CalendarEventType.Type00 Type00 (non-working day)
    		 sap.me.CalendarEventType.Type10 Type10 (working day) ONLY Available after 1.22.x hence we have check
    		 sap.me.CalendarEventType.Type01 Type01 (Booked/Approved)
    		 sap.me.CalendarEventType.Type04 Type04 (open request / manager action needed)
    		 sap.me.CalendarEventType.Type06 Type06 (public holiday)
    		 sap.me.CalendarEventType.Type07 Type07 (deletion requested / your action needed/ Rejected)
    		 Precedences(low---high) : REJECTED< SENT< (APPROVED|POSTED)
    		 It means if you have two leave requests on same day, Approved will more precedence than rejected one.
    		 WEEKEND , WORKDAY, PHOLIDAY, (all LEAVE TYPES) are independent. 
    		 Hence toggling is needed only b/w leave types
    		 */
			if (!!oCalEvents.REJECTED && oCalEvents.REJECTED.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.REJECTED, sap.me.CalendarEventType.Type00, false);
				_this.cale.toggleDatesType(oCalEvents.REJECTED, sap.me.CalendarEventType.Type01, false);
				_this.cale.toggleDatesType(oCalEvents.REJECTED, sap.me.CalendarEventType.Type04, false);
				_this.cale.toggleDatesType(oCalEvents.REJECTED, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(oCalEvents.REJECTED, sap.me.CalendarEventType.Type07, true);
				_this.cale.toggleDatesType(oCalEvents.REJECTED, sap.me.CalendarEventType.Type10, false);
			}
			if (!!oCalEvents.SENT && oCalEvents.SENT.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.SENT, sap.me.CalendarEventType.Type00, false);
				_this.cale.toggleDatesType(oCalEvents.SENT, sap.me.CalendarEventType.Type01, false);
				_this.cale.toggleDatesType(oCalEvents.SENT, sap.me.CalendarEventType.Type04, true);
				_this.cale.toggleDatesType(oCalEvents.SENT, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(oCalEvents.SENT, sap.me.CalendarEventType.Type07, false);
				_this.cale.toggleDatesType(oCalEvents.SENT, sap.me.CalendarEventType.Type10, false);
			}
			if (!!oCalEvents.APPROVED && oCalEvents.APPROVED.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.APPROVED, sap.me.CalendarEventType.Type00, false);
				_this.cale.toggleDatesType(oCalEvents.APPROVED, sap.me.CalendarEventType.Type01, true);
				_this.cale.toggleDatesType(oCalEvents.APPROVED, sap.me.CalendarEventType.Type04, false);
				_this.cale.toggleDatesType(oCalEvents.APPROVED, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(oCalEvents.APPROVED, sap.me.CalendarEventType.Type07, false);
			}
			if (!!oCalEvents.POSTED && oCalEvents.POSTED.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.POSTED, sap.me.CalendarEventType.Type00, false);
				_this.cale.toggleDatesType(oCalEvents.POSTED, sap.me.CalendarEventType.Type01, true);
				_this.cale.toggleDatesType(oCalEvents.POSTED, sap.me.CalendarEventType.Type04, false);
				_this.cale.toggleDatesType(oCalEvents.POSTED, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(oCalEvents.POSTED, sap.me.CalendarEventType.Type07, false);
				_this.cale.toggleDatesType(oCalEvents.POSTED, sap.me.CalendarEventType.Type10, false);
			}
			if (!!oCalEvents.WEEKEND && oCalEvents.WEEKEND.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.WEEKEND, sap.me.CalendarEventType.Type00, true);
				_this.cale.toggleDatesType(oCalEvents.WEEKEND, sap.me.CalendarEventType.Type07, false);
				_this.cale.toggleDatesType(oCalEvents.WEEKEND, sap.me.CalendarEventType.Type04, false);
				_this.cale.toggleDatesType(oCalEvents.WEEKEND, sap.me.CalendarEventType.Type01, false);
				_this.cale.toggleDatesType(oCalEvents.WEEKEND, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(oCalEvents.WEEKEND, sap.me.CalendarEventType.Type10, false);
			}
			if (!!oCalEvents.PHOLIDAY && oCalEvents.PHOLIDAY.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.PHOLIDAY, sap.me.CalendarEventType.Type00, false);
				_this.cale.toggleDatesType(oCalEvents.PHOLIDAY, sap.me.CalendarEventType.Type01, false);
				_this.cale.toggleDatesType(oCalEvents.PHOLIDAY, sap.me.CalendarEventType.Type04, false);
				_this.cale.toggleDatesType(oCalEvents.PHOLIDAY, sap.me.CalendarEventType.Type06, true);
				_this.cale.toggleDatesType(oCalEvents.PHOLIDAY, sap.me.CalendarEventType.Type07, false);
				_this.cale.toggleDatesType(oCalEvents.PHOLIDAY, sap.me.CalendarEventType.Type10, false);
			}
			if (!!oCalEvents.WORKDAY && oCalEvents.WORKDAY.length > 0) {
				_this.cale.toggleDatesType(oCalEvents.WORKDAY, sap.me.CalendarEventType.Type00, false);
				_this.cale.toggleDatesType(oCalEvents.WORKDAY, sap.me.CalendarEventType.Type01, false);
				_this.cale.toggleDatesType(oCalEvents.WORKDAY, sap.me.CalendarEventType.Type04, false);
				_this.cale.toggleDatesType(oCalEvents.WORKDAY, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(oCalEvents.WORKDAY, sap.me.CalendarEventType.Type07, false);
				_this.cale.toggleDatesType(oCalEvents.WORKDAY, sap.me.CalendarEventType.Type10, true);
			}
		},

	_getCaleEvtTypeForStatus: function(sStatus) {
		// maps the back end status to the corresponding sap.me.calendar event type
		// sap.me.CalendarEventType.Type00 Type 00 (non-working day (e.g.
		// sap.me.CalendarEventType.Type01 Type 01 (nonattendance / submitted day)
		// sap.me.CalendarEventType.Type04 Type 04 (open request / manager action needed)
		// sap.me.CalendarEventType.Type06 Type 06 (public holiday)
		// sap.me.CalendarEventType.Type07 Type 07 (deletion requested / your action needed/ Rejected)
		if (sStatus === "WEEKEND") {
			return sap.me.CalendarEventType.Type00;
		} else if (sStatus === "PHOLIDAY") {
			return sap.me.CalendarEventType.Type06;
		} else if (sStatus === "SENT") {
			return sap.me.CalendarEventType.Type04;
		} else if (sStatus === "POSTED" || sStatus === "APPROVED") {
			return sap.me.CalendarEventType.Type01;
		} else if (sStatus === "REJECTED") {
			return sap.me.CalendarEventType.Type07;
		} else if (sStatus === "WORKDAY") {
			if (sap.me.CalendarEventType.Type10)
				return sap.me.CalendarEventType.Type10;
			else return "";
		} else {
			return "";
		}
	},

	_getCalLabelsError: function(objResponse) {
		//sap.ca.ui.utils.busydialog.releaseBusyDialog();
		hcm.myleaverequest.utils.UIHelper.errorDialog(objResponse);
	},

	_onChangeCurrentDate: function(evt) {
		if (this.cale) {
			this._setHighlightedDays(this.cale.getCurrentDate());
		}
	},

	_getStartEndDate: function(aStringDates) {
		var _oDates = [];
		var _oDatesSorted = [];
		var oResponse = {};
		for (var i = 0; i < aStringDates.length; i++) {
			_oDates[i] = new Date(aStringDates[i]);
		}

		if (_oDates.length === 0) {
			oResponse.startDate = {};
			oResponse.endDate = {};
		} else if (_oDates.length === 1) {
			oResponse.startDate = _oDates[0];
			oResponse.endDate = _oDates[0];
		} else {
			_oDatesSorted = _oDates.sort(function(date1, date2) {
				if (date1 < date2)
					return -1;
				if (date1 > date2)
					return 1;
				return 0;
			});
			oResponse.startDate = _oDatesSorted[0];
			oResponse.endDate = _oDatesSorted[_oDatesSorted.length - 1];
		}

		return oResponse;
	},

	_getLeaveTypesFromModel: function() {
		// This method reads the absence types from the model and fills the information in aLeaveTypes.
		// THis method was done to handle the slightly different formats in which the absence type information
		// is stored in the model -> it can be a single records or an array depending on if mock data or oData data is used
		var _aLeaveTypes = new Array();
		for (var x in this.oDataModel.oData) {
			if (x.substring(0, 21) === "AbsenceTypeCollection") {
				if (this.oDataModel.oData[x] instanceof Array) {
					for (var i = 0; i < this.oDataModel.oData[x].length; i++) {
						_aLeaveTypes.push(this.oDataModel.oData[x][i]);
					}
				} else {
					_aLeaveTypes.push(this.oDataModel.oData[x]);
				}
			}
		}
		return _aLeaveTypes;
	},

	_setUpLeaveTypeData: function(absenceTypeCode) {
		// When the absence types are read for the first time the user has not yet
		// selected one absence type from the list. Therefore the absence type are
		// initially done for the first absence type of the list.
		if (!absenceTypeCode) {
			this.leaveType = this._getDefaultAbsenceType(this.aLeaveTypes);
			absenceTypeCode = this.leaveType.AbsenceTypeCode;
		} else {
			this.leaveType = this._readWithKey(this.aLeaveTypes, absenceTypeCode);
		}
		if (this.slctLvType) {
			this.slctLvType.setSelectedKey(absenceTypeCode);
		}
		this._leaveTypeDependantSettings(this.leaveType);
		this.getBalancesForAbsenceType(absenceTypeCode);
		this.selectorInititDone = true;
	},
	_readWithKey: function(aList, keyValue) {
		// searches an arry for a given key/value pair and returns the first matching entry
		// used to search the array of absence types
		var oDefault;
		for (var i = 0; i < aList.length; i++) {
			if (aList[i].AbsenceTypeCode === keyValue) {
				oDefault = aList[i];
				return oDefault;
			}
		}
		if (aList.length > 1) {
			return aList[0];
		}
	},
	_getDefaultAbsenceType: function(aList) {
		// searches an arry for a given key/value pair and returns the first matching entry
		// used to search the array of absence types
		var oDefault;
		for (var i = 0; i < aList.length; i++) {
			if (aList[i].DefaultType === true) {
				oDefault = aList[i];
				return oDefault;
			}
		}
		//if defaultLeave Type is not fount in employee's leave types throw error! can't proceed.
		if (!oDefault) {
			hcm.myleaverequest.utils.UIHelper.errorDialog(this.resourceBundle.getText("LR_DD_GENERIC_ERR"));
			jQuery.sap.log.warning("couldn't find defaultLeaveType", "_getDefaultAbsenceType", "hcm.myleaverequest.view.S1");
		}
		//fallback case: send the first item as default one
		if (aList.length > 1) {
			return aList[0];
		}
	},

	_getBalancesBusyOn: function() {
		// Removes the "used days" and "remaining days" screen elements and replaces
		// them with busy indicators while the information is read asynchronously from the back end
		//Removal and addition is not optimal so visibilities are changed!		
		this.bookedVacation.setVisible(false);
		this.byId("LRS1_BUSY_BOOKEDDAYS").setVisible(true);
		this.remainingVacation.setVisible(false);
		this.byId("LRS1_BUSY_REMAININGDAYS").setVisible(true);
	},

	_getBalancesBusyOff: function() {
		// Removes the busy indicators and replaces them with the "used days" and "remaining days"
		// screen elements as soon as the asynchronous calls to get the information are finished
		//Removal and addition is not optimal so visibilities are changed!
		this.bookedVacation.setVisible(true);
		this.byId("LRS1_BUSY_BOOKEDDAYS").setVisible(false);
		this.remainingVacation.setVisible(true);
		this.byId("LRS1_BUSY_REMAININGDAYS").setVisible(false);
	},

	_leaveTypeDependantSettings: function(lt) {
		/* Time input visibility is controlled based leaveType selected */
		var oConfig = hcm.myleaverequest.utils.DataManager.getCachedModelObjProp("DefaultConfigurations");
		var oCustomData;
		if (lt && lt.AllowedDurationPartialDayInd) {
			if (this.timeInputElem && this.byId("LRS4_FELEM_ABSENCE") && oConfig) {
				this.timeInputElem.setVisible(oConfig.RecordInClockTimesAllowedInd);
				this.byId("LRS4_FELEM_ABSENCE").setVisible(oConfig.RecordInClockHoursAllowedInd);
			}
		} else {
			if (this.timeInputElem && this.byId("LRS4_FELEM_ABSENCE")) {
				this.timeInputElem.setVisible(false);
				this.byId("LRS4_FELEM_ABSENCE").setVisible(false);
			}
		}
		if (lt) {
			this.byId("LR_FELEM_APPROVER").setVisible(lt.ApproverVisibleInd);
			this.byId("LRS4_APPROVER_NAME").setEnabled(!lt.ApproverReadOnlyInd);
			if (this.changeMode && this.oChangeModeData.ApproverEmployeeID) {
				oCustomData = new sap.ui.core.CustomData({
					"key": "ApproverEmployeeID",
					"value": this.oChangeModeData.ApproverEmployeeID
				});
				this.byId("LRS4_APPROVER_NAME").setValue(this.oChangeModeData.ApproverEmployeeName);
			} else {
				oCustomData = new sap.ui.core.CustomData({
					"key": "ApproverEmployeeID",
					"value": oConfig.DefaultApproverEmployeeID
				});
				this.byId("LRS4_APPROVER_NAME").setValue(oConfig.DefaultApproverEmployeeName);
			}
			this.byId("LRS4_APPROVER_NAME").removeAllCustomData();
			this.byId("LRS4_APPROVER_NAME").addCustomData(oCustomData);
			this.byId("LRS4_FELEM_NOTE").setVisible(lt.NoteVisibleInd);
			this.byId("LRS4_FELEM_FILEATTACHMENTS").setVisible(lt.AttachmentEnabled);
			//Reset the values
			this.timeFrom.setValue("");
			this.timeTo.setValue("");
			this.byId("LRS4_ABS_HOURS").setValue("");
			this.note.setValue("");
			this.byId("fileUploader").setValue("");
		}
	},

	_orientationDependancies: function(currentMode) {
		/*Months to be visible and layoutData is decided based on device type and orientation*/
		//backward compatibility for getLayoutData
		try {
			if (sap.ui.Device.system.phone === true) {
				if (this.cale) {
					this.cale.setMonthsToDisplay(1);
					this.cale.setMonthsPerRow(1);
				}
			} else {
				if (currentMode === "portrait") {
					if (this.byId("LRS4_FRM_CNT_CALENDAR") && this.byId("LRS4_FRM_CNT_CALENDAR").getLayoutData()) {
						this.byId("LRS4_FRM_CNT_CALENDAR").getLayoutData().setWeight(5);
					}
					if (this.cale) {
						this.cale.setMonthsToDisplay(1);
						this.cale.setMonthsPerRow(1);
					}
					if (this.formContainer && this.formContainer.getLayoutData()) {
						this.formContainer.getLayoutData().setWeight(5);
					}
				} else if (currentMode === "landscape" && this.byId("LRS4_FRM_CNT_CALENDAR").getLayoutData()) {
					if (this.byId("LRS4_FRM_CNT_CALENDAR")) {
						this.byId("LRS4_FRM_CNT_CALENDAR").getLayoutData().setWeight(6);
					}
					if (this.cale) {
						this.cale.setMonthsToDisplay(2);
						this.cale.setMonthsPerRow(2);
					}
					if (this.formContainer && this.formContainer.getLayoutData()) {
						this.formContainer.getLayoutData().setWeight(3);
					}
				}
			}
		} catch (e) {
			jQuery.sap.log.warning("Unable to set the orientation Dependancies:" + e.message, [], [
				"hcm.myleaverequest.view.S1.controller._orientationDependancies"]);
		}
	},

	_deviceDependantLayout: function() {
		// This method defines the screen layout depending on the used device.
		// The only mechanism used here to rearrange the screen elements is the line-break
		// function of the sap.ui.commons.form.Form control.
		// The initial screen layout as defined in the html view is used for phones
		try {
			if (sap.ui.Device.system.phone) {
				// ******************** PHONE start ********************
				if (this.byId("LRS4_LEGEND")) {
					this.byId("LRS4_LEGEND").setExpandable(true);
					this.byId("LRS4_LEGEND").setExpanded(false);
				}
				if (this.timeInputElem) {
					this.timeInputElem.getLayoutData().setLinebreak(true);
				}

				if (this.formContainer) {
					this.formContainer.getLayoutData().setLinebreak(true);
					this.formContainer.getLayoutData().setWeight(3);
				}
				// ******************** PHONE end ********************
			} else {
				// ******************** TABLET / PC start *******************
				// scrolling is only needed for phone - disabled on other devices
				if (this.byId("S4")) {
					this.byId("S4").setEnableScrolling(false);
				}
				// Calendar - default full day? - Cale takes up complete 1st row
				if (this.byId("LRS4_FRM_CNT_CALENDAR")) {
					this.byId("LRS4_FRM_CNT_CALENDAR").getLayoutData().setWeight(6);
				}
				if (this.cale) {
					this.cale.setMonthsToDisplay(2);
					this.cale.setMonthsPerRow(2);
				}

				if (this.formContainer) {
					this.formContainer.getLayoutData().setLinebreak(false);
					this.formContainer.getLayoutData().setWeight(3);
				}
				// Balances
				if (this.balanceElem) {
					this.balanceElem.getLayoutData().setLinebreak(false);
				}

				// Time Input
				// - default full day? - Time Input should not be shown
				if (this.timeInputElem) {
					this.timeInputElem.getLayoutData().setLinebreak(true);
					this.timeInputElem.setVisible(false);
				}

				// Note
				if (this.noteElem) {
					this.noteElem.getLayoutData().setLinebreak(true);
				}

				// Legend
				if (this.byId("LRS4_LEGEND")) {
					this.byId("LRS4_LEGEND").setExpandable(true);
					this.byId("LRS4_LEGEND").setExpanded(true);
				}
				if (this.byId("LRS4_FRM_CNT_LEGEND")) {
					this.byId("LRS4_FRM_CNT_LEGEND").getLayoutData().setLinebreak(true);
					this.byId("LRS4_FRM_CNT_LEGEND").getLayoutData().setWeight(9);
				}
				// ******************** TABLET / PC end ********************
			}

			/**
			 * @ControllerHook Extend behavior of device Dependant Layout
			 * This hook method can be used to add UI or business logic
			 * It is called when the deviceDependantLayout method executes
			 * @callback hcm.myleaverequest.view.S1~extHookDeviceDependantLayout
			 */
			if (this.extHookDeviceDependantLayout) {
				this.extHookDeviceDependantLayout();
			}
		} catch (e) {
            jQuery.sap.log.warning("Unable to set the device Dependancies:" + e.message, [], [
				"hcm.myleaverequest.view.S1.controller._deviceDependantLayout"]);
		}
	},

	_getDaysOfRange: function(startDate, endDate) {
		var _startDate = null;
		var _endDate = null;
		var aDaysOfRange = [];

		if (startDate instanceof Date) {
			_startDate = new Date(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate());
		} else if (typeof startDate === "string") {
			_startDate = new Date(startDate);
			//	_startDate = new Date(_startDate.getUTCFullYear(), _startDate.getUTCMonth(), _startDate.getUTCDate());
		}
		if (endDate instanceof Date) {
			_endDate = new Date(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate());
		} else if (typeof endDate === "string") {
			_endDate = new Date(endDate);
			//	_endDate = new Date(_endDate.getUTCFullYear(), _endDate.getUTCMonth(), _endDate.getUTCDate());
		}
		if (_endDate === null) {
			_startDate = new Date(_startDate);
			return [_startDate.toDateString()];
		} else {
			while (_startDate <= _endDate) {
				// add day to result array
				aDaysOfRange.push(_startDate.toDateString());
				// proceed to the next day
				_startDate.setTime(_startDate.getTime() + 86400000);
			}
			return aDaysOfRange;
		}
	},

	onSend: function() {
		this.submit(true);
	},

	submit: function(isSimulation) {
		// This method is called when the "send" button is tapped after entering a new leave request
		// or changing an existing one.
		// The method is called two times during one "submit" event. The first time it is called by the
		// tap event handler of the submit button. This call is done with parameter isSimulation=true. This
		// parameter is passed on to the backend where the data is checked. If the check has a positive result
		// a confirmation popup with a summary of the lr data is show. When the user confirmr this popup this function
		// is called the second time this time not in simulate mode

		var sStartDate, sStartTime, sEndDate, sEndTime;
		// reset globals
		this.bApproverOK = null;
		this.bSubmitOK = null;
		this.oSubmitResult = {};
		this.bSimulation = isSimulation;

		if (this.cale) {
			var _oStartEndDates = this._getStartEndDate(this.cale.getSelectedDates());
			// collect data for submit
			if (this.timeFrom && this.timeTo && this.leaveType.AllowedDurationPartialDayInd) {
				sStartDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(_oStartEndDates.startDate) + 'T00:00:00';
				if (this.timeFrom.getValue() === "") {
					sStartTime = '000000';
				} else {
					sStartTime = this.timeFrom.getValue().substring(0, 2) + this.timeFrom.getValue().substring(3, 5) + "00";
				}
				sEndDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(_oStartEndDates.endDate) + 'T00:00:00';
				if (this.timeTo.getValue() === "") {
					sEndTime = '000000';
				} else {
					sEndTime = this.timeTo.getValue().substring(0, 2) + this.timeTo.getValue().substring(3, 5) + "00";
				}
			} else {
				sStartDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(_oStartEndDates.startDate) + 'T00:00:00';
				sStartTime = '000000';
				sEndDate = hcm.myleaverequest.utils.Formatters.DATE_YYYYMMdd(_oStartEndDates.endDate) + 'T00:00:00';
				sEndTime = '000000';
			}
			// submit leave request
			if (!this.oBusy) {
				this.oBusy = new sap.m.BusyDialog();
			}
			this.oBusy.open();
			var notes = "";
			if (this.note) { // App Designer specific: in case note field was removed
				notes = this.note.getValue();
			}
			var oNewEntry = {};
			oNewEntry.StartDate = sStartDate;
			oNewEntry.StartTime = sStartTime;
			oNewEntry.Notes = notes;
			oNewEntry.ProcessCheckOnlyInd = (isSimulation ? true : false);
			oNewEntry.AbsenceTypeCode = this.leaveType.AbsenceTypeCode;
			oNewEntry.EndDate = sEndDate;
			oNewEntry.EndTime = sEndTime;
			oNewEntry.InfoType = this.leaveType.InfoType;

			if (this.byId("LRS4_ABS_HOURS").getValue()) {
				oNewEntry.WorkingHoursDuration = this.byId("LRS4_ABS_HOURS").getValue();
			}
			if (this.byId("LRS4_APPROVER_NAME").getValue()) {
				oNewEntry.ApproverEmployeeName = this.byId("LRS4_APPROVER_NAME").getValue();
			}
			try {
				oNewEntry.ApproverEmployeeID = this.byId("LRS4_APPROVER_NAME").getCustomData()[0].getValue();
			} catch (e) {
				oNewEntry.ApproverEmployeeID = "";
			}

			if (this.changeMode) {
				// if an existing LR is changed additional data is needed to identify the lr to be changed
				oNewEntry.RequestID = this.oChangeModeData.requestID;
				oNewEntry.EmployeeID = hcm.myleaverequest.utils.UIHelper.getPernr();
				oNewEntry.ChangeStateID = this.oChangeModeData.changeStateID;
				oNewEntry.ActionCode = 2;
				oNewEntry.LeaveKey = this.oChangeModeData.leaveKey;
				oNewEntry.EmployeeID = hcm.myleaverequest.utils.UIHelper.getPernr();
				hcm.myleaverequest.utils.DataManager.changeLeaveRequest(oNewEntry, isSimulation, this.onSubmitLRCsuccess, this.onSubmitLRCfail, this.uploadFileAttachments);

			} else {
				oNewEntry.RequestID = ""; //new request- hence will be empty
				oNewEntry.EmployeeID = hcm.myleaverequest.utils.UIHelper.getPernr();
				oNewEntry.ActionCode = 1;
				hcm.myleaverequest.utils.DataManager.submitLeaveRequest(oNewEntry, isSimulation, this.onSubmitLRCsuccess, this.onSubmitLRCfail, this.uploadFileAttachments);
			}
		}

		/**
		 * @ControllerHook Extend behavior of submit
		 * This hook method can be used to add UI or business logic
		 * It is called when the submit method executes
		 * @callback hcm.myleaverequest.view.S1~extHookSubmit
		 */
		if (this.extHookSubmit) {
			this.extHookSubmit();
		}
	},

	onSubmitLRCfail: function(aErrorMessages) {
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
		_this.evalSubmitResult("submitLRC", false, {});
		_this.oBusy.close();

		/**
		 * @ControllerHook Extend behavior of request submit failure
		 * This hook method can be used to add UI or business logic
		 * It is called when the submit method executes
		 * @callback hcm.myleaverequest.view.S1~extHookOnSubmitLRCfail
		 * @param {object} ErrorMessages Object
		 * @return {object} ErrorMessages Object
		 */
		if (this.extHookOnSubmitLRCfail) {
			aErrorMessages = this.extHookOnSubmitLRCfail(aErrorMessages);
		}
		hcm.myleaverequest.utils.UIHelper.errorDialog(aErrorMessages);
	},

	onSubmitLRCsuccess: function(oResult, oMsgHeader) {
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
		/**
		 * @ControllerHook Extend behavior of request submit failure
		 * This hook method can be used to add UI or business logic
		 * It is called when the submit method executes
		 * @callback hcm.myleaverequest.view.S1~extHookOnSubmitLRCsuccess
		 * @param {object} oResult Object
		 * @param {object} oMsgHeader Object
		 * @return {object} Object with oResult and oMsgHeader
		 */
		if (this.extHookOnSubmitLRCsuccess) {
			var extResult = this.extHookOnSubmitLRCsuccess(oResult, oMsgHeader);
			oResult = extResult.oResult;
			oMsgHeader = extResult.oMsgHeader;
		}
		_this.oLRSuccessResult = oResult;
		// get approver for confirmation dialog
		if (_this.bSimulation) {
			if (oMsgHeader && oMsgHeader.severity) {
				// show the warning message in a MessageBox
				if (oMsgHeader.severity === "warning") {
					//inject the method into the native prototype for those browsers which don't support trim()
					if (typeof String.prototype.trim !== "function") {
						String.prototype.trim = function() {
							return this.replace(/^\s+|\s+$/g, '');
						};
					}
					var detailsMsg = "";
					oMsgHeader.details.forEach(function(entry) {
						detailsMsg += decodeURI(entry.message).trim() + '\r\n';
					});
					sap.ca.ui.message.showMessageBox({
							type: sap.ca.ui.message.Type.WARNING,
							message: decodeURI(oMsgHeader.message).trim(),
							details: detailsMsg
						},
						_this._fetchApprover(oResult));
				} else {
					_this._fetchApprover(oResult);
				}
			} else {
				_this._fetchApprover(oResult);
			}

		} else {
			// just for change mode - remove old day markings
			if (_this.cale && _this.changeMode) {
				var oDaysRange = _this._getDaysOfRange(_this.oChangeModeData.startDate, _this.oChangeModeData.endDate);
				_this.cale.toggleDatesType(oDaysRange, _this.oChangeModeData.evtType, false);
				_this._deleteOldDatesFromCalendarCache(oDaysRange, _this.oChangeModeData.StatusCode);
				//replace the oChangeModeData for the next change Action
				var startDate_UTC = hcm.myleaverequest.utils.Formatters.getDate(_this.oLRSuccessResult.StartDate);
				var endDate_UTC = hcm.myleaverequest.utils.Formatters.getDate(_this.oLRSuccessResult.EndDate);
				startDate_UTC = new Date(startDate_UTC.getUTCFullYear(), startDate_UTC.getUTCMonth(), startDate_UTC.getUTCDate(), 0, 0, 0);
				endDate_UTC = new Date(endDate_UTC.getUTCFullYear(), endDate_UTC.getUTCMonth(), endDate_UTC.getUTCDate(), 0, 0, 0);
				_this.oChangeModeData.requestId = _this.oLRSuccessResult.RequestID;
				_this.oChangeModeData.leaveTypeCode = _this.oLRSuccessResult.AbsenceTypeCode;
				_this.oChangeModeData.startDate = startDate_UTC.toString();
				_this.oChangeModeData.endDate = endDate_UTC.toString();
				_this.oChangeModeData.requestID = _this.oLRSuccessResult.RequestID;
				_this.oChangeModeData.noteTxt = _this.oLRSuccessResult.Notes;
				_this.oChangeModeData.startTime = _this.oLRSuccessResult.StartTime;
				_this.oChangeModeData.endTime = _this.oLRSuccessResult.EndTime;
				_this.oChangeModeData.employeeID = _this.oLRSuccessResult.EmployeeID;
				_this.oChangeModeData.changeStateID = _this.oLRSuccessResult.ChangeStateID;
				_this.oChangeModeData.leaveKey = _this.oLRSuccessResult.LeaveKey;
				_this.oChangeModeData.evtType = _this._getCaleEvtTypeForStatus(_this.oLRSuccessResult.StatusCode);
				_this.oChangeModeData.StatusCode = _this.oLRSuccessResult.StatusCode;
				_this.oChangeModeData.ApproverEmployeeID = _this.oLRSuccessResult.ApproverEmployeeID;
				_this.oChangeModeData.ApproverEmployeeName = _this.oLRSuccessResult.ApproverEmployeeName;
				_this.oChangeModeData.WorkingHoursDuration = _this.oLRSuccessResult.WorkingHoursDuration;
				_this.oChangeModeData.AttachmentDetails = _this.oLRSuccessResult.AttachmentDetails;
			}
			sap.m.MessageToast.show(_this.resourceBundle.getText("LR_SUBMITDONE", [_this.sApprover]), {
				width: "15em"
			});
			_this._clearData();
			_this._setUpLeaveTypeData(_this.slctLvType.getSelectedKey());
			_this.note.setValue("");
			if (_this.cale) {
				//temp solution
				var datesArray = _this.cale.getSelectedDates();

				var daysOfRange = _this._getDaysOfRange(_this.oLRSuccessResult.StartDate, _this.oLRSuccessResult.EndDate);
				if (!daysOfRange) {
					daysOfRange = _this._getDaysOfRange(datesArray[0], datesArray[datesArray.length - 1]);
				}
				//Updating the Calendar Cache
				for (var i = 0; i < daysOfRange.length; i++) {
					var currDate = new Date(daysOfRange[i]);
					//get the first day of month and its cache data
					var firstDayOfMonth = new Date(currDate.getFullYear(), currDate.getMonth(), 1);
					var CalCache = hcm.myleaverequest.utils.CalendarTools.oCache;
					//check if cache exists for that month
					if (CalCache.hasOwnProperty(firstDayOfMonth.toString())) {
						var currObj = CalCache[firstDayOfMonth];
						//find the date in all the other arrays and remove it
						for (var key in currObj) {
							if (currObj.hasOwnProperty(key)) {
								if (currObj[key].length > 0) {
									for (var j = 0; j < currObj[key].length; j++) {
										//direct comparison would lead to erraneous output
										//hence convert both to dates and then to sting and then compare
										if ((new Date(currObj[key][j])).toString() == (new Date(currDate)).toString()) {
											//delete currObj[key][j]; // DON'T USE because it sets it to undefined
											currObj[key].splice(j, 1);
											//delete the array if its empty || else it creates trouble in label painting
											if (currObj[key].length < 1) {
												delete currObj[key]; //use delete here, because key is not integer/index
											}
											break;
										}
									}
								}
							}
						}

						//push to Approval pending i.e., SENT array OR APPROVED array
						//if array exists already
						if (_this.oLRSuccessResult.StatusCode === "APPROVED") {
							if (currObj.hasOwnProperty("APPROVED"))
								currObj.APPROVED.push(daysOfRange[i]);
							//else create the array and push
							else {
								currObj.APPROVED = new Array(daysOfRange[i]);
							}
						} else {
							if (currObj.hasOwnProperty("SENT"))
								currObj.SENT.push(daysOfRange[i]);
							//else create the array and push
							else {
								currObj.SENT = new Array(daysOfRange[i]);
							}
						}
					}
				}
				_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type06, false);
				_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type01, false);
				_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type07, false);
				_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type04, false);
				if (sap.me.CalendarEventType.Type10) {
					_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type10, false);
				}
				if (_this.oLRSuccessResult.StatusCode === "APPROVED" || _this.oLRSuccessResult.StatusCode === "POSTED") {
					_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type01, true);
				} else {
					_this.cale.toggleDatesType(daysOfRange, sap.me.CalendarEventType.Type04, true);
				}

			}
		}
		_this.oBusy.close();
	},

	_fetchApprover: function(oLRResult) {
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
		var _oResult = {};
		if (oLRResult.ApproverEmployeeName !== "") {
			//reset to selected item. issue with binding trigger. need to check.
			_this.slctLvType.setSelectedKey(_this.leaveType.AbsenceTypeCode);

			_oResult.sApprover = _this.sApprover = oLRResult.ApproverEmployeeName;
			_this.evalSubmitResult("getApprover", true, _oResult);
			_this.evalSubmitResult("submitLRC", true, _this.oLRSuccessResult);

		} else {
			hcm.myleaverequest.utils.DataManager.getApprover(function(sApprover) {
				//reset to selected item. issue with binding trigger. need to check.
				_this.slctLvType.setSelectedKey(_this.leaveType.AbsenceTypeCode);

				_oResult.sApprover = _this.sApprover = sApprover;
				_this.evalSubmitResult("getApprover", true, _oResult);
				_this.evalSubmitResult("submitLRC", true, _this.oLRSuccessResult);

			}, function() {
				_oResult.sApprover = _this.resourceBundle.getText("LR_UNKNOWN");
				_this.evalSubmitResult("getApprover", false, _oResult);
			}, this);
		}

	},

	evalSubmitResult: function(sCaller, bSuccess, oResult) {
		// evaluate the results of two asynchronous calls (submit leave request and get approver) to decide when the
		// confirmation popup can be shown
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
		if (sCaller === "submitLRC") {
			_this.bSubmitOK = bSuccess;
			_this.oSubmitResult = oResult;
		}
		if (sCaller === "getApprover") {
			_this.bApproverOK = bSuccess;
			_this.sApprover = oResult.sApprover;
		}
		if (_this.bSubmitOK === false) {
			if (_this.oBusy) {
				_this.oBusy.close();
			}
			// errors are already shown by the caller
		} else if (_this.bSubmitOK === true) {
			if (_this.bApproverOK === false) {
				if (_this.oBusy) {
					_this.oBusy.close();
				}
				_this.callDialog(_this.oSubmitResult, _this.sApprover);
			} else if (_this.bApproverOK === true) {
				if (_this.oBusy) {
					_this.oBusy.close();
				}
				_this.callDialog(_this.oSubmitResult, _this.sApprover);
			}
		}
	},

	callDialog: function(oSimResponse, sApprover) {
		// here the confirmation dialog is created which is shown when the "send" button is clicked
		// The generic Dialog popup sap.ca.common.uilib.dialog.dialog is reused.
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();

		var _from, _to;

		if (jQuery.sap.getUriParameters().get("responderOn")) {
			if (_this.selRange.start === null) {
				try {
					_this.selRange.start = sap.me.Calendar.parseDate(_this.cale.getSelectedDates()[0]);
				} catch (e) {
					_this.selRange.start = new Date(_this.cale.getSelectedDates()[0]);
				}
			}
			_from = _this.selRange.start;
			if (_this.selRange.end === null) {
				_to = _this.selRange.start;
			} else {
				_to = _this.selRange.end;
			}
		} else {
			if (_this.leaveType.AllowedDurationPartialDayInd) {
				_from = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(oSimResponse.StartDate, "medium");
				_to = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(oSimResponse.EndDate, "medium");
				_from += " " + hcm.myleaverequest.utils.Formatters.TIME_hhmm(oSimResponse.StartTime);
				_to += " " + hcm.myleaverequest.utils.Formatters.TIME_hhmm(oSimResponse.EndTime);
			} else {
				_from = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(oSimResponse.StartDate);
				_to = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(oSimResponse.EndDate);
			}
		}

		var oSettings = {
			question: this.resourceBundle.getText("LR_CONFIRMATIONMSG", [sApprover]),
			additionalInformation: [
				{
					label: _this.resourceBundle.getText("LR_BALANCE_DEDUCTIBLE"),
					text: this.leaveType.AbsenceTypeName
					},
				{
					label: _this.resourceBundle.getText("LR_FROM"),
					text: _from
					},
				{
					label: _this.resourceBundle.getText("LR_TO"),
					text: _to
					},
				{
					label: _this.resourceBundle.getText("LR_REQUEST"),
					text: hcm.myleaverequest.utils.Formatters.adjustSeparator(oSimResponse.WorkingHoursDuration) + " " + _this.resourceBundle.getText(
						"LR_LOWERCASE_HOURS")
			    }],
			showNote: false,
			title: _this.resourceBundle.getText("LR_TITLE_SEND"),
			confirmButtonLabel: _this.resourceBundle.getText("LR_OK")
		};
		//if approver don't exist, deelete the confirmation text
		if (!sApprover || sApprover === null || sApprover === undefined) {
			delete oSettings.question;
		}
		/**
		 * @ControllerHook Modify the Dialog Content
		 * This hook method can be used to modify the dialog content
		 * It is called when the leave was submitted and oData response was received
		 * @callback hcm.myleaverequest.view.S1~extHookCallDialog
		 * @param {object} Settings Object
		 * @return {object} Settings Object
		 */
		if (this.extHookCallDialog) {
			oSettings = this.extHookCallDialog(oSettings);
		}

		sap.ca.ui.dialog.factory.confirm(oSettings, function(response) {
			if (response.isConfirmed === true) {
				_this.submit(false);
			}
		});
	},

	onSelectionChange: function(evt) {
		var selectdItem = evt.getParameter("selectedItem");
		var absenceTypeCode = selectdItem.getProperty("key");
		this._setUpLeaveTypeData(absenceTypeCode);
	},

	/*
	 * Fetches used,available,planned timeAccount for a particular absenceType
	 * Will NOT display this formElement if the timeAccount is an empty Array
	 */
	getBalancesForAbsenceType: function(sAbsenceTypeCode) {
		if (!sAbsenceTypeCode) {
			return;
		}
		this._getBalancesBusyOn();
		var _this = this;
		hcm.myleaverequest.utils.DataManager.getBalancesForAbsenceType(sAbsenceTypeCode, function(sBalancePlanned,
			sTimeUnitNamePlanned, sBalanceAvailable, sTimeUnitNameAvailable, sTimeAccountTypeName, sBalanceUsed, sBalanceTotalUsedQuantity,
			doValuesExist) {
			//hide the formElement if the values don't exist
			_this.balanceElem.setVisible(doValuesExist);
			// Success handler for DataManager.getBalancesForAbsenceType
			_this._getBalancesBusyOff();
			if (doValuesExist) {
				// create json model to bind the values to the s4 screen elements
				var json = {
					BalancePlannedQuantity: sBalancePlanned,
					BalanceAvailableQuantity: sBalanceAvailable,
					BalanceUsedQuantity: sBalanceUsed,
					BalanceTotalUsedQuantity: sBalanceTotalUsedQuantity,
					TimeUnitName: sTimeUnitNameAvailable
				};
				var oModel = new sap.ui.model.json.JSONModel(json);
				_this.getView().setModel(oModel, "TimeAccount");
				oModel.createBindingContext("/", function(oContext) {
					_this.getView().setBindingContext(oContext, "TimeAccount");
				});
			}
		}, function(aErrorMessages) {
			// Error handler for DataManager.getBalancesForAbsenceType
			_this._getBalancesBusyOff();
			hcm.myleaverequest.utils.UIHelper.errorDialog(aErrorMessages);
		}, this);
	},

	onTimeChange: function() {
		// set default value of the endTime picker based on the startTime
		var _endTime = this.byId("LRS4_DAT_ENDTIME").getValue();
		var _startTime = this.byId("LRS4_DAT_STARTTIME").getValue();

		if (this.byId("LRS4_DAT_ENDTIME") && _endTime === "" && _startTime !== "") {
			this.byId("LRS4_DAT_ENDTIME").setValue(_startTime);
		}
		if (this.byId("LRS4_DAT_STARTTIME") && _endTime !== "" && _startTime === "") {
			this.byId("LRS4_DAT_STARTTIME").setValue(_endTime);
		}

	},

	onSendClick: function() {
		this.submit(true);
	},

	onCancelClick: function() {
		if (!this.changeMode) {
			this._isLocalReset = true;
			this._clearData();
			hcm.myleaverequest.utils.CalendarTools.clearCache();
			this._setHighlightedDays(this.cale.getCurrentDate());
		} else {
			this.oRouter.navTo("master");
		}
	},

	onEntitlementClick: function() {
		this.oRouter.navTo("entitlements", {});
	},

	onHistoryClick: function() {
		this.oRouter.navTo("master", {});
	},

	handleValueHelp: function() {
		var _this = this;
		var DialogHeader = _this.resourceBundle.getText("LR_APPROVER");
		var oSelectDialog = new sap.m.SelectDialog({
			title: DialogHeader,
			search: _this._searchAction
		});
		oSelectDialog.open();
	},
	_searchAction: function(evt) {
		var _this = this;
		if (evt.getParameter('value').length > 0 || !isNaN(evt.getParameter('value'))) {
			sap.ca.ui.utils.busydialog.requireBusyDialog();
			var successCall = function(oData) {
				//delete the unwanted results
				for (var i = 0; i < oData.results.length; i++) {
					if (oData.results[i].ApproverEmployeeID === "00000000") {
						delete oData.results[i];
					}
				}
				var oModel = new sap.ui.model.json.JSONModel(oData);
				sap.ca.ui.utils.busydialog.releaseBusyDialog();
				var itemTemplate = new sap.m.StandardListItem({
					title: "{ApproverEmployeeName}",
					description: "{ApproverEmployeeID}",
					active: "true"
				});
				_this.setModel(oModel);
				_this.bindAggregation("items", "/results", itemTemplate);
				_this.attachConfirm(function(evt) {
					var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
					var selectedItem = evt.getParameter("selectedItem");
					var oCustomData = new sap.ui.core.CustomData({
						"key": "ApproverEmployeeID",
						"value": selectedItem.getDescription()
					});
					_this.byId("LRS4_APPROVER_NAME").removeAllCustomData();
					_this.byId("LRS4_APPROVER_NAME").addCustomData(oCustomData);
					_this.byId("LRS4_APPROVER_NAME").setValue(selectedItem.getTitle());
				});
			};
			hcm.myleaverequest.utils.DataManager.searchApprover(evt.getParameter('value'), successCall);
		}
	},
	uploadFileAttachments: function(successCallback, objResponseData, objMsg) {
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
		_this.objectResponse = objResponseData;
		var oFileUploader = _this.byId("fileUploader");
		_this.ResponseMessage = objMsg;
		if (!_this.bSimulation && _this.leaveType.AttachmentEnabled && oFileUploader.getValue()) {
			var oUrl = "/LeaveRequestCollection(EmployeeID='',RequestID='" + objResponseData.RequestID +
				"',ChangeStateID=1,LeaveKey='')/LeaveRequestFileAttachment";
			oUrl = _this.oDataModel.sServiceUrl + oUrl; //appending application service URL (shouldn't e hardcoded)
			oFileUploader.setUploadUrl(oUrl);
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "slug",
				value: oFileUploader.getValue()
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: _this.oDataModel.getSecurityToken()
			}));
			oFileUploader.setSendXHR(true);
			if (oFileUploader.getValue()) {
				oFileUploader.upload();
			}
		} else {
			_this.onSubmitLRCsuccess(_this.objectResponse, _this.ResponseMessage);
		}
	},
	handleUploadComplete: function(oControlEvent) {
		var _this = hcm.myleaverequest.utils.UIHelper.getControllerInstance();
		var oParameters = oControlEvent.getParameters();
		if (parseInt(oParameters.status, 10) >= 400) {
			//handle error
			var XmlContent = jQuery.parseXML(oParameters.responseRaw);
			var error = hcm.myleaverequest.utils.DataManager.Xml2Json(XmlContent.documentElement);
			var oSettings = {
				message: error.message,
				type: sap.ca.ui.message.Type.ERROR
			};
			sap.ca.ui.message.showMessageBox(oSettings);
		}
		this.onSubmitLRCsuccess(_this.objectResponse, _this.ResponseMessage);
	},
	handleValueChange: function() {
		//do change the send button 
		jQuery.sap.log.info("fileUploaderValue changed", ["handleValueChange"], ["S1 controller"]);
	},
	_deleteOldDatesFromCalendarCache: function(daysOfRange, status) {
		try {
			for (var i = 0; i < daysOfRange.length; i++) {
				var currDate = new Date(daysOfRange[i]);
				//get the first day of month and its cache data
				var firstDayOfMonth = new Date(currDate.getFullYear(), currDate.getMonth(), 1);
				var CalCache = hcm.myleaverequest.utils.CalendarTools.oCache;
				//check if cache exists for that month
				if (CalCache.hasOwnProperty(firstDayOfMonth.toString())) {
					var currObj = CalCache[firstDayOfMonth];
					//find the date in all the other arrays and remove it
					for (var key in currObj) {
						if (key === status && currObj.hasOwnProperty(key)) {
							if (currObj[key].length > 0) {
								for (var j = 0; j < currObj[key].length; j++) {
									//direct comparison would lead to erraneous output
									//hence convert both to dates and then to sting and then compare
									if ((new Date(currObj[key][j])).toString() == (new Date(currDate)).toString()) {
										//delete currObj[key][j]; // DON'T USE because it sets it to undefined
										currObj[key].splice(j, 1);
										//delete the array if its empty || else it creates trouble in label painting
										if (currObj[key].length < 1) {
											delete currObj[key]; //use delete here, because key is not integer/index
										}
										break;
									}
								}
							}
						}
					}
				}
			}
		} catch (e) {
			jQuery.sap.log.warning("falied to update cache" + e, "_deleteOldDatesFromCalendarCache", "hcm.myleaverequest.view.S1");
		}
	},
	initializeView: function() {
		var _this = this;
		var combinedPromise = $.when(hcm.myleaverequest.utils.DataManager.getConfiguration(), hcm.myleaverequest.utils.DataManager.getAbsenceTypeCollection());
		combinedPromise.done(function(defaultType, leaveTypeColl) {
			// make sure that the leave type collection is available.
			_this.aLeaveTypes = leaveTypeColl;
			var objAbsenceTypes = {};
			objAbsenceTypes.AbsenceTypeCollection = _this.aLeaveTypes;
			_this.slctLvType.setModel(new sap.ui.model.json.JSONModel(objAbsenceTypes));
			_this.slctLvType.bindItems({
				path: "/AbsenceTypeCollection",
				template: new sap.ui.core.Item({
					key: "{AbsenceTypeCode}",
					text: "{AbsenceTypeName}"
				})
			});
			if (_this.aLeaveTypes.length > 0) {
				//var abscenceCode = _this.aLeaveTypes[0].AbsenceTypeCode;
				//_this._setUpLeaveTypeData(abscenceCode);					
				_this._setUpLeaveTypeData();
			}
		});
		combinedPromise.fail(function(error) {
			hcm.myleaverequest.utils.UIHelper.errorDialog(error);
		});
		_this._setHighlightedDays(_this.cale.getCurrentDate());
	}
});
},
	"hcm/myleaverequest/view/S1.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<!--Copyright (C) 2009-2013 SAP AG or an SAP affiliate company. All rights reserved-->\n<sap.ui.core:View id="S1" xmlns="sap.m"\n    xmlns:sap.ui.layout.form="sap.ui.layout.form" xmlns:sap.ui.layout="sap.ui.layout"\n    xmlns:sap.me="sap.me" xmlns:sap.ui.core="sap.ui.core" xmlns:ui="sap.ca.ui" xmlns:sap.ui.unified="sap.ui.unified"\n    controllerName="hcm.myleaverequest.view.S1">\n\n\t<Page id="S1_page" title="{i18n>LR_TITLE_HOME_VIEW}">\n\t\t<content>\n\t\t\t<sap.ui.layout:Grid id="LRS4_FLX_TOP" width="auto" defaultIndent="L4 M3"\n\t\t\t\tdefaultSpan="L4 M6 S12" class="s4leaveTypeSelectorFlx">\n\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t<Select id="SLCT_LEAVETYPE" change="onSelectionChange"\n\t\t\t\t\t\twidth="100%">\t\t\t\t\t\t\n\t\t\t\t\t</Select>\n\t\t\t\t</sap.ui.layout:content>\n\t\t\t</sap.ui.layout:Grid>\n\n\t\t\t<sap.ui.layout:Grid defaultSpan="L12 M12 S12"\n\t\t\t\twidth="auto">\n\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t<sap.ui.layout.form:Form id="LRS4_FRM_MAIN"\n\t\t\t\t\t\tminWidth="1024" maxContainerCols="2">\n\t\t\t\t\t\t<sap.ui.layout.form:layout>\n\t\t\t\t\t\t\t<sap.ui.layout.form:ResponsiveGridLayout\n\t\t\t\t\t\t\t\tlabelSpanL="3" labelSpanM="3" emptySpanL="4" emptySpanM="4"\n\t\t\t\t\t\t\t\tcolumnsL="1" columnsM="1" />\n\t\t\t\t\t\t</sap.ui.layout.form:layout>\n\n\t\t\t\t\t\t<sap.ui.layout.form:formContainers>\n\t\t\t\t\t\t\t<sap.ui.layout.form:FormContainer\n\t\t\t\t\t\t\t\tid="LRS4_FRM_CNT_CALENDAR">\n\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\n\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\tweight="6" linebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t</sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t<sap.ui.layout.form:formElements>\n\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement\n\t\t\t\t\t\t\t\t\t\tid="LRS4_FELEM_CALENDAR">\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t\t\t<sap.me:Calendar id="LRS4_DAT_CALENDAR"\n\t\t\t\t\t\t\t\t\t\t\t\tclass="s4Calendar"></sap.me:Calendar>\n\t\t\t\t\t\t\t\t\t\t\t<sap.me:CalendarLegend id="LRS4_LEGEND"         \n                                                class="s4LEGEND" legendWidth="18em">                                \n                                                <sap.me:layoutData>\n                                                <sap.ui.layout:ResponsiveFlowLayoutData\n                                                    id="LRS4_LYO_LEGEND" minWidth="30" weight="15"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                                </sap.me:layoutData>\n                                            </sap.me:CalendarLegend>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t</sap.ui.layout.form:formElements>\n\t\t\t\t\t\t\t</sap.ui.layout.form:FormContainer>\n\t\t\t\t\t\t\t<sap.ui.layout.form:FormContainer\n\t\t\t\t\t\t\t\tid="LRS4_FRM_CNT_BALANCES">\n\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\tweight="3"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t</sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t<sap.ui.layout.form:formElements>\n\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement\n\t\t\t\t\t\t\t\t\t\tid="LRS4_FELEM_BALANCES">\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:Grid width="100%"\n\t\t\t\t\t\t\t\t\t\t\t\tdefaultSpan="L6 M6 S6">\n\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:VerticalLayout id="LRS4_TXT_BOOKEDDAYS"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tclass="s4BalancesFlxLeft" width="100%">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<BusyIndicator id="LRS1_BUSY_BOOKEDDAYS" size= "1em" visible ="true"></BusyIndicator>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectNumber id="LRS4_TXT_BOOKED_DAYS"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tclass="s4BALANCEOBJECT" number="{TimeAccount>BalanceTotalUsedQuantity}"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tunit="{TimeAccount>TimeUnitName}" visible="false">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<FlexItemData growFactor="1"></FlexItemData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ObjectNumber>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectStatus id="LRS4_TXT_BOOKED" text="{i18n>LR_BALANCE_USED}">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<FlexItemData growFactor="1"></FlexItemData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ObjectStatus>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:VerticalLayout>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:VerticalLayout id="LRS4_TXT_REMAININGDAY"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\tclass="s4BalancesFlxRight" width="100%">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<BusyIndicator id="LRS1_BUSY_REMAININGDAYS" size= "1em" visible ="true"></BusyIndicator>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectNumber id="LRS4_TXT_REMAINING_DAYS"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tclass="s4BALANCEOBJECT" number="{TimeAccount>BalanceAvailableQuantity}"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tunit="{TimeAccount>TimeUnitName}" visible="false">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<FlexItemData growFactor="1"></FlexItemData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ObjectNumber>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ObjectStatus id="LRS4_TXT_REMAINING" text="{i18n>LR_BALANCE_BALANCE}">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<FlexItemData growFactor="1"></FlexItemData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ObjectStatus>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:VerticalLayout>\n\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:Grid>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement\n\t\t\t\t\t\t\t\t\t\tid="LRS4_FELEM_TIMEINPUT" visible="false">\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tlinebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t    </sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:Grid width="100%"\n\t\t\t\t\t\t\t\t\t\t\t\tdefaultSpan="L6 M6 S6">\n\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:VerticalLayout width="100%">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Label id="LRS4_LBL_STARTTIME" text="{i18n>LR_START_TIME}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<DateTimeInput id="LRS4_DAT_STARTTIME"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tchange="onTimeChange" type="Time"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tvalueFormat="HH:mm"></DateTimeInput>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:VerticalLayout>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:VerticalLayout width="100%">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Label id="LRS4_LBL_ENDTIME" text="{i18n>LR_END_TIME}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<DateTimeInput id="LRS4_DAT_ENDTIME" change="onTimeChange"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\ttype="Time" valueFormat="HH:mm"></DateTimeInput>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:VerticalLayout>\n\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:Grid>\n\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement\n\t\t\t\t\t\t\t\t\t\tid="LRS4_FELEM_ABSENCE" visible="false">\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tlinebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t    </sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t    <sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:Grid width="100%"\n\t\t\t\t\t\t\t\t\t\t\t\tdefaultSpan="L12 M12 S12">\n\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:VerticalLayout width="100%">\n\t\t\t\t\t\t\t\t\t\t\t\t\t   \t<Label id="LRS4_LBL_ABS_HOURS" text="{i18n>LR_ABS_HOURS}"></Label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<Input id="LRS4_ABS_HOURS" change="onAbsenceHoursChange" maxLength="10"></Input>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:VerticalLayout>\n\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:Grid>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement\n\t\t\t\t\t\t\t\t\t\tid="LR_FELEM_APPROVER">\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tlinebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:Grid id="LR_APPROVER" width="100%"\n\t\t\t\t\t\t\t\t\t\t\t\tdefaultSpan="L12 M12 S12">\n\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<Label id="LRS4_LBL_APPROVER" text="{i18n>LR_APPROVER}">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tlinebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<Input\n                                                        id="LRS4_APPROVER_NAME"\n                                                        type="Text"\n                                                        showSuggestion="true"\n                                                        valueHelpOnly="true"\n                                                        showValueHelp="true"\n                                                        valueHelpRequest="handleValueHelp">\n                                                             \n                                                      </Input>\n\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:Grid>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement\n\t\t\t\t\t\t\t\t\t\tid="LRS4_FELEM_NOTE">\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\tlinebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:layoutData>\n\t\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:Grid id="LRS4_NOTE" width="100%"\n\t\t\t\t\t\t\t\t\t\t\t\tdefaultSpan="L12 M12 S12">\n\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<Label id="LRS4_LBL_NOTE" text="{i18n>LR_NOTE}">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tlinebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</Label>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<TextArea id="LRS4_TXA_NOTE" class="s4Notes "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\twidth="100%" height="6rem" wrapping="None" maxLength="255">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<sap.ui.layout:ResponsiveFlowLayoutData\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tweight="8" linebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</layoutData>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</TextArea>\n\t\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:content>\n\t\t\t\t\t\t\t\t\t\t\t</sap.ui.layout:Grid>\n\t\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:fields>\n\t\t\t\t\t\t\t\t\t</sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t\t<sap.ui.layout.form:FormElement visible = "false"\n                                    id="LRS4_FELEM_FILEATTACHMENTS">\n                                        <sap.ui.layout.form:layoutData>\n                                            <sap.ui.layout:ResponsiveFlowLayoutData\n                                                linebreak="true"></sap.ui.layout:ResponsiveFlowLayoutData>\n                                        </sap.ui.layout.form:layoutData>\n                                        <sap.ui.layout.form:fields>\n                                            <sap.ui.layout:Grid id="LRS4_FILEATTACHMENTS" width="100%"\n                                                defaultSpan="L12 M12 S12">\n                                                <sap.ui.layout:content>\n                                                    <sap.ui.unified:FileUploader\n                                                          id="fileUploader"\n                                                          width="100%"\n                                                          uploadUrl=""\n                                                          placeholder="{i18n>LR_ATTACHMENT}"\n                                                          uploadOnChange="false"\n                                                          uploadComplete="handleUploadComplete"\n                                                          change="handleValueChange"\n                                                          typeMissmatch="handleTypeMissmatch"\n                                                          style="Emphasized"\n                                                          useMultipart="false"\n                                                          >\n                                                           </sap.ui.unified:FileUploader>\n                                                <UploadCollection\n                                                            id="fileupload"\n                                                            visible="false"\n                                                            uploadEnabled="false"\n                                                            editMode="false"\n                                                            items="{files>/AttachmentsCollection}">\n                                                             <UploadCollectionItem\n                                                             contributor= "{files>Contributor}"\n                                                             documentId="{files>DocumentId}"\n                                                             enableDelete="false"\n                                                             enableEdit="false"\n                                                             url="{files>FileUrl}"\n                                                             mimeType="{files>MimeType}"\n                                                             fileName="{files>FileName}"\n                                                             fileSize="{files>FileSize}"\n                                                             uploadedDate="{files>UploadedDate}"\n                                                             > </UploadCollectionItem>\n                                                          </UploadCollection>\n                                                    </sap.ui.layout:content> \n                                            </sap.ui.layout:Grid>\n                                        </sap.ui.layout.form:fields>\n                                    </sap.ui.layout.form:FormElement>\n\t\t\t\t\t\t\t\t\t<!-- extension point for additional fields -->\n\t\t\t\t\t\t\t\t\t<sap.ui.core:ExtensionPoint name="extS1Field"></sap.ui.core:ExtensionPoint>\n\t\t\t\t\t\t\t\t</sap.ui.layout.form:formElements>\n\t\t\t\t\t\t\t</sap.ui.layout.form:FormContainer>\n\t\t\t\t\t\t</sap.ui.layout.form:formContainers>\n\t\t\t\t\t\t<sap.ui.layout.form:layout>\n\t\t\t\t\t\t\t<sap.ui.layout.form:ResponsiveLayout\n\t\t\t\t\t\t\t\tid="LRS4_FRM_MAIN_LAYOUT"></sap.ui.layout.form:ResponsiveLayout>\n\t\t\t\t\t\t</sap.ui.layout.form:layout>\n\t\t\t\t\t</sap.ui.layout.form:Form>\n\t\t\t\t</sap.ui.layout:content>\n\t\t\t</sap.ui.layout:Grid>\n\t\t</content>\n\t</Page>\n</sap.ui.core:View>',
	"hcm/myleaverequest/view/S2.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
jQuery.sap.require("hcm.myleaverequest.utils.ConcurrentEmployment");
/*global hcm:true*/
sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.myleaverequest.view.S2", {

	extHookChangeFooterButtons: null,	
	extHookTimeAccountCollection : null,
	
	onInit : function() {

		sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
        this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();

		this.entitlementTableCntrl = this.byId("entitlemntTble");		
		this.templateCntrl = this.byId("LRS2_LISTITEM");

		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);

		hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
		hcm.myleaverequest.utils.Formatters.init(this.resourceBundle);
	},
	
	_handleRouteMatched : function(oEvent){
		if(oEvent.getParameter("name") === "entitlements"){	
			var _this = this;
			var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			if (oPernr) {
					_this.initializeEntitlementView();
				}
			else{
			    hcm.myleaverequest.utils.ConcurrentEmployment.getCEEnablement(this, function() {
				_this.initializeEntitlementView();
			});
			}
			
		}
	},
	initializeEntitlementView: function(){
	    var _this = this;
	    sap.ca.ui.utils.busydialog.requireBusyDialog();	
	    hcm.myleaverequest.utils.DataManager.getTimeAccountCollection(function(response) {			
				sap.ca.ui.utils.busydialog.releaseBusyDialog();
				
				/**
		     * @ControllerHook Modify the TimeAccountCollection response
		     * This hook method can be used to modify the TimeAccountCollection
		     * It is called when the method getTimeAccountCollection in DataManager executes
		     * @callback hcm.myleaverequest.view.S2~extHookTimeAccountCollection
		     * @param {object} TimeAccountCollection Object
		     * @return {object} TimeAccountCollection Object
		     */
				if(this.extHookTimeAccountCollection) {
					response = this.extHookTimeAccountCollection(response);
				}
			  _this.entitlementTableCntrl.setModel(new sap.ui.model.json.JSONModel(response));		   
			  _this.entitlementTableCntrl.bindItems("/TimeAccountCollection", _this.templateCntrl);
			}, function(objResponse) {
					sap.ca.ui.utils.busydialog.releaseBusyDialog();
					hcm.myleaverequest.utils.UIHelper.errorDialog(hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse));
			});
	},

	getHeaderFooterOptions : function() {
		var objHdrFtr = {
			sI18NFullscreenTitle : "LR_TITLE_BALANCE_VIEW"
			/*onBack: jQuery.proxy(function() {
				//Check if a navigation to master is the previous entry in the history
				var sDir = sap.ui.core.routing.History.getInstance().getDirection(this.oRouter.getURL("home"));
				if (sDir === "Backwards") {
					window.history.go(-1);
				} else {
					//we came from somewhere else - create the master view
					this.oRouter.navTo("home");
				}
			}, this)*/
		};
		var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHdrFtr.bSuppressBookmarkButton = true;
		}
		
		/**
         * @ControllerHook Modify the footer buttons
         * This hook method can be used to add and change buttons for the detail view footer
         * It is called when the decision options for the detail item are fetched successfully
         * @callback hcm.myleaverequest.view.S2~extHookChangeFooterButtons
         * @param {object} Header Footer Object
         * @return {object} Header Footer Object
         */
    	
    	if (this.extHookChangeFooterButtons) {
    		objHdrFtr = this.extHookChangeFooterButtons(objHdrFtr);
    	}
    	return objHdrFtr;
	}
});
},
	"hcm/myleaverequest/view/S2.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<!--Copyright (C) 2009-2013 SAP AG or an SAP affiliate company. All rights reserved-->\n<core:View id="S2" xmlns:core="sap.ui.core"\n    xmlns="sap.m" xmlns:sap.ui.layout="sap.ui.layout" controllerName="hcm.myleaverequest.view.S2">\n\n   <Page id="S2_page" >\n        <content>\n            <Table id="entitlemntTble" items="{TimeAccountCollection}">\n                <ColumnListItem id="LRS2_LISTITEM">\n                        <cells>\n                              <sap.ui.layout:VerticalLayout width="100%">\n                                \n                                    <ObjectIdentifier id="LRS2_LIST_ITEM_ACCOUNT" title="{TimeAccountTypeName}" badgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n                                        <sap.ui.layout:HorizontalLayout id="LRS2_HBOX1">\n                                       \n                                            <ObjectIdentifier text="{i18n>LR_UP_TO}" hAlign="Left" badgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n                                            <Label width="1em"></Label>\n                                            <ObjectIdentifier id="LRS2_LIST_ITEM_END_DATE" hAlign="Center" text="{path:\'DeductionEndDate\', formatter:\'hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy\'}" badgeNotes="false" badgePeople="false" badgeAttachments="false"></ObjectIdentifier>\n                                        \n                                        </sap.ui.layout:HorizontalLayout>\n                              </sap.ui.layout:VerticalLayout>\n                            <ObjectNumber number="{path:\'BalanceAvailableQuantity\', formatter:\'hcm.myleaverequest.utils.Formatters.BALANCE\'}" numberUnit="{TimeUnitName}"></ObjectNumber>\n                            <ObjectNumber number="{parts: [{path:\'BalanceUsedQuantity\'},{path: \'BalanceApprovedQuantity\'},{path: \'BalanceRequestedQuantity\'}], formatter:\'hcm.myleaverequest.utils.Formatters.calculateUsed\'}" numberUnit="{TimeUnitName}"></ObjectNumber>\n                            <ObjectNumber number="{path:\'BalanceEntitlementQuantity\', formatter:\'hcm.myleaverequest.utils.Formatters.BALANCE\'}" numberUnit="{TimeUnitName}"></ObjectNumber>\n                            <!-- extension point for additional Column Item -->\n                            <core:ExtensionPoint name="extS2ColItem"></core:ExtensionPoint>\n                        </cells>\n                </ColumnListItem>               \n                <columns>\n                    <Column width="19em">\n                        <header>\n                            <Label text="{i18n>LR_BALANCE_DEDUCTIBLE}"></Label>\n                        </header>\n                    </Column>\n                    <Column hAlign="Right" minScreenWidth="small" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>LR_BALANCE_BALANCE}"></Label>\n                        </header>\n                    </Column>\n                    <Column hAlign="Right" minScreenWidth="small" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>LR_BALANCE_USED}"></Label>\n                        </header>\n                    </Column>\n                    <Column hAlign="Right" minScreenWidth="small" demandPopin="true">\n                        <header>\n                            <Label text="{i18n>LR_ENTITLEMENT_QUOTA}"></Label>\n                        </header>\n                    </Column>\n                    <!-- extension point for additional Column Header -->\n                    <core:ExtensionPoint name="extS2ColHeader"></core:ExtensionPoint>\n                </columns>\n            </Table>\n        </content>\n    </Page>\n</core:View>',
	"hcm/myleaverequest/view/S3.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("hcm.myleaverequest.utils.ConcurrentEmployment");
jQuery.sap.require("sap.m.ObjectAttribute");
/*global hcm window*/
sap.ca.scfld.md.controller.ScfldMasterController.extend("hcm.myleaverequest.view.S3", {

	extHookChangeFooterButtons: null,
	extHookLeaveRequestCollection : null,
	extHookItemTemplate : null,
	
	onInit : function() {
		sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
		hcm.myleaverequest.utils.Formatters.init(this.resourceBundle);
		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
		this.masterListCntrl = this.oView.byId("list");
		this.objLeaveRequestCollection = null;
		this.oBus = sap.ui.getCore().getEventBus();
		this.oBus.subscribe("hcm.myleaverequest.LeaveCollection", "refresh", this._initData, this);
		this.onDataLoaded();
		this._fnRefreshCompleted = null;
		this._isLocalRouting = false;
		this._isInitialized = false;
		this._isMasterRefresh = false;
		this._searchField = "";
	},

	/**
     * @public [onDataLoaded On master list loaded]
     */
    onDataLoaded: function() {
    	var that = this;
        if (that.getList().getItems().length < 1) {
            if (!sap.ui.Device.system.phone) {
            	 that.showEmptyView();
            }
           
        }
    },


	getHeaderFooterOptions : function() {
		var _this = this;
		var objHdrFtr = {
			sI18NMasterTitle : "LR_TITLE_LEAVE_REQUESTS",
			onRefresh : function(searchField, fnRefreshCompleted){
				_this._fnRefreshCompleted = fnRefreshCompleted;
				_this._searchField = searchField;
				_this._isMasterRefresh = true;
				_this._initData();
			}
		};
        var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objHdrFtr.bSuppressBookmarkButton = true;
		}
		/**
         * @ControllerHook Modify the footer buttons
         * This hook method can be used to add and change buttons for the detail view footer
         * It is called when the decision options for the detail item are fetched successfully
         * @callback hcm.myleaverequest.view.S3~extHookChangeFooterButtons
         * @param {object} Header Footer Object
         * @return {object} Header Footer Object
         */
    	
    	if (this.extHookChangeFooterButtons) {
    		objHdrFtr = this.extHookChangeFooterButtons(objHdrFtr);
    	}
    	return objHdrFtr;
	},
	
	
	_handleRouteMatched : function(oEvent) {
        var _this = this;
		// to use cached data for local routing
		if (oEvent.getParameter("name") === "master" && ((this._isLocalRouting === false) || hcm.myleaverequest.utils.UIHelper.getIsChangeAction())) {
			hcm.myleaverequest.utils.UIHelper.setIsChangeAction(false);
			//clear searchField
			if(!!this._oControlStore & !!this._oControlStore.oMasterSearchField && !!this._oControlStore.oMasterSearchField.clear){
				this._oControlStore.oMasterSearchField.clear();
			}
			var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
			if (oPernr) {
					_this._initData();
				}
			else{
			    hcm.myleaverequest.utils.ConcurrentEmployment.getCEEnablement(this, function() {
				_this._initData();
			});
			}
			
		}
		
		//reset flag
		if(oEvent.getParameter("name") === "master" && this._isLocalRouting === false){
			this._isLocalRouting = true;
		}
		
	},
		
	_initData : function(){		
		var _this = this;
		sap.ca.ui.utils.busydialog.requireBusyDialog();
		  
		  // creation of a local JSON model is required because the leave request collection in the OData model contains
			// all leave requests including change requests. In the list view, only the original requests shall be shown.
			// Change requests to the original requests shall be only reflected by adding an additional info field like e.g.
			// 'Change Pending'
			// Solution: Function getConsolidatedLeaveRequests operates on all leave requests and creates a new collection
			// result only
			// containing the original requests which have a relation to the change request leave key
		if(!hcm.myleaverequest.utils.UIHelper.getIsLeaveCollCached()){
			hcm.myleaverequest.utils.DataManager.getConsolidatedLeaveRequests(function(objResponse) {
				
				_this.objLeaveRequestCollection = objResponse.LeaveRequestCollection;
				
				/**
		     * @ControllerHook Modify the LeaveRequestCollection response
		     * This hook method can be used to modify the LeaveRequestCollection
		     * It is called when the method LeaveRequestCollection in DataManager executes
		     * @callback hcm.myleaverequest.view.S3~extHookLeaveRequestCollection
		     * @param {object} LeaveRequestCollection Object
		     * @return {object} LeaveRequestCollection Object
		     */
				if(_this.extHookLeaveRequestCollection) {
					_this.objLeaveRequestCollection = _this.extHookLeaveRequestCollection(_this.objLeaveRequestCollection);
				}
				
				hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("ConsolidatedLeaveRequests",_this.objLeaveRequestCollection);
				hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(false);
				_this.setMasterListItems();
				if(_this._searchField!=="")
				{
				_this.applySearchPattern(_this._searchField);
				}
			}, function(objResponse) {

				hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse);
			});
		}
		else{
			_this.objLeaveRequestCollection=hcm.myleaverequest.utils.DataManager.getCachedModelObjProp("ConsolidatedLeaveRequests");
			hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(false);
			_this.setMasterListItems();
		}
	},
	
	//@overriding since we are using LeaveKey/RequestId as contextPath
	getDetailNavigationParameters : function(oListItem) {
		var navProperty = "";
		if(oListItem){
		var parameters = oListItem.getBindingContext(this.sModelName).getPath().substr(1).split("/");
		if((parameters.length > 1) && (this.objLeaveRequestCollection.length > parameters[1])){
			navProperty = this.objLeaveRequestCollection[parameters[1]]._navProperty;
		}
		return {
			contextPath : encodeURIComponent(navProperty)
		};
		}
	},
	
	setMasterListItems : function(){
		var _this = this;
		try{
			if (_this.objLeaveRequestCollection) {
				hcm.myleaverequest.utils.UIHelper.setRoutingProperty(_this.objLeaveRequestCollection);
				_this.objLeaveRequestCollection=hcm.myleaverequest.utils.UIHelper.getRoutingProperty();				
				var oModel = new sap.ui.model.json.JSONModel({ "LeaveRequestCollection" : _this.objLeaveRequestCollection});
				_this.oView.setModel(oModel);
				//_this._isLocalRouting = true;
				
				var itemTemplate = new sap.m.ObjectListItem(
            {
              type : "{device>/listItemType}",
               title : "{AbsenceTypeName}",
                 number : "{path:'WorkingHoursDuration', formatter:'hcm.myleaverequest.utils.Formatters.adjustSeparator'}",
                 numberUnit :_this.resourceBundle.getText("LR_LOWERCASE_HOURS"),
                 attributes : [
                                 new sap.m.ObjectAttribute(
                                               {			text : "{path:'StartDate', formatter:'hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy'}"
                                               }),
                                 new sap.m.ObjectAttribute(
                                               {
                                                      text : "{parts:[{path:'i18n>LR_HYPHEN'},{path:'WorkingDaysDuration'},{path:'StartTime'},{path:'EndDate'},{path:'EndTime'}], formatter: 'hcm.myleaverequest.utils.Formatters.FORMAT_ENDDATE'}"
                                               }) ],
                 firstStatus :  new sap.m.ObjectStatus({
                	 text : "{StatusName}",
              		 state : "{path:'StatusCode', formatter:'hcm.myleaverequest.utils.Formatters.State'}"	 
                 }), 
                 secondStatus : new sap.m.ObjectStatus({
                		 state : "Error",
                		 text : "{path:'aRelatedRequests', formatter:'hcm.myleaverequest.utils.Formatters.FORMATTER_INTRO'}"	 
                 }),
                 press : jQuery.proxy(_this._handleItemPress,_this)
        });
				
				
				/**
		     * @ControllerHook Modify the item template for list
		     * This hook method can be used to modify the itemTemplate
		     * It is called when the method setMasterListItems executes
		     * @callback hcm.myleaverequest.view.S3~extHookItemTemplate
		     * @param {object} itemTemplate Object
		     * @return {object} itemTemplate Object
		     */
				if(this.extHookItemTemplate) {
					itemTemplate = this.extHookItemTemplate(itemTemplate);
				}
							
				
				_this.masterListCntrl.bindItems({
					path : "/LeaveRequestCollection",
					template : itemTemplate
				});
				if(_this._fnRefreshCompleted)
				{
					_this._fnRefreshCompleted();
				}
				//sap.ca.ui.utils.busydialog.releaseBusyDialog();
			 }	
			}
			
			catch(err)
			{
				jQuery.sap.log.warning(err);

			}
			sap.ca.ui.utils.busydialog.releaseBusyDialog();
			if(!jQuery.device.is.phone && !_this._isInitialized){
				_this.registerMasterListBind(_this.masterListCntrl);						
				_this._isInitialized = true;
			}
			if(!jQuery.device.is.phone || hcm.myleaverequest.utils.UIHelper.getIsWithDrawAction()){
				
				_this.setLeadSelection();
			}
			
	},
	

	// event handler for setting the lead selection in the history overview list. Initially the first entry is
	// preselected.
	// also called when in history details a leave was withdrawn
	setLeadSelection : function() {
		var oItems = this.masterListCntrl.getItems();
		var oIndex = null, searchKey = null;
		var completeURL =  window.location.hash.split('detail');
		if(completeURL[1]!== undefined){
			completeURL= completeURL[1].split('/');
		}
		if(completeURL[1]!== undefined){
			searchKey = decodeURIComponent(completeURL[1]);
			searchKey = decodeURIComponent (searchKey);
		}
		if((searchKey !== null && searchKey !== "")&& (this.objLeaveRequestCollection)){
			for ( var i = 0; i < this.objLeaveRequestCollection.length; i++) {
				if (this.objLeaveRequestCollection[i]._navProperty === searchKey) {
					oIndex = i;
					break;
				}
			}
			if(oIndex === null){
				if(hcm.myleaverequest.utils.UIHelper.getIsWithDrawn(searchKey) && (oItems.length > 0)){
					this.setListItem(oItems[0]);
			}else{
					this.showEmptyView();
				}
	
			}else{
				if(oItems.length > oIndex){
				   this.setListItem(oItems[oIndex]);
				}
			}

		}else {
			oIndex = 0;
			if(oItems.length > 0){
				this.setListItem(oItems[oIndex]);
			}
		}		
	},
	
	
  setListItem : function(oItem) {
	  if(this._isMasterRefresh){
		  this._isMasterRefresh = false;
		  this.setLeadSelection();
	  }else{
		  if (oItem !== undefined) {
			  oItem.setSelected(true);
			  if(hcm.myleaverequest.utils.UIHelper.getIsWithDrawAction() && jQuery.device.is.phone){
				  hcm.myleaverequest.utils.UIHelper.setIsWithDrawAction(false);
				  this.oRouter.navTo("detail",this.getDetailNavigationParameters(oItem),true);
			  }else{
				  this.oRouter.navTo("detail",this.getDetailNavigationParameters(oItem),!jQuery.device.is.phone);
			  }
		  } 
		  this._isLocalRouting = true;    
	  }
  }
	

});
},
	"hcm/myleaverequest/view/S3.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<sap.ui.core:View id="S3" controllerName="hcm.myleaverequest.view.S3"\n    xmlns="sap.m"\n    xmlns:sap.ui.core="sap.ui.core" >\n    <Page>\n        <content>\n            <List id="list" mode="{device>/listMode}" select="_handleSelect">\n                 \n            </List>\n        </content>\n \n    </Page>\n</sap.ui.core:View>',
	"hcm/myleaverequest/view/S6B.controller.js":function(){/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("hcm.myleaverequest.utils.ConcurrentEmployment");
/*global hcm:true window*/
sap.ca.scfld.md.controller.BaseDetailController.extend("hcm.myleaverequest.view.S6B", {

	extHookChangeFooterButtons: null,
	extHookWithdrawDialogContent: null,
	extHookDetailView: null,

	onInit: function() {

		sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.resourceBundle = this.oApplicationFacade.getResourceBundle();
		this.oDataModel = this.oApplicationFacade.getODataModel();
		hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
		hcm.myleaverequest.utils.Formatters.init(this.resourceBundle);

		this._buildHeaderFooter();

		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
	},

	_handleRouteMatched: function(oEvent) {

		if (oEvent.getParameter("name") === "detail") {
			hcm.myleaverequest.utils.DataManager.init(this.oDataModel, this.resourceBundle);
			oEvent.getParameter("arguments").contextPath = decodeURIComponent(oEvent.getParameter("arguments").contextPath);
			var _this = this;
			var contextPath = decodeURIComponent(oEvent.getParameter("arguments").contextPath);
			var indexVal = null;
			var consolidatedLeaveRequestcollection = null;
			var setDetails = function() {
				hcm.myleaverequest.utils.UIHelper.setRoutingProperty(consolidatedLeaveRequestcollection);
				consolidatedLeaveRequestcollection = hcm.myleaverequest.utils.UIHelper.getRoutingProperty();
				if (consolidatedLeaveRequestcollection !== null) {
					for (var i = 0; i < consolidatedLeaveRequestcollection.length; i++) {
						if (consolidatedLeaveRequestcollection[i]._navProperty === contextPath) {
							indexVal = i;
							break;
						}
					}
				}
				var curntLeaveRequest = consolidatedLeaveRequestcollection[indexVal];

				if (curntLeaveRequest) {
					_this.currntObj = curntLeaveRequest;

					var cntrlObjectHeader = _this.byId("LRS6B_HEADER");
					var cntrlNotesTab = _this.byId("LRS6B_ICNTABBAR");

					var lblOrigDate = _this.byId("LRS6B_LBL_ORIGINAL_DATE");
					var hdrStartDate = _this.byId("LRS6B_HEADER_START_DATE");
					var hdrEndDate = _this.byId("LRS6B_HEADER_END_DATE");
					var lblChngedDate = _this.byId("LRS6B_LBL_CHANGED_DATE");
					var hdrNewStartDate = _this.byId("LRS6B_NEW_HEADER_START_DATE");
					var hdrNewEndDate = _this.byId("LRS6B_NEW_HEADER_END_DATE");
					var hdrStatus = _this.byId("LRS6B_HEADER_STATUS");
					var hdrStatus2 = _this.byId("LRS6B_HEADER_STATUS2");
					if (_this.currntObj.Notes === "") {
						cntrlNotesTab.setVisible(false);
					} else {
						cntrlNotesTab.setVisible(true);
					}
					cntrlObjectHeader.setTitle(curntLeaveRequest.AbsenceTypeName);
					cntrlObjectHeader.setNumber(hcm.myleaverequest.utils.Formatters.adjustSeparator(curntLeaveRequest.WorkingHoursDuration));
					cntrlObjectHeader.setNumberUnit(_this.resourceBundle.getText("LR_LOWERCASE_HOURS"));

					lblOrigDate.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_VISIBILITY(curntLeaveRequest.aRelatedRequests));
					hdrStartDate.setText(hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyyLong(curntLeaveRequest.StartDate));
					hdrEndDate.setText(hcm.myleaverequest.utils.Formatters.FORMAT_ENDDATE_LONG(_this.resourceBundle.getText("LR_HYPHEN"),
						curntLeaveRequest.WorkingDaysDuration, curntLeaveRequest.StartTime, curntLeaveRequest.EndDate, curntLeaveRequest.EndTime));
					lblChngedDate.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_VISIBILITY(curntLeaveRequest.aRelatedRequests));
					hdrNewStartDate.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_START_DATE_VISIBILITY(curntLeaveRequest.aRelatedRequests));
					hdrNewStartDate.setText(hcm.myleaverequest.utils.Formatters.FORMAT_RELATED_START_DATE_LONG(curntLeaveRequest.aRelatedRequests));
					hdrNewEndDate.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_END_DATE_VISIBILITY(curntLeaveRequest.aRelatedRequests));
					hdrNewEndDate.setText(hcm.myleaverequest.utils.Formatters.FORMAT_RELATED_END_DATE_LONG(_this.resourceBundle.getText("LR_HYPHEN"),
						curntLeaveRequest.aRelatedRequests));
					hdrStatus.setText(curntLeaveRequest.StatusName);
					hdrStatus.setState(hcm.myleaverequest.utils.Formatters.State(curntLeaveRequest.StatusCode));
					hdrStatus2.setText(hcm.myleaverequest.utils.Formatters.FORMATTER_INTRO(curntLeaveRequest.aRelatedRequests));
					hdrStatus2.setState("Error");
					_this.byId("LRS6B_NOTESICNTAB").setVisible(false);
                    _this.byId("S6B_NOTES_LIST").destroyItems();
                    _this.byId("LRS6B_ATTACH_ICNTAB").setVisible(false);
                    _this.byId("S6B_FILE_LIST").destroyItems();
					if (curntLeaveRequest.Notes) {
						var oDataNotes = hcm.myleaverequest.utils.Formatters._parseNotes(curntLeaveRequest.Notes);
						if (oDataNotes.NotesCollection) {
							_this.byId("LRS6B_NOTESICNTAB").setVisible(true);
							_this.byId("LRS6B_ICNTABBAR").setVisible(true);
							_this.byId("LRS6B_NOTESICNTAB").setCount(oDataNotes.NotesCollection.length);
						var oNotesModel = new sap.ui.model.json.JSONModel(oDataNotes);
						_this.byId("S6B_NOTES_LIST").setModel(oNotesModel, "notes");
						} else {
							_this.byId("LRS6B_NOTESICNTAB").setVisible(false);
							_this.byId("LRS6B_ICNTABBAR").setVisible(false);
						}
					}
					if (curntLeaveRequest.AttachmentDetails) {
						var oDataFiles = hcm.myleaverequest.utils.Formatters._parseAttachments(curntLeaveRequest.AttachmentDetails,curntLeaveRequest.RequestID,_this.oDataModel);
						if (oDataFiles.AttachmentsCollection) {
							_this.byId("LRS6B_ATTACH_ICNTAB").setCount(oDataFiles.AttachmentsCollection.length);
							_this.byId("LRS6B_ATTACH_ICNTAB").setVisible(true);
							_this.byId("LRS6B_ICNTABBAR").setVisible(true);
							var attachmentsModel = new sap.ui.model.json.JSONModel(oDataFiles);
							_this.byId("S6B_FILE_LIST").setModel(attachmentsModel, "files");
						} else {
							_this.byId("LRS6B_ATTACH_ICNTAB").setVisible(false);
						}
					}
					_this.byId("LRS6B_ICNTABBAR").rerender();
					_this._initState();
				}
			};
			consolidatedLeaveRequestcollection = hcm.myleaverequest.utils.DataManager.getCachedModelObjProp("ConsolidatedLeaveRequests");
			var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
            if (oPernr) {
			    if (consolidatedLeaveRequestcollection === undefined) {
			        hcm.myleaverequest.utils.DataManager.getConsolidatedLeaveRequests(function (objResponse) {

			            consolidatedLeaveRequestcollection = objResponse.LeaveRequestCollection;
			            hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("ConsolidatedLeaveRequests", consolidatedLeaveRequestcollection);
			            setDetails();
			            hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(true);
			        }, function (objResponse) {
			            hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse);
			        });
			    } else {
			        setDetails();
			    }
			} else {
			    hcm.myleaverequest.utils.ConcurrentEmployment.getCEEnablement(this, function () {
			        if (consolidatedLeaveRequestcollection === undefined) {
			            hcm.myleaverequest.utils.DataManager.getConsolidatedLeaveRequests(function (objResponse) {

			                consolidatedLeaveRequestcollection = objResponse.LeaveRequestCollection;
			                hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("ConsolidatedLeaveRequests", consolidatedLeaveRequestcollection);
			                setDetails();
			                hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(true);
			            }, function (objResponse) {
			                hcm.myleaverequest.utils.DataManager.parseErrorMessages(objResponse);
			            });
			        } else {
			            setDetails();
			        }
			    });
			}
			/**
			 * @ControllerHook Modify the loaded view
			 * This hook method can be used to add or change UI and business logic
			 * It is called when the route match to detail
			 * @callback hcm.myleaverequest.view.S6B~extHookDetailView
			 */
			if (this.extHookDetailView) {
				this.extHookDetailView();
			}

			//sap.ca.ui.utils.busydialog.releaseBusyDialog();
		}

	},

	/*	
	 * override BaseMasterController method in order to decode the JSONModel based contextPath
	 * Crossroads.js does not allow slashes in the navigation hash, JSON contextPath contains
	 */
	/*resolveHash : function(oEvent){
			      return URI.decode(oEvent.getParameter("arguments").contextPath);
			    },*/

	_buildHeaderFooter: function() {

		var _this = this;
		//workaround for scaffolding API
		var objOptionsHeaderFooter = {
			sI18NDetailTitle: "LR_TITLE_LEAVE_REQUEST",
			buttonList: [{
				sId: "LRS6B_BTN_CHANGE",
				sI18nBtnTxt: "LR_CHANGE",
				onBtnPressed: function(evt) {
					_this.onChange(evt);
				}
								}, {
				sId: "LRS6B_BTN_WITDHDRAW",
				sI18nBtnTxt: "LR_WITHDRAW",
				onBtnPressed: function(evt) {
					_this.onWithdraw(evt);
				}
								}],
			oAddBookmarkSettings: {
				title: _this.resourceBundle.getText("LR_TITLE_DETAILS_VIEW"),
				icon: "sap-icon://Fiori2/F0394"
			}
		};
        var m = new sap.ui.core.routing.HashChanger();
		var oUrl = m.getHash();
		if (oUrl.indexOf("Shell-runStandaloneApp") >= 0) {
			objOptionsHeaderFooter.bSuppressBookmarkButton = true;
		}    
		/**
		 * @ControllerHook Modify the footer buttons
		 * This hook method can be used to add and change buttons for the detail view footer
		 * It is called when the decision options for the detail item are fetched successfully
		 * @callback hcm.myleaverequest.view.S6B~extHookChangeFooterButtons
		 * @param {object} Header Footer Object
		 * @return {object} Header Footer Object
		 */
		if (this.extHookChangeFooterButtons) {
			objOptionsHeaderFooter = this.extHookChangeFooterButtons(objOptionsHeaderFooter);
		}

		this.setHeaderFooterOptions(objOptionsHeaderFooter);
	},

	_isChangeRequest: function(aRelatedRequests) {
		return aRelatedRequests != undefined && aRelatedRequests.length > 0 && aRelatedRequests[0].LeaveRequestType == "2";
	},

	_hasNewEndDate: function(aRelatedRequests) {
		return this._isChangeRequest(aRelatedRequests) && this._hasEndDate(aRelatedRequests[0].WorkingDaysDuration);
	},

	_hasEndDate: function(sWorkingDaysDuration) {
		return sWorkingDaysDuration != undefined && (hcm.myleaverequest.utils.Formatters.isHalfDayLeave(sWorkingDaysDuration) ||
			sWorkingDaysDuration * 1 != 1);
	},

	_initState: function() {
		var btnChngeAttr = false;
		if (!this.currntObj.RelatedRequests || this.currntObj.RelatedRequests.length < 1) {
			btnChngeAttr = this.currntObj.ActionModifyInd;
		} else if (this.currntObj.RelatedRequests) {
			if (this.currntObj.RelatedRequests[0].LeaveRequestType == "2") {
				btnChngeAttr = this.currntObj.RelatedRequests[0].ActionModifyInd;
			}
		}

		this.setBtnEnabled("LRS6B_BTN_CHANGE", btnChngeAttr);
		var btnWtDrwAttr = false;

		if (!this.currntObj.RelatedRequests || this.currntObj.RelatedRequests.length < 1) {
			btnWtDrwAttr = this.currntObj.ActionDeleteInd || this.currntObj.StatusCode === "CREATED";
		}

		this.setBtnEnabled("LRS6B_BTN_WITDHDRAW", btnWtDrwAttr);

	},

	// event handler for change button
	onChange: function() {
		var reqId = this.currntObj.RequestID;
		hcm.myleaverequest.utils.UIHelper.setIsChangeAction(true);
		if (reqId === "") {
			reqId = this.currntObj.LeaveKey;
		}
		if (reqId !== "") {
			this.oRouter.navTo("change", {
				requestID: reqId
			});
		} else {
			/*hcm.myleaverequest.utils.UIHelper.errorDialog([this.resourceBundle.getText("LR_DD_GENERIC_ERR"), 
							                                                    "hcm.myleaverequest.view.S6B",
							                                                    "_handleRouteMatched",
							                                                    "curntLeaveRequest is null"]);*/
			jQuery.sap.log.warning("curntLeaveRequest is null", "_handleRouteMatched", "hcm.myleaverequest.view.S6B");
		}
	},

	// event handler for withdraw button
	onWithdraw: function() {
		var _this = this;
		this.oHeader = this.byId("LRS6B_HEADER");
		var _from;
		var _to;
		var _fromTime = this.currntObj.StartTime;
		var _toTime = this.currntObj.EndTime;
		var _startDate = this.currntObj.StartDate;
		var _endDate = this.currntObj.EndDate;
		var _absenceType = this.currntObj.AbsenceTypeName;

		if (_fromTime === "000000" && _toTime === "000000") {
			_from = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(_startDate);
			_to = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(_endDate);
		} else {
			_from = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(_startDate, "medium");
			_to = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(_endDate, "medium");
			_from += " " + hcm.myleaverequest.utils.Formatters.TIME_hhmm(_fromTime);
			_to += " " + hcm.myleaverequest.utils.Formatters.TIME_hhmm(_toTime);
		}

		var sNumberAndUnit = null;
		if (this.oHeader) {
			sNumberAndUnit = this.oHeader.getNumber() + "  " + this.oHeader.getNumberUnit();
		} else {
			sNumberAndUnit = "-";
		}

		var oSettings = {
			question: this.resourceBundle.getText("LR_WITHDRAWNMSG"),
			additionalInformation: [{
				label: this.resourceBundle.getText("LR_BALANCE_DEDUCTIBLE"),
				text: _absenceType
							}, {
				label: this.resourceBundle.getText("LR_FROM"),
				text: _from
							}, {
				label: this.resourceBundle.getText("LR_TO"),
				text: _to
							}, {
				label: this.resourceBundle.getText("LR_REQUEST"),
				text: sNumberAndUnit
							}],
			showNote: false,
			title: this.resourceBundle.getText("LR_TITLE_WITHDRAW"),
			confirmButtonLabel: this.resourceBundle.getText("LR_OK")
		};

		/**
		 * @ControllerHook Modify the content of withdraw dialog
		 * This hook method can be used to add and change content of withdraw dialog
		 * It is called when the onWithdraw method gets executed
		 * @callback hcm.myleaverequest.view.S6B~extHookWithdrawDialogContent
		 * @param {object} oSettings Object
		 * @return {object} oSettings Object
		 */
		if (this.extHookWithdrawDialogContent) {
			oSettings = this.extHookWithdrawDialogContent(oSettings);
		}

		sap.ca.ui.dialog.factory.confirm(oSettings, function(response) {
			if (response.isConfirmed === true) {
				_this.withdraw();
			}
		});
	},

	// withdraw leave request
	withdraw: function() {
		var _this = this;

		//sap.ca.ui.utils.busydialog.requireBusyDialog();

		var sStatusCode = this.currntObj.StatusCode;
		var sEmployeeID = this.currntObj.EmployeeID;
		var sRequestId = this.currntObj.RequestID;
		var sChangeStateID = this.currntObj.ChangeStateID;
		var sLeaveKey = this.currntObj.LeaveKey;

		hcm.myleaverequest.utils.DataManager.withdrawLeaveRequest(sStatusCode, sEmployeeID, sRequestId,
			sChangeStateID, sLeaveKey, function(response) {
				// sap.ca.ui.utils.busydialog.releaseBusyDialog();

				sap.ui.getCore().getEventBus().publish("hcm.myleaverequest.LeaveCollection", "refresh");
				hcm.myleaverequest.utils.UIHelper.setIsWithDrawn(_this.currntObj._navProperty);
				hcm.myleaverequest.utils.UIHelper.setIsWithDrawAction(true);
				sap.m.MessageToast.show(_this.resourceBundle.getText("LR_WITHDRAWDONE"));
			}, function(errorMsgs) {
				//sap.ca.ui.utils.busydialog.releaseBusyDialog();
				hcm.myleaverequest.utils.UIHelper.errorDialog(errorMsgs);
			}, this);

	}
});
},
	"hcm/myleaverequest/view/S6B.view.xml":'<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<!--Copyright (C) 2009-2013 SAP AG or an SAP affiliate company. All rights reserved-->\n<sap.ui.core:View id="S6B" controllerName="hcm.myleaverequest.view.S6B"\n    xmlns="sap.m"\n    xmlns:sap.ui.layout.form="sap.ui.layout.form"\n    xmlns:sap.ui.layout="sap.ui.layout"\n    xmlns:sap.ui.core="sap.ui.core" >\n    <Page class="sapUiFioriObjectPage">\n        <content>\n            <ObjectHeader id="LRS6B_HEADER" introActive="true" titleActive="false" iconActive="false">\n                <attributes>\n                    <ObjectAttribute id="LRS6B_LBL_ORIGINAL_DATE" text="{i18n>LR_OLD_VERSION}" active="false"></ObjectAttribute>\n                    <ObjectAttribute id="LRS6B_HEADER_START_DATE" active="false"></ObjectAttribute>\n                    <ObjectAttribute id="LRS6B_HEADER_END_DATE" active="false"></ObjectAttribute>\n                    <ObjectAttribute id="LRS6B_LBL_CHANGED_DATE" text="{i18n>LR_NEW_VERSION}" active="false"></ObjectAttribute>\n                    <ObjectAttribute id="LRS6B_NEW_HEADER_START_DATE" active="false"></ObjectAttribute>\n                   <ObjectAttribute id="LRS6B_NEW_HEADER_END_DATE" active="false"></ObjectAttribute>\n                </attributes>\n                <firstStatus>\n                    <ObjectStatus id="LRS6B_HEADER_STATUS"></ObjectStatus>\n                </firstStatus>\n                <secondStatus>\n                    <ObjectStatus id="LRS6B_HEADER_STATUS2"></ObjectStatus>\n                </secondStatus>\n                <!-- extension point for additional Header Field-->\n                <sap.ui.core:ExtensionPoint name="extS6BHeaderField"></sap.ui.core:ExtensionPoint>\n            </ObjectHeader>\n            <IconTabBar id="LRS6B_ICNTABBAR" visible="false">\n                <items>\n                    <IconTabFilter id="LRS6B_NOTESICNTAB" icon="sap-icon://notes" visible="false">\n                        <content>\n                             <sap.ui.layout:VerticalLayout\n                                width="100%">\n                                  <List id="S6B_NOTES_LIST" \n                                    items="{notes>/NotesCollection}"\n                                    inset="false"\n        \t\t\t\t\t\t\tmode="SingleSelectMaster"\n        \t\t\t\t\t\t\tshowSeparators="None"\n        \t\t\t\t\t\t\theaderDesign="Plain">\n                                    <FeedListItem\n                                      sender="{notes>Author}"\n                                      showIcon="false" \n\t\t\t                          senderActive="false" \n                                      timestamp="{notes>Timestamp}"\n                                      text="{notes>Text}" />\n                                  </List>\n                              </sap.ui.layout:VerticalLayout>\n                             </content>\n                    </IconTabFilter>  \n                    <IconTabFilter id="LRS6B_ATTACH_ICNTAB" icon="sap-icon://attachment" visible="false">\n                        <content>\n                             <sap.ui.layout:VerticalLayout\n                                width="100%">\n                                  <UploadCollection id="S6B_FILE_LIST"\n                                  uploadEnabled="false"\n                                  items="{files>/AttachmentsCollection}"\n                                  >\n                                     <UploadCollectionItem\n                                     contributor= "{files>Contributor}"\n                                     documentId="{files>DocumentId}"\n                                     enableDelete="false"\n                                     enableEdit="false"\n                                     url="{files>FileUrl}"\n                                     mimeType="{files>MimeType}"\n                                     fileName="{files>FileName}"\n                                     fileSize="{files>FileSize}"\n                                     uploadedDate="{files>UploadedDate}"\n                                     > </UploadCollectionItem>\n                                  </UploadCollection>\n                              </sap.ui.layout:VerticalLayout>\n                             </content>\n                    </IconTabFilter>  \n                    \n                    <!-- extension point for additional Icon Tab Filter-->\n                    <sap.ui.core:ExtensionPoint name="extS6BIconTab"></sap.ui.core:ExtensionPoint>\n                </items>\n            </IconTabBar>            \n        </content>\n    </Page>\n</sap.ui.core:View>'
}});
