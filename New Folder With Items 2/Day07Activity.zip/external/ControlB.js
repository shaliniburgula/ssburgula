jQuery.sap.declare("accenture.external.ControlB");
jQuery.sap.require("sap.ui.thirdparty.d3");
jQuery.sap.require("accenture.external.c3");

sap.ui.core.Control.extend("accenture.external.ControlB",
{
    init:function(){},
    metadata:{
        properties:{
            
        }
    },
    renderer: function (oRm, oControl) {      // the part creating theHTML
                       oRm.write("<div id='chart'");
                        oRm.addClass ('chart-chart');
                        oRm.writeClasses ();
                        oRm.addStyle ('width', '100%');
                        oRm.addStyle ('height', '100%');
                       oRm.writeStyles ();
                      oRm.write ('>');
                      oRm.write ('</div>');
                         },    
                         
    onAfterRendering:function(){
        var chart=c3.generate({
            data:{
                columns:[
                    ['data1',10,20,50,40,60,50],
                    ['data2',200,130,90,240,130,220],
                    ['data3',300,200,160,400,250,250],
                    ['data4',10,30,100,200,300,400],
                    ['data5',130,120,150,140,160,150],
                    ['data6',90,70,20,50,60,120]
                    ],
                    
                    type:'bar',
                    types:{
                        data3:'spline',
                        data4:'line',
                        data6:'area'
                    },
                    
                    groups:[
                        ['data1','data2']
                        ]
            }
        });
    },
        exit: function () {}
       });
    