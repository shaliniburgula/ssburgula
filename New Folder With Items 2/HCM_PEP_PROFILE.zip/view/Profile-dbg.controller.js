/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("hcm.people.profile.blocks.Notifications");
jQuery.sap.require("hcm.people.profile.blocks.TimeRecording");
jQuery.sap.require("hcm.people.profile.blocks.Vacations");
jQuery.sap.require("hcm.people.profile.blocks.Cources");
jQuery.sap.require("hcm.people.profile.blocks.Qualifications");
jQuery.sap.require("hcm.people.profile.blocks.Performance");
jQuery.sap.require("hcm.people.profile.blocks.Progression");
jQuery.sap.require("hcm.people.profile.blocks.Payslip");
jQuery.sap.require("hcm.people.profile.blocks.Salary");
jQuery.sap.require("hcm.people.profile.blocks.Notes");
jQuery.sap.require("hcm.people.profile.blocks.PersInfo");
jQuery.sap.require("hcm.people.profile.util.ConcurrentEmployment");
jQuery.sap.require("hcm.people.profile.blocks.TimeBalance");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.people.profile.view.Profile", {
	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf hcm.emp.myinfo.src.main.webapp.view.Main
	 */
	onInit: function() {

		this.oDataModel = this.oApplicationFacade.getODataModel();
		hcm.people.profile.util.UIHelper.setODataModel(this.oDataModel);
		this.notifODataModel = this.oApplicationFacade.getODataModel("NOTIFICATIONSTORE");
		hcm.people.profile.util.UIHelper.setNotifODataModel(this.notifODataModel);
		hcm.people.profile.util.UIHelper.setControllerInstance(this);

		this.resourseBundle = this.oApplicationFacade.getResourceBundle();
		hcm.people.profile.util.UIHelper.setResourceBundle(this.resourseBundle);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;

		this.ctrlObjectPageLayout = this.byId("ctrlObjectPageLayout");
		this.ctrlObjHeaderEmp = this.byId("ctlrObjHeaderEmp");
		this.pernr = null;
		this.extHookSections = null;

		/*var that = this;
		var combinedPromise = $.when(this.getEmployeeDataSet(), this.getConfigurationSet());
			
		combinedPromise.done(function(objEmployeeData,objConfigurationData){		
				that.buildHeaderUI(objEmployeeData);
		        that.buildByConfiguration(objConfigurationData);
		});
		
	    combinedPromise.fail(function(error){
			jQuery.sap.log.getLogger().error("Data fetch failed" + error.toString());
		});*/

	},
	initializeView: function() {
		var that = this;
		var combinedPromise = $.when(this.getEmployeeDataSet(), this.getConfigurationSet());

		combinedPromise.done(function(objEmployeeData, objConfigurationData) {
			that.buildHeaderUI(objEmployeeData);
			that.buildByConfiguration(objConfigurationData);
		});

		combinedPromise.fail(function(error) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + error.toString());
		});
		var imgId = this.byId("ctrlHeaderImage").getId();
		$("#" + imgId).css("border-radius", "100%");
	},
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf hcm.emp.myinfo.src.main.webapp.view.Main
	 */
	onBeforeRendering: function() {

	},

	getEmployeeDataSet: function() {
		var deferredEmployeeDataSet = $.Deferred();
		//this.oDataModel.read("EmployeeDataSet", null, null, true, function(response) {
		this.oDataModel.read("EmployeeDataSet('" + this.oApplication.pernr + "')", null, null, true, function(response) {
			deferredEmployeeDataSet.resolve(response);
		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
			deferredEmployeeDataSet.reject("Data fetch failed" + response.toString());
		});
		return deferredEmployeeDataSet.promise();
	},

	getConfigurationSet: function() {
		var deferredConfigurationSet = $.Deferred();
		this.oDataModel.read("ConfigurationSet('" + this.oApplication.pernr + "')", null, null, true, function(response) {
			deferredConfigurationSet.resolve(response);
		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
			deferredConfigurationSet.reject("Data fetch failed" + response.toString());
		});
		return deferredConfigurationSet.promise();
	},

	buildHeaderUI: function(objEmployeeData) {
		var that = this;
		that.pernr = objEmployeeData.Employeenumber;

		hcm.people.profile.util.UIHelper.setPernr(that.pernr);

		var imageURL = this.oDataModel.sServiceUrl + "/EmployeeDataSet('" + that.pernr + "')/$value";

		var ctrlHeaderImage = that.byId("ctrlHeaderImage");

		that.ctrlObjHeaderEmp.setObjectImageURI(imageURL);
		ctrlHeaderImage.setSrc(imageURL);
		ctrlHeaderImage.addStyleClass("sapHcmObjectHeaderImage");

		if (sap.ui.Device.system.desktop) {
			ctrlHeaderImage.setWidth("10rem");
			ctrlHeaderImage.setHeight("10rem");
		} else if (sap.ui.Device.system.tablet) {
			ctrlHeaderImage.setWidth("8rem");
			ctrlHeaderImage.setHeight("8rem");
		} else if (sap.ui.Device.system.phone) {
			ctrlHeaderImage.setWidth("6rem");
			ctrlHeaderImage.setHeight("6rem");
		} else {
			ctrlHeaderImage.setWidth("10rem");
			ctrlHeaderImage.setHeight("10rem");
		}

		that.ctrlObjHeaderEmp.setObjectTitle(objEmployeeData.Ename);
		that.ctrlObjHeaderEmp.setObjectSubtitle(objEmployeeData.PositionTxt);

		if (objEmployeeData.Ename) {
			that.byId("lblName").setTitle(objEmployeeData.Ename);
			that.byId("lblName").addStyleClass("sapHcmHeaderTitle");
		} else {
			that.byId("lblName").setVisible(false);
		}

		if (objEmployeeData.Employeenumber) {
			that.byId("lblEmpNo").setText(objEmployeeData.Employeenumber);
		} else {
			that.byId("lblEmpNo").setVisible(false);
		}
		if (objEmployeeData.PositionTxt) {
			that.byId("lblPosition").setText(objEmployeeData.PositionTxt);
		} else {
			that.byId("lblPosition").setVisible(false);
		}
		if (objEmployeeData.OrgunitTxt) {
			that.byId("lblOrgUnit").setText(objEmployeeData.OrgunitTxt);
		} else {
			that.byId("lblOrgUnit").setVisible(false);
		}

		if (objEmployeeData.BldingNo.trim() === "" && objEmployeeData.RoomNo.trim() === "") {
			that.byId("lblLocation").setVisible(false);
		} else {

			var seprtr1 = null;
			if (objEmployeeData.BldingNo.trim() !== "" && objEmployeeData.RoomNo.trim() !== "") {
				seprtr1 = ", ";
			} else {
				seprtr1 = "";
			}

			that.byId("lblLocation").setText(objEmployeeData.RoomNo + seprtr1 + objEmployeeData.BldingNo);
		}

		if (objEmployeeData.Phone) {
			var strPhone = objEmployeeData.Phone;
			strPhone = objEmployeeData.Phone.replace("/", "-");
			that.byId("lblPhone").setText(strPhone);
			that.empPhone = objEmployeeData.Phone;
		} else {
			that.byId("lblPhone").setVisible(false);
		}

		if (objEmployeeData.Email) {
			that.byId("lblEmail").setText(objEmployeeData.Email);
			that.empEmail = objEmployeeData.Email;
		} else {
			that.byId("lblEmail").setVisible(false);
		}

		if (objEmployeeData.City.trim() === "" && objEmployeeData.Country.trim() === "") {
			that.byId("lblCountryLocation").setVisible(false);
		} else {

			var seprtr2 = null;
			if (objEmployeeData.City.trim() !== "" && objEmployeeData.Country.trim() !== "") {
				seprtr2 = ", ";
			} else {
				seprtr2 = "";
			}
			that.byId("lblCountryLocation").setText(objEmployeeData.City + seprtr2 + objEmployeeData.Country);
		}

		if (objEmployeeData.Localtime) {
			var dateTimeInst = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				pattern: "EEEE, d MMMM, h:mm a",
				style: "medium"
			});
			that.byId("lblTime").setText(dateTimeInst.format(objEmployeeData.Localtime));
		} else {
			that.byId("lblTime").setVisible(false);
		}

	},

	onEmailClick: function(evt) {
		sap.m.URLHelper.triggerEmail(this.empEmail);
	},

	onPhoneClick: function(evt) {
		sap.m.URLHelper.triggerTel(this.empPhone);
	},

	onBackPress: function(evt) {
		window.history.go(-1);
	},

	onHierarchyPress: function() {
		var aPersData = hcm.people.profile.util.UIHelper.getCachedPersData();
		aPersData.crossAppNavFlag = true;
		this.oPersonalizer.setPersData(aPersData);
		hcm.people.profile.util.UIHelper.cachePersData(aPersData);
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				shellHash: "#Organization-lookup&/hierarchy/" + this.pernr
			}
		});
	},

	buildByConfiguration: function(configObj) {
		var that = this;

		hcm.people.profile.util.UIHelper.setConfiguration(configObj);

		if (configObj.ShowNotifications === "X" || configObj.ShowTimerecording === "X" || configObj.ShowVacation === "X") {
			var oSectionWhatsNew = new sap.uxap.ObjectPageSection({
				title: that.resourseBundle.getText("WHATS_NEW")
			});
			if (configObj.ShowNotifications === "X") {
				var oSubSectionNotif = new sap.uxap.ObjectPageSubSection({
					title: that.resourseBundle.getText("NOTIFICATIONS")
				});
				oSubSectionNotif.insertBlock(new hcm.people.profile.blocks.Notifications());
				hcm.people.profile.util.UIHelper.setSubSecNotf(oSubSectionNotif);
				oSectionWhatsNew.addSubSection(oSubSectionNotif);
			}
			if (configObj.ShowTimerecording === "X" || configObj.ShowVacation === "X" || configObj.ShowTimeBalance === "X") {
				var oSubSectionTimeAbs = new sap.uxap.ObjectPageSubSection({
					title: that.resourseBundle.getText("TIMESHEET_ABSCENCES")
				});
				if (configObj.ShowTimerecording === "X") {
					oSubSectionTimeAbs.insertBlock(new hcm.people.profile.blocks.TimeRecording(), 0);
				}
				if (configObj.ShowVacation === "X") {
					oSubSectionTimeAbs.insertBlock(new hcm.people.profile.blocks.Vacations(), 1);
				}
				if (configObj.ShowTimeBalance === "X") {
					oSubSectionTimeAbs.insertBlock(new hcm.people.profile.blocks.TimeBalance(), 2);
				}
				oSectionWhatsNew.addSubSection(oSubSectionTimeAbs);
			}

			that.ctrlObjectPageLayout.addSection(oSectionWhatsNew);
		}

		if (configObj.ShowSocialMediaInfo === "X") {
			that.oDataModel.read("EmployeeDataSet('" + that.pernr + "')/SocialMediaSet", null, null, true, function(response) {
				var ctrlSocialMediaHolder = that.byId("ctrlSocialMediaHolder");

				response.results.forEach(function(socialEntry) {
					ctrlSocialMediaHolder.addContent(new sap.m.Image({
						width: "21px",
						height: "21px",
						src: socialEntry.ImageUrl
					}));
				});

			}, function(response) {
				jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
			});
		}

		if (configObj.ShowCourse === "X" || configObj.ShowQualification === "X" || configObj.ShowPerformance === "X" || configObj.ShowProgression ===
			"X") {
			var oSectionTalent = new sap.uxap.ObjectPageSection({
				title: that.resourseBundle.getText("TALENT")
			});
			if (configObj.ShowCourse === "X") {
				var oSubSectionCource = new sap.uxap.ObjectPageSubSection({
					title: that.resourseBundle.getText("UPCOMING_COURSES"),
					mode: "Collapsed",
					showSubSectionMore: true
				});

				hcm.people.profile.util.UIHelper.setSubSecCourses(oSubSectionCource);

				oSubSectionCource.insertBlock(new hcm.people.profile.blocks.Cources());
				oSectionTalent.addSubSection(oSubSectionCource);
			}
			if (configObj.ShowQualification === "X") {
				var oSubSectionQualif = new sap.uxap.ObjectPageSubSection({
					title: that.resourseBundle.getText("QUALIFICATIONS_SKILLS")
				});

				hcm.people.profile.util.UIHelper.setSubSecQualif(oSubSectionQualif);

				oSubSectionQualif.insertBlock(new hcm.people.profile.blocks.Qualifications());
				oSectionTalent.addSubSection(oSubSectionQualif);
			}
			if (configObj.ShowPerformance === "X") {
				var oSubSectionPerf = new sap.uxap.ObjectPageSubSection({
					title: that.resourseBundle.getText("PERFORMANCE")
				});
				oSubSectionPerf.insertBlock(new hcm.people.profile.blocks.Performance());
				hcm.people.profile.util.UIHelper.setSubSecPerf(oSubSectionPerf);
				oSectionTalent.addSubSection(oSubSectionPerf);
			}

			if (configObj.ShowProgression === "X") {
				var oSubSectionProg = new sap.uxap.ObjectPageSubSection({
					title: that.resourseBundle.getText("PROGRESSION")
				});
				oSubSectionProg.insertBlock(new hcm.people.profile.blocks.Progression());
				oSectionTalent.addSubSection(oSubSectionProg);
			}

			that.ctrlObjectPageLayout.addSection(oSectionTalent);
		}

		if (configObj.ShowCompensation === "X") {
			var oSectionComp = new sap.uxap.ObjectPageSection({
				title: that.resourseBundle.getText("COMPENSATION")
			});

			var oSubSectionPay = new sap.uxap.ObjectPageSubSection({
				title: that.resourseBundle.getText("PAYSLIP")
			});
			hcm.people.profile.util.UIHelper.setSubSecPayslip(oSubSectionPay);
			oSubSectionPay.insertBlock(new hcm.people.profile.blocks.Payslip());
			oSectionComp.addSubSection(oSubSectionPay);

			var oSubSectionSal = new sap.uxap.ObjectPageSubSection({
				title: that.resourseBundle.getText("SALARY_BONUS")
			});
			oSubSectionSal.insertBlock(new hcm.people.profile.blocks.Salary());
			oSectionComp.addSubSection(oSubSectionSal);

			that.ctrlObjectPageLayout.addSection(oSectionComp);
		}

		if (configObj.ShowNotes === "X") {
			var oSectionNotes = new sap.uxap.ObjectPageSection({
				title: that.resourseBundle.getText("NOTES")
			});

			var oSubSectionNotes = new sap.uxap.ObjectPageSubSection({
				title: that.resourseBundle.getText("MY_PERSONAL_NOTES")
			});
			oSubSectionNotes.insertBlock(new hcm.people.profile.blocks.Notes());
			oSectionNotes.addSubSection(oSubSectionNotes);

			that.ctrlObjectPageLayout.addSection(oSectionNotes);
		}

		if (configObj.ShowPersonalinfo === "X") {
			var oSectionPersInfo = new sap.uxap.ObjectPageSection({
				title: that.resourseBundle.getText("PERSONAL_INFO")
			});
			hcm.people.profile.util.UIHelper.setSecPersInfo(oSectionPersInfo);

			var oSubSectionPersInfo = new sap.uxap.ObjectPageSubSection({
				id: "subSecPersInfo",
				title: ""
			});

			hcm.people.profile.util.UIHelper.setSubSecPersInfo(oSubSectionPersInfo);

			oSubSectionPersInfo.insertBlock(new hcm.people.profile.blocks.PersInfo());
			oSectionPersInfo.addSubSection(oSubSectionPersInfo);

			that.ctrlObjectPageLayout.addSection(oSectionPersInfo);
		}

		/**
		 * @ControllerHook Add sections in the Object Page Layout
		 * This hook method can be used to add and change sections
		 * It is called when the building of exting sections were done
		 * @callback hcm.people.profile.view.Profile~extHookSections
		 * @param {object} ObjectPageLayout Object
		 * @return {object} ObjectPageLayout Object
		 */
		if (that.extHookSections) {
			that.ctrlObjectPageLayout = this.extHookSections(that.ctrlObjectPageLayout);
		}

	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf hcm.emp.myinfo.src.main.webapp.view.Main
	 */
	onAfterRendering: function() {
		//Get the personalizer
		this.createPersonalizationObj();
		//Reading end user personalization data
		this.getPersonalizationData(this.oPersId);

	},

	getPersonalizationData: function(oId) {
		this.oPersonalizer
			.getPersData()
			.done(this.userPersData.bind(this))
			.fail(
				function() {

					jQuery.sap.log
						.error("Reading personalization data failed.");
				}
		);
	},

	userPersData: function(aPersData) {
		if (aPersData === undefined || aPersData.crossAppNavFlag === false) {
			if (!this.oApplication.pernr) {
				hcm.people.profile.util.ConcurrentEmployment.getCEEnablement(this, jQuery.proxy(function() {
					var aData = {
						selectedCEPernr: this.oApplication.pernr,
						crossAppNavFlag: false
					};
					this.oPersonalizer.setPersData(aData);
					hcm.people.profile.util.UIHelper.cachePersData(aData);

					this.initializeView();
				}, this));
			}
		} else {
			try {
				//set navigation status flag to false
				aPersData.crossAppNavFlag = false;
				this.oPersonalizer.setPersData(aPersData);
				hcm.people.profile.util.UIHelper.cachePersData(aPersData);
			} catch (exception) {
				//Do nothing
			}
			this.oApplication.pernr = aPersData.selectedCEPernr;
			this.initializeView();
		}
	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf hcm.emp.myinfo.src.main.webapp.view.Main
	 */
	onExit: function() {

	},

	createPersonalizationObj: function() {
		if (sap.ushell !== undefined && sap.ushell.Container !== undefined) {
			var oPersonalizationService = sap.ushell.Container.getService("Personalization");
			var oConstants = oPersonalizationService.constants;
			var oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());

			var oScope = {
				keyCategory: oConstants.keyCategory.FIXED_KEY,
				writeFrequency: oConstants.writeFrequency.LOW,
				clientStorageAllowed: true,
				validity: Infinity
			};
			this.oPersId = {
				container: "hcm.people.profile",
				item: "appPersSettings"
			};
			this.oPersonalizer = oPersonalizationService.getPersonalizer(this.oPersId, oScope, oComponent);
			hcm.people.profile.util.UIHelper.setPersonalizerInstance(this.oPersonalizer);
		}
	}
});