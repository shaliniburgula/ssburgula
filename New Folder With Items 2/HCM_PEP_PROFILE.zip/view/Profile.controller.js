/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("hcm.people.profile.blocks.Notifications");
jQuery.sap.require("hcm.people.profile.blocks.TimeRecording");
jQuery.sap.require("hcm.people.profile.blocks.Vacations");
jQuery.sap.require("hcm.people.profile.blocks.Cources");
jQuery.sap.require("hcm.people.profile.blocks.Qualifications");
jQuery.sap.require("hcm.people.profile.blocks.Performance");
jQuery.sap.require("hcm.people.profile.blocks.Progression");
jQuery.sap.require("hcm.people.profile.blocks.Payslip");
jQuery.sap.require("hcm.people.profile.blocks.Salary");
jQuery.sap.require("hcm.people.profile.blocks.Notes");
jQuery.sap.require("hcm.people.profile.blocks.PersInfo");
jQuery.sap.require("hcm.people.profile.util.ConcurrentEmployment");
jQuery.sap.require("hcm.people.profile.blocks.TimeBalance");
sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.people.profile.view.Profile", {
	onInit: function() {
		this.oDataModel = this.oApplicationFacade.getODataModel();
		hcm.people.profile.util.UIHelper.setODataModel(this.oDataModel);
		this.notifODataModel = this.oApplicationFacade.getODataModel("NOTIFICATIONSTORE");
		hcm.people.profile.util.UIHelper.setNotifODataModel(this.notifODataModel);
		hcm.people.profile.util.UIHelper.setControllerInstance(this);
		this.resourseBundle = this.oApplicationFacade.getResourceBundle();
		hcm.people.profile.util.UIHelper.setResourceBundle(this.resourseBundle);
		this.oApplication = this.oApplicationFacade.oApplicationImplementation;
		this.ctrlObjectPageLayout = this.byId("ctrlObjectPageLayout");
		this.ctrlObjHeaderEmp = this.byId("ctlrObjHeaderEmp");
		this.pernr = null;
		this.extHookSections = null;
	},
	initializeView: function() {
		var t = this;
		var c = $.when(this.getEmployeeDataSet(), this.getConfigurationSet());
		c.done(function(o, a) {
			t.buildHeaderUI(o);
			t.buildByConfiguration(a);
		});
		c.fail(function(e) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + e.toString());
		});
		var i = this.byId("ctrlHeaderImage").getId();
		$("#" + i).css("border-radius", "100%");
	},
	onBeforeRendering: function() {},
	getEmployeeDataSet: function() {
		var d = $.Deferred();
		this.oDataModel.read("EmployeeDataSet('" + this.oApplication.pernr + "')", null, null, true, function(r) {
			d.resolve(r);
		}, function(r) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
			d.reject("Data fetch failed" + r.toString());
		});
		return d.promise();
	},
	getConfigurationSet: function() {
		var d = $.Deferred();
		this.oDataModel.read("ConfigurationSet('" + this.oApplication.pernr + "')", null, null, true, function(r) {
			d.resolve(r);
		}, function(r) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
			d.reject("Data fetch failed" + r.toString());
		});
		return d.promise();
	},
	buildHeaderUI: function(o) {
		var t = this;
		t.pernr = o.Employeenumber;
		hcm.people.profile.util.UIHelper.setPernr(t.pernr);
		var i = this.oDataModel.sServiceUrl + "/EmployeeDataSet('" + t.pernr + "')/$value";
		var c = t.byId("ctrlHeaderImage");
		t.ctrlObjHeaderEmp.setObjectImageURI(i);
		c.setSrc(i);
		c.addStyleClass("sapHcmObjectHeaderImage");
		if (sap.ui.Device.system.desktop) {
			c.setWidth("10rem");
			c.setHeight("10rem");
		} else if (sap.ui.Device.system.tablet) {
			c.setWidth("8rem");
			c.setHeight("8rem");
		} else if (sap.ui.Device.system.phone) {
			c.setWidth("6rem");
			c.setHeight("6rem");
		} else {
			c.setWidth("10rem");
			c.setHeight("10rem");
		}
		t.ctrlObjHeaderEmp.setObjectTitle(o.Ename);
		t.ctrlObjHeaderEmp.setObjectSubtitle(o.PositionTxt);
		if (o.Ename) {
			t.byId("lblName").setTitle(o.Ename);
			t.byId("lblName").addStyleClass("sapHcmHeaderTitle");
		} else {
			t.byId("lblName").setVisible(false);
		} if (o.Employeenumber) {
			t.byId("lblEmpNo").setText(o.Employeenumber);
		} else {
			t.byId("lblEmpNo").setVisible(false);
		} if (o.PositionTxt) {
			t.byId("lblPosition").setText(o.PositionTxt);
		} else {
			t.byId("lblPosition").setVisible(false);
		} if (o.OrgunitTxt) {
			t.byId("lblOrgUnit").setText(o.OrgunitTxt);
		} else {
			t.byId("lblOrgUnit").setVisible(false);
		} if (o.BldingNo.trim() === "" && o.RoomNo.trim() === "") {
			t.byId("lblLocation").setVisible(false);
		} else {
			var s = null;
			if (o.BldingNo.trim() !== "" && o.RoomNo.trim() !== "") {
				s = ", ";
			} else {
				s = "";
			}
			t.byId("lblLocation").setText(o.RoomNo + s + o.BldingNo);
		} if (o.Phone) {
			var a = o.Phone;
			a = o.Phone.replace("/", "-");
			t.byId("lblPhone").setText(a);
			t.empPhone = o.Phone;
		} else {
			t.byId("lblPhone").setVisible(false);
		} if (o.Email) {
			t.byId("lblEmail").setText(o.Email);
			t.empEmail = o.Email;
		} else {
			t.byId("lblEmail").setVisible(false);
		} if (o.City.trim() === "" && o.Country.trim() === "") {
			t.byId("lblCountryLocation").setVisible(false);
		} else {
			var b = null;
			if (o.City.trim() !== "" && o.Country.trim() !== "") {
				b = ", ";
			} else {
				b = "";
			}
			t.byId("lblCountryLocation").setText(o.City + b + o.Country);
		} if (o.Localtime) {
			var d = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				pattern: "EEEE, d MMMM, h:mm a",
				style: "medium"
			});
			t.byId("lblTime").setText(d.format(o.Localtime));
		} else {
			t.byId("lblTime").setVisible(false);
		}
	},
	onEmailClick: function(e) {
		sap.m.URLHelper.triggerEmail(this.empEmail);
	},
	onPhoneClick: function(e) {
		sap.m.URLHelper.triggerTel(this.empPhone);
	},
	onBackPress: function(e) {
		window.history.go(-1);
	},
	onHierarchyPress: function() {
		var p = hcm.people.profile.util.UIHelper.getCachedPersData();
		p.crossAppNavFlag = true;
		this.oPersonalizer.setPersData(p);
		hcm.people.profile.util.UIHelper.cachePersData(p);
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				shellHash: "#Organization-lookup&/hierarchy/" + this.pernr
			}
		});
	},
	buildByConfiguration: function(c) {
		var t = this;
		hcm.people.profile.util.UIHelper.setConfiguration(c);
		if (c.ShowNotifications === "X" || c.ShowTimerecording === "X" || c.ShowVacation === "X") {
			var s = new sap.uxap.ObjectPageSection({
				title: t.resourseBundle.getText("WHATS_NEW")
			});
			if (c.ShowNotifications === "X") {
				var S = new sap.uxap.ObjectPageSubSection({
					title: t.resourseBundle.getText("NOTIFICATIONS")
				});
				S.insertBlock(new hcm.people.profile.blocks.Notifications());
				hcm.people.profile.util.UIHelper.setSubSecNotf(S);
				s.addSubSection(S);
			}
			if (c.ShowTimerecording === "X" || c.ShowVacation === "X" || c.ShowTimeBalance === "X") {
				var o = new sap.uxap.ObjectPageSubSection({
					title: t.resourseBundle.getText("TIMESHEET_ABSCENCES")
				});
				if (c.ShowTimerecording === "X") {
					o.insertBlock(new hcm.people.profile.blocks.TimeRecording(), 0);
				}
				if (c.ShowVacation === "X") {
					o.insertBlock(new hcm.people.profile.blocks.Vacations(), 1);
				}
				if (c.ShowTimeBalance === "X") {
					o.insertBlock(new hcm.people.profile.blocks.TimeBalance(), 2);
				}
				s.addSubSection(o);
			}
			t.ctrlObjectPageLayout.addSection(s);
		}
		if (c.ShowSocialMediaInfo === "X") {
			t.oDataModel.read("EmployeeDataSet('" + t.pernr + "')/SocialMediaSet", null, null, true, function(r) {
				var n = t.byId("ctrlSocialMediaHolder");
				r.results.forEach(function(p) {
					n.addContent(new sap.m.Image({
						width: "21px",
						height: "21px",
						src: p.ImageUrl
					}));
				});
			}, function(r) {
				jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
			});
		}
		if (c.ShowCourse === "X" || c.ShowQualification === "X" || c.ShowPerformance === "X" || c.ShowProgression === "X") {
			var a = new sap.uxap.ObjectPageSection({
				title: t.resourseBundle.getText("TALENT")
			});
			if (c.ShowCourse === "X") {
				var b = new sap.uxap.ObjectPageSubSection({
					title: t.resourseBundle.getText("UPCOMING_COURSES"),
					mode: "Collapsed",
					showSubSectionMore: true
				});
				hcm.people.profile.util.UIHelper.setSubSecCourses(b);
				b.insertBlock(new hcm.people.profile.blocks.Cources());
				a.addSubSection(b);
			}
			if (c.ShowQualification === "X") {
				var d = new sap.uxap.ObjectPageSubSection({
					title: t.resourseBundle.getText("QUALIFICATIONS_SKILLS")
				});
				hcm.people.profile.util.UIHelper.setSubSecQualif(d);
				d.insertBlock(new hcm.people.profile.blocks.Qualifications());
				a.addSubSection(d);
			}
			if (c.ShowPerformance === "X") {
				var e = new sap.uxap.ObjectPageSubSection({
					title: t.resourseBundle.getText("PERFORMANCE")
				});
				e.insertBlock(new hcm.people.profile.blocks.Performance());
				hcm.people.profile.util.UIHelper.setSubSecPerf(e);
				a.addSubSection(e);
			}
			if (c.ShowProgression === "X") {
				var f = new sap.uxap.ObjectPageSubSection({
					title: t.resourseBundle.getText("PROGRESSION")
				});
				f.insertBlock(new hcm.people.profile.blocks.Progression());
				a.addSubSection(f);
			}
			t.ctrlObjectPageLayout.addSection(a);
		}
		if (c.ShowCompensation === "X") {
			var g = new sap.uxap.ObjectPageSection({
				title: t.resourseBundle.getText("COMPENSATION")
			});
			var h = new sap.uxap.ObjectPageSubSection({
				title: t.resourseBundle.getText("PAYSLIP")
			});
			hcm.people.profile.util.UIHelper.setSubSecPayslip(h);
			h.insertBlock(new hcm.people.profile.blocks.Payslip());
			g.addSubSection(h);
			var i = new sap.uxap.ObjectPageSubSection({
				title: t.resourseBundle.getText("SALARY_BONUS")
			});
			i.insertBlock(new hcm.people.profile.blocks.Salary());
			g.addSubSection(i);
			t.ctrlObjectPageLayout.addSection(g);
		}
		if (c.ShowNotes === "X") {
			var j = new sap.uxap.ObjectPageSection({
				title: t.resourseBundle.getText("NOTES")
			});
			var k = new sap.uxap.ObjectPageSubSection({
				title: t.resourseBundle.getText("MY_PERSONAL_NOTES")
			});
			k.insertBlock(new hcm.people.profile.blocks.Notes());
			j.addSubSection(k);
			t.ctrlObjectPageLayout.addSection(j);
		}
		if (c.ShowPersonalinfo === "X") {
			var l = new sap.uxap.ObjectPageSection({
				title: t.resourseBundle.getText("PERSONAL_INFO")
			});
			hcm.people.profile.util.UIHelper.setSecPersInfo(l);
			var m = new sap.uxap.ObjectPageSubSection({
				id: "subSecPersInfo",
				title: ""
			});
			hcm.people.profile.util.UIHelper.setSubSecPersInfo(m);
			m.insertBlock(new hcm.people.profile.blocks.PersInfo());
			l.addSubSection(m);
			t.ctrlObjectPageLayout.addSection(l);
		}
		if (t.extHookSections) {
			t.ctrlObjectPageLayout = this.extHookSections(t.ctrlObjectPageLayout);
		}
	},
	onAfterRendering: function() {
		this.createPersonalizationObj();
		this.getPersonalizationData(this.oPersId);
	},
	getPersonalizationData: function(i) {
		this.oPersonalizer.getPersData().done(this.userPersData.bind(this)).fail(function() {
			jQuery.sap.log.error("Reading personalization data failed.");
		});
	},
	userPersData: function(p) {
		if (p === undefined || p.crossAppNavFlag === false) {
			if (!this.oApplication.pernr) {
				hcm.people.profile.util.ConcurrentEmployment.getCEEnablement(this, jQuery.proxy(function() {
					var d = {
						selectedCEPernr: this.oApplication.pernr,
						crossAppNavFlag: false
					};
					this.oPersonalizer.setPersData(d);
					hcm.people.profile.util.UIHelper.cachePersData(d);
					this.initializeView();
				}, this));
			}
		} else {
			try {
				p.crossAppNavFlag = false;
				this.oPersonalizer.setPersData(p);
				hcm.people.profile.util.UIHelper.cachePersData(p);
			} catch (e) {}
			this.oApplication.pernr = p.selectedCEPernr;
			this.initializeView();
		}
	},
	onExit: function() {},
	createPersonalizationObj: function() {
		if (sap.ushell !== undefined && sap.ushell.Container !== undefined) {
			var p = sap.ushell.Container.getService("Personalization");
			var c = p.constants;
			var C = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var s = {
				keyCategory: c.keyCategory.FIXED_KEY,
				writeFrequency: c.writeFrequency.LOW,
				clientStorageAllowed: true,
				validity: Infinity
			};
			this.oPersId = {
				container: "hcm.people.profile",
				item: "appPersSettings"
			};
			this.oPersonalizer = p.getPersonalizer(this.oPersId, s, C);
			hcm.people.profile.util.UIHelper.setPersonalizerInstance(this.oPersonalizer);
		}
	}
});