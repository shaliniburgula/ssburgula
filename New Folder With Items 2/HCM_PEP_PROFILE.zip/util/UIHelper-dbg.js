/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.util.UIHelper");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");

hcm.people.profile.util.UIHelper = (function() {

	var _notifODataModel = null;
	var _oDataModel = null;
	var _resourceBundle = null;
	var _configuration = null;
	var _prnr = null;
	var _objSubSecPersInfo = null;
	var _objSecPersInfo = null;
	var _objSubSecCourses = null;
	var _objDataCourses = null;
	var _objSubSecPayslip = null;
	var _objDataPayslip = null;
	var _objSubSecQualif = null;
	var _objDataQualif = null;
	var _objSubSecPerf = null;
	var _objDataPerf = null;
	var _objSubSecNotf = null;
	var _objDataNotf = null;
	var _oController = null;
	var _oPersonalizer = null;
	var _oPersData = null;

	return {

		setNotifODataModel: function(notifODataModel) {
			_notifODataModel = notifODataModel;
		},

		getNotifODataModel: function() {
			return _notifODataModel;
		},

		setODataModel: function(oDataModel) {
			_oDataModel = oDataModel;
		},

		getODataModel: function() {
			return _oDataModel;
		},

		setResourceBundle: function(resourceBundle) {
			_resourceBundle = resourceBundle;
		},

		getResourceBundle: function() {
			return _resourceBundle;
		},

		setConfiguration: function(configuration) {
			_configuration = configuration;
		},

		getConfiguration: function() {
			return _configuration;
		},

		setPernr: function(prnr) {
			_prnr = prnr;
		},

		getPernr: function() {
			return _prnr;
		},

		cachePersData: function(oPersData) {
			_oPersData = oPersData;
		},

		getCachedPersData: function() {
			return _oPersData;
		},

		setPersonalizerInstance: function(personalizer) {
			_oPersonalizer = personalizer;
		},
		getPersonalizerInstance: function() {
			return _oPersonalizer;
		},

		setControllerInstance: function(self) {
			_oController = self;
		},

		getControllerInstance: function() {
			return _oController;
		},

		setSubSecPersInfo: function(objSubSecPersInfo) {
			_objSubSecPersInfo = objSubSecPersInfo;
		},

		getSubSecPersInfo: function() {
			return _objSubSecPersInfo;
		},

		setSubSecCourses: function(objSubSeccourses) {
			_objSubSecCourses = objSubSeccourses;
		},

		getSubSecCourses: function() {
			return _objSubSecCourses;
		},

		setDataCourses: function(objDataCourses) {
			_objDataCourses = objDataCourses;
		},

		getDataCourses: function() {
			return _objDataCourses;
		},

		setSubSecPayslip: function(objSubSecPayslip) {
			_objSubSecPayslip = objSubSecPayslip;
		},

		getSubSecPayslip: function() {
			return _objSubSecPayslip;
		},

		setDataPayslip: function(objDataPayslip) {
			_objDataPayslip = objDataPayslip;
		},

		getDataPayslip: function() {
			return _objDataPayslip;
		},

		setSubSecQualif: function(objSubSecQualif) {
			_objSubSecQualif = objSubSecQualif;
		},

		getSubSecQualif: function() {
			return _objSubSecQualif;
		},

		setDataQualif: function(objDataQualif) {
			_objDataQualif = objDataQualif;
		},

		getDataQualif: function() {
			return _objDataQualif;
		},

		setSubSecPerf: function(objSubSecPerf) {
			_objSubSecPerf = objSubSecPerf;
		},

		getSubSecPerf: function() {
			return _objSubSecPerf;
		},

		setDataPerf: function(objDataPerf) {
			_objDataPerf = objDataPerf;
		},

		getDataPerf: function() {
			return _objDataPerf;
		},

		setSubSecNotf: function(objSubSecNotf) {
			_objSubSecNotf = objSubSecNotf;
		},

		getSubSecNotf: function() {
			return _objSubSecNotf;
		},

		setDataNotf: function(objDataNotf) {
			_objDataNotf = objDataNotf;
		},

		getDataNotf: function() {
			return _objDataNotf;
		},

		setSecPersInfo: function(objSecPersInfo) {
			_objSecPersInfo = objSecPersInfo;
		},

		getSecPersInfo: function() {
			return _objSecPersInfo;
		},

		formatDate: function(oDate, isUTC) {
			var oDateFormat = sap.ca.ui.model.format.DateFormat.getDateInstance({
				style: "medium"
			});
			if (oDate !== null && oDate !== undefined) {
				if (isUTC !== undefined) {
					return oDateFormat.format(oDate, isUTC);
				} else {
					return oDateFormat.format(oDate, true);
				}
			}
		},

		formatTime: function(oDate, isUTC) {
			var oDateFormat = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				style: "medium"
			});
			if (oDate !== null && oDate !== undefined) {
				if (isUTC !== undefined) {
					return oDateFormat.format(oDate, isUTC);
				} else {
					return oDateFormat.format(oDate, true);
				}
			}
		},

		formatNumber: function(oValue) {
			var numberFormatter = sap.ca.ui.model.format.NumberFormat.getInstance();
			return numberFormatter.format(oValue);
		},

		sortArrayByProperty: function(array, propertyName) {
			function dynamicSort(property) {
				var sortOrder = 1;
				if (property[0] === "-") {
					sortOrder = -1;
					property = property.substr(1);
				}
				return function(a, b) {
					var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
					return result * sortOrder;
				};
			}

			return array.sort(dynamicSort(propertyName));

		},

		buildTimePeriod: function(beginDate, endDate, isFullRange) {
			var monthInst = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				pattern: "MMM",
				style: "medium"
			});
			var strBeginYear = beginDate.getFullYear();
			var strBeginMnth = beginDate.getMonth();
			var strBeginMnthFrmt = monthInst.format(beginDate);
			var strBeginDate = beginDate.getDate();

			var strEndYear = endDate.getFullYear();
			var strEndMnth = endDate.getMonth();
			var strEndMnthFrmt = monthInst.format(endDate);
			var strEndDate = endDate.getDate();

			var endPlusDate = new Date(endDate);
			endPlusDate.setDate(endDate.getDate() + 1);

			var strEndPlusMnth = endPlusDate.getMonth();
			var strEndPlusDate = endPlusDate.getDate();

			if (isFullRange) {

				if ((strBeginDate === strEndDate) && (strBeginMnth === strEndMnth) && (strBeginYear === strEndYear)) {
					strBeginDate = "";
					strBeginMnth = "";
					strBeginYear = "";
					strEndMnth = strEndMnthFrmt;
				} else if ((strBeginMnth === strEndMnth) && (strBeginYear === strEndYear)) {
					strBeginMnth = "";
					strBeginYear = "";
					strEndMnth = strEndMnthFrmt;
				} else if ((strBeginYear === strEndYear)) {
					strBeginYear = "";
					strBeginMnth = strBeginMnthFrmt;
					strEndMnth = strEndMnthFrmt;
				} else {
					strBeginMnth = strBeginMnthFrmt;
					strEndMnth = strEndMnthFrmt;
				}

			} else {

				if (strBeginYear === strEndYear) {
					strBeginYear = "";
				}

				if ((strBeginMnth === strEndPlusMnth) && (strBeginDate === strEndPlusDate)) {
					strBeginMnth = "";
					strEndMnth = "";
					strBeginDate = "";
					strEndDate = "";
				} else {
					strBeginMnth = strBeginMnthFrmt;
					strEndMnth = strEndMnthFrmt;
				}

				if (strBeginDate === strEndPlusDate) {
					strBeginDate = "";
					strEndDate = "";
				}

			}

			var strFullBegin = strBeginDate + " " + strBeginMnth + " " + strBeginYear;
			var strFullEnd = strEndDate + " " + strEndMnth + " " + strEndYear;

			var isBeginDateFull = false;
			if ((strBeginDate !== "") && (strBeginMnth !== "") && (strBeginYear !== "")) {
				isBeginDateFull = true;
			}

			var isEndDateFull = false;
			if ((strEndDate !== "") && (strEndMnth !== "") && (strEndYear !== "")) {
				isEndDateFull = true;
			}

			if (isBeginDateFull && isEndDateFull) {
				strFullBegin = this.formatDate(beginDate);
				strFullEnd = this.formatDate(endDate);
			}

			if (strFullBegin.trim() !== "") {
				strFullBegin = strFullBegin + " - ";
			} else if (isFullRange) {
				strFullEnd = this.formatDate(endDate);
			}

			return strFullBegin + strFullEnd;
		}

	};

}());