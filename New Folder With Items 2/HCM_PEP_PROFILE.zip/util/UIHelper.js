/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.util.UIHelper");
jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
hcm.people.profile.util.UIHelper = (function() {
	var _ = null;
	var c = null;
	var d = null;
	var e = null;
	var f = null;
	var g = null;
	var h = null;
	var i = null;
	var j = null;
	var k = null;
	var l = null;
	var m = null;
	var n = null;
	var o = null;
	var p = null;
	var q = null;
	var r = null;
	var s = null;
	var t = null;
	var u = null;
	return {
		setNotifODataModel: function(a) {
			_ = a;
		},
		getNotifODataModel: function() {
			return _;
		},
		setODataModel: function(D) {
			c = D;
		},
		getODataModel: function() {
			return c;
		},
		setResourceBundle: function(a) {
			d = a;
		},
		getResourceBundle: function() {
			return d;
		},
		setConfiguration: function(a) {
			e = a;
		},
		getConfiguration: function() {
			return e;
		},
		setPernr: function(a) {
			f = a;
		},
		getPernr: function() {
			return f;
		},
		cachePersData: function(P) {
			u = P;
		},
		getCachedPersData: function() {
			return u;
		},
		setPersonalizerInstance: function(a) {
			t = a;
		},
		getPersonalizerInstance: function() {
			return t;
		},
		setControllerInstance: function(a) {
			s = a;
		},
		getControllerInstance: function() {
			return s;
		},
		setSubSecPersInfo: function(a) {
			g = a;
		},
		getSubSecPersInfo: function() {
			return g;
		},
		setSubSecCourses: function(a) {
			i = a;
		},
		getSubSecCourses: function() {
			return i;
		},
		setDataCourses: function(a) {
			j = a;
		},
		getDataCourses: function() {
			return j;
		},
		setSubSecPayslip: function(a) {
			k = a;
		},
		getSubSecPayslip: function() {
			return k;
		},
		setDataPayslip: function(a) {
			l = a;
		},
		getDataPayslip: function() {
			return l;
		},
		setSubSecQualif: function(a) {
			m = a;
		},
		getSubSecQualif: function() {
			return m;
		},
		setDataQualif: function(a) {
			n = a;
		},
		getDataQualif: function() {
			return n;
		},
		setSubSecPerf: function(a) {
			o = a;
		},
		getSubSecPerf: function() {
			return o;
		},
		setDataPerf: function(a) {
			p = a;
		},
		getDataPerf: function() {
			return p;
		},
		setSubSecNotf: function(a) {
			q = a;
		},
		getSubSecNotf: function() {
			return q;
		},
		setDataNotf: function(a) {
			r = a;
		},
		getDataNotf: function() {
			return r;
		},
		setSecPersInfo: function(a) {
			h = a;
		},
		getSecPersInfo: function() {
			return h;
		},
		formatDate: function(D, a) {
			var b = sap.ca.ui.model.format.DateFormat.getDateInstance({
				style: "medium"
			});
			if (D !== null && D !== undefined) {
				if (a !== undefined) {
					return b.format(D, a);
				} else {
					return b.format(D, true);
				}
			}
		},
		formatTime: function(D, a) {
			var b = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				style: "medium"
			});
			if (D !== null && D !== undefined) {
				if (a !== undefined) {
					return b.format(D, a);
				} else {
					return b.format(D, true);
				}
			}
		},
		formatNumber: function(v) {
			var a = sap.ca.ui.model.format.NumberFormat.getInstance();
			return a.format(v);
		},
		sortArrayByProperty: function(v, w) {
			function x(y) {
				var z = 1;
				if (y[0] === "-") {
					z = -1;
					y = y.substr(1);
				}
				return function(a, b) {
					var A = (a[y] < b[y]) ? -1 : (a[y] > b[y]) ? 1 : 0;
					return A * z;
				};
			}
			return v.sort(x(w));
		},
		buildTimePeriod: function(b, a, v) {
			var w = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
				pattern: "MMM",
				style: "medium"
			});
			var x = b.getFullYear();
			var y = b.getMonth();
			var z = w.format(b);
			var A = b.getDate();
			var B = a.getFullYear();
			var C = a.getMonth();
			var D = w.format(a);
			var E = a.getDate();
			var F = new Date(a);
			F.setDate(a.getDate() + 1);
			var G = F.getMonth();
			var H = F.getDate();
			if (v) {
				if ((A === E) && (y === C) && (x === B)) {
					A = "";
					y = "";
					x = "";
					C = D;
				} else if ((y === C) && (x === B)) {
					y = "";
					x = "";
					C = D;
				} else if ((x === B)) {
					x = "";
					y = z;
					C = D;
				} else {
					y = z;
					C = D;
				}
			} else {
				if (x === B) {
					x = "";
				}
				if ((y === G) && (A === H)) {
					y = "";
					C = "";
					A = "";
					E = "";
				} else {
					y = z;
					C = D;
				} if (A === H) {
					A = "";
					E = "";
				}
			}
			var I = A + " " + y + " " + x;
			var J = E + " " + C + " " + B;
			var K = false;
			if ((A !== "") && (y !== "") && (x !== "")) {
				K = true;
			}
			var L = false;
			if ((E !== "") && (C !== "") && (B !== "")) {
				L = true;
			}
			if (K && L) {
				I = this.formatDate(b);
				J = this.formatDate(a);
			}
			if (I.trim() !== "") {
				I = I + " - ";
			} else if (v) {
				J = this.formatDate(a);
			}
			return I + J;
		}
	};
}());