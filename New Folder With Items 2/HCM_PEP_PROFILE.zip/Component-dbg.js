/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

//local
// (function() {
//       jQuery.sap.registerModulePath("sap.hcm.lib.common", "/src/main/webapp/uilib/sap/hcm/lib/common");
// }());

//production
(function() {
    var sPath = jQuery.sap.getModulePath("hcm.people.profile");
    if (sPath.indexOf("/hcm_pep_profile") !== -1) {
        if (sPath.lastIndexOf("/") !== sPath.length - 1) {
            sPath += "/";
        }
        jQuery.sap.registerModulePath("sap.hcm.lib.common",
                sPath + "../hcm_common/sap/hcm/lib/common/");
    }
}());

// extent of sap.ca.scfld.md.ComponentBase
sap.ca.scfld.md.ComponentBase.extend("hcm.people.profile.Component", {
	metadata : sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		"name": "Fullscreen Sample",
		"version" : "1.8.0",
		"library" : "hcm.people.profile",
		"includes" : [],
		"dependencies" : {
			"libs" : ["sap.m", "sap.me","sap.uxap"],
			"components" : []
		},
		"config" : {
		  "resourceBundle" : "i18n/i18n.properties",
          "titleResource" : "PEOPLE_PROFILE" 
		},
		viewPath : "hcm.people.profile.view",
		fullScreenPageRoutes : {
			"fullscreen" : {
				"pattern" : "",
				"view" : "Profile"
			}
		}
	}),	

	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
		var oViewData = {component: this};
		return sap.ui.view({
			viewName : "hcm.people.profile.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	}
});