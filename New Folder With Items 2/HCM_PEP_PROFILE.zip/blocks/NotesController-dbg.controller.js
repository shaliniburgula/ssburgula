/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.NotesController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();

		var queryPath = "EmployeeDataSet('" + pernr + "')/NotesSet";
		oDataModel.read(queryPath, null, null, true, function(response) {
		    var notesColl = [];
		    response.results.forEach(function(notesObj) {
		        notesObj.Timestamp = hcm.people.profile.util.UIHelper.formatTime(notesObj.Timestamp);
		        notesColl.push(notesObj);
		    });
		    
		    if(notesColl.length>0){
		        var oNoteCollection = {
				        "EntryCollection": notesColl
			        };
    			var oModel = new sap.ui.model.json.JSONModel(oNoteCollection);
    			that.byId("ctrlNotesFeed").setModel(oModel);
    			that.byId("ctrlNotesFeed").bindItems("/EntryCollection", that.byId("ctrlNotesEntry"));
    			that.byId("lblDispMsg").setVisible(false);
		    }else{
		        that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("NOTES_NO_DATA"));
		        that.byId("dispStatusMsg").setVisible(true);
		        that.byId("ctrlNotesFeed").setVisible(false);
		    }
		    

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});