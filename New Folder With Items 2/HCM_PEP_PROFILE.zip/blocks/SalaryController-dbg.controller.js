/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.SalaryController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();

		var queryPath = "EmployeeDataSet('" + pernr + "')/CompensationSet";
		var ctrlVizSalary = that.byId("ctrlVizFrameSalary");
		//var oPopOver = this.byId("idPopOver");

		if (sap.ui.Device.system.desktop) {
			ctrlVizSalary.setWidth("80%");
		} else if (sap.ui.Device.system.tablet) {
			ctrlVizSalary.setWidth("90%");
		} else {
			ctrlVizSalary.setWidth("100%");
		}

		oDataModel.read(queryPath, null, null, true, function(response) {
		    
		    if(response.results.length>0){

    			var SalaryList = [];
    			var currencyName = "";
    
    			var sortedSalaryList = hcm.people.profile.util.UIHelper.sortArrayByProperty(response.results, "Year");
    
    			sortedSalaryList.forEach(function(salaryItem) {
    				var bonusObj = {};
    				bonusObj.Category = hcm.people.profile.util.UIHelper.getResourceBundle().getText("BONUS");
    				bonusObj.Compensation = salaryItem.Bonus;
    				bonusObj.Year = salaryItem.Year;
    				currencyName = salaryItem.Currency;
    				SalaryList.push(bonusObj);
    				var salObj = {};
    				salObj.Category = hcm.people.profile.util.UIHelper.getResourceBundle().getText("SALARY");
    				salObj.Compensation = salaryItem.Salary;
    				salObj.Year = salaryItem.Year;
    				SalaryList.push(salObj);
    			});
    
    			var strYear = hcm.people.profile.util.UIHelper.getResourceBundle().getText("YEAR");
    			var strCategory = hcm.people.profile.util.UIHelper.getResourceBundle().getText("CATEGORY");
    			var strCompensation = hcm.people.profile.util.UIHelper.getResourceBundle().getText("COMPENSATION");
    
    			strCompensation = strCompensation + " (" + currencyName + ")";
    
    			var oModel = new sap.ui.model.json.JSONModel({
    				SalaryBonus: SalaryList
    			});
    
    			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
    			   dimensions: [{
    						name: strYear,
    						value: "{Year}"
                        },
    					{
    						name: strCategory,
    						value: "{Category}"
                   }],
    				measures: [
    					{
    						name: strCompensation,
    						value: '{Compensation}'
                        }
                   ],
    				data: {
    					path: "/SalaryBonus"
    				}
    			});
    
    			ctrlVizSalary.setVizProperties({
    				valueAxis: {
    					label: {
    						formatString: 'u'
    					}
    				},
    				plotArea: {
    					dataLabel: {
    						visible: true
    					}
    				},
    				legend: {
    					visible: true,
    					title: {
    						visible: true
    					}
    				},
    				title: {
    					visible: false,
    					text: " "
    				},
    				interaction : {
    				    selectability : {
    				        mode : "none",
    				        axisLabelSelection : false,
    				        plotLassoSelection : false,
    				        plotStdSelection : false
    				    }
    				},
    				legendGroup : {
    				    layout : {
    				   //     position : "bottom"
    				    }
    				}
    			});
    
    			ctrlVizSalary.setModel(oModel);
    			ctrlVizSalary.setDataset(oDataset);
    
    			var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
    					'uid': "primaryValues",
    					'type': "Measure",
    					'values': [strCompensation]
    				}),
    				feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
    					'uid': "axisLabels",
    					'type': "Dimension",
    					'values': [strYear]
    				}),
    				feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({
    					'uid': "regionColor",
    					'type': "Dimension",
    					'values': [strCategory]
    				});
    
    			ctrlVizSalary.addFeed(feedPrimaryValues);
    			ctrlVizSalary.addFeed(feedAxisLabels);
    			ctrlVizSalary.addFeed(feedColor);
    			
    			//oPopOver.connect(ctrlVizSalary.getVizUid());
    			
    			
        		ctrlVizSalary.attachRenderComplete(function(evt){
            	   $("#" + evt.getParameters().id).find('.ui5-viz-controls-app').css( "background-color", "transparent" );
            	   $("#" + evt.getParameters().id).find('.ui5-viz-controls-viz-frame').css( "background-color", "transparent" );
            	});
	    
    			
    			
		    }else{
		        var noOfYears = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().CompensationNoOfYears);
			    that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("COMP_NO_DATA",[noOfYears]));
                that.byId("dispStatusMsg").setVisible(true);
                ctrlVizSalary.setVisible(false);
                //oPopOver.setVisible(false);
		    }

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});