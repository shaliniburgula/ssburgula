/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.TimeBalanceController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		that.pernr = hcm.people.profile.util.UIHelper.getPernr();
		//var ctrlHeaderContainer = this.byId("ctrlHeaderContainer");

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		//var oConfig = hcm.people.profile.util.UIHelper.getConfiguration();

		var ctrlNumericContent = that.byId("ctrlNumericContent");
		var ctrlDispAsOf = that.byId("ctrlDispAsOf");
		var ctrlDispText = that.byId("ctrlDispText");

		var queryPathTime = "EmployeeDataSet('" + that.pernr + "')/TimeBalanceSet";
		oDataModel.read(queryPathTime, null, null, true, function(response) {
			//Set the date as recieved from response , if the date is "00000000" set it to current date.
			var year, month, day, unformatteddate, date;
			if (Number(response.AsofDate) !== 0) {
				unformatteddate = response.AsofDate;
				//create formatted Date
				year = unformatteddate.substring(0, 4);
				month = unformatteddate.substring(4, 6);
				day = unformatteddate.substring(6, 8);
				date = hcm.people.profile.util.UIHelper.formatDate(new Date(year, month, day));
			} else {
				date = hcm.people.profile.util.UIHelper.formatDate(new Date());
			}

			if (response.BalanceText.length > 0) {
				//Get balance numeric value and it's unit
				var balVal = response.BalanceValue;
				var balvalNumber = balVal.split(" ")[0].replace(",", ".");
				var balvalUnit = balVal.split(" ")[1];
				var calTruncate = balvalNumber.trim().length;

				ctrlNumericContent.setTruncateValueTo(calTruncate);
				var calcWidth = "";
				calcWidth =calTruncate+4+"rem";
				ctrlNumericContent.setWidth(calcWidth);
				ctrlNumericContent.setValue(balvalNumber + " " + balvalUnit);
				ctrlNumericContent.setTooltip(hcm.people.profile.util.UIHelper.formatNumber(balvalNumber));
				ctrlDispText.setText(response.BalanceText);
				ctrlDispAsOf.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("AS_OF", [date]));

			} else {
				ctrlNumericContent.setVisible(false);
				that.byId("spaceHolder").setVisible(true);
				that.byId("spaceHolder2").setVisible(true);
				ctrlDispText.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("TIME_BAL_NO_DATA_ASOF", [date]));
			}
		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	},

	onCreateTimePress: function() {
		var oPersonalizer = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
		var aData = hcm.people.profile.util.UIHelper.getCachedPersData();
		if (aData.crossAppNavFlag !== true) {
			aData.crossAppNavFlag = true;
		}
		oPersonalizer.setPersData(aData);
		hcm.people.profile.util.UIHelper.cachePersData(aData);
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				semanticObject: "TimeEntry",
				action: "manageCorrections"
			},
			params: {
				"pernr": this.pernr
			}
		});
	}

});