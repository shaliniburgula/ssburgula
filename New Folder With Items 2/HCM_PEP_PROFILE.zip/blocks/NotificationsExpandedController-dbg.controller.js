/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.people.profile.blocks.NotificationsExpandedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;

		var notfColl = hcm.people.profile.util.UIHelper.getDataNotf();

		notfColl.forEach(function(notif) {
			var titleObj = new sap.m.Text({
				text: notif.Title
			});
			titleObj.addStyleClass("sapHcmECTitleFont");
			that.byId("ctrlNotiList").addContent(titleObj);
			var timeObj = new sap.m.Text({
				text: hcm.people.profile.util.UIHelper.formatTime(notif.Updated)
			});
			timeObj.addStyleClass("sapHcmECSubtitle");
			that.byId("ctrlNotiList").addContent(timeObj);
			that.byId("ctrlNotiList").addContent(new sap.m.Text());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});