/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.TimeRecordingController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		that.pernr = hcm.people.profile.util.UIHelper.getPernr();
		//var ctrlHeaderContainer = this.byId("ctrlHeaderContainer");

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		//var oConfig = hcm.people.profile.util.UIHelper.getConfiguration();

		var ctrlNumericContent = that.byId("ctrlNumericContent");
		var ctrlDispText = that.byId("ctrlDispText");
		var queryPathTime = "EmployeeDataSet('" + that.pernr + "')/TimeRecording";
		oDataModel.read(queryPathTime, null, null, true, function(response) {
			ctrlNumericContent.setValue(response.Missingdays);
			if (response.Missingdays && response.Missingdays !== 0) {
				var calTruncate = response.Missingdays.toString().trim().length;

				ctrlNumericContent.setTruncateValueTo(calTruncate);
				ctrlNumericContent.setValue(hcm.people.profile.util.UIHelper.formatNumber(response.Missingdays));
				ctrlNumericContent.setTooltip(response.Missingdays.toString());

				ctrlDispText.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("INCOMPLETE_DAYS"));
				that.byId("ctrlDispSince").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("SINCE") + " " +
					hcm.people.profile.util.UIHelper.formatDate(response.Startdate));
				var calcWidth = "";
				calcWidth =calTruncate+4+"rem";
				ctrlNumericContent.setWidth(calcWidth);

			} else {
				ctrlDispText.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("TIME_NO_DATA"));
			}
		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	},

	onRecordTimePress: function() {
		var oPersonalizer = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
		var aData = hcm.people.profile.util.UIHelper.getCachedPersData();
		if (aData.crossAppNavFlag !== true) {
			aData.crossAppNavFlag = true;
		}
		oPersonalizer.setPersData(aData);
		hcm.people.profile.util.UIHelper.cachePersData(aData);
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				semanticObject: "TimeEntry",
				action: "manage"
			},
			params: {
				"pernr": this.pernr
			}
		});
	}

});