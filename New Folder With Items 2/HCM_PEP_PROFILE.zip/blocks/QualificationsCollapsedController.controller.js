/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
sap.ui.controller("hcm.people.profile.blocks.QualificationsCollapsedController", {
	onInit: function() {
		this.buildUI();
	},
	onExit: function() {},
	buildUI: function() {
		var t = this;
		var p = hcm.people.profile.util.UIHelper.getPernr();
		var d = hcm.people.profile.util.UIHelper.getODataModel();
		var c = t.byId("ctrlQualificationContainer");
		var q = "EmployeeDataSet('" + p + "')/QualificationSet";
		d.read(q, null, null, true, function(r) {
			var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "ValidUntil");
			hcm.people.profile.util.UIHelper.setDataQualif(s);
			if (s.length > 3) {
				var a = hcm.people.profile.util.UIHelper.getSubSecQualif();
				a.getBlocks()[0].setShowSubSectionMore(true);
			}
			if (s.length === 0) {
				var n = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().QualificationNoOfMonths);
				t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("QUALIF_NO_DATA", [n]));
				t.byId("dispStatusMsg").setVisible(true);
				c.setVisible(false);
			}
			var b = 0;
			s.forEach(function(e) {
				if (b < 3) {
					var v = new sap.ui.layout.VerticalLayout();
					var f = new sap.suite.ui.commons.BulletChart({
						size: "M",
						targetValue: parseInt(e.RequiredRating),
						minValue: "0",
						maxValue: parseInt(e.ScaleCount)
					});
					f.setActual(new sap.suite.ui.commons.BulletChartData({
						value: parseInt(e.Rating),
						color: (parseInt(e.Rating) < parseInt(e.RequiredRating)) ? "Error" : "Good"
					}));
					f.addAggregation("thresholds", new sap.suite.ui.commons.BulletChartData({
						value: 0
					}));
					v.addContent(f);
					v.addContent(new sap.m.Label({
						text: e.Name,
						design: "Bold"
					}));
					v.addContent(new sap.m.Text({
						text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("VALID_UNTIL") + " " + hcm.people.profile.util.UIHelper.formatDate(
							e.ValidUntil),
						wrapping: true
					}));
					c.addContent(v);
					b++;
				}
			});
		}, function(r) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
		});
	},
	onBeforeRendering: function() {},
	onAfterRendering: function() {}
});