/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.blocks.Qualifications");
jQuery.sap.require("sap.uxap.BlockBase");
sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Qualifications", {
	metadata: {
		views: {
			Collapsed: {
				viewName: "hcm.people.profile.blocks.QualificationsCollapsed",
				type: "XML"
			},
			Expanded: {
				viewName: "hcm.people.profile.blocks.QualificationsExpanded",
				type: "XML"
			}
		},
		properties: {
			"columnLayout": {
				type: "sap.uxap.BlockBaseColumnLayout",
				group: "Behavior",
				defaultValue: "2"
			}
		}
	}
});