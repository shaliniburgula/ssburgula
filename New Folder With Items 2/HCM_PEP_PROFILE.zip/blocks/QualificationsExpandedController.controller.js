/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
sap.ui.controller("hcm.people.profile.blocks.QualificationsExpandedController", {
	onInit: function() {
		this.buildUI();
	},
	onExit: function() {},
	buildUI: function() {
		var t = this;
		var p = hcm.people.profile.util.UIHelper.getPernr();
		var c = t.byId("ctrlQualificationContainer");
		var s = hcm.people.profile.util.UIHelper.getDataQualif();
		s.forEach(function(r) {
			var v = new sap.ui.layout.VerticalLayout();
			var b = new sap.suite.ui.commons.BulletChart({
				size: "M",
				targetValue: parseInt(r.RequiredRating),
				minValue: "0",
				maxValue: parseInt(r.ScaleCount)
			});
			b.setActual(new sap.suite.ui.commons.BulletChartData({
				value: parseInt(r.Rating),
				color: (parseInt(r.Rating) < parseInt(r.RequiredRating)) ? "Error" : "Good"
			}));
			b.addAggregation("thresholds", new sap.suite.ui.commons.BulletChartData({
				value: 0
			}));
			v.addContent(b);
			v.addContent(new sap.m.Label({
				text: r.Name,
				design: "Bold"
			}));
			v.addContent(new sap.m.Text({
				text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("VALID_UNTIL") + " " + hcm.people.profile.util.UIHelper.formatDate(
					r.ValidUntil),
				wrapping: true
			}));
			c.addContent(v);
		});
	},
	onBeforeRendering: function() {},
	onAfterRendering: function() {}
});