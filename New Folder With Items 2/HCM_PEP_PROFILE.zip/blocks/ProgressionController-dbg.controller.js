/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.ProgressionController", {

	onInit: function() {
		this.buildUI();

	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		this.ctrlProgressionTimeline = this.byId("ctrlProgressionTimeline");

		if (sap.ui.Device.system.phone) {
			this.ctrlProgressionTimeline.setAxisOrientation("Vertical");
		} else {
			this.ctrlProgressionTimeline.setAxisOrientation("Horizontal");
			this.getView().setHeight("200px");
		}

		var ctrlProgressionTimeline = this.byId("ctrlProgressionTimeline");
		//var ctrlTimelineItem = this.byId("ctrlTimelineItem");

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		var queryPath = "EmployeeDataSet('" + pernr + "')/ProgressionSet";
		oDataModel.read(queryPath, null, null, true, function(response) {

			//  var formattedList = [];

			//   response.results.forEach(function(progressionObj) {
			//           var actualDate = new Date(progressionObj.BeginDate);
			//           progressionObj.BeginDate  = new Date(actualDate.getUTCFullYear(),actualDate.getUTCMonth(),actualDate.getUTCDay());
			//           formattedList.push(progressionObj);  
			// });

			//   var oProgModel = new sap.ui.model.json.JSONModel({
			// 	Progression:  formattedList
			// });

			// ctrlProgressionTimeline.setModel(oProgModel);
			// ctrlProgressionTimeline.bindAggregation("content", {
			//              path: "/Progression",
			//              template: ctrlTimelineItem
			//          });     
			
			if(response.results.length>0){

    			response.results.forEach(function(progressionObj) {
    				//var actualDate = new Date(progressionObj.BeginDate);
    				var formattedDate =  hcm.people.profile.util.UIHelper.formatDate(progressionObj.BeginDate);
    				var timelineItem = new sap.suite.ui.commons.TimelineItem({
    					title: progressionObj.PositionTxt,
    					text: progressionObj.OrgunitTxt,
    					dateTime: progressionObj.BeginDate
    					// //                dateTime : hcm.people.profile.util.UIHelper.formatDate(progressionObj.BeginDate)
    				});
    				
    				timelineItem.onAfterRendering = function(evt){
    				    var itemShellId = evt.srcControl.getId() + "-shell";
    				    $("#" + itemShellId).find('.sapSuiteUiCommonsTimelineItemShellDateTime').text(formattedDate);
    				};
    				ctrlProgressionTimeline.insertContent(timelineItem);
                });
            }else{
			    that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PROG_NO_DATA"));
			    that.byId("dispStatusMsg").setVisible(true);
			    ctrlProgressionTimeline.setVisible(false);
            }

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});