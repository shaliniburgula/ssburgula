/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.QualificationsCollapsedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();

// 		var ctrlQualificationsTbl = that.byId("ctrlQualificationsTbl");
// 		var ctrlQualificationItem = that.byId("ctrlQualificationItem");
        var ctrlQualificationContainer = that.byId("ctrlQualificationContainer");

// 		if (sap.ui.Device.system.desktop) {
// 			ctrlQualificationsTbl.setWidth("80%");
// 		} else if (sap.ui.Device.system.tablet) {
// 			ctrlQualificationsTbl.setWidth("90%");
// 		} else {
// 			ctrlQualificationsTbl.setWidth("100%");
// 		}

		var queryPath = "EmployeeDataSet('" + pernr + "')/QualificationSet";
		oDataModel.read(queryPath, null, null, true, function(response) {
//			var newResults = [];

			var sortedQualificationsList = hcm.people.profile.util.UIHelper.sortArrayByProperty(response.results, "ValidUntil");
			
			hcm.people.profile.util.UIHelper.setDataQualif(sortedQualificationsList);
			if(sortedQualificationsList.length>3){
			    var subSecQualif = hcm.people.profile.util.UIHelper.getSubSecQualif();
			    subSecQualif.getBlocks()[0].setShowSubSectionMore(true);
			}
			
			if(sortedQualificationsList.length===0){
			 var noOfMnths = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().QualificationNoOfMonths);
			 that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("QUALIF_NO_DATA",[noOfMnths]));
			 that.byId("dispStatusMsg").setVisible(true);
			 ctrlQualificationContainer.setVisible(false);
			}

            var count = 0;

			sortedQualificationsList.forEach(function(result) {
				// result.ValidUntil = hcm.people.profile.util.UIHelper.getResourceBundle().getText("VALID_UNTIL") + " " + hcm.people.profile.util.UIHelper
				// 	.formatDate(result.ValidUntil);
				// result.Rating = parseInt(result.Rating);
				// result.RequiredRating = parseInt(result.RequiredRating);
				// result.ScaleCount = parseInt(result.ScaleCount);
				// result.Color = ((result.Rating < result.RequiredRating) ? "Error" : "Good");
				// newResults.push(result);
				if(count<3){
    				var vertContainer = new sap.ui.layout.VerticalLayout();
    				
    				var bulletChart = new sap.suite.ui.commons.BulletChart({size:"M", targetValue :  parseInt(result.RequiredRating), minValue:"0", 
    				maxValue :parseInt(result.ScaleCount)});
    				bulletChart.setActual(new sap.suite.ui.commons.BulletChartData({value:parseInt(result.Rating),
    				color:(parseInt(result.Rating) < parseInt(result.RequiredRating)) ? "Error" : "Good"}));
    				bulletChart.addAggregation("thresholds", new sap.suite.ui.commons.BulletChartData({value:0})); 
    				
    				vertContainer.addContent(bulletChart);
    				vertContainer.addContent(new sap.m.Label({text : result.Name, design:"Bold" })); 
    				vertContainer.addContent(new sap.m.Text({text : hcm.people.profile.util.UIHelper.getResourceBundle().getText("VALID_UNTIL") + " " 
    				+ hcm.people.profile.util.UIHelper.formatDate(result.ValidUntil), wrapping:true })); 
    				
    				ctrlQualificationContainer.addContent(vertContainer);
    				count++;
				}
			});
// 			var oDataModel = new sap.ui.model.json.JSONModel({
// 				qualifications: newResults
// 			});
// 			ctrlQualificationsTbl.setModel(oDataModel);
// 			ctrlQualificationsTbl.bindItems("/qualifications", ctrlQualificationItem);

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});