/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.PayslipCollapsedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		var ctrlPayslipContainer = that.byId("ctrlPayslipContainer");
		var queryPath = "EmployeeDataSet('" + pernr + "')/PaystubSet";
		oDataModel.read(queryPath, null, null, true, function(response) {

			var sortedPayslipList = hcm.people.profile.util.UIHelper.sortArrayByProperty(response.results, "-Paydate");
			hcm.people.profile.util.UIHelper.setDataPayslip(sortedPayslipList);

			if (sortedPayslipList.length > 3) {
				var subSecPayslip = hcm.people.profile.util.UIHelper.getSubSecPayslip();
				subSecPayslip.getBlocks()[0].setShowSubSectionMore(true);
			}

			if (sortedPayslipList.length === 0) {
				var noOfMnths = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().PaystubNoOfMonths);
				that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PAYSLIP_NO_DATA", [noOfMnths]));
				that.byId("dispStatusMsg").setVisible(true);
				ctrlPayslipContainer.setVisible(false);
			}

			var count = 0;

			sortedPayslipList.forEach(function(payslip) {

				if (count < 3) {
					var ctrlVertLayout = new sap.ui.layout.VerticalLayout();
					var calTruncate = payslip.Amount.toString().length;
					var calcWidth = "";
					if (calTruncate === 1) {
						calcWidth = "6rem";
					} else if (calTruncate === 2) {
						calcWidth = "7rem";
					} else if (calTruncate === 3) {
						calcWidth = "8rem";
					} else if (calTruncate === 4) {
						calcWidth = "9rem";
					} else {
						calcWidth = (calTruncate + 5) + "rem";
					}

					var payNumeric = new sap.suite.ui.commons.NumericContent({
						value: hcm.people.profile.util.UIHelper.formatNumber(payslip.Amount) + " " + payslip.Currency,
						valueUnit: payslip.Currency,
						size: "S",
						icon: "sap-icon://monitor-payments",
						tooltip: hcm.people.profile.util.UIHelper.formatNumber(payslip.Amount) + " " + payslip.Currency,
						scale: payslip.Currency,
						formatterValue: true,
						iconDescription: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY"),
						width: calcWidth,
						truncateValueTo: calTruncate
					});

					ctrlVertLayout.addContent(payNumeric);
					ctrlVertLayout.addContent(new sap.m.Label({
						text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY")
					}));
					ctrlVertLayout.addContent(new sap.m.Label({
						text: hcm.people.profile.util.UIHelper.formatDate(payslip.Paydate)
					}));
					ctrlPayslipContainer.addContent(ctrlVertLayout);
					count++;
				}
			});

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onAfterRendering: function() {

	},

	onBeforeRendering: function() {

	},

	onViewPayslip: function() {
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				semanticObject: "RemunerationStatement",
				action: "display"
			}
		});
	}

});