/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.VacationsController", {

	onInit: function() {
		this.buildUI();
	},

	buildUI: function() {
		var that = this;
		that.pernr = hcm.people.profile.util.UIHelper.getPernr();
		var ctrlHeaderContainer = this.byId("ctrlHeaderContainer");
		var ctrlNumericContent = that.byId("ctrlNumericContent");

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		var oConfig = hcm.people.profile.util.UIHelper.getConfiguration();

		var queryPathAbscense = "EmployeeDataSet('" + that.pernr + "')/VacationSet";
		oDataModel.read(queryPathAbscense, null, null, true, function(response) {

			var sortedVacationList = hcm.people.profile.util.UIHelper.sortArrayByProperty(response.results, "BeginDate");

			if (sortedVacationList[0]) {
				var calTruncate = sortedVacationList[0].Days.toString().trim().length;
				ctrlNumericContent.setTruncateValueTo(calTruncate);
				//ctrlNumericContent.setScale(hcm.people.profile.util.UIHelper.getResourceBundle().getText("DAYS"));
				var calcWidth = "";
				calcWidth =calTruncate+4+"rem";
				ctrlNumericContent.setWidth(calcWidth);
				var strVal = hcm.people.profile.util.UIHelper.formatNumber(sortedVacationList[0].Days) + " " + hcm.people.profile.util.UIHelper.getResourceBundle()
					.getText("DAYS");
				ctrlNumericContent.setValue(strVal);
				ctrlNumericContent.setTooltip(strVal);

				that.byId("cntrlVacType").setText(sortedVacationList[0].Type + " - " + sortedVacationList[0].Status);
				//that.byId("cntrlVacDateRange").setText(hcm.people.profile.util.UIHelper.formatDate(sortedVacationList[0].BeginDate) +
				//	" - " + hcm.people.profile.util.UIHelper.formatDate(sortedVacationList[0].EndDate));

				that.byId("cntrlVacDateRange").setText(hcm.people.profile.util.UIHelper.buildTimePeriod(sortedVacationList[0].BeginDate,
					sortedVacationList[0].EndDate, true));

				//that.byId("cntrlVacStatus").setText(response.results[0].Status);
			} else {
				var noOfMnths = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().VacationNoOfMonths);
				that.byId("cntrlVacStatus").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("LEAVES_NO_DATA", [noOfMnths]));
				that.byId("spaceHolder").setVisible(true);
				that.byId("spaceHolder2").setVisible(true);
				that.byId("cntrlVacStatus").setVisible(true);
				ctrlNumericContent.setVisible(false);
			}
		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onExit: function() {

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	},

	onApplyLeavePress: function() {
		var oPersonalizer = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
		var aData = hcm.people.profile.util.UIHelper.getCachedPersData();
		if (aData.crossAppNavFlag !== true) {
			aData.crossAppNavFlag = true;
		}
		oPersonalizer.setPersData(aData);
		hcm.people.profile.util.UIHelper.cachePersData(aData);
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				semanticObject: "LeaveRequest",
				action: "manage"
			},
			params: {
				"pernr": this.pernr
			}
		});
	}
});