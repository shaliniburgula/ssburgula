/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.PayslipExpandedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var ctrlPayslipContainer = that.byId("ctrlPayslipContainer");

		var sortedPayslipList = hcm.people.profile.util.UIHelper.getDataPayslip();

		sortedPayslipList.forEach(function(payslip) {

			var ctrlVertLayout = new sap.ui.layout.VerticalLayout();
			var calTruncate = payslip.Amount.toString().length;
			var calcWidth = "";
			if (calTruncate === 1) {
				calcWidth = "6rem";
			} else if (calTruncate === 2) {
				calcWidth = "7rem";
			} else if (calTruncate === 3) {
				calcWidth = "8rem";
			} else if (calTruncate === 4) {
				calcWidth = "9rem";
			} else {
				calcWidth = (calTruncate + 5) + "rem";
			}

			var payNumeric = new sap.suite.ui.commons.NumericContent({
				value: hcm.people.profile.util.UIHelper.formatNumber(payslip.Amount) + " " + payslip.Currency,
				valueUnit: payslip.Currency,
				size: "S",
				icon: "sap-icon://monitor-payments",
				scale: payslip.Currency,
				tooltip: hcm.people.profile.util.UIHelper.formatNumber(payslip.Amount) + " " + payslip.Currency,
				formatterValue : true,
				iconDescription: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY"),
				width: calcWidth,
				truncateValueTo: calTruncate
			});
			ctrlVertLayout.addContent(payNumeric);
			ctrlVertLayout.addContent(new sap.m.Label({
				text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY")
			}));
			ctrlVertLayout.addContent(new sap.m.Label({
				text: hcm.people.profile.util.UIHelper.formatDate(payslip.Paydate)
			}));
			ctrlPayslipContainer.addContent(ctrlVertLayout);
		});

	},

	onAfterRendering: function() {

	},

	onBeforeRendering: function() {

	},

	onViewPayslip: function() {
		sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
			target: {
				semanticObject: "RemunerationStatement",
				action: "display"
			}
		});
	}

});