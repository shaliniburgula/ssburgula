/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.blocks.Progression");
jQuery.sap.require("sap.uxap.BlockBase");

sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Progression", {
    metadata: {
        views: {
            Collapsed: {
                viewName: "hcm.people.profile.blocks.Progression",
                type: "XML"
            },
            Expanded: {
                viewName: "hcm.people.profile.blocks.Progression",
                type: "XML"
            }
        },
        properties: {
           "columnLayout" : {type: "sap.uxap.BlockBaseColumnLayout", group: "Behavior", defaultValue: "2"}
        }
    }
});
