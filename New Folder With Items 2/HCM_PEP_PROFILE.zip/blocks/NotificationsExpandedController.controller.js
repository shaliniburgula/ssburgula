/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.people.profile.blocks.NotificationsExpandedController",{onInit:function(){this.buildUI();},onExit:function(){},buildUI:function(){var t=this;var n=hcm.people.profile.util.UIHelper.getDataNotf();n.forEach(function(a){var b=new sap.m.Text({text:a.Title});b.addStyleClass("sapHcmECTitleFont");t.byId("ctrlNotiList").addContent(b);var c=new sap.m.Text({text:hcm.people.profile.util.UIHelper.formatTime(a.Updated)});c.addStyleClass("sapHcmECSubtitle");t.byId("ctrlNotiList").addContent(c);t.byId("ctrlNotiList").addContent(new sap.m.Text());});},onBeforeRendering:function(){},onAfterRendering:function(){}});
