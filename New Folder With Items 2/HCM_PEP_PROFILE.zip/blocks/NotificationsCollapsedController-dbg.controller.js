/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.people.profile.blocks.NotificationsCollapsedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;

		var notifODataModel = hcm.people.profile.util.UIHelper.getNotifODataModel();

		notifODataModel.read("NotificationCollection", null, null, true, function(response) {
		    
		    if(response.results.length===0){
		        that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("NOTIF_NO_DATA"));
		        that.byId("dispStatusMsg").setVisible(true);
		        that.byId("ctrlNotifHolder").setVisible(false);
		    }else{
		        that.byId("dispStatusMsg").setVisible(false);
		        var notfCollection = response.results;
		        
		        hcm.people.profile.util.UIHelper.setDataNotf(notfCollection);
    		
    			if(notfCollection.length>4){
    			    var subSecNotf = hcm.people.profile.util.UIHelper.getSubSecNotf();
    			    subSecNotf.getBlocks()[0].setShowSubSectionMore(true);
    			}
		       	var count = 0;
		        notfCollection.forEach(function(notif) {
		            if(count<4){
    		            var titleObj = new sap.m.Text({ text: notif.Title });
    		            titleObj.addStyleClass("sapHcmTitleFont");
        				that.byId("ctrlNotiList").addContent(titleObj);
        				var timeObj = new sap.m.Text({ text: hcm.people.profile.util.UIHelper.formatTime(notif.Updated)	});
        				timeObj.addStyleClass("sapHcmSubtitleFont");
        				that.byId("ctrlNotiList").addContent(timeObj);
        				that.byId("ctrlNotiList").addContent(new sap.m.Text());
        				count++;
		            }
			    });
		    }

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});