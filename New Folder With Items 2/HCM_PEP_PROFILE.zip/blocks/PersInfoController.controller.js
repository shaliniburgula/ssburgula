/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("sap.ui.layout.form.SimpleForm");
sap.ui.controller("hcm.people.profile.blocks.PersInfoController", {
	onInit: function() {
		this.buildUI();
	},
	buildUI: function() {
		var t = this;
		var p = hcm.people.profile.util.UIHelper.getPernr();
		var i = false;
		var d = hcm.people.profile.util.UIHelper.getODataModel();
		var q = "EmployeeDataSet('" + p + "')/PersonalInfoSet";
		d.read(q, null, null, true, function(r) {
			var a = r.results;
			var g = [];
			var b = [];
			var s = hcm.people.profile.util.UIHelper.getSecPersInfo();
			if (a.length > 0) {
				a.forEach(function(c) {
					if (b[c.Groupname]) {
						b[c.Groupname].vals.push({
							"Fieldlabel": c.Fieldlabel,
							"Fieldvalue": c.Fieldvalue
						});
					} else {
						g.push(c.Groupname);
						b[c.Groupname] = {
							"groupName": c.Groupname,
							vals: []
						};
						b[c.Groupname].vals.push({
							"Fieldlabel": c.Fieldlabel,
							"Fieldvalue": c.Fieldvalue
						});
					}
				});
				g.forEach(function(c) {
					var e = new sap.ui.layout.form.SimpleForm({
						maxContainerCols: 2,
						editable: false,
						layout: "ResponsiveGridLayout"
					});
					b[c].vals.forEach(function(h) {
						e.addContent(new sap.m.Label({
							text: h.Fieldlabel
						}));
						e.addContent(new sap.m.Text({
							text: h.Fieldvalue
						}));
					});
					if (!i) {
						var f = hcm.people.profile.util.UIHelper.getSubSecPersInfo();
						f.setTitle(c);
						f.insertBlock(e);
						i = true;
					} else {
						var n = new sap.uxap.ObjectPageSubSection({
							title: c
						});
						n.insertBlock(e);
						s.addSubSection(n);
					}
				});
			} else {
				t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERS_NO_DATA"));
				t.byId("dispStatusMsg").setVisible(true);
			}
		}, function(r) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
		});
	},
	onExit: function() {},
	onBeforeRendering: function() {},
	onAfterRendering: function() {}
});