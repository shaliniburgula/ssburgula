/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");sap.ui.controller("hcm.people.profile.blocks.CourcesExpandedController",{onInit:function(){this.buildUI();},onExit:function(){},buildUI:function(){var t=this;var c=t.byId("ctrlCourseContainer");var s=hcm.people.profile.util.UIHelper.getDataCourses();s.forEach(function(a){var b=new sap.ui.layout.VerticalLayout();b.addContent(new sap.m.Label({text:a.Name,design:"Bold"}));b.addContent(new sap.m.Text({text:a.Description,wrapping:true}));b.addContent(new sap.m.Text({text:hcm.people.profile.util.UIHelper.buildTimePeriod(a.BeginDate,a.EndDate,true),wrapping:true}));c.addContent(b);});},onBeforeRendering:function(){},onAfterRendering:function(){}});
