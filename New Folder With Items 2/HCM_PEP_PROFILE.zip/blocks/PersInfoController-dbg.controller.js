/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("sap.ui.layout.form.SimpleForm");

sap.ui.controller("hcm.people.profile.blocks.PersInfoController", {

	onInit: function() {
		this.buildUI();
	},

	buildUI: function() {

		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();
		var isSubSectionUsed = false;

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		var queryPath = "EmployeeDataSet('" + pernr + "')/PersonalInfoSet";
		oDataModel.read(queryPath, null, null, true, function(response) {

			var persInfoColl = response.results;
			var groupNameList = [];
			var groupColl = [];
			var secPersInfo = hcm.people.profile.util.UIHelper.getSecPersInfo();
			
			if(persInfoColl.length>0){

    			persInfoColl.forEach(function(persInfoItem) {
    				// if (Date.parse(persInfoItem.Fieldvalue)) {
    				//     var formattedVal = hcm.people.profile.util.UIHelper.formatDate(persInfoItem.Fieldvalue);
    				//     if(formattedVal.toString().indexOf('NaN')===-1){
    				//         persInfoItem.Fieldvalue = formattedVal;
    				//     }
    				// }
    
    				if (groupColl[persInfoItem.Groupname]) {
    					groupColl[persInfoItem.Groupname].vals.push({
    						"Fieldlabel": persInfoItem.Fieldlabel,
    						"Fieldvalue": persInfoItem.Fieldvalue
    					});
    				} else {
    					groupNameList.push(persInfoItem.Groupname);
    					groupColl[persInfoItem.Groupname] = {
    						"groupName": persInfoItem.Groupname,
    						vals: []
    					};
    					groupColl[persInfoItem.Groupname].vals.push({
    						"Fieldlabel": persInfoItem.Fieldlabel,
    						"Fieldvalue": persInfoItem.Fieldvalue
    					});
    				}
    			});
    
    			groupNameList.forEach(function(grpName) {
    
    				var ctrlSimpleForm = new sap.ui.layout.form.SimpleForm({
    					maxContainerCols: 2,
    					editable: false,
    					layout: "ResponsiveGridLayout"
    				});
    
    				groupColl[grpName].vals.forEach(function(fieldObj) {
    					ctrlSimpleForm.addContent(new sap.m.Label({
    						text: fieldObj.Fieldlabel
    					}));
    					ctrlSimpleForm.addContent(new sap.m.Text({
    						text: fieldObj.Fieldvalue
    					}));
    				});
    
    				if (!isSubSectionUsed) {
    
    					var subSection = hcm.people.profile.util.UIHelper.getSubSecPersInfo();
    					subSection.setTitle(grpName);
    					subSection.insertBlock(ctrlSimpleForm);
    					isSubSectionUsed = true;
    
    				} else {
    
    					var oNewSubSection = new sap.uxap.ObjectPageSubSection({
    						title: grpName
    					});
    					oNewSubSection.insertBlock(ctrlSimpleForm);
    					secPersInfo.addSubSection(oNewSubSection);
    
    				}
    
    			});
    			
			}else{
			    that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERS_NO_DATA"));
			    that.byId("dispStatusMsg").setVisible(true);
			}

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onExit: function() {

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});