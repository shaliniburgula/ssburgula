/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.CourcesCollapsedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();
		var oConfigObj = hcm.people.profile.util.UIHelper.getConfiguration();
		var ctrlCourseContainer = that.byId("ctrlCourseContainer");
		var queryPath = "EmployeeDataSet('" + pernr + "')/CourseSet";
		oDataModel.read(queryPath, null, null, true, function(response) {

			var sortedCourseList = hcm.people.profile.util.UIHelper.sortArrayByProperty(response.results, "BeginDate");
			hcm.people.profile.util.UIHelper.setDataCourses(sortedCourseList);
			if(sortedCourseList.length>3){
			    var subSecCources = hcm.people.profile.util.UIHelper.getSubSecCourses();
			    subSecCources.getBlocks()[0].setShowSubSectionMore(true);
			}
			
			if(sortedCourseList.length===0){
			    ctrlCourseContainer.setVisible(false);
			    that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("COURSES_NO_DATA",[parseInt(oConfigObj.CourseNoOfMonths)]));
			    that.byId("dispStatusMsg").setVisible(true);
			}
			
			var count = 0;
			
			sortedCourseList.forEach(function(courseObj) {
                if(count<3){
    				var ctrlVertLayout = new sap.ui.layout.VerticalLayout();
    				ctrlVertLayout.addContent(new sap.m.Label({
    					text: courseObj.Name,
    					design : "Bold"
    				}));
       				ctrlVertLayout.addContent(new sap.m.Text({
    					text: courseObj.Description,
    					wrapping: true
    				}));
    				ctrlVertLayout.addContent(new sap.m.Text({
    					//text: hcm.people.profile.util.UIHelper.formatDate(courseObj.BeginDate) +
    					//	" - " + hcm.people.profile.util.UIHelper.formatDate(courseObj.EndDate),
    					text : hcm.people.profile.util.UIHelper.buildTimePeriod(courseObj.BeginDate,courseObj.EndDate,true),
    					wrapping: true
    				}));
    
    				ctrlCourseContainer.addContent(ctrlVertLayout);
    				count++;
                }
			});

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});