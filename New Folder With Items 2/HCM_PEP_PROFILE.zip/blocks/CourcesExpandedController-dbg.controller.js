/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");

sap.ui.controller("hcm.people.profile.blocks.CourcesExpandedController", {

	onInit: function() {
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var ctrlCourseContainer = that.byId("ctrlCourseContainer");
		var sortedCourseList = 	hcm.people.profile.util.UIHelper.getDataCourses();

		sortedCourseList.forEach(function(courseObj) {

				var ctrlVertLayout = new sap.ui.layout.VerticalLayout();
				ctrlVertLayout.addContent(new sap.m.Label({
					text: courseObj.Name,
					design : "Bold"
				}));
				ctrlVertLayout.addContent(new sap.m.Text({
					text: courseObj.Description,
					wrapping: true
				}));
				ctrlVertLayout.addContent(new sap.m.Text({
    				//text: hcm.people.profile.util.UIHelper.formatDate(courseObj.BeginDate) +
    				//	" - " + hcm.people.profile.util.UIHelper.formatDate(courseObj.EndDate),
    				text : hcm.people.profile.util.UIHelper.buildTimePeriod(courseObj.BeginDate,courseObj.EndDate,true),
					wrapping: true
				}));
				
				ctrlCourseContainer.addContent(ctrlVertLayout);
		});

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});