/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("hcm.people.profile.util.UIHelper");
jQuery.sap.require("sap.viz.ui5.controls.VizFrame");

sap.ui.controller("hcm.people.profile.blocks.PerformanceCollapsedController", {

	onInit: function() {
		this.ctrlPerfChartsHolder = this.byId("ctrlPerfChartsHolder");
		this.buildUI();
	},

	onExit: function() {

	},

	buildUI: function() {
		var that = this;
		var pernr = hcm.people.profile.util.UIHelper.getPernr();

		var oDataModel = hcm.people.profile.util.UIHelper.getODataModel();

		var queryPath = "EmployeeDataSet('" + pernr + "')/PerformanceSet";

		oDataModel.read(queryPath, null, null, true, function(response) {

			if (response.results.length > 0) {

				var sortedPerformanceList = hcm.people.profile.util.UIHelper.sortArrayByProperty(response.results, "BeginDate");
				
				hcm.people.profile.util.UIHelper.setDataPerf(sortedPerformanceList);

				var groupScaleList = [];
				var groupColl = [];

				sortedPerformanceList.forEach(function(perfItem) {

					if (groupColl[perfItem.ScaleCount.toString()]) {
						groupColl[perfItem.ScaleCount.toString()].vals.push(perfItem);
					} else {
						groupScaleList.push(perfItem.ScaleCount.toString());
						groupColl[perfItem.ScaleCount.toString()] = {
							"groupScale": perfItem.ScaleCount.toString(),
							vals: []
						};
						groupColl[perfItem.ScaleCount.toString()].vals.push(perfItem);
					}
				});
				
				if(groupScaleList.length>1){
				    var subSecPerf = hcm.people.profile.util.UIHelper.getSubSecPerf();
				    subSecPerf.getBlocks()[0].setShowSubSectionMore(true);
				}

				var grpScale = groupScaleList[groupScaleList.length-1];
				that.ctrlPerfChartsHolder.insertContent(that.buildChart(grpScale, groupColl[grpScale].vals));


			} else {
				var noOfYears = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().PerformanceNoOfYears);
				that.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERF_NO_DATA", [noOfYears]));
				that.byId("dispStatusMsg").setVisible(true);
			}

		}, function(response) {
			jQuery.sap.log.getLogger().error("Data fetch failed" + response.toString());
		});

	},

	buildChart: function(grpScale, perfObjCollection) {

		var ctrlPerfChart = new sap.viz.ui5.controls.VizFrame({
			'uiConfig': {'applicationSet':'fiori'},
			'vizType': "line"
		});
		var strAppraisalRating = hcm.people.profile.util.UIHelper.getResourceBundle().getText("APPRAISAL_RATING");
		var strPeriod = hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERIOD");
		
		if (sap.ui.Device.system.desktop) {
			ctrlPerfChart.setWidth("80%");
		} else if (sap.ui.Device.system.tablet) {
			ctrlPerfChart.setWidth("90%");
		} else {
			ctrlPerfChart.setWidth("100%");
		}

        var perfCollection = [];
		perfObjCollection.forEach(function(performance) {
			var period = hcm.people.profile.util.UIHelper.buildTimePeriod(performance.BeginDate,performance.EndDate,false);
			perfCollection.push({
				AppraisalRating: performance.AppraisalRating,
				Period: period
			});
		});

		var oModel = new sap.ui.model.json.JSONModel({
			Performance: perfCollection
		});

		var oDataset = new sap.viz.ui5.data.FlattenedDataset({
			dimensions: [{
				name: strPeriod,
				value: "{Period}"
                   }],
			measures: [
				{
					name: strAppraisalRating,
					value: '{AppraisalRating}'
                        }
                   ],
			data: {
				path: "/Performance"
			}
		});

		ctrlPerfChart.setVizProperties({
			valueAxis: {
				label: {
					formatString: 'u'
				}
			},
			legendGroup: {
				layout: {
					//position : "bottom"
				}
			},
			plotArea: {
				dataLabel: {
					visible: true
				}
			},
			yAxis: {
				scale: {
					fixedRange: true,
					maxValue: parseInt(grpScale),
					minValue: 0
				}
			},
			legend: {
				visible: true,
				isScrollable: true,
				title: {
					visible: false
				}
			},
			title: {
				visible: false,
				text: ''
			},
			interaction: {
				selectability: {
					mode: "none",
					axisLabelSelection: false,
					plotLassoSelection: false,
					plotStdSelection: false

				}
			}

		});

		ctrlPerfChart.setModel(oModel);
		ctrlPerfChart.setDataset(oDataset);

		var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "primaryValues",
				'type': "Measure",
				'values': [strAppraisalRating]
			}),
			feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
				'uid': "axisLabels",
				'type': "Dimension",
				'values': [strPeriod]
			});

		ctrlPerfChart.addFeed(feedPrimaryValues);
		ctrlPerfChart.addFeed(feedAxisLabels);

		ctrlPerfChart.attachRenderComplete(function(evt){
    	   $("#" + evt.getParameters().id).find('.ui5-viz-controls-app').css( "background-color", "transparent" );
    	   $("#" + evt.getParameters().id).find('.ui5-viz-controls-viz-frame').css( "background-color", "transparent" );
    	});
	    
		return ctrlPerfChart;
	},
	
	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	}

});