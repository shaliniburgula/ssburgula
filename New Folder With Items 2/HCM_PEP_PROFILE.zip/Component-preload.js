jQuery.sap.registerPreloadedModules({
	"name": "hcm/people/profile/Component-preload",
	"version": "2.0",
	"modules": {
		"hcm/people/profile/Component.js": function() {
			/*
			 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
			 */
			jQuery.sap.declare("hcm.people.profile.Component");
			jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
			(function() {
				var p = jQuery.sap.getModulePath("hcm.people.profile");
				if (p.indexOf("/hcm_pep_profile") !== -1) {
					if (p.lastIndexOf("/") !== p.length - 1) {
						p += "/";
					}
					jQuery.sap.registerModulePath("sap.hcm.lib.common", p + "../hcm_common/sap/hcm/lib/common/");
				}
			}());
			sap.ca.scfld.md.ComponentBase.extend("hcm.people.profile.Component", {
				metadata: sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
					"name": "Fullscreen Sample",
					"version": "1.8.0",
					"library": "hcm.people.profile",
					"includes": [],
					"dependencies": {
						"libs": ["sap.m", "sap.me", "sap.uxap"],
						"components": []
					},
					"config": {
						"resourceBundle": "i18n/i18n.properties",
						"titleResource": "PEOPLE_PROFILE"
					},
					viewPath: "hcm.people.profile.view",
					fullScreenPageRoutes: {
						"fullscreen": {
							"pattern": "",
							"view": "Profile"
						}
					}
				}),
				createContent: function() {
					var v = {
						component: this
					};
					return sap.ui.view({
						viewName: "hcm.people.profile.Main",
						type: sap.ui.core.mvc.ViewType.XML,
						viewData: v
					});
				}
			});
		},
		"hcm/people/profile/Configuration.js": function() {
			jQuery.sap.declare("hcm.people.profile.Configuration");
			jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
			jQuery.sap.require("sap.ca.scfld.md.app.Application");
			sap.ca.scfld.md.ConfigurationBase.extend("hcm.people.profile.Configuration", {
				oServiceParams: {
					serviceList: [{
						name: "HCM_PEOPLE_PROFILE_SRV",
						serviceUrl: "/sap/opu/odata/sap/HCM_PEOPLE_PROFILE_SRV/",
						isDefault: true,
						useBatch: true,
						mockedDataSource: "/hcm.people.profile/model/metadata.xml"
					}, {
						name: "NOTIFICATIONSTORE",
						serviceUrl: "/sap/opu/odata/IWFND/NOTIFICATIONSTORE",
						isDefault: false
					}]
				},
				getServiceParams: function() {
					return this.oServiceParams;
				},
				getAppConfig: function() {
					return this.oAppConfig;
				},
				getServiceList: function() {
					return this.oServiceParams.serviceList;
				}
			});
		},
		"hcm/people/profile/Main.controller.js": function() {
			sap.ui.controller("hcm.people.profile.Main", {
				onInit: function() {
					jQuery.sap.require("sap.ca.scfld.md.Startup");
					sap.ui.getCore().loadLibrary("sap.hcm.lib.common");
					sap.ca.scfld.md.Startup.init("hcm.people.profile", this);
				},
				onExit: function() {
					try {
						var p = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
						var d = hcm.people.profile.util.UIHelper.getCachedPersData();
						if (d.crossAppNavFlag !== true) {
							p.delPersData();
							hcm.people.profile.util.UIHelper.cachePersData(null);
						}
					} catch (a) {}
					try {
						var c = hcm.people.profile.util.UIHelper.getControllerInstance();
						if (c.oCEDialog.isOpen()) {
							c.oCEDialog.Cancelled = true;
							c.oCEDialog.close();
						}
					} catch (e) {
						jQuery.sap.log.error("couldn't execute onExit", ["onExit failed in main controller"], ["hcm.people.profile.Main"]);
					}
				}
			});
		},
		"hcm/people/profile/Main.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:core="sap.ui.core"\n           xmlns="sap.m" controllerName="hcm.people.profile.Main"  displayBlock="true" height="100%">\n        <App id="fioriContent" showHeader="false">\n        </App>\n</core:View>',
		"hcm/people/profile/blocks/Cources.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Cources");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Cources", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.CourcesCollapsed",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.CourcesExpanded",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/CourcesCollapsed.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.CourcesCollapsedController">\n        \n        <layout:Grid  id="ctrlCourseContainer" defaultSpan="L4 M6 S12" hSpacing="0"> \n        </layout:Grid>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n</mvc:View>\n',
		"hcm/people/profile/blocks/CourcesCollapsedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.CourcesCollapsedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var c = hcm.people.profile.util.UIHelper.getConfiguration();
					var a = t.byId("ctrlCourseContainer");
					var q = "EmployeeDataSet('" + p + "')/CourseSet";
					d.read(q, null, null, true, function(r) {
						var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "BeginDate");
						hcm.people.profile.util.UIHelper.setDataCourses(s);
						if (s.length > 3) {
							var b = hcm.people.profile.util.UIHelper.getSubSecCourses();
							b.getBlocks()[0].setShowSubSectionMore(true);
						}
						if (s.length === 0) {
							a.setVisible(false);
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("COURSES_NO_DATA", [parseInt(c.CourseNoOfMonths)]));
							t.byId("dispStatusMsg").setVisible(true);
						}
						var e = 0;
						s.forEach(function(f) {
							if (e < 3) {
								var g = new sap.ui.layout.VerticalLayout();
								g.addContent(new sap.m.Label({
									text: f.Name,
									design: "Bold"
								}));
								g.addContent(new sap.m.Text({
									text: f.Description,
									wrapping: true
								}));
								g.addContent(new sap.m.Text({
									text: hcm.people.profile.util.UIHelper.buildTimePeriod(f.BeginDate, f.EndDate, true),
									wrapping: true
								}));
								a.addContent(g);
								e++;
							}
						});
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/CourcesExpanded.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.CourcesExpandedController">\n        \n        <layout:Grid  id="ctrlCourseContainer" defaultSpan="L4 M6 S12" hSpacing="0">  \n        </layout:Grid>\n</mvc:View>\n',
		"hcm/people/profile/blocks/CourcesExpandedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.CourcesExpandedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var c = t.byId("ctrlCourseContainer");
					var s = hcm.people.profile.util.UIHelper.getDataCourses();
					s.forEach(function(a) {
						var b = new sap.ui.layout.VerticalLayout();
						b.addContent(new sap.m.Label({
							text: a.Name,
							design: "Bold"
						}));
						b.addContent(new sap.m.Text({
							text: a.Description,
							wrapping: true
						}));
						b.addContent(new sap.m.Text({
							text: hcm.people.profile.util.UIHelper.buildTimePeriod(a.BeginDate, a.EndDate, true),
							wrapping: true
						}));
						c.addContent(b);
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/Notes.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Notes");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Notes", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.Notes",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.Notes",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/Notes.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.NotesController">\n        \n        <m:List id="ctrlNotesFeed" items="{EntryCollection}" growing="true" growingThreshold="5">\n            <m:FeedListItem id="ctrlNotesEntry"\n              icon="/sap/opu/odata/sap/HCM_PEOPLE_PROFILE_SRV/NotesSet(Employeenumber=\'{Employeenumber}\',NoteEmployeeNo=\'{NoteEmployeeNo}\')/$value"\n              sender="{NoteEmplName}"\n              senderActive="false"\n              iconActive="false"\n              iconDensityAware="false"\n              info="{NoteTitle}"\n              timestamp="{Timestamp}"\n              text="{NoteText}" />\n        </m:List>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n</mvc:View>\n',
		"hcm/people/profile/blocks/NotesController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.NotesController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var q = "EmployeeDataSet('" + p + "')/NotesSet";
					d.read(q, null, null, true, function(r) {
						var n = [];
						r.results.forEach(function(a) {
							a.Timestamp = hcm.people.profile.util.UIHelper.formatTime(a.Timestamp);
							n.push(a);
						});
						if (n.length > 0) {
							var N = {
								"EntryCollection": n
							};
							var m = new sap.ui.model.json.JSONModel(N);
							t.byId("ctrlNotesFeed").setModel(m);
							t.byId("ctrlNotesFeed").bindItems("/EntryCollection", t.byId("ctrlNotesEntry"));
							t.byId("lblDispMsg").setVisible(false);
						} else {
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("NOTES_NO_DATA"));
							t.byId("dispStatusMsg").setVisible(true);
							t.byId("ctrlNotesFeed").setVisible(false);
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/Notifications.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Notifications");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Notifications", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.NotificationsCollapsed",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.NotificationsExpanded",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/NotificationsCollapsed.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:l="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        controllerName="hcm.people.profile.blocks.NotificationsCollapsedController">\n\n        <l:VerticalLayout id="ctrlNotiList">\n        </l:VerticalLayout>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n</mvc:View>\n',
		"hcm/people/profile/blocks/NotificationsCollapsedController.controller.js": function() {
			sap.ui.controller("hcm.people.profile.blocks.NotificationsCollapsedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var n = hcm.people.profile.util.UIHelper.getNotifODataModel();
					n.read("NotificationCollection", null, null, true, function(r) {
						if (r.results.length === 0) {
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("NOTIF_NO_DATA"));
							t.byId("dispStatusMsg").setVisible(true);
							t.byId("ctrlNotifHolder").setVisible(false);
						} else {
							t.byId("dispStatusMsg").setVisible(false);
							var a = r.results;
							hcm.people.profile.util.UIHelper.setDataNotf(a);
							if (a.length > 4) {
								var s = hcm.people.profile.util.UIHelper.getSubSecNotf();
								s.getBlocks()[0].setShowSubSectionMore(true);
							}
							var c = 0;
							a.forEach(function(b) {
								if (c < 4) {
									var d = new sap.m.Text({
										text: b.Title
									});
									d.addStyleClass("sapHcmTitleFont");
									t.byId("ctrlNotiList").addContent(d);
									var e = new sap.m.Text({
										text: hcm.people.profile.util.UIHelper.formatTime(b.Updated)
									});
									e.addStyleClass("sapHcmSubtitleFont");
									t.byId("ctrlNotiList").addContent(e);
									t.byId("ctrlNotiList").addContent(new sap.m.Text());
									c++;
								}
							});
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/NotificationsExpanded.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:l="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        controllerName="hcm.people.profile.blocks.NotificationsExpandedController">\n\n        <l:VerticalLayout id="ctrlNotiList">\n        </l:VerticalLayout>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n</mvc:View>\n',
		"hcm/people/profile/blocks/NotificationsExpandedController.controller.js": function() {
			sap.ui.controller("hcm.people.profile.blocks.NotificationsExpandedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var n = hcm.people.profile.util.UIHelper.getDataNotf();
					n.forEach(function(a) {
						var b = new sap.m.Text({
							text: a.Title
						});
						b.addStyleClass("sapHcmECTitleFont");
						t.byId("ctrlNotiList").addContent(b);
						var c = new sap.m.Text({
							text: hcm.people.profile.util.UIHelper.formatTime(a.Updated)
						});
						c.addStyleClass("sapHcmECSubtitle");
						t.byId("ctrlNotiList").addContent(c);
						t.byId("ctrlNotiList").addContent(new sap.m.Text());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/Payslip.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Payslip");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Payslip", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.PayslipCollapsed",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.PayslipExpanded",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/PayslipCollapsed.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.PayslipCollapsedController">\n                   \n        <layout:Grid id="ctrlPayslipContainer" defaultSpan="L4 M6 S12" hSpacing="0">  \n        </layout:Grid>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n        <m:Link text="{i18n>VIEW_PAYSLIP}" press="onViewPayslip" emphasized="true"></m:Link>    \n</mvc:View>\n',
		"hcm/people/profile/blocks/PayslipCollapsedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.PayslipCollapsedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var c = t.byId("ctrlPayslipContainer");
					var q = "EmployeeDataSet('" + p + "')/PaystubSet";
					d.read(q, null, null, true, function(r) {
						var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "-Paydate");
						hcm.people.profile.util.UIHelper.setDataPayslip(s);
						if (s.length > 3) {
							var a = hcm.people.profile.util.UIHelper.getSubSecPayslip();
							a.getBlocks()[0].setShowSubSectionMore(true);
						}
						if (s.length === 0) {
							var n = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().PaystubNoOfMonths);
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PAYSLIP_NO_DATA", [n]));
							t.byId("dispStatusMsg").setVisible(true);
							c.setVisible(false);
						}
						var b = 0;
						s.forEach(function(e) {
							if (b < 3) {
								var f = new sap.ui.layout.VerticalLayout();
								var g = e.Amount.toString().length;
								var h = "";
								if (g === 1) {
									h = "6rem";
								} else if (g === 2) {
									h = "7rem";
								} else if (g === 3) {
									h = "8rem";
								} else if (g === 4) {
									h = "9rem";
								} else {
									h = (g + 5) + "rem";
								}
								var i = new sap.suite.ui.commons.NumericContent({
									value: hcm.people.profile.util.UIHelper.formatNumber(e.Amount) + " " + e.Currency,
									valueUnit: e.Currency,
									size: "S",
									icon: "sap-icon://monitor-payments",
									tooltip: hcm.people.profile.util.UIHelper.formatNumber(e.Amount) + " " + e.Currency,
									scale: e.Currency,
									formatterValue: true,
									iconDescription: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY"),
									width: h,
									truncateValueTo: g
								});
								f.addContent(i);
								f.addContent(new sap.m.Label({
									text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY")
								}));
								f.addContent(new sap.m.Label({
									text: hcm.people.profile.util.UIHelper.formatDate(e.Paydate)
								}));
								c.addContent(f);
								b++;
							}
						});
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onAfterRendering: function() {},
				onBeforeRendering: function() {},
				onViewPayslip: function() {
					sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
						target: {
							semanticObject: "RemunerationStatement",
							action: "display"
						}
					});
				}
			});
		},
		"hcm/people/profile/blocks/PayslipExpanded.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.PayslipExpandedController">\n                   \n        <layout:Grid id="ctrlPayslipContainer" defaultSpan="L4 M6 S12" hSpacing="0">  \n        </layout:Grid>\n        <m:Link text="{i18n>VIEW_PAYSLIP}" press="onViewPayslip" emphasized="true"></m:Link>    \n</mvc:View>\n',
		"hcm/people/profile/blocks/PayslipExpandedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.PayslipExpandedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var c = t.byId("ctrlPayslipContainer");
					var s = hcm.people.profile.util.UIHelper.getDataPayslip();
					s.forEach(function(p) {
						var a = new sap.ui.layout.VerticalLayout();
						var b = p.Amount.toString().length;
						var d = "";
						if (b === 1) {
							d = "6rem";
						} else if (b === 2) {
							d = "7rem";
						} else if (b === 3) {
							d = "8rem";
						} else if (b === 4) {
							d = "9rem";
						} else {
							d = (b + 5) + "rem";
						}
						var e = new sap.suite.ui.commons.NumericContent({
							value: hcm.people.profile.util.UIHelper.formatNumber(p.Amount) + " " + p.Currency,
							valueUnit: p.Currency,
							size: "S",
							icon: "sap-icon://monitor-payments",
							scale: p.Currency,
							tooltip: hcm.people.profile.util.UIHelper.formatNumber(p.Amount) + " " + p.Currency,
							formatterValue: true,
							iconDescription: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY"),
							width: d,
							truncateValueTo: b
						});
						a.addContent(e);
						a.addContent(new sap.m.Label({
							text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("TAKE_HOME_PAY")
						}));
						a.addContent(new sap.m.Label({
							text: hcm.people.profile.util.UIHelper.formatDate(p.Paydate)
						}));
						c.addContent(a);
					});
				},
				onAfterRendering: function() {},
				onBeforeRendering: function() {},
				onViewPayslip: function() {
					sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
						target: {
							semanticObject: "RemunerationStatement",
							action: "display"
						}
					});
				}
			});
		},
		"hcm/people/profile/blocks/Performance.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Performance");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Performance", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.PerformanceCollapsed",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.PerformanceExpanded",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/PerformanceCollapsed.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:viz="sap.viz.ui5.controls" \n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.PerformanceCollapsedController">\n\n        <layout:VerticalLayout id="ctrlPerfChartsHolder" width="100%"></layout:VerticalLayout>\n\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n \n</mvc:View>\n',
		"hcm/people/profile/blocks/PerformanceCollapsedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			jQuery.sap.require("sap.viz.ui5.controls.VizFrame");
			sap.ui.controller("hcm.people.profile.blocks.PerformanceCollapsedController", {
				onInit: function() {
					this.ctrlPerfChartsHolder = this.byId("ctrlPerfChartsHolder");
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var q = "EmployeeDataSet('" + p + "')/PerformanceSet";
					d.read(q, null, null, true, function(r) {
						if (r.results.length > 0) {
							var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "BeginDate");
							hcm.people.profile.util.UIHelper.setDataPerf(s);
							var g = [];
							var a = [];
							s.forEach(function(e) {
								if (a[e.ScaleCount.toString()]) {
									a[e.ScaleCount.toString()].vals.push(e);
								} else {
									g.push(e.ScaleCount.toString());
									a[e.ScaleCount.toString()] = {
										"groupScale": e.ScaleCount.toString(),
										vals: []
									};
									a[e.ScaleCount.toString()].vals.push(e);
								}
							});
							if (g.length > 1) {
								var b = hcm.people.profile.util.UIHelper.getSubSecPerf();
								b.getBlocks()[0].setShowSubSectionMore(true);
							}
							var c = g[g.length - 1];
							t.ctrlPerfChartsHolder.insertContent(t.buildChart(c, a[c].vals));
						} else {
							var n = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().PerformanceNoOfYears);
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERF_NO_DATA", [n]));
							t.byId("dispStatusMsg").setVisible(true);
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				buildChart: function(g, p) {
					var c = new sap.viz.ui5.controls.VizFrame({
						'uiConfig': {
							'applicationSet': 'fiori'
						},
						'vizType': "line"
					});
					var s = hcm.people.profile.util.UIHelper.getResourceBundle().getText("APPRAISAL_RATING");
					var a = hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERIOD");
					if (sap.ui.Device.system.desktop) {
						c.setWidth("80%");
					} else if (sap.ui.Device.system.tablet) {
						c.setWidth("90%");
					} else {
						c.setWidth("100%");
					}
					var b = [];
					p.forEach(function(h) {
						var i = hcm.people.profile.util.UIHelper.buildTimePeriod(h.BeginDate, h.EndDate, false);
						b.push({
							AppraisalRating: h.AppraisalRating,
							Period: i
						});
					});
					var m = new sap.ui.model.json.JSONModel({
						Performance: b
					});
					var d = new sap.viz.ui5.data.FlattenedDataset({
						dimensions: [{
							name: a,
							value: "{Period}"
						}],
						measures: [{
							name: s,
							value: '{AppraisalRating}'
						}],
						data: {
							path: "/Performance"
						}
					});
					c.setVizProperties({
						valueAxis: {
							label: {
								formatString: 'u'
							}
						},
						legendGroup: {
							layout: {}
						},
						plotArea: {
							dataLabel: {
								visible: true
							}
						},
						yAxis: {
							scale: {
								fixedRange: true,
								maxValue: parseInt(g),
								minValue: 0
							}
						},
						legend: {
							visible: true,
							isScrollable: true,
							title: {
								visible: false
							}
						},
						title: {
							visible: false,
							text: ''
						},
						interaction: {
							selectability: {
								mode: "none",
								axisLabelSelection: false,
								plotLassoSelection: false,
								plotStdSelection: false
							}
						}
					});
					c.setModel(m);
					c.setDataset(d);
					var f = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "primaryValues",
							'type': "Measure",
							'values': [s]
						}),
						e = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "axisLabels",
							'type': "Dimension",
							'values': [a]
						});
					c.addFeed(f);
					c.addFeed(e);
					c.attachRenderComplete(function(h) {
						$("#" + h.getParameters().id).find('.ui5-viz-controls-app').css("background-color", "transparent");
						$("#" + h.getParameters().id).find('.ui5-viz-controls-viz-frame').css("background-color", "transparent");
					});
					return c;
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/PerformanceExpanded.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:viz="sap.viz.ui5.controls" \n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.PerformanceExpandedController">\n       \n        <layout:VerticalLayout id="ctrlPerfChartsHolder" width="100%"></layout:VerticalLayout>\n\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n \n</mvc:View>\n',
		"hcm/people/profile/blocks/PerformanceExpandedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			jQuery.sap.require("sap.viz.ui5.controls.VizFrame");
			sap.ui.controller("hcm.people.profile.blocks.PerformanceExpandedController", {
				onInit: function() {
					this.ctrlPerfChartsHolder = this.byId("ctrlPerfChartsHolder");
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var s = hcm.people.profile.util.UIHelper.getDataPerf();
					var g = [];
					var a = [];
					s.forEach(function(p) {
						if (a[p.ScaleCount.toString()]) {
							a[p.ScaleCount.toString()].vals.push(p);
						} else {
							g.push(p.ScaleCount.toString());
							a[p.ScaleCount.toString()] = {
								"groupScale": p.ScaleCount.toString(),
								vals: []
							};
							a[p.ScaleCount.toString()].vals.push(p);
						}
					});
					g.forEach(function(b) {
						t.ctrlPerfChartsHolder.insertContent(new sap.m.Text());
						t.ctrlPerfChartsHolder.insertContent(t.buildChart(b, a[b].vals));
					});
				},
				buildChart: function(g, p) {
					var c = new sap.viz.ui5.controls.VizFrame({
						'uiConfig': {
							'applicationSet': 'fiori'
						},
						'vizType': "line"
					});
					var s = hcm.people.profile.util.UIHelper.getResourceBundle().getText("APPRAISAL_RATING");
					var a = hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERIOD");
					if (sap.ui.Device.system.desktop) {
						c.setWidth("80%");
					} else if (sap.ui.Device.system.tablet) {
						c.setWidth("90%");
					} else {
						c.setWidth("100%");
					}
					var b = [];
					p.forEach(function(h) {
						var i = hcm.people.profile.util.UIHelper.buildTimePeriod(h.BeginDate, h.EndDate, false);
						b.push({
							AppraisalRating: h.AppraisalRating,
							Period: i
						});
					});
					var m = new sap.ui.model.json.JSONModel({
						Performance: b
					});
					var d = new sap.viz.ui5.data.FlattenedDataset({
						dimensions: [{
							name: a,
							value: "{Period}"
						}],
						measures: [{
							name: s,
							value: '{AppraisalRating}'
						}],
						data: {
							path: "/Performance"
						}
					});
					c.setVizProperties({
						valueAxis: {
							label: {
								formatString: 'u'
							}
						},
						legendGroup: {
							layout: {}
						},
						plotArea: {
							dataLabel: {
								visible: true
							}
						},
						yAxis: {
							scale: {
								fixedRange: true,
								maxValue: parseInt(g),
								minValue: 0
							}
						},
						legend: {
							visible: true,
							isScrollable: true,
							title: {
								visible: false
							}
						},
						title: {
							visible: false,
							text: ''
						},
						interaction: {
							selectability: {
								mode: "none",
								axisLabelSelection: false,
								plotLassoSelection: false,
								plotStdSelection: false
							}
						}
					});
					c.setModel(m);
					c.setDataset(d);
					var f = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "primaryValues",
							'type': "Measure",
							'values': [s]
						}),
						e = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "axisLabels",
							'type': "Dimension",
							'values': [a]
						});
					c.addFeed(f);
					c.addFeed(e);
					c.attachRenderComplete(function(h) {
						$("#" + h.getParameters().id).find('.ui5-viz-controls-app').css("background-color", "transparent");
						$("#" + h.getParameters().id).find('.ui5-viz-controls-viz-frame').css("background-color", "transparent");
					});
					return c;
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/PersInfo.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.PersInfo");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.PersInfo", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.PersInfo",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.PersInfo",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/PersInfo.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.PersInfoController">\n        \n        <!--<layout:Grid id="ctrlPersInfoHolder" width="100%" defaultSpan="L6 M6 S12">-->\n\n        <!--</layout:Grid> -->\n        \n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n \n</mvc:View>\n',
		"hcm/people/profile/blocks/PersInfoController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			jQuery.sap.require("sap.ui.layout.form.SimpleForm");
			sap.ui.controller("hcm.people.profile.blocks.PersInfoController", {
				onInit: function() {
					this.buildUI();
				},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var i = false;
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var q = "EmployeeDataSet('" + p + "')/PersonalInfoSet";
					d.read(q, null, null, true, function(r) {
						var a = r.results;
						var g = [];
						var b = [];
						var s = hcm.people.profile.util.UIHelper.getSecPersInfo();
						if (a.length > 0) {
							a.forEach(function(c) {
								if (b[c.Groupname]) {
									b[c.Groupname].vals.push({
										"Fieldlabel": c.Fieldlabel,
										"Fieldvalue": c.Fieldvalue
									});
								} else {
									g.push(c.Groupname);
									b[c.Groupname] = {
										"groupName": c.Groupname,
										vals: []
									};
									b[c.Groupname].vals.push({
										"Fieldlabel": c.Fieldlabel,
										"Fieldvalue": c.Fieldvalue
									});
								}
							});
							g.forEach(function(c) {
								var e = new sap.ui.layout.form.SimpleForm({
									maxContainerCols: 2,
									editable: false,
									layout: "ResponsiveGridLayout"
								});
								b[c].vals.forEach(function(h) {
									e.addContent(new sap.m.Label({
										text: h.Fieldlabel
									}));
									e.addContent(new sap.m.Text({
										text: h.Fieldvalue
									}));
								});
								if (!i) {
									var f = hcm.people.profile.util.UIHelper.getSubSecPersInfo();
									f.setTitle(c);
									f.insertBlock(e);
									i = true;
								} else {
									var n = new sap.uxap.ObjectPageSubSection({
										title: c
									});
									n.insertBlock(e);
									s.addSubSection(n);
								}
							});
						} else {
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PERS_NO_DATA"));
							t.byId("dispStatusMsg").setVisible(true);
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onExit: function() {},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/Progression.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Progression");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Progression", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.Progression",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.Progression",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/Progression.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.ProgressionController" id="viewProgression">\n        \n        <suite:Timeline id="ctrlProgressionTimeline" width="100%" showIcons="false" sortOldestFirst="true" showHeaderBar="false" enableAllInFilterItem="false"\n            growing="true" growingThreshold="3" enableBackendFilter="false" enableScroll="false">\n             <suite:content>\n              <!--<suite:TimelineItem-->\n              <!--  id="ctrlTimelineItem" -->\n              <!--  dateTime="{BeginDate}"-->\n              <!--  title="{PositionTxt}" -->\n              <!--  text="{OrgunitTxt}">-->\n              <!--</suite:TimelineItem>-->\n            </suite:content>\n        </suite:Timeline> \n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n\n</mvc:View>',
		"hcm/people/profile/blocks/ProgressionController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.ProgressionController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					this.ctrlProgressionTimeline = this.byId("ctrlProgressionTimeline");
					if (sap.ui.Device.system.phone) {
						this.ctrlProgressionTimeline.setAxisOrientation("Vertical");
					} else {
						this.ctrlProgressionTimeline.setAxisOrientation("Horizontal");
						this.getView().setHeight("200px");
					}
					var c = this.byId("ctrlProgressionTimeline");
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var q = "EmployeeDataSet('" + p + "')/ProgressionSet";
					d.read(q, null, null, true, function(r) {
						if (r.results.length > 0) {
							r.results.forEach(function(a) {
								var f = hcm.people.profile.util.UIHelper.formatDate(a.BeginDate);
								var b = new sap.suite.ui.commons.TimelineItem({
									title: a.PositionTxt,
									text: a.OrgunitTxt,
									dateTime: a.BeginDate
								});
								b.onAfterRendering = function(e) {
									var i = e.srcControl.getId() + "-shell";
									$("#" + i).find('.sapSuiteUiCommonsTimelineItemShellDateTime').text(f);
								};
								c.insertContent(b);
							});
						} else {
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("PROG_NO_DATA"));
							t.byId("dispStatusMsg").setVisible(true);
							c.setVisible(false);
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/Qualifications.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Qualifications");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Qualifications", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.QualificationsCollapsed",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.QualificationsExpanded",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/QualificationsCollapsed.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.QualificationsCollapsedController">\n        \n            <!--<m:Table id="ctrlQualificationsTbl" items="{qualifications}" backgroundDesign="Transparent">-->\n            <!--            <m:columns>-->\n            <!--             <m:Column demandPopin="true" popinHAlign="Left" popinDisplay="Block">-->\n            <!--                <m:Text text="{i18n>TOPIC}" />-->\n            <!--             </m:Column>-->\n            <!--             <m:Column demandPopin="true" popinHAlign="Left" popinDisplay="Block">-->\n            <!--                <m:Text text="{i18n>COMPETENCY_LEVEL}" />-->\n            <!--             </m:Column>     -->\n            <!--            </m:columns>-->\n            <!--            <m:items>-->\n            <!--            <m:ColumnListItem id="ctrlQualificationItem">-->\n            <!--              <m:cells>-->\n            <!--                <layout:VerticalLayout>-->\n            <!--                <m:Label text="{Name}" design="Bold" />-->\n            <!--                <m:Text text="{ValidUntil}" wrapping="true"/>-->\n            <!--                </layout:VerticalLayout>-->\n            <!--                <suite:BulletChart size="M" targetValue="{RequiredRating}" minValue="0" maxValue="{Scalecount}" class="marginTopLeft">-->\n            <!--                    <suite:actual>-->\n            <!--                    <suite:BulletChartData value="{Rating}" color="{Color}"/>-->\n            <!--                    </suite:actual>-->\n            <!--                    <suite:thresholds>-->\n            <!--                    <suite:BulletChartData value="0"/>-->\n            <!--                    </suite:thresholds>-->\n            <!--                </suite:BulletChart>      -->\n            <!--              </m:cells>-->\n            <!--            </m:ColumnListItem>-->\n            <!--            </m:items>-->\n            <!--</m:Table>-->\n \n        <layout:Grid  id="ctrlQualificationContainer" defaultSpan="L4 M6 S12" hSpacing="0">  \n        </layout:Grid>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n \n</mvc:View>\n',
		"hcm/people/profile/blocks/QualificationsCollapsedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.QualificationsCollapsedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var c = t.byId("ctrlQualificationContainer");
					var q = "EmployeeDataSet('" + p + "')/QualificationSet";
					d.read(q, null, null, true, function(r) {
						var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "ValidUntil");
						hcm.people.profile.util.UIHelper.setDataQualif(s);
						if (s.length > 3) {
							var a = hcm.people.profile.util.UIHelper.getSubSecQualif();
							a.getBlocks()[0].setShowSubSectionMore(true);
						}
						if (s.length === 0) {
							var n = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().QualificationNoOfMonths);
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("QUALIF_NO_DATA", [n]));
							t.byId("dispStatusMsg").setVisible(true);
							c.setVisible(false);
						}
						var b = 0;
						s.forEach(function(e) {
							if (b < 3) {
								var v = new sap.ui.layout.VerticalLayout();
								var f = new sap.suite.ui.commons.BulletChart({
									size: "M",
									targetValue: parseInt(e.RequiredRating),
									minValue: "0",
									maxValue: parseInt(e.ScaleCount)
								});
								f.setActual(new sap.suite.ui.commons.BulletChartData({
									value: parseInt(e.Rating),
									color: (parseInt(e.Rating) < parseInt(e.RequiredRating)) ? "Error" : "Good"
								}));
								f.addAggregation("thresholds", new sap.suite.ui.commons.BulletChartData({
									value: 0
								}));
								v.addContent(f);
								v.addContent(new sap.m.Label({
									text: e.Name,
									design: "Bold"
								}));
								v.addContent(new sap.m.Text({
									text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("VALID_UNTIL") + " " + hcm.people.profile.util.UIHelper.formatDate(
										e.ValidUntil),
									wrapping: true
								}));
								c.addContent(v);
								b++;
							}
						});
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/QualificationsExpanded.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.QualificationsExpandedController">\n        \n            <!--<m:Table id="ctrlQualificationsTbl" items="{qualifications}" backgroundDesign="Transparent">-->\n            <!--            <m:columns>-->\n            <!--             <m:Column demandPopin="true" popinHAlign="Left" popinDisplay="Block">-->\n            <!--                <m:Text text="{i18n>TOPIC}" />-->\n            <!--             </m:Column>-->\n            <!--             <m:Column demandPopin="true" popinHAlign="Left" popinDisplay="Block">-->\n            <!--                <m:Text text="{i18n>COMPETENCY_LEVEL}" />-->\n            <!--             </m:Column>     -->\n            <!--            </m:columns>-->\n            <!--            <m:items>-->\n            <!--            <m:ColumnListItem id="ctrlQualificationItem">-->\n            <!--              <m:cells>-->\n            <!--                <layout:VerticalLayout>-->\n            <!--                <m:Label text="{Name}" design="Bold" />-->\n            <!--                <m:Text text="{ValidUntil}" wrapping="true"/>-->\n            <!--                </layout:VerticalLayout>-->\n            <!--                <suite:BulletChart size="M" targetValue="{RequiredRating}" minValue="0" maxValue="{Scalecount}" class="marginTopLeft">-->\n            <!--                    <suite:actual>-->\n            <!--                    <suite:BulletChartData value="{Rating}" color="{Color}"/>-->\n            <!--                    </suite:actual>-->\n            <!--                    <suite:thresholds>-->\n            <!--                    <suite:BulletChartData value="0"/>-->\n            <!--                    </suite:thresholds>-->\n            <!--                </suite:BulletChart>      -->\n            <!--              </m:cells>-->\n            <!--            </m:ColumnListItem>-->\n            <!--            </m:items>-->\n            <!--</m:Table>-->\n \n        <layout:Grid  id="ctrlQualificationContainer" defaultSpan="L4 M6 S12" hSpacing="0">  \n        </layout:Grid>\n        <m:Label id="dispStatusMsg" visible="false"></m:Label>\n \n</mvc:View>\n',
		"hcm/people/profile/blocks/QualificationsExpandedController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.QualificationsExpandedController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var c = t.byId("ctrlQualificationContainer");
					var s = hcm.people.profile.util.UIHelper.getDataQualif();
					s.forEach(function(r) {
						var v = new sap.ui.layout.VerticalLayout();
						var b = new sap.suite.ui.commons.BulletChart({
							size: "M",
							targetValue: parseInt(r.RequiredRating),
							minValue: "0",
							maxValue: parseInt(r.ScaleCount)
						});
						b.setActual(new sap.suite.ui.commons.BulletChartData({
							value: parseInt(r.Rating),
							color: (parseInt(r.Rating) < parseInt(r.RequiredRating)) ? "Error" : "Good"
						}));
						b.addAggregation("thresholds", new sap.suite.ui.commons.BulletChartData({
							value: 0
						}));
						v.addContent(b);
						v.addContent(new sap.m.Label({
							text: r.Name,
							design: "Bold"
						}));
						v.addContent(new sap.m.Text({
							text: hcm.people.profile.util.UIHelper.getResourceBundle().getText("VALID_UNTIL") + " " + hcm.people.profile.util.UIHelper.formatDate(
								r.ValidUntil),
							wrapping: true
						}));
						c.addContent(v);
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/Salary.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Salary");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Salary", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.Salary",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.Salary",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/Salary.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:viz="sap.viz.ui5.controls" \n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.SalaryController">\n        \n        <!--<viz:Popover id="idPopOver"></viz:Popover>-->\n        <viz:VizFrame id="ctrlVizFrameSalary" uiConfig="{applicationSet:\'fiori\'}" vizType="stacked_bar">\n        </viz:VizFrame>\n        <m:Label id="dispStatusMsg" visible="false" design="Bold" width="100%"></m:Label>\n \n</mvc:View>\n',
		"hcm/people/profile/blocks/SalaryController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.SalaryController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					var p = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var q = "EmployeeDataSet('" + p + "')/CompensationSet";
					var c = t.byId("ctrlVizFrameSalary");
					if (sap.ui.Device.system.desktop) {
						c.setWidth("80%");
					} else if (sap.ui.Device.system.tablet) {
						c.setWidth("90%");
					} else {
						c.setWidth("100%");
					}
					d.read(q, null, null, true, function(r) {
						if (r.results.length > 0) {
							var S = [];
							var a = "";
							var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "Year");
							s.forEach(function(j) {
								var k = {};
								k.Category = hcm.people.profile.util.UIHelper.getResourceBundle().getText("BONUS");
								k.Compensation = j.Bonus;
								k.Year = j.Year;
								a = j.Currency;
								S.push(k);
								var l = {};
								l.Category = hcm.people.profile.util.UIHelper.getResourceBundle().getText("SALARY");
								l.Compensation = j.Salary;
								l.Year = j.Year;
								S.push(l);
							});
							var b = hcm.people.profile.util.UIHelper.getResourceBundle().getText("YEAR");
							var e = hcm.people.profile.util.UIHelper.getResourceBundle().getText("CATEGORY");
							var f = hcm.people.profile.util.UIHelper.getResourceBundle().getText("COMPENSATION");
							f = f + " (" + a + ")";
							var m = new sap.ui.model.json.JSONModel({
								SalaryBonus: S
							});
							var D = new sap.viz.ui5.data.FlattenedDataset({
								dimensions: [{
									name: b,
									value: "{Year}"
								}, {
									name: e,
									value: "{Category}"
								}],
								measures: [{
									name: f,
									value: '{Compensation}'
								}],
								data: {
									path: "/SalaryBonus"
								}
							});
							c.setVizProperties({
								valueAxis: {
									label: {
										formatString: 'u'
									}
								},
								plotArea: {
									dataLabel: {
										visible: true
									}
								},
								legend: {
									visible: true,
									title: {
										visible: true
									}
								},
								title: {
									visible: false,
									text: " "
								},
								interaction: {
									selectability: {
										mode: "none",
										axisLabelSelection: false,
										plotLassoSelection: false,
										plotStdSelection: false
									}
								},
								legendGroup: {
									layout: {}
								}
							});
							c.setModel(m);
							c.setDataset(D);
							var g = new sap.viz.ui5.controls.common.feeds.FeedItem({
									'uid': "primaryValues",
									'type': "Measure",
									'values': [f]
								}),
								h = new sap.viz.ui5.controls.common.feeds.FeedItem({
									'uid': "axisLabels",
									'type': "Dimension",
									'values': [b]
								}),
								i = new sap.viz.ui5.controls.common.feeds.FeedItem({
									'uid': "regionColor",
									'type': "Dimension",
									'values': [e]
								});
							c.addFeed(g);
							c.addFeed(h);
							c.addFeed(i);
							c.attachRenderComplete(function(j) {
								$("#" + j.getParameters().id).find('.ui5-viz-controls-app').css("background-color", "transparent");
								$("#" + j.getParameters().id).find('.ui5-viz-controls-viz-frame').css("background-color", "transparent");
							});
						} else {
							var n = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().CompensationNoOfYears);
							t.byId("dispStatusMsg").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("COMP_NO_DATA", [n]));
							t.byId("dispStatusMsg").setVisible(true);
							c.setVisible(false);
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {}
			});
		},
		"hcm/people/profile/blocks/TimeBalance.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.TimeBalance");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.TimeBalance", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.TimeBalance",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.TimeBalance",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "2"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/TimeBalance.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.TimeBalanceController">\n\n\n            <layout:VerticalLayout>\n            <m:Label text="{i18n>TIME_BALANCE_HEADER}" design="Bold"/>\n            <m:Label id="spaceHolder" visible="false" />\n            <m:Label id="spaceHolder2" visible="false" />\n            <suite:NumericContent id="ctrlNumericContent" size="S" formatterValue="true" icon="sap-icon://create-entry-time" />\n            <m:Label id="ctrlDispText" design="Bold" width="100%"/>\n            <m:Label id="ctrlDispAsOf"/>\n            <m:Label text=""/>\n            <m:Link text="{i18n>CREATE_TIME_EVENT}" press="onCreateTimePress" emphasized="true"></m:Link>\n            </layout:VerticalLayout>\n            \n</mvc:View>',
		"hcm/people/profile/blocks/TimeBalanceController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.TimeBalanceController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					t.pernr = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var c = t.byId("ctrlNumericContent");
					var a = t.byId("ctrlDispAsOf");
					var b = t.byId("ctrlDispText");
					var q = "EmployeeDataSet('" + t.pernr + "')/TimeBalanceSet";
					d.read(q, null, null, true, function(r) {
						var y, m, e, u, f;
						if (Number(r.AsofDate) !== 0) {
							u = r.AsofDate;
							y = u.substring(0, 4);
							m = u.substring(4, 6);
							e = u.substring(6, 8);
							f = hcm.people.profile.util.UIHelper.formatDate(new Date(y, m, e));
						} else {
							f = hcm.people.profile.util.UIHelper.formatDate(new Date());
						} if (r.BalanceText.length > 0) {
							var g = r.BalanceValue;
							var h = g.split(" ")[0].replace(",", ".");
							var i = g.split(" ")[1];
							var j = h.trim().length;
							c.setTruncateValueTo(j);
							var k = "";
							k = j + 4 + "rem";
							c.setWidth(k);
							c.setValue(h + " " + i);
							c.setTooltip(hcm.people.profile.util.UIHelper.formatNumber(h));
							b.setText(r.BalanceText);
							a.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("AS_OF", [f]));
						} else {
							c.setVisible(false);
							t.byId("spaceHolder").setVisible(true);
							t.byId("spaceHolder2").setVisible(true);
							b.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("TIME_BAL_NO_DATA_ASOF", [f]));
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {},
				onCreateTimePress: function() {
					var p = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
					var d = hcm.people.profile.util.UIHelper.getCachedPersData();
					if (d.crossAppNavFlag !== true) {
						d.crossAppNavFlag = true;
					}
					p.setPersData(d);
					hcm.people.profile.util.UIHelper.cachePersData(d);
					sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
						target: {
							semanticObject: "TimeEntry",
							action: "manageCorrections"
						},
						params: {
							"pernr": this.pernr
						}
					});
				}
			});
		},
		"hcm/people/profile/blocks/TimeRecording.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.TimeRecording");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.TimeRecording", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.TimeRecording",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.TimeRecording",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "1"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/TimeRecording.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.TimeRecordingController">\n\n\n            <layout:VerticalLayout>\n            <m:Label text="{i18n>TIME_RECORDING}" design="Bold"/>\n            <suite:NumericContent id="ctrlNumericContent" size="S" formatterValue="true" icon="sap-icon://time-entry-request" />\n            <m:Label id="ctrlDispText" design="Bold" width="100%"/>\n            <m:Label id="ctrlDispSince"/>\n            <m:Label text=""/>\n            <m:Link text="{i18n>RECORD_TIME}" press="onRecordTimePress" emphasized="true"></m:Link>\n            </layout:VerticalLayout>\n            \n</mvc:View>\n',
		"hcm/people/profile/blocks/TimeRecordingController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.TimeRecordingController", {
				onInit: function() {
					this.buildUI();
				},
				onExit: function() {},
				buildUI: function() {
					var t = this;
					t.pernr = hcm.people.profile.util.UIHelper.getPernr();
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var c = t.byId("ctrlNumericContent");
					var a = t.byId("ctrlDispText");
					var q = "EmployeeDataSet('" + t.pernr + "')/TimeRecording";
					d.read(q, null, null, true, function(r) {
						c.setValue(r.Missingdays);
						if (r.Missingdays && r.Missingdays !== 0) {
							var b = r.Missingdays.toString().trim().length;
							c.setTruncateValueTo(b);
							c.setValue(hcm.people.profile.util.UIHelper.formatNumber(r.Missingdays));
							c.setTooltip(r.Missingdays.toString());
							a.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("INCOMPLETE_DAYS"));
							t.byId("ctrlDispSince").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("SINCE") + " " + hcm.people.profile.util
								.UIHelper.formatDate(r.Startdate));
							var e = "";
							e = b + 4 + "rem";
							c.setWidth(e);
						} else {
							a.setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("TIME_NO_DATA"));
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onBeforeRendering: function() {},
				onAfterRendering: function() {},
				onRecordTimePress: function() {
					var p = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
					var d = hcm.people.profile.util.UIHelper.getCachedPersData();
					if (d.crossAppNavFlag !== true) {
						d.crossAppNavFlag = true;
					}
					p.setPersData(d);
					hcm.people.profile.util.UIHelper.cachePersData(d);
					sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
						target: {
							semanticObject: "TimeEntry",
							action: "manage"
						},
						params: {
							"pernr": this.pernr
						}
					});
				}
			});
		},
		"hcm/people/profile/blocks/Vacations.js": function() {
			jQuery.sap.declare("hcm.people.profile.blocks.Vacations");
			jQuery.sap.require("sap.uxap.BlockBase");
			sap.uxap.BlockBase.extend("hcm.people.profile.blocks.Vacations", {
				metadata: {
					views: {
						Collapsed: {
							viewName: "hcm.people.profile.blocks.Vacations",
							type: "XML"
						},
						Expanded: {
							viewName: "hcm.people.profile.blocks.Vacations",
							type: "XML"
						}
					},
					properties: {
						"columnLayout": {
							type: "sap.uxap.BlockBaseColumnLayout",
							group: "Behavior",
							defaultValue: "1"
						}
					}
				}
			});
		},
		"hcm/people/profile/blocks/Vacations.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<mvc:View\n        xmlns:core="sap.ui.core"\n        xmlns:mvc="sap.ui.core.mvc"\n        xmlns:layout="sap.ui.layout"\n        xmlns:f="sap.ui.layout.form"\n        xmlns:m="sap.m"\n        xmlns:suite="sap.suite.ui.commons" \n        controllerName="hcm.people.profile.blocks.VacationsController">\n\n            <layout:VerticalLayout>\n            <m:Label text="{i18n>UPCOMING_LEAVE}" design="Bold"/>\n            <suite:NumericContent id="ctrlNumericContent" size="S" formatterValue="true" icon="sap-icon://general-leave-request" />\n            <m:Label id="spaceHolder" visible="false" />\n            <m:Label id="spaceHolder2" visible="false" />\n            <m:Label id="cntrlVacStatus" visible="false" design="Bold" width="100%"/>\n            <m:Label id="cntrlVacType" design="Bold"/>\n            <m:Label id="cntrlVacDateRange"/>\n            <m:Label text=""/>\n            <m:Link text="{i18n>APPLY_LEAVE}" press="onApplyLeavePress" emphasized="true"></m:Link>\n             </layout:VerticalLayout>\n\n</mvc:View>\n',
		"hcm/people/profile/blocks/VacationsController.controller.js": function() {
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			sap.ui.controller("hcm.people.profile.blocks.VacationsController", {
				onInit: function() {
					this.buildUI();
				},
				buildUI: function() {
					var t = this;
					t.pernr = hcm.people.profile.util.UIHelper.getPernr();
					var c = this.byId("ctrlHeaderContainer");
					var a = t.byId("ctrlNumericContent");
					var d = hcm.people.profile.util.UIHelper.getODataModel();
					var C = hcm.people.profile.util.UIHelper.getConfiguration();
					var q = "EmployeeDataSet('" + t.pernr + "')/VacationSet";
					d.read(q, null, null, true, function(r) {
						var s = hcm.people.profile.util.UIHelper.sortArrayByProperty(r.results, "BeginDate");
						if (s[0]) {
							var b = s[0].Days.toString().trim().length;
							a.setTruncateValueTo(b);
							var e = "";
							e = b + 4 + "rem";
							a.setWidth(e);
							var f = hcm.people.profile.util.UIHelper.formatNumber(s[0].Days) + " " + hcm.people.profile.util.UIHelper.getResourceBundle().getText(
								"DAYS");
							a.setValue(f);
							a.setTooltip(f);
							t.byId("cntrlVacType").setText(s[0].Type + " - " + s[0].Status);
							t.byId("cntrlVacDateRange").setText(hcm.people.profile.util.UIHelper.buildTimePeriod(s[0].BeginDate, s[0].EndDate, true));
						} else {
							var n = parseInt(hcm.people.profile.util.UIHelper.getConfiguration().VacationNoOfMonths);
							t.byId("cntrlVacStatus").setText(hcm.people.profile.util.UIHelper.getResourceBundle().getText("LEAVES_NO_DATA", [n]));
							t.byId("spaceHolder").setVisible(true);
							t.byId("spaceHolder2").setVisible(true);
							t.byId("cntrlVacStatus").setVisible(true);
							a.setVisible(false);
						}
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
					});
				},
				onExit: function() {},
				onBeforeRendering: function() {},
				onAfterRendering: function() {},
				onApplyLeavePress: function() {
					var p = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
					var d = hcm.people.profile.util.UIHelper.getCachedPersData();
					if (d.crossAppNavFlag !== true) {
						d.crossAppNavFlag = true;
					}
					p.setPersData(d);
					hcm.people.profile.util.UIHelper.cachePersData(d);
					sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
						target: {
							semanticObject: "LeaveRequest",
							action: "manage"
						},
						params: {
							"pernr": this.pernr
						}
					});
				}
			});
		},
		"hcm/people/profile/i18n/i18n.properties": '#<Describe your application/i18n file here; required for translation >\r\n# __ldi.translation.uuid=3b42d5c8-5cc3-4e78-b201-a90d564f50f2\r\n# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=People Profile\r\n\r\n#XTIT: \r\nWHATS_NEW=Whats New!\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notes\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=My Personal Notes\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Personal Information\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notifications \r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Timesheet & Absences\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Upcoming Courses\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Qualifications/Skills\r\n\r\n#XTIT: \r\nPERFORMANCE=Performance\r\n\r\n#XTIT: \r\nPROGRESSION=Progression\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Payslip\r\n\r\n#XTIT: \r\nSALARY_BONUS=Salary and Bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Time Recording\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Upcoming Vacation\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Upcoming Leave\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=No data available for the last {0} months\r\n\r\n#XFLD\r\nLEAVES_NO_DATA=No upcoming leaves in the next {0} months\r\n\r\n#XFLD\r\nTIME_NO_DATA=Time recording is up to date\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=No time balances available as of {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=No payslips available in the last {0} months\r\n\r\n#XFLD\r\nQUALIF_NO_DATA=No qualifications available in the last {0} months\r\n\r\n#XFLD\r\nCOURSES_NO_DATA=No upcoming courses in the next {0} months\r\n\r\n#XFLD\r\nPERF_NO_DATA=No performance rating available for the last {0} years\r\n\r\n#XFLD\r\nCOMP_NO_DATA=No compensation data available for the last {0} years\r\n\r\n#XFLD\r\nPROG_NO_DATA=No progression data available \r\n\r\n#XFLD\r\nNOTIF_NO_DATA=No notifications available \r\n\r\n#XFLD\r\nNOTES_NO_DATA=No notes available \r\n\r\n#XFLD\r\nPERS_NO_DATA=No information available \r\n\r\n#XFLD\r\nNO_DATA=No data available\r\n\r\n#XFLD\r\nTOPIC=Topic\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Competency Level\r\n\r\n#XFLD\r\nVALID_UNTIL=Valid Until\r\n\r\n#XFLD\r\nDATEOFBIRTH=Date of Birth\r\n\r\n#XFLD\r\nMARITALSTATUS=Marital Status\r\n\r\n#XFLD\r\nMISSING_DAYS=Missing Days\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Incomplete Days\r\n\r\n#XFLD\r\nDAYS=Days\r\n\r\n#XFLD\r\nHOURS=Hours\r\n\r\n#XFLD\r\nSINCE=Since\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Salary & Bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Appraisal Rating\r\n\r\n#XFLD\r\nRECORD_TIME=Record Time\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Apply Leave\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=View Payslip\r\n\r\n#XFLD\r\nLOCATION=Location\r\n\r\n#XFLD\r\nOFFICE_PHONE=Office phone\r\n\r\n#XFLD\r\nEMAIL=Email\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Take home Pay\r\n\r\n#XFLD\r\nSALARY=Salary\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Year\r\n\r\n#XFLD\r\nCOMPENSATION=Compensation\r\n\r\n#XFLD\r\nCATEGORY=Category\r\n\r\n#XFLD\r\nPERIOD=Period\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Employee Hierarchy\r\n\r\n#XFLD\r\nAS_OF=As of {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Choose a Personnel Assignment\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Personnel Assignments\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY= An internal error Occurred. Please contact system administrator.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR= Internal Error\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Cancel\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT= Create Time Event\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER= Time Balance',
		"hcm/people/profile/i18n/i18n_ar.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=\\u0645\\u0644\\u0641 \\u062A\\u0639\\u0631\\u064A\\u0641 \\u0627\\u0644\\u0623\\u0634\\u062E\\u0627\\u0635\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u0627\\u0644\\u0645\\u0632\\u0627\\u064A\\u0627 \\u0627\\u0644\\u062C\\u062F\\u064A\\u062F\\u0629\r\n\r\n#XTIT: \r\nTALENT=\\u0627\\u0644\\u0645\\u0647\\u0627\\u0631\\u0629\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=\\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\\u064A \\u0627\\u0644\\u0634\\u062E\\u0635\\u064A\\u0629\r\n\r\n#XTIT: \r\nPERSONAL_INFO=\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062A \\u0634\\u062E\\u0635\\u064A\\u0629\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u0625\\u0634\\u0639\\u0627\\u0631\\u0627\\u062A\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=\\u0635\\u062D\\u064A\\u0641\\u0629 \\u0627\\u0644\\u062D\\u0636\\u0648\\u0631 \\u0648\\u0639\\u0645\\u0644\\u064A\\u0627\\u062A \\u0627\\u0644\\u063A\\u064A\\u0627\\u0628\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=\\u0627\\u0644\\u062F\\u0648\\u0631\\u0627\\u062A \\u0627\\u0644\\u062A\\u062F\\u0631\\u064A\\u0628\\u064A\\u0629 \\u0627\\u0644\\u0645\\u0642\\u0628\\u0644\\u0629\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=\\u0627\\u0644\\u0645\\u0624\\u0647\\u0644\\u0627\\u062A \\u0648\\u0627\\u0644\\u0645\\u0647\\u0627\\u0631\\u0627\\u062A\r\n\r\n#XTIT: \r\nPERFORMANCE=\\u0627\\u0644\\u0623\\u062F\\u0627\\u0621\r\n\r\n#XTIT: \r\nPROGRESSION=\\u062A\\u0642\\u062F\\u0645\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u0642\\u0633\\u064A\\u0645\\u0629 \\u0627\\u0644\\u0631\\u0627\\u062A\\u0628\r\n\r\n#XTIT: \r\nSALARY_BONUS=\\u0627\\u0644\\u0631\\u0627\\u062A\\u0628 \\u0648\\u0627\\u0644\\u0645\\u0643\\u0627\\u0641\\u0623\\u0629\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u062A\\u0633\\u062C\\u064A\\u0644 \\u0627\\u0644\\u0648\\u0642\\u062A\r\n\r\n#XFLD\r\nUPCOMING_VACATION=\\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0627\\u0644\\u0645\\u0642\\u0628\\u0644\\u0629\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=\\u0627\\u0644\\u0625\\u062C\\u0627\\u0632\\u0629 \\u0627\\u0644\\u0645\\u0642\\u0628\\u0644\\u0629\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u0644\\u0622\\u062E\\u0631 {0} \\u0645\\u0646 \\u0627\\u0644\\u0623\\u0634\\u0647\\u0631 \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u0644\\u0627 \\u062A\\u0648\\u062C\\u062F \\u0625\\u062C\\u0627\\u0632\\u0627\\u062A \\u0645\\u0642\\u0628\\u0644\\u0629 \\u0641\\u064A {0} \\u0645\\u0646 \\u0627\\u0644\\u0623\\u0634\\u0647\\u0631 \\u0627\\u0644\\u062A\\u0627\\u0644\\u064A\\u0629\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u062A\\u0633\\u062C\\u064A\\u0644 \\u0627\\u0644\\u0648\\u0642\\u062A \\u0645\\u062D\\u062F\\u0651\\u064E\\u062B\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0623\\u0631\\u0635\\u062F\\u0629 \\u0648\\u0642\\u062A \\u0627\\u0639\\u062A\\u0628\\u0627\\u0631\\u064B\\u0627 \\u0645\\u0646 {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0642\\u0633\\u0627\\u0626\\u0645 \\u0631\\u0627\\u062A\\u0628 \\u0641\\u064A \\u0622\\u062E\\u0631 {0} \\u0645\\u0646 \\u0627\\u0644\\u0623\\u0634\\u0647\\u0631 \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0645\\u0624\\u0647\\u0644\\u0627\\u062A \\u0641\\u064A \\u0622\\u062E\\u0631 {0} \\u0645\\u0646 \\u0627\\u0644\\u0623\\u0634\\u0647\\u0631 \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u0644\\u0627 \\u062A\\u0648\\u062C\\u062F \\u0628\\u0631\\u0627\\u0645\\u062C \\u062A\\u062F\\u0631\\u064A\\u0628\\u064A\\u0629 \\u0641\\u064A {0} \\u0645\\u0646 \\u0627\\u0644\\u0623\\u0634\\u0647\\u0631 \\u0627\\u0644\\u062A\\u0627\\u0644\\u064A\\u0629\r\n\r\n#XFLD\r\nPERF_NO_DATA=\\u0644\\u0627 \\u064A\\u062A\\u0648\\u0641\\u0631 \\u062A\\u0642\\u064A\\u064A\\u0645 \\u0623\\u062F\\u0627\\u0621 \\u0644\\u0622\\u062E\\u0631 {0} \\u0645\\u0646 \\u0627\\u0644\\u0633\\u0646\\u0648\\u0627\\u062A\r\n\r\n#XFLD\r\nCOMP_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u062A\\u0639\\u0648\\u064A\\u0636 \\u0644\\u0622\\u062E\\u0631 {0} \\u0645\\u0646 \\u0627\\u0644\\u0633\\u0646\\u0648\\u0627\\u062A\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A \\u062A\\u0642\\u062F\\u0645\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0625\\u0634\\u0639\\u0627\\u0631\\u0627\\u062A\r\n\r\n#XFLD\r\nNOTES_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0645\\u0644\\u0627\\u062D\\u0638\\u0627\\u062A\r\n\r\n#XFLD\r\nPERS_NO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062A\r\n\r\n#XFLD\r\nNO_DATA=\\u0644\\u0627 \\u062A\\u062A\\u0648\\u0641\\u0631 \\u0628\\u064A\\u0627\\u0646\\u0627\\u062A\r\n\r\n#XFLD\r\nTOPIC=\\u0627\\u0644\\u0645\\u0648\\u0636\\u0648\\u0639\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u0645\\u0633\\u062A\\u0648\\u0649 \\u0627\\u0644\\u0643\\u0641\\u0627\\u0621\\u0629\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u0635\\u0627\\u0644\\u062D \\u062D\\u062A\\u0649\r\n\r\n#XFLD\r\nDATEOFBIRTH=\\u062A\\u0627\\u0631\\u064A\\u062E \\u0627\\u0644\\u0645\\u064A\\u0644\\u0627\\u062F\r\n\r\n#XFLD\r\nMARITALSTATUS=\\u0627\\u0644\\u062D\\u0627\\u0644\\u0629 \\u0627\\u0644\\u0627\\u062C\\u062A\\u0645\\u0627\\u0639\\u064A\\u0629\r\n\r\n#XFLD\r\nMISSING_DAYS=\\u0627\\u0644\\u0623\\u064A\\u0627\\u0645 \\u0627\\u0644\\u0645\\u0641\\u0642\\u0648\\u062F\\u0629\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=\\u0623\\u064A\\u0627\\u0645 \\u063A\\u064A\\u0631 \\u0645\\u0643\\u062A\\u0645\\u0644\\u0629\r\n\r\n#XFLD\r\nDAYS=\\u0627\\u0644\\u0623\\u064A\\u0627\\u0645\r\n\r\n#XFLD\r\nHOURS=\\u0627\\u0644\\u0633\\u0627\\u0639\\u0627\\u062A\r\n\r\n#XFLD\r\nSINCE=\\u0645\\u0646\\u0630\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=\\u0627\\u0644\\u0631\\u0627\\u062A\\u0628 \\u0648\\u0627\\u0644\\u0645\\u0643\\u0627\\u0641\\u0623\\u0629\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u062A\\u0635\\u0646\\u064A\\u0641 \\u0627\\u0644\\u062A\\u0642\\u064A\\u064A\\u0645\r\n\r\n#XFLD\r\nRECORD_TIME=\\u062A\\u0633\\u062C\\u064A\\u0644 \\u0627\\u0644\\u0648\\u0642\\u062A\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u062A\\u0642\\u062F\\u064A\\u0645 \\u0625\\u062C\\u0627\\u0632\\u0629\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u0639\\u0631\\u0636 \\u0642\\u0633\\u064A\\u0645\\u0629 \\u0627\\u0644\\u0631\\u0627\\u062A\\u0628 \\u0627\\u0644\\u062A\\u0641\\u0635\\u064A\\u0644\\u064A\\u0629\r\n\r\n#XFLD\r\nLOCATION=\\u0627\\u0644\\u0645\\u0648\\u0642\\u0639\r\n\r\n#XFLD\r\nOFFICE_PHONE=\\u0647\\u0627\\u062A\\u0641 \\u0627\\u0644\\u0645\\u0643\\u062A\\u0628\r\n\r\n#XFLD\r\nEMAIL=\\u0627\\u0644\\u0628\\u0631\\u064A\\u062F \\u0627\\u0644\\u0625\\u0644\\u0643\\u062A\\u0631\\u0648\\u0646\\u064A\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u0627\\u0644\\u0645\\u0631\\u062A\\u0628 \\u0627\\u0644\\u0635\\u0627\\u0641\\u064A\r\n\r\n#XFLD\r\nSALARY=\\u0627\\u0644\\u0631\\u0627\\u062A\\u0628\r\n\r\n#XFLD\r\nBONUS=\\u0645\\u0643\\u0627\\u0641\\u0623\\u0629\r\n\r\n#XFLD\r\nYEAR=\\u0627\\u0644\\u0633\\u0646\\u0629\r\n\r\n#XFLD\r\nCOMPENSATION=\\u0627\\u0644\\u062A\\u0639\\u0648\\u064A\\u0636\r\n\r\n#XFLD\r\nCATEGORY=\\u0627\\u0644\\u0641\\u0626\\u0629\r\n\r\n#XFLD\r\nPERIOD=\\u0641\\u062A\\u0631\\u0629\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u0647\\u0631\\u0645\\u064A\\u0629 \\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\\u064A\\u0646\r\n\r\n#XFLD\r\nAS_OF=\\u0627\\u0639\\u062A\\u0628\\u0627\\u0631\\u064B\\u0627 \\u0645\\u0646 {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=\\u0627\\u062E\\u062A\\u0631 \\u062A\\u0639\\u064A\\u064A\\u0646 \\u0645\\u0648\\u0638\\u0641\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=\\u062A\\u0639\\u064A\\u064A\\u0646\\u0627\\u062A \\u0627\\u0644\\u0645\\u0648\\u0638\\u0641\\u064A\\u0646\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=\\u062D\\u062F\\u062B \\u062E\\u0637\\u0623 \\u062F\\u0627\\u062E\\u0644\\u064A. \\u0628\\u0631\\u062C\\u0627\\u0621 \\u0627\\u0644\\u0627\\u062A\\u0635\\u0627\\u0644 \\u0628\\u0645\\u0633\\u0624\\u0648\\u0644 \\u0627\\u0644\\u0646\\u0638\\u0627\\u0645.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=\\u062E\\u0637\\u0623 \\u062F\\u0627\\u062E\\u0644\\u064A\r\n\r\n#XBUT: Button to accept\r\nOK=\\u0645\\u0648\\u0627\\u0641\\u0642\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u0625\\u0644\\u063A\\u0627\\u0621\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=\\u0625\\u0646\\u0634\\u0627\\u0621 \\u062D\\u062F\\u062B \\u0632\\u0645\\u0646\\u064A\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u0631\\u0635\\u064A\\u062F \\u0627\\u0644\\u0648\\u0642\\u062A\r\n',
		"hcm/people/profile/i18n/i18n_bg.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=\\u041F\\u0440\\u043E\\u0444\\u0438\\u043B \\u043D\\u0430 \\u0445\\u043E\\u0440\\u0430\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u041A\\u0430\\u043A\\u0432\\u043E \\u043D\\u043E\\u0432\\u043E\r\n\r\n#XTIT: \r\nTALENT=\\u0422\\u0430\\u043B\\u0430\\u043D\\u0442\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=\\u0411\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=\\u041C\\u043E\\u0438\\u0442\\u0435 \\u043B\\u0438\\u0447\\u043D\\u0438  \\u0431\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\r\n\r\n#XTIT: \r\nPERSONAL_INFO=\\u041B\\u0438\\u0447\\u043D\\u0430 \\u0438\\u043D\\u0444\\u043E\\u0440\\u043C\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u0418\\u0437\\u0432\\u0435\\u0441\\u0442\\u0438\\u044F\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=\\u0412\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0440\\u0430\\u0437\\u0447\\u0435\\u0442 \\u0438 \\u043E\\u0442\\u0441\\u044A\\u0441\\u0442\\u0432\\u0438\\u044F\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=\\u041F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438 \\u043A\\u0443\\u0440\\u0441\\u043E\\u0432\\u0435\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=\\u041A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u0438 \\u0438 \\u0443\\u043C\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XTIT: \r\nPERFORMANCE=\\u041F\\u0440\\u043E\\u0438\\u0437\\u0432\\u043E\\u0434\\u0438\\u0442\\u0435\\u043B\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XTIT: \r\nPROGRESSION=\\u041D\\u0430\\u043F\\u0440\\u0435\\u0434\\u044A\\u043A\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u0424\\u0438\\u0448 \\u0437\\u0430 \\u0437\\u0430\\u043F\\u043B\\u0430\\u0442\\u0430\r\n\r\n#XTIT: \r\nSALARY_BONUS=\\u0417\\u0430\\u043F\\u043B\\u0430\\u0442\\u0430 \\u0438 \\u0431\\u043E\\u043D\\u0443\\u0441\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u0417\\u0430\\u043F\\u0438\\u0441\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0432\\u0440\\u0435\\u043C\\u0435\r\n\r\n#XFLD\r\nUPCOMING_VACATION=\\u041F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449 \\u0433\\u043E\\u0434\\u0438\\u0448\\u0435\\u043D \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=\\u041F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0442\\u0435 {0} \\u043C\\u0435\\u0441\\u0435\\u0446\\u0438 \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\\u0438 \\u0432 \\u0441\\u043B\\u0435\\u0434\\u0432\\u0430\\u0449\\u0438\\u0442\\u0435 {0} \\u043C\\u0435\\u0441\\u0435\\u0446\\u0438\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u0417\\u0430\\u043F\\u0438\\u0441\\u0432\\u0430\\u043D\\u0435\\u0442\\u043E \\u043D\\u0430 \\u0432\\u0440\\u0435\\u043C\\u0435 \\u0435 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u0438\\u0437\\u0438\\u0440\\u0430\\u043D\\u043E\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0432\\u0440\\u0435\\u043C\\u0435\\u0432\\u0438 \\u0441\\u0430\\u043B\\u0434\\u0430 \\u043A\\u044A\\u043C {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0444\\u0438\\u0448\\u043E\\u0432\\u0435 \\u0437\\u0430 \\u0437\\u0430\\u043F\\u043B\\u0430\\u0442\\u0438 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0442\\u0435 {0} \\u043C\\u0435\\u0441\\u0435\\u0446\\u0438 \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u043A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u0438 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0442\\u0435 {0} \\u043C\\u0435\\u0441\\u0435\\u0446\\u0438 \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438 \\u043A\\u0443\\u0440\\u0441\\u043E\\u0432\\u0435 \\u0432 \\u0441\\u043B\\u0435\\u0434\\u0432\\u0430\\u0449\\u0438\\u0442\\u0435 {0} \\u043C\\u0435\\u0441\\u0435\\u0446\\u0438\r\n\r\n#XFLD\r\nPERF_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0430 \\u043A\\u043B\\u0430\\u0441\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u044F \\u043D\\u0430 \\u043F\\u0440\\u043E\\u0438\\u0437\\u0432\\u043E\\u0434\\u0438\\u0442\\u0435\\u043B\\u043D\\u043E\\u0441\\u0442 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0442\\u0435 {0} \\u0433\\u043E\\u0434\\u0438\\u043D\\u0438\r\n\r\n#XFLD\r\nCOMP_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438 \\u0437\\u0430 \\u043A\\u043E\\u043C\\u043F\\u0435\\u043D\\u0441\\u0430\\u0446\\u0438\\u0438 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0442\\u0435 {0} \\u0433\\u043E\\u0434\\u0438\\u043D\\u0438\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438 \\u0437\\u0430 \\u043D\\u0430\\u043F\\u0440\\u0435\\u0434\\u044A\\u043A\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0438\\u0437\\u0432\\u0435\\u0441\\u0442\\u0438\\u044F\r\n\r\n#XFLD\r\nNOTES_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0431\\u0435\\u043B\\u0435\\u0436\\u043A\\u0438\r\n\r\n#XFLD\r\nPERS_NO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0430 \\u0438\\u043D\\u0444\\u043E\\u0440\\u043C\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XFLD\r\nNO_DATA=\\u041D\\u044F\\u043C\\u0430 \\u043D\\u0430\\u043B\\u0438\\u0447\\u043D\\u0438 \\u0434\\u0430\\u043D\\u043D\\u0438\r\n\r\n#XFLD\r\nTOPIC=\\u0422\\u0435\\u043C\\u0430\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u041D\\u0438\\u0432\\u043E \\u043D\\u0430 \\u043A\\u043E\\u043C\\u043F\\u0435\\u0442\\u0435\\u043D\\u0442\\u043D\\u043E\\u0441\\u0442\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u0412\\u0430\\u043B\\u0438\\u0434\\u0435\\u043D \\u0434\\u043E\r\n\r\n#XFLD\r\nDATEOFBIRTH=\\u0414\\u0430\\u0442\\u0430 \\u043D\\u0430 \\u0440\\u0430\\u0436\\u0434\\u0430\\u043D\\u0435\r\n\r\n#XFLD\r\nMARITALSTATUS=\\u0421\\u0435\\u043C\\u0435\\u0439\\u043D\\u043E \\u043F\\u043E\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD\r\nMISSING_DAYS=\\u0414\\u043D\\u0438 \\u0431\\u0435\\u0437 \\u0434\\u0430\\u043D\\u043D\\u0438\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=\\u041D\\u0435\\u043F\\u044A\\u043B\\u043D\\u0438 \\u0434\\u043D\\u0438\r\n\r\n#XFLD\r\nDAYS=\\u0414\\u043D\\u0438\r\n\r\n#XFLD\r\nHOURS=\\u0427\\u0430\\u0441\\u043E\\u0432\\u0435\r\n\r\n#XFLD\r\nSINCE=\\u041E\\u0442\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=\\u0417\\u0430\\u043F\\u043B\\u0430\\u0442\\u0430 \\u0438 \\u0431\\u043E\\u043D\\u0443\\u0441\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u041A\\u043B\\u0430\\u0441\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u044F \\u043D\\u0430 \\u043E\\u0446\\u0435\\u043D\\u043A\\u0430\r\n\r\n#XFLD\r\nRECORD_TIME=\\u0427\\u0430\\u0441 \\u043D\\u0430 \\u0437\\u0430\\u043F\\u0438\\u0441\\u0432\\u0430\\u043D\\u0435\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u041A\\u0430\\u043D\\u0434\\u0438\\u0434\\u0430\\u0442\\u0441\\u0442\\u0432\\u0430\\u043D\\u0435 \\u0437\\u0430 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u041F\\u0440\\u0435\\u0433\\u043B\\u0435\\u0434 \\u043D\\u0430 \\u0444\\u0438\\u0448 \\u0437\\u0430 \\u0437\\u0430\\u043F\\u043B\\u0430\\u0442\\u0430\r\n\r\n#XFLD\r\nLOCATION=\\u041C\\u0435\\u0441\\u0442\\u043E\\u043F\\u043E\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD\r\nOFFICE_PHONE=\\u041E\\u0444\\u0438\\u0441 \\u0442\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\r\n\r\n#XFLD\r\nEMAIL=\\u0418\\u043C\\u0435\\u0439\\u043B\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u041D\\u0435\\u0442\\u043D\\u0430 \\u0437\\u0430\\u043F\\u043B\\u0430\\u0442\\u0430\r\n\r\n#XFLD\r\nSALARY=\\u0417\\u0430\\u043F\\u043B\\u0430\\u0442\\u0430\r\n\r\n#XFLD\r\nBONUS=\\u0411\\u043E\\u043D\\u0443\\u0441\r\n\r\n#XFLD\r\nYEAR=\\u0413\\u043E\\u0434\\u0438\\u043D\\u0430\r\n\r\n#XFLD\r\nCOMPENSATION=\\u041A\\u043E\\u043C\\u043F\\u0435\\u043D\\u0441\\u0430\\u0446\\u0438\\u044F\r\n\r\n#XFLD\r\nCATEGORY=\\u041A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XFLD\r\nPERIOD=\\u041F\\u0435\\u0440\\u0438\\u043E\\u0434\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u0419\\u0435\\u0440\\u0430\\u0440\\u0445\\u0438\\u044F \\u043D\\u0430 \\u0441\\u043B\\u0443\\u0436\\u0438\\u0442\\u0435\\u043B\\u0438\r\n\r\n#XFLD\r\nAS_OF=\\u041A\\u044A\\u043C {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=\\u0418\\u0437\\u0431\\u0435\\u0440\\u0435\\u0442\\u0435 \\u043F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=\\u041F\\u0440\\u0438\\u0441\\u044A\\u0435\\u0434\\u0438\\u043D\\u044F\\u0432\\u0430\\u043D\\u0438\\u044F \\u043D\\u0430 \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=\\u0412\\u044A\\u0437\\u043D\\u0438\\u043A\\u043D\\u0430 \\u0432\\u044A\\u0442\\u0440\\u0435\\u0448\\u043D\\u0430 \\u0433\\u0440\\u0435\\u0448\\u043A\\u0430. \\u041C\\u043E\\u043B\\u044F \\u0441\\u0432\\u044A\\u0440\\u0436\\u0435\\u0442\\u0435 \\u0441\\u0435 \\u0441 \\u0432\\u0430\\u0448\\u0438\\u044F \\u0441\\u0438\\u0441\\u0442\\u0435\\u043C\\u0435\\u043D \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=\\u0412\\u044A\\u0442\\u0440\\u0435\\u0448\\u043D\\u0430 \\u0433\\u0440\\u0435\\u0448\\u043A\\u0430\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u041E\\u0442\\u043A\\u0430\\u0437\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=\\u0421\\u044A\\u0437\\u0434\\u0430\\u0432\\u0430\\u043D\\u0435 \\u043D\\u0430 \\u0432\\u0440\\u0435\\u043C\\u0435\\u0432\\u043E \\u0441\\u044A\\u0431\\u0438\\u0442\\u0438\\u0435\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u0412\\u0440\\u0435\\u043C\\u0435\\u0432\\u043E \\u0441\\u0430\\u043B\\u0434\\u043E\r\n',
		"hcm/people/profile/i18n/i18n_cs.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil lid\\u00ED\r\n\r\n#XTIT: \r\nWHATS_NEW=Novinky\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Pozn\\u00E1mky\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Moje osobn\\u00ED pozn\\u00E1mky\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Osobn\\u00ED informace\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Ozn\\u00E1men\\u00ED\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Evidence \\u010Dasu a nep\\u0159\\u00EDtomnost\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Chystan\\u00E9 kurzy\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifikace a schopnosti\r\n\r\n#XTIT: \r\nPERFORMANCE=V\\u00FDkon\r\n\r\n#XTIT: \r\nPROGRESSION=Postup\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=V\\u00FDplatn\\u00ED p\\u00E1ska\r\n\r\n#XTIT: \r\nSALARY_BONUS=Plat a p\\u0159\\u00EDplatek\r\n\r\n#XFLD\r\nTIME_RECORDING=Evidence \\u010Dasu\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Chystan\\u00E1 dovolen\\u00E1\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Chystan\\u00E9 volno\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Nejsou k dispozici \\u017E\\u00E1dn\\u00E1 data za n\\u00E1sleduj\\u00EDc\\u00ED po\\u010Det posledn\\u00EDch m\\u011Bs\\u00EDc\\u016F\\: {0}  \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=V n\\u00E1sleduj\\u00EDc\\u00EDm po\\u010Dtu m\\u011Bs\\u00EDc\\u016F nejsou \\u017E\\u00E1dn\\u00E9 nadch\\u00E1zej\\u00EDc\\u00ED dovolen\\u00E9\\: {0} \r\n\r\n#XFLD\r\nTIME_NO_DATA=Evidence \\u010Dasu je aktu\\u00E1ln\\u00ED\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 \\u010Dasov\\u00E9 z\\u016Fstatky od {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 v\\u00FDplatn\\u00ED p\\u00E1sky za n\\u00E1sleduj\\u00EDc\\u00ED po\\u010Det posledn\\u00EDch m\\u011Bs\\u00EDc\\u016F\\: {0}  \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 kvalifikace za n\\u00E1sleduj\\u00EDc\\u00ED po\\u010Det posledn\\u00EDch m\\u011Bs\\u00EDc\\u016F\\: {0}  \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=V n\\u00E1sleduj\\u00EDc\\u00EDm po\\u010Dtu m\\u011Bs\\u00EDc\\u016F nejsou k dispozici \\u017E\\u00E1dn\\u00E9 kurzy\\: {0} \r\n\r\n#XFLD\r\nPERF_NO_DATA=Nen\\u00ED k dispozici \\u017E\\u00E1dn\\u00E9 hodnocen\\u00ED v\\u00FDkonu za n\\u00E1sleduj\\u00EDc\\u00ED po\\u010Det posledn\\u00EDch let\\: {0} \r\n\r\n#XFLD\r\nCOMP_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E1 data o odm\\u011B\\u0148ov\\u00E1n\\u00ED za n\\u00E1sleduj\\u00EDc\\u00ED po\\u010Det posledn\\u00EDch let\\: {0} \r\n\r\n#XFLD\r\nPROG_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E1 data o postupu\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E1 hl\\u00E1\\u0161en\\u00ED\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 pozn\\u00E1mky\r\n\r\n#XFLD\r\nPERS_NO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E9 informace\r\n\r\n#XFLD\r\nNO_DATA=Nejsou k dispozici \\u017E\\u00E1dn\\u00E1 data\r\n\r\n#XFLD\r\nTOPIC=T\\u00E9ma\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u00DArove\\u0148 kompetenc\\u00ED\r\n\r\n#XFLD\r\nVALID_UNTIL=Plat\\u00ED do\r\n\r\n#XFLD\r\nDATEOFBIRTH=Datum narozen\\u00ED\r\n\r\n#XFLD\r\nMARITALSTATUS=Rodinn\\u00FD stav\r\n\r\n#XFLD\r\nMISSING_DAYS=Chyb\\u011Bj\\u00EDc\\u00ED dny\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Ne\\u00FApln\\u00E9 dny\r\n\r\n#XFLD\r\nDAYS=Dny\r\n\r\n#XFLD\r\nHOURS=Hodiny\r\n\r\n#XFLD\r\nSINCE=Od\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Plat a bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Vyhodnocen\\u00ED posudk\\u016F\r\n\r\n#XFLD\r\nRECORD_TIME=Z\\u00E1znam \\u010Dasu\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u017D\\u00E1dost o dovolenou\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Zobrazit v\\u00FDplatn\\u00ED p\\u00E1sku\r\n\r\n#XFLD\r\nLOCATION=M\\u00EDsto\r\n\r\n#XFLD\r\nOFFICE_PHONE=Pracovn\\u00ED telefon\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Platba netto\r\n\r\n#XFLD\r\nSALARY=Plat\r\n\r\n#XFLD\r\nBONUS=P\\u0159\\u00EDplatek\r\n\r\n#XFLD\r\nYEAR=Rok\r\n\r\n#XFLD\r\nCOMPENSATION=Odm\\u011B\\u0148ov\\u00E1n\\u00ED\r\n\r\n#XFLD\r\nCATEGORY=Kategorie\r\n\r\n#XFLD\r\nPERIOD=Obdob\\u00ED\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hierarchie zam\\u011Bstnanc\\u016F\r\n\r\n#XFLD\r\nAS_OF=Od {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Zvolte pracovn\\u00ED smlouvu\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Pracovn\\u00ED smlouvy\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Do\\u0161lo k intern\\u00ED chyb\\u011B. Obra\\u0165te se na spr\\u00E1vce syst\\u00E9mu.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Intern\\u00ED chyba\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Zru\\u0161it\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Vytvo\\u0159it \\u010Dasovou ud\\u00E1lost\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u010Casov\\u00FD z\\u016Fstatek\r\n',
		"hcm/people/profile/i18n/i18n_de.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Mitarbeiterprofil\r\n\r\n#XTIT: \r\nWHATS_NEW=Neue Funktionen\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notizen\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Eigene Notizen\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Pers\\u00F6nliche Daten\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Benachrichtigungen\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Zeiterfassung und Abwesenheiten\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Anstehende Trainings\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Qualifikationen\r\n\r\n#XTIT: \r\nPERFORMANCE=Performance\r\n\r\n#XTIT: \r\nPROGRESSION=Karriereentwicklung\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Entgeltnachweis\r\n\r\n#XTIT: \r\nSALARY_BONUS=Gehalt und Bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Zeiterfassung\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Geplanter Urlaub\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Bevorstehende Abwesenheit\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=F\\u00FCr die letzten {0} Monate sind keine Daten verf\\u00FCgbar. \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=F\\u00FCr die n\\u00E4chsten {0} Monate sind keine bevorstehenden Abwesenheiten vorhanden.\r\n\r\n#XFLD\r\nTIME_NO_DATA=Zeiterfassung ist aktuell\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Ab {0} sind keine Zeitsalden verf\\u00FCgbar. \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=F\\u00FCr die letzten {0} Monate sind keine Entgeltnachweise verf\\u00FCgbar. \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=F\\u00FCr die letzten {0} Monate sind keine Qualifikationen verf\\u00FCgbar. \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=F\\u00FCr die n\\u00E4chsten {0} Monate sind keine anstehenden Trainings vorhanden.\r\n\r\n#XFLD\r\nPERF_NO_DATA=F\\u00FCr die letzten {0} Jahre sind keine Leistungsbewertungen vorhanden.\r\n\r\n#XFLD\r\nCOMP_NO_DATA=F\\u00FCr die letzten {0} Jahre sind keine Verg\\u00FCtungsdaten verf\\u00FCgbar.\r\n\r\n#XFLD\r\nPROG_NO_DATA=Keine Daten zur Karriereentwicklung verf\\u00FCgbar\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Keine Benachrichtigungen verf\\u00FCgbar\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Keine Notizen verf\\u00FCgbar\r\n\r\n#XFLD\r\nPERS_NO_DATA=Keine Informationen verf\\u00FCgbar\r\n\r\n#XFLD\r\nNO_DATA=Keine Daten verf\\u00FCgbar\r\n\r\n#XFLD\r\nTOPIC=Thema\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Kompetenzstufe\r\n\r\n#XFLD\r\nVALID_UNTIL=G\\u00FCltig bis\r\n\r\n#XFLD\r\nDATEOFBIRTH=Geburtsdatum\r\n\r\n#XFLD\r\nMARITALSTATUS=Familienstand\r\n\r\n#XFLD\r\nMISSING_DAYS=Nicht erfasste Tage\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Unvollst\\u00E4ndig erfasste Tage\r\n\r\n#XFLD\r\nDAYS=Tage\r\n\r\n#XFLD\r\nHOURS=Stunden\r\n\r\n#XFLD\r\nSINCE=Seit\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Gehalt und Bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Bewertung der Beurteilung\r\n\r\n#XFLD\r\nRECORD_TIME=Zeit erfassen\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Abwesenheit anlegen\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Entgeltnachweis anzeigen\r\n\r\n#XFLD\r\nLOCATION=Standort\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telefon B\\u00FCro\r\n\r\n#XFLD\r\nEMAIL=E-Mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Zahlbetrag\r\n\r\n#XFLD\r\nSALARY=Gehalt\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Jahr\r\n\r\n#XFLD\r\nCOMPENSATION=Verg\\u00FCtung\r\n\r\n#XFLD\r\nCATEGORY=Kategorie\r\n\r\n#XFLD\r\nPERIOD=Zeitraum\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Mitarbeiterhierarchie\r\n\r\n#XFLD\r\nAS_OF=Ab {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=W\\u00E4hlen Sie einen Besch\\u00E4ftigungsvertrag\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Besch\\u00E4ftigungsvertr\\u00E4ge\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Es ist ein interner Fehler aufgetreten. Wenden Sie sich an Ihre Systemadministration.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Interner Fehler\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Abbrechen\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Zeitereignis anlegen\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Zeitsaldo\r\n',
		"hcm/people/profile/i18n/i18n_en.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=People Profile\r\n\r\n#XTIT: \r\nWHATS_NEW=What\'s New\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notes\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=My Personal Notes\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Personal Information\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notifications\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Timesheet & Absences\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Upcoming Courses\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Qualifications & Skills\r\n\r\n#XTIT: \r\nPERFORMANCE=Performance\r\n\r\n#XTIT: \r\nPROGRESSION=Progression\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Payslip\r\n\r\n#XTIT: \r\nSALARY_BONUS=Salary and Bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Time Recording\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Upcoming Vacation\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Upcoming Leave\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=No data available for the last {0} months \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=No upcoming leaves in the next {0} months\r\n\r\n#XFLD\r\nTIME_NO_DATA=Time recording is up to date\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=No time balances available as of {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=No payslips available in the last {0} months \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=No qualifications available in the last {0} months \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=No upcoming courses in the next {0} months\r\n\r\n#XFLD\r\nPERF_NO_DATA=No performance rating available for the last {0} years\r\n\r\n#XFLD\r\nCOMP_NO_DATA=No compensation data available for the last {0} years\r\n\r\n#XFLD\r\nPROG_NO_DATA=No Progression Data Available\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=No Notifications Available\r\n\r\n#XFLD\r\nNOTES_NO_DATA=No Notes Available\r\n\r\n#XFLD\r\nPERS_NO_DATA=No Information Available\r\n\r\n#XFLD\r\nNO_DATA=No Data Available\r\n\r\n#XFLD\r\nTOPIC=Topic\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Competency Level\r\n\r\n#XFLD\r\nVALID_UNTIL=Valid Until\r\n\r\n#XFLD\r\nDATEOFBIRTH=Date of Birth\r\n\r\n#XFLD\r\nMARITALSTATUS=Marital Status\r\n\r\n#XFLD\r\nMISSING_DAYS=Missing Days\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Incomplete Days\r\n\r\n#XFLD\r\nDAYS=Days\r\n\r\n#XFLD\r\nHOURS=Hours\r\n\r\n#XFLD\r\nSINCE=Since\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Salary & Bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Appraisal Rating\r\n\r\n#XFLD\r\nRECORD_TIME=Record Time\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Apply for Leave\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=View Payslip\r\n\r\n#XFLD\r\nLOCATION=Location\r\n\r\n#XFLD\r\nOFFICE_PHONE=Office Phone\r\n\r\n#XFLD\r\nEMAIL=Email\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Take-Home Pay\r\n\r\n#XFLD\r\nSALARY=Salary\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Year\r\n\r\n#XFLD\r\nCOMPENSATION=Compensation\r\n\r\n#XFLD\r\nCATEGORY=Category\r\n\r\n#XFLD\r\nPERIOD=Period\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Employee Hierarchy\r\n\r\n#XFLD\r\nAS_OF=As of {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Choose a Personnel Assignment\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Personnel Assignments\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=An internal error has occurred. Please contact your system administrator.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Internal error\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Cancel\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Create Time Event\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Time Balance\r\n',
		"hcm/people/profile/i18n/i18n_en_US.properties": '# Note: This file was created according to the conventions that can be found at \n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\n\n#XTIT: this is the title for the fullscreen section\nFULLSCREEN_TITLE=People Profile',
		"hcm/people/profile/i18n/i18n_en_US_sappsd.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=[[[\\u01A4\\u0113\\u014F\\u03C1\\u013A\\u0113 \\u01A4\\u0157\\u014F\\u0192\\u012F\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nWHATS_NEW=[[[\\u0174\\u0125\\u0105\\u0163\\u015F \\u0143\\u0113\\u0175\\!\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nTALENT=[[[\\u0162\\u0105\\u013A\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=[[[\\u0143\\u014F\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=[[[\\u039C\\u0177 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u0105\\u013A \\u0143\\u014F\\u0163\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nPERSONAL_INFO=[[[\\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u0105\\u013A \\u012C\\u014B\\u0192\\u014F\\u0157\\u0271\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nNOTIFICATIONS=[[[\\u0143\\u014F\\u0163\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B\\u015F \\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=[[[\\u0162\\u012F\\u0271\\u0113\\u015F\\u0125\\u0113\\u0113\\u0163 & \\u0100\\u0183\\u015F\\u0113\\u014B\\u010B\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=[[[\\u016E\\u03C1\\u010B\\u014F\\u0271\\u012F\\u014B\\u011F \\u0108\\u014F\\u0171\\u0157\\u015F\\u0113\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=[[[\\u01EC\\u0171\\u0105\\u013A\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B\\u015F/\\u015C\\u0137\\u012F\\u013A\\u013A\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nPERFORMANCE=[[[\\u01A4\\u0113\\u0157\\u0192\\u014F\\u0157\\u0271\\u0105\\u014B\\u010B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nPROGRESSION=[[[\\u01A4\\u0157\\u014F\\u011F\\u0157\\u0113\\u015F\\u015F\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=[[[\\u01A4\\u0105\\u0177\\u015F\\u013A\\u012F\\u03C1\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: \r\nSALARY_BONUS=[[[\\u015C\\u0105\\u013A\\u0105\\u0157\\u0177 \\u0105\\u014B\\u018C \\u0181\\u014F\\u014B\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nTIME_RECORDING=[[[\\u0162\\u012F\\u0271\\u0113 \\u0158\\u0113\\u010B\\u014F\\u0157\\u018C\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nUPCOMING_VACATION=[[[\\u016E\\u03C1\\u010B\\u014F\\u0271\\u012F\\u014B\\u011F \\u01B2\\u0105\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=[[[\\u016E\\u03C1\\u010B\\u014F\\u0271\\u012F\\u014B\\u011F \\u013B\\u0113\\u0105\\u028B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=[[[\\u0143\\u014F \\u018C\\u0105\\u0163\\u0105 \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u0192\\u014F\\u0157 \\u0163\\u0125\\u0113 \\u013A\\u0105\\u015F\\u0163 {0} \\u0271\\u014F\\u014B\\u0163\\u0125\\u015F]]]\r\n\r\n#XFLD\r\nLEAVES_NO_DATA=[[[\\u0143\\u014F \\u0171\\u03C1\\u010B\\u014F\\u0271\\u012F\\u014B\\u011F \\u013A\\u0113\\u0105\\u028B\\u0113\\u015F \\u012F\\u014B \\u0163\\u0125\\u0113 \\u014B\\u0113\\u03C7\\u0163 {0} \\u0271\\u014F\\u014B\\u0163\\u0125\\u015F]]]\r\n\r\n#XFLD\r\nTIME_NO_DATA=[[[\\u0162\\u012F\\u0271\\u0113 \\u0157\\u0113\\u010B\\u014F\\u0157\\u018C\\u012F\\u014B\\u011F \\u012F\\u015F \\u0171\\u03C1 \\u0163\\u014F \\u018C\\u0105\\u0163\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=[[[\\u0143\\u014F \\u0163\\u012F\\u0271\\u0113 \\u0183\\u0105\\u013A\\u0105\\u014B\\u010B\\u0113\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u0105\\u015F \\u014F\\u0192 {0} ]]]\r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=[[[\\u0143\\u014F \\u03C1\\u0105\\u0177\\u015F\\u013A\\u012F\\u03C1\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u012F\\u014B \\u0163\\u0125\\u0113 \\u013A\\u0105\\u015F\\u0163 {0} \\u0271\\u014F\\u014B\\u0163\\u0125\\u015F]]]\r\n\r\n#XFLD\r\nQUALIF_NO_DATA=[[[\\u0143\\u014F \\u01A3\\u0171\\u0105\\u013A\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u012F\\u014B \\u0163\\u0125\\u0113 \\u013A\\u0105\\u015F\\u0163 {0} \\u0271\\u014F\\u014B\\u0163\\u0125\\u015F]]]\r\n\r\n#XFLD\r\nCOURSES_NO_DATA=[[[\\u0143\\u014F \\u0171\\u03C1\\u010B\\u014F\\u0271\\u012F\\u014B\\u011F \\u010B\\u014F\\u0171\\u0157\\u015F\\u0113\\u015F \\u012F\\u014B \\u0163\\u0125\\u0113 \\u014B\\u0113\\u03C7\\u0163 {0} \\u0271\\u014F\\u014B\\u0163\\u0125\\u015F]]]\r\n\r\n#XFLD\r\nPERF_NO_DATA=[[[\\u0143\\u014F \\u03C1\\u0113\\u0157\\u0192\\u014F\\u0157\\u0271\\u0105\\u014B\\u010B\\u0113 \\u0157\\u0105\\u0163\\u012F\\u014B\\u011F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u0192\\u014F\\u0157 \\u0163\\u0125\\u0113 \\u013A\\u0105\\u015F\\u0163 {0} \\u0177\\u0113\\u0105\\u0157\\u015F]]]\r\n\r\n#XFLD\r\nCOMP_NO_DATA=[[[\\u0143\\u014F \\u010B\\u014F\\u0271\\u03C1\\u0113\\u014B\\u015F\\u0105\\u0163\\u012F\\u014F\\u014B \\u018C\\u0105\\u0163\\u0105 \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u0192\\u014F\\u0157 \\u0163\\u0125\\u0113 \\u013A\\u0105\\u015F\\u0163 {0} \\u0177\\u0113\\u0105\\u0157\\u015F]]]\r\n\r\n#XFLD\r\nPROG_NO_DATA=[[[\\u0143\\u014F \\u03C1\\u0157\\u014F\\u011F\\u0157\\u0113\\u015F\\u015F\\u012F\\u014F\\u014B \\u018C\\u0105\\u0163\\u0105 \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=[[[\\u0143\\u014F \\u014B\\u014F\\u0163\\u012F\\u0192\\u012F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nNOTES_NO_DATA=[[[\\u0143\\u014F \\u014B\\u014F\\u0163\\u0113\\u015F \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nPERS_NO_DATA=[[[\\u0143\\u014F \\u012F\\u014B\\u0192\\u014F\\u0157\\u0271\\u0105\\u0163\\u012F\\u014F\\u014B \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113 \\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nNO_DATA=[[[\\u0143\\u014F \\u018C\\u0105\\u0163\\u0105 \\u0105\\u028B\\u0105\\u012F\\u013A\\u0105\\u0183\\u013A\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nTOPIC=[[[\\u0162\\u014F\\u03C1\\u012F\\u010B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=[[[\\u0108\\u014F\\u0271\\u03C1\\u0113\\u0163\\u0113\\u014B\\u010B\\u0177 \\u013B\\u0113\\u028B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nVALID_UNTIL=[[[\\u01B2\\u0105\\u013A\\u012F\\u018C \\u016E\\u014B\\u0163\\u012F\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nDATEOFBIRTH=[[[\\u010E\\u0105\\u0163\\u0113 \\u014F\\u0192 \\u0181\\u012F\\u0157\\u0163\\u0125\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nMARITALSTATUS=[[[\\u039C\\u0105\\u0157\\u012F\\u0163\\u0105\\u013A \\u015C\\u0163\\u0105\\u0163\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nMISSING_DAYS=[[[\\u039C\\u012F\\u015F\\u015F\\u012F\\u014B\\u011F \\u010E\\u0105\\u0177\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=[[[\\u012C\\u014B\\u010B\\u014F\\u0271\\u03C1\\u013A\\u0113\\u0163\\u0113 \\u010E\\u0105\\u0177\\u015F\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nDAYS=[[[\\u010E\\u0105\\u0177\\u015F]]]\r\n\r\n#XFLD\r\nHOURS=[[[\\u0124\\u014F\\u0171\\u0157\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nSINCE=[[[\\u015C\\u012F\\u014B\\u010B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=[[[\\u015C\\u0105\\u013A\\u0105\\u0157\\u0177 & \\u0181\\u014F\\u014B\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=[[[\\u0100\\u03C1\\u03C1\\u0157\\u0105\\u012F\\u015F\\u0105\\u013A \\u0158\\u0105\\u0163\\u012F\\u014B\\u011F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nRECORD_TIME=[[[\\u0158\\u0113\\u010B\\u014F\\u0157\\u018C \\u0162\\u012F\\u0271\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nAPPLY_LEAVE=[[[\\u0100\\u03C1\\u03C1\\u013A\\u0177 \\u013B\\u0113\\u0105\\u028B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=[[[\\u01B2\\u012F\\u0113\\u0175 \\u01A4\\u0105\\u0177\\u015F\\u013A\\u012F\\u03C1\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nLOCATION=[[[\\u013B\\u014F\\u010B\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nOFFICE_PHONE=[[[\\u014E\\u0192\\u0192\\u012F\\u010B\\u0113 \\u03C1\\u0125\\u014F\\u014B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nEMAIL=[[[\\u0114\\u0271\\u0105\\u012F\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=[[[\\u0162\\u0105\\u0137\\u0113 \\u0125\\u014F\\u0271\\u0113 \\u01A4\\u0105\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nSALARY=[[[\\u015C\\u0105\\u013A\\u0105\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nBONUS=[[[\\u0181\\u014F\\u014B\\u0171\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nYEAR=[[[\\u0176\\u0113\\u0105\\u0157]]]\r\n\r\n#XFLD\r\nCOMPENSATION=[[[\\u0108\\u014F\\u0271\\u03C1\\u0113\\u014B\\u015F\\u0105\\u0163\\u012F\\u014F\\u014B\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nCATEGORY=[[[\\u0108\\u0105\\u0163\\u0113\\u011F\\u014F\\u0157\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nPERIOD=[[[\\u01A4\\u0113\\u0157\\u012F\\u014F\\u018C\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=[[[\\u0114\\u0271\\u03C1\\u013A\\u014F\\u0177\\u0113\\u0113 \\u0124\\u012F\\u0113\\u0157\\u0105\\u0157\\u010B\\u0125\\u0177\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XFLD\r\nAS_OF=[[[\\u0100\\u015F \\u014F\\u0192 {0} ]]]\r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=[[[\\u0108\\u0125\\u014F\\u014F\\u015F\\u0113 \\u0105 \\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u014B\\u0113\\u013A \\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0271\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=[[[\\u01A4\\u0113\\u0157\\u015F\\u014F\\u014B\\u014B\\u0113\\u013A \\u0100\\u015F\\u015F\\u012F\\u011F\\u014B\\u0271\\u0113\\u014B\\u0163\\u015F\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=[[[\\u0100\\u014B \\u012F\\u014B\\u0163\\u0113\\u0157\\u014B\\u0105\\u013A \\u0113\\u0157\\u0157\\u014F\\u0157 \\u014E\\u010B\\u010B\\u0171\\u0157\\u0157\\u0113\\u018C. \\u01A4\\u013A\\u0113\\u0105\\u015F\\u0113 \\u010B\\u014F\\u014B\\u0163\\u0105\\u010B\\u0163 \\u015F\\u0177\\u015F\\u0163\\u0113\\u0271 \\u0105\\u018C\\u0271\\u012F\\u014B\\u012F\\u015F\\u0163\\u0157\\u0105\\u0163\\u014F\\u0157.\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=[[[\\u012C\\u014B\\u0163\\u0113\\u0157\\u014B\\u0105\\u013A \\u0114\\u0157\\u0157\\u014F\\u0157\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XBUT: Button to accept\r\nOK=[[[\\u014E\\u0136\\u2219\\u2219]]]\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=[[[\\u0108\\u0105\\u014B\\u010B\\u0113\\u013A\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=[[[\\u0108\\u0157\\u0113\\u0105\\u0163\\u0113 \\u0162\\u012F\\u0271\\u0113 \\u0114\\u028B\\u0113\\u014B\\u0163\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=[[[\\u0162\\u012F\\u0271\\u0113 \\u0181\\u0105\\u013A\\u0105\\u014B\\u010B\\u0113\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219\\u2219]]]\r\n',
		"hcm/people/profile/i18n/i18n_en_US_saptrc.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=XV4sjJxbgdTO+oG97G7VZw_People Profile\r\n\r\n#XTIT: \r\nWHATS_NEW=r8ufXdlY349UKjvkEqBOAQ_Whats New\\!\r\n\r\n#XTIT: \r\nTALENT=vNe0jr79dqv/Q6bo4hYK+A_Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Bp8XFUWmOLitH1zkmOaq9w_Notes\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=q8aUhTDmO3ejtAafuc1Zig_My Personal Notes\r\n\r\n#XTIT: \r\nPERSONAL_INFO=kqX0dJdvlJ5ud7KTJwqPHA_Personal Information\r\n\r\n#XTIT: \r\nNOTIFICATIONS=TnxowqiDrozIFeEkuZ8EmA_Notifications \r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=uMee1CnwZBtYvDtbAjll8Q_Timesheet & Absences\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=kGIT+3Vu4CNBHzax+9xNCQ_Upcoming Courses\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=tDxO63vm37xCLn1ocCiI/g_Qualifications/Skills\r\n\r\n#XTIT: \r\nPERFORMANCE=pe1MXQXQOP/jKw7wzbO4kA_Performance\r\n\r\n#XTIT: \r\nPROGRESSION=tzBV8tL9slm2fkZ2WsP2cA_Progression\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=mNCT9watHF79UwZedMuApg_Payslip\r\n\r\n#XTIT: \r\nSALARY_BONUS=rxcrFJgCnwIQ1RbSKe8Vqg_Salary and Bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=7cY7wAyvHjbI3z5RzL9jeQ_Time Recording\r\n\r\n#XFLD\r\nUPCOMING_VACATION=ETu9AVanxzTS/TRSwP/N/g_Upcoming Vacation\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=f0T9XNsRDOITK35zMiR8sg_Upcoming Leave\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=vJQdrvS1kWKVXVnc7+FoBQ_No data available for the last {0} months\r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Fj/JhyelTAlIofDPejukqA_No upcoming leaves in the next {0} months\r\n\r\n#XFLD\r\nTIME_NO_DATA=b37a8x6GXO3oBSx+QbC7Dw_Time recording is up to date\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=JLYChumLKohTYDddnurOYA_No time balances available as of {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=VD1EftuWDMUcNJSwfUNixQ_No payslips available in the last {0} months\r\n\r\n#XFLD\r\nQUALIF_NO_DATA=1xJG8dkCTj4exDPaVGNZpw_No qualifications available in the last {0} months\r\n\r\n#XFLD\r\nCOURSES_NO_DATA=9uUf6k9jgGGcZqgJGPUUMg_No upcoming courses in the next {0} months\r\n\r\n#XFLD\r\nPERF_NO_DATA=yjz7uLzAJXFhAG7R2X4pWQ_No performance rating available for the last {0} years\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Y2TEQqpQPKk+asS2NsNjrQ_No compensation data available for the last {0} years\r\n\r\n#XFLD\r\nPROG_NO_DATA=eINYEXk4tKug25OXtHgG1A_No progression data available \r\n\r\n#XFLD\r\nNOTIF_NO_DATA=3enTOAltuEJCpBLdwbHmQg_No notifications available \r\n\r\n#XFLD\r\nNOTES_NO_DATA=fbXynMTiv9yg8/A3Ilz2Qg_No notes available \r\n\r\n#XFLD\r\nPERS_NO_DATA=dnLIuuhf/RtzUhbV9mT3qA_No information available \r\n\r\n#XFLD\r\nNO_DATA=HXjOwGCO0+wCkciojtkP3g_No data available\r\n\r\n#XFLD\r\nTOPIC=cbSE9t0KN1ns/zkVHaUKEg_Topic\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=HPwFW1HCujzaQ3rXra/rjA_Competency Level\r\n\r\n#XFLD\r\nVALID_UNTIL=QLa+z+jag1e/y56PSiggkw_Valid Until\r\n\r\n#XFLD\r\nDATEOFBIRTH=QyVUlOiHQlqCIVDNaSJJMA_Date of Birth\r\n\r\n#XFLD\r\nMARITALSTATUS=Fy8gQ7zVRpap5rOcGD27bw_Marital Status\r\n\r\n#XFLD\r\nMISSING_DAYS=q3QKKaMTkWkOabMyVETBNg_Missing Days\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=/q+ugQinwaIn39HbTYAOXg_Incomplete Days\r\n\r\n#XFLD\r\nDAYS=OyHdkrLXAHDG2RnbMhlqlw_Days\r\n\r\n#XFLD\r\nHOURS=lI+oDayb9DF0o2ooFXvg/g_Hours\r\n\r\n#XFLD\r\nSINCE=jKcSHqbjx9gk9ttHuraPIA_Since\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=6cvfbfiejf5qjwBS5mqqSg_Salary & Bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=rdf2eloVF/BchlVk82zKZg_Appraisal Rating\r\n\r\n#XFLD\r\nRECORD_TIME=Gbvxd5YsrZRaw9KFQhVlLg_Record Time\r\n\r\n#XFLD\r\nAPPLY_LEAVE=x0u4D3w0cMDZ1lfqnj/tkA_Apply Leave\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=ZEZ0xbZYIWXDXDVwtTk4DA_View Payslip\r\n\r\n#XFLD\r\nLOCATION=3QqiSk3eFLCx140xONSG+w_Location\r\n\r\n#XFLD\r\nOFFICE_PHONE=hNMex9pAWXDVYDX8+uBHdQ_Office phone\r\n\r\n#XFLD\r\nEMAIL=LG8+Sp4OkHDb7tJN8j0rSA_Email\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=TDaj9xzX9V0Vv4PKbBp1qw_Take home Pay\r\n\r\n#XFLD\r\nSALARY=Av0hIlfclA0XAS9zxMK6+A_Salary\r\n\r\n#XFLD\r\nBONUS=Y3o7nwBf4UFdH1bMujsTLA_Bonus\r\n\r\n#XFLD\r\nYEAR=Dz2l+8wQj2HoLQdhvcWDpQ_Year\r\n\r\n#XFLD\r\nCOMPENSATION=rUHOcPtoF8akT7s5s3dw2Q_Compensation\r\n\r\n#XFLD\r\nCATEGORY=nLy2UxLsiOxYFeOLlM4PYA_Category\r\n\r\n#XFLD\r\nPERIOD=I3P1OpeFmBaVCveXVQ7lVQ_Period\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=iZx6XtX5enwGRQCkTp+dKQ_Employee Hierarchy\r\n\r\n#XFLD\r\nAS_OF=gWo+/6HsAqoW5Jx2wmOunQ_As of {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=G6v8VporolIpda8/3CLF7w_Choose a Personnel Assignment\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=bu3qPk6cHl6pLZtpde0RyQ_Personnel Assignments\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=ISCJtPwEy0JLZdNH2j4HJQ_An internal error Occurred. Please contact system administrator.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=HKfpjftiVRnY3ZxnoCr+LQ_Internal Error\r\n\r\n#XBUT: Button to accept\r\nOK=kZYIVqsW04RIg/zTiUyN2w_OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=DHkP+RAwAdCVJrlpS5SeiA_Cancel\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=96M9jSMU1vEutaJ3TpOwgQ_Create Time Event\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=1Hw41MaEryXR84R2gYQbrw_Time Balance\r\n',
		"hcm/people/profile/i18n/i18n_es.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Perfil de personas\r\n\r\n#XTIT: \r\nWHATS_NEW=Novedades\r\n\r\n#XTIT: \r\nTALENT=Talento\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notas\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Mis notas personales\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Informaci\\u00F3n personal\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notificaciones\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Registro de tiempos y ausencias\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Pr\\u00F3ximos cursos\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Cualificaciones y habilidades\r\n\r\n#XTIT: \r\nPERFORMANCE=Rendimiento\r\n\r\n#XTIT: \r\nPROGRESSION=Progreso\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Recibo de n\\u00F3mina\r\n\r\n#XTIT: \r\nSALARY_BONUS=Salario y bonificaci\\u00F3n\r\n\r\n#XFLD\r\nTIME_RECORDING=Registro de tiempos\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Pr\\u00F3ximas vacaciones\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Pr\\u00F3xima ausencia\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=No existen datos disponibles en los \\u00FAltimos {0} meses \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=No existen pr\\u00F3ximas bajas para los pr\\u00F3ximos {0} meses\r\n\r\n#XFLD\r\nTIME_NO_DATA=La grabaci\\u00F3n de tiempo est\\u00E1 actualizada\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=No existen modelos de transferencias de tiempos disponibles a partir de {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=No existen recibos de n\\u00F3mina disponibles en los \\u00FAltimos {0} meses \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=No existen calificaciones disponibles en los \\u00FAltimos {0} meses \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=No existen pr\\u00F3ximos cursos para los pr\\u00F3ximos {0} meses\r\n\r\n#XFLD\r\nPERF_NO_DATA=No existen evaluaciones de rendimiento disponibles en los \\u00FAltimos {0} a\\u00F1os\r\n\r\n#XFLD\r\nCOMP_NO_DATA=No existen datos de compensaci\\u00F3n disponibles para los \\u00FAltimos {0} a\\u00F1os\r\n\r\n#XFLD\r\nPROG_NO_DATA=No existen datos de progresi\\u00F3n disponibles\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=No existen notificaciones disponibles\r\n\r\n#XFLD\r\nNOTES_NO_DATA=No existen notas disponibles\r\n\r\n#XFLD\r\nPERS_NO_DATA=No existe informaci\\u00F3n disponible\r\n\r\n#XFLD\r\nNO_DATA=No existen datos disponibles\r\n\r\n#XFLD\r\nTOPIC=Tema\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Nivel de competencia\r\n\r\n#XFLD\r\nVALID_UNTIL=V\\u00E1lido hasta\r\n\r\n#XFLD\r\nDATEOFBIRTH=Fecha de nacimiento\r\n\r\n#XFLD\r\nMARITALSTATUS=Estado civil\r\n\r\n#XFLD\r\nMISSING_DAYS=D\\u00EDas faltantes\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=D\\u00EDas no completados\r\n\r\n#XFLD\r\nDAYS=D\\u00EDas\r\n\r\n#XFLD\r\nHOURS=Horas\r\n\r\n#XFLD\r\nSINCE=Desde\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Salario y bonificaci\\u00F3n\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Clasificaci\\u00F3n\r\n\r\n#XFLD\r\nRECORD_TIME=Registrar tiempo\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Solicitar ausencia\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Ver recibo de n\\u00F3mina\r\n\r\n#XFLD\r\nLOCATION=Ubicaci\\u00F3n\r\n\r\n#XFLD\r\nOFFICE_PHONE=Tel\\u00E9fono de la oficina\r\n\r\n#XFLD\r\nEMAIL=Correo electr\\u00F3nico\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Salario neto\r\n\r\n#XFLD\r\nSALARY=Salario\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Ejercicio\r\n\r\n#XFLD\r\nCOMPENSATION=Remuneraci\\u00F3n\r\n\r\n#XFLD\r\nCATEGORY=Categor\\u00EDa\r\n\r\n#XFLD\r\nPERIOD=Per\\u00EDodo\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Jerarqu\\u00EDa de empleados\r\n\r\n#XFLD\r\nAS_OF=A partir de {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Seleccione un contrato de ocupaci\\u00F3n\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Contratos de ocupaci\\u00F3n\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Se ha producido un error interno. P\\u00F3ngase en contacto con el administrador del sistema.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Error interno\r\n\r\n#XBUT: Button to accept\r\nOK=Aceptar\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Cancelar\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Crear hecho temporal\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Saldo de tiempos\r\n',
		"hcm/people/profile/i18n/i18n_fr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil de personnes\r\n\r\n#XTIT: \r\nWHATS_NEW=Nouveaut\\u00E9s\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notes\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Mes notes personnelles\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Informations personnelles\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notifications\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Feuille de saisie des temps et absences\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Formations pr\\u00E9vues\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Comp\\u00E9tences et facult\\u00E9s\r\n\r\n#XTIT: \r\nPERFORMANCE=Performance\r\n\r\n#XTIT: \r\nPROGRESSION=Progression\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Fiche de paie\r\n\r\n#XTIT: \r\nSALARY_BONUS=Salaires et primes\r\n\r\n#XFLD\r\nTIME_RECORDING=Saisie des temps\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Cong\\u00E9s pr\\u00E9vus\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Cong\\u00E9 en attente\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Aucune donn\\u00E9e disponible pour les {0} derniers mois \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Aucun cong\\u00E9 pr\\u00E9vu dans les {0} prochains mois\r\n\r\n#XFLD\r\nTIME_NO_DATA=La saisie des temps est \\u00E0 jour.\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Aucun solde horaire disponible \\u00E0 partir du {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Aucune fiche de paie disponible pour les {0} derniers mois \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Aucune comp\\u00E9tence disponible pour les {0} derniers mois \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Aucune formation pr\\u00E9vue dans les {0} prochains mois\r\n\r\n#XFLD\r\nPERF_NO_DATA=Aucune \\u00E9valuation de la performance disponible pour les {0} derni\\u00E8res ann\\u00E9es\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Aucune donn\\u00E9e de r\\u00E9mun\\u00E9ration disponible pour les {0} derni\\u00E8res ann\\u00E9es\r\n\r\n#XFLD\r\nPROG_NO_DATA=Aucune donn\\u00E9e de progression disponible\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Aucune notification disponible\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Aucune note disponible\r\n\r\n#XFLD\r\nPERS_NO_DATA=Aucune information disponible\r\n\r\n#XFLD\r\nNO_DATA=Aucune donn\\u00E9e disponible\r\n\r\n#XFLD\r\nTOPIC=Rubrique\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Niveau de comp\\u00E9tence\r\n\r\n#XFLD\r\nVALID_UNTIL=Fin de validit\\u00E9\r\n\r\n#XFLD\r\nDATEOFBIRTH=Date de naissance\r\n\r\n#XFLD\r\nMARITALSTATUS=Situation de famille\r\n\r\n#XFLD\r\nMISSING_DAYS=Jours non renseign\\u00E9s\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Jours incomplets\r\n\r\n#XFLD\r\nDAYS=Jrs\r\n\r\n#XFLD\r\nHOURS=Heures\r\n\r\n#XFLD\r\nSINCE=Depuis\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Salaire et prime\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u00C9valuation\r\n\r\n#XFLD\r\nRECORD_TIME=Enregistrer temps\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Demander cong\\u00E9\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Afficher fiche de paie\r\n\r\n#XFLD\r\nLOCATION=Lieu de travail\r\n\r\n#XFLD\r\nOFFICE_PHONE=N\\u00B0 t\\u00E9l. travail\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Salaire net\r\n\r\n#XFLD\r\nSALARY=Salaire\r\n\r\n#XFLD\r\nBONUS=Prime\r\n\r\n#XFLD\r\nYEAR=Exercice\r\n\r\n#XFLD\r\nCOMPENSATION=R\\u00E9mun\\u00E9ration\r\n\r\n#XFLD\r\nCATEGORY=Cat\\u00E9gorie\r\n\r\n#XFLD\r\nPERIOD=P\\u00E9riode\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hi\\u00E9rarchie de salari\\u00E9s\r\n\r\n#XFLD\r\nAS_OF=\\u00C0 partir du {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=S\\u00E9lectionner un contrat de travail\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Contrats de travail\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Une erreur interne s\'est produite. Contactez l\'administrateur syst\\u00E8me.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Erreur interne\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Interrompre\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Cr\\u00E9ation de mouvements\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Solde horaire\r\n',
		"hcm/people/profile/i18n/i18n_hr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil zaposlenika\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u0160to je novo\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Bilje\\u0161ke\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Moje osobne bilje\\u0161ke\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Osobne informacije\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Obavijesti\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Bilje\\u017Eenje vremena i odsutnosti\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Nadolaze\\u0107i te\\u010Dajevi\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifikacije i vje\\u0161tine\r\n\r\n#XTIT: \r\nPERFORMANCE=U\\u010Dinkovitost\r\n\r\n#XTIT: \r\nPROGRESSION=Napredak\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Ispis pla\\u0107e\r\n\r\n#XTIT: \r\nSALARY_BONUS=Pla\\u0107a i bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Bilje\\u017Eenje vremena\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Predstoje\\u0107i dopust\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Predstoje\\u0107e odsustvo\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Podaci nisu raspolo\\u017Eivi za zadnjih {0} mjeseci \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Nema predstoje\\u0107ih dopusta u sljede\\u0107ih {0} mjeseci\r\n\r\n#XFLD\r\nTIME_NO_DATA=Bilje\\u017Eenje vremena aktualno\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Vremenska stanja raspolo\\u017Eiva od {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Ispisi pla\\u0107e nisu raspolo\\u017Eivi za zadnjih {0} mjeseci \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Kvalifikacije nisu raspolo\\u017Eive za zadnjih {0} mjeseci \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Nema predstoje\\u0107ih te\\u010Dajeva u sljede\\u0107ih {0} mjeseci\r\n\r\n#XFLD\r\nPERF_NO_DATA=Vrednovanje izvedbe nije raspolo\\u017Eivo za zadnjih {0} godina\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Podaci naknade nisu raspolo\\u017Eivi za zadnjih {0} godina\r\n\r\n#XFLD\r\nPROG_NO_DATA=Podaci o napretku nisu raspolo\\u017Eivi\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Obavijesti nisu raspolo\\u017Eive\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Bilje\\u0161ke nisu raspolo\\u017Eive\r\n\r\n#XFLD\r\nPERS_NO_DATA=Informacije nije raspolo\\u017Eive\r\n\r\n#XFLD\r\nNO_DATA=Podaci nisu raspolo\\u017Eivi\r\n\r\n#XFLD\r\nTOPIC=Tema\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Razina stru\\u010Dnosti\r\n\r\n#XFLD\r\nVALID_UNTIL=Vrijedi do\r\n\r\n#XFLD\r\nDATEOFBIRTH=Datum ro\\u0111enja\r\n\r\n#XFLD\r\nMARITALSTATUS=Bra\\u010Dno stanje\r\n\r\n#XFLD\r\nMISSING_DAYS=Dani koji nedostaju\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Nepotpuni dani\r\n\r\n#XFLD\r\nDAYS=Dani\r\n\r\n#XFLD\r\nHOURS=Sati\r\n\r\n#XFLD\r\nSINCE=Od\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Pla\\u0107a i bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Rangiranje ocjena\r\n\r\n#XFLD\r\nRECORD_TIME=Zabilje\\u017Ei vrijeme\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Prijavi se za dopust\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Prika\\u017Ei ispis pla\\u0107e\r\n\r\n#XFLD\r\nLOCATION=Lokacija\r\n\r\n#XFLD\r\nOFFICE_PHONE=Poslovni telefon\r\n\r\n#XFLD\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Neto pla\\u0107a\r\n\r\n#XFLD\r\nSALARY=Pla\\u0107a\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Godina\r\n\r\n#XFLD\r\nCOMPENSATION=Naknada\r\n\r\n#XFLD\r\nCATEGORY=Kategorija\r\n\r\n#XFLD\r\nPERIOD=Razdoblje\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hijerarhija zaposlenika\r\n\r\n#XFLD\r\nAS_OF=Od {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Izaberite ugovor o radu\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Ugovori o radu\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Pojavila se interna gre\\u0161ka. Molimo, kontaktirajte svog administratora sustava.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Interna gre\\u0161ka\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Otka\\u017Ei\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Kreiraj vremenski doga\\u0111aj\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Vremensko stanje\r\n',
		"hcm/people/profile/i18n/i18n_hu.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Szem\\u00E9lyek profilja\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u00DAjdons\\u00E1gok\r\n\r\n#XTIT: \r\nTALENT=Tehets\\u00E9g\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Megjegyz\\u00E9sek\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Saj\\u00E1t szem\\u00E9lyes jegyzetek\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Szem\\u00E9lyi adatok\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u00C9rtes\\u00EDt\\u00E9sek\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Id\\u0151r\\u00F6gz\\u00EDt\\u00E9s & t\\u00E1voll\\u00E9tek\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=K\\u00F6zelg\\u0151 tanfolyamok\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifik\\u00E1ci\\u00F3k & j\\u00E1rtass\\u00E1gok\r\n\r\n#XTIT: \r\nPERFORMANCE=Teljes\\u00EDtm\\u00E9ny\r\n\r\n#XTIT: \r\nPROGRESSION=El\\u0151menetel\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=B\\u00E9rszelv\\u00E9ny\r\n\r\n#XTIT: \r\nSALARY_BONUS=Fizet\\u00E9s \\u00E9s b\\u00F3nusz\r\n\r\n#XFLD\r\nTIME_RECORDING=Id\\u0151r\\u00F6gz\\u00EDt\\u00E9s\r\n\r\n#XFLD\r\nUPCOMING_VACATION=K\\u00F6zelg\\u0151 szabads\\u00E1g\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=K\\u00F6zelg\\u0151 t\\u00E1voll\\u00E9t\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Nem \\u00E1ll rendelkez\\u00E9sre adat az ut\\u00F3bbi {0} h\\u00F3napra vonatkoz\\u00F3an \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Nincs k\\u00F6zelg\\u0151 t\\u00E1voll\\u00E9t a k\\u00F6vetkez\\u0151 {0} h\\u00F3napban\r\n\r\n#XFLD\r\nTIME_NO_DATA=Az id\\u0151r\\u00F6gz\\u00EDt\\u00E9s aktu\\u00E1lis\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Nem \\u00E1ll rendelkez\\u00E9sre id\\u0151egyenleg ekkort\\u00F3l\\: {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Nem \\u00E1ll rendelkez\\u00E9sre b\\u00E9rszelv\\u00E9ny az ut\\u00F3bbi {0} h\\u00F3napban \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Nem \\u00E1ll rendelkez\\u00E9sre kvalifik\\u00E1ci\\u00F3 az ut\\u00F3bbi {0} h\\u00F3napban \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Nincs k\\u00F6zelg\\u0151 tanfolyam a k\\u00F6vetkez\\u0151 {0} h\\u00F3napban\r\n\r\n#XFLD\r\nPERF_NO_DATA=Nem \\u00E1ll rendelkez\\u00E9sre performance-\\u00E9rt\\u00E9kel\\u00E9s az ut\\u00F3bbi {0} \\u00E9vben\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Nem \\u00E1llnak rendelkez\\u00E9sre javadalmaz\\u00E1si adatok az ut\\u00F3bbi {0} \\u00E9vre vonatkoz\\u00F3an\r\n\r\n#XFLD\r\nPROG_NO_DATA=Nem \\u00E1llnak rendelkez\\u00E9sre adatok az el\\u0151menetelr\\u0151l\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Nem \\u00E1llnak rendelkez\\u00E9sre megjegyz\\u00E9sek\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Nem \\u00E1llnak rendelkez\\u00E9sre jegyzetek\r\n\r\n#XFLD\r\nPERS_NO_DATA=Nem \\u00E1ll rendelkez\\u00E9sre inform\\u00E1ci\\u00F3\r\n\r\n#XFLD\r\nNO_DATA=Nem \\u00E1ll rendelkez\\u00E9sre adat\r\n\r\n#XFLD\r\nTOPIC=T\\u00E9ma\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Kompetenciaszint\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u00C9rv\\u00E9nyes eddig\\:\r\n\r\n#XFLD\r\nDATEOFBIRTH=Sz\\u00FClet\\u00E9si d\\u00E1tum\r\n\r\n#XFLD\r\nMARITALSTATUS=Csal\\u00E1di \\u00E1llapot\r\n\r\n#XFLD\r\nMISSING_DAYS=Hi\\u00E1nyz\\u00F3 napok\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Nem teljes napok\r\n\r\n#XFLD\r\nDAYS=Napok\r\n\r\n#XFLD\r\nHOURS=\\u00D3r\\u00E1k\r\n\r\n#XFLD\r\nSINCE=Kezd\\u0151d\\u00E1tum\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Fizet\\u00E9s & b\\u00F3nusz\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u00C9rt\\u00E9kel\\u0151 besz\\u00E9lget\\u00E9s eredm\\u00E9nye\r\n\r\n#XFLD\r\nRECORD_TIME=Id\\u0151 r\\u00F6gz\\u00EDt\\u00E9se\r\n\r\n#XFLD\r\nAPPLY_LEAVE=T\\u00E1voll\\u00E9t k\\u00E9relmez\\u00E9se\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=B\\u00E9rszelv\\u00E9ny megjelen\\u00EDt\\u00E9se\r\n\r\n#XFLD\r\nLOCATION=Lok\\u00E1ci\\u00F3\r\n\r\n#XFLD\r\nOFFICE_PHONE=Munkahelyi telefon\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Nett\\u00F3 fizet\\u00E9s\r\n\r\n#XFLD\r\nSALARY=Fizet\\u00E9s\r\n\r\n#XFLD\r\nBONUS=B\\u00F3nusz\r\n\r\n#XFLD\r\nYEAR=\\u00C9v\r\n\r\n#XFLD\r\nCOMPENSATION=Kompenz\\u00E1ci\\u00F3\r\n\r\n#XFLD\r\nCATEGORY=Kateg\\u00F3ria\r\n\r\n#XFLD\r\nPERIOD=Peri\\u00F3dus\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Alkalmazotti hierarchia\r\n\r\n#XFLD\r\nAS_OF=Ekkort\\u00F3l\\: {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Foglalkoztat\\u00E1si szerz\\u0151d\\u00E9s v\\u00E1laszt\\u00E1sa\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Foglalkoztat\\u00E1si szerz\\u0151d\\u00E9sek\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Bels\\u0151 hiba t\\u00F6rt\\u00E9nt. K\\u00E9rem, vegye fel a kapcsolatot rendszeradminisztr\\u00E1tor\\u00E1val.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Bels\\u0151 hiba\r\n\r\n#XBUT: Button to accept\r\nOK=Rendben\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=M\\u00E9gse\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Id\\u0151esem\\u00E9ny l\\u00E9trehoz\\u00E1sa\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Id\\u0151egyenleg\r\n',
		"hcm/people/profile/i18n/i18n_it.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profilo persone\r\n\r\n#XTIT: \r\nWHATS_NEW=Novit\\u00E0\r\n\r\n#XTIT: \r\nTALENT=Talento\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Note\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Le mie note personali\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Dati personali\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notifiche\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Timesheet e assenze\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Corsi futuri\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Qualifiche e competenze\r\n\r\n#XTIT: \r\nPERFORMANCE=Prestazione\r\n\r\n#XTIT: \r\nPROGRESSION=Progressione\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Busta paga\r\n\r\n#XTIT: \r\nSALARY_BONUS=Retribuzione e bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Rilevazione presenze\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Ferie future\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Ferie future\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Nessun dato disponibile per gli ultimi {0} mesi \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Non figurano ferie future nei prossimi {0} mesi\r\n\r\n#XFLD\r\nTIME_NO_DATA=La rilevazione presenze \\u00E8 aggiornata\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Nessun saldo tempi disponibile a partire da {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Nessuna busta paga disponibile negli ultimi {0} mesi \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Nessuna qualifica disponibile negli ultimi {0} mesi \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Nessun corso futuro nei prossimi {0} mesi\r\n\r\n#XFLD\r\nPERF_NO_DATA=Nessuna scala di valutazione disponibile per gli ultimi {0} anni\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Nessun dato di retribuzione disponibile per gli ultimi {0} anni\r\n\r\n#XFLD\r\nPROG_NO_DATA=Nessun dato disponibile sulla progressione\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Nessuna notifica disponibile\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Nessuna nota disponibile\r\n\r\n#XFLD\r\nPERS_NO_DATA=Nessuna informazione disponibile\r\n\r\n#XFLD\r\nNO_DATA=Nessun dato disponibile\r\n\r\n#XFLD\r\nTOPIC=Argomento\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Livello di competenza\r\n\r\n#XFLD\r\nVALID_UNTIL=Valido fino al\r\n\r\n#XFLD\r\nDATEOFBIRTH=Data di nascita\r\n\r\n#XFLD\r\nMARITALSTATUS=Stato civile\r\n\r\n#XFLD\r\nMISSING_DAYS=Giorni mancanti\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Giorni incompleti\r\n\r\n#XFLD\r\nDAYS=Giorni\r\n\r\n#XFLD\r\nHOURS=Ore\r\n\r\n#XFLD\r\nSINCE=Da\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Retribuzione e bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Scala di valutazione\r\n\r\n#XFLD\r\nRECORD_TIME=Registra orari\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Fai domanda di ferie\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Visualizza busta paga\r\n\r\n#XFLD\r\nLOCATION=Ubicazione\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telefono dell\'ufficio\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Stipendio netto\r\n\r\n#XFLD\r\nSALARY=Retribuzione\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Anno\r\n\r\n#XFLD\r\nCOMPENSATION=Retribuzione\r\n\r\n#XFLD\r\nCATEGORY=Categoria\r\n\r\n#XFLD\r\nPERIOD=Periodo\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Gerarchia dipendenti\r\n\r\n#XFLD\r\nAS_OF=A partire da {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Seleziona un contratto d\'impiego\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Contratti d\'impiego\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Si \\u00E8 verificato un errore interno; contatta l\'amministratore del sistema.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Errore interno\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Annulla\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Crea evento tempo\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Saldo tempi\r\n',
		"hcm/people/profile/i18n/i18n_iw.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=\\u05E4\\u05E8\\u05D5\\u05E4\\u05D9\\u05DC \\u05E2\\u05D5\\u05D1\\u05D3\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u05D7\\u05D3\\u05E9\\u05D5\\u05EA\r\n\r\n#XTIT: \r\nTALENT=\\u05DE\\u05D5\\u05E2\\u05DE\\u05D3 \\u05DE\\u05D5\\u05D1\\u05D9\\u05DC\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=\\u05D4\\u05E2\\u05E8\\u05D5\\u05EA\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=\\u05D4\\u05D4\\u05E2\\u05E8\\u05D5\\u05EA \\u05D4\\u05D0\\u05D9\\u05E9\\u05D9\\u05D5\\u05EA \\u05E9\\u05DC\\u05D9\r\n\r\n#XTIT: \r\nPERSONAL_INFO=\\u05DE\\u05D9\\u05D3\\u05E2 \\u05D0\\u05D9\\u05E9\\u05D9\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u05D4\\u05D5\\u05D3\\u05E2\\u05D5\\u05EA\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=\\u05D2\\u05D9\\u05DC\\u05D9\\u05D5\\u05DF \\u05E9\\u05E2\\u05D5\\u05EA \\u05D5\\u05D4\\u05D9\\u05E2\\u05D3\\u05E8\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=\\u05D4\\u05E7\\u05D5\\u05E8\\u05E1\\u05D9\\u05DD \\u05D4\\u05E7\\u05E8\\u05D5\\u05D1\\u05D9\\u05DD\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=\\u05DB\\u05D9\\u05E9\\u05D5\\u05E8\\u05D9\\u05DD \\u05D5\\u05DE\\u05D9\\u05D5\\u05DE\\u05E0\\u05D5\\u05D9\\u05D5\\u05EA\r\n\r\n#XTIT: \r\nPERFORMANCE=\\u05D1\\u05D9\\u05E6\\u05D5\\u05E2\\u05D9\\u05DD\r\n\r\n#XTIT: \r\nPROGRESSION=\\u05D4\\u05EA\\u05E7\\u05D3\\u05DE\\u05D5\\u05EA\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u05EA\\u05DC\\u05D5\\u05E9 \\u05DE\\u05E9\\u05DB\\u05D5\\u05E8\\u05EA\r\n\r\n#XTIT: \r\nSALARY_BONUS=\\u05DE\\u05E9\\u05DB\\u05D5\\u05E8\\u05EA \\u05D5\\u05D1\\u05D5\\u05E0\\u05D5\\u05E1\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u05E8\\u05D9\\u05E9\\u05D5\\u05DD \\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XFLD\r\nUPCOMING_VACATION=\\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05D4\\u05E7\\u05E8\\u05D5\\u05D1\\u05D4\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=\\u05D4\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4 \\u05D4\\u05E7\\u05E8\\u05D5\\u05D1\\u05D4\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=\\u05D0\\u05D9\\u05DF \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05D7\\u05D5\\u05D3\\u05E9\\u05D9\\u05DD \\u05D4\\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D9\\u05DD \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u05DC\\u05D0 \\u05DE\\u05EA\\u05D5\\u05DB\\u05E0\\u05E0\\u05D5\\u05EA \\u05D7\\u05D5\\u05E4\\u05E9\\u05D5\\u05EA \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05D7\\u05D5\\u05D3\\u05E9\\u05D9\\u05DD \\u05D4\\u05D1\\u05D0\\u05D9\\u05DD\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u05E8\\u05D9\\u05E9\\u05D5\\u05DD \\u05E9\\u05E2\\u05D5\\u05EA \\u05D4\\u05E2\\u05D1\\u05D5\\u05D3\\u05D4 \\u05E2\\u05D3\\u05DB\\u05E0\\u05D9\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=\\u05DC\\u05D0 \\u05E7\\u05D9\\u05D9\\u05DE\\u05D5\\u05EA \\u05D9\\u05EA\\u05E8\\u05D5\\u05EA \\u05D6\\u05DE\\u05DF \\u05D6\\u05DE\\u05D9\\u05E0\\u05D5\\u05EA \\u05D4\\u05D7\\u05DC \\u05DE- {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05EA\\u05DC\\u05D5\\u05E9\\u05D9 \\u05DE\\u05E9\\u05DB\\u05D5\\u05E8\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05D7\\u05D5\\u05D3\\u05E9\\u05D9\\u05DD \\u05D4\\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D9\\u05DD \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05DB\\u05D9\\u05E9\\u05D5\\u05E8\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05D7\\u05D5\\u05D3\\u05E9\\u05D9\\u05DD \\u05D4\\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D9\\u05DD \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u05DC\\u05D0 \\u05DE\\u05EA\\u05D5\\u05DB\\u05E0\\u05E0\\u05D9\\u05DD \\u05E7\\u05D5\\u05E8\\u05E1\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05D7\\u05D5\\u05D3\\u05E9\\u05D9\\u05DD \\u05D4\\u05D1\\u05D0\\u05D9\\u05DD\r\n\r\n#XFLD\r\nPERF_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05D3\\u05D9\\u05E8\\u05D5\\u05D2\\u05D9 \\u05D1\\u05D9\\u05E6\\u05D5\\u05E2\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05E9\\u05E0\\u05D9\\u05DD \\u05D4\\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D5\\u05EA\r\n\r\n#XFLD\r\nCOMP_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9 \\u05E4\\u05D9\\u05E6\\u05D5\\u05D9\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD \\u05E2\\u05D1\\u05D5\\u05E8 {0} \\u05D4\\u05E9\\u05E0\\u05D9\\u05DD \\u05D4\\u05D0\\u05D7\\u05E8\\u05D5\\u05E0\\u05D5\\u05EA\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9 \\u05D4\\u05EA\\u05E7\\u05D3\\u05DE\\u05D5\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05D4\\u05D5\\u05D3\\u05E2\\u05D5\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D5\\u05EA\r\n\r\n#XFLD\r\nNOTES_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05D4\\u05E2\\u05E8\\u05D5\\u05EA \\u05D6\\u05DE\\u05D9\\u05E0\\u05D5\\u05EA\r\n\r\n#XFLD\r\nPERS_NO_DATA=\\u05D0\\u05D9\\u05DF \\u05DE\\u05D9\\u05D3\\u05E2 \\u05D6\\u05DE\\u05D9\\u05DF\r\n\r\n#XFLD\r\nNO_DATA=\\u05D0\\u05D9\\u05DF \\u05E0\\u05EA\\u05D5\\u05E0\\u05D9\\u05DD \\u05D6\\u05DE\\u05D9\\u05E0\\u05D9\\u05DD\r\n\r\n#XFLD\r\nTOPIC=\\u05E0\\u05D5\\u05E9\\u05D0\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u05E8\\u05DE\\u05EA \\u05D9\\u05DB\\u05D5\\u05DC\\u05EA\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u05D1\\u05EA\\u05D5\\u05E7\\u05E3 \\u05E2\\u05D3\r\n\r\n#XFLD\r\nDATEOFBIRTH=\\u05EA\\u05D0\\u05E8\\u05D9\\u05DA \\u05DC\\u05D9\\u05D3\\u05D4\r\n\r\n#XFLD\r\nMARITALSTATUS=\\u05DE\\u05E6\\u05D1 \\u05DE\\u05E9\\u05E4\\u05D7\\u05EA\\u05D9\r\n\r\n#XFLD\r\nMISSING_DAYS=\\u05D9\\u05DE\\u05D9\\u05DD \\u05D7\\u05E1\\u05E8\\u05D9\\u05DD\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=\\u05D9\\u05DE\\u05D9\\u05DD \\u05DC\\u05D0 \\u05DE\\u05DC\\u05D0\\u05D9\\u05DD\r\n\r\n#XFLD\r\nDAYS=\\u05D9\\u05DE\\u05D9\\u05DD\r\n\r\n#XFLD\r\nHOURS=\\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XFLD\r\nSINCE=\\u05DE\\u05D0\\u05D6\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=\\u05DE\\u05E9\\u05DB\\u05D5\\u05E8\\u05EA \\u05D5\\u05D1\\u05D5\\u05E0\\u05D5\\u05E1\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u05D3\\u05D9\\u05E8\\u05D5\\u05D2 \\u05D7\\u05D5\\u05D5\\u05EA \\u05D3\\u05E2\\u05EA\r\n\r\n#XFLD\r\nRECORD_TIME=\\u05E8\\u05E9\\u05D5\\u05DD \\u05E9\\u05E2\\u05D5\\u05EA \\u05E2\\u05D1\\u05D5\\u05D3\\u05D4\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u05D4\\u05D2\\u05E9 \\u05D1\\u05E7\\u05E9\\u05D4 \\u05DC\\u05D7\\u05D5\\u05E4\\u05E9\\u05D4\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u05D4\\u05E6\\u05D2 \\u05EA\\u05DC\\u05D5\\u05E9 \\u05DE\\u05E9\\u05DB\\u05D5\\u05E8\\u05EA\r\n\r\n#XFLD\r\nLOCATION=\\u05DE\\u05D9\\u05E7\\u05D5\\u05DD\r\n\r\n#XFLD\r\nOFFICE_PHONE=\\u05D8\\u05DC\\u05E4\\u05D5\\u05DF \\u05DE\\u05E9\\u05E8\\u05D3\\u05D9\r\n\r\n#XFLD\r\nEMAIL=\\u05D3\\u05D5\\u05D0"\\u05DC\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u05DE\\u05E9\\u05DB\\u05D5\\u05E8\\u05EA \\u05E0\\u05D8\\u05D5\r\n\r\n#XFLD\r\nSALARY=\\u05E9\\u05DB\\u05E8\r\n\r\n#XFLD\r\nBONUS=\\u05D1\\u05D5\\u05E0\\u05D5\\u05E1\r\n\r\n#XFLD\r\nYEAR=\\u05E9\\u05E0\\u05D4\r\n\r\n#XFLD\r\nCOMPENSATION=\\u05E4\\u05D9\\u05E6\\u05D5\\u05D9\\u05D9\\u05DD\r\n\r\n#XFLD\r\nCATEGORY=\\u05E7\\u05D8\\u05D2\\u05D5\\u05E8\\u05D9\\u05D4\r\n\r\n#XFLD\r\nPERIOD=\\u05EA\\u05E7\\u05D5\\u05E4\\u05D4\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u05D4\\u05D9\\u05E8\\u05E8\\u05DB\\u05D9\\u05D9\\u05EA \\u05E2\\u05D5\\u05D1\\u05D3\\u05D9\\u05DD\r\n\r\n#XFLD\r\nAS_OF=\\u05D4\\u05D7\\u05DC \\u05DE-{0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=\\u05D1\\u05D7\\u05E8 \\u05D4\\u05E7\\u05E6\\u05D0\\u05EA \\u05E2\\u05D5\\u05D1\\u05D3\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=\\u05D4\\u05E7\\u05E6\\u05D0\\u05D5\\u05EA \\u05E2\\u05D5\\u05D1\\u05D3\\u05D9\\u05DD\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=\\u05D0\\u05D9\\u05E8\\u05E2\\u05D4 \\u05E9\\u05D2\\u05D9\\u05D0\\u05D4 \\u05E4\\u05E0\\u05D9\\u05DE\\u05D9\\u05EA. \\u05E6\\u05D5\\u05E8 \\u05E7\\u05E9\\u05E8 \\u05E2\\u05DD \\u05DE\\u05E0\\u05D4\\u05DC \\u05D4\\u05DE\\u05E2\\u05E8\\u05DB\\u05EA.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=\\u05E9\\u05D2\\u05D9\\u05D0\\u05D4 \\u05E4\\u05E0\\u05D9\\u05DE\\u05D9\\u05EA\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u05D1\\u05D8\\u05DC\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=\\u05E6\\u05D5\\u05E8 \\u05D0\\u05D9\\u05E8\\u05D5\\u05E2 \\u05E8\\u05D9\\u05E9\\u05D5\\u05DD \\u05E9\\u05E2\\u05D5\\u05EA\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u05D9\\u05EA\\u05E8\\u05EA \\u05D6\\u05DE\\u05DF\r\n',
		"hcm/people/profile/i18n/i18n_ja.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=\\u5F93\\u696D\\u54E1\\u30D7\\u30ED\\u30D5\\u30A1\\u30A4\\u30EB\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u65B0\\u6A5F\\u80FD\r\n\r\n#XTIT: \r\nTALENT=\\u30BF\\u30EC\\u30F3\\u30C8\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=\\u30E1\\u30E2\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=\\u500B\\u4EBA\\u30E1\\u30E2\r\n\r\n#XTIT: \r\nPERSONAL_INFO=\\u500B\\u4EBA\\u60C5\\u5831\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u901A\\u77E5\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=\\u30BF\\u30A4\\u30E0\\u30B7\\u30FC\\u30C8\\u304A\\u3088\\u3073\\u4F11\\u52D9\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=\\u4E88\\u5B9A\\u7814\\u4FEE\\u30B3\\u30FC\\u30B9\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=\\u8CC7\\u683C/\\u80FD\\u529B\\u304A\\u3088\\u3073\\u30B9\\u30AD\\u30EB\r\n\r\n#XTIT: \r\nPERFORMANCE=\\u696D\\u7E3E\r\n\r\n#XTIT: \r\nPROGRESSION=\\u9032\\u6357\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u7D66\\u4E0E\\u660E\\u7D30\r\n\r\n#XTIT: \r\nSALARY_BONUS=\\u7D66\\u4E0E\\u304A\\u3088\\u3073\\u30DC\\u30FC\\u30CA\\u30B9\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u30BF\\u30A4\\u30E0\\u30EC\\u30B3\\u30FC\\u30C7\\u30A3\\u30F3\\u30B0\r\n\r\n#XFLD\r\nUPCOMING_VACATION=\\u4E88\\u5B9A\\u4F11\\u6687\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=\\u6B21\\u306E\\u4F11\\u6687\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=\\u904E\\u53BB {0} \\u30AB\\u6708\\u9593\\u306E\\u30C7\\u30FC\\u30BF\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093 \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u4ECA\\u5F8C {0} \\u30AB\\u6708\\u306B\\u4E88\\u5B9A\\u3055\\u308C\\u3066\\u3044\\u308B\\u4F11\\u6687\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u30BF\\u30A4\\u30E0\\u30EC\\u30B3\\u30FC\\u30C7\\u30A3\\u30F3\\u30B0\\u306F\\u6700\\u65B0\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF={0} \\u6642\\u70B9\\u306E\\u30BF\\u30A4\\u30E0\\u30D0\\u30E9\\u30F3\\u30B9\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093 \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=\\u904E\\u53BB {0} \\u30AB\\u6708\\u9593\\u306E\\u7D66\\u4E0E\\u660E\\u7D30\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093 \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=\\u904E\\u53BB {0} \\u30AB\\u6708\\u9593\\u306E\\u8CC7\\u683C/\\u80FD\\u529B\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093 \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u4ECA\\u5F8C {0} \\u30AB\\u6708\\u9593\\u306B\\u4E88\\u5B9A\\u3055\\u308C\\u3066\\u3044\\u308B\\u30B3\\u30FC\\u30B9\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XFLD\r\nPERF_NO_DATA=\\u904E\\u53BB {0} \\u5E74\\u9593\\u306E\\u696D\\u7E3E\\u8A55\\u4FA1\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XFLD\r\nCOMP_NO_DATA=\\u904E\\u53BB {0} \\u5E74\\u9593\\u306E\\u5831\\u916C\\u30C7\\u30FC\\u30BF\\u306F\\u3042\\u308A\\u307E\\u305B\\u3093\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u5229\\u7528\\u53EF\\u80FD\\u306A\\u9032\\u6357\\u30C7\\u30FC\\u30BF\\u306A\\u3057\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=\\u5229\\u7528\\u53EF\\u80FD\\u306A\\u901A\\u77E5\\u306A\\u3057\r\n\r\n#XFLD\r\nNOTES_NO_DATA=\\u5229\\u7528\\u53EF\\u80FD\\u30E1\\u30E2\\u306A\\u3057\r\n\r\n#XFLD\r\nPERS_NO_DATA=\\u5229\\u7528\\u53EF\\u80FD\\u306A\\u60C5\\u5831\\u306A\\u3057\r\n\r\n#XFLD\r\nNO_DATA=\\u5229\\u7528\\u53EF\\u80FD\\u30C7\\u30FC\\u30BF\\u306A\\u3057\r\n\r\n#XFLD\r\nTOPIC=\\u30C8\\u30D4\\u30C3\\u30AF\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u30B3\\u30F3\\u30D4\\u30C6\\u30F3\\u30B7\\u30FC\\u30EC\\u30D9\\u30EB\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u6709\\u52B9\\u671F\\u9650\r\n\r\n#XFLD\r\nDATEOFBIRTH=\\u751F\\u5E74\\u6708\\u65E5\r\n\r\n#XFLD\r\nMARITALSTATUS=\\u5A5A\\u59FB\\u72B6\\u6CC1\r\n\r\n#XFLD\r\nMISSING_DAYS=\\u4E0D\\u8DB3\\u65E5\\u6570\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=\\u672A\\u5B8C\\u4E86\\u306E\\u65E5\\u6570\r\n\r\n#XFLD\r\nDAYS=\\u65E5\r\n\r\n#XFLD\r\nHOURS=\\u6642\\u9593\r\n\r\n#XFLD\r\nSINCE=\\u958B\\u59CB\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=\\u7D66\\u4E0E\\u304A\\u3088\\u3073\\u30DC\\u30FC\\u30CA\\u30B9\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u8003\\u8AB2\\u8A55\\u4FA1\r\n\r\n#XFLD\r\nRECORD_TIME=\\u6642\\u9593\\u306E\\u8A18\\u9332\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u4F11\\u6687\\u306E\\u7533\\u8ACB\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u7D66\\u4E0E\\u660E\\u7D30\\u7167\\u4F1A\r\n\r\n#XFLD\r\nLOCATION=\\u30ED\\u30B1\\u30FC\\u30B7\\u30E7\\u30F3\r\n\r\n#XFLD\r\nOFFICE_PHONE=\\u52E4\\u52D9\\u5148\\u306E\\u96FB\\u8A71\r\n\r\n#XFLD\r\nEMAIL=\\u30E1\\u30FC\\u30EB\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u624B\\u53D6\\u7D66\\u4E0E\r\n\r\n#XFLD\r\nSALARY=\\u7D66\\u4E0E\r\n\r\n#XFLD\r\nBONUS=\\u30DC\\u30FC\\u30CA\\u30B9\r\n\r\n#XFLD\r\nYEAR=\\u5E74\r\n\r\n#XFLD\r\nCOMPENSATION=\\u5831\\u916C\r\n\r\n#XFLD\r\nCATEGORY=\\u30AB\\u30C6\\u30B4\\u30EA\r\n\r\n#XFLD\r\nPERIOD=\\u671F\\u9593\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u5F93\\u696D\\u54E1\\u968E\\u5C64\r\n\r\n#XFLD\r\nAS_OF={0} \\u6642\\u70B9 \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=\\u5F93\\u696D\\u54E1\\u5272\\u5F53\\u306E\\u9078\\u629E\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=\\u5F93\\u696D\\u54E1\\u5272\\u5F53\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=\\u5185\\u90E8\\u30A8\\u30E9\\u30FC\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\\u3002\\u30B7\\u30B9\\u30C6\\u30E0\\u7BA1\\u7406\\u8005\\u306B\\u9023\\u7D61\\u3057\\u3066\\u304F\\u3060\\u3055\\u3044\\u3002\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=\\u5185\\u90E8\\u30A8\\u30E9\\u30FC\\u304C\\u767A\\u751F\\u3057\\u307E\\u3057\\u305F\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u4E2D\\u6B62\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=\\u30BF\\u30A4\\u30E0\\u30A4\\u30D9\\u30F3\\u30C8\\u767B\\u9332\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u30BF\\u30A4\\u30E0\\u30D0\\u30E9\\u30F3\\u30B9\r\n',
		"hcm/people/profile/i18n/i18n_no.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Personprofil\r\n\r\n#XTIT: \r\nWHATS_NEW=Nyheter\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Merknader\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Mine personlige merknader\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Personlig informasjon\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Meldinger\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Arbeidstidsskjema og frav\\u00E6r\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Forest\\u00E5ende kurs\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifikasjoner og ferdigheter\r\n\r\n#XTIT: \r\nPERFORMANCE=Prestasjon\r\n\r\n#XTIT: \r\nPROGRESSION=Progresjon\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=L\\u00F8nnsslipp\r\n\r\n#XTIT: \r\nSALARY_BONUS=L\\u00F8nn og tillegg\r\n\r\n#XFLD\r\nTIME_RECORDING=Arbeidstidsregistrering\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Forest\\u00E5ende ferie\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Forest\\u00E5ende frav\\u00E6r\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Ingen tilgjengelige data for de siste {0} m\\u00E5nedene \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Ingen forest\\u00E5ende frav\\u00E6r de neste {0} m\\u00E5nedene\r\n\r\n#XFLD\r\nTIME_NO_DATA=Arbeidstidsregistrering er oppdatert\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Ingen tidssaldoer er tilgjengelige fra {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Ingen tilgjengelige l\\u00F8nnsslipper de siste {0} m\\u00E5nedene \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Ingen tilgjengelige kvalifiseringer de siste {0} m\\u00E5nedene \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Ingen forest\\u00E5ende kurs de neste {0} m\\u00E5nedene\r\n\r\n#XFLD\r\nPERF_NO_DATA=Ingen tilgjengelig prestasjonsvurdering for de siste {0} \\u00E5rene\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Ingen tilgjengelige kompensasjonsdata for de siste {0} \\u00E5rene\r\n\r\n#XFLD\r\nPROG_NO_DATA=Ingen tilgjengelige prosgresjonsdata\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Ingen tilgjengelige meldinger\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Ingen tilgjengelige merknader\r\n\r\n#XFLD\r\nPERS_NO_DATA=Ingen tilgjengelig informasjon\r\n\r\n#XFLD\r\nNO_DATA=Ingen tilgjengelige data\r\n\r\n#XFLD\r\nTOPIC=Emne\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Kompetanseniv\\u00E5\r\n\r\n#XFLD\r\nVALID_UNTIL=Gyldig til\r\n\r\n#XFLD\r\nDATEOFBIRTH=F\\u00F8dselsdato\r\n\r\n#XFLD\r\nMARITALSTATUS=Sivilstand\r\n\r\n#XFLD\r\nMISSING_DAYS=Ikke-registrerte dager\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Ufullstendige dager\r\n\r\n#XFLD\r\nDAYS=Dager\r\n\r\n#XFLD\r\nHOURS=Timer\r\n\r\n#XFLD\r\nSINCE=Siden\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=L\\u00F8nn og tillegg\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Vurdering av medarbeidersamtale\r\n\r\n#XFLD\r\nRECORD_TIME=Registrer tid\r\n\r\n#XFLD\r\nAPPLY_LEAVE=S\\u00F8k om ferie\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Vis l\\u00F8nnsslipp\r\n\r\n#XFLD\r\nLOCATION=Lokalisering\r\n\r\n#XFLD\r\nOFFICE_PHONE=Kontortelefon\r\n\r\n#XFLD\r\nEMAIL=E-post\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Nettol\\u00F8nn\r\n\r\n#XFLD\r\nSALARY=L\\u00F8nn\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=\\u00C5r\r\n\r\n#XFLD\r\nCOMPENSATION=Kompensasjon\r\n\r\n#XFLD\r\nCATEGORY=Kategori\r\n\r\n#XFLD\r\nPERIOD=Periode\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Medarbeiderhierarki\r\n\r\n#XFLD\r\nAS_OF=Fra {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Velg en ansettelseskontrakt\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Ansettelseskontrakter\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=En intern feil har oppst\\u00E5tt. Kontakt systemansvarlig.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Intern feil\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Avbryt\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Opprett tidshendelse\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Tidssaldo\r\n',
		"hcm/people/profile/i18n/i18n_pl.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil os\\u00F3b\r\n\r\n#XTIT: \r\nWHATS_NEW=Co nowego?\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notatki\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Moje osobiste notatki\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Dane osobowe\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Zawiadomienia\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Wprowadzanie czasu i nieobecno\\u015Bci\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Nadchodz\\u0105ce kursy\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kwalifikacje i umiej\\u0119tno\\u015Bci\r\n\r\n#XTIT: \r\nPERFORMANCE=Wydajno\\u015B\\u0107\r\n\r\n#XTIT: \r\nPROGRESSION=Progresja\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Pasek p\\u0142acowy\r\n\r\n#XTIT: \r\nSALARY_BONUS=Wynagrodzenie i premia\r\n\r\n#XFLD\r\nTIME_RECORDING=Rejestracja czasu\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Nadchodz\\u0105cy urlop wypoczynkowy\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Nadchodz\\u0105cy urlop\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Brak danych z ostatnich {0} miesi\\u0119cy \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Brak nadchodz\\u0105cych urlop\\u00F3w w nast\\u0119pnych {0} miesi\\u0105cach\r\n\r\n#XFLD\r\nTIME_NO_DATA=Rejestracja czasu jest aktualna\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Brak sald czasowych od {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Brak pask\\u00F3w p\\u0142acowych z ostatnich {0} miesi\\u0119cy \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Brak kwalifikacji z ostatnich {0} miesi\\u0119cy \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Brak nadchodz\\u0105cych kurs\\u00F3w w nast\\u0119pnych {0} miesi\\u0105cach\r\n\r\n#XFLD\r\nPERF_NO_DATA=Brak oceny efektywno\\u015Bci z ostatnich {0} lat\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Brak danych dotycz\\u0105cych wynagrodzenia z ostatnich {0} lat\r\n\r\n#XFLD\r\nPROG_NO_DATA=Brak danych o post\\u0119pie\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Brak zawiadomie\\u0144\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Brak notatek\r\n\r\n#XFLD\r\nPERS_NO_DATA=Brak informacji\r\n\r\n#XFLD\r\nNO_DATA=Brak danych\r\n\r\n#XFLD\r\nTOPIC=Temat\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Poziom kompetencji\r\n\r\n#XFLD\r\nVALID_UNTIL=Wa\\u017Cny do\r\n\r\n#XFLD\r\nDATEOFBIRTH=Data urodzenia\r\n\r\n#XFLD\r\nMARITALSTATUS=Stan cywilny\r\n\r\n#XFLD\r\nMISSING_DAYS=Brakuj\\u0105ce dni\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Dni niekompletne\r\n\r\n#XFLD\r\nDAYS=Dni\r\n\r\n#XFLD\r\nHOURS=Godziny\r\n\r\n#XFLD\r\nSINCE=Od\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Wynagrodzenie i premia\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Ocena\r\n\r\n#XFLD\r\nRECORD_TIME=Rejestruj czas\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Wnioskuj o urlop\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Wy\\u015Bwietl pasek p\\u0142acowy\r\n\r\n#XFLD\r\nLOCATION=Lokalizacja\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telefon do biura\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Wyp\\u0142ata netto\r\n\r\n#XFLD\r\nSALARY=Wynagrodzenie\r\n\r\n#XFLD\r\nBONUS=Premia\r\n\r\n#XFLD\r\nYEAR=Rok\r\n\r\n#XFLD\r\nCOMPENSATION=Ekwiwalent\r\n\r\n#XFLD\r\nCATEGORY=Kategoria\r\n\r\n#XFLD\r\nPERIOD=Okres\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hierarchia pracownik\\u00F3w\r\n\r\n#XFLD\r\nAS_OF=Od {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Wybierz umow\\u0119 o prac\\u0119\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Umowy o prac\\u0119\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Wyst\\u0105pi\\u0142 b\\u0142\\u0105d wewn\\u0119trzny. Skontaktuj si\\u0119 z administratorem systemu.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=B\\u0142\\u0105d wewn\\u0119trzny\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Anuluj\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Utw\\u00F3rz zdarzenie czasowe\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Saldo czasowe\r\n',
		"hcm/people/profile/i18n/i18n_pt.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Perfil de pessoas\r\n\r\n#XTIT: \r\nWHATS_NEW=O que h\\u00E1 de novo\r\n\r\n#XTIT: \r\nTALENT=Talento\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notas\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Minhas notas pessoais\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Dados pessoais\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notifica\\u00E7\\u00F5es\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Registro de tempos e aus\\u00EAncias\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Pr\\u00F3ximos cursos\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Qualifica\\u00E7\\u00F5es & Compet\\u00EAncias\r\n\r\n#XTIT: \r\nPERFORMANCE=Performance\r\n\r\n#XTIT: \r\nPROGRESSION=Progress\\u00E3o\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Comprovante de remunera\\u00E7\\u00E3o\r\n\r\n#XTIT: \r\nSALARY_BONUS=Sal\\u00E1rio e b\\u00F4nus\r\n\r\n#XFLD\r\nTIME_RECORDING=Registro de tempos\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Pr\\u00F3ximas f\\u00E9rias\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Pr\\u00F3xima aus\\u00EAncia\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Nenhum dado dispon\\u00EDvel para os \\u00FAltimos {0} meses \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Nenhuma aus\\u00EAncia nos pr\\u00F3ximos {0} meses\r\n\r\n#XFLD\r\nTIME_NO_DATA=Registro de tempos \\u00E9 atual\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Nenhum saldo de horas dispon\\u00EDvel a partir de {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Nenhum comprovante de remunera\\u00E7\\u00E3o dispon\\u00EDvel nos \\u00FAltimos {0} meses \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Nenhuma qualifica\\u00E7\\u00E3o dispon\\u00EDvel nos \\u00FAltimos {0} meses \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Nenhum curso nos pr\\u00F3ximos {0} meses\r\n\r\n#XFLD\r\nPERF_NO_DATA=Nenhuma avalia\\u00E7\\u00E3o de desempenho dispon\\u00EDvel para os \\u00FAltimos {0} anos\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Nenhum dado de remunera\\u00E7\\u00E3o para os \\u00FAltimos {0} anos\r\n\r\n#XFLD\r\nPROG_NO_DATA=Nenhum dado de progress\\u00E3o dispon\\u00EDvel\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Nenhuma notifica\\u00E7\\u00E3o dispon\\u00EDvel\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Nenhuma nota dispon\\u00EDvel\r\n\r\n#XFLD\r\nPERS_NO_DATA=Nenhuma informa\\u00E7\\u00E3o dispon\\u00EDvel\r\n\r\n#XFLD\r\nNO_DATA=Nenhum dado dispon\\u00EDvel\r\n\r\n#XFLD\r\nTOPIC=T\\u00F3pico\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=N\\u00EDvel de compet\\u00EAncia\r\n\r\n#XFLD\r\nVALID_UNTIL=V\\u00E1lido at\\u00E9\r\n\r\n#XFLD\r\nDATEOFBIRTH=Data de nascimento\r\n\r\n#XFLD\r\nMARITALSTATUS=Estado civil\r\n\r\n#XFLD\r\nMISSING_DAYS=Dias de falta\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Dias incompletos\r\n\r\n#XFLD\r\nDAYS=Dias\r\n\r\n#XFLD\r\nHOURS=Horas\r\n\r\n#XFLD\r\nSINCE=Desde\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Sal\\u00E1rio e b\\u00F4nus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Classifica\\u00E7\\u00E3o de avalia\\u00E7\\u00E3o\r\n\r\n#XFLD\r\nRECORD_TIME=Registrar tempo\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Solicitar aus\\u00EAncia\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Exibir comprovante de remunera\\u00E7\\u00E3o\r\n\r\n#XFLD\r\nLOCATION=Localiza\\u00E7\\u00E3o\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telefone do escrit\\u00F3rio\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Sal\\u00E1rio l\\u00EDquido\r\n\r\n#XFLD\r\nSALARY=Sal\\u00E1rio\r\n\r\n#XFLD\r\nBONUS=B\\u00F4nus\r\n\r\n#XFLD\r\nYEAR=Ano\r\n\r\n#XFLD\r\nCOMPENSATION=Remunera\\u00E7\\u00E3o\r\n\r\n#XFLD\r\nCATEGORY=Categoria\r\n\r\n#XFLD\r\nPERIOD=Per\\u00EDodo\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hierarquia de funcion\\u00E1rio\r\n\r\n#XFLD\r\nAS_OF=A partir de {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Selecionar um contrato de emprego\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Contratos de emprego\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Ocorreu um erro interno. Contate o administrador do sistema.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Erro interno\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Anular\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Criar evento com registro de hora\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Saldo de horas\r\n',
		"hcm/people/profile/i18n/i18n_ro.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil persoane\r\n\r\n#XTIT: \r\nWHATS_NEW=Nout\\u0103\\u0163i\r\n\r\n#XTIT: \r\nTALENT=Candidat\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Note\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Notele mele personale\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Informa\\u0163ii personale\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Notific\\u0103ri\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Fi\\u015F\\u0103 de timp & absen\\u0163e\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Cursuri \\u00EEn a\\u015Fteptare\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Calific\\u0103ri & competen\\u0163e\r\n\r\n#XTIT: \r\nPERFORMANCE=Performan\\u0163\\u0103\r\n\r\n#XTIT: \r\nPROGRESSION=Dezvoltare carier\\u0103\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Justificativ de salariu\r\n\r\n#XTIT: \r\nSALARY_BONUS=Salariu \\u015Fi prim\\u0103\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u00CEnregistrare timp\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Concediu de odihn\\u0103 \\u00EEn a\\u015Fteptare\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Concediu \\u00EEn a\\u015Fteptare\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Nu sunt disponibile date pt. ultimele {0} luni \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=F\\u0103r\\u0103 concedii \\u00EEn a\\u015Fteptare \\u00EEn urm\\u0103toarele {0} luni\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u00CEnregistrare timp este actualizat\\u0103\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Nu sunt disponibile solduri de timp de la {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Nu sunt disponibile justificative de salariu \\u00EEn ultimele {0} luni \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Nu sunt disponibile calific\\u0103ri \\u00EEn ultimele {0} luni \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=F\\u0103r\\u0103 cursuri \\u00EEn a\\u015Fteptare \\u00EEn urm\\u0103toarele {0} luni\r\n\r\n#XFLD\r\nPERF_NO_DATA=Nicio evaluare de performan\\u0163\\u0103 disponibil\\u0103 pt. ultimii {0} ani\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Nu sunt disponibile date compensa\\u0163ie pt. ultimii {0} ani\r\n\r\n#XFLD\r\nPROG_NO_DATA=Nu sunt disponibile date dezvoltare carier\\u0103\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=F\\u0103r\\u0103 notific\\u0103ri disponibile\r\n\r\n#XFLD\r\nNOTES_NO_DATA=F\\u0103r\\u0103 note disponibile\r\n\r\n#XFLD\r\nPERS_NO_DATA=F\\u0103r\\u0103 informa\\u0163ii disponibile\r\n\r\n#XFLD\r\nNO_DATA=F\\u0103r\\u0103 date disponibile\r\n\r\n#XFLD\r\nTOPIC=Tem\\u0103\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Nivel de competen\\u0163\\u0103\r\n\r\n#XFLD\r\nVALID_UNTIL=Valabil p\\u00E2n\\u0103 la\r\n\r\n#XFLD\r\nDATEOFBIRTH=Dat\\u0103 de na\\u015Ftere\r\n\r\n#XFLD\r\nMARITALSTATUS=Stare civil\\u0103\r\n\r\n#XFLD\r\nMISSING_DAYS=Zile necompletate\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Zile incomplete\r\n\r\n#XFLD\r\nDAYS=Zile\r\n\r\n#XFLD\r\nHOURS=Ore\r\n\r\n#XFLD\r\nSINCE=De la\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Salariu & prim\\u0103\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Clasificare evaluare\r\n\r\n#XFLD\r\nRECORD_TIME=\\u00CEnregistrare timp\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Solicitare concediu\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Afi\\u015Fare justificativ de salariu\r\n\r\n#XFLD\r\nLOCATION=Loc\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telefon birou\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Salariu net\r\n\r\n#XFLD\r\nSALARY=Salariu\r\n\r\n#XFLD\r\nBONUS=Prim\\u0103\r\n\r\n#XFLD\r\nYEAR=An\r\n\r\n#XFLD\r\nCOMPENSATION=Compensa\\u0163ie\r\n\r\n#XFLD\r\nCATEGORY=Categorie\r\n\r\n#XFLD\r\nPERIOD=Perioad\\u0103\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Ierarhie de angaja\\u0163i\r\n\r\n#XFLD\r\nAS_OF=De la {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Alege\\u0163i un contract de munc\\u0103\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Contracte de munc\\u0103\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=A ap\\u0103rut o eroare intern\\u0103. Contacta\\u0163i administratorul dvs.de sistem.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Eroare intern\\u0103\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Anulare\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Creare eveniment de timp\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Sold de timp\r\n',
		"hcm/people/profile/i18n/i18n_ru.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=\\u041F\\u0440\\u043E\\u0444\\u0438\\u043B\\u044C \\u043F\\u0435\\u0440\\u0441\\u043E\\u043D\\u0430\\u043B\\u0430\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u0427\\u0442\\u043E \\u043D\\u043E\\u0432\\u043E\\u0433\\u043E\r\n\r\n#XTIT: \r\nTALENT=\\u0422\\u0430\\u043B\\u0430\\u043D\\u0442\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=\\u041F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u044F\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=\\u041C\\u043E\\u0438 \\u043B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u043F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u044F\r\n\r\n#XTIT: \r\nPERSONAL_INFO=\\u041B\\u0438\\u0447\\u043D\\u044B\\u0435 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0435\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u0423\\u0432\\u0435\\u0434\\u043E\\u043C\\u043B\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=\\u0422\\u0430\\u0431\\u0435\\u043B\\u044C \\u0438 \\u043E\\u0442\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0438\\u044F\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=\\u041F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438\\u0435 \\u043A\\u0443\\u0440\\u0441\\u044B\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=\\u041A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u0438 \\u0438 \\u043D\\u0430\\u0432\\u044B\\u043A\\u0438\r\n\r\n#XTIT: \r\nPERFORMANCE=\\u041F\\u0440\\u043E\\u0438\\u0437\\u0432\\u043E\\u0434\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u043E\\u0441\\u0442\\u044C\r\n\r\n#XTIT: \r\nPROGRESSION=\\u0423\\u0441\\u043F\\u0435\\u0445\\u0438\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u0420\\u0430\\u0441\\u0447\\u0435\\u0442\\u043D\\u044B\\u0439 \\u043B\\u0438\\u0441\\u0442\\u043E\\u043A\r\n\r\n#XTIT: \r\nSALARY_BONUS=\\u0417\\u0430\\u0440\\u043F\\u043B\\u0430\\u0442\\u0430 \\u0438 \\u043D\\u0430\\u0434\\u0431\\u0430\\u0432\\u043A\\u0430\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u0420\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044F \\u0432\\u0440\\u0435\\u043C\\u0435\\u043D\\u0438\r\n\r\n#XFLD\r\nUPCOMING_VACATION=\\u041F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438\\u0439 \\u043E\\u0442\\u043F\\u0443\\u0441\\u043A\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=\\u041F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0435\\u0435 \\u043E\\u0442\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0438\\u0435\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0445 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0435 {0} \\u043C\\u0435\\u0441. \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u041D\\u0435\\u0442 \\u043F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438\\u0445 \\u043E\\u0442\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0438\\u0439 \\u043D\\u0430 \\u0431\\u043B\\u0438\\u0436\\u0430\\u0439\\u0448\\u0438\\u0435 {0} \\u043C\\u0435\\u0441.\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u0420\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044F \\u0432\\u0440\\u0435\\u043C\\u0435\\u043D\\u0438 \\u0430\\u043A\\u0442\\u0443\\u0430\\u043B\\u044C\\u043D\\u0430\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0432\\u0440\\u0435\\u043C\\u0435\\u043D\\u043D\\u044B\\u0445 \\u0441\\u0430\\u043B\\u044C\\u0434\\u043E \\u043D\\u0430 {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0440\\u0430\\u0441\\u0447\\u0435\\u0442\\u043D\\u044B\\u0445 \\u043B\\u0438\\u0441\\u0442\\u043A\\u043E\\u0432 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0435 {0} \\u043C\\u0435\\u0441. \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u043A\\u0432\\u0430\\u043B\\u0438\\u0444\\u0438\\u043A\\u0430\\u0446\\u0438\\u0439 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0435 {0} \\u043C\\u0435\\u0441. \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u041D\\u0435\\u0442 \\u043F\\u0440\\u0435\\u0434\\u0441\\u0442\\u043E\\u044F\\u0449\\u0438\\u0445 \\u043A\\u0443\\u0440\\u0441\\u043E\\u0432 \\u043D\\u0430 \\u0431\\u043B\\u0438\\u0436\\u0430\\u0439\\u0448\\u0438\\u0435 {0} \\u043C\\u0435\\u0441.\r\n\r\n#XFLD\r\nPERF_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0440\\u0435\\u0439\\u0442\\u0438\\u043D\\u0433\\u043E\\u0432 \\u043F\\u0440\\u043E\\u0438\\u0437\\u0432\\u043E\\u0434\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u043E\\u0441\\u0442\\u0438 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0435 {0} \\u0433\\u043E\\u0434\\u0430(\\u043B\\u0435\\u0442)\r\n\r\n#XFLD\r\nCOMP_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0445 \\u043A\\u043E\\u043C\\u043F\\u0435\\u043D\\u0441\\u0430\\u0446\\u0438\\u0438 \\u0437\\u0430 \\u043F\\u043E\\u0441\\u043B\\u0435\\u0434\\u043D\\u0438\\u0435 {0} \\u0433\\u043E\\u0434\\u0430(\\u043B\\u0435\\u0442)\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0445 \\u043F\\u043E \\u0443\\u0441\\u043F\\u0435\\u0445\\u0430\\u043C\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0443\\u0432\\u0435\\u0434\\u043E\\u043C\\u043B\\u0435\\u043D\\u0438\\u0439\r\n\r\n#XFLD\r\nNOTES_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u043F\\u0440\\u0438\\u043C\\u0435\\u0447\\u0430\\u043D\\u0438\\u0439\r\n\r\n#XFLD\r\nPERS_NO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u043E\\u0439 \\u0438\\u043D\\u0444\\u043E\\u0440\\u043C\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD\r\nNO_DATA=\\u041D\\u0435\\u0442 \\u0434\\u043E\\u0441\\u0442\\u0443\\u043F\\u043D\\u044B\\u0445 \\u0434\\u0430\\u043D\\u043D\\u044B\\u0445\r\n\r\n#XFLD\r\nTOPIC=\\u0422\\u0435\\u043C\\u0430\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u0423\\u0440\\u043E\\u0432\\u0435\\u043D\\u044C \\u043A\\u043E\\u043C\\u043F\\u0435\\u0442\\u0435\\u043D\\u0446\\u0438\\u0438\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u0414\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043B\\u044C\\u043D\\u043E \\u043F\\u043E\r\n\r\n#XFLD\r\nDATEOFBIRTH=\\u0414\\u0430\\u0442\\u0430 \\u0440\\u043E\\u0436\\u0434\\u0435\\u043D\\u0438\\u044F\r\n\r\n#XFLD\r\nMARITALSTATUS=\\u0421\\u0435\\u043C\\u0435\\u0439\\u043D\\u043E\\u0435 \\u043F\\u043E\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD\r\nMISSING_DAYS=\\u0414\\u043D\\u0435\\u0439 \\u043E\\u0442\\u0441\\u0443\\u0442\\u0441\\u0442\\u0432\\u0438\\u044F\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=\\u041D\\u0435\\u043F\\u043E\\u043B\\u043D\\u044B\\u0445 \\u0434\\u043D\\u0435\\u0439\r\n\r\n#XFLD\r\nDAYS=\\u0414\\u043D\\u0438\r\n\r\n#XFLD\r\nHOURS=\\u0427\\u0430\\u0441\\u044B\r\n\r\n#XFLD\r\nSINCE=\\u0421\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=\\u0417\\u0430\\u0440\\u043F\\u043B\\u0430\\u0442\\u0430 \\u0438 \\u043D\\u0430\\u0434\\u0431\\u0430\\u0432\\u043A\\u0430\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u041E\\u0446\\u0435\\u043D\\u043A\\u0430 \\u0430\\u0442\\u0442\\u0435\\u0441\\u0442\\u0430\\u0446\\u0438\\u0438\r\n\r\n#XFLD\r\nRECORD_TIME=\\u0412\\u0440\\u0435\\u043C\\u044F \\u0437\\u0430\\u043F\\u0438\\u0441\\u0438\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u041F\\u043E\\u0434\\u0430\\u0442\\u044C \\u0437\\u0430\\u044F\\u0432\\u043A\\u0443\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u041F\\u0440\\u043E\\u0441\\u043C\\u043E\\u0442\\u0440\\u0435\\u0442\\u044C \\u0440\\u0430\\u0441\\u0447\\u0435\\u0442\\u043D\\u044B\\u0439 \\u043B\\u0438\\u0441\\u0442\\u043E\\u043A\r\n\r\n#XFLD\r\nLOCATION=\\u041C\\u0435\\u0441\\u0442\\u043E\\u043F\\u043E\\u043B\\u043E\\u0436\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD\r\nOFFICE_PHONE=\\u0420\\u0430\\u0431\\u043E\\u0447\\u0438\\u0439 \\u0442\\u0435\\u043B\\u0435\\u0444\\u043E\\u043D\r\n\r\n#XFLD\r\nEMAIL=\\u042D\\u043B\\u0435\\u043A\\u0442\\u0440\\u043E\\u043D\\u043D\\u0430\\u044F \\u043F\\u043E\\u0447\\u0442\\u0430\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u0417\\u0430\\u0440\\u043F\\u043B\\u0430\\u0442\\u0430 \\u043C\\u0438\\u043D\\u0443\\u0441 \\u043D\\u0430\\u043B\\u043E\\u0433\\u0438\r\n\r\n#XFLD\r\nSALARY=\\u0417\\u0430\\u0440\\u043F\\u043B\\u0430\\u0442\\u0430\r\n\r\n#XFLD\r\nBONUS=\\u041D\\u0430\\u0434\\u0431\\u0430\\u0432\\u043A\\u0430\r\n\r\n#XFLD\r\nYEAR=\\u0413\\u043E\\u0434\r\n\r\n#XFLD\r\nCOMPENSATION=\\u0412\\u043E\\u0437\\u043D\\u0430\\u0433\\u0440\\u0430\\u0436\\u0434\\u0435\\u043D\\u0438\\u0435\r\n\r\n#XFLD\r\nCATEGORY=\\u041A\\u0430\\u0442\\u0435\\u0433\\u043E\\u0440\\u0438\\u044F\r\n\r\n#XFLD\r\nPERIOD=\\u041F\\u0435\\u0440\\u0438\\u043E\\u0434\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u0418\\u0435\\u0440\\u0430\\u0440\\u0445\\u0438\\u044F \\u0441\\u043E\\u0442\\u0440\\u0443\\u0434\\u043D\\u0438\\u043A\\u043E\\u0432\r\n\r\n#XFLD\r\nAS_OF=\\u041D\\u0430 {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=\\u0412\\u044B\\u0431\\u0440\\u0430\\u0442\\u044C \\u0442\\u0440\\u0443\\u0434\\u043E\\u0432\\u043E\\u0439 \\u0434\\u043E\\u0433\\u043E\\u0432\\u043E\\u0440\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=\\u0422\\u0440\\u0443\\u0434\\u043E\\u0432\\u044B\\u0435 \\u0434\\u043E\\u0433\\u043E\\u0432\\u043E\\u0440\\u044B\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=\\u041F\\u0440\\u043E\\u0438\\u0437\\u043E\\u0448\\u043B\\u0430 \\u0432\\u043D\\u0443\\u0442\\u0440\\u0435\\u043D\\u043D\\u044F\\u044F \\u043E\\u0448\\u0438\\u0431\\u043A\\u0430. \\u041E\\u0431\\u0440\\u0430\\u0442\\u0438\\u0442\\u0435\\u0441\\u044C \\u043A \\u0430\\u0434\\u043C\\u0438\\u043D\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u043E\\u0440\\u0443.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=\\u0412\\u043D\\u0443\\u0442\\u0440\\u0435\\u043D\\u043D\\u044F\\u044F \\u043E\\u0448\\u0438\\u0431\\u043A\\u0430\r\n\r\n#XBUT: Button to accept\r\nOK=\\u041E\\u041A\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u041E\\u0442\\u043C\\u0435\\u043D\\u0438\\u0442\\u044C\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=\\u0421\\u043E\\u0437\\u0434\\u0430\\u0442\\u044C \\u0432\\u0440\\u0435\\u043C\\u0435\\u043D\\u043D\\u043E\\u0435 \\u0441\\u043E\\u0431\\u044B\\u0442\\u0438\\u0435\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u0412\\u0440\\u0435\\u043C\\u0435\\u043D\\u043D\\u043E\\u0435 \\u0441\\u0430\\u043B\\u044C\\u0434\\u043E\r\n',
		"hcm/people/profile/i18n/i18n_sh.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil osobe\r\n\r\n#XTIT: \r\nWHATS_NEW=Novosti\r\n\r\n#XTIT: \r\nTALENT=Talenat\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Bele\\u0161ke\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Moje li\\u010Dne bele\\u0161ke\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Li\\u010Dne informacije\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Obave\\u0161tenja\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Lista radnog vremena & odsustva\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Predstoje\\u0107i kursevi\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifikacije & ve\\u0161tine\r\n\r\n#XTIT: \r\nPERFORMANCE=Produktivnost\r\n\r\n#XTIT: \r\nPROGRESSION=Napredak\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Platni listi\\u0107\r\n\r\n#XTIT: \r\nSALARY_BONUS=Plata i bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Bele\\u017Eenje vremena\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Predstoje\\u0107i godi\\u0161nji odmor\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Predstoje\\u0107e odsustvo\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Podaci nisu dostupni za poslednjih {0} meseci \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Nema predstoje\\u0107eg odsustva u narednih {0} meseci\r\n\r\n#XFLD\r\nTIME_NO_DATA=Bele\\u017Eenje vremena je a\\u017Eurirano\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Vremenski bilansi nisu dostupni od {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Platni listi\\u0107i nisu dostupni za poslednjih {0} meseci \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Kvalifikacije nisu dostupne za poslednjih {0} meseci \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Nema predstoje\\u0107ih kurseva u narednih {0} meseci\r\n\r\n#XFLD\r\nPERF_NO_DATA=Vrednovanje produktivnosti nije dostupno za poslednjih {0} godina\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Podaci kompenzacije nisu dostupni za poslednjih {0} godina\r\n\r\n#XFLD\r\nPROG_NO_DATA=Podaci o napretku nisu dostupni\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Obave\\u0161tenja nisu dostupna\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Bele\\u0161ke nisu dostupne\r\n\r\n#XFLD\r\nPERS_NO_DATA=Informacije nisu dostupne\r\n\r\n#XFLD\r\nNO_DATA=Podaci nisu dostupni\r\n\r\n#XFLD\r\nTOPIC=Tema\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Nivo stru\\u010Dnosti\r\n\r\n#XFLD\r\nVALID_UNTIL=Va\\u017Ee\\u0107e do\r\n\r\n#XFLD\r\nDATEOFBIRTH=Datum ro\\u0111enja\r\n\r\n#XFLD\r\nMARITALSTATUS=Bra\\u010Dno stanje\r\n\r\n#XFLD\r\nMISSING_DAYS=Dani koji nedostaju\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Nepotpuni dani\r\n\r\n#XFLD\r\nDAYS=Dani\r\n\r\n#XFLD\r\nHOURS=Sati\r\n\r\n#XFLD\r\nSINCE=Od\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Plata & bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Vrednovanje ocene\r\n\r\n#XFLD\r\nRECORD_TIME=Zabele\\u017Ei vreme\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Primeni na odsustvo\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Prika\\u017Ei platni listi\\u0107\r\n\r\n#XFLD\r\nLOCATION=Lokacija\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telefon u kancelariji\r\n\r\n#XFLD\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Iznos za isplatu\r\n\r\n#XFLD\r\nSALARY=Plata\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Godina\r\n\r\n#XFLD\r\nCOMPENSATION=Naknada\r\n\r\n#XFLD\r\nCATEGORY=Kategorija\r\n\r\n#XFLD\r\nPERIOD=Period\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hijerarhija zaposlenih\r\n\r\n#XFLD\r\nAS_OF=Od {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Izaberite ugovor o radu\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Ugovori o radu\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Interna gre\\u0161ka. Obavestite sistemskog administratora.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Interna gre\\u0161ka\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Odustani\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Kreiraj vremenski doga\\u0111aj\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Vremenski bilans\r\n',
		"hcm/people/profile/i18n/i18n_sk.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil os\\u00F4b\r\n\r\n#XTIT: \r\nWHATS_NEW=Novinky\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Pozn\\u00E1mky\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Moje osobn\\u00E9 pozn\\u00E1mky\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Osobn\\u00E9 inform\\u00E1cie\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Ozn\\u00E1menia\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Evidencia \\u010Dasu a nepr\\u00EDtomnos\\u0165\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Pripravovan\\u00E9 \\u0161kolenia\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifik\\u00E1cie a zru\\u010Dnosti\r\n\r\n#XTIT: \r\nPERFORMANCE=V\\u00FDkon\r\n\r\n#XTIT: \r\nPROGRESSION=Kari\\u00E9rny postup\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=V\\u00FDplatn\\u00FD l\\u00EDstok\r\n\r\n#XTIT: \r\nSALARY_BONUS=Plat a pr\\u00EDplatok\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u010Casov\\u00E1 evidencia\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Nadch\\u00E1dzaj\\u00FAca dovolenka\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Nadch\\u00E1dzaj\\u00FAce vo\\u013Eno\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne d\\u00E1ta za posledn\\u00FDch {0} mesiacov \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u017Diadne nadch\\u00E1dzaj\\u00FAce dovolenky v nasleduj\\u00FAcich {0} mesiacoch\r\n\r\n#XFLD\r\nTIME_NO_DATA=Evidencia \\u010Dasu je aktu\\u00E1lna\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Od {0} nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne \\u010Dasov\\u00E9 zostatky. \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne v\\u00FDplatn\\u00E9 l\\u00EDstky za posledn\\u00FDch {0} mesiacov \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne kvalifik\\u00E1cie za posledn\\u00FDch {0} mesiacov \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u017Diadne pripravovan\\u00E9 \\u0161kolenia v nasleduj\\u00FAcich {0} mesiacoch\r\n\r\n#XFLD\r\nPERF_NO_DATA=Nie je k dispoz\\u00EDcii \\u017Eiadne hodnotenie v\\u00FDkonu za posledn\\u00FDch {0} rokov\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne d\\u00E1ta odme\\u0148ovania za posledn\\u00FDch {0} mesiacov\r\n\r\n#XFLD\r\nPROG_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne d\\u00E1ta o postupe\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne ozn\\u00E1menia\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne pozn\\u00E1mky\r\n\r\n#XFLD\r\nPERS_NO_DATA=Nie s\\u00FA k dispoz\\u00EDcii \\u017Eiadne inform\\u00E1cie\r\n\r\n#XFLD\r\nNO_DATA=D\\u00E1ta nie s\\u00FA k dispoz\\u00EDcii\r\n\r\n#XFLD\r\nTOPIC=T\\u00E9ma\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u00DArove\\u0148 kompetencie\r\n\r\n#XFLD\r\nVALID_UNTIL=Plat\\u00ED do\r\n\r\n#XFLD\r\nDATEOFBIRTH=D\\u00E1tum narodenia\r\n\r\n#XFLD\r\nMARITALSTATUS=Rodinn\\u00FD stav\r\n\r\n#XFLD\r\nMISSING_DAYS=Ch\\u00FDbaj\\u00FAce dni\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Ne\\u00FApln\\u00E9 dni\r\n\r\n#XFLD\r\nDAYS=Dni\r\n\r\n#XFLD\r\nHOURS=Hodiny\r\n\r\n#XFLD\r\nSINCE=Od\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Plat a pr\\u00EDplatok\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Hodnotenie\r\n\r\n#XFLD\r\nRECORD_TIME=Z\\u00E1znam \\u010Dasu\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u017Diada\\u0165 o dovolenku\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Zobrazi\\u0165 v\\u00FDplatn\\u00FD l\\u00EDstok\r\n\r\n#XFLD\r\nLOCATION=Miesto\r\n\r\n#XFLD\r\nOFFICE_PHONE=Telef\\u00F3n do kancel\\u00E1rie\r\n\r\n#XFLD\r\nEMAIL=E-mail\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u010Ciastka na v\\u00FDplatu\r\n\r\n#XFLD\r\nSALARY=Plat\r\n\r\n#XFLD\r\nBONUS=Pr\\u00EDplatok\r\n\r\n#XFLD\r\nYEAR=Rok\r\n\r\n#XFLD\r\nCOMPENSATION=Odme\\u0148ovanie\r\n\r\n#XFLD\r\nCATEGORY=Kateg\\u00F3ria\r\n\r\n#XFLD\r\nPERIOD=Obdobie\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hierarchia zamestnancov\r\n\r\n#XFLD\r\nAS_OF=Od {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Vyberte pracovn\\u00FA zmluvu\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Pracovn\\u00E9 zmluvy\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Vyskytla sa intern\\u00E1 chyba. Obr\\u00E1\\u0165te sa na spr\\u00E1vcu syst\\u00E9mu.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Intern\\u00E1 chyba\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Zru\\u0161i\\u0165\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Vytvori\\u0165 \\u010Dasov\\u00FA udalos\\u0165\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u010Casov\\u00FD zostatok\r\n',
		"hcm/people/profile/i18n/i18n_sl.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Profil oseb\r\n\r\n#XTIT: \r\nWHATS_NEW=Kaj je novega\r\n\r\n#XTIT: \r\nTALENT=Talent\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Zabele\\u017Eke\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Moje osebne zabele\\u017Eke\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Osebni podatki\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Opozorila\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Evidenca delovnega \\u010Dasa & odsotnosti\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Prihajajo\\u010Di te\\u010Daji\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Kvalifikacije & znanja\r\n\r\n#XTIT: \r\nPERFORMANCE=U\\u010Dinkovitost\r\n\r\n#XTIT: \r\nPROGRESSION=Napredek\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=Pla\\u010Dilni list\r\n\r\n#XTIT: \r\nSALARY_BONUS=Pla\\u010Da in bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Evidentiranje \\u010Dasa\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Prihajajo\\u010Di dopust\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Prihajajo\\u010Di dopust\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Podatki za zadnjih {0} mesecev niso na voljo \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Ni prihajajo\\u010Dih dopustov v naslednjih {0} mesecih\r\n\r\n#XFLD\r\nTIME_NO_DATA=Evidentiranje \\u010Dasa je a\\u017Eurno\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=Uskladitve \\u010Dasa niso na voljo od {0} \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Pla\\u010Dilni listi za zadnjih {0} mesecev niso na voljo \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Kvalifikacije za zadnjih {0} mesecev niso na voljo \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Ni prihajajo\\u010Dih te\\u010Dajve v naslednjih {0} mesecih\r\n\r\n#XFLD\r\nPERF_NO_DATA=Ocena zmogljivosti za zadnjih {0} let ni na voljo\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Podatki o kompenzacijah za zadnjih {0} let niso na voljo\r\n\r\n#XFLD\r\nPROG_NO_DATA=Podatki o napredku niso na voljo\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Sporo\\u010Dila niso na voljo\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Zabele\\u017Eke niso na voljo\r\n\r\n#XFLD\r\nPERS_NO_DATA=Informacije niso na voljo\r\n\r\n#XFLD\r\nNO_DATA=Podatki niso na voljo\r\n\r\n#XFLD\r\nTOPIC=Tema\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Stopnja usposobljenosti\r\n\r\n#XFLD\r\nVALID_UNTIL=Veljavno do\r\n\r\n#XFLD\r\nDATEOFBIRTH=Datum rojstva\r\n\r\n#XFLD\r\nMARITALSTATUS=Zakonski stan\r\n\r\n#XFLD\r\nMISSING_DAYS=Manjkajo\\u010Di dnevi\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Pomanjkljivi dnevi\r\n\r\n#XFLD\r\nDAYS=Dnevi\r\n\r\n#XFLD\r\nHOURS=Ure\r\n\r\n#XFLD\r\nSINCE=Od\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Pla\\u010Da in bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=Vrednotenje ocenitve\r\n\r\n#XFLD\r\nRECORD_TIME=Zapis \\u010Dasa\r\n\r\n#XFLD\r\nAPPLY_LEAVE=Pro\\u0161nja za dopust\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=Ogled pla\\u010Dilnega lista\r\n\r\n#XFLD\r\nLOCATION=Lokacija\r\n\r\n#XFLD\r\nOFFICE_PHONE=Slu\\u017Ebeni telefon\r\n\r\n#XFLD\r\nEMAIL=E-po\\u0161ta\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Neto prejemki\r\n\r\n#XFLD\r\nSALARY=Pla\\u010Da\r\n\r\n#XFLD\r\nBONUS=Bonus\r\n\r\n#XFLD\r\nYEAR=Leto\r\n\r\n#XFLD\r\nCOMPENSATION=Kompenzacija\r\n\r\n#XFLD\r\nCATEGORY=Kategorija\r\n\r\n#XFLD\r\nPERIOD=Obdobje\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=Hierarhija zaposlenih\r\n\r\n#XFLD\r\nAS_OF=Od {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Izberite pogodbo o delu\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Pogodbe o delu\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Pri\\u0161lo je do interne napake. Prosim, obrnite se na svojega administratorja sistema.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Interna napaka\r\n\r\n#XBUT: Button to accept\r\nOK=OK\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=Prekinitev\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Kreiranje \\u010Dasovnega dogodka\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Ukladitev \\u010Dasa\r\n',
		"hcm/people/profile/i18n/i18n_tr.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=Ki\\u015Fi profili\r\n\r\n#XTIT: \r\nWHATS_NEW=Yenilikler\r\n\r\n#XTIT: \r\nTALENT=Yetenek\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=Notlar\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=Personel notlar\\u0131m\r\n\r\n#XTIT: \r\nPERSONAL_INFO=Ki\\u015Fisel bilgiler\r\n\r\n#XTIT: \r\nNOTIFICATIONS=Bildirimler\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=Zaman \\u00E7izelgesi ve devams\\u0131zl\\u0131klar\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=Yakla\\u015Fan kurslar\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=Nitelikler ve yetenekler\r\n\r\n#XTIT: \r\nPERFORMANCE=Performans\r\n\r\n#XTIT: \r\nPROGRESSION=\\u0130lerleme\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u00DCcret pusulas\\u0131\r\n\r\n#XTIT: \r\nSALARY_BONUS=Maa\\u015F ve bonus\r\n\r\n#XFLD\r\nTIME_RECORDING=Zaman kayd\\u0131\r\n\r\n#XFLD\r\nUPCOMING_VACATION=Yakla\\u015Fan tatil\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=Yakla\\u015Fan izin\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=Son {0} ay i\\u00E7in veri yok \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=Gelecek {0} ay i\\u00E7inde yakla\\u015Fan izinler yok\r\n\r\n#XFLD\r\nTIME_NO_DATA=Zaman kayd\\u0131 g\\u00FCncellenecek\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF={0} itibariyle zaman bakiyesi mevcut de\\u011Fil \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=Son {0} ay i\\u00E7inde \\u00FCcret pusulas\\u0131 yok \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=Son {0} ay i\\u00E7inde nitelendirme yok \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=Gelecek {0} ay i\\u00E7inde yakla\\u015Fan kurslar yok\r\n\r\n#XFLD\r\nPERF_NO_DATA=Son {0} y\\u0131l i\\u00E7in performans derecelendirme yok\r\n\r\n#XFLD\r\nCOMP_NO_DATA=Son {0} y\\u0131l i\\u00E7in \\u00F6deme verileri yok\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u0130lerleme verileri mevcut de\\u011Fil\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=Bildirimler mevcut de\\u011Fil\r\n\r\n#XFLD\r\nNOTES_NO_DATA=Notlar mevcut de\\u011Fil\r\n\r\n#XFLD\r\nPERS_NO_DATA=Bilgi mevcut de\\u011Fil\r\n\r\n#XFLD\r\nNO_DATA=Veri mevcut de\\u011Fil\r\n\r\n#XFLD\r\nTOPIC=Ba\\u015Fl\\u0131k\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=Yetkinlik d\\u00FCzeyi\r\n\r\n#XFLD\r\nVALID_UNTIL=Ge\\u00E7erlilik biti\\u015Fi\r\n\r\n#XFLD\r\nDATEOFBIRTH=Do\\u011Fum tarihi\r\n\r\n#XFLD\r\nMARITALSTATUS=Medeni durum\r\n\r\n#XFLD\r\nMISSING_DAYS=Eksik g\\u00FCnler\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=Eksik g\\u00FCnler\r\n\r\n#XFLD\r\nDAYS=G\\u00FCn\r\n\r\n#XFLD\r\nHOURS=Saat\r\n\r\n#XFLD\r\nSINCE=Ba\\u015Flang\\u0131\\u00E7\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=Maa\\u015F ve bonus\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=De\\u011Ferlendirme derecelendirme\r\n\r\n#XFLD\r\nRECORD_TIME=Kay\\u0131t zaman\\u0131\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u0130zin i\\u00E7in onay\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u00DCcret pusulas\\u0131n\\u0131 g\\u00F6r\\u00FCnt\\u00FCle\r\n\r\n#XFLD\r\nLOCATION=Yer\r\n\r\n#XFLD\r\nOFFICE_PHONE=Ofis telefonu\r\n\r\n#XFLD\r\nEMAIL=E-posta\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=Net maa\\u015F\r\n\r\n#XFLD\r\nSALARY=Maa\\u015F\r\n\r\n#XFLD\r\nBONUS=Prim\r\n\r\n#XFLD\r\nYEAR=Y\\u0131l\r\n\r\n#XFLD\r\nCOMPENSATION=Telif edici \\u00F6deme\r\n\r\n#XFLD\r\nCATEGORY=Kategori\r\n\r\n#XFLD\r\nPERIOD=D\\u00F6nem\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u00C7al\\u0131\\u015Fan hiyerar\\u015Fisi\r\n\r\n#XFLD\r\nAS_OF={0} itibariyle \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=Personel tayini se\\u00E7\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=Personel tayinleri\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=Dahili hata ortaya \\u00E7\\u0131kt\\u0131. Sistem y\\u00F6neticinizle irtibata ge\\u00E7in.\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=Dahili hata\r\n\r\n#XBUT: Button to accept\r\nOK=Tamam\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u0130ptal et\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=Zaman olay\\u0131 olu\\u015Ftur\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=Zaman bakiyesi\r\n',
		"hcm/people/profile/i18n/i18n_zh_CN.properties": '# GUID to be created with http://www.famkruithof.net/uuid/uuidgen\r\n\r\n# Note: This file was created according to the conventions that can be found at \r\n# https://wiki.wdf.sap.corp/wiki/display/LeanDI/Lean+DI+Translation+Process\r\n# https://wiki.wdf.sap.corp/wiki/pages/viewpage.action?pageId=1445717842\r\n\r\n#XTIT: \r\nPEOPLE_PROFILE=\\u4EBA\\u5458\\u4E2A\\u4EBA\\u8D44\\u6599\r\n\r\n#XTIT: \r\nWHATS_NEW=\\u65B0\\u589E\\u529F\\u80FD\r\n\r\n#XTIT: \r\nTALENT=\\u4EBA\\u624D\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nNOTES=\\u6CE8\\u91CA\r\n\r\n#XTIT: \r\nMY_PERSONAL_NOTES=\\u6211\\u7684\\u4E2A\\u4EBA\\u6CE8\\u91CA\r\n\r\n#XTIT: \r\nPERSONAL_INFO=\\u4E2A\\u4EBA\\u4FE1\\u606F\r\n\r\n#XTIT: \r\nNOTIFICATIONS=\\u901A\\u77E5\r\n\r\n#XTIT: \r\nTIMESHEET_ABSCENCES=\\u5DE5\\u65F6\\u8868\\u548C\\u7F3A\\u52E4\\u4FE1\\u606F\r\n\r\n#XTIT: \r\nUPCOMING_COURSES=\\u5373\\u5C06\\u53C2\\u52A0\\u7684\\u8BFE\\u7A0B\r\n\r\n#XTIT: \r\nQUALIFICATIONS_SKILLS=\\u8D44\\u683C\\u548C\\u6280\\u80FD\r\n\r\n#XTIT: \r\nPERFORMANCE=\\u7EE9\\u6548\r\n\r\n#XTIT: \r\nPROGRESSION=\\u7D2F\\u8FDB\r\n\r\n#XTIT: \r\nCOMPENSATION=Compensation\r\n\r\n#XTIT: \r\nPAYSLIP=\\u5DE5\\u8D44\\u5355\r\n\r\n#XTIT: \r\nSALARY_BONUS=\\u5DE5\\u8D44\\u548C\\u5956\\u91D1\r\n\r\n#XFLD\r\nTIME_RECORDING=\\u65F6\\u95F4\\u8BB0\\u5F55\r\n\r\n#XFLD\r\nUPCOMING_VACATION=\\u5373\\u5C06\\u5230\\u6765\\u7684\\u5047\\u671F\r\n\r\n#XFLD\r\nUPCOMING_LEAVE=\\u672A\\u6765\\u4F11\\u5047\r\n\r\n#XFLD\r\nNO_DATA_AVAILABLE=\\u8FC7\\u53BB {0} \\u4E2A\\u6708\\u65E0\\u53EF\\u7528\\u6570\\u636E \r\n\r\n#XFLD\r\nLEAVES_NO_DATA=\\u672A\\u6765 {0} \\u4E2A\\u6708\\u65E0\\u4F11\\u5047\r\n\r\n#XFLD\r\nTIME_NO_DATA=\\u65F6\\u95F4\\u8BB0\\u5F55\\u662F\\u6700\\u65B0\\u72B6\\u6001\r\n\r\n#XFLD\r\nTIME_BAL_NO_DATA_ASOF=\\u81EA {0} \\u8D77\\u65E0\\u5269\\u4F59\\u4F11\\u5047\\u65F6\\u95F4 \r\n\r\n#XFLD\r\nPAYSLIP_NO_DATA=\\u8FC7\\u53BB {0} \\u4E2A\\u6708\\u65E0\\u53EF\\u7528\\u5DE5\\u8D44\\u5355 \r\n\r\n#XFLD\r\nQUALIF_NO_DATA=\\u8FC7\\u53BB {0} \\u4E2A\\u6708\\u65E0\\u53EF\\u7528\\u8D44\\u683C \r\n\r\n#XFLD\r\nCOURSES_NO_DATA=\\u672A\\u6765 {0} \\u4E2A\\u6708\\u65E0\\u8BFE\\u7A0B\r\n\r\n#XFLD\r\nPERF_NO_DATA=\\u8FC7\\u53BB {0} \\u5E74\\u65E0\\u53EF\\u7528\\u7EE9\\u6548\\u8BC4\\u4F30\r\n\r\n#XFLD\r\nCOMP_NO_DATA=\\u8FC7\\u53BB {0} \\u4E2A\\u6708\\u65E0\\u53EF\\u7528\\u85AA\\u916C\\u6570\\u636E\r\n\r\n#XFLD\r\nPROG_NO_DATA=\\u65E0\\u804C\\u4E1A\\u53D1\\u5C55\\u6570\\u636E\r\n\r\n#XFLD\r\nNOTIF_NO_DATA=\\u65E0\\u53EF\\u7528\\u901A\\u77E5\r\n\r\n#XFLD\r\nNOTES_NO_DATA=\\u65E0\\u53EF\\u7528\\u6CE8\\u91CA\r\n\r\n#XFLD\r\nPERS_NO_DATA=\\u65E0\\u53EF\\u7528\\u4FE1\\u606F\r\n\r\n#XFLD\r\nNO_DATA=\\u65E0\\u53EF\\u7528\\u6570\\u636E\r\n\r\n#XFLD\r\nTOPIC=\\u4E3B\\u9898\r\n\r\n#XFLD\r\nCOMPETENCY_LEVEL=\\u80FD\\u529B\\u6C34\\u5E73\r\n\r\n#XFLD\r\nVALID_UNTIL=\\u6709\\u6548\\u671F\\u81F3\r\n\r\n#XFLD\r\nDATEOFBIRTH=\\u51FA\\u751F\\u65E5\\u671F\r\n\r\n#XFLD\r\nMARITALSTATUS=\\u5A5A\\u59FB\\u72B6\\u51B5\r\n\r\n#XFLD\r\nMISSING_DAYS=\\u7F3A\\u5C11\\u5929\\u6570\r\n\r\n#XFLD\r\nINCOMPLETE_DAYS=\\u4E0D\\u5B8C\\u6574\\u7684\\u5929\\u6570\r\n\r\n#XFLD\r\nDAYS=\\u5929\r\n\r\n#XFLD\r\nHOURS=\\u5C0F\\u65F6\r\n\r\n#XFLD\r\nSINCE=\\u81EA\r\n\r\n#XFLD\r\nSALARY_AND_BONUS=\\u5DE5\\u8D44\\u548C\\u5956\\u91D1\r\n\r\n#XFLD\r\nAPPRAISAL_RATING=\\u8BC4\\u4F30\\u7B49\\u7EA7\r\n\r\n#XFLD\r\nRECORD_TIME=\\u8BB0\\u5F55\\u65F6\\u95F4\r\n\r\n#XFLD\r\nAPPLY_LEAVE=\\u7533\\u8BF7\\u4F11\\u5047\r\n\r\n#XFLD\r\nVIEW_PAYSLIP=\\u67E5\\u770B\\u5DE5\\u8D44\\u5355\r\n\r\n#XFLD\r\nLOCATION=\\u5730\\u70B9\r\n\r\n#XFLD\r\nOFFICE_PHONE=\\u529E\\u516C\\u7535\\u8BDD\r\n\r\n#XFLD\r\nEMAIL=\\u7535\\u5B50\\u90AE\\u4EF6\r\n\r\n#XFLD\r\nTAKE_HOME_PAY=\\u5B9E\\u5F97\\u5DE5\\u8D44\r\n\r\n#XFLD\r\nSALARY=\\u5DE5\\u8D44\r\n\r\n#XFLD\r\nBONUS=\\u5956\\u91D1\r\n\r\n#XFLD\r\nYEAR=\\u5E74\r\n\r\n#XFLD\r\nCOMPENSATION=\\u85AA\\u916C\r\n\r\n#XFLD\r\nCATEGORY=\\u7C7B\\u522B\r\n\r\n#XFLD\r\nPERIOD=\\u671F\\u95F4\r\n\r\n#XFLD\r\nEMPLOYEE_HIERARCHY=\\u5458\\u5DE5\\u5C42\\u6B21\\u7ED3\\u6784\r\n\r\n#XFLD\r\nAS_OF=\\u81EA {0} \r\n\r\n#XFLD: Select Personnel Assignment Label\r\nPERSONAL_ASSIGN=\\u9009\\u62E9\\u4EBA\\u4E8B\\u5206\\u914D\r\n\r\n#XTIT: Select Personnel Assignment Title\r\nPERSONAL_ASSIGN_TITLE=\\u4EBA\\u4E8B\\u5206\\u914D\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR_BODY=\\u53D1\\u751F\\u5185\\u90E8\\u9519\\u8BEF\\u3002\\u8BF7\\u8054\\u7CFB\\u7CFB\\u7EDF\\u7BA1\\u7406\\u5458\\u3002\r\n\r\n#YMSE: Generic Error Message\r\nINTERNAL_ERROR=\\u5185\\u90E8\\u9519\\u8BEF\r\n\r\n#XBUT: Button to accept\r\nOK=\\u786E\\u5B9A\r\n\r\n#XBUT: Button to cancel\r\nCANCEL=\\u53D6\\u6D88\r\n\r\n#XTIT: record time events\r\nCREATE_TIME_EVENT=\\u521B\\u5EFA\\u65F6\\u95F4\\u4E8B\\u4EF6\r\n\r\n#XTIT: Time events\r\nTIME_BALANCE_HEADER=\\u65F6\\u95F4\\u4F59\\u989D\r\n',
		"hcm/people/profile/util/ConcurrentEmployment.js": function() {
			jQuery.sap.declare("hcm.people.profile.util.ConcurrentEmployment");
			hcm.people.profile.util.ConcurrentEmployment = {
				getCEEnablement: function(s, a) {
					this.initialize(s, a);
					var m = new sap.ui.model.json.JSONModel();
					this.getPersonellAssignments(s, function(d) {
						if (d.length > 1) {
							m.setData(d);
							s.oCEForm.setModel(m);
							s.oCEDialog.open();
						} else {
							s.oApplication.pernr = d[0].Pernr;
							a();
						}
					});
				},
				initialize: function(s, a) {
					var i = new sap.m.RadioButton({
						text: "{AssignmentText}",
						customData: new sap.ui.core.CustomData({
							"key": "Pernr",
							"value": "{Pernr}"
						})
					});
					s.oCESelect = new sap.m.RadioButtonGroup().bindAggregation("buttons", "/", i);
					s.oCEForm = new sap.ui.layout.form.Form({
						maxContainerCols: 2,
						class: "sapUiLargeMarginTopBottom",
						layout: new sap.ui.layout.form.ResponsiveGridLayout({
							labelSpanL: 12,
							labelSpanM: 12,
							labelSpanS: 12,
							columnsL: 2,
							columnsM: 2
						}),
						formContainers: new sap.ui.layout.form.FormContainer({
							formElements: [new sap.ui.layout.form.FormElement({
								label: new sap.m.Label({
									text: s.resourseBundle.getText("PERSONAL_ASSIGN")
								}),
								fields: s.oCESelect
							})]
						})
					});
					s.oCEDialog = new sap.m.Dialog({
						title: s.resourseBundle.getText("PERSONAL_ASSIGN_TITLE"),
						class: "sapUiContentPadding sapUiLargeMarginTopBottom",
						content: s.oCEForm,
						buttons: [new sap.m.Button({
							text: s.resourseBundle.getText("OK"),
							press: function() {
								s.oCEDialog.close();
								s.oApplication.pernr = s.oCESelect.getSelectedButton().data().Pernr;
								a();
							}
						}), new sap.m.Button({
							text: s.resourseBundle.getText("CANCEL"),
							press: function() {
								s.oCEDialog.close();
								s.oCEDialog.Cancelled = true;
								window.history.go(-1);
							}
						})]
					});
					s.oCEDialog.attachAfterClose(function() {
						if (!s.oApplication.pernr && s.oCEDialog.Cancelled !== true) {
							s.oCEDialog.open();
						}
					});
				},
				getPersonellAssignments: function(s, S) {
					var t = this;
					s.oDataModel.read("/ConcurrentEmploymentSet", null, [], true, function(d) {
						S(d.results);
					}, function(e) {
						t.processError(e);
					});
				},
				processError: function(E) {
					var m = "";
					var a = "";
					if (E.response) {
						var b = E.response.body;
						try {
							b = JSON.parse(b);
							if (b.error.innererror && b.error.innererror.errordetails) {
								var c = b.error.innererror.errordetails;
								for (var i = 0; i < c.length; i++) {
									a += c[i].code + " : " + c[i].message + "\n";
								}
							}
							if (a === "") {
								a = b.error.code + " : " + b.error.message.value;
							}
							m = b.error.message.value;
						} catch (e) {
							jQuery.sap.log.warning("Could parse the response", ["parseError"], ["hcm.people.profile"]);
						}
					}
					if (m === "") {
						m = this.resourseBundle.getText("INTERNAL_ERROR");
					}
					if (a === "") {
						a = this.resourseBundle.getText("INTERNAL_ERROR_BODY");
					}
					var M = {
						message: m,
						details: a,
						type: sap.ca.ui.message.Type.ERROR
					};
					sap.ca.ui.utils.busydialog.releaseBusyDialog();
					sap.ca.ui.message.showMessageBox({
						type: M.type,
						message: M.message,
						details: M.details
					});
				}
			};
		},
		"hcm/people/profile/util/UIHelper.js": function() {
			jQuery.sap.declare("hcm.people.profile.util.UIHelper");
			jQuery.sap.require("sap.ca.ui.model.format.NumberFormat");
			hcm.people.profile.util.UIHelper = (function() {
				var _ = null;
				var c = null;
				var d = null;
				var e = null;
				var f = null;
				var g = null;
				var h = null;
				var i = null;
				var j = null;
				var k = null;
				var l = null;
				var m = null;
				var n = null;
				var o = null;
				var p = null;
				var q = null;
				var r = null;
				var s = null;
				var t = null;
				var u = null;
				return {
					setNotifODataModel: function(a) {
						_ = a;
					},
					getNotifODataModel: function() {
						return _;
					},
					setODataModel: function(D) {
						c = D;
					},
					getODataModel: function() {
						return c;
					},
					setResourceBundle: function(a) {
						d = a;
					},
					getResourceBundle: function() {
						return d;
					},
					setConfiguration: function(a) {
						e = a;
					},
					getConfiguration: function() {
						return e;
					},
					setPernr: function(a) {
						f = a;
					},
					getPernr: function() {
						return f;
					},
					cachePersData: function(P) {
						u = P;
					},
					getCachedPersData: function() {
						return u;
					},
					setPersonalizerInstance: function(a) {
						t = a;
					},
					getPersonalizerInstance: function() {
						return t;
					},
					setControllerInstance: function(a) {
						s = a;
					},
					getControllerInstance: function() {
						return s;
					},
					setSubSecPersInfo: function(a) {
						g = a;
					},
					getSubSecPersInfo: function() {
						return g;
					},
					setSubSecCourses: function(a) {
						i = a;
					},
					getSubSecCourses: function() {
						return i;
					},
					setDataCourses: function(a) {
						j = a;
					},
					getDataCourses: function() {
						return j;
					},
					setSubSecPayslip: function(a) {
						k = a;
					},
					getSubSecPayslip: function() {
						return k;
					},
					setDataPayslip: function(a) {
						l = a;
					},
					getDataPayslip: function() {
						return l;
					},
					setSubSecQualif: function(a) {
						m = a;
					},
					getSubSecQualif: function() {
						return m;
					},
					setDataQualif: function(a) {
						n = a;
					},
					getDataQualif: function() {
						return n;
					},
					setSubSecPerf: function(a) {
						o = a;
					},
					getSubSecPerf: function() {
						return o;
					},
					setDataPerf: function(a) {
						p = a;
					},
					getDataPerf: function() {
						return p;
					},
					setSubSecNotf: function(a) {
						q = a;
					},
					getSubSecNotf: function() {
						return q;
					},
					setDataNotf: function(a) {
						r = a;
					},
					getDataNotf: function() {
						return r;
					},
					setSecPersInfo: function(a) {
						h = a;
					},
					getSecPersInfo: function() {
						return h;
					},
					formatDate: function(D, a) {
						var b = sap.ca.ui.model.format.DateFormat.getDateInstance({
							style: "medium"
						});
						if (D !== null && D !== undefined) {
							if (a !== undefined) {
								return b.format(D, a);
							} else {
								return b.format(D, true);
							}
						}
					},
					formatTime: function(D, a) {
						var b = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
							style: "medium"
						});
						if (D !== null && D !== undefined) {
							if (a !== undefined) {
								return b.format(D, a);
							} else {
								return b.format(D, true);
							}
						}
					},
					formatNumber: function(v) {
						var a = sap.ca.ui.model.format.NumberFormat.getInstance();
						return a.format(v);
					},
					sortArrayByProperty: function(v, w) {
						function x(y) {
							var z = 1;
							if (y[0] === "-") {
								z = -1;
								y = y.substr(1);
							}
							return function(a, b) {
								var A = (a[y] < b[y]) ? -1 : (a[y] > b[y]) ? 1 : 0;
								return A * z;
							};
						}
						return v.sort(x(w));
					},
					buildTimePeriod: function(b, a, v) {
						var w = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
							pattern: "MMM",
							style: "medium"
						});
						var x = b.getFullYear();
						var y = b.getMonth();
						var z = w.format(b);
						var A = b.getDate();
						var B = a.getFullYear();
						var C = a.getMonth();
						var D = w.format(a);
						var E = a.getDate();
						var F = new Date(a);
						F.setDate(a.getDate() + 1);
						var G = F.getMonth();
						var H = F.getDate();
						if (v) {
							if ((A === E) && (y === C) && (x === B)) {
								A = "";
								y = "";
								x = "";
								C = D;
							} else if ((y === C) && (x === B)) {
								y = "";
								x = "";
								C = D;
							} else if ((x === B)) {
								x = "";
								y = z;
								C = D;
							} else {
								y = z;
								C = D;
							}
						} else {
							if (x === B) {
								x = "";
							}
							if ((y === G) && (A === H)) {
								y = "";
								C = "";
								A = "";
								E = "";
							} else {
								y = z;
								C = D;
							} if (A === H) {
								A = "";
								E = "";
							}
						}
						var I = A + " " + y + " " + x;
						var J = E + " " + C + " " + B;
						var K = false;
						if ((A !== "") && (y !== "") && (x !== "")) {
							K = true;
						}
						var L = false;
						if ((E !== "") && (C !== "") && (B !== "")) {
							L = true;
						}
						if (K && L) {
							I = this.formatDate(b);
							J = this.formatDate(a);
						}
						if (I.trim() !== "") {
							I = I + " - ";
						} else if (v) {
							J = this.formatDate(a);
						}
						return I + J;
					}
				};
			}());
		},
		"hcm/people/profile/view/Profile.controller.js": function() {
			jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
			jQuery.sap.require("hcm.people.profile.util.UIHelper");
			jQuery.sap.require("hcm.people.profile.blocks.Notifications");
			jQuery.sap.require("hcm.people.profile.blocks.TimeRecording");
			jQuery.sap.require("hcm.people.profile.blocks.Vacations");
			jQuery.sap.require("hcm.people.profile.blocks.Cources");
			jQuery.sap.require("hcm.people.profile.blocks.Qualifications");
			jQuery.sap.require("hcm.people.profile.blocks.Performance");
			jQuery.sap.require("hcm.people.profile.blocks.Progression");
			jQuery.sap.require("hcm.people.profile.blocks.Payslip");
			jQuery.sap.require("hcm.people.profile.blocks.Salary");
			jQuery.sap.require("hcm.people.profile.blocks.Notes");
			jQuery.sap.require("hcm.people.profile.blocks.PersInfo");
			jQuery.sap.require("hcm.people.profile.util.ConcurrentEmployment");
			jQuery.sap.require("hcm.people.profile.blocks.TimeBalance");
			sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.people.profile.view.Profile", {
				onInit: function() {
					this.oDataModel = this.oApplicationFacade.getODataModel();
					hcm.people.profile.util.UIHelper.setODataModel(this.oDataModel);
					this.notifODataModel = this.oApplicationFacade.getODataModel("NOTIFICATIONSTORE");
					hcm.people.profile.util.UIHelper.setNotifODataModel(this.notifODataModel);
					hcm.people.profile.util.UIHelper.setControllerInstance(this);
					this.resourseBundle = this.oApplicationFacade.getResourceBundle();
					hcm.people.profile.util.UIHelper.setResourceBundle(this.resourseBundle);
					this.oApplication = this.oApplicationFacade.oApplicationImplementation;
					this.ctrlObjectPageLayout = this.byId("ctrlObjectPageLayout");
					this.ctrlObjHeaderEmp = this.byId("ctlrObjHeaderEmp");
					this.pernr = null;
					this.extHookSections = null;
				},
				initializeView: function() {
					var t = this;
					var c = $.when(this.getEmployeeDataSet(), this.getConfigurationSet());
					c.done(function(o, a) {
						t.buildHeaderUI(o);
						t.buildByConfiguration(a);
					});
					c.fail(function(e) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + e.toString());
					});
					var i = this.byId("ctrlHeaderImage").getId();
					$("#" + i).css("border-radius", "100%");
				},
				onBeforeRendering: function() {},
				getEmployeeDataSet: function() {
					var d = $.Deferred();
					this.oDataModel.read("EmployeeDataSet('" + this.oApplication.pernr + "')", null, null, true, function(r) {
						d.resolve(r);
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
						d.reject("Data fetch failed" + r.toString());
					});
					return d.promise();
				},
				getConfigurationSet: function() {
					var d = $.Deferred();
					this.oDataModel.read("ConfigurationSet('" + this.oApplication.pernr + "')", null, null, true, function(r) {
						d.resolve(r);
					}, function(r) {
						jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
						d.reject("Data fetch failed" + r.toString());
					});
					return d.promise();
				},
				buildHeaderUI: function(o) {
					var t = this;
					t.pernr = o.Employeenumber;
					hcm.people.profile.util.UIHelper.setPernr(t.pernr);
					var i = this.oDataModel.sServiceUrl + "/EmployeeDataSet('" + t.pernr + "')/$value";
					var c = t.byId("ctrlHeaderImage");
					t.ctrlObjHeaderEmp.setObjectImageURI(i);
					c.setSrc(i);
					c.addStyleClass("sapHcmObjectHeaderImage");
					if (sap.ui.Device.system.desktop) {
						c.setWidth("10rem");
						c.setHeight("10rem");
					} else if (sap.ui.Device.system.tablet) {
						c.setWidth("8rem");
						c.setHeight("8rem");
					} else if (sap.ui.Device.system.phone) {
						c.setWidth("6rem");
						c.setHeight("6rem");
					} else {
						c.setWidth("10rem");
						c.setHeight("10rem");
					}
					t.ctrlObjHeaderEmp.setObjectTitle(o.Ename);
					t.ctrlObjHeaderEmp.setObjectSubtitle(o.PositionTxt);
					if (o.Ename) {
						t.byId("lblName").setTitle(o.Ename);
						t.byId("lblName").addStyleClass("sapHcmHeaderTitle");
					} else {
						t.byId("lblName").setVisible(false);
					} if (o.Employeenumber) {
						t.byId("lblEmpNo").setText(o.Employeenumber);
					} else {
						t.byId("lblEmpNo").setVisible(false);
					} if (o.PositionTxt) {
						t.byId("lblPosition").setText(o.PositionTxt);
					} else {
						t.byId("lblPosition").setVisible(false);
					} if (o.OrgunitTxt) {
						t.byId("lblOrgUnit").setText(o.OrgunitTxt);
					} else {
						t.byId("lblOrgUnit").setVisible(false);
					} if (o.BldingNo.trim() === "" && o.RoomNo.trim() === "") {
						t.byId("lblLocation").setVisible(false);
					} else {
						var s = null;
						if (o.BldingNo.trim() !== "" && o.RoomNo.trim() !== "") {
							s = ", ";
						} else {
							s = "";
						}
						t.byId("lblLocation").setText(o.RoomNo + s + o.BldingNo);
					} if (o.Phone) {
						var a = o.Phone;
						a = o.Phone.replace("/", "-");
						t.byId("lblPhone").setText(a);
						t.empPhone = o.Phone;
					} else {
						t.byId("lblPhone").setVisible(false);
					} if (o.Email) {
						t.byId("lblEmail").setText(o.Email);
						t.empEmail = o.Email;
					} else {
						t.byId("lblEmail").setVisible(false);
					} if (o.City.trim() === "" && o.Country.trim() === "") {
						t.byId("lblCountryLocation").setVisible(false);
					} else {
						var b = null;
						if (o.City.trim() !== "" && o.Country.trim() !== "") {
							b = ", ";
						} else {
							b = "";
						}
						t.byId("lblCountryLocation").setText(o.City + b + o.Country);
					} if (o.Localtime) {
						var d = sap.ca.ui.model.format.DateFormat.getDateTimeInstance({
							pattern: "EEEE, d MMMM, h:mm a",
							style: "medium"
						});
						t.byId("lblTime").setText(d.format(o.Localtime));
					} else {
						t.byId("lblTime").setVisible(false);
					}
				},
				onEmailClick: function(e) {
					sap.m.URLHelper.triggerEmail(this.empEmail);
				},
				onPhoneClick: function(e) {
					sap.m.URLHelper.triggerTel(this.empPhone);
				},
				onBackPress: function(e) {
					window.history.go(-1);
				},
				onHierarchyPress: function() {
					var p = hcm.people.profile.util.UIHelper.getCachedPersData();
					p.crossAppNavFlag = true;
					this.oPersonalizer.setPersData(p);
					hcm.people.profile.util.UIHelper.cachePersData(p);
					sap.ushell.Container.getService("CrossApplicationNavigation").toExternal({
						target: {
							shellHash: "#Organization-lookup&/hierarchy/" + this.pernr
						}
					});
				},
				buildByConfiguration: function(c) {
					var t = this;
					hcm.people.profile.util.UIHelper.setConfiguration(c);
					if (c.ShowNotifications === "X" || c.ShowTimerecording === "X" || c.ShowVacation === "X") {
						var s = new sap.uxap.ObjectPageSection({
							title: t.resourseBundle.getText("WHATS_NEW")
						});
						if (c.ShowNotifications === "X") {
							var S = new sap.uxap.ObjectPageSubSection({
								title: t.resourseBundle.getText("NOTIFICATIONS")
							});
							S.insertBlock(new hcm.people.profile.blocks.Notifications());
							hcm.people.profile.util.UIHelper.setSubSecNotf(S);
							s.addSubSection(S);
						}
						if (c.ShowTimerecording === "X" || c.ShowVacation === "X" || c.ShowTimeBalance === "X") {
							var o = new sap.uxap.ObjectPageSubSection({
								title: t.resourseBundle.getText("TIMESHEET_ABSCENCES")
							});
							if (c.ShowTimerecording === "X") {
								o.insertBlock(new hcm.people.profile.blocks.TimeRecording(), 0);
							}
							if (c.ShowVacation === "X") {
								o.insertBlock(new hcm.people.profile.blocks.Vacations(), 1);
							}
							if (c.ShowTimeBalance === "X") {
								o.insertBlock(new hcm.people.profile.blocks.TimeBalance(), 2);
							}
							s.addSubSection(o);
						}
						t.ctrlObjectPageLayout.addSection(s);
					}
					if (c.ShowSocialMediaInfo === "X") {
						t.oDataModel.read("EmployeeDataSet('" + t.pernr + "')/SocialMediaSet", null, null, true, function(r) {
							var n = t.byId("ctrlSocialMediaHolder");
							r.results.forEach(function(p) {
								n.addContent(new sap.m.Image({
									width: "21px",
									height: "21px",
									src: p.ImageUrl
								}));
							});
						}, function(r) {
							jQuery.sap.log.getLogger().error("Data fetch failed" + r.toString());
						});
					}
					if (c.ShowCourse === "X" || c.ShowQualification === "X" || c.ShowPerformance === "X" || c.ShowProgression === "X") {
						var a = new sap.uxap.ObjectPageSection({
							title: t.resourseBundle.getText("TALENT")
						});
						if (c.ShowCourse === "X") {
							var b = new sap.uxap.ObjectPageSubSection({
								title: t.resourseBundle.getText("UPCOMING_COURSES"),
								mode: "Collapsed",
								showSubSectionMore: true
							});
							hcm.people.profile.util.UIHelper.setSubSecCourses(b);
							b.insertBlock(new hcm.people.profile.blocks.Cources());
							a.addSubSection(b);
						}
						if (c.ShowQualification === "X") {
							var d = new sap.uxap.ObjectPageSubSection({
								title: t.resourseBundle.getText("QUALIFICATIONS_SKILLS")
							});
							hcm.people.profile.util.UIHelper.setSubSecQualif(d);
							d.insertBlock(new hcm.people.profile.blocks.Qualifications());
							a.addSubSection(d);
						}
						if (c.ShowPerformance === "X") {
							var e = new sap.uxap.ObjectPageSubSection({
								title: t.resourseBundle.getText("PERFORMANCE")
							});
							e.insertBlock(new hcm.people.profile.blocks.Performance());
							hcm.people.profile.util.UIHelper.setSubSecPerf(e);
							a.addSubSection(e);
						}
						if (c.ShowProgression === "X") {
							var f = new sap.uxap.ObjectPageSubSection({
								title: t.resourseBundle.getText("PROGRESSION")
							});
							f.insertBlock(new hcm.people.profile.blocks.Progression());
							a.addSubSection(f);
						}
						t.ctrlObjectPageLayout.addSection(a);
					}
					if (c.ShowCompensation === "X") {
						var g = new sap.uxap.ObjectPageSection({
							title: t.resourseBundle.getText("COMPENSATION")
						});
						var h = new sap.uxap.ObjectPageSubSection({
							title: t.resourseBundle.getText("PAYSLIP")
						});
						hcm.people.profile.util.UIHelper.setSubSecPayslip(h);
						h.insertBlock(new hcm.people.profile.blocks.Payslip());
						g.addSubSection(h);
						var i = new sap.uxap.ObjectPageSubSection({
							title: t.resourseBundle.getText("SALARY_BONUS")
						});
						i.insertBlock(new hcm.people.profile.blocks.Salary());
						g.addSubSection(i);
						t.ctrlObjectPageLayout.addSection(g);
					}
					if (c.ShowNotes === "X") {
						var j = new sap.uxap.ObjectPageSection({
							title: t.resourseBundle.getText("NOTES")
						});
						var k = new sap.uxap.ObjectPageSubSection({
							title: t.resourseBundle.getText("MY_PERSONAL_NOTES")
						});
						k.insertBlock(new hcm.people.profile.blocks.Notes());
						j.addSubSection(k);
						t.ctrlObjectPageLayout.addSection(j);
					}
					if (c.ShowPersonalinfo === "X") {
						var l = new sap.uxap.ObjectPageSection({
							title: t.resourseBundle.getText("PERSONAL_INFO")
						});
						hcm.people.profile.util.UIHelper.setSecPersInfo(l);
						var m = new sap.uxap.ObjectPageSubSection({
							id: "subSecPersInfo",
							title: ""
						});
						hcm.people.profile.util.UIHelper.setSubSecPersInfo(m);
						m.insertBlock(new hcm.people.profile.blocks.PersInfo());
						l.addSubSection(m);
						t.ctrlObjectPageLayout.addSection(l);
					}
					if (t.extHookSections) {
						t.ctrlObjectPageLayout = this.extHookSections(t.ctrlObjectPageLayout);
					}
				},
				onAfterRendering: function() {
					this.createPersonalizationObj();
					this.getPersonalizationData(this.oPersId);
				},
				getPersonalizationData: function(i) {
					this.oPersonalizer.getPersData().done(this.userPersData.bind(this)).fail(function() {
						jQuery.sap.log.error("Reading personalization data failed.");
					});
				},
				userPersData: function(p) {
					if (p === undefined || p.crossAppNavFlag === false) {
						if (!this.oApplication.pernr) {
							hcm.people.profile.util.ConcurrentEmployment.getCEEnablement(this, jQuery.proxy(function() {
								var d = {
									selectedCEPernr: this.oApplication.pernr,
									crossAppNavFlag: false
								};
								this.oPersonalizer.setPersData(d);
								hcm.people.profile.util.UIHelper.cachePersData(d);
								this.initializeView();
							}, this));
						}
					} else {
						try {
							p.crossAppNavFlag = false;
							this.oPersonalizer.setPersData(p);
							hcm.people.profile.util.UIHelper.cachePersData(p);
						} catch (e) {}
						this.oApplication.pernr = p.selectedCEPernr;
						this.initializeView();
					}
				},
				onExit: function() {},
				createPersonalizationObj: function() {
					if (sap.ushell !== undefined && sap.ushell.Container !== undefined) {
						var p = sap.ushell.Container.getService("Personalization");
						var c = p.constants;
						var C = sap.ui.core.Component.getOwnerComponentFor(this.getView());
						var s = {
							keyCategory: c.keyCategory.FIXED_KEY,
							writeFrequency: c.writeFrequency.LOW,
							clientStorageAllowed: true,
							validity: Infinity
						};
						this.oPersId = {
							container: "hcm.people.profile",
							item: "appPersSettings"
						};
						this.oPersonalizer = p.getPersonalizer(this.oPersId, s, C);
						hcm.people.profile.util.UIHelper.setPersonalizerInstance(this.oPersonalizer);
					}
				}
			});
		},
		"hcm/people/profile/view/Profile.view.xml": '<!--\n\n    Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved\n\n-->\n<core:View xmlns:suite="sap.suite.ui.commons" height="100%" controllerName="hcm.people.profile.view.Profile" xmlns:bl="sap.uxap.blocks"\n\txmlns:core="sap.ui.core" xmlns:f="sap.ui.layout.form" xmlns:html="http://www.w3.org/1999/xhtml" xmlns:layout="sap.ui.layout" xmlns:m="sap.m" xmlns:mvc="sap.ui.core.mvc"\n\txmlns:pp="hcm.people.profile.blocks" xmlns:uxap="sap.uxap" xmlns:viz="sap.viz.ui5.controls">\n\t<uxap:ObjectPageLayout enableLazyLoading="true" id="ctrlObjectPageLayout" subSectionLayout="TitleOnLeft">\n\t\t<uxap:headerTitle>\n\t\t\t<uxap:ObjectPageHeader headerDesign="Light" id="ctlrObjHeaderEmp" isObjectIconAlwaysVisible="false" isObjectSubtitleAlwaysVisible="false"\n\t\t\t\tisObjectTitleAlwaysVisible="false" objectImageShape="Circle" showPlaceholder="true">\n\t\t\t\t<uxap:navigationBar>\n\t\t\t\t\t<m:Bar>\n\t\t\t\t\t\t<m:contentLeft>\n\t\t\t\t\t\t\t<m:Button icon="sap-icon://nav-back" press="onBackPress"></m:Button>\n\t\t\t\t\t\t</m:contentLeft>\n\t\t\t\t\t\t<m:contentMiddle>\n\t\t\t\t\t\t\t<m:Text text="{i18n>PEOPLE_PROFILE}"/>\n\t\t\t\t\t\t</m:contentMiddle>\n\t\t\t\t\t</m:Bar>\n\t\t\t\t</uxap:navigationBar>\n\t\t\t\t<uxap:actions>\n\t\t\t\t\t<uxap:ObjectPageHeaderActionButton icon="sap-icon://org-chart" press="onHierarchyPress" tooltip="{i18n]EMPLOYEE_HIERARCHY}"/>\n\t\t\t\t\t<!--<uxap:ObjectPageHeaderActionButton icon="sap-icon://action"/>-->\n\t\t\t\t</uxap:actions>\n\t\t\t</uxap:ObjectPageHeader>\n\t\t</uxap:headerTitle>\n\t\t<uxap:headerContent>\n\t\t\t<layout:VerticalLayout>\n\t\t\t\t<!--<layout:layoutData>-->\n\t\t\t\t<!--    <uxap:ObjectPageHeaderLayoutData-->\n\t\t\t\t<!--            width="25%"/>-->\n\t\t\t\t<!--</layout:layoutData>-->\n\t\t\t\t<m:Image id="ctrlHeaderImage"></m:Image>\n\t\t\t</layout:VerticalLayout>\n\t\t\t<layout:VerticalLayout>\n\t\t\t\t<!--<layout:layoutData>-->\n\t\t\t\t<!--    <uxap:ObjectPageHeaderLayoutData-->\n\t\t\t\t<!--            width="35%"/>-->\n\t\t\t\t<!--</layout:layoutData>-->\n\t\t\t\t<m:ObjectHeader id="lblName"/>\n\t\t\t\t<m:Text id="lblEmpNo"/>\n\t\t\t\t<m:Label id="lblPosition"/>\n\t\t\t\t<m:Label id="lblOrgUnit"/>\n\t\t\t</layout:VerticalLayout>\n\t\t\t<layout:VerticalLayout>\n\t\t\t\t<!--<layout:layoutData>-->\n\t\t\t\t<!--    <uxap:ObjectPageHeaderLayoutData-->\n\t\t\t\t<!--            width="20%"/>-->\n\t\t\t\t<!--</layout:layoutData>-->\n\t\t\t\t<m:Label id="lblLocation"/>\n\t\t\t\t<m:Link id="lblPhone" press="onPhoneClick"/>\n\t\t\t\t<m:Link id="lblEmail" press="onEmailClick"/>\n\t\t\t\t<layout:HorizontalLayout id="ctrlSocialMediaHolder"></layout:HorizontalLayout>\n\t\t\t</layout:VerticalLayout>\n\t\t\t<layout:VerticalLayout>\n\t\t\t\t<!--<layout:layoutData>-->\n\t\t\t\t<!--    <uxap:ObjectPageHeaderLayoutData-->\n\t\t\t\t<!--            width="20%"/>-->\n\t\t\t\t<!--</layout:layoutData>-->\n\t\t\t\t<m:Label id="lblCountryLocation"/>\n\t\t\t\t<m:Label id="lblTime"/>\n\t\t\t</layout:VerticalLayout>\n\t\t\t<!-- extension point for header content -->\n\t\t\t<core:ExtensionPoint name="headerField"></core:ExtensionPoint>\n\t\t</uxap:headerContent>\n\t\t<uxap:sections></uxap:sections>\n\t</uxap:ObjectPageLayout>\n</core:View>'
	}
});