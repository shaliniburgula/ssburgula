/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");
sap.ca.scfld.md.ConfigurationBase.extend("hcm.people.profile.Configuration", {
	oServiceParams: {
		serviceList: [{
			name: "HCM_PEOPLE_PROFILE_SRV",
			serviceUrl: "/sap/opu/odata/sap/HCM_PEOPLE_PROFILE_SRV/",
			isDefault: true,
			useBatch: true,
			mockedDataSource: "/hcm.people.profile/model/metadata.xml"
		}, {
			name: "NOTIFICATIONSTORE",
			serviceUrl: "/sap/opu/odata/IWFND/NOTIFICATIONSTORE",
			isDefault: false
		}]
	},
	getServiceParams: function() {
		return this.oServiceParams;
	},
	getAppConfig: function() {
		return this.oAppConfig;
	},
	getServiceList: function() {
		return this.oServiceParams.serviceList;
	}
});