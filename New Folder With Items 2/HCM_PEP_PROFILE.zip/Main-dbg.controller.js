/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.people.profile.Main", {

	onInit: function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		sap.ui.getCore().loadLibrary("sap.hcm.lib.common");
		sap.ca.scfld.md.Startup.init("hcm.people.profile", this);
	},
	onExit: function() {
		try {
			var oPersonalizer = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
			var aData = hcm.people.profile.util.UIHelper.getCachedPersData();
			//If control is not coming from the cross app navigation clear the personalization data
			if (aData.crossAppNavFlag !== true) {
				oPersonalizer.delPersData();
				hcm.people.profile.util.UIHelper.cachePersData(null);
			}
		} catch (exception) {
			//Do Nothing
		}
		//exit cleanup code here
		try {
			var oController = hcm.people.profile.util.UIHelper.getControllerInstance();
			//close the CE pop up
			if (oController.oCEDialog.isOpen()) {
				oController.oCEDialog.Cancelled = true;
				oController.oCEDialog.close();
			}
		} catch (e) {
			jQuery.sap.log.error("couldn't execute onExit", ["onExit failed in main controller"], ["hcm.people.profile.Main"]);
		}
	}
});