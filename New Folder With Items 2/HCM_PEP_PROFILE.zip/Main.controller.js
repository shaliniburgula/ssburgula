/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
sap.ui.controller("hcm.people.profile.Main", {
	onInit: function() {
		jQuery.sap.require("sap.ca.scfld.md.Startup");
		sap.ui.getCore().loadLibrary("sap.hcm.lib.common");
		sap.ca.scfld.md.Startup.init("hcm.people.profile", this);
	},
	onExit: function() {
		try {
			var p = hcm.people.profile.util.UIHelper.getPersonalizerInstance();
			var d = hcm.people.profile.util.UIHelper.getCachedPersData();
			if (d.crossAppNavFlag !== true) {
				p.delPersData();
				hcm.people.profile.util.UIHelper.cachePersData(null);
			}
		} catch (a) {}
		try {
			var c = hcm.people.profile.util.UIHelper.getControllerInstance();
			if (c.oCEDialog.isOpen()) {
				c.oCEDialog.Cancelled = true;
				c.oCEDialog.close();
			}
		} catch (e) {
			jQuery.sap.log.error("couldn't execute onExit", ["onExit failed in main controller"], ["hcm.people.profile.Main"]);
		}
	}
});