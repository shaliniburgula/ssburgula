/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("hcm.people.profile.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
(function() {
	var p = jQuery.sap.getModulePath("hcm.people.profile");
	if (p.indexOf("/hcm_pep_profile") !== -1) {
		if (p.lastIndexOf("/") !== p.length - 1) {
			p += "/";
		}
		jQuery.sap.registerModulePath("sap.hcm.lib.common", p + "../hcm_common/sap/hcm/lib/common/");
	}
}());
sap.ca.scfld.md.ComponentBase.extend("hcm.people.profile.Component", {
	metadata: sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		"name": "Fullscreen Sample",
		"version": "1.8.0",
		"library": "hcm.people.profile",
		"includes": [],
		"dependencies": {
			"libs": ["sap.m", "sap.me", "sap.uxap"],
			"components": []
		},
		"config": {
			"resourceBundle": "i18n/i18n.properties",
			"titleResource": "PEOPLE_PROFILE"
		},
		viewPath: "hcm.people.profile.view",
		fullScreenPageRoutes: {
			"fullscreen": {
				"pattern": "",
				"view": "Profile"
			}
		}
	}),
	createContent: function() {
		var v = {
			component: this
		};
		return sap.ui.view({
			viewName: "hcm.people.profile.Main",
			type: sap.ui.core.mvc.ViewType.XML,
			viewData: v
		});
	}
});