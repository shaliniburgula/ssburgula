sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("charts.controller.View1", {
    
    onInit:function(){
        
        var oVizFrame = this.getView().byId("idVizFrameBar");
        
        var columnData={
        	    "company": [{
        	    	"year":"2001",
        	        "city1": 1,
        	         "city2": 2,
        	          "city3": 4
        	       
        	    },{
        	    	"year":"2002",
        	    	"city1": 5,
        	       "city2": 2,
        	          "city3": 4
        	    }, {
        	    	"year":"2003",
        	    	"city1": 4,
        	    	"city2": 2,
        	          "city3": 4
        	       
        	    }, {
        	    	"year":"2004",
        	    	  "city1": 9,
        	    	"city2": 2,
        	          "city3": 4
        	       
        	    },  {
        	    	"year":"2005",
        	    	  "city1": 7,
        	    	"city2": 2,
        	          "city3": 4
        	       
        	    }]
        	};
        
        var oModel = new sap.ui.model.json.JSONModel();
        oModel.setData(columnData);
        
        var oDataset = new sap.viz.ui5.data.FlattenedDataset("idFds",{

            dimensions: [{
                name: "fullyear",
                value: "{year}"
            }],

            measures: [{
                name: 'city1',
                value: '{city1}'
            },
            {
                name: 'city2',
                value: '{city2}'
            },{
                name: 'city3',
                value: '{city3}'
            }],
            data: {
                path: "/company"
            }
        });

        oVizFrame.setDataset(oDataset);
        oVizFrame.setModel(oModel);
        
        var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                'uid': "valueAxis",
                'type': "Measure",
                'values': ["city1","city2","city3"]
            });

           var feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                'uid': "categoryAxis",
                'type': "Dimension",
                'values': ["fullyear"]
            });
       
       
        oVizFrame.setVizProperties({
        	 valueAxis: {
                 title: {
                     visible: true,
                     text:"City Data"
                 }
             },
            legend: {
                title: {
                    visible: true
                }
            },
            title: {
                visible: false,
                text: 'Revenue by Year and profit'
            }
        });
       
        oVizFrame.addFeed(feedValueAxis);
        oVizFrame.addFeed(feedCategoryAxis);
     

    }
	});

});