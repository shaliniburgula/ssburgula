sap.ui.define([
	"com/vjs/hyd/SCable/test/unit/controller/dashboard.controller"
], function () {
	"use strict";
});