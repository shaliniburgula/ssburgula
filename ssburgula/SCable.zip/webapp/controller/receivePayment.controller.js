sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function (Controller, Filter, FilterOperator,MessageBox) {
	"use strict";

	return Controller.extend("com.vjs.hyd.SCable.controller.receivePayment", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.vjs.hyd.SCable.view.recevicePayment
		 */
		onInit: function () {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			sap.ui.getCore().setModel("localModel");
				this._oRouter.getRoute("receivePayment").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function(){
				this.getView().byId("phNo").setValue("");
				this.getView().byId("idName").setValue("");
				
				this.getView().byId("idList").destroyItems();
		},
		onCustomerSearch: function (oEvent) {
			var aFilter = [];
			
			//var accNo = this.getView().byId("accNo").getValue();
			var phNo = this.getView().byId("phNo").getValue();
			var idName = this.getView().byId("idName").getValue();
			
			if(phNo == "" && idName == ""){
				MessageBox.alert("Enter any value to  customer search");
			}
			/*if (accNo != "") {
				this._searchID = accNo;
				aFilter.push(new Filter("name", FilterOperator.EQ, this._searchID));
			} else */if (phNo != "") {
				this._searchID = phNo;
				aFilter.push(new Filter("MobileNo", FilterOperator.Contains, this._searchID));
			} else {
				this._searchID = idName;
				aFilter.push(new Filter("CustomerName", FilterOperator.Contains, this._searchID));
			}
			this.FilterModel = sap.ui.getCore().getModel("localModel");
		
			var oList = this.getView().byId("idList").setModel(this.FilterModel ,"searchModel"),
				oBinding = oList.getBinding("items");

		oBinding.filter(aFilter, sap.ui.model.FilterType.Application);

			//this._oRouter.navTo("searchCustomer",{searchID:this._searchID});
		},
		onBackReceive: function () {
			this._oRouter.navTo("dashboard");
		},
		onCustomerList: function(oEvent){
		
			var oItem, searchID;
			oItem = oEvent.getSource();
			searchID = oItem.getBindingContextPath().split("/")[2];
			this._oRouter.navTo("searchCustomer",{
				searchID : searchID
			});
				/*	this._oRouter.navTo("searchCustomer", {
				searchID : oList.getBindingContext().getProperty("Cutomer ID")
			});*/
			
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.vjs.hyd.SCable.view.recevicePayment
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.vjs.hyd.SCable.view.recevicePayment
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.vjs.hyd.SCable.view.recevicePayment
		 */
		//	onExit: function() {
		//
		//	}

	});

});