sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller,MessageBox) {
	"use strict";

	return Controller.extend("com.vjs.hyd.SCable.controller.collManagement", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.vjs.hyd.SCable.view.collManagement
		 */
		onInit: function () {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		},
		onBackCollMgmt: function () {
			this._oRouter.navTo("dashboard");
		},
		onTimePeriod: function (oSelectedKey) {

			if (oSelectedKey.getParameters().selectedItem.getKey() == "Date Range") {
				this.getView().byId("idSD").setVisible(true);
				this.getView().byId("idDP1").setVisible(true);
				this.getView().byId("idDP1").setValue("");
				this.getView().byId("idED").setVisible(true);
				this.getView().byId("idDP2").setVisible(true);
				this.getView().byId("idDP2").setValue("");

			} else {
				this.getView().byId("idSD").setVisible(false);
				this.getView().byId("idDP1").setVisible(false);
				this.getView().byId("idED").setVisible(false);
				this.getView().byId("idDP2").setVisible(false);
			}
			var dateObject = {};
			var dateJson = new sap.ui.model.json.JSONModel();
			dateJson.setData(dateObject);
			this.getView().setModel(dateJson, "DateJson");

			this.getView().byId("idCollectionTable").setModel(dateJson, "DateJson");
			this.getView().byId("idCollectionTable").getModel("DateJson").refresh(true);

		},
		dateConversation: function (oDate) {
			var dd = String(oDate.getDate()).padStart(2, '0');
			var mm = String(oDate.getMonth() + 1).padStart(2, '0');
			var yyyy = oDate.getFullYear();

			return dd + '.' + mm + '.' + yyyy;
		},
		days_between: function (date1, date2) {
			var ONE_DAY = 1000 * 60 * 60 * 24;
			var differenceMs = Math.abs(date1 - date2);
			return Math.round(differenceMs / ONE_DAY);
		},
		onCollections: function () {
			var data = sap.ui.getCore().getModel("localModel").getData().items;
			var sTimePeriod = this.getView().byId("idTimeRange").getSelectedKey();
			var count = 0;
			var datePeriod, daysCount, startDate, endDate, dateRange, result, DP1, DP2;
			var dateArr = [];
			if (sTimePeriod == "Today") {
				var today = new Date();
				datePeriod = this.dateConversation(today);
			} else if (sTimePeriod == "Yesterday") {
				var today = new Date();
				var dd = String(today.getDate() - 1).padStart(2, '0');
				var mm = String(today.getMonth() + 1).padStart(2, '0');
				var yyyy = today.getFullYear();
				datePeriod = dd + '.' + mm + '.' + yyyy;
			}
			if (sTimePeriod == "Date Range") {
				DP1 = this.getView().byId("idDP1").getValue();
				DP2 = this.getView().byId("idDP2").getValue();
				startDate = new Date(DP1);
				endDate = new Date(DP2);
				daysCount = this.days_between(startDate, endDate);

				for (var i = 0; i <= daysCount; i++) {
					var dd = String(startDate.getDate() + i).padStart(2, '0');
					var mm = String(startDate.getMonth() + 1).padStart(2, '0');
					var yyyy = startDate.getFullYear();
					dateArr.push(dd + '.' + mm + '.' + yyyy);
				}
				dateRange = 0;
				for (var j = 0; j <= daysCount; j++) {
					result = data.reduce(function (a, arrayValue) {

						if (arrayValue.CollectionDate == dateArr[j]) {
							count = j + 1;
							return a + parseInt(arrayValue.PaidAmount);
						} else return a;

					}, 0);
					dateRange = dateRange + result;
				}

			} else {
				result = data.reduce(function (a, arrayValue) {
					if (arrayValue.CollectionDate == datePeriod) {
						count = count + 1;
						return a + parseInt(arrayValue.PaidAmount);
					} else return a;

				}, 0);

			}
			var dateObject;
			var dateValue = DP1 + " to " + DP2;
			if (sTimePeriod == "Date Range") {
				if (DP1 == "" || DP2 == "") {
					MessageBox.alert("select Start Date and End Date");
				} else {
					dateObject = {
						"TimePeriod": dateValue,
						"count": count,
						"Amount": dateRange
					};
				}
			} else {
				dateObject = {
					"TimePeriod": datePeriod,
					"count": count,
					"Amount": result
				};
			}
			var dateJson = new sap.ui.model.json.JSONModel();
			dateJson.setData(dateObject);
			this.getView().setModel(dateJson, "DateJson");

			this.getView().byId("idCollectionTable").setModel(dateJson, "DateJson");

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.vjs.hyd.SCable.view.collManagement
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.vjs.hyd.SCable.view.collManagement
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.vjs.hyd.SCable.view.collManagement
		 */
		//	onExit: function() {
		//
		//	}

	});

});