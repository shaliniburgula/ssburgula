var customerId, servicePath;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("com.vjs.hyd.SCable.controller.editCustomer", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.vjs.hyd.SCable.view.editCustomer
		 */
		onInit: function () {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.getRoute("editCustomer").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (oEvent) {
			var FilterModel = new sap.ui.model.json.JSONModel();

			customerId = oEvent.getParameter("arguments").customerId;
			servicePath = "/items/" + oEvent.getParameter("arguments").customerId;
			FilterModel.setData(sap.ui.getCore().getModel("localModel").getData().items[customerId]);
			this.getView().setModel(FilterModel, "FilterModel");

			this.getView().byId("idEditCN").setValue(FilterModel.getData().CustomerName);
			this.getView().byId("idEditAddress").setValue(FilterModel.getData().Address);
			this.getView().byId("idEditAadharCard").setValue(FilterModel.getData().Aadhar);
			this.getView().byId("idEditMobNo").setValue(FilterModel.getData().MobileNo);
			var oBoxType = this.getView().byId("idEditBoxType").getSelectedKey();

			if (oBoxType == "VCNo") {
				this.getView().byId("idBoxNo").setValue(FilterModel.getData().VCNo);
			} else {
				this.getView().byId("idBoxNo").setValue(FilterModel.getData().STBNo);
			}
			//this.getView().setModel(FilterModel, "updateModel");
			//	sPath = "updateModel>/items/" + oEvent.getParameter("arguments").customerId;

			/*	this.getView().bindElement(sPath);

				var SFEditCustomer = this.getView().byId("SFEditCustomer");
				SFEditCustomer.bindElement(sPath);*/

		},
		onBackSearch: function () {
			this._oRouter.navTo("updateCustomer");
		},
		onHomePress: function () {
			this._oRouter.navTo("dashBoard");
		},
		onSavePress: function () {
				var sEditName = this.getView().byId("idEditCN").getValue();
				var sEditAddress = this.getView().byId("idEditAddress").getValue();
				var sEditAadharCard = this.getView().byId("idEditAadharCard").getValue();
				var sEditMobNo = this.getView().byId("idEditMobNo").getValue();
				var sBoxNo = this.getView().byId("idBoxNo").getValue();

				var flag = true;

				if (sEditName == "") {
					this.getView().byId("idEditCN").getValueState("Error");
					flag = false;
				} else {
					this.getView().byId("idEditCN").getValueState("None");
				}

				if (sEditAddress == "") {
					this.getView().byId("idEditAddress").getValueState("Error");
					flag = false;
				} else {
					this.getView().byId("idEditAddress").getValueState("None");
				}

				if (sEditAadharCard == "") {
					this.getView().byId("idEditAadharCard").getValueState("Error");
					flag = false;
				} else {
					this.getView().byId("idEditAadharCard").getValueState("None");
				}
				if (sEditMobNo == "") {
					this.getView().byId("idEditMobNo").getValueState("Error");
					flag = false;
				} else {
					this.getView().byId("idEditMobNo").getValueState("None");
				}
				if (sBoxNo == "") {
					this.getView().byId("idBoxNo").getValueState("Error");
					flag = false;
				} else {
					this.getView().byId("idBoxNo").getValueState("None");
				}
				
				var that = this;
				if (flag == false) {
					MessageBox.error("Enter all Details");
				} else {

					sap.ui.getCore().getModel("localModel").getData().items[customerId].CustomerName = sEditName;
					sap.ui.getCore().getModel("localModel").getData().items[customerId].Address = sEditAddress;
					sap.ui.getCore().getModel("localModel").getData().items[customerId].Aadhar = sEditAadharCard;
					sap.ui.getCore().getModel("localModel").getData().items[customerId].MobileNo = sEditMobNo;
					var oBoxType = this.getView().byId("idEditBoxType").getSelectedKey();

					if (oBoxType == "VCNo") {
						sap.ui.getCore().getModel("localModel").getData().items[customerId].VCNo = sBoxNo;
					} else {
						sap.ui.getCore().getModel("localModel").getData().items[customerId].STBNo = sBoxNo;
					}

					MessageBox.success("Customer Details Updated Successfully", {
						title: "Success", // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.OK, // default
						emphasizedAction: sap.m.MessageBox.Action.OK, // default
						initialFocus: null, // default
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {
								that._oRouter.navTo("updateCustomer");
							}
						}

					});
					
				}

			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.vjs.hyd.SCable.view.editCustomer
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.vjs.hyd.SCable.view.editCustomer
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.vjs.hyd.SCable.view.editCustomer
		 */
		//	onExit: function() {
		//
		//	}

	});

});