sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.vjs.hyd.SCable.controller.dashboard", {
		onInit: function () {
				this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		},
		
		onPressReceivePayment: function(){
		
			this._oRouter.navTo("receivePayment");
		},
		onPressCollnMgmt: function(){
			this._oRouter.navTo("collManagement");
		},
		onPressSettings: function(){
			this._oRouter.navTo("settings");
		},
		onPressAddCustomer: function(){
			this._oRouter.navTo("addCustomer");
		}
	});
});