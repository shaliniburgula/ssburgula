jQuery.sap.require('jquery.sap.storage');
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.vjs.hyd.SCable.controller.uploadExcel", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.vjs.hyd.SCable.view.uploadExcel
		 */
		onInit: function () {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.localModel = new sap.ui.model.json.JSONModel();
				// initiate GUID storage
			this.oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
		
		
		},
		onHomePress: function(){
			this._oRouter.navTo("dashboard");	
		},
		onBackSearch: function(){
						this._oRouter.navTo("settings");
		},
		onUpload: function (e) {
			this._import(e.getParameter("files") && e.getParameter("files")[0]);
		},

		_import: function (file) {
			var that = this;
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function (e) {
					var data = e.target.result;
					var workbook = XLSX.read(data, {
						type: 'binary'
					});
					workbook.SheetNames.forEach(function (sheetName) {
						// Here is your object for every sheet in workbook
						excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);

					});
					// Setting the data to the local model 
					that.localModel.setData({
						items: excelData
					});
					that.localModel.refresh(true);
						that.getView().setModel(that.localModel, "localModel");
			sap.ui.getCore().setModel(that.localModel, "localModel");
					that.oStorage.put("localStorageData", that.localModel.getData());
					
					sap.m.MessageToast.show("Data has uploaded successfully");
				};
				reader.onerror = function (ex) {
					sap.m.MessageToast.show("Error while uploading");
				};
				reader.readAsBinaryString(file);
			}
		},

		
	});

});