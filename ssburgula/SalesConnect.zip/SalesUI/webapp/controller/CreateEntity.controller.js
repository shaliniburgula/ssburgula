sap.ui.define([
	"com/accenture/SalesConnect/SalesUI/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"

], function (BaseController, JSONModel, MessageBox) {
	"use strict";

	return BaseController.extend("com.accenture.SalesConnect.SalesUI.controller.CreateEntity", {

		_oBinding: {},

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			var that = this;
			this.getRouter().getTargets().getTarget("create").attachDisplay(null, this._onDisplay, this);
			this._oODataModel = this.getOwnerComponent().getModel();
			this._oResourceBundle = this.getResourceBundle();
			this._oViewModel = new JSONModel({
				enableCreate: false,
				delay: 0,
				busy: false,
				mode: "create",
				viewTitle: ""
			});
			this.setModel(this._oViewModel, "viewModel");

			// Register the view with the message manager
			sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
			var oMessagesModel = sap.ui.getCore().getMessageManager().getMessageModel();
			this._oBinding = new sap.ui.model.Binding(oMessagesModel, "/", oMessagesModel.getContext("/"));
			this._oBinding.attachChange(function (oEvent) {
				var aMessages = oEvent.getSource().getModel().getData();
				for (var i = 0; i < aMessages.length; i++) {
					if (aMessages[i].type === "Error" && !aMessages[i].technical) {
						that._oViewModel.setProperty("/enableCreate", false);
					}
				}
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler (attached declaratively) for the view save button. Saves the changes added by the user. 
		 * @function
		 * @public
		 */
		onSave: function () {
			var aWorkLogs = [];
			var aWorkLogItems = this.getView().byId("idTabLineItems").getItems();
			for (var i = 0; i < aWorkLogItems.length; i++) {
				var newWorkLogItem = {
					worklogno: aWorkLogItems[i].getAggregation("cells")[8].getValue(),
					custaddres: aWorkLogItems[i].getAggregation("cells")[4].getValue(),
					custphno: "",
					amount: aWorkLogItems[i].getAggregation("cells")[6].getValue(),
					curr: "INR",
					statu: aWorkLogItems[i].getAggregation("cells")[7].getValue(),
					SalesStatusText: "",
					feedback: aWorkLogItems[i].getAggregation("cells")[5].getValue(),
					FeedbackDesc: "",
					remarks: "",
					assigmentno: aWorkLogItems[i].getAggregation("cells")[0].getValue(),
					salesemp: "",
					regkey: "",
					rdes: aWorkLogItems[i].getAggregation("cells")[1].getValue(),
					prdid: "",
					quantity: 4,
					custdetail: aWorkLogItems[i].getAggregation("cells")[2].getValue(),
					CreatedTime: aWorkLogItems[i].getAggregation("cells")[3].getValue()
				};
				aWorkLogs.push(newWorkLogItem);
			}
			var aExpLogs = [];
			var aExpLogItems = this.getView().byId("idTabLineItems2").getItems();
			for (var i = 0; i < aExpLogItems.length; i++) {
				var newExpLogItem = {
					expno: aExpLogItems[i].getAggregation("cells")[1].getValue(),
					regkey: "",
					userid: "",
					rdes: aExpLogItems[i].getAggregation("cells")[3].getValue(),
					statu: aExpLogItems[i].getAggregation("cells")[7].getValue(),
					StatusDesc: "Submitted",
					remarks: "",
					approvernote: "",
					exp_timestamp: "",
					assigmentno: aExpLogItems[i].getAggregation("cells")[0].getValue(),
					expcatid: "",
					CategoryText: aExpLogItems[i].getAggregation("cells")[2].getValue(),
					amount: aExpLogItems[i].getAggregation("cells")[6].getValue(),
					curr: "INR",
					frmdate: aExpLogItems[i].getAggregation("cells")[4].getValue(),
					todate: aExpLogItems[i].getAggregation("cells")[5].getValue(),
					lockey: ""
				};
				aExpLogs.push(newExpLogItem);
			}
			var mode = this._oViewModel.getProperty("/mode");

			var payload = {
				"Accept_ac": "",
				"Reject_ac": "",
				"assigmentno": (mode === "edit") ? this.getView().byId("f1").getValue() : this.getView().byId("f7").getValue(),
				"slstrgt": (mode === "edit") ? this.getView().byId("f5").getValue() : this.getView().byId("f11").getValue(),
				"curr": "INR",
				"Assgstatus": "",
				"statusText": (mode === "edit") ? this.getView().byId("f6").getSelectedKey() : this.getView().byId("f12").getSelectedKey(),
				"SalesTargetAch": "0.00",
				"allctdexpns": "0.00",
				"remarks": "",
				"actiontime": "",
				"userid": "",
				"eassgn_timestamp": "",
				"fromdate": (mode === "edit") ? this.getView().byId("f3").getValue() : this.getView().byId("f9").getValue(),
				"assignedby": "",
				"regkey": "",
				"rdes": (mode === "edit") ? this.getView().byId("f2").getValue() : this.getView().byId("f8").getValue(),
				"todate": (mode === "edit") ? this.getView().byId("f4").getValue() : this.getView().byId("f10").getValue(),
				"cstmrtrgt": "0.00",
				"worklog": aWorkLogs,
				"expense": aExpLogs
			};
			if (this._oViewModel.getProperty("/mode") === "edit") {
				var jurl = "/sales_dest/xsjs/allocationDeepSales.xsjs?cmd=updateAlloc";
			} else {
				var jurl = "/sales_dest/xsjs/allocationDeepSales.xsjs?cmd=createAlloc";
			}

			jQuery.ajax({
				url: jurl,
				async: false,
				data: {
					dataobject: JSON.stringify(payload)
				},
				method: 'POST',
				dataType: 'text',
				success: function (data) {
					this.getView().getModel().refresh(true);
					//MessageBox.show(data, MessageBox.Icon.SUCCESS, "Created....");
					if (this._oViewModel.getProperty("/mode") === "edit") {
						this.getModel("appView").setProperty("/busy", false);
						this.getView().unbindObject();
						MessageBox.show(
							"Sales request  has successfully updated", {
								icon: MessageBox.Icon.SUCCESS,
								title: "updated...!",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === "OK") {
										this.getRouter().getTargets().display("object");
									}
								}.bind(this)
							}
						);

					} else {
						var sObjectPath = this.getModel().createKey("Zc_allocsales", {
							assigmentno: this.getView().byId("f1").getValue()
						});
						this.getModel("appView").setProperty("/itemToSelect", "/" + sObjectPath); //save last created
						this.getModel("appView").setProperty("/busy", false);
						MessageBox.show(
							"New Sales request has successfully created", {
								icon: MessageBox.Icon.SUCCESS,
								title: "Created...!",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === "OK") {
										this.getRouter().getTargets().display("object");
									}
								}.bind(this)
							}
						);

					}
				}.bind(this),
				error: function () {
					MessageBox.show("Some error occured , please check the data or Internet connectivity", MessageBox.Icon.ERROR,
						"oops error ccured.!");
				}
			});
		},

		_checkIfBatchRequestSucceeded: function (oEvent) {
			var oParams = oEvent.getParameters();
			var aRequests = oEvent.getParameters().requests;
			var oRequest;
			if (oParams.success) {
				if (aRequests) {
					for (var i = 0; i < aRequests.length; i++) {
						oRequest = oEvent.getParameters().requests[i];
						if (!oRequest.success) {
							return false;
						}
					}
				}
				return true;
			} else {
				return false;
			}
		},

		/**
		 * Event handler (attached declaratively) for the view cancel button. Asks the user confirmation to discard the changes. 
		 * @function
		 * @public
		 */
		onCancel: function () {
			// check if the model has been changed
			if (this.getModel().hasPendingChanges()) {
				// get user confirmation first
				this._showConfirmQuitChanges(); // some other thing here....
			} else {
				this.getModel("appView").setProperty("/addEnabled", true);
				// cancel without confirmation
				this._navBack();
			}
		},

		/* =========================================================== */
		/* Internal functions
		/* =========================================================== */
		/**
		 * Navigates back in the browser history, if the entry was created by this app.
		 * If not, it navigates to the Details page
		 * @private
		 */
		_navBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash();

			this.getView().unbindObject();
			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				this.getRouter().getTargets().display("object");
			}
		},

		/**
		 * Opens a dialog letting the user either confirm or cancel the quit and discard of changes.
		 * @private
		 */
		_showConfirmQuitChanges: function () {
			var oComponent = this.getOwnerComponent(),
				oModel = this.getModel();
			var that = this;
			MessageBox.confirm(
				this._oResourceBundle.getText("confirmCancelMessage"), {
					styleClass: oComponent.getContentDensityClass(),
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.OK) {
							that.getModel("appView").setProperty("/addEnabled", true);
							oModel.resetChanges();
							that._navBack();
						}
					}
				}
			);
		},

		/**
		 * Prepares the view for editing the selected object
		 * @param {sap.ui.base.Event} oEvent the  display event
		 * @private
		 */
		_onEdit: function (oEvent) {
			var oData = oEvent.getParameter("data"),
				oView = this.getView();
			this._oViewModel.setProperty("/mode", "edit");
			this._oViewModel.setProperty("/enableCreate", true);
			this._oViewModel.setProperty("/viewTitle", this._oResourceBundle.getText("editViewTitle"));

			oView.bindElement({
				path: oData.objectPath
			});
			var template = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{assigmentno}"
					}), new sap.m.Input({
						value: "{rdes}"
					}), new sap.m.Input({
						value: "{custdetail}"
					}), new sap.m.Input({
						value: "{CreatedTime}"
					}), new sap.m.Input({
						value: "{custaddres}"
					}), new sap.m.Input({
						value: "{feedback}"
					}), new sap.m.Input({
						value: "{amount}"
					}), new sap.m.Input({
						value: "{statu}"
					}), new sap.m.Input({
						value: "{worklogno}"
					})
				]
			});
			this.getView().byId("idTabLineItems").bindItems("to_WorkLog", template);
			var template2 = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{assigmentno}"
					}), new sap.m.Input({
						value: "{expno}"
					}), new sap.m.Input({
						value: "{CategoryText}"
					}), new sap.m.Input({
						value: "{rdes}"
					}), new sap.m.Input({
						value: "{frmdate}"
					}), new sap.m.Input({
						value: "{todate}"
					}), new sap.m.Input({
						value: "{amount}"
					}), new sap.m.Input({
						value: "{statu}"
					})
				]
			});
			this.getView().byId("idTabLineItems2").bindItems("to_Expense", template2);

		},

		/**
		 * Prepares the view for creating new object
		 * @param {sap.ui.base.Event} oEvent the  display event
		 * @private
		 */

		_onCreate: function (oEvent) {
			if (oEvent.getParameter("name") && oEvent.getParameter("name") !== "create") {
				this._oViewModel.setProperty("/enableCreate", false);
				this.getRouter().getTargets().detachDisplay(null, this._onDisplay, this);
				this.getView().unbindObject();
				return;
			}

			this._oViewModel.setProperty("/viewTitle", this._oResourceBundle.getText("createViewTitle"));
			this._oViewModel.setProperty("/mode", "create");
			/*	var oContext = this._oODataModel.createEntry("Zc_allocsales", {
					success: this._fnEntityCreated.bind(this),
					error: this._fnEntityCreationFailed.bind(this)
				});
				this.getView().setBindingContext(oContext);*/

		},

		/**
		 * Checks if the save button can be enabled
		 * @private
		 */
		_validateSaveEnablement: function () {
			var aInputControls = this._getFormFields(this.byId("newEntitySimpleForm"));
			var oControl;
			for (var m = 0; m < aInputControls.length; m++) {
				oControl = aInputControls[m].control;
				if (aInputControls[m].required) {
					var sValue = oControl.getValue();
					if (!sValue) {
						this._oViewModel.setProperty("/enableCreate", false);
						return;
					}
				}
			}
			this._checkForErrorMessages();
		},

		/**
		 * Checks if there is any wrong inputs that can not be saved.
		 * @private
		 */

		_checkForErrorMessages: function () {
			var aMessages = this._oBinding.oModel.oData;
			if (aMessages.length > 0) {
				var bEnableCreate = true;
				for (var i = 0; i < aMessages.length; i++) {
					if (aMessages[i].type === "Error" && !aMessages[i].technical) {
						bEnableCreate = false;
						break;
					}
				}
				this._oViewModel.setProperty("/enableCreate", bEnableCreate);
			} else {
				this._oViewModel.setProperty("/enableCreate", true);
			}
		},

		/**
		 * Handles the success of updating an object
		 * @private
		 */
		_fnUpdateSuccess: function () {
			this.getModel("appView").setProperty("/busy", false);
			this.getView().unbindObject();
			this.getRouter().getTargets().display("object");
		},

		/**
		 * Handles the success of creating an object
		 *@param {object} oData the response of the save action
		 * @private
		 */
		_fnEntityCreated: function (oData) {
			var sObjectPath = this.getModel().createKey("Zc_allocsales", oData);
			this.getModel("appView").setProperty("/itemToSelect", "/" + sObjectPath); //save last created
			this.getModel("appView").setProperty("/busy", false);
			this.getRouter().getTargets().display("object");
		},

		/**
		 * Handles the failure of creating/updating an object
		 * @private
		 */
		_fnEntityCreationFailed: function () {
			this.getModel("appView").setProperty("/busy", false);
		},

		/**
		 * Handles the onDisplay event which is triggered when this view is displayed 
		 * @param {sap.ui.base.Event} oEvent the on display event
		 * @private
		 */
		_onDisplay: function (oEvent) {
			this.getView().byId("idTabLineItems").unbindItems();
			this.getView().byId("idTabLineItems").removeAllItems();
			this.getView().byId("idTabLineItems2").unbindItems();
			this.getView().byId("idTabLineItems2").removeAllItems();
			var oData = oEvent.getParameter("data");
			if (oData && oData.mode === "update") {
				this._onEdit(oEvent);
			} else {
				//clear form fields
				var aFields = ["f7", "f8", "f9", "f10", "f11"];
				for (var i = 0; i < aFields.length; i++) {
					this.getView().byId(aFields[i]).setValue("");
				}
				this.getView().byId("f12").setSelectedKey("");
				//clear form fields
				this._onCreate(oEvent);
			}
		},

		/**
		 * Gets the form fields
		 * @param {sap.ui.layout.form} oSimpleForm the form in the view.
		 * @private
		 */
		_getFormFields: function (oSimpleForm) {
			var aControls = [];
			var aFormContent = oSimpleForm.getContent();
			var sControlType;
			for (var i = 0; i < aFormContent.length; i++) {
				sControlType = aFormContent[i].getMetadata().getName();
				if (sControlType === "sap.m.Input" || sControlType === "sap.m.DateTimeInput" ||
					sControlType === "sap.m.CheckBox") {
					aControls.push({
						control: aFormContent[i],
						required: aFormContent[i - 1].getRequired && aFormContent[i - 1].getRequired()
					});
				}
			}
			return aControls;
		},
		onAddItem: function () {
			var newItemCreate = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: this.getView().byId("f7").getValue(),
						enabled: false
					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Button({
						icon: "sap-icon://delete",
						press: function (oEvent) {
							var oItem = oEvent.getSource().getParent();
							this.getView().byId("idTabLineItems").removeItem(oItem);
						}.bind(this)
					})
				]
			});
			var newItemEdit = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{assigmentno}"
					}), new sap.m.Input({
						value: "{rdes}"
					}), new sap.m.Input({
						value: "{custdetail}"
					}), new sap.m.Input({
						value: "{CreatedTime}"
					}), new sap.m.Input({
						value: "{custaddres}"
					}), new sap.m.Input({
						value: "{feedback}"
					}), new sap.m.Input({
						value: "{amount}"
					}), new sap.m.Input({
						value: "{statu}"
					}), new sap.m.Input({
						value: "{worklogno}"
					}), new sap.m.Button({
						icon: "sap-icon://delete",
						press: function (oEvent) {
							var oItem = oEvent.getSource().getParent();
							this.getView().byId("idTabLineItems").removeItem(oItem);
						}.bind(this)
					})
				]
			});
			if (this._oViewModel.getProperty("/mode") === "edit") {
				this.getView().byId("idTabLineItems").addItem(newItemEdit);
			} else {
				this.getView().byId("idTabLineItems").addItem(newItemCreate);
			}

		},
		onAddItem2: function () {
			var newItemCreate = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: this.getView().byId("f7").getValue(),
						enabled: false
					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Input({

					}), new sap.m.Button({
						icon: "sap-icon://delete",
						press: function (oEvent) {
							var oItem = oEvent.getSource().getParent();
							this.getView().byId("idTabLineItems2").removeItem(oItem);
						}.bind(this)
					})
				]
			});
			var newItemEdit = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						value: "{assigmentno}"
					}), new sap.m.Input({
						value: "{expno}"
					}), new sap.m.Input({
						value: "{CategoryText}"
					}), new sap.m.Input({
						value: "{rdes}"
					}), new sap.m.Input({
						value: "{frmdate}"
					}), new sap.m.Input({
						value: "{todate}"
					}), new sap.m.Input({
						value: "{amount}"
					}), new sap.m.Input({
						value: "{statu}"
					}), new sap.m.Button({
						icon: "sap-icon://delete",
						press: function (oEvent) {
							var oItem = oEvent.getSource().getParent();
							this.getView().byId("idTabLineItems2").removeItem(oItem);
						}.bind(this)
					})
				]
			});
			if (this._oViewModel.getProperty("/mode") === "edit") {
				this.getView().byId("idTabLineItems2").addItem(newItemEdit);
			} else {
				this.getView().byId("idTabLineItems2").addItem(newItemCreate);
			}

		},

	});

});