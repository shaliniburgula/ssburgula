jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/accenture/SalesConnect/SalesUI/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/accenture/SalesConnect/SalesUI/test/integration/pages/App",
	"com/accenture/SalesConnect/SalesUI/test/integration/pages/Browser",
	"com/accenture/SalesConnect/SalesUI/test/integration/pages/Master",
	"com/accenture/SalesConnect/SalesUI/test/integration/pages/Detail",
	"com/accenture/SalesConnect/SalesUI/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.accenture.SalesConnect.SalesUI.view."
	});

	sap.ui.require([
		"com/accenture/SalesConnect/SalesUI/test/integration/NavigationJourneyPhone",
		"com/accenture/SalesConnect/SalesUI/test/integration/NotFoundJourneyPhone",
		"com/accenture/SalesConnect/SalesUI/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});