sap.ui.define([
	"sap/m/MessageBox",
	"sap/ui/core/mvc/Controller"
], function (MessageBox,Controller) {
	"use strict";

	return Controller.extend("tutorials.UI5.HelloWorld.controller.HelloWorld", {
		onInit: function () {

		},
		onClick: function(){
		var txtOnBtn = this.getView().byId("idbtn").getText();
		
		if(txtOnBtn ==="Hide")
			{
			this.getView().byId("idlblname").setVisible(false);
			this.getView().byId("idname").setVisible(false);
			
			this.getView().byId("idbtn").setText("UnHide");
			}
		else
			{
			this.getView().byId("idlblname").setVisible(true);
			this.getView().byId("idname").setVisible(true);
			
			this.getView().byId("idbtn").setText("Hide");
			}

		}
	});
});