sap.ui.define([
	"tutorials/UI5/HelloWorld/test/unit/controller/HelloWorld.controller"
], function () {
	"use strict";
});