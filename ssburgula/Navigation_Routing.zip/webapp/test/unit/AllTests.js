sap.ui.define([
	"tutorial/ui5/Navigation_Routing/test/unit/controller/App.controller"
], function () {
	"use strict";
});