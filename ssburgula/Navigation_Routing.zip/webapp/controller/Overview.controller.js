sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("tutorial.ui5.Navigation_Routing.controller.Overview", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf tutorial.ui5.Navigation_Routing.view.Overview
		 */
		onInit: function () {
			var oData = {
				"Employees": [{
					"EmployeeID": "123",
					"FirstName": "Vimala",
					"LastName": "Kamala",
					"Designation": "TL"
				}, {
					"EmployeeID": "134",
					"FirstName": "Sita",
					"LastName": "gita",
					"Designation": "SSE"
				}, {
					"EmployeeID": "154",
					"FirstName": "Radha",
					"LastName": "Krishna",
					"Designation": "SE"
				}, {
					"EmployeeID": "567",
					"FirstName": "vamshi",
					"LastName": "Kumar",
					"Designation": "ASE"
				}]
			};
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData(oData);
			this.getView().setModel(oJsonModel, "EmployeesModel");
		},
		handleSelectionChange: function (oEvent) {
		
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Detail");
			
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf tutorial.ui5.Navigation_Routing.view.Overview
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf tutorial.ui5.Navigation_Routing.view.Overview
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf tutorial.ui5.Navigation_Routing.view.Overview
		 */
		//	onExit: function() {
		//
		//	}

	});

});