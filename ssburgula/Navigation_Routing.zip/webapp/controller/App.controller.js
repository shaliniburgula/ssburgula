sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("tutorial.ui5.Navigation_Routing.controller.App", {
		onInit: function () {

		}
	});
});