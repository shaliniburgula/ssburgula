jQuery.sap.declare("tutorial.ui5.MasterDetail.masterdetailExtension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "tutorial.ui5.MasterDetail",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on cloud
	// Remove the url parameter once your application is deployed to productive account
	url: jQuery.sap.getModulePath("tutorial.ui5.MasterDetail.masterdetailExtension") + "/parent"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.tutorial.ui5.MasterDetail.Component.extend("tutorial.ui5.MasterDetail.masterdetailExtension.Component", {
	metadata: {
		manifest: "json"
	}
});