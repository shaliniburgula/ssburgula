function initModel() {
	var sUrl = "/Northwind_Service/V2/(S(kkgtm55bpbgfr4o5n50tbwbj))/OData/OData.svc/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}