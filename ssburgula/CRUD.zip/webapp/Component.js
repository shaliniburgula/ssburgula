sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"tutorial/ui5/CRUD/model/models",
	"sap/m/MessageBox"
], function (UIComponent, Device, models, MessageBox) {
	"use strict";

	return UIComponent.extend("tutorial.ui5.CRUD.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		},
		applicationModel: function () {
			var dModel = new sap.ui.model.json.JSONModel();
			var serviceUrl = this.getModel().sServiceUrl;
			var oDataModel = new sap.ui.model.odata.ODataModel(serviceUrl, true);

			oDataModel.read("/Products", null, null, true,
				function (data) {
					dModel.setData(data);

				},
				function (err) {

					MessageBox.alert("Error while fetching the data");

				});
			this.setModel(dModel, "readModel");
		
			

		}
	});
});