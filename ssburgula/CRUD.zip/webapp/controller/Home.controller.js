sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";
	var updateflag = false;
	return Controller.extend("tutorial.ui5.CRUD.controller.Home", {
		onInit: function () {

		},
		onRead: function () {
			this.getOwnerComponent().applicationModel();
			
		},
		onOpenFragment: function (oEvent) {
			var dialog = sap.ui.getCore().byId("createDialog");
			if (dialog === undefined) {
				dialog = sap.ui.xmlfragment("tutorial.ui5.CRUD.fragments.Create", this.getView().getController());
				this.getView().addDependent(dialog);
			}
			dialog.open();
			var btnText = oEvent.getSource().mProperties.text;

			if (btnText === "Update") {
				updateflag = true;
				var sPath = this.getView().byId("productsTabId").getSelectedItem().getBindingContext("readModel").sPath;
				var sPrdID = this.getView().getModel("readModel").getProperty(sPath).ID;
				var sPrdName = this.getView().getModel("readModel").getProperty(sPath).Name;
				var sPrdDescription = this.getView().getModel("readModel").getProperty(sPath).Description;
				sap.ui.getCore().byId("idprdid").setValue(sPrdID);
				sap.ui.getCore().byId("idprdname").setValue(sPrdName);
				sap.ui.getCore().byId("idprddes").setValue(sPrdDescription);
			} else {
				sap.ui.getCore().byId("idprdid").setValue("");
				sap.ui.getCore().byId("idprdname").setValue("");
				sap.ui.getCore().byId("idprddes").setValue("");
			}
		},
		onSubmit: function () {
			var that = this;
			var dialog = sap.ui.getCore().byId("createDialog");
			var prdid = sap.ui.getCore().byId("idprdid").getValue();
			var prdname = sap.ui.getCore().byId("idprdname").getValue();
			var prddes = sap.ui.getCore().byId("idprddes").getValue();
			var dModel = new sap.ui.model.json.JSONModel();
			var serviceUrl = this.getOwnerComponent().getModel().sServiceUrl;
			var oDataModel = new sap.ui.model.odata.ODataModel(serviceUrl, true);
			var oModel = new sap.ui.model.odata.ODataModel(serviceUrl, true);
			if (updateflag === false) {
				oModel.create("/Products", {
					ID: prdid,
					Name: prdname,
					Description: prddes

				}, {

					success: function () {

						MessageBox.show("The New Product has been Successfully Created..", {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							actions: [sap.m.MessageBox.Action.OK],

							onClose: function (oAction) {

								if (oAction === "OK") {
									sap.ui.getCore().byId("idprdid").setValue("");
									sap.ui.getCore().byId("idprdname").setValue("");
									sap.ui.getCore().byId("idprddes").setValue("");

									that.getOwnerComponent().applicationModel();

								}
							}
						});

						dialog.close();

					},
					error: function () {
						MessageBox.alert("Cannot able to create product");
					}

				});
			} else {
				oModel.update("/Products(" + prdid + ")", {

					Name: prdname,
					Description: prddes

				}, {
					success: function () {

						MessageBox.show("The New Product has been Successfully Updated..", {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							actions: [sap.m.MessageBox.Action.OK],

							onClose: function (oAction) {

								if (oAction === "OK") {
									sap.ui.getCore().byId("idprdid").setValue("");
									sap.ui.getCore().byId("idprdname").setValue("");
									sap.ui.getCore().byId("idprddes").setValue("");

									that.getOwnerComponent().applicationModel();

								}
							}
						});

						dialog.close();

					},
					error: function () {
						MessageBox.alert("failure");
					}
				});

			}
		},
		onDelete: function () {
			var sPath = this.getView().byId("productsTabId").getSelectedItem().getBindingContext("readModel").sPath;
			var sPrdID = this.getView().getModel("readModel").getProperty(sPath).ID;
			
			var serviceUrl = this.getOwnerComponent().getModel().sServiceUrl;
			var oModel = new sap.ui.model.odata.ODataModel(serviceUrl,true);
			var that = this;
			oModel.remove("/Products(" + sPrdID + ")", {
				success: function () {
				
					sap.m.MessageBox.show("The  Product has been Successfully Deleted..",{
						icon:sap.m.MessageBox.Icon.SUCCESS, 	
						actions: [sap.m.MessageBox.Action.OK],

							onClose: function (oAction) {

								if (oAction === "OK") {
									that.getOwnerComponent().applicationModel();

								}
							}
						});
				
				},
				error: function () {
					MessageBox.alert("failure");
				}
			});
		},
		onCancel: function () {
			var dialog = sap.ui.getCore().byId("createDialog");
			sap.ui.getCore().byId("idprdid").setValue("");
			sap.ui.getCore().byId("idprdname").setValue("");
			sap.ui.getCore().byId("idprddes").setValue("");

			dialog.close();
		},

	});
});