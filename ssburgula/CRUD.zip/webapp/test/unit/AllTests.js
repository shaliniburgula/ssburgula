sap.ui.define([
	"tutorial/ui5/CRUD/test/unit/controller/Home.controller"
], function () {
	"use strict";
});