/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function() {
	"use strict";

	sap.ui.require([
		"worklist/test/github/Worklist/test/integration/AllJourneys"
	], function() {
		QUnit.start();
	});
});