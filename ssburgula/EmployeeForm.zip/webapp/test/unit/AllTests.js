sap.ui.define([
	"tutorial/ui5/EmployeeForm/test/unit/controller/View1.controller"
], function () {
	"use strict";
});