sap.ui.define([
	"sap/ui/core/mvc/Controller","sap/m/MessageBox"
], function (Controller,MessageBox) {
	"use strict";

	return Controller.extend("tutorial.ui5.EmployeeForm.controller.View1", {
		onInit: function () {
		var oJsonData = {
				empId : "1290",
				empFN : "Sharma",
				empLN : "Patel",
				designation : "SSE",
				email: "sharma.patel@gmail.com"
			};
			
			 var oJsonDataModel = new sap.ui.model.json.JSONModel();
			oJsonDataModel.setData(oJsonData);
			sap.ui.getCore().setModel(oJsonDataModel,"oJsonDataModel");
			this.getView().setModel(oJsonDataModel,"oJsonDataModel");
		},
		onValidationCheck: function () {

			var bAllFilled = true;
			var bAllValid = true;

			var sEmpid = this.getView().byId("idEmpID").getValue();
			var sEmpfname = this.getView().byId("idEmpFN").getValue();
			var sEmplname = this.getView().byId("idEmpLN").getValue();
			var sEmpdesig = this.getView().byId("idDesign").getValue();
			var sEmailId = this.getView().byId("idEmail").getValue();

			this.getView().byId("idEmpID").setValueState("None");
			this.getView().byId("idEmpID").setValueStateText("");
			this.getView().byId("idEmpFN").setValueState("None");
			this.getView().byId("idEmpFN").setValueStateText("");
			this.getView().byId("idEmpLN").setValueState("None");
			this.getView().byId("idEmpLN").setValueStateText("");
			this.getView().byId("idDesign").setValueState("None");
			this.getView().byId("idDesign").setValueStateText("");
			this.getView().byId("idEmail").setValueState("None");
			this.getView().byId("idEmail").setValueStateText("");

			if (sEmpid === "") {
				bAllFilled = false;
				this.getView().byId("idEmpID").setValueState("Warning");
				this.getView().byId("idEmpID").setValueStateText("Please Enter EmpId");
			}

			if (sEmpfname === "") {
				bAllFilled = false;
				this.getView().byId("idEmpFN").setValueState("Error");
				this.getView().byId("idEmpFN").setValueStateText("Please Enter FirstName");
			}
			if (sEmplname === "") {
				bAllFilled = false;
				this.getView().byId("idEmpLN").setValueState("Error");
				this.getView().byId("idEmpLN").setValueStateText("Please Enter LastName");
			}
			if (sEmpdesig === "") {
				bAllFilled = false;
				this.getView().byId("idDesign").setValueState("Error");
				this.getView().byId("idDesign").setValueStateText("Please Enter LastName");
			}
			if (sEmailId === "") {
				bAllFilled = false;
				this.getView().byId("idEmail").setValueState("Error");
				this.getView().byId("idEmail").setValueStateText("Please Enter LastName");
			}

			if (bAllFilled === true && bAllValid === true) {
				
					MessageBox.confirm("Data Saved Successfully");
				}

		}
	});
});