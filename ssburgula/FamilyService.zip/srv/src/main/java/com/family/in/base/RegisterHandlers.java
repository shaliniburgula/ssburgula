// Note: Customizations placed in this file might be lost if the OData service is regenerated!
// Please place any customizations of handler registration in the ProviderSettings class.

package com.family.in.base;

import com.sap.cloud.server.odata.*;

class RegisterHandlers {
    private static EntityHandler handler_Details;

    public static void withServlet(com.family.in.MainServlet servlet) {
        com.family.in.proxy.InService service = (com.family.in.proxy.InService)servlet.getDataService();
        handler_Details = new com.family.in.handler.DetailsHandler(servlet, service);
        servlet.registerEntityHandler(com.family.in.proxy.InServiceMetadata.EntityTypes.details, handler_Details);
    }
}
