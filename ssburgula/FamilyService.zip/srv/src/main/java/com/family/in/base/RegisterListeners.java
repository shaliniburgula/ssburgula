// Note: Customizations placed in this file might be lost if the OData service is regenerated!
// Please place any customizations of listener registration in the ProviderSettings class.

package com.family.in.base;

import com.sap.cloud.server.odata.*;

class RegisterListeners {
    private static EntityListener detailsListener;

    public static void withServlet(com.family.in.MainServlet servlet) {
        com.family.in.proxy.InService service = (com.family.in.proxy.InService)servlet.getDataService();
        detailsListener = new com.family.in.listener.DetailsListener(servlet, service);
        servlet.registerEntityListener(com.family.in.proxy.InServiceMetadata.EntityTypes.details, detailsListener);
    }
}
