//# xsc 20.1.2-a5868d-20200407

package com.family.in.proxy;

public abstract class InServiceMetadata
{
    public static final com.sap.cloud.server.odata.csdl.CsdlDocument document = com.family.in.proxy.InServiceMetadata.resolve();

    public static final com.sap.cloud.server.odata.MetadataLock lock = new com.sap.cloud.server.odata.MetadataLock();

    private static com.sap.cloud.server.odata.csdl.CsdlDocument resolve()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:165:12
        com.family.in.proxy.internal.InServiceFactory.registerAll();
        com.family.in.proxy.internal.InServiceMetadataParser.parsed.setGeneratedProxies(true);
        return com.family.in.proxy.internal.InServiceMetadataParser.parsed;
    }

    public abstract static class EntityTypes
    {
        public static final com.sap.cloud.server.odata.EntityType details = com.family.in.proxy.internal.InServiceMetadataParser.parsed.getEntityType("com.family.in.Details");
    }

    public abstract static class EntitySets
    {
        public static final com.sap.cloud.server.odata.EntitySet detailsSet = com.family.in.proxy.internal.InServiceMetadataParser.parsed.getEntitySet("DetailsSet");
    }
}
