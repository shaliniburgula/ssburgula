//# xsc 20.1.2-a5868d-20200407

package com.family.in.proxy;

public class Details
    extends com.sap.cloud.server.odata.EntityValue
{
    public static final com.sap.cloud.server.odata.Property birth = com.family.in.proxy.InServiceMetadata.EntityTypes.details.getProperty("Birth");

    public static final com.sap.cloud.server.odata.Property detailsID = com.family.in.proxy.InServiceMetadata.EntityTypes.details.getProperty("DetailsID");

    public static final com.sap.cloud.server.odata.Property marriedTo = com.family.in.proxy.InServiceMetadata.EntityTypes.details.getProperty("MarriedTo");

    public static final com.sap.cloud.server.odata.Property name = com.family.in.proxy.InServiceMetadata.EntityTypes.details.getProperty("Name");

    public static final com.sap.cloud.server.odata.Property profession = com.family.in.proxy.InServiceMetadata.EntityTypes.details.getProperty("Profession");

    public Details()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:35:5
        this(true);
    }

    public Details(final boolean withDefaults)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:35:5
        super(withDefaults, com.family.in.proxy.InServiceMetadata.EntityTypes.details);
    }

    public com.family.in.proxy.Details copy()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:20:5
        return com.family.in.proxy.internal.Any_as_com_family_in_proxy_Details.cast(this.copyEntity());
    }

    public String getBirth()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:58:5
        return com.sap.cloud.server.odata.StringValue.unwrap(this.getDataValue(com.family.in.proxy.Details.birth));
    }

    public long getDetailsID()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:71:5
        return com.sap.cloud.server.odata.LongValue.unwrap(this.getDataValue(com.family.in.proxy.Details.detailsID));
    }

    public String getMarriedTo()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:84:5
        return com.sap.cloud.server.odata.StringValue.unwrap(this.getDataValue(com.family.in.proxy.Details.marriedTo));
    }

    public String getName()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:97:5
        return com.sap.cloud.server.odata.StringValue.unwrap(this.getDataValue(com.family.in.proxy.Details.name));
    }

    public com.family.in.proxy.Details getOld()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:15:5
        return com.family.in.proxy.internal.Any_as_com_family_in_proxy_Details.cast(this.getOldEntity());
    }

    public String getProfession()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:110:5
        return com.sap.cloud.server.odata.StringValue.unwrap(this.getDataValue(com.family.in.proxy.Details.profession));
    }

    @java.lang.Override public boolean isProxy()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:8:5
        return true;
    }

    public static com.sap.cloud.server.odata.EntityKey key(final long detailsID)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:25:12
        return new com.sap.cloud.server.odata.EntityKey().with("DetailsID", com.sap.cloud.server.odata.LongValue.of(detailsID));
    }

    public static com.family.in.proxy.DetailsList list(final com.sap.cloud.server.odata.EntityValueList from)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:30:12
        return com.family.in.proxy.DetailsList.share(from);
    }

    public void setBirth(final String value)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:63:5
        this.setDataValue(com.family.in.proxy.Details.birth, com.sap.cloud.server.odata.StringValue.of(value));
    }

    public void setDetailsID(final long value)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:76:5
        this.setDataValue(com.family.in.proxy.Details.detailsID, com.sap.cloud.server.odata.LongValue.of(value));
    }

    public void setMarriedTo(final String value)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:89:5
        this.setDataValue(com.family.in.proxy.Details.marriedTo, com.sap.cloud.server.odata.StringValue.of(value));
    }

    public void setName(final String value)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:102:5
        this.setDataValue(com.family.in.proxy.Details.name, com.sap.cloud.server.odata.StringValue.of(value));
    }

    public void setProfession(final String value)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:115:5
        this.setDataValue(com.family.in.proxy.Details.profession, com.sap.cloud.server.odata.StringValue.of(value));
    }
}
