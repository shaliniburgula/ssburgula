//# xsc 20.1.2-a5868d-20200407

package com.family.in.proxy.internal;

public abstract class Any_as_com_family_in_proxy_Details
{
    public static com.family.in.proxy.Details cast(final Object value)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:340:35 => /usr/sap/ljs/xs-temp/xs-home/templates/List.xs:88:16 => /usr/sap/ljs/xs-temp/xs-home/templates/Any.as.xs:7:12
        if (value instanceof com.family.in.proxy.Details)
        {
            final com.family.in.proxy.Details var_value = ((com.family.in.proxy.Details)value);
            return var_value;
        }
        else
        {
            throw com.sap.cloud.server.odata.core.CastException.cannotCast(value, "com.family.in.proxy.Details");
        }
    }
}
