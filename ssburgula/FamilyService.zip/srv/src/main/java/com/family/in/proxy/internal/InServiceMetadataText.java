//# xsc 20.1.2-a5868d-20200407

package com.family.in.proxy.internal;

public abstract class InServiceMetadataText
{
    public static final String XML = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<edmx:Edmx Version=\"1.0\" xmlns:edmx=\"http://schemas.microsoft.com/ado/2007/06/edmx\" xmlns:edmx4=\"http://docs.oasis-open.org/odata/ns/edmx\" xmlns:m=\"http://schemas.microsoft.com/ado/2007/08/dataservices/metadata\">\n<edmx4:Reference Uri=\"vocabularies/com.sap.cloud.server.odata.sql.v1.xml\">\n<edmx4:Include Namespace=\"com.sap.cloud.server.odata.sql.v1\" Alias=\"SQL\"/>\n</edmx4:Reference>\n<edmx:DataServices m:DataServiceVersion=\"2.0\">\n<Schema Namespace=\"com.family.in\" xmlns=\"http://schemas.microsoft.com/ado/2008/09/edm\">\n<EntityType Name=\"Details\">\n<Key>\n<PropertyRef Name=\"DetailsID\"/>\n</Key>\n<Property Name=\"Birth\" Type=\"Edm.String\" Nullable=\"false\" MaxLength=\"20\"/>\n<Property Name=\"DetailsID\" Type=\"Edm.Int64\" Nullable=\"false\"/>\n<Property Name=\"MarriedTo\" Type=\"Edm.String\" Nullable=\"false\" MaxLength=\"100\"/>\n<Property Name=\"Name\" Type=\"Edm.String\" Nullable=\"false\" MaxLength=\"100\"/>\n<Property Name=\"Profession\" Type=\"Edm.String\" Nullable=\"false\" MaxLength=\"100\"/>\n</EntityType>\n<EntityContainer Name=\"InService\" m:IsDefaultEntityContainer=\"true\">\n<Annotation Term=\"SQL.TrackChanges\" xmlns=\"http://docs.oasis-open.org/odata/ns/edm\"/>\n<EntitySet Name=\"DetailsSet\" EntityType=\"com.family.in.Details\"/>\n</EntityContainer>\n</Schema>\n</edmx:DataServices>\n</edmx:Edmx>\n";
}
