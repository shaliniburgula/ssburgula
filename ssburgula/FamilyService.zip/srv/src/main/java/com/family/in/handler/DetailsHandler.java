// Note: This handler will be overwritten if the service is regenerated.
// To allow customization and avoid overwriting upon service regeneration,
// please delete this comment.

package com.family.in.handler;

import com.sap.cloud.server.odata.*;

public class DetailsHandler extends com.sap.cloud.server.odata.DefaultEntityHandler {
    private com.family.in.MainServlet servlet;
    private com.family.in.proxy.InService service;

    public DetailsHandler(com.family.in.MainServlet servlet, com.family.in.proxy.InService service) {
        super(servlet, service);
        this.servlet = servlet;
        this.service = service;
        allowUnused(this.servlet);
        allowUnused(this.service);
    }

    @Override public DataValue executeQuery(DataQuery query) {
        return service.executeQuery(query).getResult();
    }

    @Override public void createEntity(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        service.createEntity(entity);
    }

    @Override public void updateEntity(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        entity.setMustBeModified(true);
        service.updateEntity(entity);
    }

    @Override public void deleteEntity(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        service.deleteEntity(entity);
    }
}
