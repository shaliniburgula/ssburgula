//# xsc 20.1.2-a5868d-20200407

package com.family.in.proxy;

public class InService
    extends com.sap.cloud.server.odata.DataService
{
    public InService()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:213:5
        this(null);
    }

    public InService(final com.sap.cloud.server.odata.DataServiceProvider provider)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:213:5
        super(com.sap.cloud.server.odata.MetadataOnlyProvider.newIfNull(provider, "InService"));
        this.getProvider().setMetadata(com.family.in.proxy.InServiceMetadata.document);
    }

    public com.family.in.proxy.Details getDetails(final com.sap.cloud.server.odata.DataQuery query)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:225:5
        return this.getDetails(query, null, null);
    }

    public com.family.in.proxy.Details getDetails(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:225:5
        return this.getDetails(query, headers, null);
    }

    public com.family.in.proxy.Details getDetails(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers, final com.sap.cloud.server.odata.RequestOptions options)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:225:5
        final com.sap.cloud.server.odata.http.HttpHeaders var_headers = com.sap.cloud.server.odata.http.HttpHeaders.emptyIfNull(headers);
        final com.sap.cloud.server.odata.RequestOptions var_options = com.sap.cloud.server.odata.RequestOptions.noneIfNull(options);
        return com.family.in.proxy.internal.Any_as_com_family_in_proxy_Details.cast(this.executeQuery(query.fromDefault(com.family.in.proxy.InServiceMetadata.EntitySets.detailsSet), var_headers, var_options).getRequiredEntity());
    }

    public com.family.in.proxy.DetailsList getDetailsSet()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:240:5
        return this.getDetailsSet(null, null, null);
    }

    public com.family.in.proxy.DetailsList getDetailsSet(final com.sap.cloud.server.odata.DataQuery query)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:240:5
        return this.getDetailsSet(query, null, null);
    }

    public com.family.in.proxy.DetailsList getDetailsSet(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:240:5
        return this.getDetailsSet(query, headers, null);
    }

    public com.family.in.proxy.DetailsList getDetailsSet(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers, final com.sap.cloud.server.odata.RequestOptions options)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:240:5
        final com.sap.cloud.server.odata.DataQuery var_query = com.sap.cloud.server.odata.DataQuery.newIfNull(query);
        final com.sap.cloud.server.odata.http.HttpHeaders var_headers = com.sap.cloud.server.odata.http.HttpHeaders.emptyIfNull(headers);
        final com.sap.cloud.server.odata.RequestOptions var_options = com.sap.cloud.server.odata.RequestOptions.noneIfNull(options);
        return com.family.in.proxy.Details.list(this.executeQuery(var_query.fromDefault(com.family.in.proxy.InServiceMetadata.EntitySets.detailsSet), var_headers, var_options).getEntityList());
    }

    public com.family.in.proxy.Details getDetailsWithKey(final long detailsID)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:233:5
        return this.getDetailsWithKey(detailsID, null, null, null);
    }

    public com.family.in.proxy.Details getDetailsWithKey(final long detailsID, final com.sap.cloud.server.odata.DataQuery query)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:233:5
        return this.getDetailsWithKey(detailsID, query, null, null);
    }

    public com.family.in.proxy.Details getDetailsWithKey(final long detailsID, final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:233:5
        return this.getDetailsWithKey(detailsID, query, headers, null);
    }

    public com.family.in.proxy.Details getDetailsWithKey(final long detailsID, final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers, final com.sap.cloud.server.odata.RequestOptions options)
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:233:5
        final com.sap.cloud.server.odata.DataQuery var_query = com.sap.cloud.server.odata.DataQuery.newIfNull(query);
        return this.getDetails(var_query.withKey(com.family.in.proxy.Details.key(detailsID)), headers, options);
    }

    @java.lang.Override public com.sap.cloud.server.odata.MetadataLock getMetadataLock()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:200:5
        return com.family.in.proxy.InServiceMetadata.lock;
    }

    @java.lang.Override public void refreshMetadata()
    {
        synchronized (this)
        {
            //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:219:19
            com.sap.cloud.server.odata.ProxyInternal.noRefreshMetadata();
        }
    }
}
