package com.family.in.listener;

import com.sap.cloud.server.odata.*;

public class DetailsListener extends com.sap.cloud.server.odata.DefaultEntityListener {
    private com.family.in.MainServlet servlet;
    private com.family.in.proxy.InService service;

    public DetailsListener(com.family.in.MainServlet servlet, com.family.in.proxy.InService service) {
        super();
        this.servlet = servlet;
        this.service = service;
        allowUnused(this.servlet);
        allowUnused(this.service);
    }

    @Override public void beforeQuery(DataQuery query) {
        allowUnused(query);
    }

    public void beforeSave(EntityValue entityValue) {
        // Shared code for beforeCreate / beforeUpdate.
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
    }

    @Override public void beforeCreate(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
        beforeSave(entity);
    }

    @Override public void beforeUpdate(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
        beforeSave(entity);
    }

    @Override public void beforeDelete(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
    }

    public void afterSave(EntityValue entityValue) {
        // Shared code for afterCreate / afterUpdate.
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
    }

    @Override public void afterCreate(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
        afterSave(entity);
    }

    @Override public void afterUpdate(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
        afterSave(entity);
    }

    @Override public void afterDelete(EntityValue entityValue) {
        com.family.in.proxy.Details entity = (com.family.in.proxy.Details)entityValue;
        allowUnused(entity);
    }
}
