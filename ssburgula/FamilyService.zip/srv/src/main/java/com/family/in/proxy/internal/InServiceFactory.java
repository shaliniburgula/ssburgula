//# xsc 20.1.2-a5868d-20200407

package com.family.in.proxy.internal;

public abstract class InServiceFactory
{
    public static void registerAll()
    {
        //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:175:12
        com.family.in.proxy.InServiceMetadata.EntityTypes.details.registerFactory(new com.family.in.proxy.internal.InServiceFactory.CreateDetails());
    }

    public static class CreateDetails
    extends com.sap.cloud.server.odata.core.ObjectFactory
    {
        @java.lang.Override public Object create()
        {
            //# /usr/sap/ljs/xs-temp/030ede1e-6351-4981-9cbc-d2f692550b4e/output/target/tmp/proxy-com.family.in.csdl.xs:189:9
            return new com.family.in.proxy.Details(false);
        }
    }
}
