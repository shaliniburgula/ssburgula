package com.family.in;

public abstract class LogSettings {
    public static final boolean PRETTY_TRACING = true;
}
