For each entity set, test data can optionally be provided in a file *EntitySetName.json*.

Test data is available only in "test mode", not in production mode.

Please refer to the generated TestSettings class to see the options for enabling test mode.

Sample test data for file DetailsSet.json:

''' JSON
[
    {
        "Birth": "ABCDEFGHIJKLMNOPQRST",
        "DetailsID": "101",
        "MarriedTo": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "Name": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "Profession": "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    },
    {
        "Birth": "XYZ",
        "DetailsID": "102",
        "MarriedTo": "XYZ",
        "Name": "XYZ",
        "Profession": "XYZ"
    }
]
'''
