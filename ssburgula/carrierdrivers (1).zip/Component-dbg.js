sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("au.com.caltex.carrierdrivers.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});