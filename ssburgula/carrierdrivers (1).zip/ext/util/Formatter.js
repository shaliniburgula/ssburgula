sap.ui.define(["sap/ui/core/format/DateFormat"], function (t) {
	"use strict";
	return {
		getDriverStatusColour: function (t) {
			return t.PasswordFailed ? "Negative" : "Critical"
		},
		getDriverStatusVisibility: function (t) {
			return t.PasswordFailed || t.PasswordBeingSet || !t.CreationComplete
		}
	}
});