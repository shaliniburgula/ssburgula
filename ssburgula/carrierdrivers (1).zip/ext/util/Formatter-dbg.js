sap.ui.define(["sap/ui/core/format/DateFormat"], function (DateFormat) {
	"use strict";
	return {
		getDriverStatusColour: function (driver) {
			return (driver.PasswordFailed) ? "Negative" : "Critical";
		},
		
		getDriverStatusVisibility: function (driver) {
			return (driver.PasswordFailed || driver.PasswordBeingSet || !driver.CreationComplete);
		}
	};
});