sap.ui.controller("au.com.caltex.carrierdrivers.ext.controller.ObjectPageExt", {
	onInit: function (e) {
		this.oPasswordPolicy = {
			minimumPasswordLength: 8,
			allowedFailedLoginAttempts: 5,
			passwordLockingPeriodHours: 1,
			maximumPasswordLength: 255,
			minimumPasswordAgeHours: 1,
			isSystem: false,
			passwordHistoryEntryCount: 5,
			name: "CaltexExternal",
			requiredCharacterGroupsCount: 3,
			requiredCharacterGroupsCountText: "three",
			requiredCharacterGroups: "[[a-z], [A-Z], [0-9], [^a-zA-Z0-9]]",
			maximumPasswordAgeMonths: 3,
			id: "5dfb072a95f380103f16974f",
			passwordPolicyStrength: 2,
			maximumPasswordNotUsedPeriodMonths: 3
		};
		this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(this.oPasswordPolicy), "PasswordPolicy");
		this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		var t = this.getOwnerComponent().getModel("ui");
		if (t !== undefined) {
			t.setProperty("/inputOk", false)
		}
		this.extensionAPI.attachPageDataLoaded(function (e) {
			var t = this.getOwnerComponent().getModel();
			var s = e.context.getPath();
			var r = t.getProperty(s);
			var o = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--action::ResetPassword");
			if (o !== undefined) {
				var i = this.oResourceBundle.getText("RESET_PASSWORD_TIP");
				if (!r.CreationComplete) {
					i = this.oResourceBundle.getText("DRIVER_NOT_COMPLETE")
				} else if (r.PasswordBeingSet) {
					i = this.oResourceBundle.getText("PASSWORD_BEING_SET")
				}
				o.setTooltip(i)
			}
			if (!r.CreationComplete) {
				var a = sap.ui.getCore().byId("au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--edit");
				if (a !== undefined) {
					a.setTooltip(this.oResourceBundle.getText("DRIVER_NOT_COMPLETE"))
				}
			}
			var n = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DefaultTerminalsFacet::responsiveTable"
			);
			if (n !== undefined) {
				n.setProperty("noDataText", this.oResourceBundle.getText("NO_DEFAULT_TERMINALS"))
			}
			var c = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DetailsFacet::FirstName::Field");
			if (c !== undefined) {
				c.oninput = this.onFirstNameChange.bind(this)
			}
			var d = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DetailsFacet::LastName::Field");
			if (d !== undefined) {
				d.oninput = this.onLastNameChange.bind(this)
			}
			var u = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DetailsFacet::LicenceNo::Field");
			if (u !== undefined) {
				u.oninput = this.onLicenceNoChange.bind(this)
			}
			this.checkPasswordPolicy("", "initial");
			var l = this.getOwnerComponent().getModel("ui");
			if (l !== undefined) {
				if (l.getProperty("/createMode")) {
					l.setProperty("/inputOk", false);
					this.oInputFieldsOk = {
						firstName: false,
						lastName: false,
						licenceNo: false,
						password: false
					}
				} else {
					l.setProperty("/editable", false);
					l.setProperty("/inputOk", true);
					this.oInputFieldsOk = {
						firstName: true,
						lastName: true,
						licenceNo: true,
						password: true
					}
				}
			}
		}.bind(this))
	},
	beforeLineItemDeleteExtension: function (e) {
		var t = {};
		if (e.sUiElementId ===
			"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DefaultTerminalsFacet::responsiveTable"
		) {
			t = {
				title: this.oResourceBundle.getText("DEFAULT_TERMINAL"),
				text: this.oResourceBundle.getText("DELETE_DEFAULT_TERMINAL"),
				undeletableText: ""
			}
		}
		return t
	},
	checkPasswordPolicy: function (e, t) {
		var s = this.checkPasswordLength(e, t) === 1;
		if (!this.checkPasswordNoSpace(e, t)) {
			s = false
		}
		if (!this.checkPasswordCategories(e, t)) {
			s = false
		}
		return s
	},
	checkPasswordNoSpace: function (e, t) {
		var s = e.search(/\s/) === -1;
		var r = this.byId(t + "PasswordErrorText");
		if (r === undefined) {
			r = sap.ui.getCore().byId(t + "PasswordErrorText")
		}
		if (r !== undefined) {
			if (s) {
				r.removeStyleClass("sapUiSmallMargin").setText("")
			} else {
				r.addStyleClass("sapUiSmallMargin").setText("Spaces not allowed in the password.")
			}
		}
		return s
	},
	checkPasswordLength: function (e, t) {
		var s = e.length < this.oPasswordPolicy.minimumPasswordLength ? 0 : 1;
		this.checkPasswordHintUpdate(t + "PasswordCheckLength", s);
		return s
	},
	checkPasswordCategories: function (e, t) {
		return this.oPasswordPolicy.requiredCharacterGroupsCount <= this.checkPasswordUpper(e, t) + this.checkPasswordLower(e, t) + this.checkPasswordNumber(
			e, t) + this.checkPasswordSymbol(e, t)
	},
	checkPasswordUpper: function (e, t) {
		var s = e.search(/[A-Z]/) === -1 ? 0 : 1;
		this.checkPasswordHintUpdate(t + "PasswordCheckUpper", s);
		return s
	},
	checkPasswordLower: function (e, t) {
		var s = e.search(/[a-z]/) === -1 ? 0 : 1;
		this.checkPasswordHintUpdate(t + "PasswordCheckLower", s);
		return s
	},
	checkPasswordNumber: function (e, t) {
		var s = e.search(/[0-9]/) === -1 ? 0 : 1;
		this.checkPasswordHintUpdate(t + "PasswordCheckNumber", s);
		return s
	},
	checkPasswordSymbol: function (e, t) {
		var s = e.search(/[^a-zA-Z0-9]/) === -1 ? 0 : 1;
		this.checkPasswordHintUpdate(t + "PasswordCheckSymbol", s);
		return s
	},
	checkPasswordHintUpdate: function (e, t) {
		var s = this.byId(e);
		if (s === undefined) {
			s = sap.ui.getCore().byId(e)
		}
		if (s !== undefined) {
			if (t === 0) {
				s.setSelected(false);
				s.setValueState("None")
			} else {
				s.setSelected(true);
				s.setValueState("Success")
			}
		}
	},
	onFirstNameChange: function (e) {
		var t = e.getSource ? e.getSource().getValue() : e.srcControl.getValue();
		this.oInputFieldsOk.firstName = t.trim().length > 0;
		this.checkInput()
	},
	onLastNameChange: function (e) {
		var t = e.getSource ? e.getSource().getValue() : e.srcControl.getValue();
		this.oInputFieldsOk.lastName = t.trim().length > 0;
		this.checkInput()
	},
	onLicenceNoChange: function (e) {
		var t = e.getSource ? e.getSource().getValue() : e.srcControl.getValue();
		this.oInputFieldsOk.licenceNo = t.trim().length > 0;
		this.checkInput()
	},
	onInitialPasswordChange: function (e) {
		this.oInputFieldsOk.password = this.checkPasswordPolicy(e.getSource().getValue(), "initial");
		this.checkInput(e.getSource().getBindingContext().getPath())
	},
	checkInput: function () {
		var e = this.getOwnerComponent().getModel("ui");
		if (e !== undefined) {
			var t = (!e.getProperty("/createMode") || this.oInputFieldsOk.password) && this.oInputFieldsOk.firstName && this.oInputFieldsOk.lastName &&
				this.oInputFieldsOk.licenceNo;
			e.setProperty("/inputOk", t)
		}
	},
	onResetPassword: function (e) {
		var t = this;
		var s = this.getOwnerComponent().getModel();
		var r = e.getSource().getBindingContext().getPath();
		var o = new sap.m.Dialog({
			title: this.oResourceBundle.getText("RESET_DRIVER_PASSWORD"),
			type: "Message",
			content: [new sap.m.Label({
				text: this.oResourceBundle.getText("NEW_PASSWORD"),
				labelFor: "resetPasswordText"
			}), new sap.m.Input("resetPasswordText", {
				liveChange: function (e) {
					e.getSource().getParent().getBeginButton().setEnabled(t.checkPasswordPolicy(e.getParameter("value"), "reset"))
				},
				width: "100%",
				placeholder: this.oResourceBundle.getText("ENTER_NEW_PASSWORD")
			}), new sap.m.ObjectStatus("resetPasswordErrorText", {
				text: "",
				state: "Error"
			}), new sap.m.VBox({
				items: [new sap.m.Label({
					text: this.oResourceBundle.getText("PASSWORD_MUST")
				}), new sap.m.CheckBox("resetPasswordCheckLength", {
					editable: false,
					text: this.oResourceBundle.getText("MINIMUM_LENGTH", t.oPasswordPolicy.minimumPasswordLength)
				}), new sap.m.Label({
					text: this.oResourceBundle.getText("MINIMUM_GROUPS", t.oPasswordPolicy.requiredCharacterGroupsCountText)
				}), new sap.m.CheckBox("resetPasswordCheckUpper", {
					editable: false,
					text: this.oResourceBundle.getText("UPPERCASE_LETTERS")
				}), new sap.m.CheckBox("resetPasswordCheckLower", {
					editable: false,
					text: this.oResourceBundle.getText("LOWERCASE_LETTERS")
				}), new sap.m.CheckBox("resetPasswordCheckNumber", {
					editable: false,
					text: this.oResourceBundle.getText("NUMBERS")
				}), new sap.m.CheckBox("resetPasswordCheckSymbol", {
					editable: false,
					text: this.oResourceBundle.getText("SYMBOLS")
				}), new sap.m.Label({
					text: this.oResourceBundle.getText("PLEASE_NOTE") + " " + this.oResourceBundle.getText("LAST_N_FAIL", t.oPasswordPolicy.passwordHistoryEntryCount)
				}), new sap.m.Label({
					text: this.oResourceBundle.getText("LOCKING_PERIOD", [t.oPasswordPolicy.passwordLockingPeriodHours + (t.oPasswordPolicy.passwordLockingPeriodHours ===
						1 ? " hour" : " hours"), t.oPasswordPolicy.allowedFailedLoginAttempts])
				})]
			})],
			beginButton: new sap.m.Button({
				type: sap.m.ButtonType.Emphasized,
				text: this.oResourceBundle.getText("SUBMIT"),
				enabled: false,
				press: function () {
					sap.ui.getCore().byId("resetPasswordErrorText").removeStyleClass("sapUiSmallMargin").setText("");
					var e = sap.ui.getCore().byId("resetPasswordText").getValue();
					if (e.length > 0) {
						s.setProperty(r + "/Password", e);
						s.submitChanges({
							success: function (e, t) {
								var i = true;
								var a = "";
								if (e.__batchResponses.length > 0) {
									var n = e.__batchResponses[0];
									var c = {};
									if (n.__changeResponses !== undefined && n.__changeResponses !== null && n.__changeResponses.length > 0) {
										c = n.__changeResponses[0]
									} else if (n.response !== undefined) {
										c = n.response
									}
									if (c.statusCode === "400") {
										i = false;
										var d = JSON.parse(c.body);
										a = d.error.message.value
									}
								}
								if (i) {
									sap.m.MessageToast.show(this.oResourceBundle.getText("PASSWORD_UPDATED"));
									s.read(r);
									o.close()
								} else {
									sap.ui.getCore().byId("resetPasswordErrorText").addStyleClass("sapUiSmallMargin").setText(a)
								}
							}.bind(t),
							error: function (e) {
								sap.ui.getCore().byId("resetPasswordErrorText").addStyleClass("sapUiSmallMargin").setText(this.oResourceBundle.getText(
									"PASSWORD_ERROR"))
							}.bind(t)
						})
					}
				}
			}),
			endButton: new sap.m.Button({
				text: "Cancel",
				press: function () {
					s.setProperty(r + "/Password", "");
					o.close()
				}
			}),
			afterClose: function () {
				o.destroy()
			}
		});
		o.open()
	},
	onAddTerminal: function (e) {
		var t = e.getSource().getBindingContext().getPath();
		var s = this.getOwnerComponent().getModel();
		if (this.ShippingPoints) {
			this.onAddTerminalPrompt(s, t)
		} else {
			s.read("/ShippingPoints", {
				success: function (e) {
					this.ShippingPoints = new sap.ui.model.json.JSONModel(e);
					sap.ui.getCore().setModel(this.ShippingPoints, "ShippingPoints");
					this.onAddTerminalPrompt(s, t)
				}.bind(this)
			})
		}
	},
	onAddTerminalPrompt: function (e, t) {
		var s = this.oResourceBundle;
		var r = new sap.m.Dialog({
			title: s.getText("ADD_DEFAULT_TERMINAL"),
			type: "Message",
			content: [new sap.m.Label({
				text: s.getText("DEFAULT_TERMINAL"),
				labelFor: "defaultTerminalDropDown"
			}), new sap.m.ComboBox("defaultTerminalDropDown", {
				items: {
					path: "ShippingPoints>/results",
					template: new sap.ui.core.Item({
						key: "{ShippingPoints>ShippingPointId}",
						text: "{ShippingPoints>ShippingPointName}"
					})
				},
				selectionChange: function (e) {
					var t = e.getSource().getParent();
					t.getBeginButton().setEnabled(e.getSource().getSelectedKey().length > 0)
				},
				width: "100%",
				placeholder: s.getText("DEFAULT_TERMINAL_PLACEHOLDER")
			})],
			beginButton: new sap.m.Button({
				type: sap.m.ButtonType.Emphasized,
				text: s.getText("ADD"),
				enabled: false,
				press: function (o) {
					o.getSource().setEnabled(false);
					var i = sap.ui.getCore().byId("defaultTerminalDropDown").getSelectedKey();
					if (i.length > 0) {
						e.create(t + "/ShippingPointPreferences", {
							ShippingPointId: i
						}, {
							success: function (o) {
								r.close();
								sap.m.MessageToast.show(s.getText("DEFAULT_TERMINAL_ADDED"));
								e.read(t + "/ShippingPointPreferences", {
									success: function () {
										var e = sap.ui.getCore().byId(
											"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DefaultTerminalsFacet::responsiveTable"
										);
										if (e !== undefined) {
											e.getBinding("items").refresh()
										}
									}
								})
							},
							error: function (e) {
								o.getSource().setEnabled(true);
								sap.m.MessageToast.show(s.getText("DEFAULT_TERMINAL_ERROR"))
							}
						})
					}
				}
			}),
			endButton: new sap.m.Button({
				text: s.getText("CANCEL"),
				press: function () {
					r.close()
				}
			}),
			afterClose: function () {
				r.destroy()
			}
		});
		r.open()
	}
});