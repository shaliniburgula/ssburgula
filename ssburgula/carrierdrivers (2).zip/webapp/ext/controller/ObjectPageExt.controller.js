sap.ui.controller("au.com.caltex.carrierdrivers.ext.controller.ObjectPageExt", {
	onInit: function (oEvent) {
		// Ideally, we would retrieve this config from the URI below, but it shouldn't change, so let's hardcode it.
		this.oPasswordPolicy = {
			"minimumPasswordLength": 8,
			"allowedFailedLoginAttempts": 5,
			"passwordLockingPeriodHours": 1,
			"maximumPasswordLength": 255,
			"minimumPasswordAgeHours": 1,
			//"uri": "https:\/\/arksfzonh.accounts.ondemand.com\/service\/password\/policy\/5dfb072a95f380103f16974f\/1.0",
			"isSystem": false,
			"passwordHistoryEntryCount": 5,
			"name": "CaltexExternal",
			"requiredCharacterGroupsCount": 3,
			"requiredCharacterGroupsCountText": "three",
			"requiredCharacterGroups": "[[a-z], [A-Z], [0-9], [^a-zA-Z0-9]]",
			"maximumPasswordAgeMonths": 3,
			"id": "5dfb072a95f380103f16974f",
			"passwordPolicyStrength": 2,
			"maximumPasswordNotUsedPeriodMonths": 3
		};

		this.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(this.oPasswordPolicy), "PasswordPolicy");
		this.oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		var oUIModel = this.getOwnerComponent().getModel("ui");
		if (oUIModel !== undefined) {
			oUIModel.setProperty("/inputOk", false);
		}

		this.extensionAPI.attachPageDataLoaded(function (oLoadedEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var sPath = oLoadedEvent.context.getPath();
			var oDriver = oModel.getProperty(sPath);

			var oPasswordResetBtn = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--action::ResetPassword");
			if (oPasswordResetBtn !== undefined) {
				var sPasswordResetTooltip = this.oResourceBundle.getText("RESET_PASSWORD_TIP");
				if (!oDriver.CreationComplete) {
					sPasswordResetTooltip = this.oResourceBundle.getText("DRIVER_NOT_COMPLETE");
				} else if (oDriver.PasswordBeingSet) {
					sPasswordResetTooltip = this.oResourceBundle.getText("PASSWORD_BEING_SET");
				}
				oPasswordResetBtn.setTooltip(sPasswordResetTooltip);
			}
			if (!oDriver.CreationComplete) {
				var oEditBtn = sap.ui.getCore().byId(
					"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--edit");
				if (oEditBtn !== undefined) {
					oEditBtn.setTooltip(this.oResourceBundle.getText("DRIVER_NOT_COMPLETE"));
				}
			}

			var oTable = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DefaultTerminalsFacet::responsiveTable"
			);
			if (oTable !== undefined) {
				oTable.setProperty("noDataText", this.oResourceBundle.getText("NO_DEFAULT_TERMINALS"));
			}

			var oFirstName = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DetailsFacet::FirstName::Field");
			if (oFirstName !== undefined) {
				oFirstName.oninput = this.onFirstNameChange.bind(this);
			}
			var oLastName = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DetailsFacet::LastName::Field");
			if (oLastName !== undefined) {
				oLastName.oninput = this.onLastNameChange.bind(this);
			}
			var oLicenceNo = sap.ui.getCore().byId(
				"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DetailsFacet::LicenceNo::Field");
			if (oLicenceNo !== undefined) {
				oLicenceNo.oninput = this.onLicenceNoChange.bind(this);
			}

			this.checkPasswordPolicy("", "initial");
			var oUiModel = this.getOwnerComponent().getModel("ui");
			if (oUiModel !== undefined) {
				if (oUiModel.getProperty("/createMode")) {
					oUiModel.setProperty("/inputOk", false);
					this.oInputFieldsOk = {
						"firstName": false,
						"lastName": false,
						"licenceNo": false,
						"password": false
					};
				} else {
					oUiModel.setProperty("/editable", false);
					oUiModel.setProperty("/inputOk", true);
					this.oInputFieldsOk = {
						"firstName": true,
						"lastName": true,
						"licenceNo": true,
						"password": true
					};
				}
			}
		}.bind(this));
	},

	beforeLineItemDeleteExtension: function (oBeforeLineItemDeleteProperties) {
		//Override the texts on the standard delete confirmation pop-up.
		var oLineItemDeleteConfig = {};
		if (oBeforeLineItemDeleteProperties.sUiElementId ===
			"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DefaultTerminalsFacet::responsiveTable"
		) {
			oLineItemDeleteConfig = {
				title: this.oResourceBundle.getText("DEFAULT_TERMINAL"),
				text: this.oResourceBundle.getText("DELETE_DEFAULT_TERMINAL"),
				undeletableText: ""
			};
		}
		return oLineItemDeleteConfig;
	},

	checkPasswordPolicy: function (sPassword, sIdPrefix) {
		//Check the entered password meets the password policy we will be enforcing on IAS.
		var bOk = (this.checkPasswordLength(sPassword, sIdPrefix) === 1);
		if (!this.checkPasswordNoSpace(sPassword, sIdPrefix)) {
			bOk = false;
		}
		if (!this.checkPasswordCategories(sPassword, sIdPrefix)) {
			bOk = false;
		}
		return bOk;
	},

	checkPasswordNoSpace: function (sPassword, sIdPrefix) {
		var bNoSpace = (sPassword.search(/\s/) === -1);
		var oErrorText = this.byId(sIdPrefix + "PasswordErrorText");
		if (oErrorText === undefined) {
			oErrorText = sap.ui.getCore().byId(sIdPrefix + "PasswordErrorText");
		}
		if (oErrorText !== undefined) {
			if (bNoSpace) {
				oErrorText.removeStyleClass("sapUiSmallMargin").setText("");
			} else {
				oErrorText.addStyleClass("sapUiSmallMargin").setText(
					"Spaces not allowed in the password.");
			}
		}
		return bNoSpace;
	},

	checkPasswordLength: function (sPassword, sIdPrefix) {
		var iCheck = (sPassword.length < this.oPasswordPolicy.minimumPasswordLength) ? 0 : 1;
		this.checkPasswordHintUpdate(sIdPrefix + "PasswordCheckLength", iCheck);
		return iCheck;
	},

	checkPasswordCategories: function (sPassword, sIdPrefix) {
		//IAS password policy is that the password must meet a minimum number of the categories checked for.
		//For example, at least 3 of the categories which can be to have an uppercase letter, a lowercase letter, a number, or a symbol in the password.
		return (this.oPasswordPolicy.requiredCharacterGroupsCount <= (this.checkPasswordUpper(sPassword, sIdPrefix) + this.checkPasswordLower(
				sPassword, sIdPrefix) +
			this.checkPasswordNumber(sPassword, sIdPrefix) + this.checkPasswordSymbol(sPassword, sIdPrefix)));
	},

	checkPasswordUpper: function (sPassword, sIdPrefix) {
		var iCheck = (sPassword.search(/[A-Z]/) === -1) ? 0 : 1;
		this.checkPasswordHintUpdate(sIdPrefix + "PasswordCheckUpper", iCheck);
		return iCheck;
	},

	checkPasswordLower: function (sPassword, sIdPrefix) {
		var iCheck = (sPassword.search(/[a-z]/) === -1) ? 0 : 1;
		this.checkPasswordHintUpdate(sIdPrefix + "PasswordCheckLower", iCheck);
		return iCheck;
	},

	checkPasswordNumber: function (sPassword, sIdPrefix) {
		var iCheck = (sPassword.search(/[0-9]/) === -1) ? 0 : 1;
		this.checkPasswordHintUpdate(sIdPrefix + "PasswordCheckNumber", iCheck);
		return iCheck;
	},

	checkPasswordSymbol: function (sPassword, sIdPrefix) {
		var iCheck = (sPassword.search(/[^a-zA-Z0-9]/) === -1) ? 0 : 1;
		this.checkPasswordHintUpdate(sIdPrefix + "PasswordCheckSymbol", iCheck);
		return iCheck;
	},

	checkPasswordHintUpdate: function (sId, iCheck) {
		var oHint = this.byId(sId);
		if (oHint === undefined) {
			oHint = sap.ui.getCore().byId(sId);
		}
		if (oHint !== undefined) {
			if (iCheck === 0) {
				oHint.setSelected(false);
				oHint.setValueState("None");
			} else {
				oHint.setSelected(true);
				oHint.setValueState("Success");
			}
		}
	},

	onFirstNameChange: function (oEvent) {
		var sValue = (oEvent.getSource) ? oEvent.getSource().getValue() : oEvent.srcControl.getValue();
		this.oInputFieldsOk.firstName = (sValue.trim().length > 0);
		this.checkInput();
	},

	onLastNameChange: function (oEvent) {
		var sValue = (oEvent.getSource) ? oEvent.getSource().getValue() : oEvent.srcControl.getValue();
		this.oInputFieldsOk.lastName = (sValue.trim().length > 0);
		this.checkInput();
	},

	onLicenceNoChange: function (oEvent) {
		var sValue = (oEvent.getSource) ? oEvent.getSource().getValue() : oEvent.srcControl.getValue();
		this.oInputFieldsOk.licenceNo = (sValue.trim().length > 0);
		this.checkInput();
	},

	onInitialPasswordChange: function (oEvent) {
		this.oInputFieldsOk.password = this.checkPasswordPolicy(oEvent.getSource().getValue(), "initial");
		this.checkInput(oEvent.getSource().getBindingContext().getPath());
	},

	checkInput: function () {
		var oUIModel = this.getOwnerComponent().getModel("ui");
		if (oUIModel !== undefined) {
			var bInputOk = ((!oUIModel.getProperty("/createMode") || this.oInputFieldsOk.password) && this.oInputFieldsOk.firstName && this.oInputFieldsOk
				.lastName && this.oInputFieldsOk.licenceNo);
			oUIModel.setProperty("/inputOk", bInputOk);
		}
	},

	onResetPassword: function (oEvent) {
		//Display a dialog to prompt user to enter a new password for the driver.
		var that = this;
		var oModel = this.getOwnerComponent().getModel();
		var sPath = oEvent.getSource().getBindingContext().getPath();

		var oDialog = new sap.m.Dialog({
			title: this.oResourceBundle.getText("RESET_DRIVER_PASSWORD"),
			type: "Message",
			content: [
				new sap.m.Label({
					text: this.oResourceBundle.getText("NEW_PASSWORD"),
					labelFor: "resetPasswordText"
				}),
				new sap.m.Input("resetPasswordText", {
					liveChange: function (oChangeEvent) {
						oChangeEvent.getSource().getParent().getBeginButton().setEnabled(that.checkPasswordPolicy(oChangeEvent.getParameter("value"),
							"reset"));
					},
					width: "100%",
					placeholder: this.oResourceBundle.getText("ENTER_NEW_PASSWORD")
				}),
				new sap.m.ObjectStatus("resetPasswordErrorText", {
					text: "",
					state: "Error"
				}),
				new sap.m.VBox({
					items: [new sap.m.Label({
							text: this.oResourceBundle.getText("PASSWORD_MUST")
						}),
						new sap.m.CheckBox("resetPasswordCheckLength", {
							editable: false,
							text: this.oResourceBundle.getText("MINIMUM_LENGTH", that.oPasswordPolicy.minimumPasswordLength)
						}),
						new sap.m.Label({
							text: this.oResourceBundle.getText("MINIMUM_GROUPS", that.oPasswordPolicy.requiredCharacterGroupsCountText)
						}),
						new sap.m.CheckBox("resetPasswordCheckUpper", {
							editable: false,
							text: this.oResourceBundle.getText("UPPERCASE_LETTERS")
						}),
						new sap.m.CheckBox("resetPasswordCheckLower", {
							editable: false,
							text: this.oResourceBundle.getText("LOWERCASE_LETTERS")
						}),
						new sap.m.CheckBox("resetPasswordCheckNumber", {
							editable: false,
							text: this.oResourceBundle.getText("NUMBERS")
						}),
						new sap.m.CheckBox("resetPasswordCheckSymbol", {
							editable: false,
							text: this.oResourceBundle.getText("SYMBOLS")
						}),
						new sap.m.Label({
							text: this.oResourceBundle.getText("PLEASE_NOTE") + " " + this.oResourceBundle.getText("LAST_N_FAIL", that.oPasswordPolicy.passwordHistoryEntryCount)
						}),
						new sap.m.Label({
							text: this.oResourceBundle.getText("LOCKING_PERIOD", [that.oPasswordPolicy.passwordLockingPeriodHours + ((that.oPasswordPolicy
								.passwordLockingPeriodHours === 1) ? " hour" : " hours"), that.oPasswordPolicy.allowedFailedLoginAttempts])
						})
					]
				})
			],
			beginButton: new sap.m.Button({
				type: sap.m.ButtonType.Emphasized,
				text: this.oResourceBundle.getText("SUBMIT"),
				enabled: false,
				press: function () {
					sap.ui.getCore().byId("resetPasswordErrorText").removeStyleClass("sapUiSmallMargin").setText("");
					var sText = sap.ui.getCore().byId("resetPasswordText").getValue();
					if (sText.length > 0) {
						oModel.setProperty(sPath + "/Password", sText);
						oModel.submitChanges({
							success: function (oData, response) {
								var bUpdateOk = true;
								var sErrorText = "";
								if (oData.__batchResponses.length > 0) {
									var batchResponse = oData.__batchResponses[0];
									var updateResponse = {};
									if (batchResponse.__changeResponses !== undefined && batchResponse.__changeResponses !== null && batchResponse.__changeResponses
										.length > 0) {
										updateResponse = batchResponse.__changeResponses[0];
									} else if (batchResponse.response !== undefined) {
										updateResponse = batchResponse.response;
									}

									if (updateResponse.statusCode === "400") {
										bUpdateOk = false;
										var oError = JSON.parse(updateResponse.body);
										sErrorText = oError.error.message.value;
									}
								}

								if (bUpdateOk) {
									sap.m.MessageToast.show(this.oResourceBundle.getText("PASSWORD_UPDATED"));
									oModel.read(sPath);
									oDialog.close();
								} else {
									sap.ui.getCore().byId("resetPasswordErrorText").addStyleClass("sapUiSmallMargin").setText(sErrorText);
								}
							}.bind(that),
							error: function (oError) {
								sap.ui.getCore().byId("resetPasswordErrorText").addStyleClass("sapUiSmallMargin").setText(
									this.oResourceBundle.getText("PASSWORD_ERROR"));
							}.bind(that)
						});
					}
				}
			}),
			endButton: new sap.m.Button({
				text: "Cancel",
				press: function () {
					oModel.setProperty(sPath + "/Password", "");
					oDialog.close();
				}
			}),
			afterClose: function () {
				oDialog.destroy();
			}
		});

		oDialog.open();
	},

	onAddTerminal: function (oEvent) {
		var sPath = oEvent.getSource().getBindingContext().getPath();
		var oModel = this.getOwnerComponent().getModel();
		if (this.ShippingPoints) {
			//Prompt user to enter a default terminal.
			this.onAddTerminalPrompt(oModel, sPath);
		} else {
			//Retrieve the possible Default Terminal entries if not already retrieved, and then prompt user to enter a default terminal.
			oModel.read("/ShippingPoints", {
				success: function (oData) {
					this.ShippingPoints = new sap.ui.model.json.JSONModel(oData);
					sap.ui.getCore().setModel(this.ShippingPoints, "ShippingPoints");
					this.onAddTerminalPrompt(oModel, sPath);
				}.bind(this)
			});
		}
	},

	onAddTerminalPrompt: function (oModel, sPath) {
		//Display a dialog to prompt user to enter a default terminal.
		var oResourceBundle = this.oResourceBundle;
		var oDialog = new sap.m.Dialog({
			title: oResourceBundle.getText("ADD_DEFAULT_TERMINAL"),
			type: "Message",
			content: [
				new sap.m.Label({
					text: oResourceBundle.getText("DEFAULT_TERMINAL"),
					labelFor: "defaultTerminalDropDown"
				}),
				new sap.m.ComboBox("defaultTerminalDropDown", {
					items: {
						path: "ShippingPoints>/results",
						template: new sap.ui.core.Item({
							key: "{ShippingPoints>ShippingPointId}",
							text: "{ShippingPoints>ShippingPointName}"
						})
					},
					selectionChange: function (oChangeEvent) {
						var parent = oChangeEvent.getSource().getParent();
						parent.getBeginButton().setEnabled(oChangeEvent.getSource().getSelectedKey().length > 0);
					},
					width: "100%",
					placeholder: oResourceBundle.getText("DEFAULT_TERMINAL_PLACEHOLDER")
				})
			],
			beginButton: new sap.m.Button({
				type: sap.m.ButtonType.Emphasized,
				text: oResourceBundle.getText("ADD"),
				enabled: false,
				press: function (oEvent) {
					oEvent.getSource().setEnabled(false);
					var sText = sap.ui.getCore().byId("defaultTerminalDropDown").getSelectedKey();
					if (sText.length > 0) {
						oModel.create(sPath + "/ShippingPointPreferences", {
							"ShippingPointId": sText
						}, {
							success: function (oData) {
								oDialog.close();
								sap.m.MessageToast.show(oResourceBundle.getText("DEFAULT_TERMINAL_ADDED"));
								oModel.read(sPath + "/ShippingPointPreferences", {
									success: function () {
										var oTable = sap.ui.getCore().byId(
											"au.com.caltex.carrierdrivers::sap.suite.ui.generic.template.ObjectPage.view.Details::Drivers--DefaultTerminalsFacet::responsiveTable"
										);
										if (oTable !== undefined) {
											oTable.getBinding("items").refresh();
										}
									}
								});
							},
							error: function (oError) {
								oEvent.getSource().setEnabled(true);
								sap.m.MessageToast.show(oResourceBundle.getText("DEFAULT_TERMINAL_ERROR"));
							}
						});
					}
				}
			}),
			endButton: new sap.m.Button({
				text: oResourceBundle.getText("CANCEL"),
				press: function () {
					oDialog.close();
				}
			}),
			afterClose: function () {
				oDialog.destroy();
			}
		});

		oDialog.open();
	}
});