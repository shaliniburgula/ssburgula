sap.ui.define([
	"tutorial/ui5/Fragments/test/unit/controller/View1.controller"
], function () {
	"use strict";
});