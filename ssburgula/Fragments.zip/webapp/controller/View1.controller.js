sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";
	var	testdialog;
	return Controller.extend("tutorial.ui5.Fragments.controller.View1", {

		onInit: function () {

		},
		onClick: function () {
			testdialog = sap.ui.xmlfragment("tutorial.ui5.Fragments.fragments.Dialog",
				this);
			testdialog.open();
		},
		onClose:function(){
			testdialog.close();
		}
	});
});