sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("tutorial.ui5.MasterDetail.controller.DetailObjectNotFound", {});
});
