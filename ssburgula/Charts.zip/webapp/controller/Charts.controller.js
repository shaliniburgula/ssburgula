sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("tutorial.ui5.Charts.controller.Charts", {
		onInit: function () {
			var oVizFrame = this.getView().byId("idVizFrame");

			var columnData = {
				"company": [{
					"year": "2001",
					"city1": 1,
					"city2": 2,
					"city3": 4

				}, {
					"year": "2002",
					"city1": 5,
					"city2": 6,
					"city3": 4
				}, {
					"year": "2003",
					"city1": 4,
					"city2": 8,
					"city3": 4

				}, {
					"year": "2004",
					"city1": 9,
					"city2": 10,
					"city3": 4

				}, {
					"year": "2005",
					"city1": 7,
					"city2": 20,
					"city3": 4

				}]
			};

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(columnData);
			oVizFrame.setModel(oModel);
			
		
            oVizFrame.setVizProperties({
                
                title: {
                    visible: true,
                    text: 'Year by City1 and City2 Details'
                },
                valueAxis: {
                    title: {
                        visible: true,
                        text: "Cities"
                    }
                },
                categoryAxis: {
                    title: {
                        visible: true,
                        text:"Year Details"
                    }
                }

            });

		}
	});
});