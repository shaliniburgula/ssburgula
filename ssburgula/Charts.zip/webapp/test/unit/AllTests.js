sap.ui.define([
	"tutorial/ui5/Charts/test/unit/controller/Charts.controller"
], function () {
	"use strict";
});