sap.ui.define([
	"Pers/Personalization/test/unit/controller/View1.controller"
], function () {
	"use strict";
});