sap.ui.define(["sap/ui/core/UIComponent", "sap/ushell/cpv2/services/control/contentUnit/WebContentControl"], function (UIComponent,
	WebContentControl) {
	"use strict";

	return UIComponent.extend("customjoinedcard.Component", {
		metadata: {
			manifest: "json"
		},
		createContent: function () {
			return new WebContentControl();
		}
	});
});