sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"tutorial/ui5/Table/utils/formatter"
], function (Controller, MessageBox,formatter) {
	"use strict";

	return Controller.extend("tutorial.ui5.Table.controller.View1", {
		formatter:formatter,
		onInit: function () {
			var oModel = new sap.ui.model.json.JSONModel();
			var pernrData = {
				pernrList: [{
					personID: "100",
					age: "20",
					phone: "9849334525",
					city: "Hyderabad",
					country: "India"
				}, {
					personID: "101",
					age: "24",
					phone: "9090090025",
					city: "Vijayawada",
					country: "India"
				}, {
					personID: "102",
					age: "28",
					phone: "6574679790",
					city: "Warangal",
					country: "India"
				}, {
					personID: "103",
					age: "30",
					phone: "816789899",
					city: "Cuddapah",
					country: "India"
				}, {
					personID: "104",
					age: "29",
					phone: "988898909",
					city: "Hyderabad",
					country: "Pakistan"
				}]
			};
			oModel.setData(pernrData);
			sap.ui.getCore().setModel(oModel, "pernrModel");
			this.getView().setModel(oModel, "pernrModel");

		},
		onRowSelect: function (oEvent) {
			var path = oEvent.getParameter("listItem").getBindingContext("pernrModel").getPath();
			var personID = this.getView().byId("tabId").getModel("pernrModel").getProperty(path).personID;
			var age = this.getView().byId("tabId").getModel("pernrModel").getProperty(path).age;
			var phone = this.getView().byId("tabId").getModel("pernrModel").getProperty(path).phone;
			var city = this.getView().byId("tabId").getModel("pernrModel").getProperty(path).city;
			var country = this.getView().byId("tabId").getModel("pernrModel").getProperty(path).country;
			MessageBox.alert("You have selected the row with Person ID " + personID + " Age " + age + " Phone " + phone + " City " + city +
				" & Country " + country);
		}
	});
});