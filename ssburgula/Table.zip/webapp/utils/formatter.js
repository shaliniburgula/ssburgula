sap.ui.define([], 
function(){
	return{
	
		formattingPhNo: function(value){
			return "+91-" +value;
		}
		
	};
});