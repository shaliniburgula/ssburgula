sap.ui.define([
	"tutorial/ui5/Table/test/unit/controller/View1.controller"
], function () {
	"use strict";
});