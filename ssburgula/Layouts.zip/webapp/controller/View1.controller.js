sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("tutorial.ui5.Layouts.controller.View1", {
		onInit: function () {

		}
	});
});