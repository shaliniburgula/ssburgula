sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/integration/widgets/Card",
	"sap/ui/model/Filter"
], function (Controller,JSONModel,Card,Filter) {
	"use strict";

	return Controller.extend("FA.fuelanalytics.controller.View1", {

		onInit: function () {

			this.getView().setModel( new JSONModel({
				"isBusy":false,
    			"SiteName":""
			}), "viewHelper");
			
			this._cardData = [];
			this._deliveriesData = [];
			this._measures = [];
			this._products = [];
			this._siteName = "";
			this._daysToDisplay = "7";
		},
		
		onDisplayPeriodChanged: function(event){
			this._daysToDisplay = parseInt(event.getSource().getSelectedKey(),10);
			this._drawCards();
		},
		
		onSiteChanged: function(event){
			
		},
		
		onSuggestSite: function(event){
			event.getSource().getBinding("suggestionRows").filter(
				this._createSiteFilter(event.getParameter("suggestValue").toUpperCase())
			);
		},
		
		_createSiteFilter: function(searchString){
			var filters = [];
			if (searchString) {
				//Use description to pass string - will be applied to all fields...
				filters.push( new Filter([
						new Filter("SiteName", sap.ui.model.FilterOperator.Contains, searchString),
						new Filter("SiteId", sap.ui.model.FilterOperator.Contains, searchString )
					],true)
				);
			} 
			return filters;	
		},
		
		onSiteSelected:function(event){
			
			this._cardData = [];
			this._deliveriesData = [];
			this._measures = [];	
			this._products = [];
					
			this.getView().getModel("viewHelper").setProperty("/isBusy",true);					
					
			var dataObject = event.getParameter("selectedRow").getBindingContext().getObject();
			var siteId = dataObject.SiteId;
			this._siteName = dataObject.SiteName;
			this.getView().getModel("viewHelper").setProperty("/SiteName",this._siteName);
			
		//	var siteId = event.getSource().getSelectedItem().getKey();
		//	this._siteName = event.getSource().getSelectedItem().getText();
			
			var siteKey = this.getView().getModel().createKey("Sites", {
 				"SiteId": siteId
 			});	
					
			this.getView().getModel().read("/" + siteKey + "/Products", {
				urlParameters: {
        			"$expand": "DipReadings,MeterReadings"
    			},
				success: function(data){
							
					data.results.forEach(function(product){
						
						this._products.push(
							{"ProductId":product.ProductId,"Description":product.Description,"Selected":"Success", "DaysRemaining":product.DaysRemaining}
						);

						if(product.DipReadings && product.DipReadings.results){
							product.DipReadings.results.forEach(function(dipReading){
							   
								var dimension = this._formatReadingDateFromTimestamp(dipReading.ReadingTimestamp);
								
								//Has this dimension already been added?
								var existingDimension = this._cardData.find(function(cardDataDimension){
									return cardDataDimension.readingDate === dimension;
								});
								
								if(existingDimension){
									existingDimension[product.Description + " (" + product.ProductId + ")"] = dipReading.ReadingValue;
								} else {
									var newDimension = {"readingDate":dimension,"sortDate":this._formatDateForSorting(dipReading.ReadingTimestamp)};
									newDimension[product.Description + " (" + product.ProductId + ")"] = dipReading.ReadingValue;
									this._cardData.push(newDimension);
								}
							}.bind(this));
						}	
						
						if(product.MeterReadings && product.MeterReadings.results){
							product.MeterReadings.results.forEach(function(meterReading){
								
								//Determine Dimension (Day of Reading)
								var dimension = this._formatReadingDateFromTimestamp(meterReading.ReadingTimestamp);
								
								//Has this dimension already been added?
								var existingDimension = this._cardData.find(function(cardDataDimension){
									return cardDataDimension.readingDate === dimension;
								});
								
								//Only add for dates where we have a DIP
								if(existingDimension){
									existingDimension[product.Description + " (" + product.ProductId + ")" + " Consumed"] = meterReading.ConsumedValue;
								} else {
									var newDimension = {"readingDate":dimension,"sortDate":this._formatDateForSorting(meterReading.ReadingTimestamp)};
									newDimension[product.Description + " (" + product.ProductId + ")" + " Consumed"] = meterReading.ConsumedValue;
									this._cardData.push(newDimension);
								}
							}.bind(this));
						}
						
					}.bind(this));
					
					this._cardData.sort(function(a, b){
						if (a.sortDate > b.sortDate) {
							return 1;
						} else if (a.sortDate < b.sortDate) {
							return -1;
						} else if (a.sortDate === b.sortDate) {
							return 0;
						}
					});
					
					this._loadDeliveries(siteKey);
					
				}.bind(this)
			}); 
		},
	
		_loadDeliveries:function(siteKey){
			
			this.getView().getModel().read("/" + siteKey + "/Deliveries", {
				urlParameters: {
        			"$expand": "Items"
    			},
				success: function(data){
							
					data.results.forEach(function(delivery){
						
						//Determine Dimension (Day of Reading)
						var dimension = this._formatReadingDateFromTimestamp(delivery.DeliveryDate);
								
						//Has this dimension already been added?
						var existingDimension = this._deliveriesData.find(function(cardDataDimension){
							return cardDataDimension.readingDate === dimension;
						});
						
						var descriptionPostfix = "";		
						if (delivery.IsFutureDelivery){
							descriptionPostfix = "Pending";
						} else {
							descriptionPostfix = "Delivered";
						}
								
						//Only add for dates where we have a DIP
						 if (delivery.Items.results.length === 0){
							var emptyDimension = {"readingDate":dimension,"sortDate":this._formatDateForSorting(delivery.DeliveryDate)};
							this._deliveriesData.push(emptyDimension);
						 } else {
							delivery.Items.results.forEach(function(deliveryItem){
								if(existingDimension){
									existingDimension[deliveryItem.Description + " (" + deliveryItem.ProductId + ")" + " " + descriptionPostfix] = deliveryItem.DeliveryQuantity;
								} else {
									existingDimension = {"readingDate":dimension,"sortDate":this._formatDateForSorting(delivery.DeliveryDate)};
									existingDimension[deliveryItem.Description + " (" + deliveryItem.ProductId + ")" + " " + descriptionPostfix] = deliveryItem.DeliveryQuantity;
									this._deliveriesData.push(existingDimension);
								}
							}.bind(this));
						 }
					}.bind(this));
					
					this._deliveriesData.sort(function(a, b){
						if (a.sortDate > b.sortDate) {
							return 1;
						} else if (a.sortDate < b.sortDate) {
							return -1;
						} else if (a.sortDate === b.sortDate) {
							return 0;
						}
					});
					
					//Draw the Cards - This really needs some Promises for readability...!
					this._drawCards();
				}.bind(this)
			});
		},
	
		_formatReadingDateFromTimestamp:function(readingTimestamp){
		
			var date = readingTimestamp.getDate();
			var month = readingTimestamp.getMonth();
			//var year = readingTimestamp.getFullYear();
			return this._padDate(date) + "-" + this._padDate(month + 1); // + "-" + year;
		},
		
		_formatDateForSorting:function(readingTimestamp){
		
			var date = readingTimestamp.getDate();
			var month = readingTimestamp.getMonth();
			var year = readingTimestamp.getFullYear();
			return year + this._padDate(month + 1) + this._padDate(date);
		},
	
		onProductSelected: function(event){
			
			var updatedProducts = [];
			var selectedProductId = event.getParameters().manifestParameters.productId;
			
			this._products.forEach(function(product){
				var newProduct = Object.assign({}, product);
				
				if(newProduct.ProductId === selectedProductId){
					newProduct.Selected = ( newProduct.Selected === "Success"  ? "None" : "Success" );
				}
				updatedProducts.push(newProduct);
			});
			
			this._products = updatedProducts;
			this._drawCards();
		},
		
		_drawCards: function(){
			
			var gridContainer = this.getView().byId("cardContainer");
			gridContainer.removeAllItems();
				
			gridContainer.addItem(
				new Card({
					"manifest":"{products>/}",
					"action": this.onProductSelected.bind(this),
					"layoutData": new sap.f.GridContainerItemLayoutData({ "minRows":4, "columns":4})
				})
			);
			
			var listManifest = this._listCardTemplate();
			listManifest.setProperty("/sap.card/header/title","Products sold at " + this._siteName);
			listManifest.setProperty("/sap.card/content/data/json/list",this._products);
			this.getView().setModel(listManifest, "products");
			
			var analyticManifest = this._analyticCardTemplate();
			var headerData = {
				"title":"Total product volumes at " + this._siteName
			};
			
			//Apply day filter to Card Data
			var dataLength = this._cardData.length;
			var filteredCardData = [];
			if (dataLength < this._daysToDisplay){
				filteredCardData = this._cardData;
			} else {
				filteredCardData = this._cardData.slice(this._cardData.length - this._daysToDisplay);
			}
			
			///Deliveries - Today() + 5 (future deliveries)
			dataLength = this._deliveriesData.length;
			var filteredDeliveryData = [];
			if (dataLength < ( parseInt(this._daysToDisplay,10) + 5 )){
				filteredDeliveryData = this._deliveriesData;
			} else {
				filteredDeliveryData = this._deliveriesData.slice(this._deliveriesData.length - ( parseInt(this._daysToDisplay,10) + 5 )); //5 Future Days
			}
			
			//Adjust Measures based on Selected Products
			this._measures = [];
			this._deliveredMeasures = [];
			this._products.forEach(function(product){
				if(product.Selected === "Success"){
				  	//Add an entry in the Measures List if there are readings...
				  	this._measures.push(
						{"label":product.Description,"value":"{" + product.Description + " (" + product.ProductId + ")" + "}","DaysRemaining":product.DaysRemaining}
					);		
					
					//Only add delivery measures if there is product to be delivered
					filteredDeliveryData.forEach(function(delivery){
						
						var deliveredMeasure = product.Description + " (" + product.ProductId + ")" + " Delivered";
						var pendingMeasure = product.Description + " (" + product.ProductId + ")" + " Pending";
						
						if(delivery[deliveredMeasure]){
							
							var deliveredMeasureExists = this._deliveredMeasures.find(function(existingDeliveredMeasure){
								return existingDeliveredMeasure.value === "{" + deliveredMeasure + "}";
							});
							
							if(!deliveredMeasureExists){
								this._deliveredMeasures.push(
									{"label":product.Description,"value":"{" + deliveredMeasure + "}"}
								);
							}
						}
						
						if(delivery[pendingMeasure]){
							
							var pendingMeasureExists = this._deliveredMeasures.find(function(existingPendingMeasure){
								return existingPendingMeasure.value === "{" + pendingMeasure + "}";
							});
							if(!pendingMeasureExists){
								this._deliveredMeasures.push(
									{"label":product.Description,"value":"{" + pendingMeasure + "}"}
								);
							}
						}
					}.bind(this));
				}
			}.bind(this));
			
			analyticManifest.setProperty("/sap.card/header",headerData);
			analyticManifest.setProperty("/sap.card/content/data/json/list",filteredCardData);
			analyticManifest.setProperty("/sap.card/content/measures",this._measures);
			this.getView().setModel(analyticManifest, "analytics");
			
			gridContainer.addItem(
				new Card({
					"manifest":"{analytics>/}",
					"layoutData": new sap.f.GridContainerItemLayoutData({ "minRows":4, "rows":4, "columns":8})
				})
			);
			
			var deliveriesManifest = this._analyticCardTemplate();
			var deliveriesHeaderData = {
				"title":"Deliveries at " + this._siteName + " (5 days forward looking)"
			};
			deliveriesManifest.setProperty("/sap.card/header",deliveriesHeaderData);
			deliveriesManifest.setProperty("/sap.card/content/data/json/list",filteredDeliveryData);
			deliveriesManifest.setProperty("/sap.card/content/measures",this._deliveredMeasures);
			this.getView().setModel(deliveriesManifest, "deliveries");
			
			gridContainer.addItem(
				new Card({
					"manifest":"{deliveries>/}",
					"layoutData": new sap.f.GridContainerItemLayoutData({ "minRows":4, "rows":4, "columns":12})
				})
			);
			
			//Create Individual Manifests for each Product
			this._measures.forEach(function(measure){
				var productManifest = this._analyticCardTemplate();
				
				var stateValue = "Critical";
				if(measure.DaysRemaining > 10){
					stateValue = "Good";
				} else if (measure.DaysRemaining < 3){
					stateValue = "Error";
				}
				
				var productHeader = {
					"type": "Numeric",
					"title":measure.label,
					"data": {
						"json": {
							"number":measure.DaysRemaining,
							"unit":"",
							"trend":"",
							"state":stateValue
						}
					},
					"mainIndicator": {
						"number": "{number}",
						"unit": "{unit}",
						"state": "{state}"
					},
					"details": "Estimated days remaining"
				};
				
				var productMeasures = [];
				
				productMeasures.push(measure);
				
				var showConsumption = false;
				var consumptionAttribute = measure.value.slice(1, measure.value.length-1) + " Consumed";
				filteredCardData.forEach(function(cardData){
					if(typeof cardData[consumptionAttribute] !== "undefined"){
						showConsumption = true;
					}
				});
				
				if(showConsumption){
					productMeasures.push(
						{"label":"Consumption","value":"{" + measure.value.slice(1, measure.value.length-1) + " Consumed" + "}"}
					);
				}
				
				productManifest.setProperty("/sap.card/header",productHeader);
				productManifest.setProperty("/sap.card/content/data/json/list",filteredCardData);
				productManifest.setProperty("/sap.card/content/measures",productMeasures);
				productManifest.setProperty("/sap.card/content/chartType","Line");
				var manifestName = measure.value.slice(1, measure.value.length-1);
				this.getView().setModel(productManifest, manifestName);
				
				var measureCard = new Card({
					"manifest":"{" + manifestName + ">/}",
					"layoutData": new sap.f.GridContainerItemLayoutData({ "minRows":4, "rows":4, "columns":4})
				});
				gridContainer.addItem(measureCard);
				
			}.bind(this));	
			
			this.getView().getModel("viewHelper").setProperty("/isBusy",false);	
		},
		
		_padDate:function (n) {
			return n<10 ? '0'+n : n;
		},

		_listCardTemplate:function(){
		
			return new JSONModel(
			{
				"_version": "1.14.0",
				"sap.app": {
					"type": "card"
				},
				"sap.card": {
					"type": "List",
					"header": {
						"title": "",
						"icon": {
							"src": "sap-icon://mileage"
						}
					},
					"content": {
						"data": {
							"json": {
								"list": []
							},
							"path": "/list"
						},
						"item": {
							"title": "{ProductId}",
							"description": "{Description}",
							"highlight":"{Selected}",
							"actions": [
								{
									"type": "Navigation",
									"parameters": {
										"productId": "{ProductId}"
									}
								}
							]
						}
					}
				}
			});
		},

		_analyticCardTemplate:function(){
			
			return new JSONModel(
				{
					"sap.app": {
						"type": "card"
					},
					"sap.card": {
						"type": "Analytical",
						"header": {
							"type": "Numeric",
							"data": {
								"json": {}
							},
							"title": "{title}",
							"mainIndicator": {
								"number": "{number}",
								"unit": "{unit}",
								"trend": "{trend}",
								"state": "{state}"
							}
						},
						"content": {
							"chartType": "StackedColumn",
							"legend": {
								"visible": true,
								"position": "Bottom",
								"alignment": "Left"
							},
							"plotArea": {
								"dataLabel": {
									"visible": true,
									"showTotal": true
								},
								"colorPalette" : ["red","green"],
								
								"categoryAxisText": {
									"visible": false
								},
								"valueAxisText": {
									"visible": false
								}
							},
							"title": {
								"visible": false
							},
							"measureAxis": "valueAxis",
							"dimensionAxis": "categoryAxis",
							"data": {
								"json": {
									"list": []
								},
								"path": "/list"
							},
							"dimensions": [{
								"label": "Day",
								"value": "{readingDate}"
							}],
							"measures": []
						}
					}
				});
			}
	});
});