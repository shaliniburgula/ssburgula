sap.ui.define([
	"FA/fuelanalytics/test/unit/controller/View1.controller"
], function () {
	"use strict";
});