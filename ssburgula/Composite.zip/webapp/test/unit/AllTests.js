sap.ui.define([
	"tutorial/ui5/Composite/test/unit/controller/View1.controller"
], function () {
	"use strict";
});