sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("tutorial.ui5.Composite.controller.View1", {
		onInit: function () {
			var countryJSONModel = new sap.ui.model.json.JSONModel();
			var countryData = {
				countryList: [{
					countryname: "India"
				}, {
					countryname: "China"
				}, {
					countryname: "Nepal"
				}, {
					countryname: "Bangladesh"
				}, {
					countryname: "Srilanka"
				}, {
					countryname: "Australia"
				}]
			};
			countryJSONModel.setData(countryData);
			sap.ui.getCore().setModel(countryJSONModel, "countryModel");
			this.getView().setModel(countryJSONModel, "countryModel");

		},
		onSelectCountry: function () {
		/*	var selCountry = this.getView().byId("idselect").getSelectedKey();
			MessageBox.alert("You belongs to " + selCountry);*/

		var selCountry = this.getView().byId("rbcountry").getSelectedButton().getText();
			MessageBox.alert("You belongs to " + selCountry);

		}

	});
});