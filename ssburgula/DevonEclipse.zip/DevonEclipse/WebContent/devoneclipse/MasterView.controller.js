sap.ui.controller("devoneclipse.MasterView", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf devoneclipse.MasterView
*/
	onInit: function() {
		
		var welldata={
                wellList:[
                    
                        {welltype: "Well1",Des:"Description 1",relateddata:[
                                                                            {measurement:"FTP (PSI)", date1:"76", date2:"45", date3:"7", date4:"73", date5:"10", date6:"45",date7:"8"},
                                                                            {measurement:"Temp (F)", date1:"109", date2:"145", date3:"70", date4:"7", date5:"167", date6:"145",date7:"98"},
                                                                            {measurement:"CSG (PSI)", date1:"096", date2:"5", date3:"17", date4:"73", date5:"23", date6:"60",date7:"80"},
                                                                            {measurement:"Oil (BBL)", date1:"26", date2:"34", date3:"58", date4:"89", date5:"100", date6:"95",date7:"88"},
                                                                            {measurement:"Gas (HCF)", date1:"96", date2:"95", date3:"17", date4:"93", date5:"60", date6:"95",date7:"45"},
                                                                            {measurement:"Water (BBL)", date1:"6", date2:"76", date3:"37", date4:"13", date5:"70", date6:"75",date7:"18"}
                                                                            
                                                                          ]},                        
                        
                        
                        {welltype: "Well2",Des:"Description 2",relateddata:[
                                                                            {measurement:"FTP (PSI)", date1:"8", date2:"75", date3:"17", date4:"53", date5:"80", date6:"66",date7:"83"},
                                                                            {measurement:"Temp (F)", date1:"78", date2:"95", date3:"80", date4:"27", date5:"57", date6:"75",date7:"98"},
                                                                            {measurement:"CSG (PSI)", date1:"6", date2:"54", date3:"97", date4:"63", date5:"43", date6:"20",date7:"70"},
                                                                            {measurement:"Oil (BBL)", date1:"76", date2:"84", date3:"18", date4:"32", date5:"70", date6:"5",date7:"88"},
                                                                            {measurement:"Gas (HCF)", date1:"43", date2:"85", date3:"07", date4:"29", date5:"6", date6:"45",date7:"95"},
                                                                            {measurement:"Water (BBL)", date1:"61", date2:"73", date3:"57", date4:"83", date5:"090", date6:"54",date7:"58"}
                                                                           ]}
                        
                    
                    ]
                    };
                    var wellJosnObj = new sap.ui.model.json.JSONModel();
                    wellJosnObj.setData(welldata);
                    sap.ui.getCore().setModel(wellJosnObj,"wellModel");
		

	},
	onSearch: function()
	{
		var filters = [];
		var searchString = this.getView().byId("searchField").getValue();
		if (searchString && searchString.length > 0) {
			filters = [new sap.ui.model.Filter("welltype", sap.ui.model.FilterOperator.Contains, searchString)];
		}
		// Update list binding
		this.getView().byId("list").getBinding("items").filter(filters);
	},
	onSelect: function()
	{
		var selItem = this.getView().byId("list").getSelectedItem()+"";
		var split1=selItem.split("__");
		
		var index = split1[1].charAt(split1[1].length-1);
		
		var bindexp = "wellModel>/wellList/"+index+"/welltype";
		var tabBindExp = "wellModel>/wellList/"+index+"/relateddata";
		
		sap.ui.getCore().byId("idDetailView1--detailHeader").bindProperty("title", bindexp);
       var  template = new sap.m.ColumnListItem({
            cells: [
              new sap.m.Text({ text: "{wellModel>measurement}" }),
              new sap.m.Input({ value: "{wellModel>date1}" }),
              new sap.m.Input({ value: "{wellModel>date2}" }),
              new sap.m.Input({ value: "{wellModel>date3}" }),
              new sap.m.Input({ value: "{wellModel>date4}" }),
              new sap.m.Input({ value: "{wellModel>date5}" }),
              new sap.m.Input({ value: "{wellModel>date6}" }),
              new sap.m.Input({ value: "{wellModel>date7}" })
              
            ]
          });
       
      

		sap.ui.getCore().byId("idDetailView1--tabWell").bindItems(tabBindExp,template);
		
		
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf devoneclipse.MasterView
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf devoneclipse.MasterView
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf devoneclipse.MasterView
*/
//	onExit: function() {
//
//	}

});