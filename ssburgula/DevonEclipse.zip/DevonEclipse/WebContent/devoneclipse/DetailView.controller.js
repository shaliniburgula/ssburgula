sap.ui.controller("devoneclipse.DetailView", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf devoneclipse.DetailView
*/
	onInit: function() {
		
		var welldata={
                wellList:[
                    
                        {welltype: "Well1",Des:"Description 1",relateddata:[
                                                                            {measurement:"FTP(PSI)", date:"10/01/2015", value:"100"},
                                                                            {measurement:"FTP(PSI)", date:"10/02/2015", value:"54"},
                                                                            
                                                                            {measurement:"TEMP(F)", date:"10/01/2015", value:"65"},
                                                                            {measurement:"TEMP(F)", date:"10/02/2015", value:"76"},
                                                                            
                                                                            
                                                                            
                                                                            
                                                                          
                                                                           ]},                        
                        
                        
                        {welltype: "Well2",Des:"Description 1",relateddata:[
                                                                            {measurement:"FTP(PSI)", date1:"76", date2:"45",date3:"67"},
                                                                            {measurement:"FTP(PSI)", date1:"34", date2:"12",date3:"21"},
                                                                            {measurement:"FTP(PSI)", date1:"45", date2:"78",date3:"32"},
                                                                            {measurement:"FTP(PSI)", date1:"45", date2:"76",date3:"54"},
                                                                            {measurement:"FTP(PSI)", date1:"34", date2:"67",date3:"87"}
                                                                            
                                                                           ]},
                        {welltype: "Well3",Des:"Description 1"},
                        {welltype: "Well4",Des:"Description 1"}
                    
                    ]
                    };
                    var wellJosnObj = new sap.ui.model.json.JSONModel();
                    wellJosnObj.setData(welldata);
		
		var oVizFrame = this.getView().byId("idVizFrameBar");

        var oPopOver = this.getView().byId("idPopOver");
        
      var oDataset = new sap.viz.ui5.data.FlattenedDataset({

            dimensions: [{

                name: "Date",

                value: "{date}"

            },{

                name: "Measurement",

                value: "{measurement}"

            }],

            measures: [{

                name: 'Value',

                value: '{value}'

            }],

            data: {

                path: "/wellList/0/relateddata"

            }

        });

        oVizFrame.setDataset(oDataset);

        oVizFrame.setModel(wellJosnObj);
        
        var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({

                'uid': "valueAxis",

                'type': "Measure",

                'values': ["Value"]

            }),

            feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({

                'uid': "categoryAxis",

                'type': "Dimension",

                'values': ["Date"]

            }),

            feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({

                'uid': "color",

                'type': "Dimension",

                'values': ["Measurement"]

            });



        oVizFrame.setVizProperties({
        	title:" ",
            legend: {

                title: {

                    visible: false

                }

            }
        });
        oVizFrame.addFeed(feedValueAxis);

        oVizFrame.addFeed(feedCategoryAxis);

        oVizFrame.addFeed(feedColor);

        oPopOver.connect(oVizFrame.getVizUid());

	},
	toggleFullScreen : function(oEvent) {  
		  var id = oEvent.getSource().sId;   
		  var cid = this.getView().byId(id);  
		  var spapp = sap.ui.getCore().getControl("idsplitapp");  
		 
		  if(spapp.getMode() == "ShowHideMode"){  
		  spapp.setMode('HideMode');  
		  cid.setIcon('sap-icon://exit-full-screen').setTooltip('Show in full screen mode');  
		  }else{  
		  spapp.setMode('ShowHideMode');   
		  cid.setIcon('sap-icon://full-screen').setTooltip('Exit from full screen mode');  
		  }  
	},
	onSave : function(){
		
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf devoneclipse.DetailView
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf devoneclipse.DetailView
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf devoneclipse.DetailView
*/
//	onExit: function() {
//
//	}

});