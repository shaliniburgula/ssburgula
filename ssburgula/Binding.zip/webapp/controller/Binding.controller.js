sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("tutorial.ui5.Binding.controller.Binding", {
		onInit: function () {

			/*	//Property Binding	
				var oData = {
					firstName : "  Christy"	
				};
				
				var jsonModel = new sap.ui.model.json.JSONModel();
				jsonModel.setData(oData);
				this.getView().setModel(jsonModel,"jsonModel");*/

		

			var jsonData = {
				"ProductCollection": [{
					"ProductID": "01",
					"ProductName": "Dekstop",
					"ProductQuantity": "23",
					"Price": "10",
					"Currency": "EUR"
				}, {
					"ProductID": "02",
					"ProductName": "Laptop",
					"ProductQuantity": "100",
					"Price": "100",
					"Currency": "EUR"
				}, {
					"ProductID": "03",
					"ProductName": "Mobile",
					"ProductQuantity": "110",
					"Price": "1000",
					"Currency": "EUR"
				}]

			};
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData(jsonData);
			this.getView().setModel(oJsonModel, "oJsonModel");

		},
		onListItemPress: function (oEvent) {
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oJsonModel");
			var sPath = oContext.getPath();
			var oProductDetailPanel = this.getView().byId("productDetailsPanel");
			oProductDetailPanel.setVisible(true);
			oProductDetailPanel.bindElement({
				path: sPath,
				model: "oJsonModel"
			});
		}
	});
});