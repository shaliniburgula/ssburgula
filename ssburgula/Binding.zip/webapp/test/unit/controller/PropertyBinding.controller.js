/*global QUnit*/

sap.ui.define([
	"tutorial/ui5/Binding/controller/PropertyBinding.controller"
], function (Controller) {
	"use strict";

	QUnit.module("PropertyBinding Controller");

	QUnit.test("I should test the PropertyBinding controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});