sap.ui.define([
	"tutorial/ui5/Binding/test/unit/controller/PropertyBinding.controller"
], function () {
	"use strict";
});