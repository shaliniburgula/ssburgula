sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.examples.XMLModel.controller.View1", {
		onInit: function () {
			var oModel = new sap.ui.model.xml.XMLModel();
			oModel.loadData("data.xml");
			sap.ui.getCore().setModel(oModel);
			oModel.attachRequestCompleted(function (oEvent) {
				sap.ui.getCore().setModel(oEvent.getSource());

			});

		}
	});
});