sap.ui.define([
	"com/examples/XMLModel/test/unit/controller/View1.controller"
], function () {
	"use strict";
});