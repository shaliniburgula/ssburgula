For each entity set, initial data can optionally be provided in a file *EntitySetName.json*.

Initial data is available in production and test modes.

The sample initial data below will not be automatically used, but can be copy-pasted into JSON files.

Sample initial data for file ProductSet.json:

''' JSON
[
    {
        "Description": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "Name": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "ProductID": "101"
    },
    {
        "Description": "XYZ",
        "Name": "XYZ",
        "ProductID": "102"
    }
]
'''
