For each entity set, test data can optionally be provided in a file *EntitySetName.json*.

Test data is available only in "test mode", not in production mode.

Please refer to the generated TestSettings class to see the options for enabling test mode.

Sample test data for file ProductSet.json:

''' JSON
[
    {
        "Description": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "Name": "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "ProductID": "101"
    },
    {
        "Description": "XYZ",
        "Name": "XYZ",
        "ProductID": "102"
    }
]
'''
