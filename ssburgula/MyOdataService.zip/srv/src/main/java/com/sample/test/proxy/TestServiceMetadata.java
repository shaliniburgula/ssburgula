//# xsc 20.1.2-a5868d-20200407

package com.sample.test.proxy;

public abstract class TestServiceMetadata
{
    public static final com.sap.cloud.server.odata.csdl.CsdlDocument document = com.sample.test.proxy.TestServiceMetadata.resolve();

    public static final com.sap.cloud.server.odata.MetadataLock lock = new com.sap.cloud.server.odata.MetadataLock();

    private static com.sap.cloud.server.odata.csdl.CsdlDocument resolve()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:135:12
        com.sample.test.proxy.internal.TestServiceFactory.registerAll();
        com.sample.test.proxy.internal.TestServiceMetadataParser.parsed.setGeneratedProxies(true);
        return com.sample.test.proxy.internal.TestServiceMetadataParser.parsed;
    }

    public abstract static class EntityTypes
    {
        public static final com.sap.cloud.server.odata.EntityType product = com.sample.test.proxy.internal.TestServiceMetadataParser.parsed.getEntityType("com.sample.test.Product");
    }

    public abstract static class EntitySets
    {
        public static final com.sap.cloud.server.odata.EntitySet productSet = com.sample.test.proxy.internal.TestServiceMetadataParser.parsed.getEntitySet("ProductSet");
    }
}
