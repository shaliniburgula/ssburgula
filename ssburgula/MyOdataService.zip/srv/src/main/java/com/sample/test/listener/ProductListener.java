package com.sample.test.listener;

import com.sap.cloud.server.odata.*;

public class ProductListener extends com.sap.cloud.server.odata.DefaultEntityListener {
    private com.sample.test.MainServlet servlet;
    private com.sample.test.proxy.TestService service;

    public ProductListener(com.sample.test.MainServlet servlet, com.sample.test.proxy.TestService service) {
        super();
        this.servlet = servlet;
        this.service = service;
        allowUnused(this.servlet);
        allowUnused(this.service);
    }

    @Override public void beforeQuery(DataQuery query) {
        allowUnused(query);
    }

    public void beforeSave(EntityValue entityValue) {
        // Shared code for beforeCreate / beforeUpdate.
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
    }

    @Override public void beforeCreate(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
        beforeSave(entity);
    }

    @Override public void beforeUpdate(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
        beforeSave(entity);
    }

    @Override public void beforeDelete(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
    }

    public void afterSave(EntityValue entityValue) {
        // Shared code for afterCreate / afterUpdate.
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
    }

    @Override public void afterCreate(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
        afterSave(entity);
    }

    @Override public void afterUpdate(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
        afterSave(entity);
    }

    @Override public void afterDelete(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        allowUnused(entity);
    }
}
