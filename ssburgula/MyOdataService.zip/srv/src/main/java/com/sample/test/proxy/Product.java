//# xsc 20.1.2-a5868d-20200407

package com.sample.test.proxy;

public class Product
    extends com.sap.cloud.server.odata.EntityValue
{
    public static final com.sap.cloud.server.odata.Property description = com.sample.test.proxy.TestServiceMetadata.EntityTypes.product.getProperty("Description");

    public static final com.sap.cloud.server.odata.Property name = com.sample.test.proxy.TestServiceMetadata.EntityTypes.product.getProperty("Name");

    public static final com.sap.cloud.server.odata.Property productID = com.sample.test.proxy.TestServiceMetadata.EntityTypes.product.getProperty("ProductID");

    public Product()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:35:5
        this(true);
    }

    public Product(final boolean withDefaults)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:35:5
        super(withDefaults, com.sample.test.proxy.TestServiceMetadata.EntityTypes.product);
    }

    public com.sample.test.proxy.Product copy()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:20:5
        return com.sample.test.proxy.internal.Any_as_com_sample_test_proxy_Product.cast(this.copyEntity());
    }

    public String getDescription()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:54:5
        return com.sap.cloud.server.odata.StringValue.unwrap(this.getDataValue(com.sample.test.proxy.Product.description));
    }

    public String getName()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:67:5
        return com.sap.cloud.server.odata.StringValue.unwrap(this.getDataValue(com.sample.test.proxy.Product.name));
    }

    public com.sample.test.proxy.Product getOld()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:15:5
        return com.sample.test.proxy.internal.Any_as_com_sample_test_proxy_Product.cast(this.getOldEntity());
    }

    public long getProductID()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:80:5
        return com.sap.cloud.server.odata.LongValue.unwrap(this.getDataValue(com.sample.test.proxy.Product.productID));
    }

    @java.lang.Override public boolean isProxy()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:8:5
        return true;
    }

    public static com.sap.cloud.server.odata.EntityKey key(final long productID)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:25:12
        return new com.sap.cloud.server.odata.EntityKey().with("ProductID", com.sap.cloud.server.odata.LongValue.of(productID));
    }

    public static com.sample.test.proxy.ProductList list(final com.sap.cloud.server.odata.EntityValueList from)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:30:12
        return com.sample.test.proxy.ProductList.share(from);
    }

    public void setDescription(final String value)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:59:5
        this.setDataValue(com.sample.test.proxy.Product.description, com.sap.cloud.server.odata.StringValue.of(value));
    }

    public void setName(final String value)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:72:5
        this.setDataValue(com.sample.test.proxy.Product.name, com.sap.cloud.server.odata.StringValue.of(value));
    }

    public void setProductID(final long value)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:85:5
        this.setDataValue(com.sample.test.proxy.Product.productID, com.sap.cloud.server.odata.LongValue.of(value));
    }
}
