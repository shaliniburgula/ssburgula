// Note: Customizations placed in this file might be lost if the OData service is regenerated!
// Please place any customizations of listener registration in the ProviderSettings class.

package com.sample.test.base;

import com.sap.cloud.server.odata.*;

class RegisterListeners {
    private static EntityListener productListener;

    public static void withServlet(com.sample.test.MainServlet servlet) {
        com.sample.test.proxy.TestService service = (com.sample.test.proxy.TestService)servlet.getDataService();
        productListener = new com.sample.test.listener.ProductListener(servlet, service);
        servlet.registerEntityListener(com.sample.test.proxy.TestServiceMetadata.EntityTypes.product, productListener);
    }
}
