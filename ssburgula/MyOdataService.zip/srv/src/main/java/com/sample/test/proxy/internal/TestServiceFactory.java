//# xsc 20.1.2-a5868d-20200407

package com.sample.test.proxy.internal;

public abstract class TestServiceFactory
{
    public static void registerAll()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:145:12
        com.sample.test.proxy.TestServiceMetadata.EntityTypes.product.registerFactory(new com.sample.test.proxy.internal.TestServiceFactory.CreateProduct());
    }

    public static class CreateProduct
    extends com.sap.cloud.server.odata.core.ObjectFactory
    {
        @java.lang.Override public Object create()
        {
            //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:159:9
            return new com.sample.test.proxy.Product(false);
        }
    }
}
