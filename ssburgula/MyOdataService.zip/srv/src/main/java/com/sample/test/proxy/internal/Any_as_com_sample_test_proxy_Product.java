//# xsc 20.1.2-a5868d-20200407

package com.sample.test.proxy.internal;

public abstract class Any_as_com_sample_test_proxy_Product
{
    public static com.sample.test.proxy.Product cast(final Object value)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:310:35 => /usr/sap/ljs/xs-temp/xs-home/templates/List.xs:88:16 => /usr/sap/ljs/xs-temp/xs-home/templates/Any.as.xs:7:12
        if (value instanceof com.sample.test.proxy.Product)
        {
            final com.sample.test.proxy.Product var_value = ((com.sample.test.proxy.Product)value);
            return var_value;
        }
        else
        {
            throw com.sap.cloud.server.odata.core.CastException.cannotCast(value, "com.sample.test.proxy.Product");
        }
    }
}
