//# xsc 20.1.2-a5868d-20200407

package com.sample.test.proxy;

public class TestService
    extends com.sap.cloud.server.odata.DataService
{
    public TestService()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:183:5
        this(null);
    }

    public TestService(final com.sap.cloud.server.odata.DataServiceProvider provider)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:183:5
        super(com.sap.cloud.server.odata.MetadataOnlyProvider.newIfNull(provider, "TestService"));
        this.getProvider().setMetadata(com.sample.test.proxy.TestServiceMetadata.document);
    }

    @java.lang.Override public com.sap.cloud.server.odata.MetadataLock getMetadataLock()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:170:5
        return com.sample.test.proxy.TestServiceMetadata.lock;
    }

    public com.sample.test.proxy.Product getProduct(final com.sap.cloud.server.odata.DataQuery query)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:195:5
        return this.getProduct(query, null, null);
    }

    public com.sample.test.proxy.Product getProduct(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:195:5
        return this.getProduct(query, headers, null);
    }

    public com.sample.test.proxy.Product getProduct(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers, final com.sap.cloud.server.odata.RequestOptions options)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:195:5
        final com.sap.cloud.server.odata.http.HttpHeaders var_headers = com.sap.cloud.server.odata.http.HttpHeaders.emptyIfNull(headers);
        final com.sap.cloud.server.odata.RequestOptions var_options = com.sap.cloud.server.odata.RequestOptions.noneIfNull(options);
        return com.sample.test.proxy.internal.Any_as_com_sample_test_proxy_Product.cast(this.executeQuery(query.fromDefault(com.sample.test.proxy.TestServiceMetadata.EntitySets.productSet), var_headers, var_options).getRequiredEntity());
    }

    public com.sample.test.proxy.ProductList getProductSet()
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:210:5
        return this.getProductSet(null, null, null);
    }

    public com.sample.test.proxy.ProductList getProductSet(final com.sap.cloud.server.odata.DataQuery query)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:210:5
        return this.getProductSet(query, null, null);
    }

    public com.sample.test.proxy.ProductList getProductSet(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:210:5
        return this.getProductSet(query, headers, null);
    }

    public com.sample.test.proxy.ProductList getProductSet(final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers, final com.sap.cloud.server.odata.RequestOptions options)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:210:5
        final com.sap.cloud.server.odata.DataQuery var_query = com.sap.cloud.server.odata.DataQuery.newIfNull(query);
        final com.sap.cloud.server.odata.http.HttpHeaders var_headers = com.sap.cloud.server.odata.http.HttpHeaders.emptyIfNull(headers);
        final com.sap.cloud.server.odata.RequestOptions var_options = com.sap.cloud.server.odata.RequestOptions.noneIfNull(options);
        return com.sample.test.proxy.Product.list(this.executeQuery(var_query.fromDefault(com.sample.test.proxy.TestServiceMetadata.EntitySets.productSet), var_headers, var_options).getEntityList());
    }

    public com.sample.test.proxy.Product getProductWithKey(final long productID)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:203:5
        return this.getProductWithKey(productID, null, null, null);
    }

    public com.sample.test.proxy.Product getProductWithKey(final long productID, final com.sap.cloud.server.odata.DataQuery query)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:203:5
        return this.getProductWithKey(productID, query, null, null);
    }

    public com.sample.test.proxy.Product getProductWithKey(final long productID, final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:203:5
        return this.getProductWithKey(productID, query, headers, null);
    }

    public com.sample.test.proxy.Product getProductWithKey(final long productID, final com.sap.cloud.server.odata.DataQuery query, final com.sap.cloud.server.odata.http.HttpHeaders headers, final com.sap.cloud.server.odata.RequestOptions options)
    {
        //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:203:5
        final com.sap.cloud.server.odata.DataQuery var_query = com.sap.cloud.server.odata.DataQuery.newIfNull(query);
        return this.getProduct(var_query.withKey(com.sample.test.proxy.Product.key(productID)), headers, options);
    }

    @java.lang.Override public void refreshMetadata()
    {
        synchronized (this)
        {
            //# /usr/sap/ljs/xs-temp/6f32b5f6-fa57-4266-8959-6ca6d7e9f611/output/target/tmp/proxy-com.sample.test.csdl.xs:189:19
            com.sap.cloud.server.odata.ProxyInternal.noRefreshMetadata();
        }
    }
}
