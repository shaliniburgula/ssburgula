// Note: This handler will be overwritten if the service is regenerated.
// To allow customization and avoid overwriting upon service regeneration,
// please delete this comment.

package com.sample.test.handler;

import com.sap.cloud.server.odata.*;

public class ProductHandler extends com.sap.cloud.server.odata.DefaultEntityHandler {
    private com.sample.test.MainServlet servlet;
    private com.sample.test.proxy.TestService service;

    public ProductHandler(com.sample.test.MainServlet servlet, com.sample.test.proxy.TestService service) {
        super(servlet, service);
        this.servlet = servlet;
        this.service = service;
        allowUnused(this.servlet);
        allowUnused(this.service);
    }

    @Override public DataValue executeQuery(DataQuery query) {
        return service.executeQuery(query).getResult();
    }

    @Override public void createEntity(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        service.createEntity(entity);
    }

    @Override public void updateEntity(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        entity.setMustBeModified(true);
        service.updateEntity(entity);
    }

    @Override public void deleteEntity(EntityValue entityValue) {
        com.sample.test.proxy.Product entity = (com.sample.test.proxy.Product)entityValue;
        service.deleteEntity(entity);
    }
}
