// Note: Customizations placed in this file might be lost if the OData service is regenerated!
// Please place any customizations of handler registration in the ProviderSettings class.

package com.sample.test.base;

import com.sap.cloud.server.odata.*;

class RegisterHandlers {
    private static EntityHandler handler_Product;

    public static void withServlet(com.sample.test.MainServlet servlet) {
        com.sample.test.proxy.TestService service = (com.sample.test.proxy.TestService)servlet.getDataService();
        handler_Product = new com.sample.test.handler.ProductHandler(servlet, service);
        servlet.registerEntityHandler(com.sample.test.proxy.TestServiceMetadata.EntityTypes.product, handler_Product);
    }
}
