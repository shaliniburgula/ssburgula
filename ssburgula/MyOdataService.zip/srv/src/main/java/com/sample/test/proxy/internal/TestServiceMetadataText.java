//# xsc 20.1.2-a5868d-20200407

package com.sample.test.proxy.internal;

public abstract class TestServiceMetadataText
{
    public static final String XML = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<edmx:Edmx Version=\"1.0\" xmlns:edmx=\"http://schemas.microsoft.com/ado/2007/06/edmx\" xmlns:edmx4=\"http://docs.oasis-open.org/odata/ns/edmx\" xmlns:m=\"http://schemas.microsoft.com/ado/2007/08/dataservices/metadata\">\n<edmx4:Reference Uri=\"vocabularies/com.sap.cloud.server.odata.sql.v1.xml\">\n<edmx4:Include Namespace=\"com.sap.cloud.server.odata.sql.v1\" Alias=\"SQL\"/>\n</edmx4:Reference>\n<edmx:DataServices m:DataServiceVersion=\"2.0\">\n<Schema Namespace=\"com.sample.test\" xmlns=\"http://schemas.microsoft.com/ado/2008/09/edm\">\n<EntityType Name=\"Product\">\n<Key>\n<PropertyRef Name=\"ProductID\"/>\n</Key>\n<Property Name=\"Description\" Type=\"Edm.String\" Nullable=\"false\" MaxLength=\"50\"/>\n<Property Name=\"Name\" Type=\"Edm.String\" Nullable=\"false\" MaxLength=\"30\"/>\n<Property Name=\"ProductID\" Type=\"Edm.Int64\" Nullable=\"false\"/>\n</EntityType>\n<EntityContainer Name=\"TestService\" m:IsDefaultEntityContainer=\"true\">\n<Annotation Term=\"SQL.TrackChanges\" xmlns=\"http://docs.oasis-open.org/odata/ns/edm\"/>\n<EntitySet Name=\"ProductSet\" EntityType=\"com.sample.test.Product\"/>\n</EntityContainer>\n</Schema>\n</edmx:DataServices>\n</edmx:Edmx>\n";
}
