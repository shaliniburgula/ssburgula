package com.sample.test;

public abstract class LogSettings {
    public static final boolean PRETTY_TRACING = true;
}
