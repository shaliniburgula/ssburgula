sap.ui.define([], function () {
	"use strict";

	return {

		statusIcon: function (sStatus) {
			

			switch (sStatus) {
				case "ExistApp":
					return "sap-icon://status-positive";
				case "Exist":
					 return "sap-icon://status-negative";
				case "None":
					 return "sap-icon://status-inactive";
				default:
					return  "sap-icon://status-critical";
			}
		},
		statusState: function (sStatus) {
			

			switch (sStatus) {
				case "ExistApp":
					return "Success";
				case "Exist":
					 return "Error";
				case "None":
					 return "None";
				default:
					return  "Warning";
			}
		},
		areaText: function(sArea){
			
			switch(sArea){
				case "NTH":
					return "North";
				case "STH":
					return "South";
				case "EST":
					return "East";
				default:
					return "Mobile";
			}
		}
		
	};
});